﻿
namespace Pacom.Peripheral.AlarmManagement
{
    public enum AlarmQueueSource
    {
        None,
        Sram,
        SdCard
    }
}
