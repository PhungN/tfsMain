﻿
namespace Pacom.Peripheral.AlarmManagement
{
    internal enum SubscriberType
    {
        StaticClasses = 0,
        AccessControl = 1,
        FrontEnd = 2,
        StatusAndConfiguration = 3,
        Firmware = 4,
        Expression = 5,
        DeviceLoop = 6,
    }
}
