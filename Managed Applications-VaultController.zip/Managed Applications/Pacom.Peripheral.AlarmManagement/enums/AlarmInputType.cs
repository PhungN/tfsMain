﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.AlarmManagement
{
    public enum AlarmInputType
    {
        Any = -1,
        InputPoint = 0,
        CardReader = 1,
        InfraredSensor = 2
    }
}
