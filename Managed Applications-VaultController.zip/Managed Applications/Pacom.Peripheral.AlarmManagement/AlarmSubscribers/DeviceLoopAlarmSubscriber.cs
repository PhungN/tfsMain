﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AlarmManagement
{
    public class DeviceLoopAlarmSubscriber : IDisposable
    {
        private static DeviceLoopAlarmSubscriber instance = null;

        public static DeviceLoopAlarmSubscriber CreateInstance()
        {
            if (instance == null)
                instance = new DeviceLoopAlarmSubscriber();
            return instance;
        }

        public static DeviceLoopAlarmSubscriber Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AlarmManager, () =>
                    {
                        return "DeviceLoopAlarmSubscriber instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
#endif
                return instance;
            }
        }

        public DeviceLoopAlarmSubscriber()
        {
            if (AlarmManager.Instance == null)
                throw new ArgumentNullException("AlarmManager", "SUBSCRIBER: AlarmManager must be created first.");
            ((AlarmManager)(AlarmManager.Instance)).RegisterEvents(SubscriberType.DeviceLoop);
        }
        
        #region IDisposable Members

        public void Dispose()
        {
            ((AlarmManager)(AlarmManager.Instance)).UnregisterEventsForType(SubscriberType.DeviceLoop);
            instance = null;
        }

        #endregion
    }
}
