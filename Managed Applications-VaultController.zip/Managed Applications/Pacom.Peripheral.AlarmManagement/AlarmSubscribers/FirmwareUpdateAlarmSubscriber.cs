﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.FrontEndConnection;

namespace Pacom.Peripheral.AlarmManagement
{
    public class FirmwareUpdateAlarmSubscriber : IDisposable
    {
        private static FirmwareUpdateAlarmSubscriber instance = null;

        public static FirmwareUpdateAlarmSubscriber CreateInstance()
        {
            if (instance == null)
                instance = new FirmwareUpdateAlarmSubscriber();
            return instance;
        }

        public static FirmwareUpdateAlarmSubscriber Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AlarmManager, () =>
                    {
                        return "FirmwareUpdateAlarmSubscriber instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
#endif
                return instance;
            }
        }

        private FirmwareUpdateAlarmSubscriber()
        {
            if (AlarmManager.Instance == null)
                throw new ArgumentNullException("AlarmManager", "SUBSCRIBER: AlarmManager must be created first.");
            if (FirmwareManager.Instance == null)
                throw new ArgumentNullException("FirmwareManager", "SUBSCRIBER: FirmwareManager must be created first.");
            ((AlarmManager)(AlarmManager.Instance)).RegisterEvents(SubscriberType.Firmware);
        }

        #region IDisposable Members

        public void Dispose()
        {
            ((AlarmManager)(AlarmManager.Instance)).UnregisterEventsForType(SubscriberType.Firmware);
            instance = null;
        }

        #endregion
    }
}
