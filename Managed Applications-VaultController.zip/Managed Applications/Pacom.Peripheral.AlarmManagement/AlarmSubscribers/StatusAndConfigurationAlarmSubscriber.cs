﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.AlarmManagement
{
    public class StatusAndConfigurationAlarmSubscriber : IDisposable
    {
        private static StatusAndConfigurationAlarmSubscriber instance = null;

        public static StatusAndConfigurationAlarmSubscriber CreateInstance()
        {
            if (instance == null)
                instance = new StatusAndConfigurationAlarmSubscriber();
            return instance;
        }

        public static StatusAndConfigurationAlarmSubscriber Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AlarmManager, () =>
                    {
                        return "StatusAlarmSubscriber instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
#endif
                return instance;
            }
        }

        public StatusAndConfigurationAlarmSubscriber()
        {
            if (AlarmManager.Instance == null)
                throw new ArgumentNullException("AlarmManager", "SUBSCRIBER: AlarmManager must be created first.");
            if (StatusManager.Instance == null)
                throw new ArgumentNullException("StatusManager", "SUBSCRIBER: StatusManager must be created first.");
            if (ConfigurationManager.Instance == null)
                throw new ArgumentNullException("ConfigurationManager", "SUBSCRIBER: ConfigurationManager must be created first.");
            ((AlarmManager)(AlarmManager.Instance)).RegisterEvents(SubscriberType.StatusAndConfiguration);
        }

        #region IDisposable Members

        public void Dispose()
        {
            ((AlarmManager)(AlarmManager.Instance)).UnregisterEventsForType(SubscriberType.StatusAndConfiguration);
            instance = null;
        }

        #endregion
    }
}
