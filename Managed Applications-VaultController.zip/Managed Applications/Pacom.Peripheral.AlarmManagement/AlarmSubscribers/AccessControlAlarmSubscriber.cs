﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.AccessControl;

namespace Pacom.Peripheral.AlarmManagement
{
    public class AccessControlAlarmSubscriber : IDisposable
    {
        private static AccessControlAlarmSubscriber instance = null;

        public static AccessControlAlarmSubscriber CreateInstance()
        {
            if (instance == null)
                instance = new AccessControlAlarmSubscriber();
            return instance;
        }

        public static AccessControlAlarmSubscriber Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AlarmManager, () =>
                    {
                        return "AccessControlAlarmSubscriber instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
#endif
                return instance;
            }
        }

        public AccessControlAlarmSubscriber()
        {
            if (AlarmManager.Instance == null)
                throw new ArgumentNullException("AlarmManager", "SUBSCRIBER: AlarmManager must be created first.");
            if (AccessControlManager.Instance == null)
                throw new ArgumentNullException("AccessControlManager", "SUBSCRIBER: AccessControlManager must be created first.");
            ((AlarmManager)(AlarmManager.Instance)).RegisterEvents(SubscriberType.AccessControl);
        }
        
        #region IDisposable Members

        public void Dispose()
        {
            ((AlarmManager)(AlarmManager.Instance)).UnregisterEventsForType(SubscriberType.AccessControl);
            instance = null;
        }

        #endregion
    }
}
