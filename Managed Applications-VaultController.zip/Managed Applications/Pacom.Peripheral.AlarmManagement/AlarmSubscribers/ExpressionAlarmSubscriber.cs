﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.AccessControl;

namespace Pacom.Peripheral.AlarmManagement
{
    public class ExpressionAlarmSubscriber : IDisposable
    {
        private static ExpressionAlarmSubscriber instance = null;

        public static ExpressionAlarmSubscriber CreateInstance()
        {
            if (instance == null)
                instance = new ExpressionAlarmSubscriber();
            return instance;
        }

        public static ExpressionAlarmSubscriber Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AlarmManager, () =>
                    {
                        return "ExpressionAlarmSubscriber instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
#endif
                return instance;
            }
        }

        public ExpressionAlarmSubscriber()
        {
            if (Macros.MacroManager.Instance == null)
                throw new ArgumentNullException("Expression", "SUBSCRIBER: ExpressionManager must be created first.");
            ((AlarmManager)(AlarmManager.Instance)).RegisterEvents(SubscriberType.Expression);
        }
        
        #region IDisposable Members

        public void Dispose()
        {
            ((AlarmManager)(AlarmManager.Instance)).UnregisterEventsForType(SubscriberType.Expression);
            instance = null;
        }

        #endregion
    }
}
