﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.FrontEndConnection;

namespace Pacom.Peripheral.AlarmManagement
{
    public class FrontEndAlarmSubscriber : IDisposable
    {
        private static FrontEndAlarmSubscriber instance = null;

        public static FrontEndAlarmSubscriber CreateInstance()
        {
            if (instance == null)
                instance = new FrontEndAlarmSubscriber();
            return instance;
        }

        public static FrontEndAlarmSubscriber Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AlarmManager, () =>
                    {
                        return "FrontEndAlarmSubscriber instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
#endif
                return instance;
            }
        }

        private FrontEndAlarmSubscriber()
        {
            if (AlarmManager.Instance == null)
                throw new ArgumentNullException("AlarmManager", "SUBSCRIBER: AlarmManager must be created first.");
            if (FrontEndConnectionManager.Instance == null)
                throw new ArgumentNullException("FrontEndConnectionManager", "SUBSCRIBER: FrontEndConnectionManager must be created first.");
            ((AlarmManager)(AlarmManager.Instance)).RegisterEvents(SubscriberType.FrontEnd);
        }

        #region IDisposable Members

        public void Dispose()
        {
            ((AlarmManager)(AlarmManager.Instance)).UnregisterEventsForType(SubscriberType.FrontEnd);
            instance = null;
        }

        #endregion
    }
}
