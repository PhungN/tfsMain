﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Check if any short text message is ready to be sent
    /// </summary>
    internal class CellularCheckSmsSending : CellularMonitoringBase
    {
        /// <summary>
        /// Constructor for cellular checks
        /// </summary>
        /// <param name="periodConnected">Time required to wait between execution while connected.</param>
        /// <param name="periodDisconnected">Time required to wait between execution while disconnected.</param>
        /// <param name="executionType">Indicate when is the item executed.</param>
        internal CellularCheckSmsSending(int periodConnected, int periodDisconnected, CellularMonitoringBehaviour executionType)
            : base(periodConnected, periodDisconnected, executionType)
        {
        }

        internal override void Action(CellularConnectionItem connectionItem)
        {
            if (connectionItem.NetworkRegistration == GprsNetworkRegistration.NotRegistered
                || connectionItem.NetworkRegistration == GprsNetworkRegistration.RegistrationDenied
                || connectionItem.NetworkRegistration == GprsNetworkRegistration.Searching
                || connectionItem.NetworkRegistration == GprsNetworkRegistration.Unknown)
            {
                this.CheckEnabled = true;
                this.NextCheck.Reset();
                return;
            }
                        
            // Prepare modem for sending message
            CellularSmsProvider sms = new CellularSmsProvider(connectionItem.ModemMonitoringPort);
            if (sms.SetTextMode() == false)
            {
                connectionItem.GeneralErrorHasOccurred();
                return;
            }

            // Send up to 10 messages here.
            bool isLastMessage = true; // It is last message so far.
            for (int iSend = 0; iSend < 10; iSend++)
            {

                if (connectionItem.IsDisposing == true)
                    return;

                CellularShortMessageItem item;
                if (connectionItem.ParentManager.GetSmsItem(out isLastMessage, out item) == true)
                {
                    if (sms.BeginSms(item.PhoneNumber) == true)
                    {
                        sms.WriteSms(item.Message);
                        int messageReference;
                        if (sms.EndSms(out messageReference) == true)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                            {
                                return string.Format("SMS #{0} sent to {1}", messageReference, item.PhoneNumber);
                            });
                        }
                        else
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                            {
                                return string.Format("Unable to send SMS to {0}", item.PhoneNumber);
                            });
                        }
                    }
                }
                else
                    break;
            }
            if (connectionItem.IsDisposing == true)
                return;
            // Schedule the check to be executed again
            if (isLastMessage == false)
            {
                this.CheckEnabled = true;
                this.NextCheck.Reset();
            }
        }

        public override string ToString()
        {
            return "Check SMS Sending";
        }
    }
}
