﻿using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Base class for cellular checks and monitoring
    /// </summary>
    internal abstract class CellularMonitoringBase
    {
        /// <summary>
        /// Constructor for cellular checks and monitoring
        /// </summary>
        /// <param name="periodConnected">Time required to wait between execution while connected.</param>
        /// <param name="periodDisconnected">Time required to wait between execution while disconnected.</param>
        /// <param name="executionType">Indicate when is the item executed.</param>
        internal CellularMonitoringBase(int periodConnected, int periodDisconnected, CellularMonitoringBehaviour executionType)
        {
            this.PeriodConnected = periodConnected;
            this.PeriodDisconnected = periodDisconnected;
            this.ExecutionType = executionType;
            this.CheckEnabled = true;
        }

        /// <summary>
        /// Indicates when is the item executed.
        /// </summary>
        internal CellularMonitoringBehaviour ExecutionType
        {
            get;
            private set;
        }

        /// <summary>
        /// Time between executions while connected. If zero the action will be only executed once.
        /// </summary>
        internal int PeriodConnected
        {
            get;
            private set;
        }

        /// <summary>
        /// Time between executions while disconnected. If zero the action will be only executed once.
        /// </summary>
        internal int PeriodDisconnected
        {
            get;
            private set;
        }

        /// <summary>
        /// If True, the check operation can be performed
        /// </summary>
        internal bool CheckEnabled
        {
            get;
            set;
        }

        /// <summary>
        /// Expire of the timer will cause check to be executed
        /// </summary>
        private TimeLimit nextCheck = new TimeLimit(0, false);
        internal TimeLimit NextCheck
        {
            get { return nextCheck; }
        }

        internal void Execute(CellularConnectionItem connectionItem)
        {
            try
            {
                Action(connectionItem);
            }
            catch
            {                
                Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                {
                    return string.Format("Error while executing monitoring item. [{0} on {1}]", this.ToString(), connectionItem.Port.ToString());
                });
            }
        }

        internal abstract void Action(CellularConnectionItem connectionItem);
    }
}
