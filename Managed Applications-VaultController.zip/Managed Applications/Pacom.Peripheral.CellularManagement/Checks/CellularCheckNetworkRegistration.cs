﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Update network registration details
    /// </summary>
    internal class CellularCheckNetworkRegistration : CellularMonitoringBase
    {
        /// <summary>
        /// Constructor for cellular checks
        /// </summary>
        /// <param name="periodConnected">Time required to wait between execution while connected.</param>
        /// <param name="periodDisconnected">Time required to wait between execution while disconnected.</param>
        /// <param name="executionType">Indicate when is the item executed.</param>
        internal CellularCheckNetworkRegistration(int periodConnected, int periodDisconnected, CellularMonitoringBehaviour executionType)
            : base(periodConnected, periodDisconnected, executionType)
        {
        }
        
        internal override void Action(CellularConnectionItem connectionItem)
        {
            GprsNetworkRegistration registration = GprsNetworkRegistration.NotRegistered;
            var networks = new CellularScanNetworks(connectionItem.ModemMonitoringPort);
            if (networks.GetNetworkRegistration(out registration) == false)
                connectionItem.GeneralErrorHasOccurred();

            connectionItem.NetworkRegistration = registration;
            if (registration == GprsNetworkRegistration.NotRegistered
                || registration == GprsNetworkRegistration.RegistrationDenied
                || registration == GprsNetworkRegistration.Unknown)
            {
                connectionItem.NoNetworkErrorHasOccurred();
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
            {
                return string.Format("Network registration: {0}", registration.ToString());
            });
            // When not registered, the SIM card could be removed. Terminate the call if present.
            // The network registration drops sometime during normal operation. Sometimes the modem starts searching soon after.
            if (connectionItem.IsConnected == true
                && (registration == GprsNetworkRegistration.NotRegistered
                    || registration == GprsNetworkRegistration.RegistrationDenied
                    || registration == GprsNetworkRegistration.Searching))
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                {
                    return "Terminating cellular connection due to network registration problems.";
                });
                connectionItem.HangupCellularConnection();
            }
        }

        public override string ToString()
        {
            return "Check Network Registration";
        }
    }
}
