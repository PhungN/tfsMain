﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Update signal strength details
    /// </summary>
    internal class CellularCheckSignalStrength : CellularMonitoringBase
    {
        /// <summary>
        /// Constructor for cellular checks
        /// </summary>
        /// <param name="periodConnected">Time required to wait between execution while connected.</param>
        /// <param name="periodDisconnected">Time required to wait between execution while disconnected.</param>
        /// <param name="executionType">Indicate when is the item executed.</param>
        internal CellularCheckSignalStrength(int periodConnected, int periodDisconnected, CellularMonitoringBehaviour executionType)
            : base(periodConnected, periodDisconnected, executionType)
        {
        }

        internal override void Action(CellularConnectionItem connectionItem)
        {
            GprsNetworkSignalStrength signal = GprsNetworkSignalStrength.AutoConfigurationIncomplete;
            var networks = new CellularScanNetworks(connectionItem.ModemMonitoringPort);
            if (networks.GetSignalStrength(out signal) == false)
            {
                connectionItem.GeneralErrorHasOccurred();
                return;
            }
            connectionItem.SignalStrength = signal;
            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
            {
                return string.Format("Signal strength: {0}", signal.ToString());
            });
        }

        public override string ToString()
        {
            return "Check Signal Strength";
        }
    }
}
