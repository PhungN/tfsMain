﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Hal;
using System.Net;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Update RAS link statistics
    /// </summary>
    internal class CellularCheckRasStats : CellularMonitoringBase
    {
        /// <summary>
        /// Constructor for cellular checks
        /// </summary>
        /// <param name="periodConnected">Time required to wait between execution while connected.</param>
        /// <param name="periodDisconnected">Time required to wait between execution while disconnected.</param>
        /// <param name="executionType">Indicate when is the item executed.</param>
        internal CellularCheckRasStats(int periodConnected, int periodDisconnected, CellularMonitoringBehaviour executionType)
            : base(periodConnected, periodDisconnected, executionType)
        {
        }

        internal override void Action(CellularConnectionItem connectionItem)
        {
            // Only check the statistics if connection was established.
            if (connectionItem.IsConnected == false)
                return;
            // Call the RAS 
            uint dwBytesXmited = 0;
            uint dwBytesRcved = 0;
            uint dwDurationMin = 0;
            uint dwDurationSecs = 0;
            if (NativeRasAPI.RasGetGprsLinkStatistics(connectionItem.RasEntryName, 
                ref dwBytesXmited, ref dwBytesRcved, ref dwDurationMin, ref dwDurationSecs) != 0)
            {
                connectionItem.GeneralErrorHasOccurred();
                return;
            }
            // Get hours
            uint dwDurationHours = dwDurationMin / 60;
            dwDurationMin = dwDurationMin - (dwDurationHours * 60);             
            // Log
            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
            {
                return string.Format("RAS check : Tx:{0} Rx:{1} Duration:{2}h {3}m {4}s", 
                    dwBytesXmited, dwBytesRcved, dwDurationHours, dwDurationMin, dwDurationSecs);
            });
            // Report to status manager
            TimeSpan duration = new TimeSpan((int)dwDurationHours, (int)dwDurationMin, (int)dwDurationSecs);
            connectionItem.ExpansionCardStatus.UpdateConnectionStatistics((int)dwBytesXmited, (int)dwBytesRcved, duration);

            // Check the IP address lease for the connection and report
            IPAddress address;
            if (connectionItem.GetCellularIPAddress(out address) == true)
                connectionItem.ExpansionCardStatus.UpdateConnectionIPAddress(address);
            else
                connectionItem.ExpansionCardStatus.UpdateConnectionIPAddress(IPAddress.None);
        }

        public override string ToString()
        {
            return "Check RAS Status";
        }
    }
}
