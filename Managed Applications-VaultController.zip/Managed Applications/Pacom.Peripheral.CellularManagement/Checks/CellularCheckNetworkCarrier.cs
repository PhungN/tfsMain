﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Update network carrier
    /// </summary>
    internal class CellularCheckNetworkCarrier : CellularMonitoringBase
    {
        /// <summary>
        /// Constructor for cellular checks
        /// </summary>
        /// <param name="periodConnected">Time required to wait between execution while connected.</param>
        /// <param name="periodDisconnected">Time required to wait between execution while disconnected.</param>
        /// <param name="executionType">Indicate when is the item executed.</param>
        internal CellularCheckNetworkCarrier(int periodConnected, int periodDisconnected, CellularMonitoringBehaviour executionType)
            : base(periodConnected, periodDisconnected, executionType)
        {
        }

        internal override void Action(CellularConnectionItem connectionItem)
        {
            string foundOperator = string.Empty;
            CellularAccessTechnology foundAccessTechnology = CellularAccessTechnology.Unknown;
            if (connectionItem.NetworkRegistration == GprsNetworkRegistration.Registered
                || connectionItem.NetworkRegistration == GprsNetworkRegistration.RegisteredRoaming)
            {
                var networks = new CellularScanNetworks(connectionItem.ModemMonitoringPort);
                networks.SetCarrierSelectionReporting(OperatorSelectionFormat.Long);

                OperatorSelectionMode mode;
                OperatorSelectionFormat format;

                if (networks.GetCurrentCarrier(out mode, out format, out foundOperator, out foundAccessTechnology) == true)
                {
                    if (format != OperatorSelectionFormat.Long)
                        foundOperator = string.Empty;
                }
                else
                {
                    connectionItem.GeneralErrorHasOccurred();
                }
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
            {
                if (string.IsNullOrEmpty(foundOperator) == true)
                    return "Current carrier: Not found or Searching";
                else
                    return string.Format("Current carrier: \"{0}\" Access technology: {1}", foundOperator, foundAccessTechnology.ToString());
            });
            connectionItem.ExpansionCardStatus.UpdateCellularCarrier(foundOperator, foundAccessTechnology);
        }

        public override string ToString()
        {
            return "Check Network Carrier";
        }
    }
}
