﻿using System;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Check if connection has been disconnected unexceptionally. Reconnect if disconnected. Supervise connection lockups.
    /// </summary>
    internal class CellularCheckBringUp : CellularMonitoringBase
    {
        /// <summary>
        /// Constructor for cellular checks
        /// </summary>
        /// <param name="periodConnected">Time required to wait between execution while connected.</param>
        /// <param name="periodDisconnected">Time required to wait between execution while disconnected.</param>
        /// <param name="executionType">Indicate when is the item executed.</param>
        internal CellularCheckBringUp(int periodConnected, int periodDisconnected, CellularMonitoringBehaviour executionType)
            : base(periodConnected, periodDisconnected, executionType)
        {
        }

        /// <summary>
        /// In case the signal fails during establishing connection, the function locks. The modem generates the NO CARRIER final unsolicited code, but RAS 
        /// does not seem to handle it. This timer method will guard the case and unlock the EstablishCellularConnection function.
        /// </summary>
        private IPacomTimer superviseEstablishConnection = null;

        /// <summary>
        /// Give the connection some time to negotiate the Internet connection.
        /// </summary>
        private const int maxEstablishUntilLockupDetected = 90000;

        /// <summary>
        /// Timer method to supervise establish connection.
        /// </summary>
        /// <param name="state">The CellularConnectionItem instance</param>
        private void supervisedConnection(object state)
        {
            try
            {
                CellularConnectionItem connectionItem = state as CellularConnectionItem;
                if (connectionItem == null)
                    return;
                Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                {
                    return string.Format("Supervised hungup triggered for {0}.", connectionItem.Port.ToString());
                });
                connectionItem.HangupCellularConnection();
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                {
                    return string.Format("Error occurred during supervised hungup. {0}", ex.Message);
                });
            }
        }

        private bool reconnect(CellularConnectionItem connectionItem, string reason)
        {
            superviseEstablishConnection = TimerManager.Instance.CreateTimer(supervisedConnection, connectionItem, maxEstablishUntilLockupDetected, Timeout.Infinite);
            try
            {
                if (connectionItem.EstablishCellularConnection() == true)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, () =>
                    {
                        return string.Format("Reconnected on {0} ({1})", connectionItem.Port.ToString(), reason);
                    });
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                superviseEstablishConnection.Change(Timeout.Infinite, Timeout.Infinite);
                TimerManager.Instance.RemoveTimer(superviseEstablishConnection);
            }
        }

        internal override void Action(CellularConnectionItem connectionItem)
        {
            // Check network registration
            if (connectionItem.NetworkRegistration == GprsNetworkRegistration.Registered
                || connectionItem.NetworkRegistration == GprsNetworkRegistration.RegisteredRoaming)
            {
                bool forceDisconnect = false;
                try
                {
                    // Check if not connected
                    if (connectionItem.IsConnected == false)
                    {
                        // Just simple not connected
                        forceDisconnect = reconnect(connectionItem, "RAS not connected") == false;
                    }
                    else if (connectionItem.IPAddressAssigned == false) // It is connected but IP address is not set for the modem
                    {
                        // The RAS entry could be still present
                        connectionItem.HangupCellularConnection();
                        Thread.Sleep(2000);
                        // Reconnect
                        forceDisconnect = reconnect(connectionItem, "IP address not assigned") == false;
                    }
                }
                catch
                {
                    forceDisconnect = true;
                }
                Thread.Sleep(1000);
                if (forceDisconnect == true)
                {
                    connectionItem.GeneralErrorHasOccurred();
                    connectionItem.HangupCellularConnection();
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                    {
                        return string.Format("Disconnection forced on {0}.", connectionItem.Port.ToString());
                    });
                }
            }
        }

        public override string ToString()
        {
            return "Checking Active Connection";
        }
    }
}
