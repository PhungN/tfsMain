﻿using System;
using System.IO.Ports;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.ExpansionCards;

namespace Pacom.Peripheral.CellularManagement
{
    public class CellularConnectionDataItem
    {
        /// <summary>
        /// Create current cellular parameters storage
        /// </summary>
        /// <param name="port"></param>
        public CellularConnectionDataItem(PhysicalSerialPort port)
        {            
            this.Port = port;           
            switch (port)
            {
                case PhysicalSerialPort.ExpansionCard1:
                    this.modemName = "Modem on COM2";
                    this.rasEntryName = "GPRS on COM2";
                    break;
                case PhysicalSerialPort.ExpansionCard2:
                    this.modemName = "Modem on COM3";
                    this.rasEntryName = "GPRS on COM3";
                    break;
                default:
                    throw new ArgumentException("Unknown port.");
            }
            Clear();            
        }
                
        public PhysicalSerialPort Port
        {
            get;
            private set;
        }
        
        private string modemName = string.Empty;
        public string ModemName
        {
            get { return this.modemName; }
        }

        private string rasEntryName = string.Empty;
        public string RasEntryName
        {
            get { return this.rasEntryName; }
        }

        private int portBaudRate = 0;
        public int PortBaudRate
        {
            get { return this.portBaudRate; }
            set { this.portBaudRate = value; }
        }

        private Parity portParity = Parity.None;
        public Parity PortParity
        {
            get { return this.portParity; }
            set { this.portParity = value; }
        }

        private int portDataBits = 8;
        public int PortDataBits
        {
            get { return this.portDataBits; }
            set { this.portDataBits = value; }
        }

        private StopBits portStopBits = StopBits.None;
        public StopBits PortStopBits
        {
            get { return this.portStopBits; }
            set { this.portStopBits = value; }
        }

        private string[] initializationStrings = new string[0];
        public string[] InitializationStrings
        {
            get { return initializationStrings; }
            set
            {
                if (value == null)
                    initializationStrings = new string[0];
                else
                {
                    initializationStrings = value;
                    for (int i = 0; i < initializationStrings.Length; i++)
                    {
                        if (initializationStrings[i] == null)
                            initializationStrings[i] = string.Empty;
                        else if (initializationStrings[i].ToLower().Contains("<cr>") == false)
                            initializationStrings[i] = initializationStrings[i] + "<cr>";
                    }
                }
            }
        }

        private string dialModifier = string.Empty;
        public string DialModifier
        {
            get { return dialModifier; }
            set
            {
                if (value == null)
                    dialModifier = string.Empty;
                else
                    dialModifier = value;
            }
        }

        private string phoneNumber = string.Empty;
        public string PhoneNumber
        {
            get { return phoneNumber; }
            set
            {
                if (value == null)
                    phoneNumber = string.Empty;
                else
                    phoneNumber = value;
            }
        }

        private string userName = string.Empty;
        public string UserName
        {
            get { return userName; }
            set
            {
                if (value == null)
                    userName = string.Empty;
                else
                    userName = value;
            }
        }

        private string password = string.Empty;
        public string Password
        {
            get { return password; }
            set
            {
                if (value == null)
                    password = string.Empty;
                else
                    password = value;
            }
        }

        private string domain = string.Empty;
        public string Domain
        {
            get { return domain; }
            set
            {
                if (value == null)
                    domain = string.Empty;
                else
                    domain = value;
            }
        }

        public GprsAuthenticationType AuthenticationType
        {
            get;
            set;
        }
        /// <summary>
        /// Clear the GPRS connection storage
        /// </summary>
        public virtual void Clear()
        {
            this.PortBaudRate = 0;
            this.PortParity = Parity.None;
            this.PortDataBits = 8;
            this.PortStopBits = StopBits.None;
            this.InitializationStrings = new string[0];
            this.DialModifier = string.Empty;
            this.PhoneNumber = string.Empty;
            this.UserName = string.Empty;
            this.Password = string.Empty;
            this.Domain = string.Empty;
            this.AuthenticationType = GprsAuthenticationType.Pap;
        }

        /// <summary>
        /// Copy values from port and card configuration.
        /// </summary>
        /// <param name="portValue">Port configuration</param>
        /// <param name="cardValue">Expansion card configuration</param>
        public virtual void CopyFrom(Port8003GprsPortConfiguration portValue, IPacomGprsCard cardValue)
        {
            this.PortBaudRate = cardValue.PortBaudRate;
            this.PortParity = cardValue.PortParity;
            this.PortDataBits = cardValue.PortDataBits;
            this.PortStopBits = cardValue.PortStopBits;
            if (portValue == null)
            {
                this.InitializationStrings = new string[0];
                return;
            }

            this.UserName = portValue.UserName;
            this.Password = portValue.Password;
            this.Domain = portValue.Domain;
            this.AuthenticationType = portValue.AuthenticationType;

            if (cardValue is Pacom8201GprsCard)
            {
                // InitializationStrings can store up to 5 entries, limited by the OS
                // The first 3 entries will be fixed, the 4th will configure the authentication
                // and the final entry will be the user provided string
                string userString = null;
                if (portValue.InitializationString != null)
                {
                    userString = portValue.InitializationString.Replace("<cr>", "");
                    if (userString.Length < 3)
                        userString = null;
                }

                if (userString == null)
                {
                    this.InitializationStrings = new string[4];
                }
                else
                {
                    this.InitializationStrings = new string[5];
                    this.InitializationStrings[4] = userString + "<cr>";
                }
                this.InitializationStrings[0] = "AT&F<cr>";
                this.InitializationStrings[1] = "ATQ0V1E0&D0<cr>";
                this.InitializationStrings[2] = "AT+IFC=0,0<cr>";
                if (UserName.Length == 0)
                    this.InitializationStrings[3] = "AT+WPPP=0<cr>";
                else
                    this.InitializationStrings[3] = string.Format("AT+WPPP={0},1,\"{1}\",\"{2}\"<cr>", (int)AuthenticationType, UserName, Password);

                // The DialModifier property has become the Access Point Name (APN) but on older configurations, this may still
                // be a dial modifier.
                string dialModifier = portValue.DialModifier;
                if (dialModifier == null)
                    dialModifier = string.Empty;
                if (dialModifier.Length > 0 && dialModifier[0] == '+')
                {
                    this.DialModifier = dialModifier;
                }
                else
                {
                    this.DialModifier = string.Format("+CGDCONT=1,\"IP\",\"{0}\",\"0.0.0.0\",0,0", dialModifier);
                }
            }
            else  // 8210
            {
                // InitializationStrings can store up to 5 entries, limited by the OS
                // The first 2 entries will be fixed, the 3th will be the user provided string
                string userString = null;
                if (portValue.InitializationString != null)
                {
                    userString = portValue.InitializationString.Replace("<cr>", "");
                    if (userString.Length < 3)
                        userString = null;
                }

                if (userString == null)
                {
                    this.InitializationStrings = new string[2];
                }
                else
                {
                    this.InitializationStrings = new string[3];
                    this.InitializationStrings[2] = userString + "<cr>";
                }
                this.InitializationStrings[0] = "AT&F<cr>";
                this.InitializationStrings[1] = "ATQ0V1E0&D0<cr>";

                // The DialModifier property has become the Access Point Name (APN) but on older configurations, this may still
                // be a dial modifier.
                string dialModifier = portValue.DialModifier;
                if (dialModifier == null)
                    dialModifier = string.Empty;
                if (dialModifier.Length > 0 && dialModifier[0] == '+')
                {
                    this.DialModifier = dialModifier;
                }
                else
                {
                    this.DialModifier = string.Format("+CGDCONT=1,\"IP\",\"{0}\",\"\",0,0", portValue.DialModifier);
                }
            }
            this.PhoneNumber = "*99***1#";
        }
          
        /// <summary>
        /// Compare two connection items.
        /// </summary>
        /// <param name="inputConnection"></param>
        /// <returns>Returns True when the connection parameters are the same</returns>
        public virtual bool IsSameConnection(CellularConnectionDataItem inputConnection)
        {
            if (this.Port != inputConnection.Port)
                return false;
            if (string.Compare(this.ModemName, inputConnection.ModemName) != 0)
                return false;
            if (string.Compare(this.RasEntryName, inputConnection.RasEntryName) != 0)
                return false;
            if (this.PortBaudRate != inputConnection.PortBaudRate)
                return false;
            if (this.PortParity != inputConnection.PortParity)
                return false;
            if (this.PortDataBits != inputConnection.PortDataBits)
                return false;
            if (this.PortStopBits != inputConnection.PortStopBits)
                return false;
            if (this.InitializationStrings.Length != inputConnection.InitializationStrings.Length)
                return false;
            for (int i = 0; i < this.InitializationStrings.Length; i++)
            {
                if (string.Compare(this.InitializationStrings[i], inputConnection.InitializationStrings[i]) != 0)
                    return false;
            }
            if (string.Compare(this.DialModifier, inputConnection.DialModifier) != 0)
                return false;
            if (string.Compare(this.PhoneNumber, inputConnection.PhoneNumber) != 0)
                return false;
            if (string.Compare(this.UserName, inputConnection.UserName) != 0)
                return false;
            if (string.Compare(this.Password, inputConnection.Password) != 0)
                return false;
            if (string.Compare(this.Domain, inputConnection.Domain) != 0)
                return false;
            if (this.AuthenticationType != inputConnection.AuthenticationType)
                return false;
            return true;
        }             
    }
}
