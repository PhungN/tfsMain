﻿using System;
using System.Net;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// This class will be instantiated when the main status instance does not exist.
    /// </summary>
    internal class PhantomGprsExpansionCardStatus : IGprsExpansionCardStatus
    {
        #region IGprsExpansionCardStatus Members

        public GprsNetworkRegistration NetworkRegistration
        {
            get { return GprsNetworkRegistration.Unknown; }
            set { }
        }

        public GprsNetworkSignalStrength SignalStrength
        {
            get { return GprsNetworkSignalStrength.AutoConfigurationIncomplete; }
            set { }
        }

        public string CellularCarrier
        {
            get { return string.Empty; }
        }

        public CellularAccessTechnology CellularAccessTechnology
        {
            get { return CellularAccessTechnology.Unknown; }
        }

        public string CellularModuleSerialNumber
        {
            get { return string.Empty; }
        }

        public string CellularModuleRevision
        {
            get { return string.Empty; }
        }

        public string CellularModuleModel
        {
            get { return string.Empty; }
        }

        public string CellularModuleManufacturer
        {
            get { return string.Empty; }
        }

        public TimeSpan ConnectionDuration
        {
            get { return TimeSpan.Zero; }
        }

        public int ConnectionTransmittedBytes
        {
            get { return 0; }
        }

        public int ConnectionReceivedBytes
        {
            get { return 0; }
        }

        public IPAddress ConnectionIPAddress
        {
            get { return IPAddress.None; }
        }

        public void ClearCellularModuleStatistics()
        {            
        }

        public void ClearConnectionStatistics()
        {
        }

        public void UpdateConnectionStatistics(int txBytes, int rxBytes, TimeSpan duration)
        {
        }

        public void UpdateCellularModuleStatistics(string serialNumber, string revision, string model, string manufacturer)
        {
        }

        public void UpdateCellularCarrier(string carrier, CellularAccessTechnology act)
        {
        }

        public void UpdateConnectionIPAddress(System.Net.IPAddress address)
        {
        }

        public IGprsDataUsageDetails IGprsDataUsage
        {
            get { return null; }
        }

        #endregion
    }
}
