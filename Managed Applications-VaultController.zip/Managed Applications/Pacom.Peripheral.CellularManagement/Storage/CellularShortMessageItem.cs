﻿
namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// SMS holder for cellular manager and its connection.
    /// </summary>
    internal class CellularShortMessageItem
    {
        public CellularShortMessageItem(string phoneNumber, string message)
        {
            this.PhoneNumber = phoneNumber;
            this.Message = message;
        }
        
        internal string PhoneNumber
        {
            get;
            private set;
        }

        internal string Message
        {
            get;
            private set;
        }
    }
}
