﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using Microsoft.Win32;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.ExpansionCards;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Storage class for current Cellular connection parameters
    /// </summary>
    public class CellularConnectionItem : CellularConnectionDataItem, IDisposable
    {
        /// <summary>
        /// Cellular checks executed on active connections.
        /// </summary>
        /// <remarks>The time provided is in seconds.</remarks>
        private readonly CellularMonitoringBase[] connectionChecks = new CellularMonitoringBase[] 
        {
            new CellularCheckNetworkRegistration(30, 5, CellularMonitoringBehaviour.Periodic),
            new CellularCheckSignalStrength(15, 5, CellularMonitoringBehaviour.Periodic),
            new CellularCheckNetworkCarrier(50, 25, CellularMonitoringBehaviour.Periodic),
            new CellularCheckRasStats(20, 90, CellularMonitoringBehaviour.Periodic),
            new CellularCheckBringUp(45, 20, CellularMonitoringBehaviour.Periodic),
            new CellularCheckSmsSending(1, 1, CellularMonitoringBehaviour.OnceOnly),
            new CellularCheckSmsReceiving(1, 1, CellularMonitoringBehaviour.OnceOnly),
        };

        /// <summary>
        /// Create current cellular connection
        /// </summary>
        /// <param name="port"></param>
        /// <param name="expansionCard"></param>
        /// <param name="cellularCardLogicalId"></param>
        public CellularConnectionItem(PhysicalSerialPort port, IPacomGprsCard expansionCard, int cellularCardLogicalId)
            : base(port)
        {
            this.ExpansionCard = expansionCard;
            this.CellularCardLogicalId = cellularCardLogicalId;
            isSelectCarrierOK = true;
        }

        private CellularManager parentManager = null;

        /// <summary>
        /// Internal accessor to the cellular manager.
        /// </summary>
        internal CellularManager ParentManager
        {
            get { return this.parentManager;  }
        }

        /// <summary>
        /// Set parent of the connection which is the CellularManager. The connection needs to report events for processing externally to the CellularManager,
        /// but the manager is used for all event communication.
        /// </summary>
        /// <param name="cellularManager"></param>
        internal void SetParent(CellularManager cellularManager)
        {
            this.parentManager = cellularManager;
        }

        #region Error handling

        private int generalErrorCount = 0;

        /// <summary>
        /// General error count found since last reconnection.
        /// </summary>
        public int GeneralErrorCount
        {
            get { return generalErrorCount; }
        }

        /// <summary>
        /// Maximum error count allowed.
        /// </summary>
        public const int MaxGeneralErrorCount = 3;

        /// <summary>
        /// Note that an error has occurred.
        /// </summary>
        /// <returns></returns>
        internal void GeneralErrorHasOccurred()
        {
            this.generalErrorCount++;
            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
            {
                return string.Format("General error has been noted. [Count={0}]", this.generalErrorCount);
            });
        }

        private int noNetworkErrorCount = 0;

        /// <summary>
        /// No network error count.
        /// </summary>
        public int NoNetworkErrorCount
        {
            get { return noNetworkErrorCount; }
        }

        /// <summary>
        /// Maximum error count allowed.
        /// </summary>
        public const int MaxNoNetworkErrorCount = 25;

        /// <summary>
        /// Note that an error has occurred.
        /// </summary>
        /// <returns></returns>
        internal void NoNetworkErrorHasOccurred()
        {
            this.noNetworkErrorCount++;
            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
            {
                return string.Format("No network error has been noted. [Count={0}]", this.noNetworkErrorCount);
            });
        }

        private void resetErrors()
        {
            this.generalErrorCount = 0;
            this.noNetworkErrorCount = 0;
        }

        #endregion

        #region Configuration

        private bool valid = true;

        /// <summary>
        /// Indicates if the object should be still used during next recreating ports.
        /// </summary>
        internal bool Valid
        {
            get { return valid; }
            set { valid = value; }
        }

        /// <summary>
        /// Clear all configuration items. Invalidate the connection.
        /// </summary>
        public override void Clear()
        {
            base.Clear();
            this.expansionCard = null;
            this.cellularCardLogicalId = -1;
        }

        private IPacomGprsCard expansionCard = null;
        /// <summary>
        /// Expansion card where the cellular device is present
        /// </summary>
        internal IPacomGprsCard ExpansionCard
        {
            get { return expansionCard; }
            private set { expansionCard = value; }
        }
        
        private int cellularCardLogicalId = -1;
        /// <summary>
        /// Expansion card logical id.
        /// </summary>
        /// <remarks>Will be used to access status item.</remarks>
        internal int CellularCardLogicalId
        {
            get { return cellularCardLogicalId; }
            private set { cellularCardLogicalId = value; }
        }

        /// <summary>
        /// Compare two connection items.
        /// </summary>
        /// <param name="inputConnection">An instance of CellularConnectionItem or CellularConnectionDataItem class</param>
        /// <returns>Returns True when the connection parameters are the same</returns>
        public override bool IsSameConnection(CellularConnectionDataItem inputConnection)
        {
            CellularConnectionItem item = inputConnection as CellularConnectionItem;
            if (item != null && item.CellularCardLogicalId != this.CellularCardLogicalId)
                return false;
            return base.IsSameConnection(inputConnection);
        }

        /// <summary>
        /// Use this instance of status when the configuration was disposed, but before the manager disposes the connection.
        /// </summary>
        private PhantomGprsExpansionCardStatus phantomGprsExpansionCardStatus = new PhantomGprsExpansionCardStatus();

        /// <summary>
        /// Expansion Card Status item. It must be retrieved with soft cast as status is disposed between configuration changes.
        /// </summary>
        internal IGprsExpansionCardStatus ExpansionCardStatus
        {
            get
            {
                IGprsExpansionCardStatus status = StatusManager.Instance.ExpansionCards[cellularCardLogicalId] as GprsExpansionCardStatus;
                if (status != null)
                    return status;
                else
                    return phantomGprsExpansionCardStatus;
            }
        }

        #endregion

        #region Card status update

        private GprsNetworkSignalStrength signalStrength = GprsNetworkSignalStrength.AutoConfigurationIncomplete;
        
        /// <summary>
        /// Cellular card signal strength
        /// </summary>
        internal GprsNetworkSignalStrength SignalStrength
        {
            get { return signalStrength; }
            set
            {
                if (signalStrength != value)
                {
                    signalStrength = value;
                    this.ExpansionCardStatus.SignalStrength = signalStrength;
                    updateCardStatusLed();
                }
            }
        }

        private void updateCardStatusLed()
        {
            if (this.NetworkRegistration == GprsNetworkRegistration.Registered
                || this.NetworkRegistration == GprsNetworkRegistration.RegisteredRoaming)
            {                
                switch (signalStrength)
                {
                    case GprsNetworkSignalStrength.Good:
                        this.ExpansionCard.StatusLed = PacomCellularCardStatusLed.Good;
                        break;
                    case GprsNetworkSignalStrength.OK:
                        this.ExpansionCard.StatusLed = PacomCellularCardStatusLed.OK;
                        break;
                    case GprsNetworkSignalStrength.Poor:
                        this.ExpansionCard.StatusLed = PacomCellularCardStatusLed.Poor;
                        break;
                    case GprsNetworkSignalStrength.NoNetwork:
                        // Blink red
                        // This sometimes happens even the connection is ongoing.
                        this.ExpansionCard.StatusLed = PacomCellularCardStatusLed.NoNetwork;
                        break;
                    case GprsNetworkSignalStrength.AutoConfigurationIncomplete:
                        // Blink red
                        // This sometimes happens even the connection is ongoing.
                        this.ExpansionCard.StatusLed = PacomCellularCardStatusLed.NoNetwork; // Blink red
                        break;
                }
            }
            else
            {
                // Blink red
                this.ExpansionCard.StatusLed = PacomCellularCardStatusLed.NoNetwork;
            }
        }

        private GprsNetworkRegistration networkRegistration = GprsNetworkRegistration.Unknown;
        /// <summary>
        /// Cellular card network registration
        /// </summary>
        internal GprsNetworkRegistration NetworkRegistration
        {
            get { return networkRegistration; }
            set
            {
                if (networkRegistration != value)
                {
                    networkRegistration = value;
                    this.ExpansionCardStatus.NetworkRegistration = networkRegistration;
                    updateCardStatusLed();
                }
            }
        }

        #endregion

        #region Cellular connection functions

        /// <summary>
        /// Establish connection to the cellular network.
        /// </summary>
        /// <returns></returns>
        internal bool EstablishCellularConnection()
        {
            bool result = false;
            try
            {
                // Restore settings for modem
                restoreModemRegistry();

                // Prepare RAS entries and start dialling
                uint rasResult = NativeRasAPI.RasEstablishGprsConnection(RasEntryName, PhoneNumber, ModemName, UserName, Password, Domain);
                if (rasResult == Constants.ERROR_SUCCESS)
                {
                    result = true; // Mark it as true
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                    {
                        return string.Format("Cellular connection established on {0}.", Port.ToString());
                    });

                    // Start with check on position 0 in the checks array.
                    StartChecks();
                    this.IsConnected = true;
                    resetErrors();
                }
                else
                {
                    if (rasResult == Constants.ERROR_ALREADY_ASSIGNED)
                    {
                        result = true; // It is already connected, so mark it as true                        
                        Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                        {
                            return string.Format("Cellular connection already exist on {0}.", Port.ToString());
                        });
                        this.IsConnected = true;
                    }
                    else
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                        {
                            return string.Format("Unable to connect cellular to {0} on {1}.", string.IsNullOrEmpty(PhoneNumber) ? "[No Phone Number]" : PhoneNumber, Port.ToString());
                        });
                        this.IsConnected = false;
                    }
                    this.GeneralErrorHasOccurred();
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                {
                    return string.Format("Error occurred during preparing for a cellular call on {0}. {1}", Port.ToString(), ex.Message);
                });
                result = false;
            }
            return result;
        }

        /// <summary>
        /// Check if connection is established and requires hang-up to be called.
        /// </summary>
        internal bool HangupRequired
        {
            get
            {
                bool result = false;
                try
                {
                    result = NativeRasAPI.RasHangupRequired(RasEntryName);
                }
                catch (Exception ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                    {
                        return string.Format("Unable to check if cellular is connected on {0}. {1}", Port.ToString(), ex.Message);
                    });
                }
                return result;
            }
        }

        /// <summary>
        /// Hang-up connection to the cellular network.
        /// </summary>
        internal void HangupCellularConnection()
        {
            try
            {
                NativeRasAPI.RasHangupGprsConnection(RasEntryName);
                Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                {
                    return string.Format("Cellular connection hangup on {0}.", Port.ToString());
                });
                this.IsConnected = false;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                {
                    return string.Format("Error occurred during cellular hangup on {0}. {1}", Port.ToString(), ex.Message);
                });
            }
        }

        /// <summary>
        /// Check if the connection has been assigned IP address.
        /// </summary>
        internal bool IPAddressAssigned
        {
            get
            {
                IPAddress address;
                return GetCellularIPAddress(out address);
            }
        }

        /// <summary>
        /// Get current connection IP address.
        /// </summary>
        /// <param name="address">IP address assigned to the connection by remote site.</param>
        /// <returns>Returns True, if the connection IP address is found.</returns>
        internal bool GetCellularIPAddress(out IPAddress address)
        {
            NetworkInformation networkInformation;
            if (NetworkAdapter.Instance.GetNetworkInformation(false, out networkInformation))
            {
                foreach (NetworkAdapterInformation networkAdapterInformation in networkInformation.Adapters)
                {
                    if (networkAdapterInformation.Description == ModemName)
                    {
                        if (networkAdapterInformation.Addresses.Length > 0)
                        {
                            address = networkAdapterInformation.Addresses[0].IPAddress;
                            return true;
                        }
                        else
                        {
                            address = IPAddress.None;
                            return false;
                        }
                    }
                }
            }
            address = IPAddress.None;
            return false;
        }

        /// <summary>
        ///  Specifies the number of milliseconds to delay between modem commands.
        ///  Some modems cannot handle commands that are issued immediately after they have 
        ///  responded to a previous command. Maximum value is 500.
        /// </summary>
        private int commandSendDelay = 10;

        /// <summary>
        /// Update RAS registry settings
        /// </summary>
        private void restoreModemRegistry()
        {
            RegistryKey registryExtModemsKey = Registry.LocalMachine.OpenSubKey("ExtModems", true);
            if (registryExtModemsKey == null)
            {
                registryExtModemsKey = Registry.LocalMachine.CreateSubKey("ExtModems");
            }
            try
            {
                // Recreate modem key
                var modemName = registryExtModemsKey.GetSubKeyNames().FirstOrDefault(r => string.Compare(r, ModemName, true) == 0);
                if (modemName == null)
                {
                    registryExtModemsKey.CreateSubKey(ModemName);
                }
                // Open modem registry
                RegistryKey registryModemKey = registryExtModemsKey.OpenSubKey(ModemName, true);
                try
                {
                    // Recreate Config
                    var configName = registryModemKey.GetSubKeyNames().FirstOrDefault(r => string.Compare(r, "Config", true) == 0);
                    RegistryKey registryConfigKey = registryModemKey.OpenSubKey("Config", true);
                    if (registryConfigKey == null)
                    {
                        registryConfigKey = registryModemKey.CreateSubKey("Config");
                    }
                    try
                    {
                        registryConfigKey.SetValue("BaudRate", PortBaudRate, RegistryValueKind.DWord);
                        registryConfigKey.SetValue("CallSetupFailTimer", 16, RegistryValueKind.DWord);
                        registryConfigKey.SetValue("EnableFlowHard", 0, RegistryValueKind.DWord);
                        if (string.IsNullOrEmpty(DialModifier) == true)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                            {
                                return string.Format("Dial modifier is not set. The connection may not be established for {0}.", Port.ToString());
                            });
                        }
                        registryConfigKey.SetValue("DialModifier", DialModifier, RegistryValueKind.String);
                    }
                    finally
                    {
                        registryConfigKey.Close();
                    }
                    // Recreate Init key
                    RegistryKey registryInitKey = registryModemKey.OpenSubKey("Init", true);
                    if (registryInitKey == null)
                    {
                        registryInitKey = registryModemKey.CreateSubKey("Init");
                    }
                    try
                    {
                        string[] valueNames = registryInitKey.GetValueNames();
                        bool diffValueNames = false;
                        if (InitializationStrings.Length != valueNames.Length)
                        {
                            diffValueNames = true;
                        }
                        else
                        {
                            int len = valueNames.Length;
                            for (int i = 0; i < len; i++)
                            {
                                string initString = registryInitKey.GetValue(valueNames[len - 1 - i]).ToString();
                                if (string.Compare(InitializationStrings[i], initString, true) != 0)
                                {
                                    diffValueNames = true;
                                    break;
                                }
                            }
                        }
                        if (diffValueNames == true)
                        {
                            for (int i = 0; i < valueNames.Length; i++)
                            {
                                registryInitKey.DeleteValue(valueNames[i]);
                            }
                            if (InitializationStrings.Length != 0)
                            {
                                for (int j = 0; j < InitializationStrings.Length; j++)
                                {
                                    registryInitKey.SetValue((j + 1).ToString(), InitializationStrings[j], RegistryValueKind.String);
                                }
                            }
                        }
                    }
                    finally
                    {
                        registryInitKey.Close();
                    }
                    // Recreate Settings
                    var settingsName = registryModemKey.GetSubKeyNames().FirstOrDefault(r => string.Compare(r, "Settings", true) == 0);
                    RegistryKey registrySettingsKey = registryModemKey.OpenSubKey("Settings", true);
                    if (registrySettingsKey == null)
                    {
                        registrySettingsKey = registryModemKey.CreateSubKey("Settings");
                    }
                    try
                    {
                        registrySettingsKey.SetValue("Blind_Off", "", RegistryValueKind.String);
                        registrySettingsKey.SetValue("Blind_On", "", RegistryValueKind.String);
                        registrySettingsKey.SetValue("CallSetupFailTimeout", 60, RegistryValueKind.DWord);
                        registrySettingsKey.SetValue("CmdSendDelay", this.commandSendDelay, RegistryValueKind.DWord);
                        registrySettingsKey.SetValue("DialPrefix", "D", RegistryValueKind.String);
                        registrySettingsKey.SetValue("DialPrefix", "D", RegistryValueKind.String);
                        registrySettingsKey.SetValue("DialSufix", ";", RegistryValueKind.String);
                        registrySettingsKey.SetValue("MdmLogFile", 0, RegistryValueKind.DWord);
                        registrySettingsKey.SetValue("Prefix", "AT", RegistryValueKind.String);
                        registrySettingsKey.SetValue("Pulse", "P", RegistryValueKind.String);
                        registrySettingsKey.SetValue("Reset", "AT<cr>", RegistryValueKind.String);
                        registrySettingsKey.SetValue("Terminator", "<cr>", RegistryValueKind.String);
                        if (ExpansionCard.Type == ExpansionCardType.Pacom8201GprsCard)
                        {
                            registrySettingsKey.SetValue("Tone", "T", RegistryValueKind.String);
                        }
                        else
                        {
                            registrySettingsKey.SetValue("Tone", "", RegistryValueKind.String);
                        }
                    }
                    finally
                    {
                        registrySettingsKey.Close();
                    }
                }
                finally
                {
                    registryModemKey.Close();
                }
            }
            finally
            {
                registryExtModemsKey.Close();
            }
        }

        #endregion

        #region SMS related functions

        /// <summary>
        /// List of SMS reference numbers waiting to be received. Located in default memory
        /// </summary>
        private Queue<int> smsListToReceive = new Queue<int>();

        /// <summary>
        /// Lock on the receive list as adding and removing may happen at the same time.
        /// </summary>
        private readonly object smsListToReceiveLock = new object();

        /// <summary>
        /// Enqueue receive message from SIM card. It will only happen when connection is established.
        /// </summary>
        /// <param name="referenceNumber">Message reference number</param>
        internal void EnqueueSmsReceiveRequest(int referenceNumber)
        {
            lock (smsListToReceiveLock)
            {
                smsListToReceive.Enqueue(referenceNumber);
                WakeUpTask(typeof(CellularCheckSmsReceiving));
            }
        }

        /// <summary>
        /// Get one request to download SMS from SIM card.
        /// </summary>
        /// <param name="lastMessage">If True this was the last message.</param>
        /// <returns>Return -1 if there is no requests to download, or the message reference number in default memory.</returns>
        internal int GetSmsReceiveRequest(out bool lastMessage)
        {
            if (smsListToReceive.Count == 0)
            {
                lastMessage = true;
                return -1;
            }
            lock (smsListToReceiveLock)
            {
                int referenceNumber = smsListToReceive.Dequeue();
                lastMessage = smsListToReceive.Count == 0;
                return referenceNumber;
            }
        }

        #endregion

        #region Pariodic connection checks

        /// <summary>
        /// When the connection is established initialize the checks. Check tasks that should be executed on initialization.
        /// </summary>
        internal void StartChecks()
        {
            foreach (var check in connectionChecks)
            {
                if (check.ExecutionType == CellularMonitoringBehaviour.InitializationOnly)
                {
                    check.CheckEnabled = true;
                    check.Execute(this);
                    check.CheckEnabled = false;
                }
                else if (check.ExecutionType == CellularMonitoringBehaviour.Periodic
                    || check.ExecutionType == CellularMonitoringBehaviour.OnceOnly)
                {
                    check.CheckEnabled = true;
                    check.NextCheck.ExpectedDuration = check.PeriodDisconnected * 1000;
                    check.NextCheck.Reset();
                }
                else
                {
                    check.CheckEnabled = false;
                }
            }
        }

        /// <summary>
        /// "Wake" the specified type of task for processing.
        /// </summary>
        /// <param name="typeToWake">Type to wake from the connectionChecks list.</param>
        internal void WakeUpTask(Type typeToWake)
        {
            foreach (CellularMonitoringBase itemToCheck in connectionChecks)
            {
                if (itemToCheck.GetType() == typeToWake)
                    itemToCheck.CheckEnabled = true;
            }
            // Decide if we need to wake the main checking task
            if (lastConnectionCheck.ExpectedDuration - lastConnectionCheck.ElapsedTime > 2000)
                connectionsCheckEvent.Set();
        }

        /// <summary>
        /// Do connection checks on the line
        /// </summary>
        /// <param name="disposing">Indicates if the caller is requested to be disposed.</param>
        /// <returns>Next required check in milliseconds.</returns>
        internal int Check(ref bool callerDisposing)
        {
            if (disposing == true)
                return 1000;

            int nextCheck = -1;
            try
            {
                foreach (var check in connectionChecks)
                {
                    if (Application.Closing == true || callerDisposing == true)
                        break;

                    if (check.CheckEnabled == true
                        && (check.ExecutionType == CellularMonitoringBehaviour.Periodic
                            || check.ExecutionType == CellularMonitoringBehaviour.OnceOnly))
                    {
                        if (check is CellularCheckNetworkCarrier && isSelectCarrierOK == false)
                            continue;

                        int expectedDuration;
                        if (this.IsConnected)
                            expectedDuration = check.PeriodConnected * 1000;
                        else
                            expectedDuration = check.PeriodDisconnected * 1000;
                        check.NextCheck.ExpectedDuration = expectedDuration;                        
                        if (check.NextCheck.IsTimeUp(check.NextCheck.ExpectedDuration) == true)
                        {
                            if (check.ExecutionType == CellularMonitoringBehaviour.OnceOnly)
                                check.CheckEnabled = false;

                            check.Execute(this);
                            check.NextCheck.Reset();
                        }
                        int checkTimeToNextRun = check.NextCheck.ExpectedDuration - check.NextCheck.ElapsedTime;
                        // The result does not need to be lass than 0.5 second
                        if (checkTimeToNextRun < 500)
                            checkTimeToNextRun = 500;
                        if (checkTimeToNextRun < nextCheck || nextCheck < 0)
                            nextCheck = checkTimeToNextRun;
                    }
                    if (Application.Closing == true || callerDisposing == true)
                        break;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                {
                    return string.Format("Error while executing checks for {0}. {1}", Port.ToString(), ex.Message);
                });
                nextCheck = 5000;
            }
            if (nextCheck < 0)
                nextCheck = 5000;
            return nextCheck;
        }

        #endregion

        #region Connection status and servicing functions

        private const int maxSelectCarrierTries = 2;
        private bool isSelectCarrierOK;

        /// <summary>
        /// Main waiting event in the check thread method. It prevents this manager from taking too much processing time.
        /// </summary>
        private AutoResetEvent connectionsCheckEvent = new AutoResetEvent(false);

        /// <summary>
        /// Before the processing thread locks this timer is reset to measure the duration it was asleep.
        /// </summary>
        private TimeLimit lastConnectionCheck = new TimeLimit();

        private bool externalTerminating = false;

        private bool internalTerminating = false;

        /// <summary>
        /// If True, the connection is terminating from parent request. The connection class should not be used anymore.
        /// </summary>
        public bool IsTerminating { get { return this.externalTerminating; } }

        /// <summary>
        /// Request parent termination of connection processing thread.
        /// </summary>
        public void Terminate()
        {
            externalTerminating = true;
            // During modem initialization a temporary variable is used
            if (modemInitializationMonitoringPort != null)
                modemInitializationMonitoringPort.Terminate();
            connectionsCheckEvent.Set();
            checkSIMCardDelayEvent.Set();
        }

        /// <summary>
        /// Request internal termination of connection processing thread.
        /// </summary>
        private void internalTerminate()
        {
            internalTerminating = true;
            connectionsCheckEvent.Set();
            checkSIMCardDelayEvent.Set();
        }

        /// <summary>
        /// If true, the internal connection terminating thread must terminate.
        /// </summary>
        private bool isTerminating
        {
            get { return externalTerminating || internalTerminating; }
        }

        /// <summary>
        /// Unsolicited codes processing class.
        /// </summary>
        private UnsolicitedCodesHandler uscHandler = null;

        /// <summary>
        /// Process unsolicited codes 
        /// </summary>
        /// <param name="unsolicitedCodeMessage">Code type and additional information</param>
        internal void TriggerReceivedUnsolicitedCode(CellularUnsolicitedCodeBase unsolicitedCodeMessage)
        {
            switch (unsolicitedCodeMessage.UnsolicitedCode)
            {
                case CellularUnsolicitedCodes.SimCardRemoved:
                    // If SIM cad is removed stop processing. Restart the process to be ready to receive new SIM card.
                    this.internalTerminate();
                    break;
                case CellularUnsolicitedCodes.DeviceSpecificError:
                    UnsolicitedCodeDeviceSpecificError deviceSpecificError = (UnsolicitedCodeDeviceSpecificError)unsolicitedCodeMessage;
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                    {
                        return string.Format("Device Specific Error: {0}", deviceSpecificError.Message);
                    });
                    if (deviceSpecificError.IsCritical == true)
                        this.internalTerminate();
                    break;
                case CellularUnsolicitedCodes.NetworkSpecificError:
                    UnsolicitedCodeNetworkSpecificError networkSpecificError = (UnsolicitedCodeNetworkSpecificError)unsolicitedCodeMessage;
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                    {
                        return string.Format("Network Specific Error: {0}", networkSpecificError.Message);
                    });
                    if (networkSpecificError.IsCritical == true)
                        this.internalTerminate();
                    break;
                case CellularUnsolicitedCodes.SmsReceived:
                    UnsolicitedCodeSmsReceived smsMessage = (UnsolicitedCodeSmsReceived)unsolicitedCodeMessage;
                    // The memory will be skipped. Only the default memory will be used.
                    EnqueueSmsReceiveRequest(smsMessage.ReferenceNumber);
                    break;
            }
        }

        /// <summary>
        /// Modem monitoring port. Monitoring modem status.
        /// </summary>
        private CellularSerialConnection modemMonitoringPort = null;

        /// <summary>
        /// Modem monitoring port used during initialization. Monitoring modem status.
        /// </summary>
        private CellularSerialConnection modemInitializationMonitoringPort = null;

        /// <summary>
        /// Returns modem monitoring port which can be used to query modem status.
        /// </summary>
        internal ICellularSerialConnection ModemMonitoringPort
        {
            get { return modemMonitoringPort; }
        }

        private bool isConnected = false;

        /// <summary>
        /// If True, the connection is established. The IP address can be assigned at later time.
        /// </summary>
        public bool IsConnected
        {
            get { return this.isConnected; }
            private set
            {
                if (this.isConnected != value)
                {
                    this.isConnected = value;
                    if (this.isConnected == true)
                    {
                        IPAddress address;
                        if (this.GetCellularIPAddress(out address) == true)
                            this.ExpansionCardStatus.UpdateConnectionIPAddress(address);
                        else
                            this.ExpansionCardStatus.UpdateConnectionIPAddress(IPAddress.None);
                    }
                    else
                    {
                        this.ExpansionCardStatus.ClearConnectionStatistics();
                    }
                }
                if (this.parentManager != null)
                {
                    if (this.isConnected == true)
                        this.parentManager.TriggerConnectionEstablished();
                    else
                        this.parentManager.TriggerConnectionHangup();
                }
            }
        }

        /// <summary>
        /// In case of SIM card not being ready, use this event to wait. That will allow to stop the process in 
        /// timely fashion for e.g. configuration change.
        /// </summary>
        private ManualResetEvent checkSIMCardDelayEvent = new ManualResetEvent(false);


        private bool openMonitoringPorts()
        {
            if (modemMonitoringPort != null || uscHandler != null)
                return false;

            modemInitializationMonitoringPort = CellularSerialConnection.Create(PhysicalSerialPort.CellularMonitoring1Port);
            try
            {
                var verification = new CellularModemVerification(modemInitializationMonitoringPort);
                if (verification.Begin() == false)
                    return false;

                string serialNumber;
                if (verification.GetSerialNumber(out serialNumber) == false)
                    return false;

                string revision;
                if (verification.GetRevision(out revision) == false)
                    return false;

                string model;
                if (verification.GetModel(out model) == false)
                    return false;

                string manufacturer;
                if (verification.GetManufacturer(out manufacturer) == false)
                    return false;

                verification.DisableAutomaticAnswering();

                this.ExpansionCardStatus.UpdateCellularModuleStatistics(serialNumber, revision, model, manufacturer);

                // Select carrier. On older modem/GSM network it can take several seconds.
                // Lets give the modem to adjust to the network.
                Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                {
                    return "Switching to automatic carrier selection.";
                });
                // Indicate the network is being selected. The following procedure will fail if:
                // - The SIM card is not inserted correctly; check the SIM socket
                // - The SIM card listed operators are not found within the range of the module; contact the SIM issuer
                this.ExpansionCard.StatusLed = PacomCellularCardStatusLed.NoNetwork;
                if (isSelectCarrierOK == true)
                {
                    for (int i = 1; i <= maxSelectCarrierTries; i++)
                    {
                        var scanNetworks = new CellularScanNetworks(modemInitializationMonitoringPort);
                        if (scanNetworks.SetCarrierAutomaticSelection() == false)
                        {
                            if (i == maxSelectCarrierTries)
                            {
                                isSelectCarrierOK = false;
                                Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                                {
                                    return string.Format("Unable to set carrier autodetection for {0}. Check SIM card.", Port.ToString());
                                });
                                this.ExpansionCard.StatusLed = PacomCellularCardStatusLed.PortNotConfigured;
                                return false;
                            }
                            else
                            {
                                checkSIMCardDelayEvent.Reset();
                                if (disposing == true || externalTerminating == true || checkSIMCardDelayEvent.WaitOne(i * 5000, false) == true) // is signaled
                                {
                                    this.ExpansionCard.StatusLed = PacomCellularCardStatusLed.PortNotConfigured;
                                    return false;
                                }
                            }
                        }
                        else
                            break;
                    }
                }
                this.ExpansionCard.StatusLed = PacomCellularCardStatusLed.PortNotConfigured;
                                
                // All good. Attempt to create unsolicited codes handler
                uscHandler = UnsolicitedCodesHandler.Create(this, PhysicalSerialPort.CellularMonitoring2Port);
                // We are ready for handling port monitoring
                modemMonitoringPort = modemInitializationMonitoringPort;
                modemInitializationMonitoringPort = null;
                Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                {
                    return string.Format("Monitoring ports open for {0}.", Port.ToString());
                });
            }
            finally
            {
                // Check if connection must be disposed
                if (modemInitializationMonitoringPort != null)
                {
                    modemInitializationMonitoringPort.Dispose();
                    modemInitializationMonitoringPort = null;
                }
            }
            return true;
        }

        private void closeMonitoringPorts()
        {
            if (uscHandler != null)
            {
                uscHandler.Dispose();
                uscHandler = null;
            }
            // During initialization the following is used before the instance is assigned to the modemMonitoringPort variable.
            if (modemInitializationMonitoringPort != null)
            {
                modemInitializationMonitoringPort.Dispose();
                modemInitializationMonitoringPort = null;
            }
            if (modemMonitoringPort != null)
            {
                modemMonitoringPort.Dispose();
                modemMonitoringPort = null;
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
            {
                return string.Format("Closing monitoring port for {0}.", Port.ToString());
            });
        }

        /// <summary>
        /// Start connections. Open monitoring ports.
        /// </summary>
        public void BeginConnection()
        {
            // The modem could be just internally terminated, but the connection will be reused.
            this.internalTerminating = false;
            // Start handling the connection and monitoring ports.
            bool attemptToTerminate = false;
            try
            {
                // Check if any of the following are set, do not attempt any processing.
                if (Application.Closing == true || disposed == true || disposing == true || isTerminating == true)
                    return;
                try
                {
                    if (openMonitoringPorts() == false)
                    {
                        closeMonitoringPorts();
                        return;
                    }

                    int timeToNextCheck = 1000;
                    while (Application.Closing == false && this.disposed == false && this.disposing == false && isTerminating == false)
                    {
                        // Make note when the thread went to sleep
                        lastConnectionCheck.ExpectedDuration = timeToNextCheck;
                        lastConnectionCheck.Reset();
                        // Sleep until next wakeup or next time we need to check task
                        connectionsCheckEvent.WaitOne(timeToNextCheck, false);

                        if (Application.Closing == true || disposed == true || disposing == true || isTerminating == true)
                            break;

                        timeToNextCheck = 10;
                        int timeToNextCheckPerConnection = this.Check(ref disposing);

                        // Perform reset when modem is not responsive.
                        if (this.GeneralErrorCount >= CellularConnectionItem.MaxGeneralErrorCount)
                            break;

                        // Perform reset when unable to find network.
                        if (this.NoNetworkErrorCount >= CellularConnectionItem.MaxNoNetworkErrorCount)
                            break;

                        if (Application.Closing == true || disposed == true || disposing == true || isTerminating == true)
                            break;

                        if (timeToNextCheck < timeToNextCheckPerConnection)
                            timeToNextCheck = timeToNextCheckPerConnection;
                        // Make sure the thread always waits
                        if (timeToNextCheck >= 0 && timeToNextCheck < 1000)
                            timeToNextCheck = 1000;

                        // Perform reset when modem is not responsive.
                        if (this.GeneralErrorCount >= CellularConnectionItem.MaxGeneralErrorCount)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                            {
                                return "Terminating cellular connection due to too many general modem access errors.";
                            });
                            break;
                        }

                        // Perform reset when unable to find network.
                        if (this.NoNetworkErrorCount >= CellularConnectionItem.MaxNoNetworkErrorCount)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                            {
                                return "Terminating cellular connection due to too many network registration problems.";
                            });
                            break;
                        }

                        if (Application.Closing == true || disposed == true || disposing == true || isTerminating == true)
                            break;
                    }
                    // It is time to terminate the
                    if (this.IsConnected == true)
                        this.HangupCellularConnection();
                    this.closeMonitoringPorts();
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                    {
                        return string.Format("Cellular connection monitoring has been terminated for {0}. {1}", this.Port.ToString(), ex.Message);
                    });
                    attemptToTerminate = true;
                }
                // If the above code failed, try to terminate the connection again here.
                // This code must not return without terminating the RAS and monitoring connections.
                if (attemptToTerminate)
                {
                    // Not sure why the code above failed. Try dispose again after a delay.
                    Thread.Sleep(2500);
                    try
                    {
                        if (this.IsConnected == true)
                            this.HangupCellularConnection();
                        this.closeMonitoringPorts();
                    }
                    catch (Exception ex)
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                        {
                            return string.Format("Second attempt to terminate cellular connection has failed. {0}", ex.Message);
                        });
                    }
                }
            }
            finally
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                {
                    return "Cellular connection handler is stopped.";
                });
                // Cleanup the expansion card and status.
                this.expansionCard.StatusLed = PacomCellularCardStatusLed.PortNotConfigured;
                this.signalStrength = GprsNetworkSignalStrength.AutoConfigurationIncomplete;
                this.networkRegistration = GprsNetworkRegistration.Unknown;
                resetErrors();
                // Give a bit of time for expansion card to indicate the new status.
                Thread.Sleep(10);
            }
        }

        #endregion

        #region IDisposable Members

        bool disposed = false;
        
        bool disposing = false;

        /// <summary>
        /// Returns True if the connection item is disposing.
        /// </summary>
        internal bool IsDisposing
        {
            get { return this.disposing;  }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                if (disposing)
                {
                    this.disposing = true;
                    // Terminate the connection.
                    if (this.IsConnected == true)
                        this.HangupCellularConnection();
                    checkSIMCardDelayEvent.Set(); // Stop waiting for SIM card
                    this.closeMonitoringPorts();
                    // Clean up the status, locally and on the expansion card.
                    this.expansionCard.StatusLed = PacomCellularCardStatusLed.PortNotConfigured;
                    Thread.Sleep(100);
                    this.Clear();
                    if (connectionsCheckEvent != null)
                        connectionsCheckEvent.Close();
                    // Free any other managed objects here.
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                    {
                        return string.Format("Cellular connection is disposed on {0}.", this.Port.ToString());
                    });
                }

                // Free any unmanaged objects here.                        
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
