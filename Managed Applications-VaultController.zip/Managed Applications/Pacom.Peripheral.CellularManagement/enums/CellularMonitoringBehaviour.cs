﻿
namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Specifies when is cellular monitoring item executed.
    /// </summary>
    internal enum CellularMonitoringBehaviour
    {
        DoNotExecute,
        Periodic,
        OnceOnly,
        InitializationOnly,
    }
}
