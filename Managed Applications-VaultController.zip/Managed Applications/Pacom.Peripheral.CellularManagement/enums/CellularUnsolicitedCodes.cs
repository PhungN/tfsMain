﻿
namespace Pacom.Peripheral.CellularManagement
{
    public enum CellularUnsolicitedCodes
    {
        Undefined = 0,
        SimCardRemoved,
        SimCardInserted,
        DeviceSpecificError, // CME errors
        NetworkSpecificError, // CMS errors
        SmsReceived,
    }
}
