﻿
namespace Pacom.Peripheral.CellularManagement
{
    public enum CellularNetworkStatus
    {
        Unknown = 0,
        Available = 1,
        Current = 2,
        Forbidden = 3
    }
}
