﻿
namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Operator selection format for +COPS command
    /// </summary>
    public enum OperatorSelectionFormat
    {
        /// <summary>
        /// Long format alphanumeric
        /// </summary>
        Long = 0,
        /// <summary>
        /// Short alphanumeric
        /// </summary>
        Short = 1,
        /// <summary>
        /// Numeric
        /// </summary>
        Numeric = 2
    }
}
