﻿
namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Cellular memory from which messages are read and deleted
    /// </summary>
    public enum CellularMessageMemoryType
    {
        Unknown,
        BM, // "BM" broadcast message storage
        ME, // "ME" message storage
        MT, // "MT" any of the storages associated with ME
        SM, // "SM" SIM message storage - Default Value coded into the module
        TA, // "TA" TA message storage
        SR, // "SR" status report storage
    }
}
