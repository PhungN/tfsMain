﻿
namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Operator selection mode for +COPS command
    /// </summary>
    public enum OperatorSelectionMode
    {
        Automatic = 0,
        Manual = 1,
        SetTheReadFormat = 3,
        ManualToAutomaticSwitchOnFailure = 4,
    }
}
