﻿
namespace Pacom.Peripheral.CellularManagement
{
    public class UnsolicitedCodeSmsReceived : CellularUnsolicitedCodeBase
    {
        public UnsolicitedCodeSmsReceived(CellularMessageMemoryType memory, int referenceNumber)
        {
            this.ReferenceNumber = referenceNumber;
            this.Memory = memory;
        }

        public int ReferenceNumber
        {
            private set;
            get;
        }

        public CellularMessageMemoryType Memory
        {
            private set;
            get;
        }

        public override CellularUnsolicitedCodes UnsolicitedCode
        {
            get { return CellularUnsolicitedCodes.SmsReceived; }
        }
    }
}
