﻿using System;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Hal;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Class responsible for handling unsolicited codes received from cellular module.
    /// </summary>
    public class UnsolicitedCodesHandler : IDisposable
    {
        /// <summary>
        /// Thread which will handle processing of URC messages.
        /// </summary>
        private Thread processingThread;

        /// <summary>
        /// Serial connection will block until message is received or purge is invoked on it.
        /// </summary>
        private CellularSerialConnection serialConn;

        /// <summary>
        /// This is parent class owning the handler.
        /// </summary>
        private CellularConnectionItem connectionItem = null;

        private UnsolicitedCodesHandler()
        {   
        }

        /// <summary>
        /// Create unsolicited codes handler for the specified parent and physical serial port.
        /// </summary>
        /// <param name="connectionItem">Parent class which will receive events notifications.</param>
        /// <param name="port">Physical serial port used for monitoring. Should be configured in MUX driver at the OS level.</param>
        /// <returns></returns>
        static public UnsolicitedCodesHandler Create(CellularConnectionItem connectionItem, PhysicalSerialPort port)
        {
            if (connectionItem == null)
                throw new ArgumentNullException("connectionItem");

            var obj = new UnsolicitedCodesHandler();
            if (obj.initialize(connectionItem, port) == false)
            {
                obj.Dispose();
                return null;
            }
            return obj;
        }

        /// <summary>
        /// Internal initialize.
        /// </summary>
        /// <param name="connectionItem">Parent class which will receive events notifications.</param>
        /// <param name="port">Physical serial port used for monitoring. Should be configured in MUX driver at the OS level.</param>
        /// <returns></returns>
        private bool initialize(CellularConnectionItem connectionItem, PhysicalSerialPort port)
        {
            try
            {                
                serialConn = CellularSerialConnection.Create(port);
                this.connectionItem = connectionItem;

                processingThread = new Thread(new ThreadStart(processingThreadMethod));
                processingThread.Name = "Unsolicited Processing Thread";
                processingThread.IsBackground = true;
                processingThread.Priority = ThreadPriority.BelowNormal;
                processingThread.Start();

                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Main processing thread method.
        /// </summary>
        private void processingThreadMethod()
        {
            try
            {
                var cellularVerify = new CellularModemVerification(serialConn);
                cellularVerify.Begin();

                if (cellularVerify.IsSimDetectionSupported() == true)
                {
                    if (cellularVerify.EnableSimDetection() == false)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                        {
                            return string.Format("SIM detection not enabled!");
                        });
                    }
                }

                if (cellularVerify.EnableExtendedErrorReporting() == false)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                    {
                        return string.Format("CME and CMS errors are not enabled!");
                    });
                }

                CellularSmsProvider sms = new CellularSmsProvider(serialConn);
                if (sms.EnableSmsUnsolicitedCodes() == false)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                    {
                        return string.Format("Unable to enable SMS delivery notifications!");
                    });
                }
                // SMS delivery in text mode and default storage
                if (sms.SetTextMode() == false || sms.SetDefaultMessageStorage() == false)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                    {
                        return string.Format("Unable to set SMS default values!");
                    });
                }
                
                int errorCode = -1;
                CellularMessageMemoryType smsMemory = CellularMessageMemoryType.Unknown;
                int smsIndex = -1;
                while (Application.Closing == false && disposed == false && disposing == false)
                {
                    if (serialConn.WaitIndefinitely() && serialConn.Available == true)
                    {
                        if (Application.Closing == true || disposed == true || disposing == true)
                            break;

                        string[] lines = serialConn.ReadLines();

                        // Start noting what message this could be.
                        CellularUnsolicitedCodeBase message = null;
                        if (CellularModemVerification.IsSimCardRemoved(lines) == true)
                        {
                            message = new UnsolicitedCodeSimRemoved();
                            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                            {
                                return "SIM card removed.";
                            });
                        }
                        else if (CellularModemVerification.IsSimCardInserted(lines) == true)
                        {
                            message = new UnsolicitedCodeSimInserted();
                            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                            {
                                return "SIM card inserted.";
                            });
                        }
                        else if (CellularModemVerification.IsDeviceSpecificError(lines, out errorCode) == true)
                        {
                            message = new UnsolicitedCodeDeviceSpecificError(errorCode);
                            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                            {
                                return string.Format("Device specific error {0}.", errorCode);
                            });
                        }
                        else if (CellularModemVerification.IsNetworkSpecificError(lines, out errorCode) == true)
                        {
                            message = new UnsolicitedCodeNetworkSpecificError(errorCode);
                            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                            {
                                return string.Format("Network specific error {0}.", errorCode);
                            });
                        }
                        else if (CellularSmsProvider.IsSmsDeliveryCode(lines, out smsMemory, out smsIndex) == true)
                        {
                            message = new UnsolicitedCodeSmsReceived(smsMemory, smsIndex);
                            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                            {
                                return string.Format("SMS delivery for #{0}.", smsIndex);
                            });
                        }
#if DEBUG
                        // We do not wnat to disply this message in production
                        else
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                            {
                                return string.Format("Unsolicited code: {0}", lines[0]);
                            });
                        }
#endif
                        if (message != null)
                        {
                            // Push the messsage to the parent for processing
                            connectionItem.TriggerReceivedUnsolicitedCode(message);
                        }
                    }
                    else
                    {
                        Thread.Sleep(50);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                {
                    return string.Format("Error while processing unsolicited codes. {0}", ex.Message);
                });
            }
        }

        #region IDisposable Members

        bool disposed = false;
        bool disposing = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                if (disposing)
                {
                    this.disposing = true;
                
                    try
                    {
                        this.connectionItem = null;
                        if (serialConn != null)
                            serialConn.Dispose();
                        processingThread.JoinOrRestart(10000);
                    }
                    catch
                    {
                    }
                }

                // Free any unmanaged objects here.                        
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
