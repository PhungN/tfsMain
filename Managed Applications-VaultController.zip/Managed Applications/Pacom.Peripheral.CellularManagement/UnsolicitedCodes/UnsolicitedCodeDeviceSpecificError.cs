﻿using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Unsolicited message received with CME code
    /// </summary>
    public class UnsolicitedCodeDeviceSpecificError : CellularUnsolicitedCodeBase
    {
        public UnsolicitedCodeDeviceSpecificError(int errorCode)
            : base()
        {
            this.ErrorCode = errorCode;
            string message;
            this.IsCritical = getMappingCriticalFlag(errorCode, out message);
            this.Message = message;
        }

        public override CellularUnsolicitedCodes UnsolicitedCode
        {
            get { return CellularUnsolicitedCodes.DeviceSpecificError; }
        }

        public int ErrorCode
        {
            private set;
            get;   
        }

        public string Message
        {
            private set;
            get;
        }

        /// <summary>
        /// Decide if the CME error is critical and require to have the modem possibly restarted
        /// </summary>
        public bool IsCritical
        {
            get;
            private set;
        }

#region CME Error Definitions

        internal class DeviceSpecificErrorItem
        {
            internal DeviceSpecificErrorItem(int code, string message, bool isCritical)
            {
                this.Code = code;
                this.Message = message;
                this.IsCritical = isCritical;
            }

            internal int Code { get; private set; }
            internal string Message { get; private set; }
            internal bool IsCritical { get; private set; }
        }

        internal static DeviceSpecificErrorItem[] errors = new DeviceSpecificErrorItem[]
        {
            new DeviceSpecificErrorItem(0, "Phone failure", true),
            new DeviceSpecificErrorItem(1, "No connection to phone", true),
            new DeviceSpecificErrorItem(2, "Phone-adapter link reserved", false),
            new DeviceSpecificErrorItem(3, "Operation not allowed", false),
            new DeviceSpecificErrorItem(4, "Operation not supported", false),
            new DeviceSpecificErrorItem(5, "PH-SIM PIN required", false),
            new DeviceSpecificErrorItem(6, "PH-FSIM PIN required", false),
            new DeviceSpecificErrorItem(7, "PH-FSIM PUK required", false),
            new DeviceSpecificErrorItem(10, "SIM not inserted", true),
            new DeviceSpecificErrorItem(11, "SIM PIN required", true),
            new DeviceSpecificErrorItem(12, "SIM PUK required", true),
            new DeviceSpecificErrorItem(13, "SIM failure", true),
            new DeviceSpecificErrorItem(14, "SIM busy", false),
            new DeviceSpecificErrorItem(15, "SIM wrong", true),
            new DeviceSpecificErrorItem(16, "Incorrect password", false),
            new DeviceSpecificErrorItem(17, "SIM PIN2 required", true),
            new DeviceSpecificErrorItem(18, "SIM PUK2 required", true),
            new DeviceSpecificErrorItem(20, "Memory full", false),
            new DeviceSpecificErrorItem(21, "Invalid index", false),
            new DeviceSpecificErrorItem(22, "Not found", false),
            new DeviceSpecificErrorItem(23, "Memory failure", false),
            new DeviceSpecificErrorItem(24, "Text string too long", false),
            new DeviceSpecificErrorItem(25, "Invalid characters in text string", false),
            new DeviceSpecificErrorItem(26, "Dial string too long", false),
            new DeviceSpecificErrorItem(27, "Invalid characters in dial string", false),
            new DeviceSpecificErrorItem(30, "No network service", true),
            new DeviceSpecificErrorItem(31, "Network timeout", true),
            new DeviceSpecificErrorItem(32, "Network not allowed - emergency call only", true),
            new DeviceSpecificErrorItem(40, "Network personalization PIN required", true),
            new DeviceSpecificErrorItem(41, "Network personalization PUK required", true),
            new DeviceSpecificErrorItem(42, "Network subset personalization PIN required", true),
            new DeviceSpecificErrorItem(43, "Network subset personalization PUK required", true),
            new DeviceSpecificErrorItem(44, "Service provider personalization PIN required", false),
            new DeviceSpecificErrorItem(45, "Service provider personalization PUK required", false),
            new DeviceSpecificErrorItem(46, "Corporate personalization PIN required", false),
            new DeviceSpecificErrorItem(47, "Corporate personalization PUK required", false),
            new DeviceSpecificErrorItem(99, "Resource limitation", true),
            new DeviceSpecificErrorItem(100, "Synchronization error", true),
            new DeviceSpecificErrorItem(133, "Requested service option not subscribed", false),
            new DeviceSpecificErrorItem(134, "Service option temporarily out of order", false),
            new DeviceSpecificErrorItem(148, "Unspecified GPRS error", true),
            new DeviceSpecificErrorItem(149, "PDP authentication failure", false),
            new DeviceSpecificErrorItem(150, "Invalid mobile class", false),
            new DeviceSpecificErrorItem(902, "No more sockets available; the maximum number has been reached", false),
            new DeviceSpecificErrorItem(903, "Memory problem", false),
            new DeviceSpecificErrorItem(904, "DNS error", false),
            new DeviceSpecificErrorItem(905, "TCP disconnection by the server", false),
            new DeviceSpecificErrorItem(906, "TCP/UDP connection error", false),
            new DeviceSpecificErrorItem(907, "Generic error", false),
            new DeviceSpecificErrorItem(908, "Fail to accept client request's", false),
            new DeviceSpecificErrorItem(909, "Data send by KTCPSND/KUDPSND are incoherent", false),
            new DeviceSpecificErrorItem(910, "Bad session ID", false),
            new DeviceSpecificErrorItem(911, "Session is already running", false),
            new DeviceSpecificErrorItem(912, "No more sessions can be used (maximum session is 32 for HL85xxx)", false),
            new DeviceSpecificErrorItem(913, "Socket connection timer timeout", false),
            new DeviceSpecificErrorItem(914, "Control socket connection timer timeout", false),
            new DeviceSpecificErrorItem(915, "A parameter is not expected", false),
            new DeviceSpecificErrorItem(916, "A parameter has an invalid range of values", false),
            new DeviceSpecificErrorItem(917, "A parameter is missing", false),
            new DeviceSpecificErrorItem(918, "Feature is not supported", false),
            new DeviceSpecificErrorItem(919, "Feature is not available", false),
            new DeviceSpecificErrorItem(920, "Protocol is not supported", false),
            new DeviceSpecificErrorItem(921, "Error due to invalid state of bearer connection", false),
            new DeviceSpecificErrorItem(922, "Error due to invalid state of session", false),
            new DeviceSpecificErrorItem(923, "Error due to invalid state of terminal port data mode", false),
            new DeviceSpecificErrorItem(924, "Error due to session busy, retry later", false),
            new DeviceSpecificErrorItem(925, "Failed to decode HTTP header's name, missing ':'", false),
            new DeviceSpecificErrorItem(926, "Failed to decode HTTP header's value, missing 'cr/lf'", false),
            new DeviceSpecificErrorItem(927, "HTTP header's name is an empty string", false),
            new DeviceSpecificErrorItem(928, "HTTP header's value is an empty string", false),
            new DeviceSpecificErrorItem(929, "Format of input data is invalid", false),
            new DeviceSpecificErrorItem(930, "Content of input data is invalid or not supported", false),
            new DeviceSpecificErrorItem(931, "The length of a parameter is invalid", false),
            new DeviceSpecificErrorItem(932, "The format of a parameter is invalid", false),
        };

        private static bool getMappingCriticalFlag(int errorCode, out string message)
        {
            var errorItem = errors.FirstOrDefault(e => e.Code == errorCode);
            if (errorItem == null)
            {
                message = "Unknown error (-1)";
                return false;
            }
            else
            {
                message = string.Format("{0} {{1}", errorItem.Message, errorCode);
                return errorItem.IsCritical;
            }
        }
#endregion
    }
}
