﻿
namespace Pacom.Peripheral.CellularManagement
{
    public class UnsolicitedCodeSimInserted : CellularUnsolicitedCodeBase
    {
        public override CellularUnsolicitedCodes UnsolicitedCode
        {
            get { return CellularUnsolicitedCodes.SimCardInserted; }
        }
    }
}
