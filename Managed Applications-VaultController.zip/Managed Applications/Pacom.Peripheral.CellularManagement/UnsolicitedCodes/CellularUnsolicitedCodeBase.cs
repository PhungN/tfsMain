﻿
namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Base class for unsolicited code processing.
    /// </summary>
    /// <remarks>Some unsolicited codes may return additional information which could be transfered for processing.</remarks>
    public abstract class CellularUnsolicitedCodeBase
    {
        public abstract CellularUnsolicitedCodes UnsolicitedCode { get; }
    }
}
