﻿using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Unsolicited message received with CMS code
    /// </summary>
    public class UnsolicitedCodeNetworkSpecificError : CellularUnsolicitedCodeBase
    {
        public UnsolicitedCodeNetworkSpecificError(int errorCode)
            : base()
        {
            this.ErrorCode = errorCode;
            string message;
            this.IsCritical = getMappingCriticalFlag(errorCode, out message);
            this.Message = message;
        }

        public override CellularUnsolicitedCodes UnsolicitedCode
        {
            get { return CellularUnsolicitedCodes.NetworkSpecificError; }
        }

        public int ErrorCode
        {
            private set;
            get;   
        }

        public string Message
        {
            private set;
            get;   
        }

         /// <summary>
        /// Decide if the CMS error is critical and require to have the modem possibly restarted
        /// </summary>
        public bool IsCritical
        {
            get;
            private set;
        }

#region CMS Error Definitions

        internal class NetworkSpecificErrorItem
        {
            internal NetworkSpecificErrorItem(int code, string message, bool isCritical)
            {
                this.Code = code;
                this.Message = message;
                this.IsCritical = isCritical;
            }

            internal int Code { get; private set; }
            internal string Message { get; private set; }
            internal bool IsCritical { get; private set; }
        }

        internal static NetworkSpecificErrorItem[] errors = new NetworkSpecificErrorItem[]
        {
            new NetworkSpecificErrorItem(1, "Unassigned (unallocated) number", false),
            new NetworkSpecificErrorItem(8, "Operator determined barring", false),
            new NetworkSpecificErrorItem(10, "Call barred", false),
            new NetworkSpecificErrorItem(21, "Short message transfer rejected", false),
            new NetworkSpecificErrorItem(27, "Destination out of service", false),
            new NetworkSpecificErrorItem(28, "Unidentified subscriber", false),
            new NetworkSpecificErrorItem(29, "Facility rejected", false),
            new NetworkSpecificErrorItem(30, "Unknown subscriber", false),
            new NetworkSpecificErrorItem(38, "Network out of order", true),
            new NetworkSpecificErrorItem(41, "Temporary failure", true),
            new NetworkSpecificErrorItem(42, "Congestion", true),
            new NetworkSpecificErrorItem(47, "Resources unavailable, unspecified", false),
            new NetworkSpecificErrorItem(50, "Requested facility not subscribed", false),
            new NetworkSpecificErrorItem(69, "Requested facility not implemented", false),
            new NetworkSpecificErrorItem(81, "Invalid short message transfer reference value", false),
            new NetworkSpecificErrorItem(95, "Invalid message, unspecified", false),
            new NetworkSpecificErrorItem(96, "Invalid mandatory information", false),
            new NetworkSpecificErrorItem(97, "Message type non-existent or not implemented", false),
            new NetworkSpecificErrorItem(98, "Message not compatible with short message protocol state", false),
            new NetworkSpecificErrorItem(99, "Information element non-existent or not implemented", false),
            new NetworkSpecificErrorItem(111, "Protocol error, unspecified", false),
            new NetworkSpecificErrorItem(127, "Interworking, unspecified", false),
            new NetworkSpecificErrorItem(128, "Telematic interworking not supported", false),
            new NetworkSpecificErrorItem(129, "Short message Type 0 not supported", false),
            new NetworkSpecificErrorItem(130, "Cannot replace short message", false),
            new NetworkSpecificErrorItem(143, "Unspecified TP-PID error", false),
            new NetworkSpecificErrorItem(144, "Data coding scheme (alphabet) not supported", false),
            new NetworkSpecificErrorItem(145, "Message class not supported", false),
            new NetworkSpecificErrorItem(159, "Unspecified TP-DCS error", false),
            new NetworkSpecificErrorItem(160, "Command cannot be executed", false),
            new NetworkSpecificErrorItem(161, "Command unsupported", false),
            new NetworkSpecificErrorItem(175, "Unspecified TP-Command error", false),
            new NetworkSpecificErrorItem(176, "TPDU not supported", false),
            new NetworkSpecificErrorItem(192, "SC busy", false),
            new NetworkSpecificErrorItem(193, "No SC subscription", false),
            new NetworkSpecificErrorItem(194, "SC system failure", false),
            new NetworkSpecificErrorItem(195, "Invalid SME address", false),
            new NetworkSpecificErrorItem(196, "Destination SME barred", false),
            new NetworkSpecificErrorItem(197, "SM Rejected-Duplicate SM", false),
            new NetworkSpecificErrorItem(198, "TP-VPF not supported", false),
            new NetworkSpecificErrorItem(199, "TP-VP not supported ", false),
            new NetworkSpecificErrorItem(208, "D0 SIM SMS storage full", false),
            new NetworkSpecificErrorItem(209, "No SMS storage capability in SIM", false),
            new NetworkSpecificErrorItem(210, "Error in MS", false),
            new NetworkSpecificErrorItem(211, "Memory Capacity Exceeded", false),
            new NetworkSpecificErrorItem(212, "SIM Application Toolkit Busy", false),
            new NetworkSpecificErrorItem(213, "SIM data download error", false),
            new NetworkSpecificErrorItem(255, "Unspecified error cause", false),
            new NetworkSpecificErrorItem(300, "ME failure", false),
            new NetworkSpecificErrorItem(301, "SMS service of ME reserved", false),
            new NetworkSpecificErrorItem(302, "Operation not allowed", false),
            new NetworkSpecificErrorItem(303, "Operation not supported", false),
            new NetworkSpecificErrorItem(304, "Invalid PDU mode parameter", false),
            new NetworkSpecificErrorItem(305, "Invalid text mode parameter", false),
            new NetworkSpecificErrorItem(310, "SIM not inserted", true),
            new NetworkSpecificErrorItem(311, "SIM PIN required", true),
            new NetworkSpecificErrorItem(312, "PH-SIM PIN required", false),
            new NetworkSpecificErrorItem(313, "SIM failure", true),
            new NetworkSpecificErrorItem(314, "SIM busy", false),
            new NetworkSpecificErrorItem(315, "SIM wrong", false),
            new NetworkSpecificErrorItem(316, "SIM PUK required", false),
            new NetworkSpecificErrorItem(317, "SIM PIN2 required", false),
            new NetworkSpecificErrorItem(318, "SIM PUK2 required", false),
            new NetworkSpecificErrorItem(320, "Memory failure", false),
            new NetworkSpecificErrorItem(321, "Invalid memory index", false),
            new NetworkSpecificErrorItem(322, "Memory full", false),
            new NetworkSpecificErrorItem(330, "SMSC address unknown", false),
            new NetworkSpecificErrorItem(331, "No network service", false),
            new NetworkSpecificErrorItem(332, "Network timeout", true),
            new NetworkSpecificErrorItem(340, "NO +CNMA ACK EXPECTED", false),
            new NetworkSpecificErrorItem(500, "Unknown error", false),
        };

        private static bool getMappingCriticalFlag(int errorCode, out string message)
        {
            var errorItem = errors.FirstOrDefault(e => e.Code == errorCode);
            if (errorItem == null)
            {
                message = "Unknown error (-1)";
                return false;
            }
            else
            {
                message = string.Format("{0} {{1}", errorItem.Message, errorCode);
                return errorItem.IsCritical;
            }
        }
#endregion
    }   
}
