﻿
namespace Pacom.Peripheral.CellularManagement
{
    public class UnsolicitedCodeSimRemoved : CellularUnsolicitedCodeBase
    {
        public override CellularUnsolicitedCodes UnsolicitedCode
        {
            get { return CellularUnsolicitedCodes.SimCardRemoved; }
        }
    }
}
