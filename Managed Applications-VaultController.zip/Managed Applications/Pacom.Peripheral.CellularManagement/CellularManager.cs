﻿using System;
using System.Collections.Generic;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.ExpansionCards;
using Pacom.Peripheral.Hal;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Cellular infrastructure manager.
    /// </summary>
    public class CellularManager : ICellularManager, IDisposable
    {
        /// <summary>
        /// Only one instance of the Cellular Manager will be created
        /// </summary>
        private static ICellularManager instance = null;
        public static ICellularManager CreateInstance()
        {
            if (instance == null)
                instance = new CellularManager();
            return instance;
        }

        public static ICellularManager Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                    {
                        return "Instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
#endif
                return instance;
            }
        }

        /// <summary>
        /// Constructor for CellularManager.
        /// </summary>
        public CellularManager()
        {
            prepareNewConfiguration();
            ConfigurationManager.Instance.ConfigurationChanged += new EventHandler<ConfigurationChangeEventArgs>(configurationManager_ConfigurationChanged);
        }

        #region Manager external events

        /// <summary>
        /// Triggered when the connection is started. Just after connection to the provider IP network.
        /// </summary>
        public event EventHandler<EventArgs> CellularConnectionEstablished;

        /// <summary>
        /// Triggered when the connection is ended.
        /// </summary>
        public event EventHandler<EventArgs> CellularConnectionHangup;

        /// <summary>
        /// Trigger manager external event when connection is established.
        /// </summary>
        internal void TriggerConnectionEstablished()
        {
            if (this.CellularConnectionEstablished != null)
            {
                try
                {
                    this.CellularConnectionEstablished(this, new EventArgs());
                }
                catch
                {
                }
            }
        }

        /// <summary>
        /// Trigger manager external event when connection is hangup.
        /// </summary>
        internal void TriggerConnectionHangup()
        {
            if (this.CellularConnectionHangup != null)
            {
                try
                {
                    this.CellularConnectionHangup(this, new EventArgs());
                }
                catch
                {
                }
            }
        }

        #endregion

        #region GSM multiplexer handling

        /// <summary>
        /// The GSM multiplexer appear as one of COM ports in the system. The multiplexer will be handled from the manager.
        /// </summary>
        private PhysicalSerialPort muxPort = PhysicalSerialPort.None;

        /// <summary>
        /// Set the MUX driver to access the cellular card
        /// </summary>
        public PhysicalSerialPort MuxPort
        {
            get { return muxPort; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        internal bool SetMuxPort(PhysicalSerialPort value)
        {
            if (this.muxPort != value)
            {
                this.muxPort = value;
                if (MuxAdapter.Disable() == false)
                    return false;
                if (this.muxPort == PhysicalSerialPort.ExpansionCard1
                    || this.muxPort == PhysicalSerialPort.ExpansionCard2)
                {
                    if (MuxAdapter.Disable() == false)
                        return false;
                    if (MuxAdapter.Update(this.muxPort) == false)
                        return false;
                    if (MuxAdapter.Enable() == false)
                        return false;
                }
            }
            return true;
        }

        #endregion

        #region System configuration for cellular connection

        /// <summary>
        /// Keeps connection information and status
        /// </summary>
        private CellularConnectionItem newConnectionConfiguration = null;
        private CellularConnectionItem currentConnection = null;

        /// <summary>
        /// Gets True if the cellular module configuration is present.
        /// </summary>
        public bool IsCellularModuleConfigured
        {
            get
            {
                for (int iConnection = 0; iConnection < 2; iConnection++)
                {
                    if (isConfigurationPresent(iConnection) == true)
                        return true;
                }
                return false;
            }
        }

        private void configurationManager_ConfigurationChanged(object sender, ConfigurationChangeEventArgs e)
        {
            try
            {
                if (e.AnythingAddedChangedOrRemoved == false)
                    return;

                bool changeRequired = false;
                int controllerId = ConfigurationManager.Instance.ControllerConfiguration.Id;
                foreach (ConfigurationChanges newlyAddedItem in e.NewlyAddedItems)
                {
                    if (newlyAddedItem.ConfigurationType == ConfigurationElementType.ExpansionCard && newlyAddedItem.ParentDeviceId == controllerId)
                    {
                        changeRequired = true;
                        break;
                    }
                    else if (newlyAddedItem.ConfigurationType == ConfigurationElementType.Port && newlyAddedItem.ParentDeviceId == controllerId)
                    {
                        changeRequired = true;
                        break;
                    }
                }
                if (changeRequired == false)
                {
                    foreach (ConfigurationChanges changedItem in e.ChangedItems)
                    {
                        if (changedItem.ConfigurationType == ConfigurationElementType.ExpansionCard && changedItem.ParentDeviceId == controllerId)
                        {
                            changeRequired = true;
                            break;
                        }
                        else if (changedItem.ConfigurationType == ConfigurationElementType.Port && changedItem.ParentDeviceId == controllerId)
                        {
                            changeRequired = true;
                            break;
                        }
                    }
                }
                if (changeRequired == false)
                {
                    foreach (ConfigurationChanges removedItem in e.RemovedItems)
                    {
                        if (removedItem.ConfigurationType == ConfigurationElementType.ExpansionCard && removedItem.ParentDeviceId == controllerId)
                        {
                            changeRequired = true;
                            break;
                        }
                        else if (removedItem.ConfigurationType == ConfigurationElementType.Port && removedItem.ParentDeviceId == controllerId)
                        {
                            changeRequired = true;
                            break;
                        }
                    }
                }

                if (changeRequired)
                    prepareNewConfiguration();
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                {
                    return string.Format("Error while applying configuration change in CellularManager : {0}", ex.ToString());
                });
            }
        }

        /// <summary>
        /// Prepare new configuration. The configuration manager must be locked for access before caling this procedure.
        /// </summary>
        /// <returns>Returns true if a new configuration is ready for use.</returns>
        private bool prepareNewConfiguration()
        {
            newConnectionConfiguration = null;
            for (int iConnection = 0; iConnection < 2; iConnection++)
            {
                try
                {
                    if (isConfigurationPresent(iConnection) == true)
                    {
                        Pacom8003Configuration controllerConfig = ConfigurationManager.Instance.ControllerConfiguration;
                        // Collect objects for configuration.The following references should be ready for use - hard cast them.
                        var cellularCard = (IPacomGprsCard)ExpansionCardManager.Instance.GetExpansionCard(iConnection);
                        var port = (Port8003GprsPortConfiguration)controllerConfig.ExpansionSlotPorts[iConnection];
                        int cellularCardLogicalId = controllerConfig.ExpansionCards[iConnection].Id;
                        if (cellularCard != null && port != null && cellularCardLogicalId > 0)
                        {
                            // Assign configuration which will mark it as ready for operation in the update.
                            newConnectionConfiguration = new CellularConnectionItem(cellularCard.PortId, cellularCard, cellularCardLogicalId);
                            newConnectionConfiguration.CopyFrom(port, cellularCard);
                            break;
                        }
                    }
                    else if (ExpansionCardManager.Instance.GetExpansionCardType(iConnection).IsCellular())
                    {
                        // Blank the status LED on cards without configuration. The expansion card is needed only.
                        // According to hardware manual LED5 is OFF when there is Auto-configuration Incomplete (port may not be configured).
                        var cellularCard = (IPacomGprsCard)ExpansionCardManager.Instance.GetExpansionCard(iConnection);
                        if (cellularCard != null)
                            cellularCard.StatusLed = PacomCellularCardStatusLed.PortNotConfigured;
                    }
                }
                catch
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                    {
                        return string.Format("Error while inspecting configuration for {0}.",
                            (iConnection == 0 ? PhysicalSerialPort.ExpansionCard1 : PhysicalSerialPort.ExpansionCard2).ToString());
                    });
                    newConnectionConfiguration = null;
                }
            }
            recreatePort();
            // Check if new configuration is ready for use.
            return newConnectionConfiguration != null;
        }

        private bool isConfigurationPresent(int iConnection)
        {
            Pacom8003Configuration controllerConfig = ConfigurationManager.Instance.ControllerConfiguration;
            if (controllerConfig != null
                && ExpansionCardManager.Instance.GetExpansionCardType(iConnection).IsCellular()
                && controllerConfig.ExpansionCards[iConnection] != null
                && controllerConfig.ExpansionCards[iConnection].Enabled == true
                && controllerConfig.ExpansionCards[iConnection].CardType.IsCellular()
                && controllerConfig.ExpansionSlotPorts[iConnection] != null
                && controllerConfig.ExpansionSlotPorts[iConnection].Enabled == true
                && controllerConfig.ExpansionSlotPorts[iConnection] is Port8003GprsPortConfiguration)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Request the manager to reload.
        /// </summary>
        /// <returns>Returnes true if the configuration was avaliable and reload will happen soon.</returns>
        public bool Reload()
        {
            if (currentConnection != null)
                currentConnection.Valid = false;

            return prepareNewConfiguration();
        }

        /// <summary>
        /// Recreates connection required by the current controller configuration.
        /// </summary>
        private void recreatePort()
        {
            if (disposing == true)
                return;
            try
            {
                // Check if connection termination is required
                if (currentConnection != null)
                {
                    if (newConnectionConfiguration == null
                        || currentConnection.Valid == false
                        || currentConnection.IsSameConnection(newConnectionConfiguration) == false)
                    {
                        stopThread(false);
                        // The thread will assign null to currentConnection when it is finished.
                    }
                }
                // Establish new connection
                if (currentConnection == null && newConnectionConfiguration != null)
                {
                    // Reassign the connection
                    currentConnection = newConnectionConfiguration;
                    newConnectionConfiguration = null;
                    currentConnection.SetParent(this);
                    startThread();
                }
                // Display summary about the active connection
                if (currentConnection != null)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                    {
                        return string.Format("Cellular manager is waiting on the following port: {0}", currentConnection.Port.ToString());
                    });
                }
                else
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                    {
                        return "Cellular manager is not handling any connection.";
                    });
                }
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                {
                    return string.Format("Cellular manager has encountered error while reconfiguring port. {0}", ex.ToString());
                });
            }
        }

        #endregion

        #region SMS related functions

        /// <summary>
        /// List to hold SMS objects to be delivered
        /// </summary>
        private Queue<CellularShortMessageItem> smsListToDeliver = new Queue<CellularShortMessageItem>();

        /// <summary>
        /// Maximum number of SMS items to be held
        /// </summary>
        internal const int MaxItemSmsListToDeliver = 50;

        /// <summary>
        /// Lock on the deliver list as adding and removing may happen at the same time.
        /// </summary>
        private readonly object smsListToDeliverLock = new object();

        /// <summary>
        /// Enqueue messages if established limit is not reached.
        /// </summary>
        /// <param name="phoneNumber">Recipient phone number</param>
        /// <param name="message">SMS message body</param>
        /// <returns>True, if the message was correctly enqueued</returns>
        internal bool EnqueueSms(string phoneNumber, string message)
        {
            try
            {
                // Check if module is configured
                if (this.IsCellularModuleConfigured == false)
                    return false;
                // Check if we can process the message
                if (smsListToDeliver.Count > MaxItemSmsListToDeliver || currentConnection == null)
                    return false;
                // Enqueue
                lock (smsListToDeliverLock)
                {
                    smsListToDeliver.Enqueue(new CellularShortMessageItem(phoneNumber, message));
                }
                // Start the sending task
                if (currentConnection != null)
                    currentConnection.WakeUpTask(typeof(CellularCheckSmsSending));
                return true;
            }
            catch
            {
                // Most possibly the currentConnection is not set.
                // The check for SMSs will be done next time the connection is created. It starts within one second.
                return false;
            }
        }

        /// <summary>
        /// Retrieve one short text message item from the sending list.
        /// </summary>
        /// <param name="lastMessage">If True this was the last message.</param>
        /// <param name="smsItem">SMS item</param>
        /// <returns>Return true if the item was present.</returns>
        internal bool GetSmsItem(out bool lastMessage, out CellularShortMessageItem smsItem)
        {
            if (smsListToDeliver.Count == 0)
            {
                lastMessage = true;
                smsItem = null;
                return false;
            }
            lock (smsListToDeliverLock)
            {
                smsItem = smsListToDeliver.Dequeue();
                lastMessage = smsListToDeliver.Count == 0;
                return true;
            }
        }

        #endregion

        #region Cellular connection main thread and its functions

        /// <summary>
        /// For secret statistics count the number of reconnection.
        /// </summary>
        private int numberOfReconnection = 0;

        /// <summary>
        /// Number of reconnection since the port configuration has been changed.
        /// </summary>
        public int NumberOfReconnection
        {
            get { return this.numberOfReconnection; }
        }

        private Thread processingThread = null;

        /// <summary>
        /// Event required for delay of starting connections. It will allow the RAS system to settle.
        /// </summary>
        private AutoResetEvent waitInProcessingThread = new AutoResetEvent(false);

        /// <summary>
        /// Start connection processing thread.
        /// </summary>
        private void startThread()
        {
            if (processingThread != null)
                return;
            processingThread = new Thread(new ThreadStart(processingThreadMethod));
            processingThread.Name = "Cellular Processing Thread";
            processingThread.IsBackground = true;
            processingThread.Priority = ThreadPriority.BelowNormal;
            processingThread.Start();
        }

        /// <summary>
        /// Stop connection and terminate thread.
        /// </summary>
        /// <param name="final">True if the call is for final shutdown of the manager.</param>
        private void stopThread(bool final)
        {
            if (currentConnection != null)
            {
                try
                {
                    currentConnection.Terminate();
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                    {
                        return string.Format("Error while terminating connection. {0}", ex.Message);
                    });
                }
            }
            waitInProcessingThread.Set();
            if (processingThread != null)
            {
                try
                {
                    if (final)
                    {
                        processingThread.JoinOrRestart(20 * 1000);
                    }
                    else
                    {
                        processingThread.JoinOrRestart(120 * 1000);
                    }
                }
                catch
                {
                }
                processingThread = null;
            }
            // The processing thread has stopped. The count will start again when new configuration has been found for a port.
            numberOfReconnection = 0;
            Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
            {
                return "Cellular connection is terminated.";
            });
        }

        /// <summary>
        /// Main processing thread method.
        /// </summary>
        private void processingThreadMethod()
        {
            try
            {
                while (Application.Closing == false && disposing == false)
                {
                    // Wait here for next try of establishing the connection
                    if (Application.Closing == true || disposing == true)
                        break;
                    waitInProcessingThread.WaitOne(5000, false);
                    if (Application.Closing == true || disposing == true)
                        break;
                    // Start connection
                    try
                    {
                        // Mark the card as not handled
                        currentConnection.ExpansionCard.StatusLed = PacomCellularCardStatusLed.PortNotConfigured;
                        // Start configuring monitoring ports
                        if (this.SetMuxPort(PhysicalSerialPort.None) == false)
                            continue;
                        Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, () =>
                        {
                            return string.Format("Resetting modem attached to {0} [{1}].", currentConnection.Port.ToString(), numberOfReconnection);
                        });
                        currentConnection.ExpansionCard.Reset(waitInProcessingThread);
                        if (this.SetMuxPort(currentConnection.ExpansionCard.PortId) == false)
                            continue;
                        // Start connection and block until terminated
                        if (Application.Closing == true || disposing == true)
                            break;
                        currentConnection.BeginConnection();
                        if (currentConnection.IsTerminating == true)
                            break;
                        // Make note that the reconnection has occurred
                        numberOfReconnection++;
                    }
                    catch (Exception ex)
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                        {
                            return string.Format("Error while maintaining cellular connection for {0}. {1}", currentConnection.Port.ToString(), ex.Message);
                        });
                    }
                }
            
                // Make note of the expansion card assigned to the connection.
                var card = currentConnection.ExpansionCard;
                var cardStatus = currentConnection.ExpansionCardStatus;
                currentConnection.Dispose();
                currentConnection = null;
                this.SetMuxPort(PhysicalSerialPort.None);
                // Reset the card on final step, but do not block.
                if (card != null)
                    card.Reset(null);
                if (cardStatus != null)
                    cardStatus.NetworkRegistration = GprsNetworkRegistration.NotRegistered;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.GprsConnection, () =>
                {
                    return string.Format("Error during processing cellular connection thread. {0}", ex.Message);
                });
            }
        }

        #endregion

        #region Cellular connection control

        /// <summary>
        /// Check if cellular connection is established on specified physical port.
        /// </summary>
        /// <param name="port">Physical port on which we should query the status</param>
        /// <returns>Returns True when the connection is ready for use. It must be configured, connected, and IP must be assigned.</returns>
        public bool AvailableForUse(PhysicalSerialPort port)
        {
            if (disposing == true || currentConnection == null)
                return false;

            if (currentConnection.Port == port
                && currentConnection.IsConnected == true
                && currentConnection.IPAddressAssigned == true)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Request to send SMS via the cellular mobile provider.
        /// </summary>
        /// <param name="phoneNumber">Recipient phone number</param>
        /// <param name="message">Message body</param>
        /// <remarks>The message will be discarded is the system does not have means to send it. SMS should not be sent during configuration changes.</remarks>
        /// <returns>True if the message was successfully enqueued.</returns>
        public bool SendSms(string phoneNumber, string message)
        {
            if (disposing == true)
                return false;
            return this.EnqueueSms(phoneNumber, message);
        }

        #endregion

        #region IDisposable Members

        bool disposed = false;
        bool disposing = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                if (disposing)
                {
                    this.disposing = true;
                    // Free any other managed objects here.
                    ConfigurationManager.Instance.ConfigurationChanged -= new EventHandler<ConfigurationChangeEventArgs>(configurationManager_ConfigurationChanged);
                    stopThread(true);
                    this.SetMuxPort(PhysicalSerialPort.None);
                    Logger.LogDebugMessage(LoggerClassPrefixes.GprsConnection, DebugLoggingSubCategory.GprsConnections, () =>
                    {
                        return "Cellular manager is disposed.";
                    });
                    instance = null;
                }
                // Free any unmanaged objects here.                        
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
