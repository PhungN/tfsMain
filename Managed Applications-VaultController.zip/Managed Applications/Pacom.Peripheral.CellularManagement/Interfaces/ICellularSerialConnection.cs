﻿
namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Interface to access cellular module serial port.
    /// </summary>
    public interface ICellularSerialConnection
    {
        #region Write functions

        bool LineWriteLine(string data);
        bool LineWriteLine(string data, int responseDelay);
        bool WriteLine(string data);
        bool WriteLine(string data, int responseDelay);
        bool Write(string data);
        bool Write(string data, int responseDelay);
        bool Write(char data);
        bool WriteChar(char data);

        #endregion

        #region Wait functions

        /// <summary>
        /// Indicates that there is some data available for processing.
        /// </summary>
        bool Available { get; }

        /// <summary>
        /// Wait remaining time for the response. The response time is setup while writing.
        /// </summary>
        /// <returns>Return False if the waiting time expired.</returns>
        bool Wait();

        /// <summary>
        /// Wait indefinitely for data.
        /// </summary>
        /// <returns></returns>
        bool WaitIndefinitely();

        /// <summary>
        /// Request the instance to terminate
        /// </summary>
        void Terminate();

        #endregion

        #region Read functions

        string[] ReadLines();
        bool ReadExact(string expectedResponse);
        bool ReadPartOf(string expectedResponse);

        #endregion
    }
}
