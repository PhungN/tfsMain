﻿using Pacom.Peripheral.Common.Utilities;
using System.Collections.Generic;

namespace Pacom.Peripheral.CellularManagement
{
    public abstract class CellularCommandResponseBase
    {
        /// <summary>
        /// Checks if last response is valid and if the last like is OK.
        /// </summary>
        /// <param name="lines">All received lines</param>
        /// <param name="expectedLines">Expected number of lines</param>
        /// <returns></returns>
        static public bool IsResponseOk(string[] lines, int expectedLines)
        {
            if (lines == null || lines.Length != expectedLines)
                return false;

            foreach (string line in lines)
            {
                if (line == null)
                    return false;
            }

            if (lines.Length > 0 && lines[lines.Length - 1] == "OK")
                return true;

            return false;
        }

        /// <summary>
        /// Check response value.
        /// </summary>
        /// <param name="line"></param>
        /// <param name="startingWith"></param>
        /// <param name="expectedValue"></param>
        /// <returns></returns>
        static public bool IsResponseValuePresent(string line, string startingWith, string expectedValue)
        {
            if (line == null || (line.Length > 0 && expectedValue == null))
                return false;

            if (startingWith == null || line.StartsWith(startingWith) == false)
                return false;

            string restOfLine = line.Substring(startingWith.Length);
            // Must be at least " :"
            if (restOfLine == null
                || restOfLine.Length <= 2
                || (restOfLine.StartsWith(": ") == false && expectedValue != null && expectedValue.Length > 0))
            {
                return false;
            }

            if (string.Compare(restOfLine.Substring(2), expectedValue) != 0)
                return false;

            return true;
        }

        /// <summary>
        /// Get response value as integer.
        /// </summary>
        /// <param name="line"></param>
        /// <param name="startingWith"></param>
        /// <param name="parsedValue">Value extracted and cast as integer.</param>
        /// <returns>Returns True if the value has been found.</returns>
        static public bool GetResponseValue(string line, string startingWith, out int parsedValue)
        {
            parsedValue = 0;

            if (line == null || startingWith == null || line.StartsWith(startingWith) == false)
                return false;

            string restOfLine = line.Substring(startingWith.Length);
            // Must be at least " :"
            if (restOfLine == null
                || restOfLine.Length <= 2
                || restOfLine.StartsWith(": ") == false)
            {
                return false;
            }

            string value = restOfLine.Substring(2);

            // If there are multiple arguments use the first one.
            if (value.Contains(","))
                value = value.Substring(0, value.IndexOf(','));
            if (CommonUtilities.TryParseInteger(value, out parsedValue) == true)
                return true;
            return false;
        }

        /// <summary>
        /// Get response value as string.
        /// </summary>
        /// <param name="line"></param>
        /// <param name="startingWith"></param>
        /// <param name="parsedValue">Value extracted as string.</param>
        /// <returns></returns>
        static public bool GetResponseValue(string line, string startingWith, out string parsedValue)
        {
            parsedValue = string.Empty;

            if (line == null || startingWith == null || line.StartsWith(startingWith) == false)
                return false;

            string restOfLine = line.Substring(startingWith.Length);
            // Must be at least " :"
            if (restOfLine == null
                || restOfLine.Length <= 2
                || restOfLine.StartsWith(": ") == false)
            {
                return false;
            }

            parsedValue = restOfLine.Substring(2);
            return true;
        }

        /// <summary>
        /// Get response value as string array.
        /// </summary>
        /// <param name="line"></param>
        /// <param name="startingWith"></param>
        /// <param name="parsedValues">Values extracted as array of strings.</param>
        /// <returns></returns>
        static public bool GetResponseValues(string line, string startingWith, out string[] parsedValues)
        {
            parsedValues = null;

            if (line == null || startingWith == null || line.StartsWith(startingWith) == false)
                return false;

            string restOfLine = line.Substring(startingWith.Length);
            // Must be at least " :"
            if (restOfLine == null
                || restOfLine.Length <= 2
                || restOfLine.StartsWith(": ") == false)
            {
                return false;
            }

            string[] values = restOfLine.Substring(2).Split(new char[] { ',' });
            List<string> result = new List<string>();
            foreach (string value in values)
            {
                result.Add(value.Replace("\"", ""));
            }
            parsedValues = result.ToArray();
            return true;
        }
    }
}
