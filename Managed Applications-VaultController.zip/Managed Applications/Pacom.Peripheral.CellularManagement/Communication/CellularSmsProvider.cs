﻿using System;
using System.Text;
using Pacom.Peripheral.Common.Utilities;

namespace Pacom.Peripheral.CellularManagement
{
    public class CellularSmsProvider : CellularCommandResponseBase
    {
        private readonly ICellularSerialConnection serial;

        public CellularSmsProvider(ICellularSerialConnection serial)
        {
            if (serial == null)
                throw new NullReferenceException();
            this.serial = serial;
        }

        /// <summary>
        /// Enable unsolicited codes when new SMSs are received by the mobile adapter.
        /// </summary>
        /// <returns>Returns True when the command was successful.</returns>
        public bool EnableSmsUnsolicitedCodes()
        {
            serial.LineWriteLine("AT+CNMI=2,1,0,1,0", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            return IsResponseOk(data, 1);
        }

        /// <summary>
        /// Set the default SMS memory to SIM.
        /// </summary>
        /// <returns>Returns True if the command is successful.</returns>
        public bool SetDefaultMessageStorage()
        {
            serial.LineWriteLine("AT+CPMS=\"SM\"", 10000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (data.Length == 1)
                return IsResponseOk(data, 1);
            else if (data.Length == 2)
            {
                // Sometimes the following unsolicited code may appear
                // +CPMS: <used1>,<total1>,<used2>,<total2>,<used3>,<total3>                
                string[] parameters;
                if (IsResponseOk(new string[] { data[0] }, 2) == true)
                    return true;
                else if (IsResponseOk(data, 2) == true && GetResponseValues(data[0], "+CPMS", out parameters) == true)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Switch the mobile adapter into text mode for the short text message formatting.
        /// </summary>
        /// <returns>Returns True if the formatting is switched into text mode.</returns>
        public bool SetTextMode()
        {
            serial.LineWriteLine("AT+CMGF=1", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (IsResponseOk(data, 1) == true)
                return true;
            else
                return false;
        }

        /// <summary>
        /// Prepare mobile adapter to receive short text message body.
        /// </summary>
        /// <param name="phoneNumber">Phone number</param>
        /// <returns>Returns True if the preparation of the short text message was successful.</returns>
        public bool BeginSms(string phoneNumber)
        {
            serial.Write(string.Format("\r\nAT+CMGS=\"{0}\"\r", phoneNumber), 4000);
            if (serial.Wait() == false)
                return false;
            if (serial.ReadExact(">") == false)
                return false;
            return true;
        }

        /// <summary>
        /// Write short test message body to the mobile adapter.
        /// </summary>
        /// <param name="message">Short message body. Max size is 160 characters.</param>
        public void WriteSms(string message)
        {
            if (string.IsNullOrEmpty(message))
                return;
            if (message.Length > 160)
                message = message.Substring(0, 160);
            serial.Write(message);
        }

        /// <summary>
        /// End sending short text message
        /// </summary>
        /// <param name="messageReference">Message reference number.</param>
        /// <returns>Returners True if the message was successfully sent.</returns>
        public bool EndSms(out int messageReference)
        {
            messageReference = -1;
            serial.Write("\x1A\r", 5000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (IsResponseOk(data, 2) == true)
            {
                if (GetResponseValue(data[0], "+CMGS", out messageReference) == true)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Delete SMS from memory.
        /// </summary>
        /// <param name="messageReference">Message reference number.</param>
        /// <returns>Returns True if the message has been succesfully deleted.</returns>
        public bool DeleteSms(int messageReference)
        {
            string command = string.Format("AT+CMGD={0},0", messageReference);
            serial.LineWriteLine(command, 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            return IsResponseOk(data, 1);
        }

        public bool ReadSms(int messageReference, out string phoneNumber, out string messageBody)
        {
            phoneNumber = string.Empty;
            messageBody = string.Empty;
            string command = string.Format("AT+CMGR={0}", messageReference);
            serial.LineWriteLine(command, 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            // Special case. The SMS will have at least 3 lines 
            if (data.Length <= 2)
                return false;
            // The last line must be OK
            if (IsResponseOk(data, data.Length) == false)
                return false;
            // Now the last line is OK, The first one must be +CMGR
            string[] messageDetails;
            if (GetResponseValues(data[0], "+CMGR", out messageDetails) == false)
                return false;
            if (messageDetails.Length < 2)
                return false;
            phoneNumber = messageDetails[1];
            // Now extract the message. All the line between first and last.
            StringBuilder sb = new StringBuilder(20);
            for (int i = 1; i < data.Length - 1; i++)
                sb.Append(data[i]);
            messageBody = sb.ToString();
            return true;
        }

        /// <summary>
        /// SMS unsolicited code processing.
        /// </summary>
        /// <param name="lines"></param>
        /// <param name="memory">Memory of the new message</param>
        /// <param name="index">Index in memory.</param>
        /// <returns>Returns True if the SMS unsolicited delivery has been parsed.</returns>
        static public bool IsSmsDeliveryCode(string[] lines, out CellularMessageMemoryType memory, out int index)
        {
            memory = CellularMessageMemoryType.Unknown;
            index = -1;

            string[] values;
            if (GetResponseValues(lines[0], "+CMTI", out values) == false)
                return false;

            if (values == null || values.Length != 2 || string.IsNullOrEmpty(values[0]) || string.IsNullOrEmpty(values[1]))
                return false;
            try
            {
                memory = (CellularMessageMemoryType)Enum.Parse(typeof(CellularMessageMemoryType), values[0], false);
            }
            catch
            {
                return false;
            }

            if (CommonUtilities.TryParseInteger(values[1], out index) == true)
                return true;

            return true;
        }
    }
}
