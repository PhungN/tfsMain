﻿
namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Network carrier details
    /// </summary>
    public class CellularNetworkCarrierItem
    {
        public CellularNetworkCarrierItem(CellularNetworkStatus networkStatus, string longName, string shortName, int numeric, CellularAccessTechnology accessTechnology)
        {
            this.NetworkStatus = networkStatus;
            this.LongName = longName;
            this.ShortName = shortName;
            this.Numeric = numeric;
            this.AccessTechnology = accessTechnology;
        }
        
        public CellularNetworkStatus NetworkStatus
        {
            get;
            private set;
        }

        public string LongName
        {
            get;
            private set;
        }

        public string ShortName
        {
            get;
            private set;
        }

        public int Numeric
        {
            get;
            private set;
        }

        public CellularAccessTechnology AccessTechnology
        {
            get;
            private set;
        }
    }
}
