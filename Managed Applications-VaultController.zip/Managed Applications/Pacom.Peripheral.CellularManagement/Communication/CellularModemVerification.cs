﻿using System;

namespace Pacom.Peripheral.CellularManagement
{
    public class CellularModemVerification : CellularCommandResponseBase
    {
        private readonly ICellularSerialConnection serial;

        public CellularModemVerification(ICellularSerialConnection serial)
        {
            if (serial == null)
                throw new NullReferenceException();
            this.serial = serial;
        }

        public bool Begin()
        {
            int tryCount = 20;
            while (tryCount > 0)
            {
                serial.LineWriteLine("AT", 1000);
                serial.Wait();
                if (serial.ReadPartOf("OK") == false)
                {
                    tryCount--;
                    continue;
                }
                serial.LineWriteLine("ATE0", 1000);
                serial.Wait();
                if (serial.ReadPartOf("OK") == false)
                {
                    tryCount--;
                    continue;
                }
                return true;
            }
            return false;
        }

        public bool GetSerialNumber(out string serialNumber)
        {
            serialNumber = string.Empty;
            serial.LineWriteLine("AT+GSN", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (IsResponseOk(data, 2) == false)
                return false;
            serialNumber = data[0];
            return true;
        }

        public bool GetRevision(out string revision)
        {
            revision = string.Empty;
            serial.LineWriteLine("AT+GMR", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (IsResponseOk(data, 2) == false)
                return false;
            revision = data[0];
            return true;
        }

        public bool GetModel(out string model)
        {
            model = string.Empty;
            serial.LineWriteLine("AT+GMM", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (IsResponseOk(data, 2) == false)
                return false;
            model = data[0];
            return true;
        }

        public bool GetManufacturer(out string manufacturer)
        {
            manufacturer = string.Empty;
            serial.LineWriteLine("AT+GMI", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (IsResponseOk(data, 2) == false)
                return false;
            manufacturer = data[0];
            return true;
        }

        public bool IsSmsSupported()
        {
            serial.LineWriteLine("AT+CSMS?", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (IsResponseOk(data, 2) == true)
            {
                // Should verify the first line here
                return true;
            }
            else
                return false;
        }

        public bool IsSimDetectionSupported()
        {
            serial.LineWriteLine("AT+KSIMDET?", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (IsResponseOk(data, 2) == true)
            {
                return IsResponseValuePresent(data[0], "+KSIMDET", "1");
            }
            return false;
        }

        public bool EnableSimDetection()
        {
            serial.LineWriteLine("AT+KSIMDET=1", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            return IsResponseOk(data, 1);
        }

        public bool DisableSimDetection()
        {
            serial.LineWriteLine("AT+KSIMDET=0", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            return IsResponseOk(data, 1);
        }

        static public bool IsSimCardRemoved(string[] lines)
        {
            return IsResponseValuePresent(lines[0], "+SIM", "0");
        }

        static public bool IsSimCardInserted(string[] lines)
        {
            return IsResponseValuePresent(lines[0], "+SIM", "1");
        }

        public bool EnableExtendedErrorReporting()
        {
            serial.LineWriteLine("AT+CMEE=1", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            return IsResponseOk(data, 1);
        }

        public bool DisableExtendedErrorReporting()
        {
            serial.LineWriteLine("AT+CMEE=0", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            return IsResponseOk(data, 1);
        }

        public bool DisableAutomaticAnswering()
        {
            serial.LineWriteLine("ATS0=0", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            return IsResponseOk(data, 1);
        }

        static public bool IsDeviceSpecificError(string[] lines, out int errorCode)
        {
            return GetResponseValue(lines[0], "+CME ERROR", out errorCode);
        }

        static public bool IsNetworkSpecificError(string[] lines, out int errorCode)
        {
            return GetResponseValue(lines[0], "+CMS ERROR", out errorCode);
        }
    }
}
