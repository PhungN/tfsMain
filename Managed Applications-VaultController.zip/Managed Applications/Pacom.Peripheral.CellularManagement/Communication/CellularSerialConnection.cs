﻿using System;
using System.Text;
using System.Threading;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Protocol;
using System.Collections.Generic;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Serial connection class used to handle monitoring communication with cellular module.
    /// </summary>
    public class CellularSerialConnection : ICellularSerialConnection, IDisposable
    {
        /// <summary>
        /// Timeout required for the connection to be successful.
        /// </summary>
        public const int ConnectionReadyTimeout = 5000;

        /// <summary>
        /// Default timeout required after every write until response is received.
        /// </summary>
        public const int AfterWriteDelay = 2000;

        private Serial232ConnectionWithWaitForEvent connMain;
        private readonly ManualResetEvent connectionReadyEvent = new ManualResetEvent(false);

        private const int cellularMonitoringBaudRate = 115200;

        /// <summary>
        /// Mark this instance as terminated
        /// </summary>
        private bool terminated = false;

        private CellularSerialConnection(PhysicalSerialPort channelPort)
        {
            connMain = new Serial232ConnectionWithWaitForEvent((int)channelPort, cellularMonitoringBaudRate, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);
            connMain.DataReceived += new EventHandler<ReceivedDataEventArgs>(connMain_DataReceived);
            connMain.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(connMain_ConnectionStateChanged);

            responseReadyTimeoutTimer = new Timer(responseReadyTimeoutTimerMethod, null, System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
            connMain.Connect();
            // Wait for the connection to be created
            if (connectionReadyEvent.WaitOne(ConnectionReadyTimeout, false) == false)
            {
                if (connMain.ConnectionState != ConnectionState.Connected)
                    throw new InvalidOperationException(string.Format("Unable to open cellular serial connection. Port: {0}.", channelPort.ToString()));
            }
            flush();
        }

        /// <summary>
        /// Create cellular connection class.
        /// </summary>
        /// <param name="channelPort">Physical port to be used.</param>
        /// <returns></returns>
        public static CellularSerialConnection Create(PhysicalSerialPort channelPort)
        {
            return new CellularSerialConnection(channelPort);
        }

        private readonly ManualResetEvent respnseReadyEvent = new ManualResetEvent(false);
        private StringBuilder responseMultiLine = new StringBuilder(64);
        private readonly object responseLock = new object();
        private readonly Timer responseReadyTimeoutTimer;
        private TimeLimit responseDelayTimeLeft = new TimeLimit();

        /// <summary>
        /// Response notification function.
        /// </summary>
        /// <param name="state">Not used</param>
        private void responseReadyTimeoutTimerMethod(object state)
        {
            if (disposing == true)
                return;
            respnseReadyEvent.Set();
        }

        private void connMain_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (e.NewConnectionState == ConnectionState.Connected)
                connectionReadyEvent.Set();
        }

        private void connMain_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            lock (responseLock)
            {
                responseMultiLine.Append(Encoding.ASCII.GetString(e.Data, 0, e.Data.Length));
                // Notify about the response within the following time.
                responseReadyTimeoutTimer.Change(5, System.Threading.Timeout.Infinite);
            }
        }

        private void flush()
        {
            if (disposing == true)
                return;
            lock (responseLock)
            {
                responseReadyTimeoutTimer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
                respnseReadyEvent.Reset();
                responseMultiLine.Length = 0;
            }
        }

        #region IGprsSerialConnection Members

        public bool LineWriteLine(string data)
        {
            bool result = LineWriteLine(data, AfterWriteDelay);
            responseDelayTimeLeft.ExpectedDuration = AfterWriteDelay;
            responseDelayTimeLeft.Reset();
            return result;
        }

        public bool LineWriteLine(string data, int responseDelay)
        {
            flush();
            bool result = connMain.Send(Encoding.ASCII.GetBytes(string.Format("\r\n{0}\r\n", data)), null);
            responseReadyTimeoutTimer.Change(responseDelay, System.Threading.Timeout.Infinite);
            responseDelayTimeLeft.ExpectedDuration = responseDelay;
            responseDelayTimeLeft.Reset();
            return result;
        }

        public bool WriteLine(string data)
        {
            bool result = WriteLine(data, AfterWriteDelay);
            responseDelayTimeLeft.ExpectedDuration = AfterWriteDelay;
            responseDelayTimeLeft.Reset();
            return result;
        }

        public bool WriteLine(string data, int responseDelay)
        {
            flush();
            bool result = connMain.Send(Encoding.ASCII.GetBytes(string.Format("{0}\r\n", data)), null);
            responseReadyTimeoutTimer.Change(responseDelay, System.Threading.Timeout.Infinite);
            responseDelayTimeLeft.ExpectedDuration = responseDelay;
            responseDelayTimeLeft.Reset();
            return result;
        }

        public bool Write(string data)
        {
            bool result = Write(data, AfterWriteDelay);
            responseDelayTimeLeft.ExpectedDuration = AfterWriteDelay;
            responseDelayTimeLeft.Reset();
            return result;
        }

        public bool Write(string data, int responseDelay)
        {
            flush();
            bool result = connMain.Send(Encoding.ASCII.GetBytes(data), null);
            responseReadyTimeoutTimer.Change(responseDelay, System.Threading.Timeout.Infinite);
            responseDelayTimeLeft.ExpectedDuration = responseDelay;
            responseDelayTimeLeft.Reset();
            return result;
        }

        public bool Write(char data)
        {
            bool result = Write(data, AfterWriteDelay);
            responseDelayTimeLeft.ExpectedDuration = AfterWriteDelay;
            responseDelayTimeLeft.Reset();
            return result;
        }

        public bool Write(char data, int responseDelay)
        {
            flush();
            bool result = connMain.Send(new byte[] { (byte)data }, null);
            responseReadyTimeoutTimer.Change(responseDelay, System.Threading.Timeout.Infinite);
            responseDelayTimeLeft.ExpectedDuration = responseDelay;
            responseDelayTimeLeft.Reset();
            return result;
        }

        public bool WriteChar(char data)
        {
            flush();
            return connMain.Send(new byte[] { (byte)data }, null);
        }

        /// <summary>
        /// Indicates that there is some data available for processing.
        /// </summary>
        public bool Available
        {
            get { return responseMultiLine.Length > 0; }
        }

        /// <summary>
        /// Wait remaining time for the response. The response time is setup while writing.
        /// </summary>
        /// <returns>Return False if the waiting time expired.</returns>
        /// <remarks>The maximum time this function will wait is 240 seconds.</remarks>
        public bool Wait()
        {
            if (terminated)
                return false;
            int timeout = responseDelayTimeLeft.ExpectedDuration - responseDelayTimeLeft.ElapsedTime;
            if (timeout <= 0)
                return true;
            else if (timeout > 240000) // Set the max time as 240 seconds.
                return respnseReadyEvent.WaitOne(AfterWriteDelay, false);
            else
                return respnseReadyEvent.WaitOne(timeout, false);
        }

        /// <summary>
        /// Wait indefinitely for data.
        /// </summary>
        /// <returns></returns>
        public bool WaitIndefinitely()
        {
            if (terminated)
                return false;
            return respnseReadyEvent.WaitOne();
        }

        /// <summary>
        /// Request the instance to terminate
        /// </summary>
        public void Terminate()
        {
            terminated = true;
            respnseReadyEvent.Set();
            connectionReadyEvent.Set();
        }

        public string[] ReadLines()
        {
            lock (responseLock)
            {
                string response = responseMultiLine.ToString();
                flush();
                response = response.Replace("\r", "");
                List<string> result = new List<string>();
                foreach (var s in response.Split(new char[] { '\n' }))
                {
                    if (!string.IsNullOrEmpty(s))
                        result.Add(s.Trim());
                }
                return result.ToArray();
            }
        }

        public bool ReadExact(string expectedResponse)
        {
            lock (responseLock)
            {
                string response = responseMultiLine.ToString();
                flush();
                response = response.Replace("\r\n", "").Trim();
                return string.Compare(response, expectedResponse, false) == 0;
            }
        }

        public bool ReadPartOf(string expectedResponse)
        {
            lock (responseLock)
            {
                string response = responseMultiLine.ToString();
                flush();
                return response.IndexOf(expectedResponse) >= 0;
            }
        }

        #endregion

        private void closePort()
        {
            if (connMain != null)
            {
                connMain.DataReceived -= new EventHandler<ReceivedDataEventArgs>(connMain_DataReceived);
                connMain.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(connMain_ConnectionStateChanged);
                flush();
                connMain.Dispose();
                connMain = null;
            }
        }

        #region IDisposable Members

        private bool disposed = false;

        private bool disposing = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                if (disposing == true)
                {
                    this.disposing = true;
                    terminated = true;
                    responseReadyTimeoutTimer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
                    respnseReadyEvent.Set();
                    connectionReadyEvent.Set();
                    closePort();
                    connectionReadyEvent.Close();
                    respnseReadyEvent.Close();
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
