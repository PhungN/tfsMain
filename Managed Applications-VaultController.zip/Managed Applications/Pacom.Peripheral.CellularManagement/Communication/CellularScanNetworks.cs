﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Utilities;

namespace Pacom.Peripheral.CellularManagement
{
    public class CellularScanNetworks : CellularCommandResponseBase
    {
        private readonly ICellularSerialConnection serial;

        public CellularScanNetworks(ICellularSerialConnection serial)
        {
            if (serial == null)
                throw new NullReferenceException();
            this.serial = serial;
        }

        public bool Begin()
        {
            serial.LineWriteLine("AT", 10000);
            serial.Wait();

            if (serial.ReadPartOf("OK") == false)
                return false;

            serial.LineWriteLine("ATE0");
            serial.Wait();

            if (serial.ReadPartOf("OK") == false)
                return false;
            return true;
        }

        /// <summary>
        /// Enable carrier to be automatically selected.
        /// </summary>
        /// <returns></returns>
        public bool SetCarrierAutomaticSelection()
        {
            serial.LineWriteLine("AT+COPS=0", 10000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            return IsResponseOk(data, 1);
        }

        /// <summary>
        /// Sets carrier manual selection by long name.
        /// </summary>
        /// <param name="carrierName">Carrier long name</param>
        /// <returns>Returns true if the command was successful</returns>
        public bool SetCarrierManualSelection(string carrierName)
        {
            string newSettings = string.Format("AT+COPS={0},{1},\"{2}\"",
                (int)OperatorSelectionMode.Manual, (int)OperatorSelectionFormat.Long, carrierName);
            serial.LineWriteLine(newSettings, 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            return IsResponseOk(data, 1);
        }

        /// <summary>
        /// Sets carrier manual selection by id.
        /// </summary>
        /// <param name="carrierName">Carrier id</param>
        /// <returns>Returns true if the command was successful</returns>
        public bool SetCarrierManualSelection(int carrierId)
        {
            string newSettings = string.Format("AT+COPS={0},{1},\"{2}\"",
                (int)OperatorSelectionMode.Manual, (int)OperatorSelectionFormat.Numeric, carrierId);
            serial.LineWriteLine(newSettings, 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            return IsResponseOk(data, 1);
        }

        /// <summary>
        /// Select the carrier reporting type. Numeric, long or short string.
        /// </summary>
        /// <param name="format">Desired format</param>
        /// <returns>Returns true if the command was successful</returns>
        public bool SetCarrierSelectionReporting(OperatorSelectionFormat format)
        {
            string newSettings = string.Format("AT+COPS={0},{1}", (int)OperatorSelectionMode.SetTheReadFormat, (int)format);
            serial.LineWriteLine(newSettings, 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            return IsResponseOk(data, 1);
        }

        /// <summary>
        /// Get the current carrier and its parameters.
        /// </summary>
        /// <param name="mode"></param>
        /// <param name="format"></param>
        /// <param name="foundOperator"></param>
        /// <param name="foundAct"></param>
        /// <returns>Returns True is the operation was successful.</returns>
        public bool GetCurrentCarrier(out OperatorSelectionMode mode, out OperatorSelectionFormat format, out string foundOperator, out CellularAccessTechnology foundAct)
        {
            mode = OperatorSelectionMode.Automatic;
            format = OperatorSelectionFormat.Long;
            foundOperator = string.Empty;
            foundAct = CellularAccessTechnology.Unknown;
            // Get operator
            serial.LineWriteLine("AT+COPS?", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (IsResponseOk(data, 2) == true)
            {
                if (data[0].StartsWith("+COPS: ") == true)
                {
                    string valueWhole = data[0].Substring(7).Trim();
                    string[] values = valueWhole.Split(new char[] { ',' });
                    if (values.Length >= 3 && values.Length <= 4)
                    {
                        string valueMode = values[0].Trim();
                        string valueFormat = values[1].Trim();
                        string valueOperator = values[2].Trim();
                        // Check the access technology
                        if (values.Length == 4)
                        {
                            string valueAct = values[3].Trim();
                            switch (valueAct)
                            {
                                default:
                                    foundAct = CellularAccessTechnology.Unknown;
                                    break;
                                case "0":
                                case "1":
                                case "3":
                                    foundAct = CellularAccessTechnology.GSM;
                                    break;
                                case "2":
                                case "4":
                                case "5":
                                case "6":
                                    foundAct = CellularAccessTechnology.UMTS;
                                    break;
                                case "7":
                                    foundAct = CellularAccessTechnology.LTE4G;
                                    break;
                                case "8":
                                    foundAct = CellularAccessTechnology.LTECatM1;
                                    break;
                                case "9":
                                    foundAct = CellularAccessTechnology.LTECatNB1;
                                    break;
                            }
                        }

                        // Get the other parameters
                        foundOperator = valueOperator.Replace("\"", "");

                        if (valueMode == "0")
                            mode = OperatorSelectionMode.Automatic;
                        else if (valueMode == "1")
                            mode = OperatorSelectionMode.Manual;
                        else if (valueMode == "3")
                            mode = OperatorSelectionMode.SetTheReadFormat;
                        else if (valueMode == "4")
                            mode = OperatorSelectionMode.ManualToAutomaticSwitchOnFailure;
                        else
                            return false;

                        if (valueMode == "0")
                            format = OperatorSelectionFormat.Long;
                        else if (valueMode == "1")
                            format = OperatorSelectionFormat.Short;
                        else if (valueMode == "2")
                            format = OperatorSelectionFormat.Numeric;
                        else
                            return false;

                        return true;
                    }
                }
                return false;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Get signal strength.
        /// </summary>
        /// <param name="signalStrength">Returns signal strength</param>
        /// <returns>Returns True when the modem query is successful</returns>
        public bool GetSignalStrength(out GprsNetworkSignalStrength signalStrength)
        {
            signalStrength = GprsNetworkSignalStrength.AutoConfigurationIncomplete;
            serial.LineWriteLine("AT+CSQ", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (IsResponseOk(data, 2) == true)
            {
                string[] command = data[0].Split(new char[] { ':' });
                if (command != null && command.Length == 2 && command[0] == "+CSQ")
                {
                    command = command[1].Split(new char[] { ',' });
                    if (command != null && command.Length == 2)
                    {
                        try
                        {
                            // +CSQ: (0-31,99),(0-7,99)
                            //
                            // 0-31,99  indicates the list of supported rssis
                            // 0-7,99    indicates the list of supported bers
                            //  
                            // rssi -  received signal strength indication
                            // ber  - channel bit error rate.
                            //
                            // rssi
                            //    0             -115 dBm or less
                            //    1             -111 dBm
                            //    2...30        -110... -54 dBm
                            //    31            -52 dBm or greater
                            //    99            not known or not detectable

                            // ber
                            //    0...7    as RxQual values. RxQual to ber conversion is given in the following table.
                            //    99       not known or not detectable

                            // Formula: Take the number before the ,99 and multiply it by 2.
                            //          Subtract that figure from -113dBm and that will give you your signal reading in dBm. 

                            int signalStrengthValue = int.Parse(command[0]); // Read the rssi
                            if (signalStrengthValue >= 1 && signalStrengthValue <= 9)
                                signalStrength = GprsNetworkSignalStrength.Poor;
                            else if (signalStrengthValue >= 10 && signalStrengthValue <= 19)
                                signalStrength = GprsNetworkSignalStrength.OK;
                            else if (signalStrengthValue >= 20 && signalStrengthValue <= 98) // The max value should be 31.
                                signalStrength = GprsNetworkSignalStrength.Good;
                            else if (signalStrengthValue == 99)
                                signalStrength = GprsNetworkSignalStrength.NoNetwork;
                            else
                                signalStrength = GprsNetworkSignalStrength.AutoConfigurationIncomplete;
                            return true;
                        }
                        catch
                        {
                            return false;
                        }
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }

        /// <summary>
        /// Read available networks
        /// </summary>
        /// <param name="networks">Return list of available networks and services.</param>
        /// <returns>Returns True if the mobile module has return successfully and the list was created.</returns>
        public bool ReadAvailableNetworks(out CellularNetworkCarrierItem[] networks)
        {
            networks = null;
            // Give the mobile adapter 1 min to query all the networks            
            serial.LineWriteLine("AT+COPS=?", 60000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (IsResponseOk(data, 2) == false)
                return false;
            string networkList;
            if (GetResponseValue(data[0], "+COPS", out networkList) == false)
                return false;
            // Parse
            List<CellularNetworkCarrierItem> result = new List<CellularNetworkCarrierItem>();
            List<string> networkListItems = new List<string>();
            StringBuilder sb = new StringBuilder(20);
            for (int i = 0; i < networkList.Length; i++)
            {
                if (networkList[i] == '(')
                    sb.Append(networkList[i]);
                else if (networkList[i] == ')')
                {
                    sb.Append(networkList[i]);
                    networkListItems.Add(sb.ToString());
                    sb.Length = 0;
                }
                else if (sb.Length > 0)
                    sb.Append(networkList[i]);
            }
            foreach (string networkListItem in networkListItems)
            {
                string line = networkListItem.Trim();
                if (line.StartsWith("(") && line.EndsWith(")") && line.Length >= 2)
                {
                    line = line.Substring(1, line.Length - 2);
                    string[] lineItems = line.Split(new char[] { ',' });
                    if (lineItems.Length >= 4 && lineItems.Length <= 5)
                    {
                        CellularNetworkStatus parsedNetworkStatus;
                        string parsedLongName;
                        string parsedShortName;
                        int parsedNumeric;
                        CellularAccessTechnology parsedAccessTechnology = CellularAccessTechnology.Unknown;
                        int parsedNetworkStatusNumeric;
                        if (CommonUtilities.TryParseInteger(lineItems[0], out parsedNetworkStatusNumeric) == false)
                            continue;
                        if (Enum.IsDefined(typeof(CellularNetworkStatus), parsedNetworkStatusNumeric) == false)
                            continue;
                        parsedNetworkStatus = (CellularNetworkStatus)parsedNetworkStatusNumeric;
                        parsedLongName = lineItems[1].Replace("\"", "");
                        parsedShortName = lineItems[2].Replace("\"", "");
                        if (CommonUtilities.TryParseInteger(lineItems[3].Replace("\"", ""), out parsedNumeric) == false)
                            continue;
                        // Check if access technology is present
                        if (lineItems.Length == 5)
                        {
                            int parsedAccessTechnologyNumeric;
                            if (CommonUtilities.TryParseInteger(lineItems[4].Replace("\"", ""), out parsedAccessTechnologyNumeric) == false)
                                continue;
                            if (Enum.IsDefined(typeof(CellularAccessTechnology), parsedAccessTechnologyNumeric) == false)
                                continue;
                            parsedAccessTechnology = (CellularAccessTechnology)parsedAccessTechnologyNumeric;
                        }
                        result.Add(new CellularNetworkCarrierItem(parsedNetworkStatus, parsedLongName, parsedShortName, parsedNumeric, parsedAccessTechnology));
                    }
                }
            }
            networks = result.ToArray();
            return true;
        }

        /// <summary>
        /// Get modem currently registered network.
        /// </summary>
        /// <param name="networkRegistration">Type of the network registration.</param>
        /// <returns>Returns True if the query to the modem was successful.</returns>
        public bool GetNetworkRegistration(out GprsNetworkRegistration networkRegistration)
        {
            networkRegistration = GprsNetworkRegistration.Unknown;
            serial.LineWriteLine("AT+CREG?", 2000);
            if (serial.Wait() == false)
                return false;
            string[] data = serial.ReadLines();
            if (IsResponseOk(data, 2) == true)
            {
                string[] command = data[0].Split(new char[] { ':' });
                if (command != null && command.Length == 2 && command[0] == "+CREG")
                {
                    command = command[1].Split(new char[] { ',' });
                    if (command != null && command.Length == 2)
                    {
                        try
                        {
                            int networkRegistrationValue = int.Parse(command[1]);
                            switch (networkRegistrationValue)
                            {
                                case 0:
                                    networkRegistration = GprsNetworkRegistration.NotRegistered;
                                    break;
                                case 1:
                                    networkRegistration = GprsNetworkRegistration.Registered;
                                    break;
                                case 2:
                                    networkRegistration = GprsNetworkRegistration.Searching;
                                    break;
                                case 3:
                                    networkRegistration = GprsNetworkRegistration.RegistrationDenied;
                                    break;
                                case 5:
                                    networkRegistration = GprsNetworkRegistration.RegisteredRoaming;
                                    break;
                                default:
                                    networkRegistration = GprsNetworkRegistration.Unknown;
                                    break;
                            }
                            return true;
                        }
                        catch
                        {
                            networkRegistration = GprsNetworkRegistration.Unknown;
                        }
                    }
                }
            }
            return false;
        }
    }
}
