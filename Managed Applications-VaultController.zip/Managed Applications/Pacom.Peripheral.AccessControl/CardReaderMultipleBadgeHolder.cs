﻿using System.Collections.Generic;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.AccessControl
{
    public class CardReaderMultipleBadgeHolder
    {
        /// <summary>
        /// Double badge timespan in milliseconds
        /// </summary>
        private const int DoubleBadgeTimeout = 7000;

        private Dictionary<long, CardMultiBadgeInfo> lastTimeUsedCardList = null;

        public CardReaderMultipleBadgeHolder()
        {
            lastTimeUsedCardList = new Dictionary<long, CardMultiBadgeInfo>();
        }

        /// <summary>
        /// Check if multibadging occured for this user 
        /// </summary>
        /// <returns>Badge count</returns>
        public int CheckMultiBadge(long antipassbackId)
        {
            removeOlderEntries();

            CardMultiBadgeInfo multiBadgeInfo = null;
            if (lastTimeUsedCardList.TryGetValue(antipassbackId, out multiBadgeInfo) == true)
            {
                multiBadgeInfo.Count++;
                multiBadgeInfo.LastUsedDateTime.Reset();
            }
            else
            {
                lastTimeUsedCardList.Clear();
                multiBadgeInfo = new CardMultiBadgeInfo();
                lastTimeUsedCardList[antipassbackId] = multiBadgeInfo;
            }
            return lastTimeUsedCardList[antipassbackId].Count;
        }

        private void removeOlderEntries()
        {
            CardMultiBadgeInfo multiBadgeInfo = null;
            List<long> toRemoveCardList = new List<long>();
            foreach (var pair in lastTimeUsedCardList)
            {
                multiBadgeInfo = pair.Value;
                if (multiBadgeInfo.LastUsedDateTime.ElapsedTime > DoubleBadgeTimeout)
                {
                    toRemoveCardList.Add(pair.Key);
                }
            }
            if (toRemoveCardList.Count > 0)
            {
                toRemoveCardList.ForEach(toRemoveCardId =>
                {
                    lastTimeUsedCardList.Remove(toRemoveCardId);
                });
            }
        }

        /// <summary>
        /// Clear multi badge list
        /// </summary>
        public void Clear()
        {
            lastTimeUsedCardList.Clear();
        }
    }
}
