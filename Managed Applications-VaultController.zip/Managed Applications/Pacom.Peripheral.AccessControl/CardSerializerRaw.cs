﻿using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.AccessControl;
using System;
using Pacom.Peripheral.Hal;

namespace Pacom.Peripheral.AccessControl
{
    public class CardSerializerRaw : CardSerializerBase
    {
        /// <summary>
        /// Serialize this card as a byte array.
        /// </summary>
        /// <param name="item">Card to serialize</param>
        /// <param name="output">Serialized byte array</param>
        /// <returns>True if the serialization was successful</returns>
        public override bool Serialize(CardInformation cardInformation, out byte[] output)
        {
            bool result = base.Serialize(cardInformation, out output);
            if (result == false)
                return false;

            try
            {
                CardNumberRaw cardNumber = cardInformation.CardNumber.Raw;

                output[0] = (byte)(CardStorageParameters.FrameVersionRaw);
                // Write Card Logical Id
                output[20] = (byte)(cardInformation.CardId >> 24);
                output[21] = (byte)(cardInformation.CardId >> 16);
                output[22] = (byte)(cardInformation.CardId >> 8);
                output[23] = (byte)(cardInformation.CardId);
                
                // Write Card Bit Length
                output[24] = (byte)(cardNumber.CardBitLength);

                // Write Card Number
                Buffer.BlockCopy(cardNumber.CardNumber, 0, output, 25, CardNumberRaw.RawCardNumberLength);
                // Write Card Status
                output[57] = (byte)(cardInformation.CardStatus);

                // Write User Logical Id
                output[58] = (byte)(cardInformation.UserId >> 24);
                output[59] = (byte)(cardInformation.UserId >> 16);
                output[60] = (byte)(cardInformation.UserId >> 8);
                output[61] = (byte)(cardInformation.UserId);

                // Calculate check sum
                byte[] checkSum = Crc32.ComputeHash(output, 0, output.Length - 4);
                int crcIndex = CardStorageParameters.FrameSize - CardStorageParameters.CrcItemSize;
                output[crcIndex] = checkSum[0];
                output[crcIndex + 1] = checkSum[1];
                output[crcIndex + 2] = checkSum[2];
                output[crcIndex + 3] = checkSum[3];
            }
            catch
            {
                // We do not tolerate deserialize exceptions. The frame must have been corrupted.
                output = null;
                return false;
            }
            return result;
        }

        /// <summary>
        /// Deserialize card from byte array
        /// </summary>
        /// <param name="data">byte array of data</param>
        /// <returns>Returns card or null if invalid array was provided</returns>
        public override bool Deserialize(byte[] data, ref CardInformation cardInformation)
        {
            if (base.Deserialize(data, ref cardInformation) == false)
                return false;
            if (data[0] != CardStorageParameters.FrameVersionRaw)
                return false;

            try
            {
                // Read Card Logical Id
                cardInformation.CardId = (int)((int)data[20] << 24) | (int)((int)data[21] << 16) |
                                         (int)((int)data[22] << 8) | (int)((int)data[23]);

                // Read Card Bit Length
                int cardBitLength = data[24];

                // Read Card Number
                byte[] cardNumber = new byte[CardNumberRaw.RawCardNumberLength];
                Buffer.BlockCopy(data, 25, cardNumber, 0, CardNumberRaw.RawCardNumberLength);
                cardInformation.CardNumber = new CardNumberHolder(cardNumber, cardBitLength);

                // Read Card Status
                cardInformation.CardStatus = (CardStatusType8003)data[57];

                // Read User Logical Id
                cardInformation.UserId = (int)((int)data[58] << 24) | (int)((int)data[59] << 16) |
                                         (int)((int)data[60] << 8) | (int)((int)data[61]);
            }
            catch
            {
                cardInformation = null;
                return false;
            }
            return true;
        }

        private static byte[] cardId = new byte[4];
        
        /// <summary>
        /// Deserialize only the logical card id used by Unison.
        /// </summary>
        /// <param name="frameId">Frame Id to get the card id for.</param>
        /// <returns>Card id for the card record</returns>
        public int DeserializeCardId(int frameId)
        {
            Sram.Instance.ReadData(SramLocations.CardStartOffset + (frameId * CardStorageParameters.FrameSize) + 20, cardId);
            return (int)((int)cardId[0] << 24) | (int)((int)cardId[1] << 16) | (int)((int)cardId[2] << 8) | (int)((int)cardId[3]);
        }
    }
}
