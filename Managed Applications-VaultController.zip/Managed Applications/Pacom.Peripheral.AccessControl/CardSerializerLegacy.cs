﻿using System;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.AccessControl
{
    public class CardSerializerLegacy : CardSerializerBase
    {
        public CardSerializerLegacy()
            : base()
        {
        }

        /// <summary>
        /// Serialize this card as a byte array.
        /// </summary>
        /// <param name="item">Card to serialize</param>
        /// <param name="output">Serialized byte array</param>
        /// <returns>True if the serialization was successful</returns>
        public override bool Serialize(CardInformation cardInformation, out byte[] output)
        {
            bool result = base.Serialize(cardInformation, out output);
            if (result == false)
                return false;

            try
            {
                long cardNumber = cardInformation.CardNumber.Legacy.AsLong();

                output[0] = (byte)(CardStorageParameters.FrameVersionLegacy);
                output[12] = (byte)(cardNumber >> 56);
                output[13] = (byte)(cardNumber >> 48);
                output[14] = (byte)(cardNumber >> 40);
                output[15] = (byte)(cardNumber >> 32);
                output[16] = (byte)(cardNumber >> 24);
                output[17] = (byte)(cardNumber >> 16);
                output[18] = (byte)(cardNumber >> 8);
                output[19] = (byte)(cardNumber);

                // Write UserPin
                output[20] = (byte)(cardInformation.UserPin >> 24);
                output[21] = (byte)(cardInformation.UserPin >> 16);
                output[22] = (byte)(cardInformation.UserPin >> 8);
                output[23] = (byte)(cardInformation.UserPin);

                // Write User GroupId
                output[24] = (byte)(cardInformation.GroupId >> 24);
                output[25] = (byte)(cardInformation.GroupId >> 16);
                output[26] = (byte)(cardInformation.GroupId >> 8);
                output[27] = (byte)(cardInformation.GroupId);

                output[28] = 0;
                if (cardInformation.Blocked == true)
                {
                    output[28] |= 0x01;
                }
                if (cardInformation.Expired == true)
                {
                    output[28] |= 0x02;
                }

                // Write all 64 reader schedules
                for (int i = 0; i < CardInformation.LegacyReaderScheduleCount; i++)
                {
                    int j = 29 + i * 4;
                    int scheduleId = cardInformation.GetSchedule(i + 1);
                    output[j] = (byte)(scheduleId >> 24);
                    output[j + 1] = (byte)(scheduleId >> 16);
                    output[j + 2] = (byte)(scheduleId >> 8);
                    output[j + 3] = (byte)(scheduleId);
                }

                int dateIndex = 29 + CardInformation.LegacyReaderScheduleCount*4;
                output[dateIndex++] = (byte)cardInformation.StartDate.Day;
                output[dateIndex++] = (byte)cardInformation.StartDate.Month;
                output[dateIndex++] = (byte)cardInformation.StartDate.Year;
                output[dateIndex++] = (byte)(cardInformation.StartDate.Year >> 8);
                output[dateIndex++] = (byte)(cardInformation.StartDate.Year >> 16);
                output[dateIndex++] = (byte)(cardInformation.StartDate.Year >> 24);
                output[dateIndex++] = (byte)cardInformation.EndDate.Day;
                output[dateIndex++] = (byte)cardInformation.EndDate.Month;
                output[dateIndex++] = (byte)cardInformation.EndDate.Year;
                output[dateIndex++] = (byte)(cardInformation.EndDate.Year >> 8);
                output[dateIndex++] = (byte)(cardInformation.EndDate.Year >> 16);
                output[dateIndex++] = (byte)(cardInformation.EndDate.Year >> 24);

                // User Flags
                int userFlagsIndex = 29 + 12 + CardInformation.LegacyReaderScheduleCount * 4;
                ushort userFlags = (ushort)cardInformation.UserFlags;
                output[userFlagsIndex++] = (byte)(userFlags);
                output[userFlagsIndex++] = (byte)(userFlags >> 8);

                // Floor Access
                int floorAcessIndex = userFlagsIndex;
                if (cardInformation.FloorsAccess != null && cardInformation.FloorsAccess.Length > 0)
                {
                    byte[] floors = cardInformation.FloorsAccess.ToByteArray();
                    Array.Copy(floors, 0, output, floorAcessIndex, Math.Min(16, floors.Length));
                }
                int floorAcessTimezoneIndex = floorAcessIndex + 16;
                output[floorAcessTimezoneIndex++] = (byte)(cardInformation.FloorsAccessTimezoneId >> 24);
                output[floorAcessTimezoneIndex++] = (byte)(cardInformation.FloorsAccessTimezoneId >> 16);
                output[floorAcessTimezoneIndex++] = (byte)(cardInformation.FloorsAccessTimezoneId >> 8);
                output[floorAcessTimezoneIndex++] = (byte)(cardInformation.FloorsAccessTimezoneId);
                
                // Calculate check sum
                byte[] checkSum = Crc32.ComputeHash(output, 0, output.Length - 4);
                int crcIndex = CardStorageParameters.FrameSize - CardStorageParameters.CrcItemSize;
                output[crcIndex] = checkSum[0];
                output[crcIndex + 1] = checkSum[1];
                output[crcIndex + 2] = checkSum[2];
                output[crcIndex + 3] = checkSum[3];
            }
            catch
            {
                // We do not tolerate deserialize exceptions. The frame must have been completely corrupted.
                output = null;
                return false;
            }
            return result;
        }

        /// <summary>
        /// Deserialize card from byte array
        /// </summary>
        /// <param name="data">byte array of data</param>
        /// <returns>Returns card or null if invalid array was provided</returns>
        public override bool Deserialize(byte[] data, ref CardInformation cardInformation)
        {
            if (base.Deserialize(data, ref cardInformation) == false)
                return false;
            if (data[0] != CardStorageParameters.FrameVersionLegacy)
                return false;
            try
            {
                cardInformation.CardNumber = new CardNumberHolder((long)((long)data[12] << 56) | (long)((long)data[13] << 48) |
                                                                  (long)((long)data[14] << 40) | (long)((long)data[15] << 32) |
                                                                  (long)((long)data[16] << 24) | (long)((long)data[17] << 16) |
                                                                  (long)((long)data[18] << 8) | (long)((long)data[19]));

                cardInformation.UserPin = (data[20] << 24) | (data[21] << 16) | (data[22] << 8) | (data[23]);
                cardInformation.GroupId = (data[24] << 24) | (data[25] << 16) | (data[26] << 8) | (data[27]);

                if ((data[28] & 0x01) == 0x01)
                    cardInformation.Blocked = true;
                else
                    cardInformation.Blocked = false;
                if ((data[28] & 0x02) == 0x02)
                    cardInformation.Expired = true;
                else
                    cardInformation.Expired = false;

                int[] scheduleIds = new int[CardInformation.LegacyReaderScheduleCount];
                for (int i = 0; i < CardInformation.LegacyReaderScheduleCount; i++)
                {
                    int j = 29 + i * 4;
                    scheduleIds[i] = (data[j] << 24) | (data[j + 1] << 16) | (data[j + 2] << 8) | (data[j + 3]);
                }
                cardInformation.SetSchedules(scheduleIds);

                int dateIndex = 29 + CardInformation.LegacyReaderScheduleCount * 4;
                int day = data[dateIndex++];
                int month = data[dateIndex++];
                int year = data[dateIndex++] | (data[dateIndex++] << 8) | (data[dateIndex++] << 16) | (data[dateIndex++] << 24);
                cardInformation.StartDate = year >= 2000 ? new DateTime(year, month, day) : new DateTime(2000, 1, 1);
                day = data[dateIndex++];
                month = data[dateIndex++];
                year = data[dateIndex++] | (data[dateIndex++] << 8) | (data[dateIndex++] << 16) | (data[dateIndex++] << 24);
                cardInformation.EndDate = year >= 2000 ? new DateTime(year, month, day) : new DateTime(9999, 12, 31);

                int userFlagsIndex = 29 + 12 + CardInformation.LegacyReaderScheduleCount * 4;
                ushort userFlags = (ushort)((data[userFlagsIndex++]) | (data[userFlagsIndex++] << 8));
                cardInformation.UserFlags = (LegacyCardUserFlags)userFlags;

                // Floor Access
                int floorAcessIndex = userFlagsIndex;
                cardInformation.FloorsAccess = data.ToBooleanArray(floorAcessIndex, 16);
                
                int floorAcessTimezoneIndex = floorAcessIndex + 16;
                cardInformation.FloorsAccessTimezoneId = (data[floorAcessTimezoneIndex] << 24) | (data[floorAcessTimezoneIndex + 1] << 16) | (data[floorAcessTimezoneIndex + 2] << 8) | (data[floorAcessTimezoneIndex+3]);
            }
            catch
            {
                cardInformation = null;
                return false;
            }
            return true;
        }

        /// <summary>
        /// Deserialize card from byte array
        /// </summary>
        /// <param name="data"></param>
        /// <param name="cardInformation"></param>
        /// <returns> Return card information with card number and end date only</returns>
        public bool DeserializeTemporaryCard(byte[] data, ref CardInformation cardInformation)
        {
            try
            {
                if (data[0] == CardStorageParameters.FrameVersionLegacy && isValidCardData(data))
                {
                    cardInformation.CardNumber = new CardNumberHolder((long)((long)data[12] << 56) | (long)((long)data[13] << 48) |
                                                                      (long)((long)data[14] << 40) | (long)((long)data[15] << 32) |
                                                                      (long)((long)data[16] << 24) | (long)((long)data[17] << 16) |
                                                                      (long)((long)data[18] << 8) | (long)((long)data[19]));
                    // endDateIndex = schedule index (29) + size of schedule + size of start date
                    int endDateIndex = 29 + (CardInformation.LegacyReaderScheduleCount * 4) + 6;
                    int day = data[endDateIndex++];
                    int month = data[endDateIndex++];
                    int year = data[endDateIndex++] | (data[endDateIndex++] << 8) | (data[endDateIndex++] << 16) | (data[endDateIndex++] << 24);
                    cardInformation.EndDate = new DateTime(year, month, day);
                    return true;
                }
            }
            catch
            {
            }
            return false;
        }

#if DEBUG
        public bool DeserializeCardHolderId(byte[] data, ref UniqueCardHolderId cardHolder)
        {
            try
            {
                if (data[0] == CardStorageParameters.FrameVersionLegacy && isValidCardData(data))
                {
                    cardHolder.Id = (long)((long)data[12] << 56) | (long)((long)data[13] << 48) |
                                                                      (long)((long)data[14] << 40) | (long)((long)data[15] << 32) |
                                                                      (long)((long)data[16] << 24) | (long)((long)data[17] << 16) |
                                                                      (long)((long)data[18] << 8) | (long)((long)data[19]);
                    int startDateIndex = 29 + (CardInformation.LegacyReaderScheduleCount * 4);
                    int day = data[startDateIndex++];
                    int month = data[startDateIndex++];
                    int year = data[startDateIndex++] | (data[startDateIndex++] << 8) | (data[startDateIndex++] << 16) | (data[startDateIndex++] << 24);
                    cardHolder.StartDate = new DateTime(year, month, day);
                    int endDateIndex = 29 + (CardInformation.LegacyReaderScheduleCount * 4) + 6;
                    day = data[endDateIndex++];
                    month = data[endDateIndex++];
                    year = data[endDateIndex++] | (data[endDateIndex++] << 8) | (data[endDateIndex++] << 16) | (data[endDateIndex++] << 24);
                    cardHolder.EndDate = new DateTime(year, month, day);
                    return true;
                }
            }
            catch
            {
            }
            return false;
        }
#endif

    }
}
