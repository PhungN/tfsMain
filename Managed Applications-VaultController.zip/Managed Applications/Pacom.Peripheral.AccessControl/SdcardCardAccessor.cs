using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Text;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.SQLCE;
using Pacom.Core.Access;
using System.Data.SqlServerCe;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// This class interfaces SQL CE database for the SD Card.
    /// </summary>
    public class SdcardCardAccessor : ICardAccessor, IDisposable
    {
        private DbConnection connection = null;
        private DbCommand command = null;
        private StringBuilder sqlCommand = new StringBuilder();

        private string gmsCardTableName = "Cardholders";
        private string unisonCardTableName = "CardholdersRaw";

        private readonly object writeLock = new object();

        public SdcardCardAccessor()
        {
            connection = SqlCeDatabase.Instance.OpenDatabase();
            connection.Open();
            command = connection.CreateCommand();

            createTable();

            // Check if UserFlags exist in GMS table
            addTableColumn("Cardholders", "UserFlags", "INT DEFAULT 0");

            addTableColumn("Cardholders", "FloorsAccess", "BINARY(16) DEFAULT 0");
            addTableColumn("Cardholders", "FloorsAccessTimezoneId", "INT DEFAULT 0");

            // Check if StartDate/EndDate exist in GMS table
            command.CommandText = @"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='StartDate' AND TABLE_NAME='Cardholders'";
            var columnExists = command.ExecuteScalar();
            if ((columnExists == null || columnExists.ToString() != "StartDate"))
            {
                command.CommandText = "ALTER TABLE Cardholders ADD StartDate DATETIME NOT NULL DEFAULT '20000101', EndDate DATETIME NOT NULL DEFAULT '99991231'";
                command.ExecuteNonQuery();

                command.CommandText = "SELECT CONSTRAINT_NAME FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_NAME = 'Cardholders' AND CONSTRAINT_TYPE = 'PRIMARY KEY'";
                var reader = command.ExecuteReader();
                string primaryKey = reader.Read() == true ? reader.GetString(0) : null;
                if (string.IsNullOrEmpty(primaryKey) == false)
                {
                    // 1. Remove primary key (CardholderId)
                    command.CommandText = string.Format("ALTER TABLE Cardholders DROP CONSTRAINT {0}", primaryKey);
                    command.ExecuteNonQuery();

                    // 2. Create new primary key (CardholderId, StartDate, EndDate)
                    command.CommandText = "ALTER TABLE Cardholders ADD CONSTRAINT PK_GmsCardholderId PRIMARY KEY (CardholderId, StartDate, EndDate)";
                    command.ExecuteNonQuery();
                }
            }

            int legacyRecordCount = 0;
            command.Parameters.Clear();
            command.CommandText = @"SELECT CARDINALITY FROM INFORMATION_SCHEMA.INDEXES WHERE PRIMARY_KEY = 1 AND TABLE_NAME = N'Cardholders'";
            object count = command.ExecuteScalar();
            if (count == null)
                legacyRecordCount = 0;
            else
                legacyRecordCount = (int)(Int64)count;

            int rawRecordCount = 0;
            command.Parameters.Clear();
            command.CommandText = @"SELECT CARDINALITY FROM INFORMATION_SCHEMA.INDEXES WHERE PRIMARY_KEY = 1 AND TABLE_NAME = N'CardholdersRaw'";
            count = command.ExecuteScalar();
            if (count == null)
                rawRecordCount = 0;
            else
                rawRecordCount = (int)(Int64)count;

            if (legacyRecordCount == 0 && rawRecordCount == 0)
            {
                DatabaseMode = CardAccessDatabaseMode.NoCardsPresent;
            }
            else if (legacyRecordCount > 0 && rawRecordCount == 0)
            {
                DatabaseMode = CardAccessDatabaseMode.Gms;
            }
            else if (legacyRecordCount == 0 && rawRecordCount > 0)
            {
                DatabaseMode = CardAccessDatabaseMode.Unison;
            }
            else
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return "Found both GMS and Unison card records. Clearing card database.";
                });

                command.Parameters.Clear();
                command.CommandText = "DROP TABLE Cardholders";
                command.ExecuteNonQuery();
                command.CommandText = "DROP TABLE CardholdersRaw";
                command.ExecuteNonQuery();
                DatabaseMode = CardAccessDatabaseMode.NoCardsPresent;
				createTable();
            }
        }

        private void createTable()
        {
            if (connection.TableExists(gmsCardTableName) == false)
            {
                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE TABLE Cardholders(" +
                    "CardholderId BIGINT," +
                    "Version TINYINT NOT NULL," +
                    "UserPin INT NULL," +
                    "GroupId INT NULL," +
                    "Blocked BIT DEFAULT 0," +
                    "Expired BIT DEFAULT 0," +
                    "LastUsed DATETIME DEFAULT GETDATE(),");
                for (int i = 0; i < CardInformation.LegacyReaderScheduleCount; i++)
                    sqlCommand.AppendFormat("RS{0} INT NULL,", i.ToString("00"));
                sqlCommand.Append("StartDate DATETIME NOT NULL DEFAULT '20000101',");
                sqlCommand.Append("EndDate DATETIME NOT NULL DEFAULT '99991231',");
                sqlCommand.Append("UserFlags INT DEFAULT 0,");
                sqlCommand.Append("FloorsAccess BINARY(16) DEFAULT 0,");
                sqlCommand.Append("FloorsAccessTimezoneId INT DEFAULT 0,");
                sqlCommand.Append("PRIMARY KEY (CardholderId, StartDate, EndDate))");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();
            }

            if (connection.TableExists(unisonCardTableName) == false)
            {
                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE TABLE CardholdersRaw(" +
                                        "CardLogicalId INT PRIMARY KEY," +
                                        "UserLogicalId INT NOT NULL," +
                                        "Version TINYINT NOT NULL," +
                                        "CardNumber BINARY(32) NOT NULL," +
                                        "CardBitLength TINYINT NULL," +
                                        "CardStatus TINYINT DEFAULT 0," +
                                        "LastUsed DATETIME DEFAULT GETDATE())");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();

                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE NONCLUSTERED INDEX ixCardholdersRaw ON CardholdersRaw(" +
                                        "CardNumber ASC," +
                                        "CardBitLength ASC)");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();
            }
        }

        private void addTableColumn(string tableName, string columnName, string dataType)
        {
            command.CommandText = string.Format(@"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='{0}' AND TABLE_NAME='{1}'", columnName, tableName);
            var columnExists = command.ExecuteScalar();
            if ((columnExists == null || columnExists.ToString() != columnName))
            {
                command.CommandText = string.Format("ALTER TABLE {0} ADD {1} {2}", tableName, columnName, dataType);
                command.ExecuteNonQuery();
            }
        }

        public CardAccessDatabaseMode DatabaseMode
        {
            get;
            private set;
        }

        /// <summary>
        /// Get count of all cards handled by this accessor
        /// </summary>
        /// <returns></returns>
        public int Count
        {
            get
            {
                string cardTableName;
                if (DatabaseMode == CardAccessDatabaseMode.NoCardsPresent)
                    return 0;
                if (DatabaseMode == CardAccessDatabaseMode.Unison)
                    cardTableName = unisonCardTableName;
                else
                    cardTableName = gmsCardTableName;

                lock (connection)
                {
                    command.Parameters.Clear();
                    command.CommandText = string.Format(@"SELECT CARDINALITY FROM INFORMATION_SCHEMA.INDEXES WHERE PRIMARY_KEY = 1 AND TABLE_NAME = N'{0}'", cardTableName);
                    object count = command.ExecuteScalar();
                    if (count == null)
                        return 0;
                    else
                        return (int)(Int64)count;
                }
            }
        }

        private bool setLegacyCardInformation(CardInformation cardInformation)
        {
            if (ConfigurationManager.Instance.IsUnisonMode || DatabaseMode == CardAccessDatabaseMode.Unison)
                return false;

            bool result = false;
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    sqlCommand.Length = 0;
                    sqlCommand.Append("UPDATE Cardholders ");
                    sqlCommand.Append("SET Version=@Version,UserPin=@UserPin,GroupId=@GroupId,Blocked=@Blocked,Expired=@Expired,LastUsed=@LastUsed,UserFlags=@UserFlags,FloorsAccess=@FloorsAccess,FloorsAccessTimezoneId=@FloorsAccessTimezoneId,");
                    command.AddParameterWithValue("Version", CardStorageParameters.FrameVersionLegacy);
                    command.AddParameterWithValue("UserPin", cardInformation.UserPin);
                    command.AddParameterWithValue("GroupId", cardInformation.GroupId);
                    command.AddParameterWithValue("Blocked", cardInformation.Blocked);
                    command.AddParameterWithValue("Expired", cardInformation.Expired);
                    command.AddParameterWithValue("LastUsed", cardInformation.LastUsed);
                    for (int i = 0; i < CardInformation.LegacyReaderScheduleCount; i++)
                    {
                        string readerScheduleId = string.Format("RS{0}", i.ToString().PadLeft(2, '0'));
                        sqlCommand.AppendFormat("{0}=@{1}", readerScheduleId, readerScheduleId);
                        if (i < CardInformation.LegacyReaderScheduleCount - 1)
                            sqlCommand.AppendFormat(",");
                        command.AddParameterWithValue(readerScheduleId, cardInformation.GetSchedule(i + 1));
                    }
                    command.AddParameterWithValue("CardholderId", cardInformation.CardNumber.Legacy.AsLong());
                    command.AddParameterWithValue("StartDate", cardInformation.StartDate.Date);
                    command.AddParameterWithValue("EndDate", cardInformation.EndDate.Date);
                    command.AddParameterWithValue("UserFlags", (int)cardInformation.UserFlags);
                    command.AddParameterWithValue("FloorsAccess", cardInformation.FloorsAccess.ToByteArray());
                    command.AddParameterWithValue("FloorsAccessTimezoneId", cardInformation.FloorsAccessTimezoneId);
                    sqlCommand.Append(" WHERE CardholderId=@CardholderId AND StartDate=@StartDate AND EndDate=@EndDate");
                    command.CommandText = sqlCommand.ToString();
                    int count = command.ExecuteNonQuery();
                    if (count == 0)
                    {
                        sqlCommand.Length = 0;
                        sqlCommand.Append("INSERT INTO Cardholders (CardholderId,Version,UserPin,GroupId,Blocked,Expired,LastUsed,");
                        for (int i = 0; i < CardInformation.LegacyReaderScheduleCount; i++)
                        {
                            string ReaderScheduleId = string.Format("RS{0}", i.ToString().PadLeft(2, '0'));
                            sqlCommand.AppendFormat("{0},", ReaderScheduleId);
                        }
                        sqlCommand.Append("StartDate, EndDate, UserFlags, FloorsAccess, FloorsAccessTimezoneId) VALUES(@CardholderId,@Version,@UserPin,@GroupId,@Blocked,@Expired,@LastUsed,");
                        for (int i = 0; i < CardInformation.LegacyReaderScheduleCount; i++)
                        {
                            string ReaderScheduleId = string.Format("RS{0}", i.ToString().PadLeft(2, '0'));
                            sqlCommand.AppendFormat("@{0},", ReaderScheduleId);
                        }
                        sqlCommand.Append("@StartDate, @EndDate, @UserFlags, @FloorsAccess, @FloorsAccessTimezoneId)");
                        command.CommandText = sqlCommand.ToString();
                        command.ExecuteNonQuery();
                    }
                    result = true;
                }
                DatabaseMode = CardAccessDatabaseMode.Gms;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("CARD: Error while setting card record. {0}", ex.Message);
                });
                result = false;
            }
            return result;
        }

        public bool Set(CardInformation cardInformation)
        {
            if (cardInformation.IsRawCardFormat == false)
                return setLegacyCardInformation(cardInformation);
            else
                return setUnisonCardInformation(cardInformation);
        }

        /// <summary>
        /// Add multiple cards to the SD card from Unison. This is done optimise the download process as much as possible.
        /// </summary>
        public bool SetMultiple(List<Credential> cards)
        {
            if (ConfigurationManager.Instance.IsUnisonMode == false || DatabaseMode == CardAccessDatabaseMode.Gms)
                return false;

            bool result = false;
            try
            {
                SqlCeConnection writeConnection = new SqlCeConnection(SqlCeDatabase.Instance.DefaultConnectionString);
                writeConnection.Open();
                SqlCeCommand writeCommand = writeConnection.CreateCommand();
                SqlCeResultSet resultSet;

                int lowestCardId = int.MaxValue;
                int highestCardId = int.MinValue;
                for (int i = 0; i < cards.Count; i++)
                {
                    if (cards[i].Id < lowestCardId)
                        lowestCardId = cards[i].Id;
                    if (cards[i].Id > highestCardId)
                        highestCardId = cards[i].Id;
                }

                writeCommand.CommandText = string.Format("SELECT * FROM CardholdersRaw WHERE CardLogicalId >= {0} AND CardLogicalId <= {1}", lowestCardId, highestCardId);
                resultSet = writeCommand.ExecuteResultSet(ResultSetOptions.Updatable);
                while (resultSet.Read())
                {
                    int resultSetId = resultSet.GetInt32(0);
                    // Update all already existing cards
                    for (int i = 0; i < cards.Count; i++)
                    {
                        if (resultSetId == cards[i].Id)
                        {
                            Credential card = cards[i];
                            resultSet.SetInt32(1, card.UserId);
                            resultSet.SetByte(2, (byte)CardStorageParameters.FrameVersionRaw);
                            resultSet.SetBytes(3, 0, CommonUtilities.RationalizeRawCardNumber(card.CredentialData), 0, 32);
                            resultSet.SetByte(4, (byte)card.CardBitLength);
                            resultSet.SetByte(5, (byte)card.CardStatus.To8003CardStatus());
                            resultSet.SetDateTime(6, DateTime.UtcNow);
                            resultSet.Update();
                            cards.RemoveAt(i);
                            break;
                        }
                    }
                }
                resultSet.Dispose();

                writeCommand.CommandText = "SELECT * FROM CardholdersRaw";
                resultSet = writeCommand.ExecuteResultSet(ResultSetOptions.Updatable);
                SqlCeUpdatableRecord cardRecord = resultSet.CreateRecord();
                // Insert the remaining cards
                foreach (Credential card in cards)
                {
                    cardRecord.SetInt32(0, card.Id);
                    cardRecord.SetInt32(1, card.UserId);
                    cardRecord.SetByte(2, (byte)CardStorageParameters.FrameVersionRaw);
                    cardRecord.SetBytes(3, 0, CommonUtilities.RationalizeRawCardNumber(card.CredentialData), 0, 32);
                    cardRecord.SetByte(4, (byte)card.CardBitLength);
                    cardRecord.SetByte(5, (byte)card.CardStatus.To8003CardStatus());
                    cardRecord.SetDateTime(6, DateTime.UtcNow);
                    resultSet.Insert(cardRecord);
                }
                resultSet.Dispose();
                writeCommand.Dispose();
                writeConnection.Close();
                writeConnection.Dispose();

                DatabaseMode = CardAccessDatabaseMode.Unison;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("CARD: Error while setting card record. {0}", ex.Message);
                });
                result = false;
            }
            return result;
        }

        private bool setUnisonCardInformation(CardInformation cardInformation)
        {
            if (ConfigurationManager.Instance.IsUnisonMode == false || DatabaseMode == CardAccessDatabaseMode.Gms)
                return false;

            bool result = false;
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    command.AddParameterWithValue("CardLogicalId", cardInformation.CardId);
                    command.AddParameterWithValue("UserLogicalId", cardInformation.UserId);
                    command.AddParameterWithValue("Version", CardStorageParameters.FrameVersionRaw);
                    command.AddParameterWithValue("CardNumber", cardInformation.CardNumber.Raw.CardNumber);
                    command.AddParameterWithValue("CardBitLength", cardInformation.CardNumber.Raw.CardBitLength);
                    command.AddParameterWithValue("CardStatus", (byte)cardInformation.CardStatus);
                    command.AddParameterWithValue("LastUsed", cardInformation.LastUsed);
                    command.CommandText = "UPDATE CardholdersRaw SET Version=@Version,CardBitLength=@CardBitLength,CardNumber=@CardNumber,CardStatus=@CardStatus,UserLogicalId=@UserLogicalId,LastUsed=@LastUsed WHERE CardLogicalId=@CardLogicalId";
                    int count = command.ExecuteNonQuery();
                    if (count == 0)
                    {
                        command.CommandText = "INSERT INTO CardholdersRaw (CardLogicalId,UserLogicalId,Version,CardNumber,CardBitLength,CardStatus,LastUsed) VALUES(@CardLogicalId,@UserLogicalId,@Version,@CardNumber,@CardBitLength,@CardStatus,@LastUsed)";
                        command.ExecuteNonQuery();
                    }
                }
                DatabaseMode = CardAccessDatabaseMode.Unison;                                                                                                                                                                                                                                                                                                                
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("CARD: Error while setting card record. {0}", ex.Message);
                });
                result = false;
            }
            return result;
        }

        private bool getLegacyCardInformation(CardNumberHolder cardNumber, out CardInformation cardInformation)
        {
            bool result = false;
            cardInformation = null;
            long cardId = cardNumber.Legacy.AsLong();
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    command.AddParameterWithValue("CardholderId", cardId);
                    sqlCommand.Length = 0;
                    sqlCommand.Append(@"SELECT * FROM Cardholders WHERE CardholderId = @CardholderId");
                    command.CommandText = sqlCommand.ToString();
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read() == true)
                        {
                            cardInformation = new CardInformation(
                                new CardNumberHolder(cardId),
                                reader.GetBoolean(4),
                                reader.GetBoolean(5),
                                reader.GetInt32(2),
                                reader.GetInt32(3),
                                reader.GetDateTime(6));
                            int[] schedule = new int[CardInformation.LegacyReaderScheduleCount];
                            for (int i = 0; i < CardInformation.LegacyReaderScheduleCount; i++)
                            {
                                schedule[i] = reader.GetInt32(7 + i);
                            }
                            cardInformation.SetSchedules(schedule);
                            cardInformation.StartDate = reader.GetDateTime(71).Date;
                            cardInformation.EndDate = reader.GetDateTime(72).Date;
                            cardInformation.UserFlags = (LegacyCardUserFlags)reader.GetInt32(73);
                            cardInformation.FloorsAccess = getFloorsAccess(reader, 74);
                            cardInformation.FloorsAccessTimezoneId = reader.GetInt32(75);
                            result = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("CARDSD: Error while getting card record. {0}", ex.Message);
                });
                result = false;
            }
            return result;
        }

        private bool getUnisonCardInformation(CardNumberHolder cardNumber, out CardInformation cardInformation)
        {
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    command.AddParameterWithValue("CardNumber", cardNumber.Raw.CardNumber);
                    command.AddParameterWithValue("CardBitLength", cardNumber.Raw.CardBitLength);
                    sqlCommand.Length = 0;
                    sqlCommand.Append(@"SELECT * FROM CardholdersRaw WHERE CardNumber = @CardNumber AND CardBitLength = @CardBitLength");
                    command.CommandText = sqlCommand.ToString();
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read() == true)
                        {
                            cardInformation = new CardInformation(
                                reader.GetInt32(0),                         // Card Logical Id
                                reader.GetInt32(1),                         // User Logical Id
                                cardNumber,                                 // Card Number
                                (CardStatusType8003)reader.GetByte(5),      // Card Status
                                reader.GetDateTime(6));                     // Last Used DateTime
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("CARDSD: Error while getting card record. {0}", ex.Message);
                });
            }
            cardInformation = null;
            return false;
        }

        public CardNumberHolder GetUnisonCardNumber(int cardId)
        {
            CardNumberHolder cardNumberHolder = null;
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    command.AddParameterWithValue("CardLogicalId", cardId);
                    sqlCommand.Length = 0;
                    sqlCommand.Append(@"SELECT * FROM CardholdersRaw WHERE CardLogicalId = @CardLogicalId");
                    command.CommandText = sqlCommand.ToString();
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read() == true)
                        {
                            byte[] cardNumber = new byte[32];
                            reader.GetBytes(3, 0, cardNumber, 0, cardNumber.Length);
                            cardNumberHolder = new CardNumberHolder(cardNumber, reader.GetByte(4));
                            return cardNumberHolder;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("CARDSD: Error while getting card record. {0}", ex.Message);
                });
            }
            return null;
        }

        public bool Get(CardNumberHolder cardNumber, out CardInformation cardInformation)
        {
            if (cardNumber.IsRawCardFormat == false)
                return getLegacyCardInformation(cardNumber, out cardInformation);
            else
                return getUnisonCardInformation(cardNumber, out cardInformation);
        }

        /// <summary>
        /// Get card information for specific reader Id
        /// </summary>
        /// <returns>True if the card holder was found, False otherwise.</returns>
        public bool GetUnisonCardInformationForSpecificReader(CardNumberHolder cardNumber, int readerId, out CardInformation cardInformation)
        {
            return getUnisonCardInformation(cardNumber, out cardInformation);
        }

        public List<CardInformation> GetLegacyCardInformationList(CardNumberHolder cardNumber)
        {
            long cardId = cardNumber.Legacy.AsLong();
            List<CardInformation> cardInformationList = new List<CardInformation>();
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    command.AddParameterWithValue("CardholderId", cardId);
                    command.CommandText = "SELECT TOP (50) * FROM Cardholders WHERE CardholderId = @CardholderId";
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read() == true)
                        {
                            CardInformation cardInformation = new CardInformation(
                                new CardNumberHolder(cardId),
                                reader.GetBoolean(4),
                                reader.GetBoolean(5),
                                reader.GetInt32(2),
                                reader.GetInt32(3),
                                reader.GetDateTime(6));
                            int[] schedule = new int[CardInformation.LegacyReaderScheduleCount];
                            for (int i = 0; i < CardInformation.LegacyReaderScheduleCount; i++)
                            {
                                schedule[i] = reader.GetInt32(7 + i);
                            }
                            cardInformation.SetSchedules(schedule);
                            cardInformation.StartDate = reader.GetDateTime(71).Date;
                            cardInformation.EndDate = reader.GetDateTime(72).Date;
                            cardInformation.UserFlags = (LegacyCardUserFlags)reader.GetInt32(73);
                            cardInformation.FloorsAccess = getFloorsAccess(reader, 74);
                            cardInformation.FloorsAccessTimezoneId = reader.GetInt32(75);
                            cardInformationList.Add(cardInformation);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("CARDSD: Error while getting card record. {0}", ex.Message);
                });
                return null;
            }
            return cardInformationList;
        }

        public List<CardInformation> GetLegacyCardInformationListForSpecificReader(CardNumberHolder cardNumber, int readerId)
        {
            long cardId = cardNumber.Legacy.AsLong();
            lock (connection)
            {
                command.Parameters.Clear();
                command.AddParameterWithValue("CardholderId", cardId);
                command.CommandText = string.Format(@"SELECT TOP (50) UserPin, GroupId, Blocked, Expired, RS{0}, StartDate, EndDate, UserFlags, FloorsAccess, FloorsAccessTimezoneId FROM Cardholders WHERE CardholderId = @CardholderId",
                    (readerId - 1).ToString("00"));
                List<CardInformation> cardInformationList = new List<CardInformation>();
                try
                {
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read() == true)
                        {
                            CardInformation cardInformation = new CardInformation(
                                new CardNumberHolder(cardId),
                                reader.GetBoolean(2),
                                reader.GetBoolean(3),
                                reader.GetInt32(0),
                                reader.GetInt32(1),
                                DateTime.MinValue);
                            int[] schedule = new int[CardInformation.LegacyReaderScheduleCount];
                            schedule[readerId - 1] = reader.GetInt32(4);
                            cardInformation.SetSchedules(schedule);
                            cardInformation.StartDate = reader.GetDateTime(5);
                            cardInformation.EndDate = reader.GetDateTime(6);
                            cardInformation.UserFlags = (LegacyCardUserFlags)reader.GetInt32(7);
                            cardInformation.FloorsAccess = getFloorsAccess(reader, 8);
                            cardInformation.FloorsAccessTimezoneId = reader.GetInt32(9);
                            cardInformationList.Add(cardInformation);
                        }
                        return cardInformationList;
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return string.Format("CARDSD: Error while getting card record. {0}", ex.Message);
                    });
                    return null;
                }
            }
        }

        public void Delete(CardNumberHolder cardNumber)
        {
            lock (connection)
            {
                command.Parameters.Clear();
                if (cardNumber.IsRawCardFormat)
                {
                    command.AddParameterWithValue("CardNumber", cardNumber.Raw.CardNumber);
                    command.AddParameterWithValue("CardBitLength", cardNumber.Raw.CardBitLength);
                    command.CommandText = @"DELETE FROM CardholdersRaw WHERE CardNumber = @CardNumber AND CardBitLength = @CardBitLength";
                }
                else
                {
                    command.AddParameterWithValue("CardholderId", cardNumber.Legacy.AsLong());
                    command.CommandText = @"DELETE FROM Cardholders WHERE CardholderId = @CardholderId";
                }
                command.ExecuteNonQuery();
            }
            if (Count == 0)
                DatabaseMode = CardAccessDatabaseMode.NoCardsPresent;
        }

        public void Delete(long locationIndex)
        {
            lock (connection)
            {
                command.Parameters.Clear();
                if (DatabaseMode == CardAccessDatabaseMode.Unison)
                {
                    command.AddParameterWithValue("CardLogicalId", locationIndex);
                    command.CommandText = @"DELETE FROM CardholdersRaw WHERE CardLogicalId = @CardLogicalId";
                }
                else
                {
                    command.AddParameterWithValue("CardholderId", locationIndex);
                    command.CommandText = @"DELETE FROM Cardholders WHERE CardholderId = @CardholderId";
                }
                command.ExecuteNonQuery();
            }
            if (Count == 0)
                DatabaseMode = CardAccessDatabaseMode.NoCardsPresent;
        }

        public List<CardNumberHolder> DeleteTemporaryCards()
        {
            List<CardNumberHolder> deletedCards = new List<CardNumberHolder>();
            lock (connection)
            {
                DateTime currentDate = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow).Date;
                command.CommandText = "SELECT CardholderId, EndDate FROM Cardholders";
                var reader = command.ExecuteReader();
                while (reader.Read() == true)
                {
                    if (reader.GetDateTime(1).Date < currentDate)
                    {
                        CardNumberHolder cardNumber = new CardNumberHolder(reader.GetInt64(0));
                        if (deletedCards.Contains(cardNumber) == false)
                            deletedCards.Add(cardNumber);
                    }
                }
                reader.Close();

                if (deletedCards.Count > 0)
                {
                    command.CommandText = string.Format("DELETE FROM Cardholders WHERE EndDate < '{0}'", currentDate);
                    command.ExecuteNonQuery();
                }
            }

            return deletedCards;
        }

        public bool UpdateCardInformation(CardInformation cardInformation)
        {
            return false;
        }

        /// <summary>
        /// Delete all cards
        /// </summary>
        public void Clear()
        {
            string cardTableName;
            if (DatabaseMode == CardAccessDatabaseMode.NoCardsPresent)
                return;
            if (DatabaseMode == CardAccessDatabaseMode.Unison)
                cardTableName = unisonCardTableName;
            else
                cardTableName = gmsCardTableName;

            lock (connection)
            {
                command.Parameters.Clear();
                command.CommandText = string.Format(@"DROP TABLE {0}", cardTableName);
                command.ExecuteNonQuery();

                createTable();
                DatabaseMode = CardAccessDatabaseMode.NoCardsPresent;
            }
        }

        public bool Exists(CardInformation cardInformation)
        {
            lock (connection)
            {
                command.Parameters.Clear();
                if (cardInformation.CardNumber.IsRawCardFormat)
                {
                    command.CommandText = @"SELECT TOP(1) 1 FROM CardholdersRaw WHERE CardNumber = @CardNumber AND CardBitLength = @CardBitLength";
                    command.AddParameterWithValue("CardNumber", cardInformation.CardNumber.Raw.CardNumber);
                    command.AddParameterWithValue("CardBitLength", cardInformation.CardNumber.Raw.CardBitLength);
                }
                else
                {
                    command.CommandText = @"SELECT TOP(1) 1 FROM Cardholders WHERE CardholderId = @CardholderId AND StartDate = @StartDate AND EndDate = @EndDate";
                    command.AddParameterWithValue("CardholderId", cardInformation.CardNumber.Legacy.AsLong());
                    command.AddParameterWithValue("StartDate", cardInformation.StartDate.Date);
                    command.AddParameterWithValue("EndDate", cardInformation.EndDate.Date);
                }
                object cardExists = command.ExecuteScalar();
                return cardExists != null && (int)cardExists == 1;
            }
        }

        public CardNumberHolder GetLeastUsed(out long locationIndex)
        {
            locationIndex = -1;
            return null;
        }

        public bool GetLocationIndex(int cardId, out long locationIndex)
        {
            locationIndex = cardId;
            if (DatabaseMode != CardAccessDatabaseMode.Unison)
                return false;
            return true;
        }

        /// <summary>
        /// Get collection of all cards in SdCard accessor.
        /// </summary>
        /// <returns></returns>
        public List<long> ToList()
        {
            List<long> resultList = new List<long>();

            if (DatabaseMode == CardAccessDatabaseMode.NoCardsPresent)
                return resultList;
            
            lock (connection)
            {
                command.Parameters.Clear();

                if (DatabaseMode == CardAccessDatabaseMode.Unison)
                    command.CommandText = @"SELECT CardLogicalId FROM CardholdersRaw";
                else
                    command.CommandText = @"SELECT CardholderId FROM Cardholders";

                using (DbDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read() == true)
                    {
                        if (DatabaseMode == CardAccessDatabaseMode.Unison)
                            resultList.Add(reader.GetInt32(0));
                        else
                            resultList.Add(reader.GetInt64(0));
                    }
                }
            }
            return resultList;
        }

#if DEBUG
        public List<UniqueCardHolderId> GetUniqueCardHolderIDs()
        {
            if (DatabaseMode == CardAccessDatabaseMode.NoCardsPresent)
                return null;

            List<UniqueCardHolderId> cardHolders = new List<UniqueCardHolderId>();
            lock (connection)
            {
                command.Parameters.Clear();
                if (DatabaseMode == CardAccessDatabaseMode.Gms)
                {
                    command.CommandText = @"SELECT CardholderId, StartDate, EndDate FROM Cardholders";
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read() == true)
                        {
                            cardHolders.Add(new UniqueCardHolderId(reader.GetInt64(0), reader.GetDateTime(1), reader.GetDateTime(2)));
                        }
                    }
                }
                else
                {
                    command.CommandText = @"SELECT CardLogicalId FROM CardholdersRaw";
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read() == true)
                        {
                            cardHolders.Add(new UniqueCardHolderId(reader.GetInt32(0)));
                        }
                    }
                }
            }
            return cardHolders;
        }

        public CardInformation GetCardInformation(UniqueCardHolderId cardHolder)
        {
            CardInformation cardInformation = null;
            if (DatabaseMode == CardAccessDatabaseMode.Unison)
            {
                getUnisonCardInformation(GetUnisonCardNumber((int)cardHolder.Id), out cardInformation);
                return cardInformation;
            }
            
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    command.AddParameterWithValue("CardholderId", cardHolder.Id);
                    command.AddParameterWithValue("StartDate", cardHolder.StartDate);
                    command.AddParameterWithValue("EndDate", cardHolder.EndDate);
                    sqlCommand.Length = 0;
                    sqlCommand.Append(@"SELECT * FROM Cardholders WHERE CardholderId = @CardholderId AND StartDate = @StartDate AND EndDate = @EndDate");
                    command.CommandText = sqlCommand.ToString();
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read() == true)
                        {
                            cardInformation = new CardInformation(
                                new CardNumberHolder(cardHolder.Id),
                                reader.GetBoolean(4),
                                reader.GetBoolean(5),
                                reader.GetInt32(2),
                                reader.GetInt32(3),
                                reader.GetDateTime(6));
                            int[] schedule = new int[CardInformation.LegacyReaderScheduleCount];
                            for (int i = 0; i < CardInformation.LegacyReaderScheduleCount; i++)
                            {
                                schedule[i] = reader.GetInt32(7 + i);
                            }
                            cardInformation.SetSchedules(schedule);
                            cardInformation.StartDate = reader.GetDateTime(71).Date;
                            cardInformation.EndDate = reader.GetDateTime(72).Date;
                            cardInformation.UserFlags = (LegacyCardUserFlags)reader.GetInt32(73);
                            cardInformation.FloorsAccess = getFloorsAccess(reader, 74);
                            cardInformation.FloorsAccessTimezoneId = reader.GetInt32(75);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("CARDSD: Error while getting card record. {0}", ex.Message);
                });
            }
            return cardInformation;
        }
#endif

        private bool[] getFloorsAccess(DbDataReader dbReader, int index)
        {
            byte[] floorsAccess = new byte[16];
            dbReader.GetBytes(index, 0, floorsAccess, 0, floorsAccess.Length);
            return floorsAccess.ToBooleanArray();
        }

        #region IDisposable Members

        bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                if (disposing == true)
                {
                    // Free any other managed objects here.
                    if (command != null)
                    {
                        command.Dispose();
                        command = null;
                    }
                    if (connection != null)
                    {
                        connection.Close();
                        connection.Dispose();
                        connection = null;
                    }
                }

                // Free any unmanaged objects here.            
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
