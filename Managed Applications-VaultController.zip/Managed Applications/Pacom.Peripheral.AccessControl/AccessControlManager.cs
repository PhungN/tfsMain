﻿using System;
using System.Collections.Generic;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Status;
using Pacom.Core.Contracts;
using Pacom.Peripheral.PeerToPeerCommunications;
using Pacom.Peripheral.Common.Utilities;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// Access Control Manager implementation
    /// </summary>
    public class AccessControlManager : IAccessControlManager, IDisposable
    {
        /// <summary>
        /// Card Manager instance
        /// </summary>
        private AccessCardManager cardManager = null;
        private IPacomTimer deleteTemporaryCardsTimer = null;
        /// <summary>
        /// List of last time a card was badged on a reader. Sorted list keyed by logical reader id and stores a list of cards badged on this reader and
        /// the last time each card was badged.
        /// </summary>
        private SortedList<int, CardReaderMultipleBadgeHolder> cardReaderMultiBadgeList = new SortedList<int, CardReaderMultipleBadgeHolder>();

        private IPacomTimer broadcastDeleteAllCardsTimer = null;
        private bool globalAntiPassback;

        public event EventHandler<CardAccessEventArgs> CardDeletedEvent = null;
        public event EventHandler<CardAccessEventArgs> TemporaryCardDeletedEvent = null;
        public event EventHandler<CardAccessEventArgs> CardDownloadedEvent = null;
        public event EventHandler<CardAccessEventArgs> CardAccessGrantedEvent = null;
        public event EventHandler<CardAccessEventArgs> CardAccessGrantedDuressEvent = null;
        public event EventHandler<CardAccessEventArgs> AccessDeniedCardBlockedEvent = null;
        public event EventHandler<CardAccessEventArgs> AccessDeniedCardExpiredEvent = null;
        public event EventHandler<CardAccessEventArgs> AccessDeniedCardLostEvent = null;
        public event EventHandler<CardAccessEventArgs> AccessDeniedCardCancelledEvent = null;
        public event EventHandler<CardAccessEventArgs> AccessDeniedUserInvalidEvent = null;
        public event EventHandler<CardAccessEventArgs> CardNotProgrammedEvent = null;
        public event EventHandler<CardAccessEventArgs> AccessDeniedScheduleInvalidEvent = null;
        public event EventHandler<CardAccessEventArgs> AccessDeniedReaderBlockedEvent = null;
        public event EventHandler<CardAccessEventArgs> AccessDeniedReaderInvalidEvent = null;
        public event EventHandler<CardAccessEventArgs> AccessDeniedAntiPassbackEvent = null;
        public event EventHandler<CardAccessEventArgs> AccessGrantedAntiPassbackEvent = null;
        public event EventHandler<AccessDeniedDoorInterlockedEventArgs> AccessDeniedDoorInterlockedEvent = null;

        public event EventHandler<DoorEventArgs> AccessGrantedEgressEvent = null;
        public event EventHandler<DoorEventArgs> AccessDeniedEgressScheduleEvent = null;
        public event EventHandler<DoorEventArgs> AccessDeniedEgressEvent = null;
        public event EventHandler<AccessDeniedEgressInterlockedEventArgs> AccessDeniedEgressInterlockedEvent = null;

        public event EventHandler<AccessDeniedInvalidReaderPinEventArgs> AccessDeniedInvalidReaderPinEvent = null;
        public event EventHandler<ReaderLockoutEventArgs> ReaderLockoutEvent = null;
        public event EventHandler<ReaderKeypadEventArgs> ReaderKeypadInactivityTimeoutExpired = null;
        public event EventHandler<DeleteCardBroadcastEventArgs> CardNumberBroadcastEvent = null;

        public event EventHandler<CardAccessEventArgs> DualEntryPendingEvent = null;
        public event EventHandler<CardAccessEventArgs> TripleEntryPendingEvent = null;
        public event EventHandler<CardAccessEventArgs> AccessDeniedInvalidDualEntryEvent = null;
        public event EventHandler<CardAccessEventArgs> AccessDeniedInvalidTripleEntryEvent = null;
        /// <summary>
        /// Only one instance of the Access Control Manager will be created
        /// </summary>
        private static IAccessControlManager instance = null;

        /// <summary>
        /// Create an instance of Access Control Manager
        /// </summary>
        /// <returns></returns>
        public static IAccessControlManager CreateInstance()
        {
            if (instance == null)
                instance = new AccessControlManager();
            return instance;
        }

        public static IAccessControlManager Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return "Instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
#endif
                return instance;
            }
        }

        /// <summary>
        /// Default Constructor
        /// </summary>
        private AccessControlManager()
        {
            cardManager = AccessCardManager.Instance;
            cardManager.LeastUsedCardDeletedEvent += new EventHandler<LeastUsedCardDeletedEventArgs>(cardManager_LeastUsedCardDeletedEvent);
            StatusManager statusManager = StatusManager.Instance;
            statusManager.Doors.InputChangedStatus += new EventHandler<DoorInputChangedStatusEventArgs>(notify_ContactStatusChanged);
            statusManager.Doors.InputChangedStatus += new EventHandler<DoorInputChangedStatusEventArgs>(notify_EgressStatusChanged);
            statusManager.Doors.InputChangedStatus += new EventHandler<DoorInputChangedStatusEventArgs>(notify_StrikeStatusChanged);
            statusManager.Doors.OnUpdateAntipassbackInfo += new EventHandler<OnUpdateAntipassbackEventArgs>(notify_UpdateAntipassbackInfo);
            statusManager.Doors.CardAndPinEntered += new EventHandler<CardAndPinEnteredEventArgs>(notify_CardAndPinEntered);
            statusManager.Doors.KeypadInactivityTimeoutExpired += new EventHandler<ReaderKeypadEventArgs>(notify_ReaderKeypadInactivityTimeoutExpired);
            statusManager.Readers.InvalidMultiBadgingEvent += new EventHandler<MultiBadgingEventArgs>(notify_InvalidMultiBadgingEvent);

            ConfigurationManager.Instance.CardDownloadRequest += new EventHandler<CardDownloadEventArgs>(notify_CardDownloadRequest);
            ConfigurationManager.Instance.CardDeleteRequest += new EventHandler<CardDeleteEventArgs>(notify_CardDeleteRequest);
            ConfigurationManager.Instance.ConfigurationChanged += new EventHandler<ConfigurationChangeEventArgs>(Instance_ConfigurationChanged);
            LicenseManager.Instance.LicenseChanged += new EventHandler(Instance_LicenseChanged);

            statusManager.TimeChanged += new EventHandler<EventArgs>(onTimeChanged);
            deleteTemporaryCardsTimer = TimerManager.Instance.CreateTimer(onDeleteTemporaryCardsTimeout);
            deleteTemporaryCardsTimer.RunOnce(getMillisecondsToMidnight());

            Instance_ConfigurationChanged(null, null);
        }

        void Instance_LicenseChanged(object sender, EventArgs e)
        {
            updateGlobalAntiPassback();
        }

        void Instance_ConfigurationChanged(object sender, ConfigurationChangeEventArgs e)
        {
            updateGlobalAntiPassback();
        }

        void updateGlobalAntiPassback()
        {
            if (ConfigurationManager.Instance.ControllerConfiguration.PeerToPeerMode == PeerToPeerMode.Slave &&
                (ConfigurationManager.Instance.ControllerConfiguration.PeerToPeerEnabledFeatures & PeerToPeerFeatures.AntiPassback) == PeerToPeerFeatures.AntiPassback &&
                LicenseManager.Instance.PeerToPeer == true)
            {
                globalAntiPassback = true;
            }
            else
            {
                globalAntiPassback = false;
            }
        }

        void onTimeChanged(object sender, EventArgs e)
        {
            if (deleteTemporaryCardsTimer != null)
            {
                deleteTemporaryCardsTimer.Stop();
                deleteTemporaryCardsTimer.RunOnce(getMillisecondsToMidnight());
            }
        }

        private int getMillisecondsToMidnight()
        {
            DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
            DateTime midnight = new DateTime(now.Year, now.Month, now.Day, 0, 0, 0, 0).AddDays(1);
            return (int)(midnight - now).TotalMilliseconds;
        }

        private void onDeleteTemporaryCardsTimeout(object state)
        {
            if (deleteTemporaryCardsTimer == null)
                return;
            deleteTemporaryCardsTimer.Stop();
            if (cardManager != null)
            {
                var deletedCards = cardManager.DeleteTemporaryCards();
                if (deletedCards != null)
                {
                    foreach (var deletedCard in deletedCards)
                    {
                        triggerTemporaryCardDeleteEvent(deletedCard);
                    }
                }
            }
            deleteTemporaryCardsTimer.RunOnce(getMillisecondsToMidnight());
        }

        /// <summary>
        /// Eventhandler to update antipassback information for this cardholder and reader after the door has been opened
        /// </summary>
        /// <param name="sender">Door operation agent instance.</param>
        /// <param name="e">EventArgs instance that will contain the logical reader id and the cardholder id.</param>
        private void notify_UpdateAntipassbackInfo(object sender, OnUpdateAntipassbackEventArgs e)
        {
            if (sender == null)
                return;

            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(e.LogicalReaderId);
            if (readerConfig == null)
                return;

            try
            {
                GlobalAntiPassbackResult result;
                if (globalAntiPassback)
                    result = PeerToPeerConnectionManager.Instance.UpdateGlobalAntiPassback(e.CardInformation.AntipassbackId, readerConfig.EnterIntoPresenceZoneIds, readerConfig.ExitOutOfPresenceZoneIds);
                else
                    result = StatusManager.Instance.UpdateGlobalAntiPassback(e.CardInformation.AntipassbackId, readerConfig.EnterIntoPresenceZoneIds, readerConfig.ExitOutOfPresenceZoneIds);

                if (result == GlobalAntiPassbackResult.AccessGrantedSoftAntiPassback && AccessGrantedAntiPassbackEvent != null)
                    AccessGrantedAntiPassbackEvent(this, new CardAccessEventArgs(e.LogicalDoorId, e.LogicalReaderId, e.CardInformation));
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("Exception thrown in [CheckSoftAntipassback]: {0}", ex.ToString());
                });
            }
        }

        private void notify_ReaderKeypadInactivityTimeoutExpired(object sender, ReaderKeypadEventArgs e)
        {
            if (ReaderKeypadInactivityTimeoutExpired == null)
                return;
            ReaderKeypadInactivityTimeoutExpired(this, e);
        }

        private void notify_CardDownloadRequest(object sender, CardDownloadEventArgs e)
        {
            // If more than 100 cards are being deleted we will go ahead and delete all cards as
            // the memory requirements to queue thousands of deletes are prohibative.
            // Additionally the serial broadcast buffers are limited to 500 elements which could
            // result in cards not being deleted from degraded memory that should be.

            if (e.DeleteAllExistingCards)
            {
                DeleteAll();
            }
            else if (e.Cards.Count > 100)
            {
                queueBroadcastDeleteAllCards();

                // Set DeleteAllExistingCards to true so that individual card deletes are not sent
                e.DeleteAllExistingCards = true;
            }


            if (e.Cards == null || cardManager == null)
                return;

            if (cardManager.IsSDCardPresent && e.Cards.Count > 1)
            {
                if (e.DeleteAllExistingCards == false)
                {
                    foreach (Credential card in e.Cards)
                    {
                        // As the readers the user has access to may have changed, the safest option is to delete the user
                        // from all devices degraded memory and add it back as required.
                        DeleteCard(new CardNumberHolder(CommonUtilities.RationalizeRawCardNumber(card.CredentialData), card.CardBitLength), true, false);
                    }
                }

                cardManager.AddOrUpdateMultiple(e.Cards);
            }
            else
            {
                foreach (Credential card in e.Cards)
                {
                    byte[] cardNumber = CommonUtilities.RationalizeRawCardNumber(card.CredentialData);

                    CardInformation cardInformation = new CardInformation(card.Id, card.UserId, new CardNumberHolder(cardNumber, card.CardBitLength),
                            card.CardStatus.To8003CardStatus(), DateTime.UtcNow);

                    // As the readers the user has access to may have changed, the safest option is to delete the user
                    // from all devices degraded memory and add it back as required.
                    if (e.DeleteAllExistingCards == false)
                        DeleteCard(cardInformation.CardNumber, true, false);

                    cardManager.AddOrUpdate(cardInformation);
                }
            }
        }

        private void notify_CardDeleteRequest(object sender, CardDeleteEventArgs e)
        {
            CardNumberHolder cardToDelete = null;
            if (cardManager != null)
            {
                foreach (var cardId in e.CardIds)
                {
                    cardToDelete = cardManager.GetCardNumber(cardId);
                    if (cardToDelete != null)
                        DeleteCard(cardToDelete, false, (e.CardIds.Length == 1));       // We only send the card deleted event if we are only deleting 1 card so as not to overwhelm the head end. Otherwise we send a single configuration changed event.
                }
            }
        }

        #region Card Scanned, Pin Entered and Card Scanned and Pin Entered Event Handlers

        /// <summary>
        /// Process card scanned on the reader.
        /// </summary>
        public void ProcessLegacyCardData(int logicalReaderId, CardNumberHolder legacyCardFormat)
        {
            processLegacyCardAccess(logicalReaderId, legacyCardFormat, null);
        }

        /// <summary>
        /// Process card scanned on the reader.
        /// </summary>
        public void ProcessRawCardData(int logicalReaderId, byte[] cardData, int bitCount)
        {
            if (cardData.Length != 32)
            {
                // Cards scanned on the 8003 are already 32 bytes long but cards scanned on peripherals are likely in shorter arrays
                byte[] tempCardData = new byte[32];
                Buffer.BlockCopy(cardData, 0, tempCardData, 0, cardData.Length);
                cardData = tempCardData;
            }

            CardNumberHolder rawCardFormat = new CardNumberHolder(cardData, bitCount);
            processUnisonCardAccess(logicalReaderId, rawCardFormat, null);
        }

        /// <summary>
        /// Process pin entered on keypad attached to the reader.
        /// </summary>
        public void ProcessPinData(int logicalReaderId, byte[] keys)
        {
            // Check door configuration
            int logicalDoorId = ConfigurationManager.Instance.GetLogicalDoorId(logicalReaderId);
            Door8003Configuration doorConfig = null;
            if (logicalDoorId > 0)
            {
                doorConfig = ConfigurationManager.Instance.GetDoorConfiguration(logicalDoorId);
            }
            // Pass keys when reader in Card and Pin mode only
            Reader8003ScheduleLevel mode = StatusManager.Instance.Readers.GetReaderMode(logicalReaderId);
            if (mode == Reader8003ScheduleLevel.CardAndPin)
            {
                if (doorConfig != null && doorConfig.Enabled)
                    StatusManager.Instance.Doors[logicalDoorId].AccessPinReceived(logicalReaderId, keys);
                else
                    StatusManager.Instance.Readers[logicalReaderId].AccessPinReceived(keys);
            }
        }

        /// <summary>
        /// Degraded Mode Card Access Received processing
        /// </summary>
        public void ProcessDegradedModeLegacyCardAccessEvent(CardNumberHolder legacyCardFormat, int logicalReaderId, int logicalDoorId)
        {
            if (logicalDoorId < 1 || logicalReaderId < 1)
                return;

            if (legacyCardFormat.IsValid == false)
                return;

            if (CardAccessGrantedEvent != null)
                CardAccessGrantedEvent(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, legacyCardFormat));

        }

        public void ProcessDegradedModeRawCardAccessEvent(CardNumberHolder rawCardFormat, int logicalReaderId, int logicalDoorId)
        {
            if (logicalDoorId < 1 || logicalReaderId < 1)
                return;

            if (rawCardFormat.IsValid == false)
                return;

            if (CardAccessGrantedEvent != null)
                CardAccessGrantedEvent(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, rawCardFormat));

        }

        /// <summary>
        /// Triggered when device (at this moment local) has invalid card scanned.
        /// </summary>
        public void ProcessAccessDenied(int logicalReaderId)
        {
            int logicalDoorId = ConfigurationManager.Instance.GetLogicalDoorId(logicalReaderId);
            DoorStatus doorStatus = StatusManager.Instance.Doors[logicalDoorId];
            if (doorStatus != null)
            {
                doorStatus.AccessDenied(AccessDeniedReason.InvalidCard);
            }
            else
            {
                ReaderStatus readerStatus = StatusManager.Instance.Readers[logicalReaderId];
                if (readerStatus != null)
                    readerStatus.AccessDenied(AccessDeniedReason.InvalidCard);
            }
        }

        public void ProcessAccessDeniedUnauthorizedRawCardData(int logicalReaderId, byte[] cardData, int bitCount)
        {
            if (cardData.Length != 32)
            {
                // Cards scanned on the 8003 are already 32 bytes long but cards scanned on peripherals are likely in shorter arrays
                byte[] tempCardData = new byte[32];
                Buffer.BlockCopy(cardData, 0, tempCardData, 0, cardData.Length);
                cardData = tempCardData;
            }

            CardNumberHolder rawCardFormat = new CardNumberHolder(cardData, bitCount);
            int logicalDoorId = ConfigurationManager.Instance.GetLogicalDoorId(logicalReaderId);
            triggerAccessDeniedReaderInvalidEvent(rawCardFormat, logicalDoorId, logicalReaderId);
            
        }

        public void ProcessAccessDeniedUnauthorizedCard(int logicalReaderId, CardNumberHolder cardNumber)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
            {
                return string.Format("ReaderId={0} is [Blocked]!", logicalReaderId);
            });
            int logicalDoorId = ConfigurationManager.Instance.GetLogicalDoorId(logicalReaderId);
            triggerAccessDeniedReaderInvalidEvent(cardNumber, logicalDoorId, logicalReaderId);
        }

        private void notify_CardAndPinEntered(object sender, CardAndPinEnteredEventArgs e)
        {
            if (e.CardNumber.IsRawCardFormat)
                processUnisonCardAccess(e.LogicalReaderId, e.CardNumber, e.PinAsInteger);
            else
                processLegacyCardAccess(e.LogicalReaderId, e.CardNumber, e.PinAsInteger);
        }

        private void triggerAccessDeniedDoorInterlockedEvent(int logicalDoorId, int interlockId, int logicalReaderId, CardInformation cardInformation)
        {
            MacroControl.Instance.EnqueueInterlockEvent(interlockId, InterlockContextStatus.DeniedAccess, cardInformation.UserId, cardInformation.GroupId); // for macros

            if (AccessDeniedDoorInterlockedEvent != null && logicalReaderId != -1)
            {
                AccessDeniedDoorInterlockedEvent(this, new AccessDeniedDoorInterlockedEventArgs(logicalReaderId, logicalDoorId,
                                                                                                interlockId, cardInformation.CardNumber, cardInformation.UserId));
            }
        }

        private void triggerReaderLockoutEvent(int logicalReaderId, bool lockedOut)
        {
            if (ReaderLockoutEvent != null)
                ReaderLockoutEvent(this, new ReaderLockoutEventArgs(logicalReaderId, lockedOut));
        }

        private void triggerAccessDeniedInvalidPinEvent(int logicalReaderId, int logicalDoorId, IReaderConfiguration readerConfig, CardInformation cardInformation)
        {
            if (AccessDeniedInvalidReaderPinEvent != null)
            {
                int areaId = readerConfig != null ? readerConfig.AreaId : 0;
                int doorId = logicalDoorId == -1 ? 0 : logicalDoorId;
                AccessDeniedInvalidReaderPinEvent(this, new AccessDeniedInvalidReaderPinEventArgs(logicalReaderId, doorId, areaId, cardInformation));
            }
        }

        /// <summary>
        /// Triggered when a card is scanned as well as after a pin is entered on any device loop device or local device.
        /// </summary>
        /// <param name="logicalReaderId">Reader Logical Id</param>
        /// <param name="cardFormat">Card Format: Legacy / Raw</param>
        /// <param name="pinNumber"></param>
        private void processCardAccess(CardInformation cardInformation, int logicalReaderId, int logicalDoorId, DoorStatus doorStatus, int? pinNumber)
        {
            bool isDuressPin = checkDuressPin(cardInformation, pinNumber);
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
            ReaderStatus readerStatus = StatusManager.Instance.Readers[logicalReaderId];
            // Verify PIN
            if (pinNumber.HasValue)
            {
                if (cardInformation.UserPin != pinNumber && isDuressPin == false)
                {
                    clearMultiBadgeCount(readerConfig);
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
#if DEBUG
                        return string.Format("Pin # : {0}", pinNumber);
#else
                        return "Pin # : ****";
#endif
                    });

                    // Visually notify user the pin is invalid
                    if (doorStatus != null)
                        doorStatus.AccessDenied(AccessDeniedReason.InvalidPin);
                    else
                        readerStatus.AccessDenied(AccessDeniedReason.InvalidPin);

                    // Send invalid PIN event
                    triggerAccessDeniedInvalidPinEvent(logicalReaderId, logicalDoorId, readerConfig, cardInformation);
                    if (readerConfig.ReaderCategory != ReaderCategory.Normal)
                    {
                        triggerCardAccessDeniedInvalidMultiEntryEvent(logicalDoorId, logicalReaderId, cardInformation.CardNumber, cardInformation.UserId);
                        readerStatus.MultiBadgingStatus.Clear();
                    }

                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
                        return "Invalid pin. Invalid pin event has been sent to front-end.";
                    });

                    bool sendEvent = false;
                    readerStatus.SetLockedOut(out sendEvent);
                    if (readerStatus.LockedOut == true && sendEvent == true)
                    {
                        if (doorStatus != null)
                            doorStatus.AccessDenied(AccessDeniedReason.ReaderLockedOut);
                        else
                            readerStatus.AccessDenied(AccessDeniedReason.ReaderLockedOut);
                        readerStatus.CardStatusChange = CardStatus.Blocked;
                        triggerReaderLockoutEvent(logicalReaderId, true);
                        Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                        {
                            return string.Format("Reader [{0}] has been locked out. Lockout event sent to front-end.", logicalReaderId);
                        });
                    }
                    return;
                }
                readerStatus.LockedOutCounterReset();
            }

            // Validate double-badging rules for this reader
            int badgeCount = getMultiBadgeCount(readerConfig, cardInformation);
            switch (badgeCount)
            {
                case 1:
                    // Send single badge event to the macro engine for processing: parameters to send logicalReaderId, antipassbackId and groupId
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
                        return string.Format("Card single badge [{0}]", cardInformation.CardNumber.ToString());
                    });
                    MacroControl.Instance.EnqueueSingleBadgeEvent(readerConfig.Id, cardInformation.AntipassbackId, cardInformation.GroupId);
                    break;
                case 2:
                    // Send double badge event to the macro engine for processing: parameters to send logicalReaderId, antipassbackId and groupId
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
                        return string.Format("Card double badge [{0}]", cardInformation.CardNumber.ToString());
                    });
                    MacroControl.Instance.EnqueueDoubleBadgeEvent(readerConfig.Id, cardInformation.AntipassbackId, cardInformation.GroupId);
                    break;
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
                        return string.Format("Card {0} badge [{1}]", badgeCount.ToString(), cardInformation.CardNumber.ToString());
                    });
                    break;
                default:
                    break;
            }

            if (pinNumber.HasValue)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
#if DEBUG
                    return string.Format("Valid card scan [{0}] and pin [{1}]", cardInformation.CardNumber.ToString(), pinNumber);
#else
                    return string.Format("Valid card scan [{0}] and pin [****]", cardInformation.CardNumber.ToString());
#endif
                });
            }
            else
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return string.Format("Valid card scan [{0}]", cardInformation.CardNumber.ToString());
                });
            }

            forgiveCardHolder(ref readerConfig, cardInformation.AntipassbackId);

            if (readerConfig.ReaderCategory != ReaderCategory.Normal)
            {
                processMultiBadgingCards(doorStatus, readerStatus, logicalDoorId, logicalReaderId, cardInformation, isDuressPin);
            }
            else
            {
                // Finally, check interlocking
                int blockedByInterlockId;
                if (InterlockManager.Instance.CanOpenDoor(logicalDoorId, out blockedByInterlockId) == true)
                {
                    triggerCardAccessGranted(doorStatus, readerStatus, logicalDoorId, logicalReaderId, cardInformation, isDuressPin, null, ReaderBadgingType.Normal);
                }
                else
                {
                    // Interlock denied opening this door
                    if (doorStatus != null)
                        doorStatus.AccessDenied(AccessDeniedReason.DoorInterlocked);
                    else
                        readerStatus.AccessDenied(AccessDeniedReason.DoorInterlocked);

                    triggerAccessDeniedDoorInterlockedEvent(logicalDoorId, blockedByInterlockId, logicalReaderId, cardInformation);
                }
            }
        }

        private void triggerCardAccessGranted(DoorStatus doorStatus, ReaderStatus readerStatus, int logicalDoorId, int logicalReaderId, CardInformation cardInformation, bool isDuressPin, List<CardInformation> cardInformationList, ReaderBadgingType badgingType)
        {
            if (isDuressPin == false)
            {
                // Access the door
                triggerCardAccessGrantedEvent(cardInformation, logicalDoorId, logicalReaderId, badgingType);
            }
            else
            {
                // Access the door with duress
                triggerCardAccessGrantedDuressEvent(cardInformation, logicalDoorId, logicalReaderId, badgingType);
            }

            Reader8003ScheduleLevel readerMode = StatusManager.Instance.Readers.GetReaderMode(logicalReaderId);
            if (doorStatus != null)
            {
                doorStatus.AccessWithValidCard(cardInformation, logicalReaderId, readerMode, cardInformationList, badgingType);
                MacroControl.Instance.EnqueueDoorEvent(doorStatus.LogicalId, DoorContextStatus.AccessGranted);
            }
            else
                readerStatus.AccessWithValidCard(cardInformation, readerMode, cardInformationList, badgingType);
            readerStatus.CardStatusChange = CardStatus.Valid;

            cardManager.UpdateCardLastUsed(cardInformation);

            if (ConfigurationManager.Instance.IsUnisonMode)
            {
                var user = ConfigurationManager.Instance.Users[cardInformation.UserId] as UserUnisonConfiguration;
                if (user != null && user.UserFlags.Has(UserFlags.DelayAutomaticArming))
                {
                    var readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(readerStatus.LogicalId);
                    if (readerConfig != null && readerConfig.DelayAutomaticArming == true)
                    {
                        StatusManager.Instance.Areas.DelayAutomaticArm(readerConfig.AreaId);
                    }
                }
            }

            StatusManager.Instance.Elevators.TriggerValidCardAccess(logicalReaderId, logicalDoorId, cardInformation);      
        }

        private void processMultiBadgingCards(DoorStatus doorStatus, ReaderStatus readerStatus, int logicalDoorId, int logicalReaderId, CardInformation cardInformation, bool isDuressPin)
        {
            ReaderMultiBadgingStatus multiBadgingStatus = readerStatus.MultiBadgingStatus;
            if (multiBadgingStatus != null)
            {
                if (multiBadgingStatus.IsValidCard(cardInformation) == false)
                {
                    readerStatus.CardStatusChange = CardStatus.Invalid;
                    if (doorStatus != null)
                        doorStatus.AccessDenied(AccessDeniedReason.InvalidCard);
                    else
                        readerStatus.AccessDenied(AccessDeniedReason.InvalidCard);
                    triggerCardAccessDeniedInvalidMultiEntryEvent(logicalDoorId, logicalReaderId, cardInformation.CardNumber, cardInformation.UserId);
                }
                else
                {
                    if (multiBadgingStatus.IsStarted == false)
                    {
                        multiBadgingStatus.Start(cardInformation, () =>
                        // save the first valid card and trigger pending event
                        {
                            triggerCardAccessEntryPendingEvent(logicalDoorId, logicalReaderId, cardInformation);
                            if (doorStatus != null)
                                doorStatus.AccessWithValidCardPending();
                            else
                                readerStatus.AccessWithValidCardPending();
                        });
                    }
                    else
                    {
                        multiBadgingStatus.AddCard(cardInformation, () =>
                        //if card is valid and max count not reach, trigger pending event
                        {
                            triggerCardAccessEntryPendingEvent(logicalDoorId, logicalReaderId, cardInformation);
                            if (doorStatus != null)
                                doorStatus.AccessWithValidCardPending();
                            else
                                readerStatus.AccessWithValidCardPending();
                        }, (List<CardInformation> cardInformationList) =>
                           {
		                       // If card is valid and max count reached, check interlocking then trigger access granted event
                               // Finally, check interlocking
                               int blockedByInterlockId;
                               if (InterlockManager.Instance.CanOpenDoor(logicalDoorId, out blockedByInterlockId) == true)
                               {
                                   triggerCardAccessGranted(doorStatus, readerStatus, logicalDoorId, logicalReaderId, cardInformation, isDuressPin, cardInformationList, multiBadgingStatus.BadgingType);
                               }
                               else
                               {
                                   // Interlock denied opening this door
                                   if (doorStatus != null)
                                       doorStatus.AccessDenied(AccessDeniedReason.DoorInterlocked);
                                   else
                                       readerStatus.AccessDenied(AccessDeniedReason.DoorInterlocked);

                                   triggerAccessDeniedDoorInterlockedEvent(logicalDoorId, blockedByInterlockId, logicalReaderId, cardInformation);
                               }
                           }, () =>
                        //if card is invalid, trigger access denied event
                        {
                            readerStatus.CardStatusChange = CardStatus.Invalid;
                            if (doorStatus != null)
                                doorStatus.AccessDenied(AccessDeniedReason.InvalidCard);
                            else
                                readerStatus.AccessDenied(AccessDeniedReason.InvalidCard);
                            triggerCardAccessDeniedInvalidMultiEntryEvent(logicalDoorId, logicalReaderId, cardInformation.CardNumber, cardInformation.UserId);
                        });
                    }
                }
            }
        }

        private void forgiveCardHolder(ref IReaderConfiguration readerConfig, long antipassbackId)
        {
            // Handle clear anipassback memory on other readers
            if (readerConfig.ClearPassbackMemoryOnOtherReaders == true)
            {
                if (globalAntiPassback)
                    PeerToPeerConnectionManager.Instance.ForgiveCardHolder(antipassbackId);
                else
                    StatusManager.Instance.ForgiveCardHolder(antipassbackId);
            }
        }

        /// <summary>
        /// Send access denied because card reader is blocked
        /// </summary>
        /// <param name="cardNumber">Card number</param>
        /// <param name="logicalDoorId">Door logical id.</param>
        /// <param name="logicalReaderId">Reader logical id.</param>
        private void triggerAccessDeniedReaderBlockedEvent(CardNumberHolder cardNumber, int logicalDoorId, int logicalReaderId)
        {
            if (AccessDeniedReaderBlockedEvent == null)
                return;

            AccessDeniedReaderBlockedEvent(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, cardNumber));
        }

        /// <summary>
        /// Send card not programmed event.
        /// </summary>
        /// <param name="cardNumber">Card number</param>
        /// <param name="logicalDoorId">Logical id of the door that will be opened.</param>
        /// <param name="logicalReaderId">Logical id of the reader on which the card was badged.</param>
        private void triggerCardNotProgrammedEvent(CardNumberHolder cardNumber, int logicalDoorId, int logicalReaderId)
        {
            if (CardNotProgrammedEvent == null)
                return;

            CardNotProgrammedEvent(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, cardNumber));
        }

        /// <summary>
        /// Send card access granted and door opened event.
        /// </summary>
        /// <param name="cardInformation">Card information</param>
        /// <param name="logicalDoorId">Logical id of the door that will be opened.</param>
        /// <param name="logicalReaderId">Logical id of the reader on which the card was badged.</param>
        private void triggerCardAccessGrantedEvent(CardInformation cardInformation, int logicalDoorId, int logicalReaderId, ReaderBadgingType badgingType)
        {
            if (CardAccessGrantedEvent != null)
                CardAccessGrantedEvent(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, cardInformation, badgingType));

            // Remove the area from duress mode
            IReaderConfiguration readerConfiguration = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
            if (readerConfiguration != null)
            {
                AreaStatus areaStatus = StatusManager.Instance.Areas[readerConfiguration.AreaId];
                if (areaStatus != null)
                    areaStatus.SetDuress(false);
            }
        }

        private void triggerCardAccessEntryPendingEvent(int logicalDoorId, int logicalReaderId, CardInformation cardInformation)
        {
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
            if (readerConfig != null && readerConfig.Enabled == true)
            {
                if (readerConfig.ReaderCategory == ReaderCategory.DualEntry && DualEntryPendingEvent != null)
                    DualEntryPendingEvent(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, cardInformation.CardNumber, cardInformation.UserId));
                else if (readerConfig.ReaderCategory == ReaderCategory.TripleEntry && TripleEntryPendingEvent != null)
                    TripleEntryPendingEvent(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, cardInformation.CardNumber, cardInformation.UserId));
            }
        }

        private void triggerCardAccessDeniedInvalidMultiEntryEvent(int logicalDoorId, int logicalReaderId, CardNumberHolder cardNumber, int userId)
        {
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
            if (readerConfig != null && readerConfig.Enabled == true)
            {
                if (readerConfig.ReaderCategory == ReaderCategory.DualEntry && AccessDeniedInvalidDualEntryEvent != null)
                    AccessDeniedInvalidDualEntryEvent(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, cardNumber, userId));
                else if (readerConfig.ReaderCategory == ReaderCategory.TripleEntry && AccessDeniedInvalidTripleEntryEvent != null)
                    AccessDeniedInvalidTripleEntryEvent(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, cardNumber, userId));
            }
        }

        /// <summary>
        /// Send card access granted and door opened event.
        /// </summary>
        /// <param name="cardInformation">Card information</param>
        /// <param name="logicalDoorId">Logical id of the door that will be opened.</param>
        /// <param name="logicalReaderId">Logical id of the reader on which the card was badged.</param>
        private void triggerCardAccessGrantedDuressEvent(CardInformation cardInformation, int logicalDoorId, int logicalReaderId, ReaderBadgingType badgingType)
        {
            if (CardAccessGrantedDuressEvent == null)
                return;

            CardAccessGrantedDuressEvent(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, cardInformation, badgingType));

            // Place the area into duress mode
            IReaderConfiguration readerConfiguration = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
            if (readerConfiguration != null)
            {
                AreaStatus areaStatus = StatusManager.Instance.Areas[readerConfiguration.AreaId];
                if (areaStatus != null)
                    areaStatus.SetDuress(true);
            }
        }

        private void triggerAccessDeniedReaderInvalidEvent(CardNumberHolder cardNumber, int logicalDoorId, int logicalReaderId)
        {
            if (AccessDeniedReaderInvalidEvent == null)
                return;

            CardInformation cardInformation;
            AccessControlManager.Instance.GetCardInformation(cardNumber, out cardInformation);
            CardAccessEventArgs accessEvent = cardInformation != null ?
                new CardAccessEventArgs(logicalDoorId, logicalReaderId, cardInformation) :
                new CardAccessEventArgs(logicalDoorId, logicalReaderId, cardNumber);
            AccessDeniedReaderInvalidEvent(this, accessEvent);
        }

        /// <summary>
        /// Check the card scanned
        /// </summary>
        /// <param name="cardInformation">Card data</param>
        /// <param name="readerConfig">Card reader configuration</param>
        /// <param name="logicalDoorId">Door logical id.</param>
        /// <param name="isDuressPin">The user used a duress pin</param>
        /// <returns>True if the the card access will be allowed, False otherwise</returns>
        private bool checkCardScanned(CardInformation cardInformation, IReaderConfiguration readerConfig, int logicalDoorId, bool isDuressPin, ref CardStatus cardStatus)
        {
            if (cardInformation.Blocked == true)
            {
                // Send Card Blocked event
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return "Card is [Blocked]!";
                });
                if (AccessDeniedCardBlockedEvent != null)
                {
                    AccessDeniedCardBlockedEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                }
                cardStatus = CardStatus.Blocked;
                return false;
            }

            if (cardInformation.Expired == true)
            {
                // Send Card Expired event
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return "Card is [Expired]!";
                });
                if (AccessDeniedCardExpiredEvent != null)
                {
                    AccessDeniedCardExpiredEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                }
                cardStatus = CardStatus.Expired;
                return false;
            }

            if (cardInformation.IsRawCardFormat == true)
            {
                CardStatusType cardStatusType = cardInformation.CardStatus.ToUnisonCardStatus();
                if (cardStatusType != CardStatusType.Valid)
                {
                    // Send Card Not Valid event, either Cancelled or Lost
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
                        return string.Format("Card is [{0}]!", cardStatusType.ToString());
                    });
                    if (cardStatusType == CardStatusType.Lost && AccessDeniedCardLostEvent != null)
                    {
                        AccessDeniedCardLostEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                        cardStatus = CardStatus.Lost;
                    }
                    else if (cardStatusType == CardStatusType.Canceled && AccessDeniedCardCancelledEvent != null)
                    {
                        AccessDeniedCardCancelledEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                        cardStatus = CardStatus.Cancelled;
                    }
                    return false;
                }

                // Validate Card against the User Access Groups for the reader on which the user has badged
                UserUnisonConfiguration user = ConfigurationManager.Instance.Users[cardInformation.UserId] as UserUnisonConfiguration;
                if (user == null)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
                        return string.Format("No valid user found for Card#: {0}!", cardInformation.CardId);
                    });
                    if (AccessDeniedUserInvalidEvent != null)
                        AccessDeniedUserInvalidEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                    return false;
                }

                // Check the User has Access to readerId / scheduleId at the time of badging the card
                AccessPermissionResult accessPermissionResult = user.HasAccessPermission(readerConfig.Id, isDuressPin);
                if (accessPermissionResult != AccessPermissionResult.Valid)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
                        return string.Format("User does not have access permissions for Reader: {0}!", readerConfig.Id);
                    });
                    if (accessPermissionResult == AccessPermissionResult.InvalidReader && AccessDeniedReaderInvalidEvent != null)
                        AccessDeniedReaderInvalidEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                    else if (accessPermissionResult == AccessPermissionResult.InvalidSchedule && AccessDeniedScheduleInvalidEvent != null)
                        AccessDeniedScheduleInvalidEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                    else if (accessPermissionResult == AccessPermissionResult.InvalidUser && AccessDeniedUserInvalidEvent != null)
                        AccessDeniedUserInvalidEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                    else if (accessPermissionResult == AccessPermissionResult.Expired && AccessDeniedCardExpiredEvent != null)
                    {
                        cardStatus = CardStatus.Expired;
                        AccessDeniedCardExpiredEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                    }

                    return false;
                }
            }
            else
            {
                int scheduleId = -1;
                try
                {
                    scheduleId = cardInformation.GetSchedule(readerConfig.Id);
                    if (scheduleId <= 0)
                    {
                        // Send access denied event - security level error
                        Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                        {
                            return string.Format("No access schedule exists for readerId={0}!", readerConfig.Id);
                        });
                        if (AccessDeniedReaderInvalidEvent != null)
                            AccessDeniedReaderInvalidEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                        return false;
                    }
                }
                catch (ArgumentException ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return ex.ToString();
                    });
                    return false;
                }

                Pacom8003AccessSchedule accessSchedule = ConfigurationManager.Instance.GetAccessSchedule(scheduleId);
                if (accessSchedule == null)
                {
                    // Send access denied event - security level error
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
                        return string.Format("No access schedule exists for scheduleId={0}!", scheduleId);
                    });
                    if (AccessDeniedScheduleInvalidEvent != null)
                    {
                        AccessDeniedScheduleInvalidEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                    }
                    return false;
                }

                // Do not check the access schedule if the user used a duress pin
                if (isDuressPin == false)
                {
                    if (accessSchedule.Enabled == false)
                    {
                        // Send access denied event - security level error
                        Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                        {
                            return string.Format("Access Denied for access schedule {0}!", accessSchedule.Id);
                        });
                        if (AccessDeniedScheduleInvalidEvent != null)
                        {
                            AccessDeniedScheduleInvalidEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                        }
                        return false;
                    }
                }
            }

            // Validate anti-passback rules
            if (checkAntipassback(readerConfig, cardInformation, logicalDoorId) == false)
            {
                // Send failed anti-passback rules
                return false;
            }

            return true;
        }

        /// <summary>
        /// Check if double badging occurred
        /// </summary>
        /// <param name="readerConfig">Card reader configuration</param>
        /// <param name="antipassbackId">Card holder id</param>
        /// <returns>True if double badging occurred for this card / user, False otherwise</returns>
        private int getMultiBadgeCount(IReaderConfiguration readerConfig, CardInformation cardInformation)
        {
            CardReaderMultipleBadgeHolder multiBadgeHolder = null;
            if (cardReaderMultiBadgeList.TryGetValue(readerConfig.Id, out multiBadgeHolder) == false)
            {
                // Add new card double badge holder because none was found for readerConfig.Id
                multiBadgeHolder = new CardReaderMultipleBadgeHolder();
                cardReaderMultiBadgeList[readerConfig.Id] = multiBadgeHolder;
            }
            if (multiBadgeHolder != null)
                return multiBadgeHolder.CheckMultiBadge(cardInformation.AntipassbackId);
            else
                return 0;
        }

        /// <summary>
        /// Clear double badging memory on an invalid card scan
        /// </summary>
        /// <param name="readerConfig">Card reader configuration</param>
        private void clearMultiBadgeCount(IReaderConfiguration readerConfig)
        {
            CardReaderMultipleBadgeHolder multiBadgeHolder = null;
            if (cardReaderMultiBadgeList.TryGetValue(readerConfig.Id, out multiBadgeHolder) == true)
            {
                multiBadgeHolder.Clear();
            }
        }

        /// <summary>
        /// Try to enter / exit presence zone, validate anti-passback rules for this reader and card / user.
        /// </summary>
        /// <param name="readerConfig">Card Reader configuration</param>
        /// <param name="cardInformation">Card information to verify</param>
        /// <param name="logicalDoorId">Door logical id.</param>
        /// <returns>True if the card holder can enter the presence zone, False otherwise</returns>
        private bool checkAntipassback(IReaderConfiguration readerConfig, CardInformation cardInformation, int logicalDoorId)
        {
            if (readerConfig.EnterIntoPresenceZones != null && readerConfig.EnterIntoPresenceZones.Length > 0)
            {
                GlobalAntiPassbackResult result;
                if (globalAntiPassback)
                    result = PeerToPeerConnectionManager.Instance.CheckGlobalAntiPassback(cardInformation.AntipassbackId, readerConfig.EnterIntoPresenceZoneIds);
                else
                    result = StatusManager.Instance.CheckGlobalAntiPassback(cardInformation.AntipassbackId, readerConfig.EnterIntoPresenceZoneIds);

                // Allow access if access is allowed or communications with the master was unsuccessful.
                if (result == GlobalAntiPassbackResult.AccessDenied)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
                        return string.Format("Antipassback check failed. User already in presence zone. Exit the presence zone before re-entering!");
                    });
                    if (AccessDeniedAntiPassbackEvent != null)
                    {
                        AccessDeniedAntiPassbackEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                    }
                    return false;
                }
            }
            return true;
        }

        #endregion

        #region Egress, Contact & Strike Status Changed Event Handlers

        /// <summary>
        /// Triggered when the egress button status has changed
        /// </summary>
        /// <param name="sender">SingleDoorControllerDeviceStatus instance</param>
        /// <param name="e">Door input status information</param>
        private void notify_EgressStatusChanged(object sender, DoorInputChangedStatusEventArgs e)
        {
            if (e.ChangedDoorInput != ChangedDoorControllerInput.Egress)
                return;
            if (e.Status != Common.InputStatus.Alarm)
                return;
            if (e.LogicalDoorId <= 0)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return string.Format("Egress button pressed on a device not attached to a door!");
                });
                return;
            }

            DoorStatus doorStatus = StatusManager.Instance.Doors[e.LogicalDoorId];
            if (doorStatus != null)
            {
                if (doorStatus.Enabled == false)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
                        return string.Format("DoorId={0} is [Disabled]!", e.LogicalDoorId);
                    });
                    return;
                }
                if (doorStatus.IsUnlocked == true)
                {
                    // Door is unlocked - no need to do anything else, just return
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
                        return string.Format("DoorId={0} is [Unlocked]!", e.LogicalDoorId);
                    });
                    return;
                }
            }

            DoorConfiguration doorConfig = ConfigurationManager.Instance.GetDoorConfiguration(e.LogicalDoorId);
            if (doorConfig == null)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return string.Format("DoorId={0} is [Disabled]!", e.LogicalDoorId);
                });
                return;
            }

            ReaderStatus readerStatus = StatusManager.Instance.Readers[doorConfig.ReaderInId];
            if (readerStatus == null || readerStatus.Enabled == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return string.Format("ReaderId={0} is [Disabled]!", doorConfig.ReaderInId);
                });
                return;
            }

            Reader8003ScheduleLevel readerMode = StatusManager.Instance.Readers.GetReaderMode(doorConfig.ReaderInId);
            // Check if the reader is Blocked and the EgressWhenBlocked is false then disallow the door open command.
            if (readerMode == Reader8003ScheduleLevel.Blocked && doorConfig.EgressWhenBlocked == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return string.Format("ReaderId={0} is [{1}] and egress when reader blocked is not allowed!", doorConfig.ReaderInId, readerMode);
                });
                if (AccessDeniedEgressScheduleEvent != null)
                    AccessDeniedEgressEvent(this, new DoorEventArgs(e.LogicalDoorId));
                return;
            }

            // Check if current time falls inside the permitted Egress schedule.
            if (doorConfig.EgressEnabled == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return string.Format("Egress is not enabled for ReaderId={0}!", doorConfig.ReaderInId);
                });
                if (AccessDeniedEgressScheduleEvent != null)
                    AccessDeniedEgressScheduleEvent(this, new DoorEventArgs(e.LogicalDoorId));
                return;
            }

            // Just before opening the door, check interlocking
            int blockedByInterlockId;
            if (InterlockManager.Instance.CanOpenDoor(doorConfig.Id, out blockedByInterlockId) == false)
            {
                if (AccessDeniedEgressInterlockedEvent != null)
                    AccessDeniedEgressInterlockedEvent(this, new AccessDeniedEgressInterlockedEventArgs(doorConfig.ReaderInId, e.LogicalDoorId, blockedByInterlockId));
                return;
            }

            if (AccessGrantedEgressEvent != null)
                AccessGrantedEgressEvent(this, new DoorEventArgs(e.LogicalDoorId));

            doorStatus.AccessWithEgress();
        }

        /// <summary>
        /// Triggered when the door contact status has changed
        /// </summary>
        /// <param name="sender">SingleDoorControllerDeviceStatus instance</param>
        /// <param name="e">Door input status information</param>
        private void notify_ContactStatusChanged(object sender, DoorInputChangedStatusEventArgs e)
        {
            if (e.ChangedDoorInput != ChangedDoorControllerInput.DoorContact)
                return;
        }

        /// <summary>
        /// Triggered when the strike status has changed
        /// </summary>
        /// <param name="sender">SingleDoorControllerDeviceStatus instance</param>
        /// <param name="e">Door input status information</param>
        private void notify_StrikeStatusChanged(object sender, DoorInputChangedStatusEventArgs e)
        {
            if (e.ChangedDoorInput != ChangedDoorControllerInput.Strike)
                return;
        }

        #endregion

        /// <summary>
        /// Adds if not present or updates if present a card in the memory or database
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public bool AddOrUpdateCardInformation(CardInformation cardInformation)
        {
            if (cardManager == null)
                return false;

            // As the readers the user has access to may have changed, the safest option is to delete the user
            // from all devices degraded memory and add it back as required.
            DeleteCard(cardInformation.CardNumber, true, false);
            return cardManager.AddOrUpdate(cardInformation);
        }

        /// <summary>
        /// Get existing card from the Sram or Sdcard
        /// </summary>
        public bool GetCardInformation(CardNumberHolder cardNumber, out CardInformation cardInformation)
        {
            cardInformation = null;
            if (cardManager != null)
            {
                cardInformation = cardManager.Get(cardNumber);
                return cardInformation != null;
            }
            else
                return false;
        }

        /// <summary>
        /// Get existing card from the Sram or Sdcard.
        /// </summary>
        /// <returns>True if the card information was found, False otherwise.</returns>
        public bool GetUnisonCardInformationForSpecificReader(CardNumberHolder cardNumber, int readerId, out CardInformation cardInformation)
        {
            cardInformation = null;
            if (cardManager != null)
            {
                cardInformation = cardManager.GetUnisonCardInformationForSpecificReader(cardNumber, readerId);
                if (cardInformation != null)
                {
                    IUserConfiguration user = ConfigurationManager.Instance.Users[cardInformation.UserId];
                    if (user != null)
                    {
                        cardInformation.GroupId = user.GroupId;
                        cardInformation.UserPin = user.UserPin;
                    }
                }
                return cardInformation != null;
            }
            else
                return false;
        }

        public bool GetLegacyCardInformationListForSpecificReader(CardNumberHolder cardNumber, int readerId, out List<CardInformation> cardInformationList)
        {
            cardInformationList = null;
            if (cardManager != null)
            {
                cardInformationList = cardManager.GetLegacyCardInformationListForSpecificReader(cardNumber, readerId);
                return cardInformationList != null && cardInformationList.Count > 0;
            }
            else
                return false;
        }

        /// <summary>
        /// Get existing card from the Sram or Sdcard
        /// </summary>
        public bool GetLegacyCardInformationList(CardNumberHolder cardNumber, out List<CardInformation> cardInformationList)
        {
            cardInformationList = null;
            if (cardManager != null)
            {
                cardInformationList = cardManager.GetLegacyCardInformationList(cardNumber);
                return cardInformationList != null && cardInformationList.Count > 0;
            }
            else
                return false;
        }
        /// <summary>
        /// Delete card by card number
        /// </summary>
        public void DeleteCard(CardNumberHolder cardNumber, bool peripheralsOnly, bool sendEvent)
        {
            if (cardManager == null)
                return;

            if (CardNumberBroadcastEvent != null)
                CardNumberBroadcastEvent(this, new DeleteCardBroadcastEventArgs(cardNumber));

            if (peripheralsOnly)
                return;

            cardManager.Delete(cardNumber);
            if (sendEvent)
                triggerCardDeleteEvent(cardNumber);
        }
        public void DownloadCard(CardNumberHolder cardNumber)
        {
            if (cardManager != null)
            {
                triggerCardDownloadEvent(cardNumber);
            }
        }


        private const int deleteAllBroadcastDueTime = 5 * 60 * 1000;

        /// <summary>
        /// Delete all cards from memory or database
        /// </summary>
        public void DeleteAll()
        {
            if (cardManager != null)
            {
                cardManager.DeleteAllCardsLocally();
                queueBroadcastDeleteAllCards();
            }
        }

        private readonly object broadcastDeleteAllCardsLock = new object();
        private void queueBroadcastDeleteAllCards()
        {
            lock (broadcastDeleteAllCardsLock)
            {
                if (broadcastDeleteAllCardsTimer == null)
                    broadcastDeleteAllCardsTimer = TimerManager.Instance.CreateTimer(broadcastDeleteAllTimerProc, null, deleteAllBroadcastDueTime, Timeout.Infinite);
            }
        }

        private void broadcastDeleteAllTimerProc(object state)
        {
            lock (broadcastDeleteAllCardsLock)
            {
                try
                {
                    if (CardNumberBroadcastEvent != null)
                    {
                        CardNumberBroadcastEvent(this, new DeleteCardBroadcastEventArgs(null));
                    }
                }
                catch
                {
                }
                TimerManager.Instance.RemoveTimer(broadcastDeleteAllCardsTimer);               
                broadcastDeleteAllCardsTimer = null;
            }
        }

        /// <summary>
        /// Return number of cards currently in storage
        /// </summary>
        /// <returns></returns>
        public int CountCards()
        {
            if (cardManager != null)
                return cardManager.Count;
            else
                return 0;
        }

        /// <summary>
        /// Return all card hashes in one list.
        /// </summary>
        /// <returns></returns>
        public List<long> CardHashes()
        {
            if (cardManager != null)
                return cardManager.CardHashes();
            else
                return new List<long>();
        }

#if DEBUG
        public List<UniqueCardHolderId> GetUniqueCardHolderIDs()
        {
            return cardManager != null ? cardManager.GetUniqueCardHolderIDs() : null;
        }
        public CardInformation GetCardInformation(UniqueCardHolderId cardHoder)
        {
            return cardManager != null ? cardManager.GetCardInformation(cardHoder) : null;
        }
        public bool UpdateElevatorFloorsAccess(CardInformation cardInformation)
        {
            return cardManager != null ? cardManager.UpdateElevatorFloorsAccess(cardInformation) : false;
        }
#endif
        /// <summary>
        /// Trigger an event on forced card removal. There was no more space in memory for card just added.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cardManager_LeastUsedCardDeletedEvent(object sender, LeastUsedCardDeletedEventArgs e)
        {
            triggerCardDeleteEvent(e.CardNumber);
        }

        /// <summary>
        /// Construct event and put it on the event queue.
        /// </summary>
        /// <param name="antipassbackId"></param>
        private void triggerCardDeleteEvent(CardNumberHolder cardNumber)
        {
            if (CardDeletedEvent != null)
            {
                CardDeletedEvent(this, new CardAccessEventArgs(-1, -1, cardNumber));
            }
        }

        private void triggerTemporaryCardDeleteEvent(CardNumberHolder cardNumber)
        {
            if (TemporaryCardDeletedEvent != null)
            {
                TemporaryCardDeletedEvent(this, new CardAccessEventArgs(-1, -1, cardNumber));
            }
        }

        private void triggerCardDownloadEvent(CardNumberHolder cardNumber)
        {
            if (CardDownloadedEvent != null)
            {
                CardDownloadedEvent(this, new CardAccessEventArgs(-1, -1, cardNumber));
            }
        }

        private bool getDoorStatus(int logicalReaderId, CardNumberHolder cardNumber, int? pinNumber, out DoorStatus doorStatus)
        {
            doorStatus = null;
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
            ReaderStatus readerStatus = StatusManager.Instance.Readers[logicalReaderId];
            if (readerConfig == null || readerStatus == null || readerConfig.Enabled == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return string.Format("ReaderId={0} is [DISABLED]!", logicalReaderId);
                });
                return false;
            }

            int logicalDoorId = ConfigurationManager.Instance.GetLogicalDoorId(logicalReaderId);
            if (logicalDoorId >= 1)
            {
                doorStatus = StatusManager.Instance.Doors[logicalDoorId];
                if (doorStatus == null || doorStatus.Enabled == false)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                    {
                        return string.Format("DoorId={0} is [DISABLED]!", logicalDoorId);
                    });
                    logicalDoorId = 0;
                    doorStatus = null;
                }
            }

            Reader8003ScheduleLevel readerMode = StatusManager.Instance.Readers.GetReaderMode(logicalReaderId);
            if (readerMode == Reader8003ScheduleLevel.Blocked)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return string.Format("ReaderId={0} is [Blocked]!", logicalReaderId);
                });
                triggerAccessDeniedReaderBlockedEvent(cardNumber, logicalDoorId, logicalReaderId);
                if (doorStatus != null)
                {
                    doorStatus.AccessDeniedReason = AccessDeniedReason.ReaderLockedOut;
                }
                readerStatus.CardStatusChange = CardStatus.Blocked;
                return false;
            }
            else if (pinNumber.HasValue == false && (readerMode == Reader8003ScheduleLevel.CardAndPin))
            {
                if (doorStatus != null)
                {
                    if (readerStatus.LockedOut == true)
                        doorStatus.AccessDenied(AccessDeniedReason.ReaderLockedOut);
                    else
                        doorStatus.AccessWaitForPin(cardNumber, logicalReaderId, readerMode);
                }
                else
                {
                    if (readerStatus.LockedOut == true)
                        readerStatus.AccessDenied(AccessDeniedReason.ReaderLockedOut);
                    else
                        readerStatus.AccessWaitForPin(cardNumber, readerMode);
                }
                return false;
            }
            else if (readerMode == Reader8003ScheduleLevel.Unlocked)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return string.Format("ReaderId={0} is [Unlocked]!", logicalReaderId);
                });
                return false;
            }

            if (logicalReaderId < 1)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return string.Format("Invalid reader id {0}", logicalReaderId);
                });
            }

            if (logicalDoorId < 1)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
                {
                    return string.Format("Card scanned on reader not attached to a door!");
                });
            }
            return true;
        }

        private void processCardNotFound(int logicalReaderId, CardNumberHolder cardNumber, DoorStatus doorStatus, ReaderStatus readerStatus)
        {
            var readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
            clearMultiBadgeCount(readerConfig);
            if (doorStatus != null)
                doorStatus.AccessDenied(AccessDeniedReason.InvalidCard);
            else
                readerStatus.AccessDenied(AccessDeniedReason.InvalidCard);
            readerStatus.CardStatusChange = CardStatus.Invalid;

            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () =>
            {
                return string.Format("Card not found in database: {0}", cardNumber.ToString());
            });

            int doorId = ConfigurationManager.Instance.GetLogicalDoorId(logicalReaderId);
            triggerCardNotProgrammedEvent(cardNumber, doorId, logicalReaderId);
            if (readerConfig.ReaderCategory != ReaderCategory.Normal)
            {
                triggerCardAccessDeniedInvalidMultiEntryEvent(doorId, logicalReaderId, cardNumber, -1);
                readerStatus.MultiBadgingStatus.Clear();
            }
        }

        private void processLegacyCardAccess(int logicalReaderId, CardNumberHolder cardNumber, int? pinNumber)
        {
            DoorStatus doorStatus = null;
            if (getDoorStatus(logicalReaderId, cardNumber, pinNumber, out doorStatus) == false)
                return;
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
            ReaderStatus readerStatus = StatusManager.Instance.Readers[logicalReaderId];
            legacyCardAccessStatus userAccessStatus = legacyCardAccessStatus.Success;
            int logicalDoorId = ConfigurationManager.Instance.GetLogicalDoorId(logicalReaderId);
            bool saveUserAccessStatus = false;
            List<CardInformation> cardInformationList;
            if (GetLegacyCardInformationListForSpecificReader(cardNumber, logicalReaderId, out cardInformationList) == true)
            {
                foreach (var cardInformation in cardInformationList)
                {
                    bool isDuressPin = checkDuressPin(cardInformation, pinNumber);
                    var checkUserAccess = getLegacyCardAccessStatus(cardInformation, readerConfig, logicalDoorId, isDuressPin);
                    if (checkUserAccess == legacyCardAccessStatus.Success)
                    {
                        processCardAccess(cardInformation, logicalReaderId, logicalDoorId, doorStatus, pinNumber);
                        return;
                    }
                    else if (saveUserAccessStatus == false)
                    {
                        saveUserAccessStatus = true;
                        userAccessStatus = checkUserAccess;
                    }
                }

                // Card is expired/blocked
                processLegacyCardDenyStatus(cardInformationList[0], readerConfig, logicalDoorId, userAccessStatus, readerStatus);
                clearMultiBadgeCount(readerConfig);
                if (doorStatus != null)
                    doorStatus.AccessDenied(AccessDeniedReason.CardExpiredOrBlocked);
                else
                    readerStatus.AccessDenied(AccessDeniedReason.CardExpiredOrBlocked);
            }
            else
            {
                processCardNotFound(logicalReaderId, cardNumber, doorStatus, readerStatus);
            }
        }

        private void processUnisonCardAccessDenied(ReaderStatus readerStatus, CardStatus cardStatus, Action<AccessDeniedReason> accessDeniedAction)
        {
            switch (cardStatus)
            {
                case CardStatus.Blocked:
                    readerStatus.CardStatusChange = CardStatus.Blocked;
                    accessDeniedAction(AccessDeniedReason.CardExpiredOrBlocked);
                    break;
                case CardStatus.Expired:
                    readerStatus.CardStatusChange = CardStatus.Expired;
                    accessDeniedAction(AccessDeniedReason.CardExpiredOrBlocked);
                    break;
                case CardStatus.Cancelled:
                    readerStatus.CardStatusChange = CardStatus.Cancelled;
                    accessDeniedAction(AccessDeniedReason.InvalidUser);
                    break;
                case CardStatus.Lost:
                    readerStatus.CardStatusChange = CardStatus.Lost;
                    accessDeniedAction(AccessDeniedReason.InvalidUser);
                    break;
                case CardStatus.Invalid:
                    readerStatus.CardStatusChange = CardStatus.Invalid;
                    accessDeniedAction(AccessDeniedReason.InvalidUser);
                    break;
            }
        }

        private void processUnisonCardAccess(int logicalReaderId, CardNumberHolder cardNumber, int? pinNumber)
        {
            DoorStatus doorStatus = null;
            if (getDoorStatus(logicalReaderId, cardNumber, pinNumber, out doorStatus) == false)
                return;
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
            ReaderStatus readerStatus = StatusManager.Instance.Readers[logicalReaderId];
            int logicalDoorId = ConfigurationManager.Instance.GetLogicalDoorId(logicalReaderId);
            CardInformation cardInformation = null;
            if (GetUnisonCardInformationForSpecificReader(cardNumber, logicalReaderId, out cardInformation) == true)
            {
                bool isDuressPin = checkDuressPin(cardInformation, pinNumber);
                CardStatus cardStatus = CardStatus.Invalid;
                bool checkUserAccess = checkCardScanned(cardInformation, readerConfig, logicalDoorId, isDuressPin, ref cardStatus);
                if (checkUserAccess == false)
                {
                    clearMultiBadgeCount(readerConfig);
                    if (doorStatus != null)
                        processUnisonCardAccessDenied(readerStatus, cardStatus, doorStatus.AccessDenied);
                    else
                        processUnisonCardAccessDenied(readerStatus, cardStatus, readerStatus.AccessDenied);

                    if (readerConfig.ReaderCategory != ReaderCategory.Normal)
                    {
                        triggerCardAccessDeniedInvalidMultiEntryEvent(logicalDoorId, logicalReaderId, cardNumber, -1);
                        readerStatus.MultiBadgingStatus.Clear();
                    }
                    return;
                }
                processCardAccess(cardInformation, logicalReaderId, logicalDoorId, doorStatus, pinNumber);
                return;
            }
            else
            {
                processCardNotFound(logicalReaderId, cardNumber, doorStatus, readerStatus);
            }
        }

        private bool checkDuressPin(CardInformation cardInformation, int? pinNumber)
        {
            int groupId = cardInformation.GroupId;
            int userPin = cardInformation.UserPin;
            return
                pinNumber.HasValue == true &&
                userPin != pinNumber &&
                userPin.CheckDuressPin(pinNumber.Value, ConfigurationManager.Instance.ControllerConfiguration.DuressType) == true;
        }

        private enum legacyCardAccessStatus : byte { Success, Blocked, Expired, InvalidDate, InvalidReader, InvalidTimezone, InvalidSchedule, AntiPassback }

        private legacyCardAccessStatus getLegacyCardAccessStatus(CardInformation cardInformation, IReaderConfiguration readerConfig, int logicalDoorId, bool isDuressPin)
        {
            if (cardInformation.Blocked == true)
                return legacyCardAccessStatus.Blocked;

            if (cardInformation.Expired == true)
                return legacyCardAccessStatus.Expired;

            // Check Date
            DateTime date = DateTime.Now.Date;
            if (date < cardInformation.StartDate || date > cardInformation.EndDate)
                return legacyCardAccessStatus.InvalidDate;

            int scheduleId = -1;
            if (readerConfig.Id < CardInformation.LegacyReaderScheduleCount)
                scheduleId = cardInformation.GetSchedule(readerConfig.Id);
            if (scheduleId <= 0)
                return legacyCardAccessStatus.InvalidReader;

            Pacom8003AccessSchedule accessSchedule = ConfigurationManager.Instance.GetAccessSchedule(scheduleId);
            if (accessSchedule == null)
                return legacyCardAccessStatus.InvalidTimezone;

            // Do not check the access schedule if the user used a duress pin
            if (isDuressPin == false)
            {
                if (accessSchedule.Enabled == false) // Do not check the access schedule if the user used a duress pin
                    return legacyCardAccessStatus.InvalidSchedule;
            }

            if (checkAntipassback(readerConfig, cardInformation, logicalDoorId) == false) // Validate anti-passback rules
                return legacyCardAccessStatus.AntiPassback; // Send failed anti-passback rules

            return legacyCardAccessStatus.Success;
        }

        private void processLegacyCardDenyStatus(CardInformation cardInformation, IReaderConfiguration readerConfig, int logicalDoorId, legacyCardAccessStatus cardStatus, ReaderStatus readerStatus)
        {
            switch (cardStatus)
            {
                case legacyCardAccessStatus.Blocked:
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () => { return "Card is [Blocked]!"; });
                    if (AccessDeniedCardBlockedEvent != null)
                        AccessDeniedCardBlockedEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                    readerStatus.CardStatusChange = CardStatus.Blocked;
                    break;
                case legacyCardAccessStatus.Expired:
                case legacyCardAccessStatus.InvalidDate:
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () => { return "Card is [Expired]!"; });
                    if (AccessDeniedCardExpiredEvent != null)
                        AccessDeniedCardExpiredEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                    readerStatus.CardStatusChange = CardStatus.Expired;
                    break;
                case legacyCardAccessStatus.InvalidReader:
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () => { return string.Format("No access schedule exists for readerId={0}!", readerConfig.Id); });
                    if (AccessDeniedReaderInvalidEvent != null)
                        AccessDeniedReaderInvalidEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                    break;
                case legacyCardAccessStatus.InvalidTimezone:
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () => { return "No access schedule exists for scheduleId!"; });
                    if (AccessDeniedScheduleInvalidEvent != null)
                        AccessDeniedScheduleInvalidEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                    break;
                case legacyCardAccessStatus.InvalidSchedule:
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl, () => { return "Access Denied for access schedule!"; });
                    if (AccessDeniedScheduleInvalidEvent != null)
                        AccessDeniedScheduleInvalidEvent(this, new CardAccessEventArgs(logicalDoorId, readerConfig.Id, cardInformation));
                    break;
            }
        }

        private void notify_InvalidMultiBadgingEvent(object sender, MultiBadgingEventArgs e)
        {
            foreach (var cardInformation in e.CardInformationList)
            {
                triggerCardAccessDeniedInvalidMultiEntryEvent(e.LogicalDoorId, e.LogicalReaderId, cardInformation.CardNumber, cardInformation.UserId);
            }
        }

        #region IDisposable Members

        bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            try
            {
                if (disposed == false)
                {
                    if (disposing == true)
                    {
                        LicenseManager.Instance.LicenseChanged -= new EventHandler(Instance_LicenseChanged);
                        ConfigurationManager.Instance.ConfigurationChanged -= new EventHandler<ConfigurationChangeEventArgs>(Instance_ConfigurationChanged);
                        ConfigurationManager.Instance.CardDeleteRequest -= new EventHandler<CardDeleteEventArgs>(notify_CardDeleteRequest);
                        ConfigurationManager.Instance.CardDownloadRequest -= new EventHandler<CardDownloadEventArgs>(notify_CardDownloadRequest);
                        StatusManager statusManager = StatusManager.Instance;
                        if (statusManager != null)
                        {
                            statusManager.Doors.InputChangedStatus -= new EventHandler<DoorInputChangedStatusEventArgs>(notify_ContactStatusChanged);
                            statusManager.Doors.InputChangedStatus -= new EventHandler<DoorInputChangedStatusEventArgs>(notify_EgressStatusChanged);
                            statusManager.Doors.InputChangedStatus -= new EventHandler<DoorInputChangedStatusEventArgs>(notify_StrikeStatusChanged);
                            statusManager.Doors.OnUpdateAntipassbackInfo -= new EventHandler<OnUpdateAntipassbackEventArgs>(notify_UpdateAntipassbackInfo);
                            statusManager.Doors.CardAndPinEntered -= new EventHandler<CardAndPinEnteredEventArgs>(notify_CardAndPinEntered);
                            statusManager.Doors.KeypadInactivityTimeoutExpired -= new EventHandler<ReaderKeypadEventArgs>(notify_ReaderKeypadInactivityTimeoutExpired);
                            statusManager.Readers.InvalidMultiBadgingEvent -= new EventHandler<MultiBadgingEventArgs>(notify_InvalidMultiBadgingEvent);
                            statusManager.TimeChanged -= new EventHandler<EventArgs>(onTimeChanged);
                        }

                        if (cardManager != null)
                        {
                            cardManager.LeastUsedCardDeletedEvent -= new EventHandler<LeastUsedCardDeletedEventArgs>(cardManager_LeastUsedCardDeletedEvent);
                            cardManager.Dispose();
                            cardManager = null;
                        }

                        if (broadcastDeleteAllCardsTimer != null)
                        {
                            TimerManager.Instance.RemoveTimer(broadcastDeleteAllCardsTimer);
                            broadcastDeleteAllCardsTimer = null;
                        }

                        if (deleteTemporaryCardsTimer != null)
                        {
                            deleteTemporaryCardsTimer.Stop();
                            TimerManager.Instance.RemoveTimer(deleteTemporaryCardsTimer);
                            deleteTemporaryCardsTimer = null;
                        }
                        instance = null;
                    }
                    // Free any unmanaged objects here.            
                    disposed = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogWarnMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return ex.ToString();
                });
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}
