﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Hal;
using Pacom.Core.Access;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// This class partition the space in SRAM memory, among menagers.
    /// </summary>
    public class SramCardAccessor : ICardAccessor, IDisposable
    {
        byte[] frameData = new byte[CardStorageParameters.FrameSize];

        private List<UnisonCardFrameDescriptor> unisonMainDescriptors = null;
        private GmsCardFrameDescriptor gmsMainDescriptors = null;
        private Comparison<UnisonCardFrameDescriptor> sortMemoryDescriptorsByCardHashDelegate;

        private Queue<short> freeFrames = null;

        private CardSerializerLegacy gmsSerializer = new CardSerializerLegacy();
        private CardSerializerRaw unisonSerializer = new CardSerializerRaw();

        public SramCardAccessor()
        {
            unisonMainDescriptors = new List<UnisonCardFrameDescriptor>();
            gmsMainDescriptors = new GmsCardFrameDescriptor();
            sortMemoryDescriptorsByCardHashDelegate = sortMemoryDescriptorsByCardHashMethod;

            freeFrames = new Queue<short>();
            for (int i = 0; i < CardStorageParameters.Sram.FrameCount; i++)
                freeFrames.Enqueue((short)i);

            // Load frames from SRAM
            loadFrames();
        }

        /// <summary>
        /// Method used to sort card descriptor list by its hash
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        private int sortMemoryDescriptorsByCardHashMethod(UnisonCardFrameDescriptor x, UnisonCardFrameDescriptor y)
        {
            if (x.CardId < y.CardId)
                return -1;
            else if (x.CardId > y.CardId)
                return 1;
            else
                return 0;
        }

        /// <summary>
        /// Returns current number of cards kept in SRAM memory
        /// </summary>
        /// <returns></returns>
        public int Count
        {
            get
            {
                return DatabaseMode == CardAccessDatabaseMode.Unison ? unisonMainDescriptors.Count : gmsMainDescriptors.FrameCount;
            }
        }

        /// <summary>
        /// Add new card record into the SRAM memory
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public bool Set(CardInformation cardInformation)
        {
            byte[] inputData = null;
            if (cardInformation.IsRawCardFormat)
            {
                if (ConfigurationManager.Instance.IsUnisonMode == false || DatabaseMode == CardAccessDatabaseMode.Gms)
                    return false;
                if (unisonSerializer.Serialize(cardInformation, out inputData) == false)
                    return false;
                DatabaseMode = CardAccessDatabaseMode.Unison;
                if (updateUnisonCard(cardInformation.CardNumber, inputData))
                    return true;
                long cardHash = (long)xxHash64.CalculateHash(cardInformation.CardNumber.Raw.CardNumber);
                return addUnisonCard(cardHash, inputData);
            }
            else
            {
                if (ConfigurationManager.Instance.IsUnisonMode || DatabaseMode == CardAccessDatabaseMode.Unison)
                    return false;
                if (gmsSerializer.Serialize(cardInformation, out inputData) == false)
                    return false;
                DatabaseMode = CardAccessDatabaseMode.Gms;
                if (updateGmsCard(cardInformation.CardNumber, inputData, cardInformation.StartDate, cardInformation.EndDate))
                    return true;
                return addGmsCard(cardInformation, inputData);
            }
        }

        /// <summary>
        /// Not implemented for SRAM memory
        /// </summary>
        public bool SetMultiple(List<Credential> cards)
        {
            return false;
        }

        public bool UpdateCardInformation(CardInformation cardInformation)
        {
            byte[] inputData = null;
            if (cardInformation.IsRawCardFormat)
            {
                if (unisonSerializer.Serialize(cardInformation, out inputData))
                    return updateUnisonCard(cardInformation.CardNumber, inputData);
            }
            else
            {
                if(cardInformation.IsPermanantCard && gmsSerializer.Serialize(cardInformation, out inputData))
                    return updateGmsCard(cardInformation.CardNumber, inputData, cardInformation.StartDate, cardInformation.EndDate);
            }
            return false;
        }

        private bool addUnisonCard(long cardHash, byte[] inputData)
        {
            if (freeFrames.Count == 0)
                return false;
            var frameId = freeFrames.Dequeue();
            Sram.Instance.WriteData(SramLocations.CardStartOffset + (frameId * CardStorageParameters.FrameSize), inputData);
            unisonMainDescriptors.Add(new UnisonCardFrameDescriptor((short)frameId, cardHash));
            unisonMainDescriptors.Sort(sortMemoryDescriptorsByCardHashDelegate);
            return true;
        }

        private bool updateUnisonCard(CardNumberHolder cardNumber, byte[] inputData)
        {
            int frameId = -1, descriptorId = -1;
            CardInformation foundItem;
            if (findUnisonItem(cardNumber, out frameId, out descriptorId, out foundItem) == true)
            {
                // Replace the item in SRAM with the updated Card
                Sram.Instance.WriteData(SramLocations.CardStartOffset + (frameId * CardStorageParameters.FrameSize), inputData);
                return true;
            }
            return false;
        }

        private bool addGmsCard(CardInformation cardInformation, byte[] inputData)
        {
            if (freeFrames.Count == 0)
                return false;
            var frameId = freeFrames.Dequeue();
            Sram.Instance.WriteData(SramLocations.CardStartOffset + (frameId * CardStorageParameters.FrameSize), inputData);
            var cardNumber = cardInformation.CardNumber.Legacy.AsLong();
            if (cardInformation.IsPermanantCard)
                gmsMainDescriptors.InsertFrame(cardNumber, 0, frameId);
            else
                gmsMainDescriptors.AddFrame(cardNumber, (short)frameId);
            return true;
        }

        private bool updateGmsCard(CardNumberHolder cardNumber, byte[] inputData, DateTime startDate, DateTime endDate)
        {
            var frameIds = gmsMainDescriptors.FindFrames(cardNumber.Legacy.AsLong());
            if (frameIds != null)
            {
                foreach (var frameId in frameIds)
                {
                    CardInformation foundItem = null;
                    if (getLegacyCardInformation(frameId, out foundItem) == true)
                    {
                        if (startDate.Date == foundItem.StartDate.Date && endDate.Date == foundItem.EndDate.Date)
                        {
                            Sram.Instance.WriteData(SramLocations.CardStartOffset + (frameId * CardStorageParameters.FrameSize), inputData);
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public CardNumberHolder GetUnisonCardNumber(int cardId)
        {
            CardInformation cardInformation = null;
            for (int i = 0; i < unisonMainDescriptors.Count; i++)
            {
                try
                {
                    if (Sram.Instance.ReadData(SramLocations.CardStartOffset + (unisonMainDescriptors[i].FrameId * CardStorageParameters.FrameSize), frameData) == true)
                    {
                        // Check if this is the right frame in case there are multiple frames with the same hash (this could happen in Unison
                        // card access mode because the hash is a 64bit hash of a 32byte CardNumber)
                        if (unisonSerializer.Deserialize(frameData, ref cardInformation) == true)
                        {
                            if (cardInformation.CardId == cardId)
                                return cardInformation.CardNumber;
                        }
                    }
                }
                catch
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return "CARD: Unable to find card.";
                    });
                }
            }
            return null;
        }

        private bool getUnisonCardInformation(CardNumberHolder cardNumber, out CardInformation cardInformation)
        {
            int frameId = -1, descriptorId = -1;
            return findUnisonItem(cardNumber, out frameId, out descriptorId, out cardInformation);
        }

        private bool getLegacyCardInformation(CardNumberHolder cardNumber, out CardInformation cardInformation)
        {
            cardInformation = null;
            var frameIds = gmsMainDescriptors.FindFrames(cardNumber.Legacy.AsLong());
            if (frameIds != null)
            {
                foreach (var frameId in frameIds)
                {
                    if (getLegacyCardInformation(frameId, out cardInformation))
                        return true;
                    else
                        removeFrame(frameId);
                }
                gmsMainDescriptors.DeleteCard(cardNumber.Legacy.AsLong());
            }
            return false;
        }

        /// <summary>
        /// Get card information for card number
        /// </summary>
        /// <returns>True if the card is found in the database, False otherwise.</returns>
        public bool Get(CardNumberHolder cardNumber, out CardInformation cardInformation)
        {
            // Find card item by card number
            if (DatabaseMode == CardAccessDatabaseMode.Unison)
                return getUnisonCardInformation(cardNumber, out cardInformation);
            else if (DatabaseMode == CardAccessDatabaseMode.Gms)
                return getLegacyCardInformation(cardNumber, out cardInformation);
            cardInformation = null;
            return false;
        }

        /// <summary>
        /// Get card information for specific reader Id
        /// </summary>
        /// <returns>True if the card was found, False otherwise.</returns>
        public bool GetUnisonCardInformationForSpecificReader(CardNumberHolder cardNumber, int readerId, out CardInformation cardInformation)
        {
            return getUnisonCardInformation(cardNumber, out cardInformation);
        }

        public bool Exists(CardInformation cardInfo)
        {
            if (DatabaseMode == CardAccessDatabaseMode.Unison)
            {
                int frameId = -1, descriptorId = -1;
                CardInformation cardInformation;
                return findUnisonItem(cardInfo.CardNumber, out frameId, out descriptorId, out cardInformation);
            }
            else if (DatabaseMode == CardAccessDatabaseMode.Gms)
            {
                var frameIds = gmsMainDescriptors.FindFrames(cardInfo.CardNumber.Legacy.AsLong());
                return frameIds != null && frameIds.Count > 0;
            }
            return false;
        }

        /// <summary>
        /// Get least used card
        /// </summary>
        public CardNumberHolder GetLeastUsed(out long locationIndex)
        {
            locationIndex = -1;
            DateTime scanDate = DateTime.UtcNow;
            int descriptorId = -1;
            DateTime frameLastUsed;

            CardSerializerBase serializer;
            if (DatabaseMode == CardAccessDatabaseMode.Unison)
            {
                serializer = unisonSerializer;
                for (int i = 0; i < unisonMainDescriptors.Count; i++)
                {
                    frameLastUsed = serializer.DeserializeLastUsed(unisonMainDescriptors[i].FrameId);
                    if (frameLastUsed < scanDate)
                    {
                        scanDate = frameLastUsed;
                        descriptorId = i;
                    }
                }
                if (descriptorId == -1)
                {
                    return null;
                }

                locationIndex = unisonMainDescriptors[descriptorId].FrameId;
                CardInformation cardInformation = null;
                Sram.Instance.ReadData(SramLocations.CardStartOffset + (unisonMainDescriptors[descriptorId].FrameId * CardStorageParameters.FrameSize), frameData);
                if (serializer.Deserialize(frameData, ref cardInformation) == true)
                    return cardInformation.CardNumber;
            }
            else
            {
                serializer = gmsSerializer;
                foreach (var frameIds in gmsMainDescriptors.FrameDescriptors.Values)
                {
                    foreach (var frameId in frameIds)
                    {
                        frameLastUsed = serializer.DeserializeLastUsed(frameId);
                        if (frameLastUsed < scanDate)
                        {
                            scanDate = frameLastUsed;
                            locationIndex = frameId;
                        }
                    }
                }

                if (locationIndex >= 0)
                {
                    CardInformation cardInformation = null;
                    if (getLegacyCardInformation((short)locationIndex, out cardInformation))
                        return cardInformation.CardNumber;
                }
            }
            
            return null;
        }

        public bool GetLocationIndex(int cardId, out long locationIndex)
        {
            locationIndex = -1;
            if (DatabaseMode != CardAccessDatabaseMode.Unison)
                return false;

            for (int i = 0; i < unisonMainDescriptors.Count; i++)
            {
                int queriedCardId = unisonSerializer.DeserializeCardId(unisonMainDescriptors[i].FrameId);
                if (queriedCardId == cardId)
                {
                    locationIndex = unisonMainDescriptors[i].FrameId;
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Get card records as enumeration
        /// </summary>
        public IEnumerable<CardInformation> Get()
        {
            CardInformation cardInformation = null;
            CardSerializerBase serializer;
            if (DatabaseMode == CardAccessDatabaseMode.Unison)
            {
                serializer = unisonSerializer;
                foreach (UnisonCardFrameDescriptor item in unisonMainDescriptors)
                {
                    Sram.Instance.ReadData(SramLocations.CardStartOffset + (item.FrameId * CardStorageParameters.FrameSize), frameData);
                    if (serializer.Deserialize(frameData, ref cardInformation) == true)
                    {
                        yield return cardInformation;
                    }
                }
            }
            else
            {
                serializer = gmsSerializer;
                foreach (var frameIds in gmsMainDescriptors.FrameDescriptors.Values)
                {
                    if (frameIds != null)
                    {
                        foreach (var frameId in frameIds)
                        {
                            Sram.Instance.ReadData(SramLocations.CardStartOffset + (frameId * CardStorageParameters.FrameSize), frameData);
                            if (serializer.Deserialize(frameData, ref cardInformation) == true)
                            {
                                yield return cardInformation;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Clear specific card record identified by provided card number
        /// </summary>
        public void Delete(CardNumberHolder cardNumber)
        {
            CardInformation foundItem;
            if (DatabaseMode == CardAccessDatabaseMode.Unison)
            {
                int frameId = -1;
                int descriptorId = -1;
                if (findUnisonItem(cardNumber, out frameId, out descriptorId, out foundItem) == true)
                {
                    removeFrame((short)frameId);
                    unisonMainDescriptors.Remove(unisonMainDescriptors[descriptorId]);
                }
                if (unisonMainDescriptors.Count == 0)
                    DatabaseMode = CardAccessDatabaseMode.NoCardsPresent;
            }
            else
            {
                var frameIds = gmsMainDescriptors.FindFrames(cardNumber.Legacy.AsLong());
                if (frameIds != null)
                {
                    foreach (var frameId in frameIds)
                    {
                        removeFrame(frameId);
                    }
                    gmsMainDescriptors.DeleteCard(cardNumber.Legacy.AsLong());
                }
                if (gmsMainDescriptors.FrameCount == 0)
                    DatabaseMode = CardAccessDatabaseMode.NoCardsPresent;
            }
        }

        /// <summary>
        /// Clear specific card record identified by provided locationIndex
        /// </summary>
        /// <param name="locationIndex"></param>
        public void Delete(long locationIndex)
        {
            removeFrame((short)locationIndex);
            if (DatabaseMode == CardAccessDatabaseMode.Unison)
            {
                for (int i = 0; i < unisonMainDescriptors.Count; i++)
                {
                    if (unisonMainDescriptors[i].FrameId == locationIndex)
                    {
                        unisonMainDescriptors.RemoveAt(i);
                        break;
                    }
                }
                if (unisonMainDescriptors.Count == 0)
                    DatabaseMode = CardAccessDatabaseMode.NoCardsPresent;
            }
            else
            {
                gmsMainDescriptors.DeleteFrame((short)locationIndex);
                if (gmsMainDescriptors.FrameCount == 0)
                    DatabaseMode = CardAccessDatabaseMode.NoCardsPresent;
            }
        }

        /// <summary>
        /// Delete temporary cards
        /// </summary>
        /// <returns></returns>
        public List<CardNumberHolder> DeleteTemporaryCards()
        {
            List<CardNumberHolder> deletedCards = new List<CardNumberHolder>();
            DateTime currentDate = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow).Date;
            var gmsFrameDescriptors = new SortedList<long, List<short>>(gmsMainDescriptors.FrameDescriptors);
            foreach (var frameDescriptor in gmsFrameDescriptors)
            {
                if (frameDescriptor.Value != null)
                {
                    var frameIds = new List<short>(frameDescriptor.Value);
                    CardInformation cardInformation = new CardInformation(DateTime.UtcNow);
                    foreach (var frameId in frameIds)
                    {
                        Sram.Instance.ReadData(SramLocations.CardStartOffset + (frameId * CardStorageParameters.FrameSize), frameData);
                        if (gmsSerializer.DeserializeTemporaryCard(frameData, ref cardInformation) && (cardInformation.EndDate.Date < currentDate))
                        {
                            removeFrame(frameId);
                            gmsMainDescriptors.DeleteFrame(frameDescriptor.Key, frameId);
                            if(deletedCards.Contains(cardInformation.CardNumber) == false)
                                deletedCards.Add(cardInformation.CardNumber);
                        }
                    }
                }
            }

            return deletedCards;
        }

        /// <summary>
        /// Clear all card records
        /// </summary>
        public void Clear()
        {
            for (int iRemove = 0; iRemove < 3; iRemove++)
            {
                freeFrames.Clear();
                unisonMainDescriptors.Clear();
                gmsMainDescriptors.Clear();
                for (short frameId = 0; frameId < CardStorageParameters.Sram.FrameCount; frameId++)
                {
                    removeFrame(frameId);
                }

                // Check if frames are cleared, otherwise try again.
                loadFrames();
                int count = DatabaseMode == CardAccessDatabaseMode.Unison ? unisonMainDescriptors.Count : gmsMainDescriptors.FrameCount;
                if (count == 0)
                {
                    DatabaseMode = CardAccessDatabaseMode.NoCardsPresent;
                    return;
                }
                else
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return "CARD: Clearing cards from SRAM did not result in an empty set.";
                    });
                }
            }
        }

        /// <summary>
        /// Get collection of all card hashes in Sram accessor.
        /// </summary>
        /// <returns></returns>
        public List<long> ToList()
        {
            if (DatabaseMode == CardAccessDatabaseMode.Unison)
            {
                List<long> resultList = new List<long>();
                foreach (var item in unisonMainDescriptors)
                {
                    resultList.Add(item.CardId);
                }
                return resultList;
            }
            else
            {
                return gmsMainDescriptors.CardNumbers;
            }
        }

        /// <summary>
        /// remove frame and clear memory
        /// </summary>
        /// <param name="frameId"></param>
        private void removeFrame(short frameId)
        {
            freeFrames.Enqueue(frameId);
            int offset = (SramLocations.CardStartOffset + (frameId * CardStorageParameters.FrameSize));
            offset = offset + CardStorageParameters.FrameSize - CardStorageParameters.Sram.FrameDefaultData.Length;
            Sram.Instance.WriteData(offset, CardStorageParameters.Sram.FrameDefaultData);
        }

        public CardAccessDatabaseMode DatabaseMode
        {
            get;
            private set;
        }

        /// <summary>
        /// Load valid card frames from SRAM.
        /// </summary>
        private void loadFrames()
        {
            // Count valid frames
            // Read over all frames and add frames which can be deserialize
            bool validGmsFramesFound = false;
            bool validUnisonFramesFound = false;
            DatabaseMode = CardAccessDatabaseMode.NoCardsPresent;

            CardInformation cardInformation = null;
            int frameOffset = SramLocations.CardStartOffset;
            for (int i = 0; i < CardStorageParameters.Sram.FrameCount; i++)
            {
                short frameId = freeFrames.Dequeue();
                try
                {
                    Sram.Instance.ReadData(frameOffset, frameData);
                    if (unisonSerializer.Deserialize(frameData, ref cardInformation) == true)
                    {
                        unisonMainDescriptors.Add(new UnisonCardFrameDescriptor((short)i, (long)xxHash64.CalculateHash(cardInformation.CardNumber.Raw.CardNumber)));
                        validUnisonFramesFound = true;
                    }
                    else if (gmsSerializer.Deserialize(frameData, ref cardInformation) == true)
                    {
                        if (cardInformation.IsPermanantCard)
                            gmsMainDescriptors.InsertFrame(cardInformation.CardNumber.Legacy.AsLong(), 0, frameId);
                        else
                            gmsMainDescriptors.AddFrame(cardInformation.CardNumber.Legacy.AsLong(), frameId);
                        validGmsFramesFound = true;
                    }
                    else
                    {
                        freeFrames.Enqueue(frameId);
                    }
                }
                catch
                {
                    freeFrames.Enqueue(frameId);
                }
                frameOffset += CardStorageParameters.FrameSize;
            }
            if (validUnisonFramesFound && validGmsFramesFound)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return "Found both GMS and Unison card holder records. Clearing card database.";
                });
                Clear();
            }
            else
            {
                if (validGmsFramesFound)
                    DatabaseMode = CardAccessDatabaseMode.Gms;
                else if (validUnisonFramesFound)
                    DatabaseMode = CardAccessDatabaseMode.Unison;

                unisonMainDescriptors.Sort(sortMemoryDescriptorsByCardHashDelegate);
            }
        }

        /// <summary>
        /// Returns frame offset in SRAM for given card
        /// </summary>
        /// <returns>True if item was found</returns>
        private bool findUnisonItem(CardNumberHolder cardNumber, out int frameId, out int descriptorId, out CardInformation cardInformation)
        {
            cardInformation = null;
            frameId = -1;
            descriptorId = -1;
            if (unisonMainDescriptors.Count == 0)
                return false;

            // A binary search won't work for raw card numbers as the hash is not unique
            long cardHash = (long)xxHash64.CalculateHash(cardNumber.Raw.CardNumber);
            for (int i = 0; i < unisonMainDescriptors.Count; i++)
            {
                if (unisonMainDescriptors[i].CardId == cardHash)
                {
                    try
                    {
                        if (Sram.Instance.ReadData(SramLocations.CardStartOffset + (unisonMainDescriptors[i].FrameId * CardStorageParameters.FrameSize), frameData) == true)
                        {
                            // Check if this is the right frame in case there are multiple frames with the same hash (this could happen in Unison
                            // card access mode because the hash is a 64bit hash of a 32byte CardNumber)
                            if (unisonSerializer.Deserialize(frameData, ref cardInformation) == true)
                            {
                                if (cardInformation.CardNumber.Raw.CardBitLength == cardNumber.Raw.CardBitLength && cardInformation.CardNumber.Raw.CardNumber.Compare(cardNumber.Raw.CardNumber) == true)
                                {
                                    frameId = unisonMainDescriptors[i].FrameId;
                                    descriptorId = i;
                                    return true;
                                }
                            }
                        }
                    }
                    catch
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                        {
                            return "CARD: Unable to find card.";
                        });
                    }
                }
            }

            frameId = -1;
            descriptorId = -1;
            return false;
        }

        public List<CardInformation> GetLegacyCardInformationListForSpecificReader(CardNumberHolder cardNumber, int readerId)
        {
            var frameIds = gmsMainDescriptors.FindFrames(cardNumber.Legacy.AsLong());
            if (frameIds != null && frameIds.Count > 0)
            {
                List<CardInformation> cardInformationList = new List<CardInformation>();
                CardInformation cardInformation = null;
                foreach (var frameId in frameIds)
                {
                    if (getLegacyCardInformation(frameId, out cardInformation))
                        cardInformationList.Add(cardInformation);
                }
                return cardInformationList;
            }
            return null;
        }

        public List<CardInformation> GetLegacyCardInformationList(CardNumberHolder cardNumber)
        {
            var frameIds = gmsMainDescriptors.FindFrames(cardNumber.Legacy.AsLong());
            if (frameIds != null && frameIds.Count > 0)
            {
                List<CardInformation> cardInformationList = new List<CardInformation>();
                CardInformation cardInformation = null;
                foreach (var frameId in frameIds)
                {
                    if (getLegacyCardInformation(frameId, out cardInformation))
                        cardInformationList.Add(cardInformation);
                }
                return cardInformationList;
            }
            return null;
        }

        /// <summary>
        /// get gms card information
        /// </summary>
        /// <param name="frameId"></param>
        /// <param name="cardInformation"></param>
        /// <returns></returns>
        private bool getLegacyCardInformation(short frameId, out CardInformation cardInformation)
        {
            cardInformation = null;
            Sram.Instance.ReadData(SramLocations.CardStartOffset + (frameId * CardStorageParameters.FrameSize), frameData);
            return gmsSerializer.Deserialize(frameData, ref cardInformation);
        }



#if DEBUG
        public CardInformation GetCardInformation(UniqueCardHolderId cardHolder)
        {
            CardInformation cardInformation = null;
            if (DatabaseMode == CardAccessDatabaseMode.Gms)
            {
                var frameIds = gmsMainDescriptors.FindFrames(cardHolder.Id);
                if (frameIds != null)
                {
                    foreach (var frameId in frameIds)
                    {
                        if (getLegacyCardInformation(frameId, out cardInformation))
                        {
                            if (cardInformation.StartDate == cardHolder.StartDate && cardInformation.EndDate == cardHolder.EndDate)
                                return cardInformation;
                        }
                    }
                }
            }
            else
            {
                foreach (var card in Get())
                {
                    if (card.CardId == cardHolder.Id)
                    {
                        return card;
                    }
                }
            }
            return cardInformation;
        }
        public List<UniqueCardHolderId> GetUniqueCardHolderIDs()
        {
            var cardHolders = new List<UniqueCardHolderId>();
            if (DatabaseMode == CardAccessDatabaseMode.Gms)
            {
                foreach (var frameDescriptor in gmsMainDescriptors.FrameDescriptors)
                {
                    if (frameDescriptor.Value != null)
                    {
                        var cardHolder = new UniqueCardHolderId();
                        foreach (var frameId in frameDescriptor.Value)
                        {
                            Sram.Instance.ReadData(SramLocations.CardStartOffset + (frameId * CardStorageParameters.FrameSize), frameData);
                            if (gmsSerializer.DeserializeCardHolderId(frameData, ref cardHolder) == true)
                                cardHolders.Add(cardHolder);
                        }
                    }
                }
            }
            else
            {
                foreach (var card in Get())
                {
                    cardHolders.Add(new UniqueCardHolderId() { Id = card.CardId });
                }
            }

            return cardHolders;
        }
#endif

        /// <summary>
        /// Remove (zero out) all stored card data. This function should only be used before SramCardAccessor has been 
        /// created, i.e. very early on in the startup process.
        /// </summary>
        public static void EraseAll()
        {
            byte[] zeroData = new byte[CardStorageParameters.FrameSize];
            for (int i = 0; i < CardStorageParameters.Sram.FrameCount; i++)
            {
                Sram.Instance.WriteData(SramLocations.CardStartOffset + (i * CardStorageParameters.FrameSize), zeroData);
            }
        }

        #region IDisposable Members

        bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                if (disposing)
                {
                    // Free any other managed objects here.
                    unisonMainDescriptors.Clear();
                    gmsMainDescriptors.Clear();
                }

                // Free any unmanaged objects here.            
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
