﻿using System.Collections.Generic;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.AccessControl
{
    internal class CardMultiBadgeInfo
    {
        internal TimeLimit LastUsedDateTime { get; set; }
        internal int Count { get; set; }

        public CardMultiBadgeInfo()
        {
            LastUsedDateTime = new TimeLimit();
            Count = 1;
        }
    }
}
