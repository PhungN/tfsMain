﻿using System.Collections.Generic;
namespace Pacom.Peripheral.AccessControl
{
    public class GmsCardFrameDescriptor
    {
        private SortedList<long, List<short>> frameDescriptors;
        private int frameCount;

        public GmsCardFrameDescriptor()
        {
            frameDescriptors = new SortedList<long, List<short>>();
            frameCount = 0;
        }

        public void AddFrame(long cardNumber, short frameId)
        {
            if (frameDescriptors.ContainsKey(cardNumber) == true)
                frameDescriptors[cardNumber].Add(frameId);
            else
                frameDescriptors[cardNumber] = new List<short>() { frameId };
            frameCount += 1;
        }

        public void InsertFrame(long cardNumber, int index, short frameId)
        {
            if (frameDescriptors.ContainsKey(cardNumber) == true)
                frameDescriptors[cardNumber].Insert(index, frameId);
            else
                frameDescriptors[cardNumber] = new List<short>() { frameId };
            frameCount += 1;
        }

        public void DeleteFrame(long cardNumber, short frameId)
        {
            if (frameDescriptors.ContainsKey(cardNumber) == true)
            {
                var frameIds = frameDescriptors[cardNumber];
                if (frameIds.Contains(frameId) == true)
                    frameIds.Remove(frameId);
                if (frameIds.Count == 0)
                    frameDescriptors.Remove(cardNumber);
                if (frameCount > 0)
                    frameCount -= 1;
            }
        }

        public bool DeleteFrame(short frameId)
        {
            foreach (var frameDescriptor in frameDescriptors)
            {
                var frameIds = frameDescriptor.Value;
                if (frameIds != null && frameIds.Contains(frameId) == true)
                {
                    frameIds.Remove(frameId);
                    frameCount -= 1;
                    if (frameIds.Count == 0)
                        frameDescriptors.Remove(frameDescriptor.Key);
                    return true;
                }
            }
            return false;
        }

        public void DeleteCard(long cardNumber)
        {
            var frames = FindFrames(cardNumber);
            if (frames != null)
            {
                frameCount -= frames.Count;
                frameDescriptors.Remove(cardNumber);
            }
        }

        public void Clear()
        {
            frameDescriptors.Clear();
            frameCount = 0;
        }

        public List<short> FindFrames(long cardNumber)
        {
            var cardNumbers = new List<long>(frameDescriptors.Keys);
            var index = cardNumbers.BinarySearch(cardNumber);
            return index >= 0 ? frameDescriptors[cardNumbers[index]] : null;
        }

        public int CardCount
        {
            get { return frameDescriptors.Count; }
        }

        public int FrameCount
        {
            get { return frameCount; }
            set { frameCount = value; }
        }

        public SortedList<long, List<short>> FrameDescriptors
        {
            get { return frameDescriptors; }
        }

        public List<long> CardNumbers
        {
            get { return new List<long>(frameDescriptors.Keys); }
        }
    }
}

