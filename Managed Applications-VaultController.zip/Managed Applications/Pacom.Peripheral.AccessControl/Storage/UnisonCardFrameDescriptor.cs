﻿namespace Pacom.Peripheral.AccessControl
{
    public class UnisonCardFrameDescriptor
    {
        private short frameId;
        private long cardId;

        public UnisonCardFrameDescriptor(short frameId, long cardId)
        {
            this.frameId = frameId;
            this.cardId = cardId;
        }

        public short FrameId
        {
            get
            {
                return this.frameId;
            }
        }

        public long CardId
        {
            get
            {
                return this.cardId;
            }
        }
    }
}
