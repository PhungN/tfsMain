﻿using System;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.AccessControl
{
    public abstract class CardSerializerBase
    {
        protected CardSerializerBase()
        {
        }

        /// <summary>
        /// Buffer used for deserializing last used
        /// </summary>
        private static byte[] dateLastUsed = new byte[8];

        /// <summary>
        /// Deserialize only the DateTime when this card was last used.
        /// </summary>
        /// <param name="frameId">Frame Id to get the last used for.</param>
        /// <returns>Last used for this card record</returns>
        public DateTime DeserializeLastUsed(int frameId)
        {
            Sram.Instance.ReadData(SramLocations.CardStartOffset + (frameId * CardStorageParameters.FrameSize) + 4, dateLastUsed);
            return new DateTime(BitConverter.ToInt64(dateLastUsed, 0));
        }

        /// <summary>
        /// Serialize this card as a byte array.
        /// </summary>
        /// <param name="item">Card to serialize</param>
        /// <param name="output">Serialized byte array</param>
        /// <returns>True if the serialization was successful</returns>
        public virtual bool Serialize(CardInformation cardInformation, out byte[] output)
        {
            try
            {
                // Create buffer and fill with zeros
                output = new byte[CardStorageParameters.FrameSize];
                FastArrayCopy.ArrayFill(output, CardStorageParameters.Sram.FrameDefaultData);

                output[1] = (byte)'C';
                output[2] = (byte)'R';
                output[3] = (byte)'H';

                byte[] lastUsedArray = BitConverter.GetBytes(cardInformation.LastUsed.Ticks);
                output[4] = lastUsedArray[0];
                output[5] = lastUsedArray[1];
                output[6] = lastUsedArray[2];
                output[7] = lastUsedArray[3];
                output[8] = lastUsedArray[4];
                output[9] = lastUsedArray[5];
                output[10] = lastUsedArray[6];
                output[11] = lastUsedArray[7];
            }
            catch
            {
                // We do not tolerate deserialize exceptions. The frame must have been completely corrupted.
                output = null;
                return false;
            }
            return true;
        }

        /// <summary>
        /// Deserialize card from byte array
        /// </summary>
        /// <param name="data">Byte array of data</param>
        /// <returns>Returns card or null if invalid array was provided</returns>
        public virtual bool Deserialize(byte[] data, ref CardInformation cardInformation)
        {
            try
            {
                if (isValidCardData(data) == true)
                {
                    // Read Last Used Date
                    byte[] lastUsedArray = new byte[8];
                    lastUsedArray[0] = data[4];
                    lastUsedArray[1] = data[5];
                    lastUsedArray[2] = data[6];
                    lastUsedArray[3] = data[7];
                    lastUsedArray[4] = data[8];
                    lastUsedArray[5] = data[9];
                    lastUsedArray[6] = data[10];
                    lastUsedArray[7] = data[11];
                    cardInformation = new CardInformation(new DateTime(BitConverter.ToInt64(lastUsedArray, 0)));
                    return true;
                }
            }
            catch
            {
            }
            return false;

        }

        /// <summary>
        /// check if check sum and header is valid
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        protected bool isValidCardData(byte[] data)
        {
            // Calculate check sum
            byte[] checkSum = Crc32.ComputeHash(data, 0, data.Length - 4);
            int crcIndex = CardStorageParameters.FrameSize - CardStorageParameters.CrcItemSize;
            if (data[crcIndex] != checkSum[0] || data[crcIndex + 1] != checkSum[1] ||
                data[crcIndex + 2] != checkSum[2] || data[crcIndex + 3] != checkSum[3])
                return false;

            // Check header
            if (data[1] != (byte)'C' || data[2] != (byte)'R' || data[3] != (byte)'H')
                return false;

            return true;
        }
    }
}
