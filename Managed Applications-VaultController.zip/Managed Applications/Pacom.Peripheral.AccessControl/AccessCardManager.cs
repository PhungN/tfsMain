﻿using System;
using System.Collections.Generic;
using System.Threading;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.Common.SQLCE;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using Pacom.Core.Access;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// Card manager
    /// </summary>
    public class AccessCardManager : IAccessCardManager, IDisposable
    {
        private SramCardAccessor sramMemory = null;
        private SdcardCardAccessor sdCardMemory = null;

        /// <summary>
        /// The main memory accessor used by this instance
        /// </summary>
        private ICardAccessor mainAccessor = null;

        private int mainAccessorMaxFrameCount = 0;
        private int mainAccessorNearFullFrameCount = 0;

        private object accessorLock = new object();

        /// <summary>
        /// This event is triggered when the least used card is deleted.
        /// </summary>
        public event EventHandler<LeastUsedCardDeletedEventArgs> LeastUsedCardDeletedEvent;

        /// <summary>
        /// Indicates that the manager is closing for business
        /// </summary>
        bool closing = false;

        /// <summary>
        /// Only one instance of the Card Manager will be created
        /// </summary>
        private static AccessCardManager instance = null;

        /// <summary>
        /// The thread that copies cards from SRAM to the SD card on boot.
        /// </summary>
        private Thread copyDataThread = null;

        /// <summary>
        /// Create an instance of Access Control Manager
        /// </summary>
        /// <returns></returns>
        public static AccessCardManager CreateInstance()
        {
            if (instance == null)
                instance = new AccessCardManager();
            return instance;
        }

        public static AccessCardManager Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.CardManager, () =>
                    {
                        return "Instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
#endif
                return instance;
            }
        }

        /// <summary>
        /// CardManager constructor. It must be provided with SRAM card accessor. The SD Card accessor is optional.
        /// When SD Card is provided, data will be copied to it. Only one accessor is used at any given time.
        /// </summary>
        /// <param name="sramMemory">SRAM memory accessor for card storage</param>
        /// <param name="sdCardMemory">SD Card memory accessor for card storage</param>
        private AccessCardManager()
        {
            try
            {
                int totalSDCardCardSize = 0;
                int totalSRAMCardSize = 0;
                int totalCardSize = 0;

                // Configure card accessors
                if (SqlCeDatabase.Instance.DefaultDatabaseIsValid == true)
                {
                    try
                    {
                        sdCardMemory = new SdcardCardAccessor();
                    }
                    catch (Exception ex)
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                        {
                            return string.Format("Unable to create SD card, card storage. {0}", ex.Message);
                        });
                        sdCardMemory = null;
                    }
                }
                sramMemory = new SramCardAccessor();

                if (sdCardMemory != null)
                {
                    totalSDCardCardSize = CardStorageParameters.SdCard.FrameCount;
                    totalCardSize = CardStorageParameters.SdCard.FrameCount;
                }
                else
                {
                    totalSRAMCardSize = CardStorageParameters.Sram.FrameCount;
                    totalCardSize = CardStorageParameters.Sram.FrameCount;
                }

                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    if (totalCardSize == -1)
                        return string.Format("Card manager is started. Total possible cards: Not limited (SRAM: {0}, SDCard: Not limited)",
                            totalSRAMCardSize);
                    else
                        return string.Format("Card manager is started. Total possible cards: {0} (SRAM: {1}, SDCard: {2})",
                            totalCardSize, totalSRAMCardSize, totalSDCardCardSize);
                });

                if (sdCardMemory != null)            
                {
                    mainAccessor = this.sdCardMemory;
                    mainAccessorMaxFrameCount = CardStorageParameters.SdCard.FrameCount;
                    mainAccessorNearFullFrameCount = CardStorageParameters.SdCard.NearFullFrameCount;
                    // Attempt to copy card records when SRAM has some records
                    if (this.sramMemory.Count != 0 && Hal.Pcb.DipSwitch1Pin2 == false)
                    {
                        int sramMemoryCount = this.sramMemory.Count;
                        copyDataThread = new Thread(new ThreadStart(copySramCardsToSDCardThreadMethod));
                        copyDataThread.Name = "Copy SRAM cards to SD card Thread";
                        copyDataThread.Priority = ThreadPriority.Lowest;
                        Logger.LogDebugMessage(LoggerClassPrefixes.CardManager, () =>
                        {
                            return string.Format("Moving {0} card(s) from SRAM to SD card.", sramMemoryCount);
                        });
                    }          
                }
                else
                {
                    mainAccessor = this.sramMemory;
                    mainAccessorMaxFrameCount = CardStorageParameters.Sram.FrameCount;
                    mainAccessorNearFullFrameCount = CardStorageParameters.Sram.NearFullFrameCount;
                }

            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("Error while initalizing card manager. {0}", ex.Message);
                });
            }
        }

        public CardAccessDatabaseMode DatabaseMode
        {
            get
            {
                if (closing == true)
                    return CardAccessDatabaseMode.NoCardsPresent;
                lock (accessorLock)
                {
                    return mainAccessor.DatabaseMode;
                }
            }
        }

        public void PopulateCardInformation(DeviceInformation deviceInformation)
        {
            if (mainAccessorMaxFrameCount == -1)
                deviceInformation.CardDatabaseCapacity = CardStorageParameters.SdCard.ReportedFrameCount;
            else
                deviceInformation.CardDatabaseCapacity = CardStorageParameters.Sram.FrameCount;
            deviceInformation.CardDatabaseCount = mainAccessor.Count;
        }

        private void copySramCardsToSDCardThreadMethod()
        {
            try
            {
                bool forceClose = false;
                int sramMemoryCount = 0;
                DeleteAllCardsLocally();
                // Copy data; frames should be validated by the accessor.
                foreach (CardInformation cardInformation in this.sramMemory.Get())
                {
                    AddOrUpdate(cardInformation);
                    sramMemoryCount++;
                    if (Application.Closing == true)
                    {
                        forceClose = true;
                        break;
                    }
                    Thread.Sleep(10);
                }
                if (forceClose == false)
                {
                    this.sramMemory.Clear();
                    Logger.LogDebugMessage(LoggerClassPrefixes.CardManager, () =>
                    {
                        return string.Format("Successfully moved {0} card(s) from SRAM to SD card.", sramMemoryCount);
                    });
                }                
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.CardManager, () =>
                {
                    return string.Format("Unable to copy card records to SD card. {0}", ex.Message);
                });
            }
        }

        public bool IsSDCardPresent
        {
            get
            {
                if (mainAccessorMaxFrameCount == CardStorageParameters.SdCard.FrameCount)
                    return true;
                return false;
            }
        }

        /// <summary>
        /// Add new or override existing cards in the SD card memory.
        /// </summary>
        public bool AddOrUpdateMultiple(List<Credential> cards)
        {
            if (closing == true)
                return false;

            // The accessorLock won't be held as SQL will be able to take care of adding and querying at the same time.

            return mainAccessor.SetMultiple(cards);
        }

        /// <summary>
        /// Add new or override existing card in memory. If memory is full remove the oldest item.
        /// </summary>
        public bool AddOrUpdate(CardInformation cardInformation)
        {
            if (closing == true)
                return false;
            lock (accessorLock)
            {
                // Check if there is free space
                if (mainAccessorMaxFrameCount != -1)    // Not an SD Card
                {
                    // Check if we can override exiting card
                    if (mainAccessor.Exists(cardInformation) == false)
                    {
                        if (mainAccessor.Count == (mainAccessorNearFullFrameCount - 1))
                        {
                            try
                            {
                                StatusManager.Instance.Controller.CardDatabaseStatus = CardDatabaseStatus.SramDatabase90PercentFull;
                            }
                            catch
                            {
                            }
                        }
                        else if (mainAccessor.Count == (mainAccessorMaxFrameCount - 1))
                        {
                            try
                            {
                                StatusManager.Instance.Controller.CardDatabaseStatus = CardDatabaseStatus.SramDatabaseFull;
                            }
                            catch
                            {
                            }
                        }
                        else if (mainAccessor.Count >= mainAccessorMaxFrameCount)
                        {
                            // Remove the least used card record
                            long locationIndex;
                            CardNumberHolder leastUsedCardNumber = mainAccessor.GetLeastUsed(out locationIndex);
                            if (leastUsedCardNumber != null)
                            {
                                if (leastUsedCardNumber.IsRawCardFormat)
                                    mainAccessor.Delete(locationIndex);
                                else
                                    mainAccessor.Delete(leastUsedCardNumber);
                                if (LeastUsedCardDeletedEvent != null)
                                {
                                    try
                                    {
                                        LeastUsedCardDeletedEvent(this, new LeastUsedCardDeletedEventArgs(leastUsedCardNumber));
                                    }
                                    catch
                                    {
                                    }
                                }                            
                            }
                        }
                    }
                }
                cardInformation.SetLastUsedToNow();
                return mainAccessor.Set(cardInformation);
            }
        }

        /// <summary>
        /// Update card's last used time
        /// </summary>
        /// <param name="cardInformation"></param>
        /// <returns></returns>
        public bool UpdateCardLastUsed(CardInformation cardInformation)
        {
            if (closing == true || this.sdCardMemory != null)
                return false;
            lock (accessorLock)
            {
                cardInformation.SetLastUsedToNow();
                return mainAccessor.UpdateCardInformation(cardInformation);
            }
        }

        /// <summary>
        /// Get card details by providing card number.
        /// </summary>
        public CardInformation Get(CardNumberHolder cardNumber)
        {
            if (closing == true)
                return null;
            CardInformation cardInformation;
            lock (accessorLock)
            {
                if (mainAccessor.Get(cardNumber, out cardInformation) == false)
                    return null;
            }
            return cardInformation;
        }

#if DEBUG
        public CardInformation GetCardInformation(UniqueCardHolderId cardHoderId)
        {
            if (closing == true)
                return null;
            lock (accessorLock)
            {
                return mainAccessor.GetCardInformation(cardHoderId);
            }
        }

        public List<UniqueCardHolderId> GetUniqueCardHolderIDs()
        {
            List<UniqueCardHolderId> cardHolders = null;
            lock (accessorLock)
            {
                cardHolders = mainAccessor.GetUniqueCardHolderIDs();
            }
            return cardHolders;
        }

        public bool UpdateElevatorFloorsAccess(CardInformation cardInformation)
        {
            CardInformation updatedCardInformation = Get(cardInformation.CardNumber);
            updatedCardInformation.FloorsAccess = cardInformation.FloorsAccess;
            updatedCardInformation.FloorsAccessTimezoneId = cardInformation.FloorsAccessTimezoneId;
            return mainAccessor.Set(updatedCardInformation);
        }
#endif

        /// <summary>
        /// Get partial card details by providing card number and relevant reader.
        /// </summary>
        public CardInformation GetUnisonCardInformationForSpecificReader(CardNumberHolder cardNumber, int readerId)
        {
            if (closing == true)
                return null;
            CardInformation cardInformation;
            lock (accessorLock)
            {
                if (mainAccessor.GetUnisonCardInformationForSpecificReader(cardNumber, readerId, out cardInformation) == false)
                    return null;
            }
            return cardInformation;
        }

        public List<CardInformation> GetLegacyCardInformationListForSpecificReader(CardNumberHolder cardNumber, int readerId)
        {
            if (closing == true)
                return null;
            lock (accessorLock)
            {
                return mainAccessor.GetLegacyCardInformationListForSpecificReader(cardNumber, readerId);
            }
        }

        public List<CardInformation> GetLegacyCardInformationList(CardNumberHolder cardNumber)
        {
            if (closing == true)
                return null;
            lock (accessorLock)
            {
                return mainAccessor.GetLegacyCardInformationList(cardNumber);
            }
        }

        /// <summary>
        /// Get card number from the card's logical id.
        /// </summary>
        /// <param name="cardId">The card's logical id.</param>
        /// <returns>The card number.</returns>
        public CardNumberHolder GetCardNumber(int cardId)
        {
            if (closing == true)
                return null;
            lock (accessorLock)
            {
                return mainAccessor.GetUnisonCardNumber(cardId);
            }
        }

        /// <summary>
        /// Delete card by providing card number.
        /// </summary>
        public void Delete(CardNumberHolder cardNumber)
        {
            if (closing == true)
                return;
            lock (accessorLock)
            {
                mainAccessor.Delete(cardNumber);
                updateSramDatabaseUtilizationStatus();
            }
        }

        public List<CardNumberHolder> DeleteTemporaryCards()
        {
            if (closing == true)
                return null;
            lock (accessorLock)
            {
                return mainAccessor.DeleteTemporaryCards();
            }
        }
        /// <summary>
        /// Delete card by providing logical cardId from Unison.
        /// </summary>
        public void Delete(int cardId)
        {
            if (closing == true)
                return;
            lock (accessorLock)
            {
                long locationIndex;
                if (mainAccessor.GetLocationIndex(cardId, out locationIndex))
                {
                    mainAccessor.Delete(locationIndex);
                    updateSramDatabaseUtilizationStatus();
                }
            }
        }

        /// <summary>
        /// Delete all card records.
        /// </summary>
        public void DeleteAllCardsLocally()
        {
            if (closing == true)
                return;
            lock (accessorLock)
            {
                mainAccessor.Clear();
                if (StatusManager.Instance != null)
                    updateSramDatabaseUtilizationStatus();
            }
        }

        public void UpdateStatusManager()
        {
            StatusManager.Instance.Controller.CardDatabaseStatus = CardDatabaseStatus.SDCardFitted;
            updateSramDatabaseUtilizationStatus();

            // This needs to be called after ConfigurationManager.Initialize has been called.
            if (copyDataThread != null)
                copyDataThread.Start();
        }

        private void updateSramDatabaseUtilizationStatus()
        {
            if (mainAccessorMaxFrameCount != -1)    // Not an SD Card
            {
                if (mainAccessor.Count < mainAccessorNearFullFrameCount)
                    StatusManager.Instance.Controller.CardDatabaseStatus = CardDatabaseStatus.SramDatabaseNotFull;
                else if (mainAccessor.Count < mainAccessorMaxFrameCount)
                    StatusManager.Instance.Controller.CardDatabaseStatus = CardDatabaseStatus.SramDatabase90PercentFull;
                else
                    StatusManager.Instance.Controller.CardDatabaseStatus = CardDatabaseStatus.SramDatabaseFull;
            }
        }

        /// <summary>
        /// Current number of cards in memory.
        /// </summary>
        public int Count
        {
            get
            {
                lock (accessorLock)
                {
                    return mainAccessor.Count;
                }
            }
        }

        /// <summary>
        /// Return all card hashes in one list.
        /// </summary>
        /// <returns></returns>
        public List<long> CardHashes()
        {
            List<long> cardHashes;
            lock (accessorLock)
            {
                cardHashes = mainAccessor.ToList();
            }
            return cardHashes;
        }

#region IDisposable Members

        bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            closing = true;

            if (disposed == false)
            {
                if (disposing)
                {
                    // Free any other managed objects here.
                    if (this.sramMemory != null)
                        sramMemory.Dispose();
                    if (this.sdCardMemory != null)
                        sdCardMemory.Dispose();
                    instance = null;
                }

                // Free any unmanaged objects here.            
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

#endregion

    }
}
