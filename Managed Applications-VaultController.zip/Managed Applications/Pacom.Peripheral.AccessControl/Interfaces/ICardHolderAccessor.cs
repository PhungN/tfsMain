﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Core.Access;

namespace Pacom.Peripheral.AccessControl
{
    public interface ICardAccessor
    {
        int Count
        {
            get;
        }

        bool Set(CardInformation cardInformation);

        bool SetMultiple(List<Credential> cards);

        bool Get(CardNumberHolder cardNumber, out CardInformation cardInformation);

        /// <summary>
        /// Get card information for specific reader Id
        /// </summary>
        /// <returns>True if the card was found, False otherwise.</returns>
        bool GetUnisonCardInformationForSpecificReader(CardNumberHolder cardNumber, int readerId, out CardInformation cardInformation);

        List<CardInformation> GetLegacyCardInformationListForSpecificReader(CardNumberHolder cardNumber, int readerId);

        List<CardInformation> GetLegacyCardInformationList(CardNumberHolder cardNumber);

        CardNumberHolder GetUnisonCardNumber(int cardId);

        bool Exists(CardInformation cardNumber);

        CardNumberHolder GetLeastUsed(out long locationIndex);

        bool GetLocationIndex(int cardId, out long locationIndex);

        List<long> ToList();

        void Delete(CardNumberHolder cardNumber);

        void Delete(long locationIndex);

        void Clear();

        CardAccessDatabaseMode DatabaseMode
        {
            get;
        }

        List<CardNumberHolder> DeleteTemporaryCards();

        bool UpdateCardInformation(CardInformation cardInformation);

#if DEBUG
        List<UniqueCardHolderId> GetUniqueCardHolderIDs();
        CardInformation GetCardInformation(UniqueCardHolderId cardHolder);
#endif
    }
}
