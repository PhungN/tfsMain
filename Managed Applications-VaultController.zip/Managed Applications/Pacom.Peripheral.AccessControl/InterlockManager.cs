﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.AccessControl
{
    public class InterlockManager : IDisposable
    {
        #region Instance

        private static InterlockManager instance = null;

        public static InterlockManager CreateInstance()
        {
            if (instance == null)
            {
                instance = new InterlockManager();
            }
            return instance;
        }

        public static InterlockManager Instance
        {
            get { return instance; }
        }

        #endregion

        #region IDisposable Members

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            try
            {
                if (disposed == true)
                {
                    return;
                }
                if (disposing == true)
                {
                    StatusManager.Instance.Doors.DoorStateChanged -= doorStatusChanged;
                    ConfigurationManager.Instance.ConfigurationChanging -= configurationChanging;
                    ConfigurationManager.Instance.ConfigurationChanged -= configurationChanged;
                    instance = null;
                }
                disposed = true;
            }
            catch (Exception ex)
            {
                Logger.LogWarnMessage(LoggerClassPrefixes.AccessControlManager, () => ex.ToString());
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

        public InterlockManager()
        {
            ConfigurationManager.Instance.ConfigurationChanging += configurationChanging;
            ConfigurationManager.Instance.ConfigurationChanged += configurationChanged;

            configurationChanged(null, null);
        }

        /// <summary>
        /// Configuration is about to change
        /// </summary>
        private void configurationChanging(object sender, ConfigurationChangeEventArgs e)
        {
        //    if (StatusManager.Instance.Doors != null)
        //    {
                StatusManager.Instance.Doors.DoorStateChanged -= doorStatusChanged;
            //}
        }

        /// <summary>
        /// Configuration has changed
        /// </summary>
        private void configurationChanged(object sender, ConfigurationChangeEventArgs e)
        {
            if (StatusManager.Instance.Doors != null)
            {
                StatusManager.Instance.Doors.DoorStateChanged += doorStatusChanged;
            }
            updateAllInterlocksInStatusManager();
        }

        /// <summary>
        /// See if any doors in the specified interlock group are open
        /// </summary>
        /// <param name="interlockId">Interlock ID to check</param>
        /// <returns>true if any doors in the interlock group are currently not closed (e.g. open, ajar, forced, etc.)</returns>
        private bool isInterlockOpen(int interlockId)
        {
            return isInterlockOpen(-1, interlockId);
        }

        /// <summary>
        /// See if any doors in the specified interlock group are open
        /// </summary>
        /// <param name="ignoreDoorId">Optional door to ignore, -1 if not used</param>
        /// <param name="interlockId">Interlock ID to check</param>
        /// <returns>true if any doors in the interlock group are currently not closed (e.g. open, ajar, forced, etc.)</returns>
        private bool isInterlockOpen(int ignoreDoorId, int interlockId)
        {
            InterlockGroupConfiguration interlockGroup = ConfigurationManager.Instance.GetInterlockGroupConfiguration(interlockId);
            InterlockGroupStatus interlockGroupStatus = StatusManager.Instance.InterlockGroups[interlockId];
            if (interlockGroup.Enabled == false ||
                (interlockGroupStatus != null && interlockGroupStatus.Bypassed == true))
            {
                if (interlockGroup.Enabled == false)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl,
                                           () => string.Format("interlock id {0} is disabled, skip", interlockId));
                }
                else if (interlockGroupStatus != null && interlockGroupStatus.Bypassed == true)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl,
                                           () => string.Format("interlock id {0} is bypassed, skip", interlockId));
                }

                // The interlock group is disabled in the configuration, or (temporarily) bypassed
                return false;
            }

            if (interlockGroup.DoorIds == null)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl,
                                           () => string.Format("interlock id {0} has no doors, skip", interlockId));
                return false;
            }

            foreach (int doorId in interlockGroup.DoorIds)
            {
                if (doorId == ignoreDoorId)
                {
                    // don't check this specific door
                    continue;
                }

                if (DoorIsClosed(doorId))
                {
                    // this door is closed, good
                    continue;
                }

                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl,
                                       () => String.Format("Check of interlock {0} has open door {1}",
                                                           interlockId,
                                                           ConfigurationManager.Instance.GetDoorConfiguration(doorId).ToString()));
                return true;
            }

            return false;
        }

        /// <summary>
        /// Is a door known to be closed?
        /// </summary>
        /// <param name="doorId">Door Id to check</param>
        /// <returns>true if the door is considered closed for interlocking purposes</returns>
        public bool DoorIsClosed(int doorId)
        {
            // check door is online (e.g. if on an 8603), and is in a closed state
            DoorStatus doorStatus = StatusManager.Instance.Doors[doorId];
            if (doorStatus == null)
            {
                return true;
            }

            DeviceStatusAbstractBase parentDeviceStatus = StatusManager.Instance.Devices[doorStatus.ParentDeviceId];
            bool parentGood = parentDeviceStatus == null || parentDeviceStatus.Online;
            return parentGood && doorStatus.DoorAgent.OperationState == DoorOperationState.Closed;
        }

        /// <summary>
        /// Find interlock groups for a door, that are enabled and not bypassed
        /// </summary>
        /// <param name="logicalDoorId">Door ID to find interlocks for</param>
        /// <returns>Group Id, or -1 if not found</returns>
        private static int[] activeInterlockIdsForDoor(int logicalDoorId)
        {
            // Is this door part of an interlocking group?
            List<int> interlocks = new List<int>();

            foreach (InterlockGroupConfiguration interlockGroup in ConfigurationManager.Instance.InterlockGroups)
            {
                InterlockGroupStatus interlockGroupStatus = StatusManager.Instance.InterlockGroups[interlockGroup.Id];

                if (interlockGroup.Enabled &&
                    interlockGroupStatus != null &&
                    interlockGroupStatus.Bypassed == false &&
                    interlockGroup.DoorIds != null &&
                    interlockGroup.DoorIds.Contains(logicalDoorId))
                {
                    // We've found an applicable interlock group
                    interlocks.Add(interlockGroup.Id);
                }
            }
            return interlocks.ToArray();
        }

        /// <summary>
        /// A door may have opened or closed
        /// </summary>
        private void doorStatusChanged(object sender, DoorStateChangedEventArgs e)
        {
            if ((e.OldState == DoorOperationState.Closed && e.NewState != DoorOperationState.Closed) || // A door has become open (open, ajar, forced...)
                (e.OldState != DoorOperationState.Closed && e.NewState == DoorOperationState.Closed)) // A door has become closed
            {
                int[] interlockIds = activeInterlockIdsForDoor(e.LogicalDoorId);
                if (interlockIds.Length == 0)
                {
                    // no active interlocks
                    return;
                }

                bool doorWasOpened = e.NewState != DoorOperationState.Closed;

                // Find and update the status of each active interlock that this door is part of
                List<int> changedInterlocks = new List<int>();
                foreach (int interlockId in interlockIds)
                {
                    InterlockGroupStatus interlockGroupStatus = StatusManager.Instance.InterlockGroups[interlockId];
                    if (interlockGroupStatus == null)
                    {
                        continue;
                    }

                    bool open = doorWasOpened || isInterlockOpen(interlockId);
                    if (interlockGroupStatus.IsOpen != open)
                    {
                        interlockGroupStatus.IsOpen = open;
                        if (changedInterlocks.Contains(interlockId) == false)
                        {
                            changedInterlocks.Add(interlockId);
                        }
                    }
                }

                // For each of the active interlocks the door is part of, update the other doors in that interlock group
                List<int> doorsDone = new List<int>();
                doorsDone.Add(e.LogicalDoorId); // Don't do anything on the door that was just opened
                foreach (int interlockId in changedInterlocks) // each affected interlock group
                {
                    foreach (int doorId in ConfigurationManager.Instance.GetInterlockGroupConfiguration(interlockId).DoorIds) // each door in that interlock
                    {
                        if (doorsDone.Contains(doorId))
                        {
                            // We've already done this door
                            continue;
                        }
                        doorsDone.Add(doorId);

                        int blockedByInterlockId;
                        bool canOpenDoor = doorWasOpened == false && CanOpenDoor(doorId, out blockedByInterlockId);
                        DoorStatus door = StatusManager.Instance.Doors[doorId];
                        if (canOpenDoor == true)
                        {
                            door.InterlockClosed();
                        }
                        else
                        {
                            door.InterlockOpened();
                        }
                    }
                }
            }
        }

        private void updateAllInterlocksInStatusManager()
        {
            foreach (InterlockGroupStatus interlockGroupStatus in StatusManager.Instance.InterlockGroups.Items)
            {
                interlockGroupStatus.IsOpen = isInterlockOpen(interlockGroupStatus.LogicalId);
            }
        }

        /// <summary>
        /// Is it OK to open the specified door?
        /// </summary>
        /// <param name="logicalDoorId">Door Id to open</param>
        /// <param name="blockedByInterlockId">Set to non-zero interlock Id on return of false, indicating one (of maybe many) interlocks blocking this door from opening</param>
        /// <returns>true if the door is allowed to be opened</returns>
        public bool CanOpenDoor(int logicalDoorId, out int blockedByInterlockId)
        {
            if (ConfigurationManager.Instance.InterlockGroups.Length == 0)
            {
                // No interlocking configuration at all, so easy answer
                blockedByInterlockId = 0;
                return true; // Allowed
            }

            if (logicalDoorId < 1)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl,
                                       () => string.Format("TryOpenInterlock ALLOWED, not a door"));
                blockedByInterlockId = 0;
                return true; // Allowed
            }

            if (DoorIsClosed(logicalDoorId) == false)
            {
                // The door is already open
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl,
                                       () => string.Format("TryOpenInterlock ALLOWED, already open"));
                blockedByInterlockId = 0;
                return true; // Allowed
            }

            int[] interlockIds = activeInterlockIdsForDoor(logicalDoorId);
            if (interlockIds.Length == 0)
            {
                // Not in any interlock groups, not interlocked
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl,
                                       () => string.Format("TryOpenInterlock ALLOWED, not in any active interlock groups"));
                blockedByInterlockId = 0;
                return true; // Allowed
            }

            foreach (int interlockId in interlockIds)
            {
                if (isInterlockOpen(logicalDoorId, interlockId))
                {
                    // There's a door in that interlock already open
                    blockedByInterlockId = interlockId;
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl,
                                           () => string.Format("TryOpenInterlock DENIED, blocked by interlock {0}", interlockId));
                    return false; // Not allowed
                }

                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl,
                                       () => string.Format("TryOpenInterlock check of interlock {0} OK", interlockId));
            }

            // All good, open the door
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl,
                                   () => string.Format("TryOpenInterlock ALLOWED"));
            blockedByInterlockId = 0;
            return true; // Allowed
        }

        public bool BypassInterlockCommandFromFrontEnd(long idLong, TimeSpan duration, bool restore)
        {
            int id = (int)idLong;
            InterlockGroupStatus interlockGroupStatus = StatusManager.Instance.InterlockGroups[id];
            if (interlockGroupStatus == null)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl,
                                       () => string.Format("bypassInterlock({0}, {1}, {2}) couldn't find group status with that ID", id, duration.ToString(), restore));
                return false;
            }

            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, DebugLoggingSubCategory.AccessControl,
                                   () => string.Format("bypassInterlock({0}, {1}, {2})", id, duration.ToString(), restore));
            interlockGroupStatus.SetBypassedFromFrontEnd(restore == false, (int)duration.TotalSeconds);
            return true;
        }
    }
}
