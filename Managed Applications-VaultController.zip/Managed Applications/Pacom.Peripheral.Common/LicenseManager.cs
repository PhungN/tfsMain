﻿using System;
using System.Globalization;
using System.Security.Cryptography;
using System.Threading;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Status
{
    public class LicenseManager 
    {
        private readonly IDataFlash dataFlash;
        private static LicenseManager instance = null;

        private const int licenseHashSize = 16;
        private const int licenseOffset = 0x52908;
        private const int serialNumberOffset = 0x52800;
        private const int dataFlashPageSize = 264;

        public event EventHandler LicenseChanged;

        public static LicenseManager CreateInstance(IDataFlash dataFlash)
        {
            if (instance == null)
                instance = new LicenseManager(dataFlash);
            return instance;
        }

        public static LicenseManager Instance
        {
            get
            {
                // Lock deliberately ommitted
                return instance;
            }
        }
        
        private uint license1;
        private uint license2;
        private uint license3;
        
        public LicenseManager(IDataFlash dataFlash)
        {
            this.dataFlash = dataFlash;

            for (int i = 0; i < 100; i++)
            {
                if (getLicense(out license1, out license2, out license3))
                    break;
				Thread.Sleep(10);
            }

#if DEBUG_UNLIMITED
            MaximumReaderCount = Int32.MaxValue;
            MaximumDoorCount = Int32.MaxValue;
            MaximumInputCount = Int32.MaxValue;
            MaximumOutputCount = Int32.MaxValue;
#else
            MaximumReaderCount = 16;
            MaximumDoorCount = 8;
            MaximumInputCount = 96;
            MaximumOutputCount = 40;
#endif
        }
        
        public AddLicenseReturnCode AddNewLicense(FeatureToLicense feature, uint code)
        {
            return AddNewLicense(feature, code.ToString("X8"));
        }

        public AddLicenseReturnCode AddNewLicense(FeatureToLicense feature, string code)
        {
            if (code.Length != 8)
                return AddLicenseReturnCode.FailedCodeInvalid;

            byte[] parsedCode = new byte[4];
            try
            {
                for (int i = 0; i < parsedCode.Length; i++)
                {
                    parsedCode[i] = byte.Parse(code.Substring(i * 2, 2), NumberStyles.HexNumber);
                }
            }
            catch
            {
                return AddLicenseReturnCode.FailedCodeInvalid;
            }

            bool valid = false;
            bool enable = true;

            byte code1 = parsedCode[0];
            byte code2 = parsedCode[1];
            bool success = false;

            for (int i = 0; i < 2; i++)
            {
                byte[] serialNumber;
                if (i == 0)
                {
                    enable = true;
                    serialNumber = new byte[8];

                    for (int retry = 0; retry < 20; retry++)
                    {
                        if (getSerialNumber(serialNumber))
                        {
                            success = true;
                            break;
                        }
                    }

                    if (success == false)
                        return AddLicenseReturnCode.FailedApplying;
                }
                else
                {
                    enable = false;
                    serialNumber = new byte[] { 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0 };
                }

                byte result1 = (byte)((int)feature + code1);
                byte result2;

                for (int j = 0; j < serialNumber.Length; j++)
                {
                    result1 = (byte)((result1 ^ serialNumber[j]) + code2);
                }
                result2 = (byte)((result1 ^ code1) + code2);

                if (result1 == parsedCode[2] && result2 == parsedCode[3])
                {
                    valid = true;
                    break;
                }
            }

            if (valid == false)
                return AddLicenseReturnCode.FailedCodeIncorrect;

            if (enable)
                license1 |= (uint)(1 << (int)feature);
            else
                license1 &= ~(uint)(1 << (int)feature);


            success = false;
            for (int retry = 0; retry < 20; retry++)
            {
                if (setLicense(license1, license2, license3))
                {
                    success = true;
                    break;
                }
				Thread.Sleep(100);
            }

            if (success == false)
                return AddLicenseReturnCode.FailedApplying;
            return AddLicenseReturnCode.Success;
        }

        private bool getSerialNumber(byte[] serialNumber)
        {
            return dataFlash.ReadData(serialNumberOffset + 8, serialNumber);
        }

        /// <summary>
        /// The license is based on the 8002 implementation where a 16 bit flag field is used for features as well
        /// as two 8-bit integers for counts.
        /// </summary>
        /// <param name="license1">A 16 bit, bit flag of enabled features.</param>
        /// <param name="license2">An 8 bit count.</param>
        /// <param name="license3">An 8 bit count.</param>
        /// <returns></returns>
        private bool getLicense(out uint license1, out uint license2, out uint license3)
        {
            license1 = 0;
            license2 = 0;
            license3 = 0;

            byte[] licenseBlob = dataFlash.ReadData(licenseOffset, dataFlashPageSize);
            if (licenseBlob == null)
                return false;

            byte[] hash = new byte[licenseHashSize];
            hash = MD5.Create().ComputeHash(licenseBlob, 0, dataFlashPageSize - licenseHashSize);

            if (hash.SequenceEqual(licenseBlob, dataFlashPageSize - licenseHashSize, licenseHashSize))
            {
                license1 = BitConverter.ToUInt32(licenseBlob, 0);
                license2 = BitConverter.ToUInt32(licenseBlob, 4);
                license3 = BitConverter.ToUInt32(licenseBlob, 8);

                return true;
            }

            for (int i = 0; i < dataFlashPageSize; i++)
                licenseBlob[i] = 0;
            hash = MD5.Create().ComputeHash(licenseBlob, 0, dataFlashPageSize - licenseHashSize);
            Buffer.BlockCopy(hash, 0, licenseBlob, dataFlashPageSize - licenseHashSize, licenseHashSize);
            return dataFlash.WriteAndVerifyData(licenseOffset, licenseBlob);
        }

        private bool setLicense(uint license1, uint license2, uint license3)
        {
            byte[] licenseBlob = dataFlash.ReadData(licenseOffset, dataFlashPageSize);
            if (licenseBlob == null)
                return false;

            byte[] temp;
            bool writeRequired = false;
            uint readLicense1 = BitConverter.ToUInt32(licenseBlob, 0);
            uint readLicense2 = BitConverter.ToUInt32(licenseBlob, 4);
            uint readLicense3 = BitConverter.ToUInt32(licenseBlob, 8);
            if (readLicense1 != license1)
            {
                temp = BitConverter.GetBytes(license1);
                Buffer.BlockCopy(temp, 0, licenseBlob, 0, 4);
                writeRequired = true;
            }
            if (readLicense2 != license2)
            {
                temp = BitConverter.GetBytes(license2);
                Buffer.BlockCopy(temp, 0, licenseBlob, 4, 4);
                writeRequired = true;
            }
            if (readLicense3 != license3)
            {
                temp = BitConverter.GetBytes(license3);
                Buffer.BlockCopy(temp, 0, licenseBlob, 8, 4);
                writeRequired = true;
            }
            if (writeRequired == false)
                return true;

            temp = MD5.Create().ComputeHash(licenseBlob, 0, dataFlashPageSize - licenseHashSize);
            Buffer.BlockCopy(temp, 0, licenseBlob, dataFlashPageSize - licenseHashSize, licenseHashSize);
            bool success = dataFlash.WriteAndVerifyData(licenseOffset, licenseBlob);

            if (success == true && LicenseChanged != null)
            {
                LicenseChanged(this, new EventArgs());
            }
            return success;
        }

        public int MaximumReaderCount
        {
            get;
            private set;
        }

        public int MaximumDoorCount
        {
            get;
            private set;
        }

        public int MaximumInputCount
        {
            get;
            private set;
        }

        public int MaximumOutputCount
        {
            get;
            private set;
        }

        public bool PeerToPeer
        {
            get
            {
                if ((license1 & (uint)(1 << 7)) != 0)
                    return true;
                return false;
            }
        }

        public bool RemoteMaintenance
        {
            get
            {
                if ((license1 & (uint)(1 << 10)) != 0)
                    return true;
                return false;
            }
        }

        public bool WirelessAlarms
        {
            get
            {
                if ((license1 & (uint)(1 << 8)) != 0)
                    return true;
                return false;
            }
        }
    }
}
