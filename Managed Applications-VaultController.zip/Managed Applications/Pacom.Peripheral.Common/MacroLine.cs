﻿
namespace Pacom.Peripheral.Macros
{
    public class MacroLine
    {
        public MacroLine(int id)
        {
            this.Id = id;
            this.Condition = string.Empty;
            this.Actions = new string[0];
        }

        public int Id
        {
            get;
            private set;
        }

        public string Condition
        {
            get;            
            set;            
        }

        public string[] Actions
        {
            get;
            set;
        }
    }
}
