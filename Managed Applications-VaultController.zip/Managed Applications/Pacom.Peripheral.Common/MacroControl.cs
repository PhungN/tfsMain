﻿using Pacom.Peripheral.Macros;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Interface functions and properties for interacting with macro engine.
    /// </summary>
    public class MacroControl
    {
        /// <summary>
        /// Singleton instatnce
        /// </summary>
        private static MacroControl instance = null;

        /// <summary>
        /// Instance method to get singleton
        /// </summary>
        /// <returns></returns>
        public static MacroControl Instance
        {
            get
            {
                // Lock deliberately omitted
                if (instance == null)
                {
                    instance = new MacroControl();
                }
                return instance;
            }
        }

        private IMacroManager macroControl = null;

        /// <summary>
        /// Initialization function
        /// </summary>
        public void Initialize(IMacroManager value)
        {
            macroControl = value;
        }

        /// <summary>
        /// Marks the macro control object as disposed
        /// </summary>
        public void ControlDisposed()
        {
            macroControl = null;
        }

        public void EnqueueKeyPadEvent(int deviceId, int userId, int keyId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueKeyPadEvent(deviceId, userId, keyId);
            }
        }

        public void EnqueueKeyPadEvent(int deviceId, int userId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueKeyPadEvent(deviceId, userId);
            }
        }

        public void EnqueueSingleBadgeEvent(int logicalReaderId, long cardId, int groupId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueSingleBadgeEvent(logicalReaderId, cardId, groupId);
            }
        }

        public void EnqueueDoubleBadgeEvent(int logicalReaderId, long cardId, int groupId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueDoubleBadgeEvent(logicalReaderId, cardId, groupId);
            }
        }

        public void EnqueueFrontEndConnectionRestoredEvent()
        {
            if (macroControl != null)
            {
                macroControl.EnqueueFrontEndConnectionRestoredEvent();
            }
        }

        public void EnqueueAreaAlarm(int logicalAreaId, MacroAreaAlarmType areaEvent, bool confirmationTimeExpired)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueAreaAlarm(logicalAreaId, areaEvent, confirmationTimeExpired);
            }
        }

        public void EnqueueAreaModeChanged(int logicalAreaId, int userId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueAreaModeChanged(logicalAreaId, userId);
            }
        }

        public void EnqueueAreaFailedToArmEvent(int logicalAreaId, int userId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueAreaFailedToArmEvent(logicalAreaId, userId);
            }
        }

        public void EnqueueUserAreaChanged(int logicalUserAreaId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueUserAreaChanged(logicalUserAreaId);
            }
        }

        public void EnqueueAnyInputAlarm(int logicalInputId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueAnyInputAlarm(logicalInputId);
            }
        }

        public void EnqueueAnyInputTrouble(int logicalInputId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueAnyInputTrouble(logicalInputId);
            }
        }

        public void EnqueueInputTestStatus(int logicalInputId, InputTestStatus testStatus)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueInputTestStatus(logicalInputId, testStatus);
            }
        }

        public void EnqueueDeviceTamperActive(int logicalDeviceId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueDeviceTamperActive(logicalDeviceId);
            }
        }

        public void EnqueueReaderTamperActive(int logicalReaderId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueReaderTamperActive(logicalReaderId);
            }
        }

        public void EnqueueDeviceSubstitution(int logicalDeviceId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueDeviceSubstitution(logicalDeviceId);
            }
        }

        public void EnqueueUnacknowledgedAlarmsQueueEmptyEvent()
        {
            if (macroControl != null)
            {
                macroControl.EnqueueUnacknowledgedAlarmsQueueEmptyEvent();
            }
        }

        public void EnqueueShortTextMessage(string phoneNumber, string messageBody)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueShortTextMessage(phoneNumber, messageBody);
            }
        }

        public void EnqueueDoorEvent(int logicalDoorId, DoorContextStatus context)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueDoorEvent(logicalDoorId, context);
            }
        }

        public void EnqueueInterlockEvent(int logicalInterlockId, InterlockContextStatus context, int userId, int groupId)
        {
            if (macroControl != null)
            {
                macroControl.EnqueueInterlockEvent(logicalInterlockId, context, userId, groupId);
            }
        }
    }
}
