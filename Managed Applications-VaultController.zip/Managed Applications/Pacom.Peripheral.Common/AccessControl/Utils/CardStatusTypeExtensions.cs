﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Core.Access;

namespace Pacom.Peripheral.Common.AccessControl
{
    public static class CardStatusTypeExtensions
    {
        public static CardStatusType ToUnisonCardStatus(this CardStatusType8003 status)
        {
            if ((status & CardStatusType8003.Blocked) == CardStatusType8003.Blocked)
            {
                return CardStatusType.Blocked;
            }
            else if ((status & CardStatusType8003.Expired) == CardStatusType8003.Expired)
            {
                return CardStatusType.Expired;
            }
            else if ((status & CardStatusType8003.Canceled) == CardStatusType8003.Canceled)
            {
                return CardStatusType.Canceled;
            }
            else if ((status & CardStatusType8003.Lost) == CardStatusType8003.Lost)
            {
                return CardStatusType.Lost;
            }
            return CardStatusType.Valid;
        }

        public static CardStatusType8003 To8003CardStatus(this CardStatusType status)
        {
            switch (status)
            {
                case CardStatusType.Valid: return CardStatusType8003.Valid;
                case CardStatusType.Blocked: return CardStatusType8003.Blocked;
                case CardStatusType.Expired: return CardStatusType8003.Expired;
                case CardStatusType.Canceled: return CardStatusType8003.Canceled;
                case CardStatusType.Lost: return CardStatusType8003.Lost;
                default: return CardStatusType8003.Valid;
            }
        }
    }
}
