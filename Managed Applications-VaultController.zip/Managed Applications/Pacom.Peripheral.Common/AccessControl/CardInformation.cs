﻿using System;
using Pacom.Core.Access;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Commands.CommandsCommon.Legacy;

namespace Pacom.Peripheral.Common.AccessControl
{
    public class CardInformation : IContainsUserIdAndCardNumber
    {
        public const int LegacyReaderScheduleCount = 64;
        public const int LegacyFloorAccessCount = 128;

        /// <summary>
        /// Constructor for deserialization mode.
        /// </summary>
        /// <param name="antipassbackId"></param>
        /// <param name="cardNumber"></param>
        /// <param name="cardStatus"></param>
        /// <param name="lastUsed"></param>
        public CardInformation(DateTime lastUsed)
        {
            UserId = -1;
            LastUsed = lastUsed;
        }

        /// <summary>
        /// Constructor for raw mode.
        /// </summary>
        /// <param name="antipassbackId"></param>
        /// <param name="cardNumber"></param>
        /// <param name="cardStatus"></param>
        /// <param name="lastUsed"></param>
        public CardInformation(int cardId, int userId, CardNumberHolder cardNumber, CardStatusType8003 cardStatus, DateTime lastUsed)
        {
            CardId = cardId;
            UserId = userId;
            CardNumber = cardNumber;
            CardStatus = cardStatus;
            LastUsed = lastUsed;
        }

        /// <summary>
        /// Constructor for legacy mode.
        /// </summary>
        /// <param name="cardNumber"></param>
        /// <param name="blocked"></param>
        /// <param name="expired"></param>
        /// <param name="schedules"></param>
        /// <param name="userPin"></param>
        /// <param name="groupId"></param>
        /// <param name="lastUsed"></param>
        public CardInformation(CardNumberHolder cardNumber, bool blocked, bool expired, int userPin, int groupId, DateTime lastUsed)
        {
            UserId = -1;
            CardNumber = cardNumber;
            Blocked = blocked;
            Expired = expired;
            UserPin = userPin;
            GroupId = groupId;
            LastUsed = lastUsed;
        }

        /// <summary>
        /// Get antipassback unique Id, for legacy card access mode is the 64-bit representation of the card number.
        /// For raw card access mode it is the Card Id.
        /// </summary>
        public long AntipassbackId
        {
            get
            {
                if (CardNumber.IsRawCardFormat)
                    return (long)UserId;
                else
                    return CardNumber.Legacy.AsLong();
            }
        }

        /// <summary>
        /// Holds the card number
        /// </summary>
        public CardNumberHolder CardNumber
        {
            get;
            set;
        }

        /// <summary>
        /// Card Status, can be one of: Valid / Blocked / Lost / Canceled / Expired
        /// In GMS/EMCS mode Blocked and Expired can occur together, in Unison mode 
        /// the enums are independent.
        /// </summary>
        public CardStatusType8003 CardStatus
        {
            get;
            set;
        }

        /// <summary>
        /// Indicates if the card is blocked
        /// </summary>
        public bool Blocked
        {
            get { return (CardStatus & CardStatusType8003.Blocked) == CardStatusType8003.Blocked; }
            set
            {
                if (value == true)
                    CardStatus |= CardStatusType8003.Blocked;
                else
                    CardStatus &= ~CardStatusType8003.Blocked;
            }
        }

        /// <summary>
        /// Indicates if the card is expired
        /// </summary>
        public bool Expired
        {
            get { return (CardStatus & CardStatusType8003.Expired) == CardStatusType8003.Expired; }
            set
            {
                if (value == true)
                    CardStatus |= CardStatusType8003.Expired;
                else
                    CardStatus &= ~CardStatusType8003.Expired;
            }
        }

        /// <summary>
        /// Legacy Card User Flags
        /// </summary>
        public LegacyCardUserFlags UserFlags { get; set; }

        /// <summary>
        /// Last time card was used: read / write
        /// </summary>
        public DateTime LastUsed
        {
            get;
            private set;
        }

        /// <summary>
        /// Start Date
        /// </summary>
        public DateTime StartDate
        {
            get;
            set;
        }

        /// <summary>
        /// End Date
        /// </summary>
        public DateTime EndDate
        {
            get;
            set;
        }

        private bool[] floorsAccess = new bool[LegacyFloorAccessCount];
        public bool[] FloorsAccess
        {
            get { return floorsAccess; }
            set { floorsAccess = value; }
        }
        public int FloorsAccessTimezoneId
        {
            get;
            set;
        }

        public static DateTime ParseStartDate(string text)
        {
            DateTime startDate = new DateTime(2000, 1, 1);
            try
            {
                startDate = DateTime.ParseExact(text, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch
            {
            }

            return startDate;
        }

        public static DateTime ParseEndDate(string text)
        {
            DateTime endDate = new DateTime(9999, 12, 31);
            try
            {
                endDate = DateTime.ParseExact(text, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch
            {
            }

            return endDate;
        }

        public void SetStartDate(string startDate)
        {
            try
            {
                StartDate = DateTime.ParseExact(startDate, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch
            {
                StartDate = new DateTime(2000, 1, 1);
            }
        }

        public void SetEndDate(string endDate)
        {
            try
            {
                EndDate = DateTime.ParseExact(endDate, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch
            {
                EndDate = new DateTime(9999, 12, 31);
            }
        }

        /// <summary>
        /// Check if card is permanant (for GMS only)
        /// </summary>
        public bool IsPermanantCard
        {
            get
            {
                return
                    StartDate.Date == (new DateTime(2000, 1, 1)).Date &&
                    EndDate.Date == (new DateTime(9999, 12, 31)).Date;
            }
        }

        /// <summary>
        /// Set last used date
        /// </summary>
        public void SetLastUsedToNow()
        {
            LastUsed = DateTime.UtcNow;
        }

        /// <summary>
        /// Check if this is a raw card format card hoder item
        /// </summary>
        public bool IsRawCardFormat
        {
            get { return CardNumber.IsRawCardFormat; }
        }

        #region Cardholder Information
        #region Common
        /// <summary>
        /// Get / Set card holder PIN
        /// </summary>
        public int UserPin
        {
            get;
            set;
        }

        /// <summary>
        /// Get / Set card holder GroupId
        /// </summary>
        public int GroupId
        {
            get;
            set;
        }
        #endregion

        #region Legacy Only
        private int[] scheduleIds;

        public int GetSchedule(int readerLogicalId)
        {
            return scheduleIds[readerLogicalId - 1];
        }

        public void SetSchedules(int[] scheduleIds)
        {
            this.scheduleIds = scheduleIds;
        }

        public void SetSchedule(int readerId, int scheduleId)
        {
            if (scheduleIds != null && readerId >= 0 && readerId < scheduleIds.Length)
                scheduleIds[readerId] = scheduleId;
        }
        #endregion

        #region Raw Only
        /// <summary>
        /// Get / Set the cardholder's logical Id
        /// </summary>
        public int UserId
        {
            get;
            set;
        }

        /// <summary>
        /// Get / Set the card's logical Id
        /// </summary>
        public int CardId
        {
            get;
            set;
        }
        #endregion
        #endregion
    }
}
