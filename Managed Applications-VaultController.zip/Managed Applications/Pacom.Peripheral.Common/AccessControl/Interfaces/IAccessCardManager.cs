﻿using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.AccessControl
{
    /// <summary>
    /// Access Control Manager public interface
    /// </summary>
    public interface IAccessCardManager
    {
        /// <summary>
        /// Returns the type of records present ing the card access database
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        CardAccessDatabaseMode DatabaseMode { get; }

        /// <summary>
        /// Removes all credentials from the card database.
        /// Care must be taken as this doesn't inform any peripheral devices. Use AccessControlManager.DeleteAll where possible.
        /// </summary>
        void DeleteAllCardsLocally();

        /// <summary>
        /// Populate the card database capacity and current count for the device information
        /// </summary>
        void PopulateCardInformation(DeviceInformation deviceInformation);
    }
}
