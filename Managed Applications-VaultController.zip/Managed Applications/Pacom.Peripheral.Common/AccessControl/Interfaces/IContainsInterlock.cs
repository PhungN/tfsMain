﻿//namespace Pacom.Peripheral.Common.AccessControl
//{
//    /// <summary>
//    /// An interface for classes that contain an interlock Id
//    /// </summary>
//    public interface IContainsInterlock
//    {
//        int LogicalInterlockId { get; }
//    }
//}
