﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.AccessControl;

namespace Pacom.Peripheral.Common.AccessControl
{
    /// <summary>
    /// An interface for classes that contain both a UserId and CardNumber
    /// </summary>
    public interface IContainsUserIdAndCardNumber
    {
        int UserId { get; }

        CardNumberHolder CardNumber { get; }
    }
}
