﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.AccessControl;

namespace Pacom.Peripheral.Common.AccessControl
{
    /// <summary>
    /// Access Control Manager public interface
    /// </summary>
    public interface IAccessControlManager
    {
        /// <summary>
        /// Adds if not present or updates if present a card in the memory or database
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        bool AddOrUpdateCardInformation(CardInformation cardInformation);

        /// <summary>
        /// Get existing card from the Sram or Sdcard
        /// </summary>
        bool GetCardInformation(CardNumberHolder cardNumber, out CardInformation cardInformation);

        /// <summary>
        /// Get existing card from the Sram or Sdcard
        /// </summary>
        bool GetLegacyCardInformationList(CardNumberHolder cardNumber, out List<CardInformation> cardInformationList);

        /// <summary>
        /// Get existing card from the Sram or Sdcard.
        /// </summary>
        /// <returns>True if the card information was found, False otherwise.</returns>
        bool GetUnisonCardInformationForSpecificReader(CardNumberHolder cardNumber, int readerId, out CardInformation cardInformation);

        /// <summary>
        /// Delete card by card number
        /// </summary>
        void DeleteCard(CardNumberHolder cardNumber, bool peripheralsOnly, bool sendEvent);

        /// <summary>
        /// Download card by card number
        /// </summary>
        /// <param name="cardNumber"></param>
        void DownloadCard(CardNumberHolder cardNumber);

        /// <summary>
        /// Get the count of all stored cards
        /// </summary>
        /// <returns></returns>
        int CountCards();

         /// <summary>
        /// Return all card hashes in one list
        /// </summary>
        /// <returns></returns>
        List<long> CardHashes();

        /// <summary>
        /// Delete all cards from memory or database
        /// </summary>
        void DeleteAll();

        /// <summary>
        /// Event fired when card is deleted
        /// </summary>
        event EventHandler<CardAccessEventArgs> CardDeletedEvent;

        /// <summary>
        /// Event fired when card is deleted
        /// </summary>
        event EventHandler<CardAccessEventArgs> TemporaryCardDeletedEvent;

        /// <summary>
        /// Event fired when card is downloaded
        /// </summary>
        event EventHandler<CardAccessEventArgs> CardDownloadedEvent;

        /// <summary>
        /// Event fired when a valid card is badged the access is granted and the door is opened
        /// </summary>
        event EventHandler<CardAccessEventArgs> CardAccessGrantedEvent;

        /// <summary>
        /// Event fired when a valid card is badged and a valid duress PIN is enterd on the reader keypad
        /// </summary>
        event EventHandler<CardAccessEventArgs> CardAccessGrantedDuressEvent;

        /// <summary>
        /// Event fired when a blocked card is badged and the access will be denied
        /// </summary>
        event EventHandler<CardAccessEventArgs> AccessDeniedCardBlockedEvent;

        /// <summary>
        /// Event fired when an expired card is badged and the access will be denied
        /// </summary>
        event EventHandler<CardAccessEventArgs> AccessDeniedCardExpiredEvent;

        /// <summary>
        /// Event fired when a lost card is badged and the access will be denied
        /// </summary>
        event EventHandler<CardAccessEventArgs> AccessDeniedCardLostEvent;

        /// <summary>
        /// Event fired when a cancelled card is badged and the access will be denied
        /// </summary>
        event EventHandler<CardAccessEventArgs> AccessDeniedCardCancelledEvent;

        /// <summary>
        /// Event fired when a card is badged and the user can't be found or is no longer valid.
        /// </summary>
        event EventHandler<CardAccessEventArgs> AccessDeniedUserInvalidEvent;

        /// <summary>
        /// Event fired when a card that is not in the database is badged.
        /// </summary>
        event EventHandler<CardAccessEventArgs> CardNotProgrammedEvent;

        /// <summary>
        /// Event fired when a card is badged but the access schedule prohibits access.
        /// </summary>
        event EventHandler<CardAccessEventArgs> AccessDeniedScheduleInvalidEvent;

        /// <summary>
        /// Event fired when a card is badged but and card reader is BLOCKED.
        /// </summary>
        event EventHandler<CardAccessEventArgs> AccessDeniedReaderBlockedEvent;

        /// <summary>
        /// Event fired when a card is badged but the card doesn't have permission for the reader.
        /// </summary>
        event EventHandler<CardAccessEventArgs> AccessDeniedReaderInvalidEvent;

        /// <summary>
        /// Event fired when a card is badged on a presence zone entry reader a second time without
        /// badging it on an exit reader and the presence zone has HARD antipassback rules.
        /// </summary>
        event EventHandler<CardAccessEventArgs> AccessDeniedAntiPassbackEvent;

        /// <summary>
        /// Event fired when a card is badged on a presence zone entry reader a second time without
        /// badging it on an exit reader and the presence zone has SOFT antipassback rules.
        /// </summary>
        event EventHandler<CardAccessEventArgs> AccessGrantedAntiPassbackEvent;

        /// <summary>
        /// Event fired when the egress button is pressed and access is granted.
        /// </summary>
        event EventHandler<DoorEventArgs> AccessGrantedEgressEvent;

        /// <summary>
        /// Event fired when the egress button is pressed and access is denied because egress schedule 
        /// prohibits its use.
        /// </summary>
        event EventHandler<DoorEventArgs> AccessDeniedEgressScheduleEvent;

        /// <summary>
        /// Event fired when the egress button is pressed and access is denied because the door mode 
        /// prohibits its use.
        /// </summary>
        event EventHandler<DoorEventArgs> AccessDeniedEgressEvent;

        /// <summary>
        /// Event fired when the egress button is pressed and access is denied because
        /// another door in the interlock group isn't secure.
        /// </summary>
        event EventHandler<AccessDeniedEgressInterlockedEventArgs> AccessDeniedEgressInterlockedEvent;

        /// <summary>
        /// Event fired when a user that would have been otherwise able to open a door was denied access due to
        /// another door in the interlock group being insecure.
        /// </summary>
        event EventHandler<AccessDeniedDoorInterlockedEventArgs> AccessDeniedDoorInterlockedEvent;

        /// <summary>
        /// Event fired when a user enters an invalid PIN on a card reader keypad.
        /// </summary>
        event EventHandler<AccessDeniedInvalidReaderPinEventArgs> AccessDeniedInvalidReaderPinEvent;

        /// <summary>
        /// Event fired when a card reader is locked out. 
        /// </summary>
        event EventHandler<ReaderLockoutEventArgs> ReaderLockoutEvent;
        
        /// <summary>
        /// Triggered when the local device receives a card reader keypad inactivity timeout
        /// expired event. The AlarmManager instance will subscribe to this event.
        /// </summary>
        event EventHandler<ReaderKeypadEventArgs> ReaderKeypadInactivityTimeoutExpired;

        /// <summary>
        /// Triggered when a card operation is required to be forwarded to external systems.
        /// </summary>
        event EventHandler<DeleteCardBroadcastEventArgs> CardNumberBroadcastEvent;

        event EventHandler<CardAccessEventArgs> DualEntryPendingEvent;
        event EventHandler<CardAccessEventArgs> TripleEntryPendingEvent;
        event EventHandler<CardAccessEventArgs> AccessDeniedInvalidDualEntryEvent;
        event EventHandler<CardAccessEventArgs> AccessDeniedInvalidTripleEntryEvent;

        /// <summary>
        /// Process card scanned on the reader.
        /// </summary>
        /// <param name="logicalReaderId">Logical reader id</param>
        /// <param name="legacyCardFormat">Card number data</param>
        void ProcessLegacyCardData(int logicalReaderId, CardNumberHolder legacyCardFormat);

        /// <summary>
        /// Process card scanned on the reader.
        /// </summary>
        /// <param name="logicalReaderId">Logical reader id</param>
        /// <param name="cardData">Card number data</param>
        /// <param name="bitCount">Number of bits in card data</param>
        void ProcessRawCardData(int logicalReaderId, byte[] cardData, int bitCount);

        /// <summary>
        /// Process pin entered on keypad attached to the reader.
        /// </summary>
        /// <param name="logicalReaderId">Logical reader id</param>
        /// <param name="keys">Pin data</param>
        void ProcessPinData(int logicalReaderId, byte[] keys);

        /// <summary>
        /// Process legacy card access event that occurred during degraded mode.
        /// </summary>
        /// <param name="cardNumberData"></param>
        /// <param name="logicalReaderId"></param>
        /// <param name="logicalDoorId"></param>
        void ProcessDegradedModeLegacyCardAccessEvent(CardNumberHolder cardNumberData, int logicalReaderId, int logicalDoorId);

        /// <summary>
        /// Process raw card access event that occurred during degraded mode.
        /// </summary>
        /// <param name="cardNumberData"></param>
        /// <param name="logicalReaderId"></param>
        /// <param name="logicalDoorId"></param>
        void ProcessDegradedModeRawCardAccessEvent(CardNumberHolder cardNumberData, int logicalReaderId, int logicalDoorId);

        /// <summary>
        /// Process access denied. This event can be used to notify the underlying door/reader agent about an invalid card being scanned. 
        /// On local device it can happen when there is collision also.
        /// </summary>
        /// <param name="logicalReaderId"></param>
        void ProcessAccessDenied(int logicalReaderId);

        /// <summary>
        /// Process unauthorized raw card scanned on the reader.
        /// </summary>
        /// <param name="logicalReaderId">Logical reader id</param>
        /// <param name="cardData">Card number data</param>
        /// <param name="bitCount">Number of bits in card data</param>
        void ProcessAccessDeniedUnauthorizedRawCardData(int logicalReaderId, byte[] cardData, int bitCount);

        /// <summary>
        /// Process unauthorized card scanned on the reader.
        /// </summary>
        /// <param name="logicalReaderId">Logical reader id</param>
        /// <param name="legacyCardFormat">Card number data</param>
        void ProcessAccessDeniedUnauthorizedCard(int logicalReaderId, CardNumberHolder legacyCardFormat);

#if DEBUG
        List<UniqueCardHolderId> GetUniqueCardHolderIDs();
        CardInformation GetCardInformation(UniqueCardHolderId cardHolder);
        bool UpdateElevatorFloorsAccess(CardInformation cardInformation);
#endif
    }
}
