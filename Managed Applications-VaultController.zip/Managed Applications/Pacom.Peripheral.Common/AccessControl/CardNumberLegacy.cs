﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common.AccessControl
{
    public class CardNumberLegacy
    {
        public CardNumberLegacy(byte[] facility, byte[] issue, byte[] code)
        {
            if (facility != null && facility.Length > 0)
                Facility = (int)getLongFromData(facility);
            else
                Facility = 0;

            if (issue != null && issue.Length > 0)
                Issue = (int)getLongFromData(issue);
            else
                Issue = 0;

            if (code != null && code.Length > 0)
                Code = getLongFromData(code);
            else
                Code = 0;
        }

        public CardNumberLegacy(int facility, int issue, long code)
        {
            Facility = facility;
            Issue = issue;
            Code = code;
        }

        public CardNumberLegacy(long cardNumber)
        {
            int facility, issue;
            long code;
            ToFacilityIssueCode(cardNumber, out facility, out issue, out code);
            Facility = facility;
            Issue = issue;
            Code = code;
        }

        public int Facility
        {
            get;
            set;
        }

        public int Issue
        {
            get;
            set;
        }

        public long Code
        {
            get;
            set;
        }

        public bool IsValid
        {
            get { return Code > 0; }
        }

        public long AsLong()
        {
            long cardNumber = (long)(Facility & 0xFFFF) << 48;
            cardNumber |= (long)(Issue & 0xFF) << 40;
            cardNumber |= (long)(Code & 0xFFFFFFFFFF);
            return cardNumber;
        }

        public static void ToFacilityIssueCode(long cardNumber, out int facility, out int issue, out long code)
        {
            facility = (int)((cardNumber & 0x7FFF000000000000) >> 48);
            issue = (int)((cardNumber & 0x0000FF0000000000) >> 40);
            code = (long)(cardNumber & 0x000000FFFFFFFFFF);
        }

        public static string ToString(long cardNumber)
        {
            int facility;
            int issue;
            long code;
            ToFacilityIssueCode(cardNumber, out facility, out issue, out code);
            return string.Format("{0}/{1}/{2}", code, issue, facility);
        }

        public override string ToString()
        {
            return string.Format("{0}/{1}/{2}", Code, Issue, Facility);
        }

        public override bool Equals(object obj)
        {
            CardNumberLegacy cardNumber = obj as CardNumberLegacy;
            if (cardNumber == null)
                return false;

            if (cardNumber.Facility.Equals(Facility) == false)
                return false;
            if (cardNumber.Issue.Equals(Issue) == false)
                return false;
            if (cardNumber.Code.Equals(Code) == false)
                return false;

            return true;
        }

        public override int GetHashCode()
        {
            return Facility.GetHashCode() ^
                   Issue.GetHashCode() ^
                   Code.GetHashCode();
        }

        private static long getLongFromData(byte[] data)
        {
            if (data == null || data.Length == 0)
                return 0;

            long result = 0;
            for (int i = 0; i < data.Length; i++)
            {
                result = result << 8;
                result += data[i];
            }
            return result;
        }
    }
}
