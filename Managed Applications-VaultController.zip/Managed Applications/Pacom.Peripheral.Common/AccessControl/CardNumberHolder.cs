﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common.AccessControl
{
    public class CardNumberHolder
    {
        public CardNumberLegacy Legacy { get; private set; }
        public CardNumberRaw Raw { get; private set; }

        public CardNumberHolder(byte[] facility, byte[] issue, byte[] code)
        {
            Legacy = new CardNumberLegacy(facility, issue, code);
            Raw = null;
        }

        public CardNumberHolder(int facility, int issue, long code)
        {
            Legacy = new CardNumberLegacy(facility, issue, code);
            Raw = null;
        }

        public CardNumberHolder(long legacyCardAsLong)
        {
            Legacy = new CardNumberLegacy(legacyCardAsLong);
            Raw = null;
        }

        public CardNumberHolder(byte[] cardNumber, int cardBitLength)
        {
            Legacy = null;
            Raw = new CardNumberRaw(cardNumber, cardBitLength);
        }

        public bool IsRawCardFormat
        {
            get
            {
                if (Raw != null)
                    return true;
                return false;
            }
        }

        public bool IsValid
        {
            get 
            {
                if (Legacy != null && Legacy.IsValid)
                    return true;
                if (Raw != null && Raw.IsValid)
                    return true;
                return false;
            }
        }

        public override bool Equals(object obj)
        {
            CardNumberHolder cardNumber = obj as CardNumberHolder;
            if (cardNumber == null)
                return false;

            if (cardNumber.Raw == null && Raw != null)
                return false;
            if (cardNumber.Raw != null && Raw == null)
                return false;
            if (Raw != null && cardNumber.Raw.Equals(Raw) == false)
                return false;

            if (cardNumber.Legacy == null && Legacy != null)
                return false;
            if (cardNumber.Legacy != null && Legacy == null)
                return false;
            if (Legacy != null && cardNumber.Legacy.Equals(Legacy) == false)
                return false;

            return true;
        }

        public override int GetHashCode()
        {
            int hash = 0;
            if (Legacy != null)
                hash = Legacy.GetHashCode();
            if (Raw != null)
                hash ^= Raw.GetHashCode();
            return hash;
        }

        public override string ToString()
        {
            if (IsRawCardFormat)
            {
                return Raw.ToString();
            }

            return Legacy.ToString();
        }
    }
}
