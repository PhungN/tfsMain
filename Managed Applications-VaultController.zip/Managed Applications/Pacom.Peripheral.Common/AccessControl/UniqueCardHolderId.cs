﻿using System;

namespace Pacom.Peripheral.Common.AccessControl
{
    public struct UniqueCardHolderId
    {
        public long Id;
        public DateTime StartDate;
        public DateTime EndDate;

        public UniqueCardHolderId(long id) : this(id, DateTime.MinValue, DateTime.MinValue) { }
        public UniqueCardHolderId(long id, DateTime startDate, DateTime endDate)
        {
            Id = id;
            StartDate = startDate;
            EndDate = endDate;
        }

        public override string ToString()
        {
            return string.Format("<id>{0}</id><startdate>{1}</startdate><enddate>{2}</enddate>", Id, StartDate.ToString("dd/MM/yyyy"), EndDate.ToString("dd/MM/yyyy"));
        }
    }
}
