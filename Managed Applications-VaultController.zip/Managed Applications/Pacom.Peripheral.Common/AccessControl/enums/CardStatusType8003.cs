﻿using System;

namespace Pacom.Peripheral.Common.AccessControl
{
    [Flags]
    public enum CardStatusType8003
    {
        /// <summary>Valid card status.</summary>
        Valid = 0,
        /// <summary>Blocked card status.</summary>
        Blocked = 1,
        /// <summary>Lost card status.</summary>
        Lost = 2,
        /// <summary>Canceled card status.</summary>
        Canceled = 4,
        /// <summary>Expired card status.</summary>
        Expired = 8,
    }
}
