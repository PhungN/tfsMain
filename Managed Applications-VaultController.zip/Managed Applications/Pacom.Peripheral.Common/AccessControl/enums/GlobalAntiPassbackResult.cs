﻿namespace Pacom.Peripheral.Common.AccessControl
{
    public enum GlobalAntiPassbackResult
    {
        CheckFailed = 0,
        AccessDenied = 1,
        AccessGranted = 2,
        AccessGrantedSoftAntiPassback = 3,
    }
}
