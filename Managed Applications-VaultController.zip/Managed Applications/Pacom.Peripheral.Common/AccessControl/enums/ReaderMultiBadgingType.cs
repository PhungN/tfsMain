﻿namespace Pacom.Peripheral.Common.AccessControl
{
    public enum ReaderBadgingType
    {
        Normal,
        DualEntry,
        TripleEntry,
        Escort
    }
}