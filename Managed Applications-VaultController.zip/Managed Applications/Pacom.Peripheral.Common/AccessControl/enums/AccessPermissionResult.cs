﻿using System;

namespace Pacom.Peripheral.Common.AccessControl
{
    public enum AccessPermissionResult
    {
        Valid = 0,
        InvalidUser = 1,
        InvalidReader = 2,
        InvalidSchedule = 3,
        Expired = 4,
    }
}
