﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.AccessControl
{
    public class CardNumberRaw
    {
        /// <summary>Raw Card Number byte length</summary>
        public const int RawCardNumberLength = 32;

        public CardNumberRaw(byte[] cardNumber, int cardBitLength)
        {
            CardNumber = cardNumber;
            CardBitLength = cardBitLength;
        }

        public int CardBitLength { get; set; }
        public byte[] CardNumber { get; set; }

        public bool IsValid
        {
            get 
            {
                if (CardBitLength > 0 && CardNumber != null && CardNumber.Length > 0)
                    return true;
                return false;
            }
        }

        public override bool Equals(object obj)
        {
            CardNumberRaw cardNumber = obj as CardNumberRaw;
            if (cardNumber == null)
                return false;

            if (cardNumber.CardBitLength.Equals(CardBitLength) == false)
                return false;
            if (cardNumber.CardNumber.SequenceEqual(CardNumber) == false)
                return false;

            return true;
        }

        public override int GetHashCode()
        {
            return CardBitLength.GetHashCode() ^
                   CardNumber.GetHashCode();
        }

        public override string ToString()
        {
            return BitConverter.ToString(CardNumber, 0, ((CardBitLength + 7) / 8));
        }
    }
}
