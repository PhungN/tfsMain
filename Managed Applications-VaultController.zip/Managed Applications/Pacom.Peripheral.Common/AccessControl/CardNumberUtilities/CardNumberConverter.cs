﻿namespace Pacom.Peripheral.Common.AccessControl
{
    public static class CardNumberConverter
    {
        public static CardNumberHolder ToFacilityIssueCodeFormat(byte[] cardNumber, CardFormatDesignatorConfig designators)
        {
            // Allocate byte array for data
            byte[] facility = null,
                   issue = null,
                   code = null;
            if (designators.Facility > 0)
                facility = new byte[(designators.Facility / 8)];
            if (designators.Issue > 0)
                issue = new byte[(designators.Issue / 8)];
            if (designators.Code > 0)
                code = new byte[(designators.Code / 8)];

            // Scan upcomming data and read card records
            int lenFacilityAndIssue = designators.Facility + designators.Issue,
                lenFullCardData = designators.Facility + designators.Issue + designators.Code;
            for (int bitNumber = 0; bitNumber < lenFullCardData; bitNumber++)
            {
                int byteCount = bitNumber / 8;
                int byteData = byteCount;

                if ((bitNumber >= 0) && (bitNumber < designators.Facility))
                {
                    int byteFacility = bitNumber / 8;
                    int bitFacility = bitNumber - (byteFacility * 8);
                    if ((cardNumber[byteData] & (1 << bitFacility)) != 0)
                        facility[facility.Length - byteFacility - 1] |= (byte)(1 << bitFacility);
                }
                else if ((bitNumber >= designators.Facility) && (bitNumber < lenFacilityAndIssue))
                {
                    int byteIssue = (bitNumber - designators.Facility) / 8;
                    int bitIssue = (bitNumber - designators.Facility) - (byteIssue * 8);
                    if ((cardNumber[byteData] & (1 << bitIssue)) != 0)
                        issue[issue.Length - byteIssue - 1] |= (byte)(1 << bitIssue);
                }
                else if ((bitNumber >= lenFacilityAndIssue) && (bitNumber < lenFullCardData))
                {
                    int byteCode = (bitNumber - lenFacilityAndIssue) / 8;
                    int bitCode = (bitNumber - lenFacilityAndIssue) - (byteCode * 8);
                    if ((cardNumber[byteData] & (1 << bitCode)) != 0)
                        code[code.Length - byteCode - 1] |= (byte)(1 << bitCode);
                }
            }

            return new CardNumberHolder(facility, issue, code);
        }

        public static CardNumberHolder ToFacilityIssueCodeFormat(byte[] facility, byte[] issue, byte[] code)
        {
            return new CardNumberHolder(facility, issue, code);
        }
    }
}
