﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    public class ReaderEventArgs : EventArgs
    {
        public ReaderEventArgs(int logicalDoorId, int logicalReaderId, Reader8003ScheduleLevel mode, Reader8003ScheduleLevel previousMode,
                               UserAuditInfo userAuditInfo)
        {
            LogicalDoorId = logicalDoorId;
            LogicalReaderId = logicalReaderId;
            Mode = mode;
            PreviousMode = previousMode;
            UserInfo = userAuditInfo;
        }

        /// <summary>
        /// Get / Set the door logical id for which reader event has occurred
        /// </summary>
        public int LogicalDoorId { get; private set; }

        /// <summary>
        /// Get / Set the reader logical id for which the reader event has occurred
        /// </summary>
        public int LogicalReaderId { get; private set; }

        /// <summary>
        /// Get / Set current reader mode
        /// </summary>
        public Reader8003ScheduleLevel Mode { get; private set; }

        /// <summary>
        /// Get / Set previous reader mode
        /// </summary>
        public Reader8003ScheduleLevel PreviousMode { get; private set; }

        /// <summary>
        /// Get / Set user audit information
        /// </summary>
        public UserAuditInfo UserInfo { get; private set; }
    }
}
