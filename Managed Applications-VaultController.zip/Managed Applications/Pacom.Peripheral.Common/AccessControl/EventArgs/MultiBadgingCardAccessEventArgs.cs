﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.AccessControl
{
    public class MultiBadgingCardAccessEventArgs : EventArgs
    {
        public MultiBadgingCardAccessEventArgs(int logicalDoorId, int logicalReaderId, List<CardInformation> cardInformationList, ReaderBadgingType badgingType)
        {
            LogicalDoorId = logicalDoorId;
            LogicalReaderId = logicalReaderId;
            BadgingType = badgingType;
            CardInformationList = cardInformationList;
        }

        public int LogicalDoorId { get; private set; }
        public int LogicalReaderId { get; private set; }
        public ReaderBadgingType BadgingType { get; private set; }
        public List<CardInformation> CardInformationList { get; private set; }
    }
}
