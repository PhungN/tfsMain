﻿using System;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.AccessControl
{
    public class ReaderKeypadEventArgs : EventArgs
    {
        public ReaderKeypadEventArgs(int logicalReaderId, int logicalDoorId, CardNumberHolder cardNumber)
        {
            LogicalDoorId = logicalDoorId;
            LogicalReaderId = logicalReaderId;
            CardNumber = cardNumber;
        }

        /// <summary>
        /// Get / Set the door logical id for reader keypad for which the inactivity timeout event has occurred
        /// </summary>
        public int LogicalDoorId { get; private set; }

        /// <summary>
        /// Get / Set the reader keypad logical id
        /// </summary>
        public int LogicalReaderId { get; private set; }

        /// <summary>
        /// Get / Set the reader card number
        /// </summary>
        public CardNumberHolder CardNumber { get; private set; }
    }
}
