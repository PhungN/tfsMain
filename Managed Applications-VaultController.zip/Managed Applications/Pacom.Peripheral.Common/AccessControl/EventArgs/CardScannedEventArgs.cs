﻿using System;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.AccessControl
{
    public class CardScannedEventArgs : EventArgs
    {
        private readonly CardNumberHolder cardNumber = null;
        private readonly int logicalDeviceId = 0;
        private readonly int logicalReaderId = 0;
        private readonly int logicalDoorId = 0;

        public CardScannedEventArgs(CardNumberHolder cardNumber, int logicalDeviceId, int logicalReaderId, int logicalDoorId)
        {
            this.cardNumber = cardNumber;
            this.logicalDeviceId = logicalDeviceId;
            this.logicalReaderId = logicalReaderId;
            this.logicalDoorId = logicalDoorId;
        }

        public CardNumberHolder CardNumber
        {
            get { return cardNumber; }
        }

        public int LogicalDeviceId
        {
            get { return logicalDeviceId; }
        }

        public int LogicalReaderId
        {
            get { return logicalReaderId; }
        }

        public int LogicalDoorId
        {
            get { return logicalDoorId; }
        }
    }
}
