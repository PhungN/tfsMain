﻿using System;

namespace Pacom.Peripheral.AccessControl
{
    public class AccessDeniedEgressInterlockedEventArgs : EventArgs
    {
        public AccessDeniedEgressInterlockedEventArgs(int logicalReaderId, int logicalDoorId, int logicalInterlockId)
        {
            LogicalReaderId = logicalReaderId;
            LogicalDoorId = logicalDoorId;
            LogicalInterlockId = logicalInterlockId;
        }

        /// <summary>
        /// The door logical id for which the door event has occurred
        /// </summary>
        public int LogicalDoorId { get; private set; }

        /// <summary>
        /// Get / Set the interlock's logical id, that stopped the door from being opened
        /// </summary>
        public int LogicalInterlockId { get; private set; }

        /// <summary>
        /// Get / Set the reader logical id that the egress button is associated with
        /// </summary>
        public int LogicalReaderId { get; private set; }
    }
}
