﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    public class InterlockBypassedEventArgs : EventArgs
    {
        public InterlockBypassedEventArgs(int logicalInterlockId, bool bypassed, UserAuditInfo userAuditInfo)
        {
            LogicalInterlockId = logicalInterlockId;
            UserInfo = userAuditInfo;
            Bypassed = bypassed;
        }

        public bool Bypassed { get; set; }
        public int LogicalInterlockId { get; private set; }
        public UserAuditInfo UserInfo { get; private set; }
    }
}
