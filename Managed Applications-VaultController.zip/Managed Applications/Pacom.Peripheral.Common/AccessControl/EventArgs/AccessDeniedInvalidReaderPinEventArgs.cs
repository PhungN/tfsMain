﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common.AccessControl
{
    public class AccessDeniedInvalidReaderPinEventArgs : EventArgs
    {
        public AccessDeniedInvalidReaderPinEventArgs(int logicalReaderId, int logicalDoorId, int areaId, CardInformation cardInformation)
        {
            LogicalReaderId = logicalReaderId;
            LogicalDoorId = logicalDoorId;
            AreaId = areaId;
            CardInformation = cardInformation;
        }

        public int LogicalReaderId { get; private set; }

        public int LogicalDoorId { get; private set; }

        public int AreaId { get; private set; }

        public CardInformation CardInformation { get; private set; }
    }
}
