﻿using System;

namespace Pacom.Peripheral.Common.AccessControl
{
    public class ReaderLockoutEventArgs : EventArgs
    {
        public ReaderLockoutEventArgs(int logicalReaderId, bool lockedOut)
        {
            LogicalReaderId = logicalReaderId;
            LockedOut = lockedOut;
        }

        public int LogicalReaderId { get; private set; }

        public bool LockedOut { get; private set; }
    }
}
