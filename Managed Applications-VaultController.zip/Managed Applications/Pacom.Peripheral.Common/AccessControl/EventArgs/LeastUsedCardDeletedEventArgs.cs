﻿using System;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.AccessControl
{
    public class LeastUsedCardDeletedEventArgs : EventArgs
    {
        public LeastUsedCardDeletedEventArgs(CardNumberHolder cardNumber)
        {
            CardNumber = cardNumber;
        }

        /// <summary>
        /// The least used card.
        /// </summary>
        public CardNumberHolder CardNumber { get; private set; }

    }
}
