﻿using System;

namespace Pacom.Peripheral.Common.AccessControl
{
    public class DeleteCardBroadcastEventArgs : EventArgs
    {
        public DeleteCardBroadcastEventArgs(CardNumberHolder cardNumber)
        {
            CardNumber = cardNumber;
        }

        public CardNumberHolder CardNumber { get; private set; }
    }
}
