﻿using System;

namespace Pacom.Peripheral.AccessControl
{
    public class DoorAjarForcedEventArgs : DoorEventArgs
    {
        public DoorAjarForcedEventArgs(int logicalDoorId, bool contactSecure) :
            base(logicalDoorId)
        {
            ContactSecure = contactSecure;
        }

        /// <summary>
        /// Get / Set current door contact status
        /// </summary>
        public bool ContactSecure { get; private set; }
    }
}
