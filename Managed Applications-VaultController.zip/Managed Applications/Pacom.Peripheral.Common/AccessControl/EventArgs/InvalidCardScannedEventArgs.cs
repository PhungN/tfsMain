﻿using System;

namespace Pacom.Peripheral.Common.AccessControl
{
    public class InvalidCardScannedEventArgs : EventArgs
    {
        private readonly int logicalDeviceId = 0;
        private readonly int logicalReaderId = 0;
        private readonly int logicalDoorId = 0;

        public InvalidCardScannedEventArgs(int logicalDeviceId, int logicalReaderId, int logicalDoorId)
        {
            this.logicalDeviceId = logicalDeviceId;
            this.logicalReaderId = logicalReaderId;
            this.logicalDoorId = logicalDoorId;
        }

        public int LogicalDeviceId
        {
            get { return logicalDeviceId; }
        }

        public int LogicalReaderId
        {
            get { return logicalReaderId; }
        }

        public int LogicalDoorId
        {
            get { return logicalDoorId; }
        }
    }
}
