﻿using System;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.AccessControl
{
    public class AccessDeniedDoorInterlockedEventArgs : EventArgs, IContainsUserIdAndCardNumber
    {
        public AccessDeniedDoorInterlockedEventArgs(int logicalReaderId, int logicalDoorId, int logicalInterlockId, CardInformation cardInformation)
        {
            LogicalDoorId = logicalDoorId;
            LogicalReaderId = logicalReaderId;
            LogicalInterlockId = logicalInterlockId;

            CardNumber = cardInformation.CardNumber;
            UserId = cardInformation.UserId;
        }

        public AccessDeniedDoorInterlockedEventArgs(int logicalReaderId, int logicalDoorId, int logicalInterlockId, CardNumberHolder cardNumber) :
            this(logicalReaderId, logicalDoorId, logicalInterlockId, cardNumber, -1)
        {
        }

        public AccessDeniedDoorInterlockedEventArgs(int logicalReaderId, int logicalDoorId, int logicalInterlockId, CardNumberHolder cardNumber, int userId)
        {
            LogicalDoorId = logicalDoorId;
            LogicalReaderId = logicalReaderId;
            LogicalInterlockId = logicalInterlockId;

            CardNumber = cardNumber;
            UserId = userId;
        }

        /// <summary>
        /// Get / Set the card number that was badged
        /// </summary>
        public CardNumberHolder CardNumber { get; private set; }

        /// <summary>
        /// User logical Id or -1 if unused in the case of commands or macros
        /// </summary>
        public int UserId { get; private set; }

        /// <summary>
        /// Get / Set the door logical id for which the card access was granted
        /// </summary>
        public int LogicalDoorId { get; private set; }

        /// <summary>
        /// Get / Set the reader logical id on which the card was badged
        /// </summary>
        public int LogicalReaderId { get; private set; }

        /// <summary>
        /// Get / Set the interlock's logical id, that stopped the door from being opened
        /// </summary>
        public int LogicalInterlockId { get; private set; }
    }
}
