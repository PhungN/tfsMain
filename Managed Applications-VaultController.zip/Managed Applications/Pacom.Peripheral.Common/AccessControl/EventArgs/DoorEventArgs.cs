﻿using System;

namespace Pacom.Peripheral.AccessControl
{
    public class DoorEventArgs : EventArgs
    {
        public DoorEventArgs(int logicalDoorId)
        {
            LogicalDoorId = logicalDoorId;
        }

        /// <summary>
        /// Get / Set the door logical id for which the door event has occurred
        /// </summary>
        public int LogicalDoorId { get; private set; }
    }
}
