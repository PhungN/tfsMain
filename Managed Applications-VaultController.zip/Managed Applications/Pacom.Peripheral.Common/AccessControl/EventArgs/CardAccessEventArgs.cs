﻿using System;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.AccessControl
{
    public class CardAccessEventArgs : EventArgs, IContainsUserIdAndCardNumber
    {
        public CardAccessEventArgs(int logicalDoorId, int logicalReaderId, CardInformation cardInformation) : this(logicalDoorId, logicalReaderId, cardInformation, ReaderBadgingType.Normal)
        {
        }

        public CardAccessEventArgs(int logicalDoorId, int logicalReaderId, CardInformation cardInformation, ReaderBadgingType badgingType)
        {
            LogicalDoorId = logicalDoorId;
            LogicalReaderId = logicalReaderId;
            CardNumber = cardInformation.CardNumber;
            UserId = cardInformation.UserId;
            BadgingType = badgingType;
        }

        public CardAccessEventArgs(int logicalDoorId, int logicalReaderId, CardNumberHolder cardNumber) : this(logicalDoorId, logicalReaderId, cardNumber, -1)
        {
        }

        public CardAccessEventArgs(int logicalDoorId, int logicalReaderId, CardNumberHolder cardNumber, int userId)
        {
            LogicalDoorId = logicalDoorId;
            LogicalReaderId = logicalReaderId;

            CardNumber = cardNumber;
            UserId = userId;
            BadgingType = ReaderBadgingType.Normal;
        }

        /// <summary>
        /// Get / Set the card number that was badged
        /// </summary>
        public CardNumberHolder CardNumber { get; private set; }

        /// <summary>
        /// User logical Id or -1 if unused in the case of commands or macros
        /// </summary>
        public int UserId { get; private set; }

        /// <summary>
        /// Get / Set the door logical id for which the card access was granted
        /// </summary>
        public int LogicalDoorId { get; private set; }

        /// <summary>
        /// Get / Set the reader logical id on which the card was badged
        /// </summary>
        public int LogicalReaderId { get; private set; }

        public ReaderBadgingType BadgingType { get; set; }
    }
}
