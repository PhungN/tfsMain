﻿using System;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.AccessControl
{
    public class CardAndPinEnteredEventArgs : EventArgs
    {
        private readonly CardNumberHolder cardNumber = null;
        private readonly byte[] pinDigits = new byte[0];

        private readonly int logicalReaderId = 0;
        private readonly int logicalDoorId = 0;

        public CardAndPinEnteredEventArgs(CardNumberHolder cardNumber, byte[] pinDigits, int logicalReaderId, int logicalDoorId)
        {
            this.cardNumber = cardNumber;
            this.pinDigits = pinDigits;
            this.logicalReaderId = logicalReaderId;
            this.logicalDoorId = logicalDoorId;
        }

        public CardNumberHolder CardNumber
        {
            get { return cardNumber; }
        }

        public int PinLength
        {
            get { return pinDigits.Length; }
        }

        public int PinAsInteger
        {
            get 
            {
                if (pinDigits.Length == 0)
                    return 0;
                int pin = 0,
                    exponent = pinDigits.Length - 1;
                foreach (var digit in pinDigits)
                {
                    if (digit != 0x0A)
                        pin += digit * (int)Math.Pow(10, exponent);
                    exponent--;
                }
                return pin; 
            }
        }

        public int LogicalReaderId
        {
            get { return logicalReaderId; }
        }

        public int LogicalDoorId
        {
            get { return logicalDoorId; }
        }
    }
}
