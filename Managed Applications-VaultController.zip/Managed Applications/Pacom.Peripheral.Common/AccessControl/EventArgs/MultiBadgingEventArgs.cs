﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.AccessControl
{
    public class MultiBadgingEventArgs : EventArgs
    {
        public MultiBadgingEventArgs(int logicalDoorId, int logicalReaderId, List<CardInformation> cardInformationList)
        {
            LogicalDoorId = logicalDoorId;
            LogicalReaderId = logicalReaderId;
            CardInformationList = cardInformationList;
        }

        public int LogicalDoorId { get; private set; }
        public int LogicalReaderId { get; private set; }
        public List<CardInformation> CardInformationList { get; private set; }
    }
}
