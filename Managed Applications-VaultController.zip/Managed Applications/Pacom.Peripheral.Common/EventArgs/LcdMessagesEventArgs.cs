﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.LcdKeypadStateMachine
{
    public class LcdMessagesEventArgs : EventArgs
    {
        public LcdMessagesEventArgs(List<byte[]> messages)
        {
            Messages = messages;
        }

        public List<byte[]> Messages
        {
            get;
            private set;
        }
    }
}
