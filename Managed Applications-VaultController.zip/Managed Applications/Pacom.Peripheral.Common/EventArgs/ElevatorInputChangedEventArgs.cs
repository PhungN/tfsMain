﻿using System;

namespace Pacom.Peripheral.Common
{
    public class ElevatorInputChangedEventArgs : EventArgs
    {
        public ElevatorInputChangedEventArgs(int deviceId, int inputId)
        {
            DeviceId = deviceId;
            InputId = inputId;
        }

        public int DeviceId { get; private set; }
        public int InputId { get; private set; }
    }
}
