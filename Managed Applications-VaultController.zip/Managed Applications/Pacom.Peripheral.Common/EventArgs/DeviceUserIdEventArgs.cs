﻿namespace Pacom.Peripheral.Common
{
    public class DeviceUserIdEventArgs : BaseDeviceUserIdEventArgs
    {
        public DeviceUserIdEventArgs(int logicalDeviceId, int userId, int areaId) :
            base(logicalDeviceId, userId)
        {
            AreaId = areaId;
        }

        public int AreaId
        {
            get;
            private set;
        }
    }
}
