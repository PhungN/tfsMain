﻿using System;

namespace Pacom.Peripheral.Common
{
    public class StatusManagerDoorChangedIsolatedEventArgs : EventArgs
    {
        public StatusManagerDoorChangedIsolatedEventArgs(Common.Status.DoorStatus doorStatus, bool isolated, UserAuditInfo userAuditInfo)
        {
            this.DoorStatus = doorStatus;
            this.Isolated = isolated;
            UserInfo = userAuditInfo;
        }

        public Common.Status.DoorStatus DoorStatus { get; private set; }

        public bool Isolated { get; private set; }

        public UserAuditInfo UserInfo { get; private set; }
    }
}
