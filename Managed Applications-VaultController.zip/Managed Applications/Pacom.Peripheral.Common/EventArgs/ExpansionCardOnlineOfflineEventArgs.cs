﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class ExpansionCardOnlineOfflineEventArgs : EventArgs
    {
        public ExpansionCardOnlineOfflineEventArgs(int logicalDeviceId, bool offline)
        {
            LogicalDeviceId = logicalDeviceId;
            Offline = offline;
        }

        public int LogicalDeviceId { get; private set; }

        public bool Offline { get; private set; }

    }
}
