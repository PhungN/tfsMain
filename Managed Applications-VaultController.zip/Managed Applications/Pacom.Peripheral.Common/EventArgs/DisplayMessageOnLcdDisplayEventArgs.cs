﻿using System;
using System.Text;

using Pacom.Peripheral.Common.GraphicsKeypad;

namespace Pacom.Peripheral.Common.LcdKeypadStateMachine
{
    public class DisplayMessageOnLcdDisplayEventArgs : EventArgs
    {
        public DisplayMessageOnLcdDisplayEventArgs(byte lcdLine, bool showCursor, byte cursorLocation, byte[] message)
        {
            LcdLine = lcdLine;
            ShowCursor = showCursor;
            CursorLocation = cursorLocation;
            Message = message;
        }

        public byte LcdLine
        {
            get;
            private set;
        }

        public bool ShowCursor
        {
            get;
            private set;
        }

        public byte CursorLocation
        {
            get;
            private set;
        }

        public byte[] Message
        {
            get;
            private set;
        }
    }

    

    

    
    

    public class GraphicsKeypadMenuEventArgs : EventArgs
    {
        public GraphicsKeypadMenuEventArgs(MenuFlags menuFlags, DisplayFlags displayFlags, byte itemIndex, byte bitmap1, byte bitmap2, string text)
        {
            MenuFlags = menuFlags;
            DisplayFlags = displayFlags;
            ItemIndex = itemIndex;
            Bitmap1 = bitmap1;
            Bitmap2 = bitmap2;
            Text = text;
        }

        public MenuFlags MenuFlags { get; private set; }
        public DisplayFlags DisplayFlags { get; private set; }

        /// <summary>
        /// This is the menu item index number. Note that if the Title flag is set then this has no meaning
        /// </summary>
        public byte ItemIndex { get; private set; }

        /// <summary>
        /// This is the leading bitmap image number to display at the front of the menu item. 
        /// A value of 0 means do not display any bitmap. A value of 1 is for the first 
        /// </summary>
        public byte Bitmap1 { get; private set; }

        /// <summary>
        /// This is the trailing bitmap image number to display at end of the menu item. 
        /// This is shown right justified. A value of 0 means do not display any bitmap. 
        /// A value of 1 is for the first bitmap.
        /// </summary>
        public byte Bitmap2 { get; private set; }

        /// <summary>
        /// String text. This is the text for the menu item, unless the title bit is set 
        /// in which case it is text for the menu’s title. 
        /// Note that the 8105 will truncate text greater than 24 characters.
        /// </summary>
        public string Text { get; private set; }

        public byte[] Data
        {
            get
            {
                int textLen = string.IsNullOrEmpty(Text) == true ? 0 : Text.Length;
                byte[] data = new byte[5 + textLen];
                data[0] = (byte)MenuFlags;
                data[1] = (byte)DisplayFlags;
                data[2] = ItemIndex;
                data[3] = Bitmap1;
                data[4] = Bitmap2;
                if (textLen > 0)
                {
                    Array.Copy(Encoding.ASCII.GetBytes(Text), 0, data, 5, textLen);
                }
                return data;
            }
        }
    }

    public class GraphicsKeypadLogoBitmapEventArgs : EventArgs
    {
        public GraphicsKeypadLogoBitmapEventArgs(byte bitmap, byte flags)
        {
            Bitmap = bitmap;
            Flags = flags;
        }

        /// <summary>
        /// This is the bitmap image number to use as the keypads screen saver logo. 
        /// A value of 0 means use the default Pacom logo bitmap. 
        /// </summary>
        public byte Bitmap { get; private set; }

        /// <summary>
        /// Bitmask
	    ///     0x01 = spare
        /// Spare: 
        /// This bit is not yet defined.
        /// </summary>
        public byte Flags { get; private set; }

        public byte[] Data
        {
            get
            {
                return new byte[] { Bitmap, Flags };
            }
        }
    }

    public class GraphicsKeypadBitmapChecksumEventArgs : EventArgs
    {
        public GraphicsKeypadBitmapChecksumEventArgs(byte bitmap, byte type)
        {
            Bitmap = bitmap;
            Type = type;
        }

        /// <summary>
        /// Bitmap reference number. 
        /// If this number is 0xff then the device is to return check sums for all the images it is currently holding.
        /// </summary>
        public byte Bitmap { get; private set; }

        /// <summary>
        /// 0 = simple 16 bit check sum of the bitmap data. 
        /// Note that if the bitmap data is stored on the device with a lossy compression 
        /// then the check sum will have to be stored and returned as it is before the compression.
        /// </summary>
        public byte Type { get; private set; }

        public byte[] Data
        {
            get
            {
                return new byte[2] { Bitmap , Type };
            }
        }
    }

    public class GraphicsKeypadIconButtonEventArgs : EventArgs
    {
        public GraphicsKeypadIconButtonEventArgs(DisplayIconFlags flags, byte itemIndex, byte bitmap, string text)
        {
            Flags = flags;
            ItemIndex = itemIndex;
            Bitmap = bitmap;
            Text = text;
        }

        public DisplayIconFlags Flags { get; private set; }

        /// <summary>
        /// Reference number
        /// </summary>
        public byte ItemIndex { get; private set; }

        /// <summary>
        /// This is the bitmap image number to display at the front of the menu item. 
        /// A value of 0 means do not display any bitmap. A value of 1 is for the first bitmap.
        /// </summary>
        public byte Bitmap { get; private set; }

        /// <summary>
        /// This is the text for the icon item
        /// </summary>
        public string Text { get; private set; }

        public byte[] Data
        {
            get
            {
                int textLen = string.IsNullOrEmpty(Text) == true ? 0 : Text.Length;
                byte[] data = new byte[3 + textLen];
                data[0] = (byte)Flags;
                data[1] = ItemIndex;
                data[2] = Bitmap;
                if (textLen > 0)
                {
                    Array.Copy(Encoding.ASCII.GetBytes(Text), 0, data, 3, textLen);
                }
                return data;
            }
        }
    }

    public class GraphicsKeypadAlertMessageEventArgs : EventArgs
    {
        public GraphicsKeypadAlertMessageEventArgs(AlertMessageFlags flags, BitmapId bitmap, string text)
        {
            Flags = flags;
            Bitmap = bitmap;
            Text = text;
        }

        public AlertMessageFlags Flags { get; private set; }
        public BitmapId Bitmap { get; private set; }
        public string Text { get; private set; }

        public byte[] Data
        {
            get
            {
                int textLen = string.IsNullOrEmpty(Text) == true ? 0 : Text.Length;
                byte[] data = new byte[2 + textLen];
                data[0] = (byte)Flags;
                data[1] = (byte)Bitmap;
                if (textLen > 0)
                {
                    Array.Copy(Encoding.ASCII.GetBytes(Text), 0, data, 2, textLen);
                }
                return data;
            }
        }
    }

    public class GraphicsKeypadBitmapLoadingEventArgs : EventArgs
    {
        public int LogicalId { get; private set; }
        public int BitmapId { get; private set; }
        public GraphicsKeypadBitmapLoadingEventArgs(int logicalId, int bitmapId)
        {
            LogicalId = logicalId;
            BitmapId = bitmapId;
        }
    }
}
