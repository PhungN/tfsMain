﻿using System;

namespace Pacom.Peripheral.Common
{
    public class StatusManagerOutputChangedActiveEventArgs : EventArgs
    {
        public StatusManagerOutputChangedActiveEventArgs(Common.Status.OutputStatus outputStatus, bool active, UserAuditInfo userAuditInfo)
        {
            OutputStatus = outputStatus;
            Active = active;
            UserInfo = userAuditInfo;
        }

        public Common.Status.OutputStatus OutputStatus { get; private set; }

        public bool Active { get; private set; }

        public UserAuditInfo UserInfo { get; private set; }
    }
}
