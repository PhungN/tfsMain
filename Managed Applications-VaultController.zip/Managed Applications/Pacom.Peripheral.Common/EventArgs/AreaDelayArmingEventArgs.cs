﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class AreaDelayArmingEventArgs : EventArgs
    {
        public AreaDelayArmingEventArgs(AreaStatus areaStatus, UserAuditInfo userAuditInfo)
        {
            AreaStatus = areaStatus;
            UserAuditInfo = userAuditInfo;
        }

        public AreaStatus AreaStatus { get; private set; }

        public UserAuditInfo UserAuditInfo { get; private set; }
    }
}
