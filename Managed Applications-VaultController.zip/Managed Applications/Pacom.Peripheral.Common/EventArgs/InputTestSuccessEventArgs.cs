﻿using System;

namespace Pacom.Peripheral.Common
{
    public class InputTestSuccessEventArgs : EventArgs
    {
        public int LogicalInputId { get; private set; }
        public UserAuditInfo UserInfo { get; private set; }
        public InputTestSuccessEventArgs(int logicalInputId, UserAuditInfo userAudioInfo)
        {
            this.LogicalInputId = logicalInputId;
            this.UserInfo = userAudioInfo;
        }
    }
}
