﻿using System;
using Pacom.Core.Access;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common
{
    public class CardDownloadEventArgs : EventArgs
    {
        public CardDownloadEventArgs(List<Credential> cards, bool deleteAllExistingCards)
        {
            Cards = cards;
            DeleteAllExistingCards = deleteAllExistingCards;
        }

        public List<Credential> Cards
        {
            get;
            private set;
        }

        public bool DeleteAllExistingCards
        {
            get;
            set;
        }
    }
}
