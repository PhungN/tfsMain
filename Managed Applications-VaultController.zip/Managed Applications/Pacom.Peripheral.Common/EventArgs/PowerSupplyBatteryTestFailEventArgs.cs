﻿using System;
using Pacom.Events.EventsCommon;
 
namespace Pacom.Peripheral.Common
{
    public class PowerSupplyBatteryTestFailEventArgs : PowerSupplyEventArgs
    {
        public PowerSupplyBatteryTestFailEventArgs(int logicalDeviceId, BatteryTestFailReason reason) :
            base(logicalDeviceId)
        {
            Reason = reason;
        }

        /// <summary>
        /// Get / Set failure reason
        /// </summary>
        public BatteryTestFailReason Reason { get; private set; }
    }
}
