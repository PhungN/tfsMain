﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common
{
    public class FailedToArmAreaEventArgs : EventArgs
    {
        public FailedToArmAreaEventArgs(int areaId, UserAuditInfo userAuditInfo)
        {
            LogicalAreaId = areaId;
            UserId = userAuditInfo.OriginatingUserId;
            UserInfo = userAuditInfo;
        }

        public int LogicalAreaId
        {
            get;
            private set;
        }

        public int UserId
        {
            get;
            private set;
        }

        public UserAuditInfo UserInfo
        {
            get;
            private set;
        }
    }
}
