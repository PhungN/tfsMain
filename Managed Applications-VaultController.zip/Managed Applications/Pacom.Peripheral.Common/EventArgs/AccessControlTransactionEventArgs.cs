﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class AccessControlTransactionEventArgs : EventArgs
    {
        public AccessControlTransactionEventArgs(TransactionType tt)
        {
            LastTransaction = tt;
        }

        public TransactionType LastTransaction
        {
            get;
            private set;
        }
    }
}
