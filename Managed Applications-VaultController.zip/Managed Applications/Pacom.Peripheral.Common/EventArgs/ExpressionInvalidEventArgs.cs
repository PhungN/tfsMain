﻿using System;

namespace Pacom.Peripheral.Common
{
    public class ExpressionInvalidEventArgs : EventArgs
    {
        public ExpressionInvalidEventArgs(int id)
        {
            this.Id = id;
        }

        /// <summary>
        /// Expression logical Id.
        /// </summary>
        public int Id { get; private set; }
    }
}
