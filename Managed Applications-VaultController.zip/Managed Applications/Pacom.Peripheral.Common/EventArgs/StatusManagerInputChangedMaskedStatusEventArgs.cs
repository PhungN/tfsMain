﻿using System;

namespace Pacom.Peripheral.Common
{
    public class StatusManagerInputChangedMaskedStatusEventArgs : EventArgs
    {
        private readonly Common.Status.InputStatus inputStatus;
        private readonly InputStatus maskedStatus;
        private readonly InputStatus previousMaskedStatus;

        public StatusManagerInputChangedMaskedStatusEventArgs(Common.Status.InputStatus inputStatus, InputStatus maskedStatus, InputStatus previousMaskedStatus) : 
            this(inputStatus, maskedStatus, previousMaskedStatus, false)
        {
        }

        public StatusManagerInputChangedMaskedStatusEventArgs(Common.Status.InputStatus inputStatus, InputStatus maskedStatus, InputStatus previousMaskedStatus, bool inTestMode)
        {
            this.inputStatus = inputStatus;
            this.maskedStatus = maskedStatus;
            this.previousMaskedStatus = previousMaskedStatus;
            InTestMode = inTestMode;
        }


        public bool InTestMode { get; private set; }

        public Common.Status.InputStatus InputStatus
        {
            get { return inputStatus; }
        }

        public int InputNumber
        {
            get { return inputStatus.LogicalId; }
        }

        public InputStatus Status
        {
            get { return inputStatus.UnmaskedStatus; }
        }

        public InputStatus MaskedStatus
        {
            get { return maskedStatus; }
        }

        public InputStatus PreviousMaskedStatus
        {
            get { return previousMaskedStatus; }
        }
    }
}
