﻿using System;

namespace Pacom.Peripheral.Common
{
    public class StatusManagerDoorChangedTroubleEventArgs : EventArgs
    {
        public StatusManagerDoorChangedTroubleEventArgs(Common.Status.DoorStatus doorStatus, DoorTroubleType troubleType, bool trouble)
        {
            this.DoorStatus = doorStatus;
            this.Trouble = trouble;
            this.TroubleType = troubleType;
        }

        public Common.Status.DoorStatus DoorStatus { get; private set; }

        public DoorTroubleType TroubleType { get; private set; }

        public bool Trouble { get; private set; }
    }
}
