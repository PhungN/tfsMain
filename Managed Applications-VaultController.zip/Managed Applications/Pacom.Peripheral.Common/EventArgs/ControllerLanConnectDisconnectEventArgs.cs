﻿using System;

namespace Pacom.Peripheral.Common
{
    public class ControllerLanConnectDisconnectEventArgs : EventArgs
    {
        public ControllerLanConnectDisconnectEventArgs(bool connected)
        {
            Connected = connected;
        }

        public bool Connected { get; private set; }
    }
}
