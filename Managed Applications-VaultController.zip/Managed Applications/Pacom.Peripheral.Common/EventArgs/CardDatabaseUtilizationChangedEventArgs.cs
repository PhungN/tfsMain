﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class CardDatabaseUtilizationChangedEventArgs : EventArgs
    {
        public CardDatabaseUtilizationChangedEventArgs(CardDatabaseStatus currentStatus, CardDatabaseStatus previousStatus)
        {
            CurrentStatus = currentStatus;
            PreviousStatus = previousStatus;
        }

        public CardDatabaseStatus CurrentStatus { get; private set; }
        public CardDatabaseStatus PreviousStatus { get; private set; }
    }
}
