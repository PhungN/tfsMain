﻿using System;
using Pacom.Events.EventsCommon;

namespace Pacom.Peripheral.Common
{
    public class FirmwareUpdateEventArgs : EventArgs
    {
        public FirmwareUpdateEventArgs(int logicalDeviceId, DeviceType deviceType, SoftwareDownloadState currentState)
        {
            LogicalDeviceId = logicalDeviceId;
            DeviceType = deviceType;
            CurrentState = currentState;
        }

        public int LogicalDeviceId
        {
            get;
            private set;
        }

        public DeviceType DeviceType
        {
            get;
            private set;
        }

        public SoftwareDownloadState CurrentState
        {
            get;
            private set;
        }
    }
}
