﻿using System;

namespace Pacom.Peripheral.Common.LcdKeypadStateMachine
{
    public class EchoLastCharOnLcdDisplayEventArgs : EventArgs
    {
        public EchoLastCharOnLcdDisplayEventArgs(byte character, byte location, byte lcdLine)
        {
            Character = character;
            Location = location;
            LcdLine = lcdLine;
        }

        public byte Character
        {
            get;
            private set;
        }

        public byte Location
        {
            get;
            private set;
        }

        public byte LcdLine
        {
            get;
            private set;
        }
    }
}
