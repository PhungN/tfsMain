﻿using System;

namespace Pacom.Peripheral.Common
{
    public class PerformExpressionActionEventArgs : EventArgs
    {
        public PerformExpressionActionEventArgs(string action)
        {
            Action = action;
        }

        public string Action
        {
            get;
            private set;
        }
    }
}
