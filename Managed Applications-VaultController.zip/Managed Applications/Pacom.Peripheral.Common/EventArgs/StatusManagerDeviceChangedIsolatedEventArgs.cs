﻿using System;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class StatusManagerDeviceChangedIsolatedEventArgs : EventArgs
    {
        public StatusManagerDeviceChangedIsolatedEventArgs(IDeviceStatusBase deviceStatus, EventSourceLatchOrIsolateType isolatedAlarms, 
                                                           EventSourceLatchOrIsolateType previousIsolatedAlarms, UserAuditInfo userAuditInfo)
        {
            this.DeviceStatus = deviceStatus;
            this.IsolatedAlarms = isolatedAlarms;
            this.PreviousIsolatedAlarms = previousIsolatedAlarms;
            UserInfo = userAuditInfo;
        }

        public IDeviceStatusBase DeviceStatus { get; private set; }

        public EventSourceLatchOrIsolateType IsolatedAlarms { get; private set; }

        public EventSourceLatchOrIsolateType PreviousIsolatedAlarms { get; private set; }

        public UserAuditInfo UserInfo { get; private set; }
    }
}
