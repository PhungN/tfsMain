﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class ItemStatusChangedEventArgs : EventArgs
    {
        public ItemStatusChangedEventArgs(int itemlogicalId, bool newItemStatus)
        {
            LogicalId = itemlogicalId;
            Status = newItemStatus;
        }

        /// <summary>
        /// Returns the Status Item Status.
        /// </summary>
        public bool Status
        {
            get;
            private set;
        }

        /// <summary>
        /// Item Status logical Id
        /// </summary>
        public int LogicalId
        {
            get;
            private set;
        }
    }
}
