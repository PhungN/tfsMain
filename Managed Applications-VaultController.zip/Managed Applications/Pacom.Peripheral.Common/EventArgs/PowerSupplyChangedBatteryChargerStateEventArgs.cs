﻿using System;
using Pacom.Events.EventsCommon;

namespace Pacom.Peripheral.Common
{
    public class PowerSupplyChangedBatteryChargerStateEventArgs : PowerSupplyEventArgs
    {
        public PowerSupplyChangedBatteryChargerStateEventArgs(int logicalDeviceId, bool failed, bool previouslyFailed) :
            base(logicalDeviceId)
        {
            Failed = failed;
            PreviouslyFailed = previouslyFailed;
        }

        /// <summary>
        /// Get / Set power supply status
        /// </summary>
        public bool Failed { get; private set; }

        /// <summary>
        /// Get / Set power supply previous status
        /// </summary>
        public bool PreviouslyFailed { get; private set; }
    }
}
