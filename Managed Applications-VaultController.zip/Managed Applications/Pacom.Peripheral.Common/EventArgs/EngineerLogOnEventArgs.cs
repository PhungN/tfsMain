﻿using System;

namespace Pacom.Peripheral.Common
{
    public class EngineerLogOnEventArgs : ItemStatusAreaChangedEventArgs
    {
        public EngineerLogOnEventArgs(int logicalId, int areaId, UserAuditInfo userAuditInfo, int groupId, bool status)
            : base(logicalId, areaId, status)
        {
            UserId = userAuditInfo.OriginatingUserId;
            UserInfo = userAuditInfo;
            GroupId = groupId;
        }

        public int UserId
        {
            get;
            private set;
        }

        public int GroupId
        {
            get;
            private set;
        }

        public UserAuditInfo UserInfo
        {
            get;
            private set;
        }
    }
}
