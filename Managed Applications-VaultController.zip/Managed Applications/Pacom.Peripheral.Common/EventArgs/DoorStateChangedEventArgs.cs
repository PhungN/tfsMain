﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.AccessControl
{
    public class DoorStateChangedEventArgs : EventArgs
    {
        public DoorStateChangedEventArgs(int logicalId, DoorOperationState oldState, DoorOperationState newState)
        {
            LogicalDoorId = logicalId;
            OldState = oldState;
            NewState = newState;
        }

        public int LogicalDoorId { get; private set; }
        public DoorOperationState OldState { get; private set; }
        public DoorOperationState NewState { get; private set; }
    }
}
