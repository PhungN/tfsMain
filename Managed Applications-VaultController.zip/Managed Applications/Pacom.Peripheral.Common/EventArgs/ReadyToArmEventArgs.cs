﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class ReadyToArmEventArgs : EventArgs
    {
        public ReadyToArmEventArgs(AreaStatus areaStatus, bool readyToArm)
        {
            LogicalAreaId = areaStatus.LogicalId;
            ReadyToArm = readyToArm;
        }

        public int LogicalAreaId
        {
            get;
            private set;
        }

        public bool ReadyToArm
        {
            get;
            private set;
        }
    }
}
