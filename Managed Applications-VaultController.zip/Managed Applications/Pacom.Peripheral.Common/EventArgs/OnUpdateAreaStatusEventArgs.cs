﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class OnUpdateAreaStatusEventArgs : EventArgs
    {
        private readonly AreaStatus areaStatus = null;
        public OnUpdateAreaStatusEventArgs(AreaStatus areaStatus)
        {
            this.areaStatus = areaStatus;
        }

        public AreaStatus AreaStatus
        {
            get { return areaStatus; }
        }
    }
}
