﻿using System;
namespace Pacom.Peripheral.Common
{
    public class DeviceAlarmChangedStateEventArgs : EventArgs
    {
        public IDeviceStatusBase Status { get; private set; }

        public DeviceAlarmChangedStateEventArgs(IDeviceStatusBase status)
        {
            Status = status;
        }
    }
}
