﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common
{
    public class ConfigurationChangeEventArgs : EventArgs
    {
        // This is required as several places in code call configurationChanged for first time initialization
        public ConfigurationChangeEventArgs(ConfigurationElementsAffected configurationElementsAffected)
        {
            ConfigurationElementsAffected = configurationElementsAffected;

            ForceConfigurationChange = true;
            AnythingAdded = true;
            AnythingChanged = true;
            AnythingRemoved = true;
            ControllerChanged = true;
            ControllerLocalPeripheralsAffected = true;
            AnyNonControllerDevicesAffected = true;
            ConnectionTableAffected = true;
        }

        public ConfigurationChangeEventArgs(ConfigurationElementsAffected configurationElementsAffected, List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems)
        {
            ConfigurationElementsAffected = configurationElementsAffected;
            NewlyAddedItems = newlyAddedItems;
            ChangedItems = changedItems;
            RemovedItems = removedItems;

            AnythingAdded = NewlyAddedItems.Count > 0;
            AnythingChanged = ChangedItems.Count > 0;
            AnythingRemoved = RemovedItems.Count > 0;
            
            AffectedDevices = new List<int>();
            updateFlagsAndAffected(removedItems, true);
            updateFlagsAndAffected(changedItems, true);
            updateFlagsAndAffected(newlyAddedItems, false);
        }

        private void updateFlagsAndAffected(List<ConfigurationChanges> list, bool addItemItself)
        {
            foreach (ConfigurationChanges item in list)
            {
                updateFlags(item);

                // Check if an existing device or something attached to the device was changed
                if (addItemItself && item.ConfigurationType == ConfigurationElementType.Device && AffectedDevices.Contains(item.Id) == false)
                {
                    AffectedDevices.Add(item.Id);
                }

                if (item.ParentDeviceId > 0 && AffectedDevices.Contains(item.ParentDeviceId) == false)
                {
                    AffectedDevices.Add(item.ParentDeviceId);
                }

                // Grandparent is only ever set if the item is on an expansion card
                if (item.GrandParentDeviceId > 0 && AffectedDevices.Contains(item.GrandParentDeviceId) == false)
                {
                    AffectedDevices.Add(item.GrandParentDeviceId);
                }
            }
        }

        private void updateFlags(ConfigurationChanges item)
        {
            int controllerLogicalId = ConfigurationManager.Instance.ControllerConfiguration.Id;
            if (item.ConfigurationType == ConfigurationElementType.Device)
            {
                if (item.Id == controllerLogicalId)
                    ControllerChanged = true;
                else
                    AnyNonControllerDevicesAffected = true;
            }
            else if (item.ConfigurationType == ConfigurationElementType.ExpansionCard)
            {
                if (item.ParentDeviceId == controllerLogicalId)
                    ControllerLocalPeripheralsAffected = true;
                else
                    AnyNonControllerDevicesAffected = true;
            }
            else if (item.ConfigurationType == ConfigurationElementType.Input ||
                     item.ConfigurationType == ConfigurationElementType.Output ||
                     item.ConfigurationType == ConfigurationElementType.Reader ||
                     item.ConfigurationType == ConfigurationElementType.Door)
            {
                if (item.ParentDeviceId == controllerLogicalId || item.GrandParentDeviceId == controllerLogicalId)
                    ControllerLocalPeripheralsAffected = true;
                else
                    AnyNonControllerDevicesAffected = true;
            }
            else if (item.ConfigurationType == ConfigurationElementType.ControllerConnectionTable)
            {
                ConnectionTableAffected = true;
            }
        }

        public bool ForceConfigurationChange { get; private set; }
        public bool AnythingAdded { get; private set; }
        public bool AnythingChanged { get; private set; }
        public bool AnythingRemoved { get; private set; }
        public bool AnythingAddedChangedOrRemoved { get { return AnythingAdded | AnythingChanged | AnythingRemoved; } }
        public bool ControllerChanged { get; private set; }
        public bool ControllerLocalPeripheralsAffected { get; private set; }
        public bool AnyNonControllerDevicesAffected { get; private set; }
        public bool ConnectionTableAffected { get; private set; }

        public bool ContainsChange(ConfigurationElementType type, int id, bool searchNew, bool searchChanged, bool seachRemoved)
        {
            if (ForceConfigurationChange)
                return true;

            if (searchNew)
            {
                foreach (ConfigurationChanges item in NewlyAddedItems)
                {
                    if (item.ConfigurationType == type && item.Id == id)
                        return true;
                }
            }
            if (searchChanged)
            {
                foreach (ConfigurationChanges item in ChangedItems)
                {
                    if (item.ConfigurationType == type && item.Id == id)
                        return true;
                }
            }
            if (seachRemoved)
            {
                foreach (ConfigurationChanges item in RemovedItems)
                {
                    if (item.ConfigurationType == type && item.Id == id)
                        return true;
                }
            }

            return false;
        }

        public bool ContainsChange(ConfigurationElementType type, List<int> ids, bool searchNew, bool searchChanged, bool seachRemoved)
        {
            if (ForceConfigurationChange)
                return true;

            if (searchNew)
            {
                foreach (ConfigurationChanges item in NewlyAddedItems)
                {
                    if (item.ConfigurationType == type && ids.Contains(item.Id))
                        return true;
                }
            }
            if (searchChanged)
            {
                foreach (ConfigurationChanges item in ChangedItems)
                {
                    if (item.ConfigurationType == type && ids.Contains(item.Id))
                        return true;
                }
            }
            if (seachRemoved)
            {
                foreach (ConfigurationChanges item in RemovedItems)
                {
                    if (item.ConfigurationType == type && ids.Contains(item.Id))
                        return true;
                }
            }

            return false;
        }

        public bool ContainsChange(ConfigurationElementType type, bool searchNew, bool searchChanged, bool seachRemoved)
        {
            if (ForceConfigurationChange)
                return true;

            if (searchNew)
            {
                foreach (ConfigurationChanges item in NewlyAddedItems)
                {
                    if (item.ConfigurationType == type)
                        return true;
                }
            }
            if (searchChanged)
            {
                foreach (ConfigurationChanges item in ChangedItems)
                {
                    if (item.ConfigurationType == type)
                        return true;
                }
            }
            if (seachRemoved)
            {
                foreach (ConfigurationChanges item in RemovedItems)
                {
                    if (item.ConfigurationType == type)
                        return true;
                }
            }

            return false;
        }

        public ConfigurationElementsAffected ConfigurationElementsAffected
        {
            get;
            private set;
        }

        public List<ConfigurationChanges> NewlyAddedItems
        {
            get;
            private set;
        }

        public List<ConfigurationChanges> ChangedItems
        {
            get;
            private set;
        }

        public List<ConfigurationChanges> RemovedItems
        {
            get;
            private set;
        }

        public List<int> AffectedDevices
        {
            get;
            private set;
        }

        private static void appendItemList(string title, List<ConfigurationChanges> list, StringBuilder sb)
        {
            sb.Append(" ");
            sb.Append(title);
            sb.AppendLine(":");
            if (list == null || list.Count == 0)
            {
                sb.AppendLine("  None");
                return;
            }

            foreach (ConfigurationChanges item in list)
            {
                sb.AppendLine(String.Format("  {0} ID {1} Parent {2} GrandParent {3}",
                                            item.ConfigurationType.ToString(), item.Id, item.ParentDeviceId, item.GrandParentDeviceId));
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("ConfigurationChangeEventArgs:");
            sb.AppendLine(String.Format(" ForceConfigurationChange {0}", ForceConfigurationChange ? "yes" : "no"));
            sb.AppendLine(String.Format(" AnythingAdded {0}", AnythingAdded ? "yes" : "no"));
            sb.AppendLine(String.Format(" AnythingChanged {0}", AnythingChanged ? "yes" : "no"));
            sb.AppendLine(String.Format(" AnythingRemoved {0}", AnythingRemoved ? "yes" : "no"));
            sb.AppendLine(String.Format(" AnythingAddedChangedOrRemoved {0}", AnythingAddedChangedOrRemoved ? "yes" : "no"));
            sb.AppendLine(String.Format(" ControllerChanged {0}", ControllerChanged ? "yes" : "no"));
            sb.AppendLine(String.Format(" ControllerLocalPeripheralsAffected {0}", ControllerLocalPeripheralsAffected ? "yes" : "no"));
            sb.AppendLine(String.Format(" AnyNonControllerDevicesAffected {0}", AnyNonControllerDevicesAffected ? "yes" : "no"));
            sb.AppendLine(String.Format(" ConfigurationElementsAffected {0:x3}", ConfigurationElementsAffected.ToString()));

            appendItemList("Newly Added Items", NewlyAddedItems, sb);
            appendItemList("Changed Items", ChangedItems, sb);
            appendItemList("Removed Items", RemovedItems, sb);

            return sb.ToString();
        }
    }
}
