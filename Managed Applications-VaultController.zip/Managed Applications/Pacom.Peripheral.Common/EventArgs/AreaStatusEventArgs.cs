﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class AreaStatusEventArgs : EventArgs
    {
        public AreaStatusEventArgs(AreaStatus areaStatus)
        {
            AreaStatus = areaStatus;
        }

        public AreaStatus AreaStatus
        {
            get;
            private set;
        }
    }
}
