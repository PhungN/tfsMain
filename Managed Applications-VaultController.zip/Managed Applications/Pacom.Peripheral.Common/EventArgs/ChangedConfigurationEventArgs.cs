﻿using System;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class ChangedConfigurationEventArgs : EventArgs
    {
        public ChangedConfigurationEventArgs(int controllerId, string identifier, UserAuditInfo userAuditInfo)
        {
            ControllerId = controllerId;
            Identifier = identifier;
            UserInfo = userAuditInfo;
        }

        public int ControllerId
        {
            get;
            private set;
        }

        public string Identifier
        {
            get;
            private set;
        }

        public UserAuditInfo UserInfo
        {
            get;
            private set;
        }
    }

    public class ConfigurationChangeInProgressEventArgs : ChangedConfigurationEventArgs
    {
        public ConfigurationChangeInProgressEventArgs(int controllerId, string identifier, UserAuditInfo userAuditInfo) :
            base(controllerId, identifier, userAuditInfo)
        {
        }
    }

}