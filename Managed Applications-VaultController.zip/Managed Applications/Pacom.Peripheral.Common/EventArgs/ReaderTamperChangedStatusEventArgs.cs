﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class ReaderTamperChangedStatusEventArgs : EventArgs
    {
        private readonly ReaderStatus readerStatus = null;
        private readonly bool previousTamperActive = false;

        public ReaderTamperChangedStatusEventArgs(ReaderStatus readerStatus, bool previousTamperActive)
        {
            this.readerStatus = readerStatus;
            this.previousTamperActive = previousTamperActive;
        }

        /// <summary>
        /// Returns true if tamper is active.
        /// </summary>
        public bool TamperActive
        {
            get { return readerStatus.TamperActive; }
        }

        public bool PreviousTamperActive
        {
            get { return previousTamperActive; }
        }

        public int LogicalReaderId
        {
            get { return readerStatus.LogicalId; }
        }
    }
}
