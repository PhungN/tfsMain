﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Common.LcdKeypadStateMachine
{
    public class UpdateAllLedsEventArgs : EventArgs
    {
        public UpdateAllLedsEventArgs(LedColour[] ledColours)
        {
            LedColours = ledColours;
        }

        public LedColour[] LedColours
        {
            get;
            private set;
        }
    }
}
