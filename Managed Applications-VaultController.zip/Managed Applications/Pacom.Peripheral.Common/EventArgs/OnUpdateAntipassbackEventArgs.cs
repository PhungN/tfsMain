﻿using System;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.Common
{
    public class OnUpdateAntipassbackEventArgs : EventArgs
    {
        public OnUpdateAntipassbackEventArgs(int logicalDoorId, int logicalReaderId, CardInformation cardInformation)
        {
            LogicalReaderId = logicalReaderId;
            CardInformation = cardInformation;
            LogicalDoorId = logicalDoorId;
        }

        public int LogicalDoorId { get; private set; }

        public int LogicalReaderId { get; private set; }

        public CardInformation CardInformation { get; private set; }
    }
}
