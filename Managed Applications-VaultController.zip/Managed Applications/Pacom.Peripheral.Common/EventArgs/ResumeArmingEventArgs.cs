﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common
{
    public class ResumeArmingEventArgs : EventArgs
    {
        private readonly List<int> areaIdsList = new List<int>();

        public ResumeArmingEventArgs(List<int> areaIds)
        {
            areaIdsList = areaIds;
        }

        public List<int> AreaIds
        {
            get { return areaIdsList; }
        }
    }
}
