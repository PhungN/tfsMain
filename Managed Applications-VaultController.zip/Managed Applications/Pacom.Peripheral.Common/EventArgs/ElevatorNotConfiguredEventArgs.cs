﻿using System;

namespace Pacom.Peripheral.Common
{
    public class ElevatorNotConfiguredEventArgs : EventArgs
    {
        public ElevatorNotConfiguredEventArgs(int logicalDeviceId, int elevatorNumber)
        {
            LogicalDeviceId = logicalDeviceId;
            ElevatorNumber = elevatorNumber;
        }

        public int LogicalDeviceId { get; private set; }
        public int ElevatorNumber { get; private set; }
    }
}
