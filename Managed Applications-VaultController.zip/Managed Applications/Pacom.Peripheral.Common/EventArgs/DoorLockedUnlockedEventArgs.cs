﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class DoorLockedUnlockedEventArgs : EventArgs
    {
        private readonly DoorStatus doorStatus = null;
        private readonly bool unlocked = false;

        public DoorLockedUnlockedEventArgs(DoorStatus doorStatus, bool unlocked)
        {
            this.doorStatus = doorStatus;
            this.unlocked = unlocked;
        }

        public DoorStatus DoorStatus
        {
            get { return doorStatus; }
        }

        public bool Unlocked
        {
            get { return unlocked; }
        }
    }
}
