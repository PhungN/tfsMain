﻿using System;

namespace Pacom.Peripheral.Common.LcdKeypadStateMachine
{
    public class UpdateCustomCharacterEventArgs : EventArgs
    {
        public UpdateCustomCharacterEventArgs(byte programmableCharacterId, byte[] newBitPattern)
        {
            ProgrammableCharacterId = programmableCharacterId;
            BitPattern = newBitPattern;
        }

        public byte ProgrammableCharacterId
        {
            get;
            private set;
        }

        public byte[] BitPattern
        {
            get;
            private set;
        }
    }
}
