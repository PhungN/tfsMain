﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class TamperChangedStatusEventArgs : EventArgs
    {
        public TamperChangedStatusEventArgs(IDeviceStatusBase deviceStatus, bool previousTamperActive)
        {
            LogicalDeviceId = deviceStatus.LogicalId;
            TamperActive = deviceStatus.MaskedTamperActive;
            PreviousTamperActive = previousTamperActive;
        }

        /// <summary>
        /// Returns true if masked tamper is active.
        /// </summary>
        public bool TamperActive
        {
            get;
            private set;
        }

        public bool PreviousTamperActive
        {
            get;
            private set;
        }

        public int LogicalDeviceId
        {
            get;
            private set;
        }
    }
}
