﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class AreaChangedDuressModeEventArgs : EventArgs
    {
        private readonly AreaStatus areaStatus;

        private readonly bool duressActive;

        public AreaChangedDuressModeEventArgs(AreaStatus areaStatus, bool duressActive)
        {
            this.areaStatus = areaStatus;
            this.duressActive = duressActive;
        }

        public int LogicalAreaId
        {
            get { return areaStatus.LogicalId; }
        }

        public bool DuressActive
        {
            get { return duressActive; }
        }
    }
}
