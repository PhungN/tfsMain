﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class AreaConfirmedAlarmEventArgs : EventArgs
    {
        public AreaConfirmedAlarmEventArgs(AreaStatus areaStatus, UserAuditInfo userAuditInfo)
        {
            LogicalAreaId = areaStatus.LogicalId;
            HasConfirmedAlarm = areaStatus.HasConfirmedAlarm;
            UserInfo = userAuditInfo;
        }

        public int LogicalAreaId
        {
            get;
            private set;
        }

        public bool HasConfirmedAlarm
        {
            get;
            private set;
        }

        public UserAuditInfo UserInfo
        {
            get;
            private set;
        }
    }
}
