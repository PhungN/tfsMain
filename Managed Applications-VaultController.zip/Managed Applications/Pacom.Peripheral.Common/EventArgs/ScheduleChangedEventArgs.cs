﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common
{
    public class SchedulesChangedEventArgs : EventArgs
    {
        public List<ScheduleIntervalDetails> ScheduleIntervalDetailsList { get; set; }
        public SchedulesChangedEventArgs(List<ScheduleIntervalDetails> scheduleIntervalDetailsList)
        {
            ScheduleIntervalDetailsList = scheduleIntervalDetailsList;
        }
    }
}
