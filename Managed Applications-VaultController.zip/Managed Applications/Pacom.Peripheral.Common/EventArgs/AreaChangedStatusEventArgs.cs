﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class AreaChangedStatusEventArgs : EventArgs
    {
        public AreaChangedStatusEventArgs(AreaStatus areaStatus, UserAuditInfo userAuditInfo)
        {
            LogicalAreaId = areaStatus.LogicalId;
            Status = areaStatus.Mode;
            UserId = userAuditInfo.OriginatingUserId;
            UserInfo = userAuditInfo;
        }

        public int LogicalAreaId
        {
            get;
            private set;
        }

        public AreaScheduleLevel Status
        {
            get;
            private set;
        }

        public int UserId
        {
            get;
            private set;
        }

        public UserAuditInfo UserInfo
        {
            get;
            private set;
        }
    }
}
