﻿using System;
namespace Pacom.Peripheral.Common
{
    public class ExpansionCardAlarmChangedStateEventArgs : EventArgs
    {
        public Pacom.Peripheral.Common.Status.ExpansionCardStatus Status { get; private set; }

        public ExpansionCardAlarmChangedStateEventArgs(Pacom.Peripheral.Common.Status.ExpansionCardStatus status)
        {
            Status = status;
        }
    }
}
