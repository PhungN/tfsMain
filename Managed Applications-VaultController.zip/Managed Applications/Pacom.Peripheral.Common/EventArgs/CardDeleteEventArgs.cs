﻿using System;
using Pacom.Core.Access;

namespace Pacom.Peripheral.Common
{
    public class CardDeleteEventArgs : EventArgs
    {
        public CardDeleteEventArgs(int cardId)
        {
            CardIds = new int[1];
            CardIds[0] = cardId;
        }

        public CardDeleteEventArgs(int[] cardIds)
        {
            CardIds = cardIds;
        }

        public int[] CardIds
        {
            get;
            private set;
        }
    }
}
