﻿using System;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.EventQueue
{
    /// <summary>
    /// Event argument uset to signal new event added to the queue. It has added some statistics.
    /// </summary>
    public class NewEventAddedEventArgs : EventArgs
    {
        private readonly int[] countOfEvents;
        private readonly bool[] highPriorityPresent;

        public NewEventAddedEventArgs(int[] countOfEvents, bool[] highPriorityPresent, EventMessageBase eventMessage)
        {
            this.countOfEvents = countOfEvents;
            this.highPriorityPresent = highPriorityPresent;
            EventMessage = eventMessage;
        }

        /// <summary>
        /// An array with 8 integer values representing total number of events on the queue for a system.
        /// </summary>
        public int[] CountOfEvents 
        {
            get { return this.countOfEvents; }
        }

        /// <summary>
        /// An array with 8 boolean values indicating high priority events on the event queue for a system.
        /// </summary>
        public bool[] HighPriorityPresent
        {
            get { return this.highPriorityPresent; }
        }

        /// <summary>
        /// Stored Event instance
        /// </summary>
        public EventMessageBase EventMessage
        {
            get;
            private set;
        }
    }
}
