﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class ItemStatusAreaChangedEventArgs : ItemStatusChangedEventArgs
    {
        public ItemStatusAreaChangedEventArgs(int itemlogicalId, int areaId, bool newItemStatus)
            : base(itemlogicalId, newItemStatus)
        {
            AreaId = areaId;
        }

        /// <summary>
        /// Item Area logical Id
        /// </summary>
        public int AreaId
        {
            get;
            private set;
        }
    }
}
