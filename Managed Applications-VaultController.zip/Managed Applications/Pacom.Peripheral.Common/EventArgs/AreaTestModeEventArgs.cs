﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common
{
    public class AreaTestModeEventArgs : EventArgs
    {
        public AreaTestModeEventArgs(List<int> areasIds, UserAuditInfo userAuditInfo)
        {
            AreaIds = areasIds;
            UserInfo = userAuditInfo;
            UserId = userAuditInfo.OriginatingUserId;
        }

        public List<int> AreaIds
        {
            get;
            private set;
        }

        public UserAuditInfo UserInfo
        {
            get;
            private set;
        }

        public int UserId
        {
            get;
            private set;
        }
    }
}
