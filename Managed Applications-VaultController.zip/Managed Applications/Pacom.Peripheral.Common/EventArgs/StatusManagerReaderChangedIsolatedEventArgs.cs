﻿using System;

namespace Pacom.Peripheral.Common
{
    public class StatusManagerReaderChangedIsolatedEventArgs : EventArgs
    {
        public StatusManagerReaderChangedIsolatedEventArgs(Common.Status.ReaderStatus readerStatus, bool isolated, UserAuditInfo userAuditInfo)
        {
            ReaderStatus = readerStatus;
            Isolated = isolated;
            UserInfo = userAuditInfo;
        }

        public Common.Status.ReaderStatus ReaderStatus { get; private set; }

        public bool Isolated { get; private set; }

        public UserAuditInfo UserInfo { get; private set; }
    }
}
