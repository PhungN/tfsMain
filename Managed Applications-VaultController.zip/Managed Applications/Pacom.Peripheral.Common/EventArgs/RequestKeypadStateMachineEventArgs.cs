﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common
{
    public class RequestKeypadStateMachineEventArgs : EventArgs
    {
        public RequestKeypadStateMachineEventArgs(PortProtocol protocol, DeviceType device, int logicalDeviceId)
        {
            this.Protocol = protocol;
            this.Device = device;
            this.KeypadStateMachine = null;
            LogicalDeviceId = logicalDeviceId;
        }

        public PortProtocol Protocol
        {
            get;
            private set;
        }
   
        public DeviceType Device
        {
            get;
            private set;
        }

        public int LogicalDeviceId
        {
            get;
            private set;
        }

        public IKeypadStateMachine KeypadStateMachine
        {
            get;
            set;
        }
    }
}
