﻿
namespace Pacom.Peripheral.Common
{
    public class InvalidConfigurationEventFromDevice : InvalidConfigurationEventBase
    {
        public InvalidConfigurationEventFromDevice(string propertyName, int logicalDeviceId)
            : base(propertyName)
        {
            this.LogicalDeviceId = logicalDeviceId;
        }

        public int LogicalDeviceId
        {
            get;
            private set;
        }
    }
}
