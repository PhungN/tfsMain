﻿using System;

namespace Pacom.Peripheral.Common
{
    public class ControllerPeerToPeerEventArgs : EventArgs
    {
        public ControllerPeerToPeerEventArgs(int siteId, bool restore)
        {
            SiteId = siteId;
            Restore = restore;
        }

        public int SiteId
        {
            get;
            private set;
        }

        public bool Restore
        {
            get;
            private set;
        }
    }
}
