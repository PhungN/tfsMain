﻿using System;
namespace Pacom.Peripheral.Common.LcdKeypadStateMachine
{
    public class BuzzerOnEventArgs : EventArgs
    {
        public BuzzerOnEventArgs(int numberOfBeeps, double milliseconds, ReasonForBeeping reason)
        {
            NumberOfBeeps = numberOfBeeps;
            Milliseconds = milliseconds;
            Reason = reason;
        }

        public int NumberOfBeeps
        {
            get;
            private set;
        }

        public double Milliseconds
        {
            get;
            private set;
        }

        public ReasonForBeeping Reason
        {
            get;
            private set;
        }

        public void SetState(int numberOfBeeps, double milliseconds, ReasonForBeeping reason)
        {
            NumberOfBeeps = numberOfBeeps;
            Milliseconds = milliseconds;
            Reason = reason;
        }
    }
}
