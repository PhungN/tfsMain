﻿using System;

namespace Pacom.Peripheral.Common
{
    public class InvalidConfigurationEventBase : EventArgs
    {
        public InvalidConfigurationEventBase(string propertyName)
        {
            this.PropertyName = propertyName;
        }

        public string PropertyName
        {
            get;
            private set;
        }
    }
}
