﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Common
{
    public class InputChangedStatusEventArgs : EventArgs
    {
        private readonly int inputNumber;
        private readonly InputStatus status;
        private readonly int analogValue;

        public InputChangedStatusEventArgs(int inputNumber, InputStatus status)
        {
            this.inputNumber = inputNumber;
            this.status = status;
            this.analogValue = 0;
        }

        public InputChangedStatusEventArgs(int inputNumber, int analogValue)
        {
            this.inputNumber = inputNumber;
            this.status = InputStatus.Analog;
            this.analogValue = analogValue;
        }

        public int InputNumber
        {
            get { return inputNumber; }
        }

        public InputStatus Status
        {
            get { return status; }
        }

        public int AnalogValue
        {
            get { return analogValue; }
        }
    }
}
