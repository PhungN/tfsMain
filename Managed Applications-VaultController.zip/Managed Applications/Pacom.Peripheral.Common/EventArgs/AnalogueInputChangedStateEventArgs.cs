﻿#if INOVONICSTEMPERATUREDEMO
using System;
using Pacom.Events.EventsCommon;

namespace Pacom.Peripheral.Common
{
    public class AnalogueInputChangedStateEventArgs : EventArgs
    {
        public AnalogueInputChangedStateEventArgs(int logicalId, int areaId, AnalogueInputUnits units, int analogueValue)
        {
            LogicalId = logicalId;
            AreaId = areaId;
            Units = units;
            AnalogueValue = analogueValue;
        }

        public int LogicalId
        {
            get;
            private set;
        }

        public int AreaId
        {
            get;
            private set;
        }

        public AnalogueInputUnits Units
        {
            get;
            private set;
        }

        public int AnalogueValue
        {
            get;
            private set;
        }
    }
}
#endif