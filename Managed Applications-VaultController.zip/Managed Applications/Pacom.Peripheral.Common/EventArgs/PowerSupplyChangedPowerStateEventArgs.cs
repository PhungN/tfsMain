﻿using System;
using Pacom.Events.EventsCommon;
 
namespace Pacom.Peripheral.Common
{
    public class PowerSupplyChangedPowerStateEventArgs : PowerSupplyEventArgs
    {
        public PowerSupplyChangedPowerStateEventArgs(int logicalDeviceId, PowerFailState state, PowerFailState previousState) :
            base(logicalDeviceId)
        {
            State = state;
            PreviousState = previousState;
        }

        /// <summary>
        /// Get / Set power supply status
        /// </summary>
        public PowerFailState State { get; private set; }

        /// <summary>
        /// Get / Set power supply previous status
        /// </summary>
        public PowerFailState PreviousState { get; private set; }
    }
}
