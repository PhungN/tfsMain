﻿using System;

namespace Pacom.Peripheral.Common.LcdKeypadStateMachine
{
    public class EchoLastDigitOnLcdDisplayEventArgs : EventArgs
    {
        public EchoLastDigitOnLcdDisplayEventArgs(byte digit, byte location, byte lcdLine, bool isPassword, bool displayCursor)
        {
            Digit = digit;
            Location = location;
            LcdLine = lcdLine;
            IsPassword = isPassword;
            DisplayCursor = displayCursor;
        }

        public byte Digit
        {
            get;
            private set;
        }

        public byte Location
        {
            get;
            private set;
        }

        public byte LcdLine
        {
            get;
            private set;
        }

        public bool IsPassword
        {
            get;
            private set;
        }

        public bool DisplayCursor
        {
            get;
            private set;
        }
    }
}
