﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common
{
    public class StopArmingEventArgs : EventArgs
    {
        public StopArmingEventArgs(List<int> areaIds, KeypadBuzzerPriority buzzerBeepTypeAndDuration, bool beepBuzzer)
        {
            AreaIds = areaIds;
            BuzzerBeepTypeAndDuration = buzzerBeepTypeAndDuration;
            BeepBuzzer = beepBuzzer;
        }

        public KeypadBuzzerPriority BuzzerBeepTypeAndDuration
        {
            get;
            private set;
        }

        public List<int> AreaIds
        {
            get;
            private set;
        }

        public bool BeepBuzzer
        {
            get;
            private set;
        }

        public int UserId
        {
            get;
            private set;
        }
    }
}
