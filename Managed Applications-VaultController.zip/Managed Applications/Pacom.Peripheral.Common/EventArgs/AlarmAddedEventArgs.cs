﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class AlarmAddedEventArgs : EventArgs
    {
        public AlarmAddedEventArgs(int areaId)
        {
            LogicalAreaId = areaId;
        }

        public int LogicalAreaId
        {
            get;
            private set;
        }
    }
}
