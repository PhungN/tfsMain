﻿using System;

namespace Pacom.Peripheral.Common
{
    public class DeviceOfflineEventArgs : EventArgs
    {
        private readonly int logicalDeviceId = 0;

        public DeviceOfflineEventArgs(int logicalDeviceId)
        {
            this.logicalDeviceId = logicalDeviceId;
        }

        public int LogicalDeviceId
        {
            get { return logicalDeviceId; }
        }
    }
}
