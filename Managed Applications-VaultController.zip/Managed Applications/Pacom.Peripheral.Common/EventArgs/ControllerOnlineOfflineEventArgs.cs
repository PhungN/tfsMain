﻿using System;

namespace Pacom.Peripheral.Common
{
    public class ControllerOnlineOfflineEventArgs : EventArgs
    {
        public ControllerOnlineOfflineEventArgs(int connectionTable, bool offline)
        {
            ConnectionTable = connectionTable;
            Offline = offline;
        }

        public int ConnectionTable { get; private set; }

        public bool Offline { get; private set; }
    }
}
