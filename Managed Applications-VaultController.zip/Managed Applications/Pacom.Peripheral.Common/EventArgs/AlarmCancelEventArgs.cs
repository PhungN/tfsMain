﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class AlarmCancelEventArgs : EventArgs
    {
        public AlarmCancelEventArgs(AreaStatus areaStatus, UserAuditInfo userAuditInfo)
        {
            LogicalAreaId = areaStatus.LogicalId;
            UserInfo = userAuditInfo;
        }

        public int LogicalAreaId
        {
            get;
            private set;
        }

        public UserAuditInfo UserInfo
        {
            get;
            private set;
        }
    }
}
