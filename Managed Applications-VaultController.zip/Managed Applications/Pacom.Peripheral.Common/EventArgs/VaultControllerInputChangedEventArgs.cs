﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class ReportVaultInputChangedEventArgs : EventArgs
    {
        public ReportVaultInputChangedEventArgs(int id, int vaultNumber, VaultControllerInputType inputType, bool restore)
        {
            LogicalId = id;
            VaultNumber = vaultNumber;
            InputType = inputType;
            Restore = restore;
        }

        public VaultControllerInputType InputType { get; private set; }
        public int LogicalId { get; private set; }
        public int VaultNumber { get; private set; }
        public bool Restore { get; private set; }
    }

    public class ReportVaultStatusChangedEventArgs : EventArgs
    {
        public ReportVaultStatusChangedEventArgs(int id, int vaultNumber, VaultStatus status)
        {
            LogicalId = id;
            VaultNumber = vaultNumber;
            Status = status;
        }
        public int LogicalId { get; private set; }
        public int VaultNumber { get; private set; }
        public VaultStatus Status { get; private set; }
    }

    public class VaultStatusChangedEventArgs : EventArgs
    {
        public byte MinuteToExpire { get; private set; }
        public byte SecondToExpire { get; private set; }
        public VaultControllerStatus VaultController { get; private set; }

        public VaultStatusChangedEventArgs(VaultControllerStatus vaultController)
            : this( vaultController, 0, 0)
        {
        }
        public VaultStatusChangedEventArgs(VaultControllerStatus vaultController, byte minuteToExpire, byte secondToExpire)
        {
            MinuteToExpire = minuteToExpire;
            SecondToExpire = secondToExpire;
            VaultController = vaultController;
        }
    }
}
