﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class DoorInputChangedStatusEventArgs : EventArgs
    {
        private readonly DoorStatus doorStatus;
        private readonly ChangedDoorControllerInput changedInput;
        private readonly InputStatus status;
        private readonly InputStatus previousStatus;

        public DoorInputChangedStatusEventArgs(DoorStatus doorStatus, ChangedDoorControllerInput changedInput, InputStatus status, InputStatus previousStatus)
        {
            this.doorStatus = doorStatus;
            this.changedInput = changedInput;
            this.status = status;
            this.previousStatus = previousStatus;
        }

        public InputStatus Status
        {
            get { return status; }
        }

        public InputStatus PreviousStatus
        {
            get { return previousStatus; }
        }

        public ChangedDoorControllerInput ChangedDoorInput
        {
            get { return changedInput; }
        }

        public int LogicalDoorId
        {
            get { return doorStatus.LogicalId; }
        }
    }
}
