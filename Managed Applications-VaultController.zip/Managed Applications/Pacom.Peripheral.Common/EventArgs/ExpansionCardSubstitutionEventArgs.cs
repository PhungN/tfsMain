﻿using System;

namespace Pacom.Peripheral.Common
{
    public class ExpansionCardSubstitutionEventArgs : EventArgs
    {
        public ExpansionCardSubstitutionEventArgs(int logicalDeviceId, bool restore)
        {
            LogicalDeviceId = logicalDeviceId;
            Restore = restore;
        }

        public int LogicalDeviceId
        {
            get;
            private set;
        }

        public bool Restore
        {
            get;
            private set;
        }
    }
}
