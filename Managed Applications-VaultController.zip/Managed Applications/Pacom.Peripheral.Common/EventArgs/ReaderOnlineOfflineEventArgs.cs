﻿using System;

namespace Pacom.Peripheral.Common
{
    public class ReaderOnlineOfflineEventArgs : EventArgs
    {
        public ReaderOnlineOfflineEventArgs(int logicalReaderId, int logicalDoorId, bool offline)
        {
            LogicalReaderId = logicalReaderId;
            LogicalDoorId = logicalDoorId;
            Offline = offline;
        }

        public int LogicalReaderId { get; private set; }

        public int LogicalDoorId { get; private set; }

        public bool Offline { get; private set; }
    }
}
