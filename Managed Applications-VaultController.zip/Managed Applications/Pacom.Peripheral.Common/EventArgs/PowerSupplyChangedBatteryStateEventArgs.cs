﻿using System;
using Pacom.Events.EventsCommon;

namespace Pacom.Peripheral.Common
{
    public class PowerSupplyChangedBatteryStateEventArgs : PowerSupplyEventArgs
    {
        public PowerSupplyChangedBatteryStateEventArgs(int logicalDeviceId, BatteryFailState state, BatteryFailState previousState) :
            base(logicalDeviceId)
        {
            State = state;
            PreviousState = previousState;
        }

        /// <summary>
        /// Get / Set power supply status
        /// </summary>
        public BatteryFailState State { get; private set; }

        /// <summary>
        /// Get / Set power supply previous status
        /// </summary>
        public BatteryFailState PreviousState { get; private set; }
    }
}
