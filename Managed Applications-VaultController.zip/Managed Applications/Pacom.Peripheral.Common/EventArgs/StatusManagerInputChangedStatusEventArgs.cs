﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class StatusManagerInputChangedStatusEventArgs : EventArgs
    {
        private readonly Common.Status.InputStatus inputStatus;
        private readonly InputStatus previousStatus = Common.InputStatus.Unknown;

        public StatusManagerInputChangedStatusEventArgs(Common.Status.InputStatus inputStatus, InputStatus previousStatus)
        {
            this.inputStatus = inputStatus;
            this.previousStatus = previousStatus;

        }

        public Common.Status.InputStatus InputStatus
        {
            get { return inputStatus; }
        }

        public int InputNumber
        {
            get { return inputStatus.LogicalId; }
        }

        public InputStatus Status
        {
            get { return inputStatus.UnmaskedStatus; }
        }

        public InputStatus PreviousStatus
        {
            get { return previousStatus; }
        }
    }
}
