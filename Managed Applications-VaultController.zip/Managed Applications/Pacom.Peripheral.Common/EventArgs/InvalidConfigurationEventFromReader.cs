﻿
namespace Pacom.Peripheral.Common
{
    public class InvalidConfigurationEventFromReader : InvalidConfigurationEventBase
    {
        public InvalidConfigurationEventFromReader(string propertyName, int logicalReaderId)
            : base(propertyName)
        {
            this.LogicalReaderId = logicalReaderId;
        }

        public int LogicalReaderId
        {
            get;
            private set;
        }
    }
}
