﻿using System;

namespace Pacom.Peripheral.Common
{
    public class PowerSupplyEventArgs : EventArgs
    {
        public PowerSupplyEventArgs(int logicalDeviceId)
        {
            LogicalDeviceId = logicalDeviceId;
        }

        /// <summary>
        /// Get / Set power supply device logical id
        /// </summary>
        public int LogicalDeviceId { get; private set; }
    }
}
