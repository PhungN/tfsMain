﻿using System;

namespace Pacom.Peripheral.Common
{
    public class StatusManagerInputChangedIsolatedEventArgs : EventArgs
    {
        public StatusManagerInputChangedIsolatedEventArgs(Common.Status.InputStatus inputStatus, bool isolated, UserAuditInfo userAuditInfo)
        {
            this.InputStatus = inputStatus;
            this.Isolated = isolated;
            UserInfo = userAuditInfo;
        }

        public Common.Status.InputStatus InputStatus { get; private set; }

        public bool Isolated { get; private set; }

        public UserAuditInfo UserInfo { get; private set; }
    }
}
