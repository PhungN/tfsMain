﻿using System;
namespace Pacom.Peripheral.Common.LcdKeypadStateMachine
{
    public class CountdownEventArgs : EventArgs
    {
        public CountdownEventArgs(int countdownCount, int displayLineWidth)
        {
            CountdownCount = countdownCount;
            DisplayLineWidth = displayLineWidth;
        }

        public int CountdownCount
        {
            get;
            private set;
        }

        public int DisplayLineWidth
        {
            get;
            private set;
        }
    }
}
