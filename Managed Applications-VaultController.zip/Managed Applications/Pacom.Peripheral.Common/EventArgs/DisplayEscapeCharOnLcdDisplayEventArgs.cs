﻿using System;

namespace Pacom.Peripheral.Common.LcdKeypadStateMachine
{
    public class DisplayEscapeCharOnLcdDisplayEventArgs : EventArgs
    {
        public DisplayEscapeCharOnLcdDisplayEventArgs(int displayLineWidth)
        {
            DisplayLineWidth = displayLineWidth;
        }

        public int DisplayLineWidth
        {
            get;
            private set;
        }
    }
}
