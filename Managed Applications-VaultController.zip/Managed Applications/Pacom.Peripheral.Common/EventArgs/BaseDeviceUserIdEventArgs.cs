﻿using System;

namespace Pacom.Peripheral.Common
{
    public abstract class BaseDeviceUserIdEventArgs : EventArgs
    {
        protected BaseDeviceUserIdEventArgs(int logicalDeviceId, int userId)
        {
            LogicalId = logicalDeviceId;
            UserId = userId;
        }

        public int LogicalId
        {
            get;
            protected set;
        }

        public int UserId
        {
            get;
            protected set;
        }
    }
}
