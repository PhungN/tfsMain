﻿using System;

namespace Pacom.Peripheral.Common
{
    public class StatusManagerOutputChangedIsolatedEventArgs : EventArgs
    {
        public StatusManagerOutputChangedIsolatedEventArgs(Common.Status.OutputStatus outputStatus, bool isolated, UserAuditInfo userAuditInfo)
        {
            this.OutputStatus = outputStatus;
            this.Isolated = isolated;
            UserInfo = userAuditInfo;
        }

        public Common.Status.OutputStatus OutputStatus { get; private set; }

        public bool Isolated { get; private set; }

        public UserAuditInfo UserInfo { get; private set; }
    }
}
