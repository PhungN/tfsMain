﻿using System;

namespace Pacom.Peripheral.Common
{
    public class LogonDateTimeEventArgs : EventArgs
    {
        public DateTime FronEndDateTime { get; private set; }
        public int TimeZoneOffsetMinutes { get; private set; }
        public int ConnectionTableIndex { get; private set; }

        public LogonDateTimeEventArgs(DateTime dateTime, int timeZoneOffsetMinutes, int connectionTableIndex)
        {
            FronEndDateTime = dateTime;
            TimeZoneOffsetMinutes = timeZoneOffsetMinutes;
            ConnectionTableIndex = connectionTableIndex;
        }
    }
}
