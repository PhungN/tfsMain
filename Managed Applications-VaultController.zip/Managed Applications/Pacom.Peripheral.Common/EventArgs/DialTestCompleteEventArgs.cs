﻿using System;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common
{
    public class DialTestCompleteEventArgs : EventArgs
    {
        public DialTestCompleteEventArgs(bool success, int connectionTableId, int entryInConnectionTable, PortType portType)
        {
            Success = success;
            ConnectionTableId = connectionTableId;
            EntryInConnectionTable = entryInConnectionTable;
            PortType = portType;
        }

        public bool Success { get; set; }
        public int ConnectionTableId { get; set; }
        public int EntryInConnectionTable { get; set; }
        public PortType PortType { get; set; }
    }
}
