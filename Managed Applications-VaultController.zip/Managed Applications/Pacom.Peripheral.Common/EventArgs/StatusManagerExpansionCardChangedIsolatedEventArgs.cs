﻿using System;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public class StatusManagerExpansionCardChangedIsolatedEventArgs : EventArgs
    {
        public StatusManagerExpansionCardChangedIsolatedEventArgs(Status.ExpansionCardStatus cardStatus, EventSourceLatchOrIsolateType isolatedAlarms, EventSourceLatchOrIsolateType previousIsolatedAlarms,
                                                                  UserAuditInfo userAuditInfo)
        {
            CardStatus = cardStatus;
            IsolatedAlarms = isolatedAlarms;
            PreviousIsolatedAlarms = previousIsolatedAlarms;
            UserInfo = userAuditInfo;
        }

        public Status.ExpansionCardStatus CardStatus { get; private set; }

        public EventSourceLatchOrIsolateType IsolatedAlarms { get; private set; }

        public EventSourceLatchOrIsolateType PreviousIsolatedAlarms { get; private set; }

        public UserAuditInfo UserInfo { get; private set; }
    }
}
