﻿using System;
using Pacom.Peripheral.Common.Status;
using Pacom.Events.EventsCommon;

namespace Pacom.Peripheral.Common
{
    public class ListenInDeviceStatusEventArgs : EventArgs
    {
        public ListenInDeviceStatusEventArgs(int logicalDeviceId, ListenInDeviceConnectStatus connectStatus, UserAuditInfo userInfo)
        {
            LogicalDeviceId = logicalDeviceId;
            ConnectStatus = connectStatus;
            UserInfo = userInfo;
        }

        public int LogicalDeviceId
        {
            get;
            private set;
        }

        public ListenInDeviceConnectStatus ConnectStatus
        {
            get;
            private set;
        }

        public UserAuditInfo UserInfo
        {
            get;
            private set;
        }
    }

}
