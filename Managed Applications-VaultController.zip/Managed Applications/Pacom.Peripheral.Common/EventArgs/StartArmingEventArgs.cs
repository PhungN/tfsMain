﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common
{
    public class StartArmingEventArgs : EventArgs
    {
        private readonly List<int> areaIdsList = new List<int>();
        private KeypadBuzzerPriority buzzerBeepTypeAndDuration = KeypadBuzzerPriority.NoBeeping;
        private bool beepBuzzer = false;

        public StartArmingEventArgs(List<int> areaIds, KeypadBuzzerPriority buzzerBeepTypeAndDuration, bool beepBuzzer)
        {
            areaIdsList = areaIds;
            BuzzerBeepTypeAndDuration = buzzerBeepTypeAndDuration;
            BeepBuzzer = beepBuzzer;
        }

        public List<int> AreaIds
        {
            get { return areaIdsList; }
        }

        public KeypadBuzzerPriority BuzzerBeepTypeAndDuration
        {
            get { return buzzerBeepTypeAndDuration; }
            private set { buzzerBeepTypeAndDuration = value; }
        }

        public bool BeepBuzzer
        {
            get { return beepBuzzer; }
            private set { beepBuzzer = value; }
        }
    }
}
