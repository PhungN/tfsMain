﻿using System;

namespace Pacom.Peripheral.Common
{
    public class GprsSignalStrengthArgs : EventArgs
    {
        public GprsSignalStrengthArgs(int logicalDeviceId, GprsNetworkSignalStrength previousSignalStrength, GprsNetworkSignalStrength signalStrength)
        {
            LogicalDeviceId = logicalDeviceId;
            PreviousSignalStrength = previousSignalStrength;
            SignalStrength = signalStrength;
        }

        public int LogicalDeviceId
        {
            get;
            private set;
        }

        public GprsNetworkSignalStrength PreviousSignalStrength
        {
            get;
            private set;
        }

        public GprsNetworkSignalStrength SignalStrength
        {
            get;
            private set;
        }
    }
}
