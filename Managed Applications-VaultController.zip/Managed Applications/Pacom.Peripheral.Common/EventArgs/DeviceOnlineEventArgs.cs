﻿using System;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common
{
    public class DeviceOnlineEventArgs : EventArgs
    {
        private readonly int logicalDeviceId = 0;

        public DeviceOnlineEventArgs(int logicalDeviceId)
        {
            this.logicalDeviceId = logicalDeviceId;
        }

        public int LogicalDeviceId
        {
            get { return logicalDeviceId; }
        }
    }
}
