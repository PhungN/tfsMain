﻿using System;

namespace Pacom.Peripheral.Common
{
    public class RemoteMaintenanceStatusEventArgs : EventArgs
    {
        public RemoteMaintenanceStatusEventArgs(UserAuditInfo userInfo)
        {
            UserInfo = userInfo;
        }

        public UserAuditInfo UserInfo
        {
            get;
            private set;
        }
    }

}
