﻿using System;
using System.Collections.Generic;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class is a simple version of Monitor which doesn't allow a single thread to acquire the lock multiple times
    /// but also doesn't enforce Exit being called from the same thread that holds the lock.
    /// </summary>
    public class DumbMonitor : IDisposable
    {
        public readonly List<ManualResetEvent> waitList = new List<ManualResetEvent>();
        public bool monitorHeld = false;
        public bool disposed = false;

        public bool TryEnter()
        {
            lock (waitList)
            {
                if (disposed)
                    return false;

                if (monitorHeld == false)
                {
                    monitorHeld = true;
                    return true;
                }
            }
            return false;
        }
        
        public void Enter()
        {
            ManualResetEvent waitEvent = null;
            try
            {
                lock (waitList)
                {
                    if (disposed)
                        return;

                    if (monitorHeld == false)
                    {
                        monitorHeld = true;
                    }
                    else
                    {
                        waitEvent = new ManualResetEvent(false);
                        waitList.Add(waitEvent);
                    }
                }
                if (waitEvent != null)
                {
                    waitEvent.WaitOne();
                    waitEvent.Close();
                }
            }
            catch (ThreadAbortException)
            {
                try
                {
                    lock (waitList)
                    {
                        if (waitEvent != null)
                            waitEvent.Close();
                        waitList.Remove(waitEvent);
                    }
                    throw;
                }
                catch
                {
                }
            }
        }

        public void Exit()
        {
            lock (waitList)
            {
                if (disposed)
                    return;

                if (waitList.Count == 0)
                {
                    monitorHeld = false;
                }
                else
                {
                    bool releaseMonitorHeld = true;
                    while (waitList.Count > 0)
                    {
                        try
                        {
                            ManualResetEvent waitEvent = waitList[0];
                            waitList.RemoveAt(0);
                            waitEvent.Set();
                            releaseMonitorHeld = false;
                            break;
                        }
                        catch
                        {
                        }
                    }
                    if (releaseMonitorHeld)
                        monitorHeld = false;
                }
            }
        }

        public void Dispose()
        {
            lock (waitList)
            {
                monitorHeld = false;
                while (waitList.Count > 0)
                {
                    try
                    {
                        ManualResetEvent waitEvent = waitList[0];
                        waitList.RemoveAt(0);
                        waitEvent.Set();
                    }
                    catch
                    {
                    }
                }
                disposed = true;
            }
        }
    }
}
