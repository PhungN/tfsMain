﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common
{
    public interface IAlarmsQueue<T> : IDisposable
    {
        /// <summary>
        /// Triggered when a new alarm was added to alarms queue
        /// </summary>
        event EventHandler<AlarmAddedEventArgs> AlarmAdded;

        /// <summary>
        /// Return list of alarms for area
        /// </summary>
        /// <param name="areaId">Area id, 1 based</param>
        /// <returns>List of alarms for area or null if no alarms exist for area.</returns>
        List<T> this[int areaId]
        {
            get;
        }

        /// <summary>
        /// Get the alarms count for the queue
        /// </summary>
        int AlarmCount
        {
            get;
        }

        /// <summary>
        /// Get alarms count for area.
        /// </summary>
        /// <param name="areaId">Area Id for which to get the alarms count.</param>
        /// <returns>Alarms count for area.</returns>
        int Count(int areaId);

        /// <summary>
        /// Get the list of alarms in sorted order with the most recent alarm 1st
        /// </summary>
        List<T> SortedAlarms
        {
            get;
        }

        /// <summary>
        /// Remove alarm from areaId list
        /// </summary>
        /// <param name="areaId">Area ID for which first alarm will be removed.</param>
        /// <param name="alarm">Alarm to remove from list</param>
        /// <returns>True if the alarm was successfully removed.</returns>
        bool RemoveAlarm(int areaId, T alarm);

        /// <summary>
        /// Check if the eventMessage is reportable and needs to be added to the queue
        /// </summary>
        /// <param name="eventMessage">Event Message to check</param>
        /// <returns>True if the event is reportable, False otherwise.</returns>
        bool IsReportableEvent(T eventMessage);
    }
}
