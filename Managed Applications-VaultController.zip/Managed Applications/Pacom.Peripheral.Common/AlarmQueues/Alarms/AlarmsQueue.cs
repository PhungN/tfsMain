﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Core.Contracts;
using Pacom.Peripheral.EventQueue;
using System.IO;

namespace Pacom.Peripheral.Common
{
    public sealed class AlarmsQueue<T> : AlarmsQueueBase<T> where T : EventMessageBase
    {
        public AlarmsQueue()
            : base()
        {
            Capacity = ConfigurationManager.Instance.ControllerConfiguration.EventQueueCapacity;
            ConfigurationManager.Instance.ConfigurationChanged += new EventHandler<ConfigurationChangeEventArgs>(configurationChanged);
        }

        private void configurationChanged(object sender, ConfigurationChangeEventArgs e)
        {
            if (e.ControllerChanged == false)
                return;

            lock (alarmsMapSync)
            {
                Capacity = ConfigurationManager.Instance.ControllerConfiguration.EventQueueCapacity;
            }
        }

        #region IAlarmsQueue<T> Members

        /// <summary>
        /// DatTime comparer returnig dates in descending order - most recent date 1st
        /// </summary>
        public class DescendingEventTimestampComparer : IComparer<T>
        {
            public int Compare(T left, T right)
            {
                // Reverse the result given by the default DateTime comparer (resturns DateTime in ascending order)
                return -Comparer<DateTime>.Default.Compare(left.UtcTimestamp, right.UtcTimestamp);
            }
        }

        /// <summary>
        /// Get the list of alarms in sorted order with the most recent alarm 1st
        /// </summary>
        public override List<T> SortedAlarms
        {
            get 
            {
                lock (alarmsMapSync)
                {
                    List<T> sortedAlarms = new List<T>();
                    foreach (var alarmAreaPair in alarmsQueue)
                    {
                        var alarmsList = alarmAreaPair.Value;
                        if (alarmsList.Count == 0)
                            continue;
                        T[] alarms = alarmsList.ToArray();
                        Array.Reverse(alarms);
                        sortedAlarms.AddRange(alarms);
                    }
                    sortedAlarms.Sort(new DescendingEventTimestampComparer());
                    return sortedAlarms;
                }
            }
        }

        /// <summary>
        /// Check if the eventMessage is reportable and needs to be added to the queue
        /// </summary>
        /// <param name="eventMessage">Event Message to check</param>
        /// <returns>True if the event is reportable, False otherwise.</returns>
        public override bool IsReportableEvent(T eventMessage)
        {
            return eventMessage.ReportableEventType.Has(ReportableEventType.AddToAlarmQueue);
        }

        /// <summary>
        /// Load events queue from Event Queue Manager - System8.
        /// </summary>
        /// <param name="eventQueueManager">Event Queue Manager instance</param>
        public void LoadFromStorage(IEventQueueManager eventQueueManager)
        {
            if (eventQueueManager == null)
                return;

            lock (alarmsMapSync)
            {
                foreach (byte[] iteratedEventData in eventQueueManager.IterateQueue(FrontEndSystem.System8))
                {
                    if (iteratedEventData == null || iteratedEventData.Length == 0)
                        continue;

                    // Exceptions can be thrown when deserializing an event from a newer firmware that this version of 
                    // firmware is not aware of.
                    try
                    {
                        using (MemoryStream eventStream = new MemoryStream(iteratedEventData))
                        {
                            eventStream.Position = 0;
                            EventMessageBase eventMessage = (EventMessageBase)EventSerializer.Deserialize(eventStream);
                            if (eventMessage != null && IsReportableEvent((T)eventMessage) == true)
                            {
                                AddAlarm((T)eventMessage);
                            }
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }

        #endregion

        internal override void Cleanup()
        {
            base.Cleanup();
            ConfigurationManager.Instance.ConfigurationChanged -= new EventHandler<ConfigurationChangeEventArgs>(configurationChanged);
        }
    }
}
