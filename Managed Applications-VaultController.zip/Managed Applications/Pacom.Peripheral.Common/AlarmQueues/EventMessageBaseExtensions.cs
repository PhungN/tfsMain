﻿using System;
using Pacom.Core.Contracts;
using Pacom.Events.EventsCommon;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public static class EventMessageBaseExtensions
    {
        /// <summary>
        /// Get event description in the following format:
        ///     PREFIX:SOURCENAME {EVENT NAME} {AREA NAME} {EVENT TIME}, where
        ///         - PREFIX  - one of: I - input, V - device, D - door, R - reader, etc.
        ///         - SOURCENAME - source(point) name from configuration
        ///         - EVENT NAME - [alarmEvent] name
        ///         - AREA NAME - event area name if the event has an area, nothing otherwise
        ///         - EVENT TIME - UTC date/time of event in format DDD HH:MM:ss
        ///         - USER TYPE / USER ID - user that triggered this event if known
        /// </summary>
        /// <param name="alarmEvent">Event instance</param>
        /// <returns></returns>
        public static string Description(this EventMessageBase alarmEvent)
        {
            if (alarmEvent == null)
                return "INVALID EVENT!";
            return string.Format("{0} {1}{2}{3}{4}", EventSourceName(alarmEvent), EventName(alarmEvent), eventAreaName(alarmEvent), 
                                                     eventDaytimeAsString(alarmEvent), eventUserTypeId(alarmEvent));
        }


        /// <summary>
        /// Get the name of the area where this event happened
        /// </summary>
        /// <returns>Area Name or Empty if this event doesn't have an area assigned.</returns>
        private static string eventAreaName(EventMessageBase alarmEvent)
        {
            string areaName = " ";
            IEventContainsArea areaEvent = alarmEvent as IEventContainsArea;
            if (areaEvent != null && areaEvent.AreaId > 0)
            {
                AreaConfiguration areaConfig = ConfigurationManager.Instance.GetAreaConfiguration(areaEvent.AreaId);
                if (areaConfig != null)
                    areaName = string.Format(" {0} ", areaConfig.GetName());
            }
            return areaName;
        }

        /// <summary>
        /// Get localized event day and time as string
        /// </summary>
        private static string eventDaytimeAsString(EventMessageBase alarmEvent)
        {
            DateTime dateTime = ConfigurationManager.Instance.ToLocalTime(alarmEvent.UtcTimestamp);
            string localDayName = ConfigurationManager.Instance.ControllerConfiguration.LocalizedDayName(dateTime);
            string timeStr = dateTime.ToString("HH:mm:ss dd/MM/yy");
            int timeLen = timeStr.Length + 1;
            int dayNameLength = localDayName.Length;
            timeStr = timeStr.PadLeft(timeLen);
            return string.Concat(localDayName, timeStr);
        }

        public static string EventSourceName(this EventMessageBase alarmEvent)
        {
            IStatusItem eventSource = StatusManager.Instance[alarmEvent.Category, (int)alarmEvent.Id];
            if (eventSource != null)
            {
                return eventSource.DisplayName;
            }
            IDeviceEvent deviceEvent = alarmEvent as IDeviceEvent;
            if (deviceEvent != null)
            {
                return hardwareTypeAsString(deviceEvent.HardwareType);
            }
            else if (alarmEvent.Id > 0)
            {
                return string.Format("{0}:{1}", ConfigurationManager.Instance.ControllerConfiguration.UnknownText, alarmEvent.Id);
            }
            else
            {
                return ConfigurationManager.Instance.ControllerConfiguration.UnknownText;
            }
        }

        private static string hardwareTypeAsString(HardwareType hardwareType)
        {
            switch (hardwareType)
            {
                case HardwareType.Pacom8003: return "8003";
                case HardwareType.Pacom8303: return "POWER SUPPLY";
                case HardwareType.Pacom8308: return "PACOM 8308 UPS";
                case HardwareType.Pacom8501: return "PACOM 8501";
                case HardwareType.Pacom8101: return "PACOM 8101 KEYPAD";
                case HardwareType.Pacom1061: return "PACOM 1061 KEYPAD";
                case HardwareType.Pacom1064DoorController: return "PACOM 1064 DOOR CONTROLLER";
                case HardwareType.Pacom1064InputOutput: return "PACOM 1064 INPUT/OUTPUT";
                case HardwareType.Pacom1068InputOutput: return "PACOM 1068 INPUT/OUTPUT";
                case HardwareType.Pacom1076DoorController: return "PACOM 1076 DOOR CONTROLLER";
                case HardwareType.Pacom1076InputOutput: return "PACOM 1076 INPUT/OUTPUT";
                case HardwareType.Pacom8603: return "PACOM 8603";
                case HardwareType.Pacom8502InputOutput: return "PACOM 8502 INPUT/OUTPUT";
                case HardwareType.Pacom1065InputOutput: return "PACOM 1065 INPUT/OUTPUT";
                case HardwareType.Pacom1065ElevatorController: return "PACOM ELEVATOR CONTROLLER";
            }
            return ConfigurationManager.Instance.ControllerConfiguration.UnknownText;
        }

        /// <summary>
        /// Get the User Type or User Name of the user that triggered this event. 
        /// User Name will only be displayed for alarm keypad users, the User Type
        /// will be displayed otherwise.
        /// </summary>
        /// <returns>USERTYPE / USER NAME or Empty if this event doesn't have a user.</returns>
        private static string eventUserTypeId(EventMessageBase alarmEvent)
        {
            string userName = "";
            if (alarmEvent != null && alarmEvent.OriginUserType != OriginatingUserType.None)
            {
                if (alarmEvent.OriginUserType == OriginatingUserType.AlarmKeypadUser && alarmEvent.UserId > 0)
                {
                    IUserConfiguration user = ConfigurationManager.Instance.Users[alarmEvent.UserId];
                    if (user != null)
                    {
                        // Display the user name
                        return " " + user.FullName();
                    }
                    return userName;
                }
                return " " + alarmEvent.OriginUserType.AsString();
            }
            return userName;
        }

        /// <summary>
        /// Get localized alarm event name
        /// </summary>
        public static string EventName(this EventMessageBase alarmEvent)
        {
            string eventNameUpCase = alarmEvent.EventName.ToUpper();
            if (alarmEvent is InputActiveEvent)
                eventNameUpCase = ((InputActiveEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is MaskEvent)
                eventNameUpCase = ((MaskEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is RangeReductionEvent)
                eventNameUpCase = ((RangeReductionEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is ShortCircuitEvent)
                eventNameUpCase = ((ShortCircuitEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is OpenCircuitEvent)
                eventNameUpCase = ((OpenCircuitEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is TroubleEvent)
                eventNameUpCase = ((TroubleEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is InputTestFailEvent)
                eventNameUpCase = ((InputTestFailEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is TamperEvent)
                eventNameUpCase = ((TamperEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is OfflineEvent)
                eventNameUpCase = ((OfflineEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is ReportingFailEvent)
                eventNameUpCase = ((ReportingFailEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is PowerFailEvent)
                eventNameUpCase = ((PowerFailEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is BatteryPreWarningTimeEvent)
                eventNameUpCase = ((BatteryPreWarningTimeEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is BatteryChargerFailEvent)
                eventNameUpCase = ((BatteryChargerFailEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is BatteryFailEvent)
                eventNameUpCase = ((BatteryFailEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is FuseFailEvent)
                eventNameUpCase = ((FuseFailEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is TemperatureFailEvent)
                eventNameUpCase = ((TemperatureFailEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is InternalBatteryFailEvent)
                eventNameUpCase = ((InternalBatteryFailEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is SignalFailEvent)
                eventNameUpCase = ((SignalFailEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is AjarEvent)
                eventNameUpCase = ((AjarEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is ForceEvent)
                eventNameUpCase = ((ForceEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is ContactTroubleEvent || alarmEvent is EgressTroubleEvent ||
                     alarmEvent is StrikeTroubleEvent || alarmEvent is SpareTroubleEvent)
                eventNameUpCase = ((RestorableEventMessageBase)alarmEvent).LocalizedEventName();
            else if (alarmEvent is AreaConfirmedAlarmEvent)
                eventNameUpCase = ((AreaConfirmedAlarmEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is DeviceSubstitutionEvent)
                eventNameUpCase = ((DeviceSubstitutionEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is TooManyInvalidLogonAttemptsEvent)
                eventNameUpCase = ((TooManyInvalidLogonAttemptsEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is AlarmQueueFullEvent)
                eventNameUpCase = ((AlarmQueueFullEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is AreaDuressEvent)
                eventNameUpCase = ((AreaDuressEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is ArmEvent)
                eventNameUpCase = ((ArmEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is ArmFailEvent)
                eventNameUpCase = ((ArmFailEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is CommunicationTestFailEvent)
                eventNameUpCase = ((CommunicationTestFailEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is ConfigurationChangeEvent)
                eventNameUpCase = ((ConfigurationChangeEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is ConfigurationFailEvent)
                eventNameUpCase = ((ConfigurationFailEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is DeviceDuressEvent)
                eventNameUpCase = ((DeviceDuressEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is DeviceIsolateEvent)
                eventNameUpCase = ((DeviceIsolateEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is DeviceLockoutEvent)
                eventNameUpCase = ((DeviceLockoutEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is IsolateEvent)
                eventNameUpCase = ((IsolateEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is TimeChangeEvent)
                eventNameUpCase = ((TimeChangeEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is ReaderOfflineEvent)
                eventNameUpCase = ((ReaderOfflineEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is ReaderTamperEvent)
                eventNameUpCase = ((ReaderTamperEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is EngineerLogOnEvent)
                eventNameUpCase = ((EngineerLogOnEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is DeviceRestartEvent)
                eventNameUpCase = ((DeviceRestartEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is SoftwareDownloadEvent)
                eventNameUpCase = ((SoftwareDownloadEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is LanDisconnectEvent)
                eventNameUpCase = ((LanDisconnectEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is ReceiverJammedEvent)
                eventNameUpCase = ((ReceiverJammedEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is SensorCleanRequiredEvent)
                eventNameUpCase = ((SensorCleanRequiredEvent)alarmEvent).LocalizedEventName();
            else if (alarmEvent is AreaAlarmConfirmationTimerExpiredEvent)
                eventNameUpCase = ((AreaAlarmConfirmationTimerExpiredEvent)alarmEvent).LocalizedEventName();

            IEventSourceLatched eventLatched = alarmEvent as IEventSourceLatched;
            if (eventLatched != null && eventLatched.LatchStatus != EventSourceLatchStatus.NotLatched)
            {
                eventNameUpCase += " " + ConfigurationManager.Instance.ControllerConfiguration.LatchedEventText;
                if (eventLatched.LatchStatus == EventSourceLatchStatus.SuspectBehaviour)
                    eventNameUpCase += " " + ConfigurationManager.Instance.ControllerConfiguration.SuspectLatchedText;
                eventNameUpCase = eventNameUpCase.TrimEnd();
            }
            return eventNameUpCase;
        }
    }
}
