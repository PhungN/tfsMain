﻿using System;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Events.EventsCommon;
using Pacom.Configuration.ConfigurationCommon;
using System.Reflection;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Common.CompactFramework.Helpers;

namespace Pacom.Peripheral.Common
{
    public abstract class AlarmsQueueBase<T> : IAlarmsQueue<T> where T : EventMessageBase
    {
        /// <summary>
        /// unacknowledge alarms queue thread synchronization object
        /// </summary>
        protected readonly object alarmsMapSync = new object();

        /// <summary>
        /// Map of unacknowledged alarms for each alarm system area. The map is keyed by Area Id and
        /// each entry will contain a linked list with all the unacknowledged alarms for area with the
        /// oldest being the last in the list.
        /// </summary>
        protected Dictionary<int, List<T>> alarmsQueue = null;

        /// <summary>
        /// Cache the current alarm count so we don't have to calculate it each time we need to add a new
        /// alarm to list.
        /// </summary>
        protected int alarmCount = 0;

        /// <summary>
        /// Get / Set alarm queue capacity
        /// </summary>
        protected int Capacity = 0;

        protected AlarmsQueueBase()
        {
            alarmsQueue = new Dictionary<int, List<T>>();
        }

        private Asn1DerFormatter asnEventSerializer = null;
        protected Asn1DerFormatter EventSerializer
        {
            get
            {
                if (asnEventSerializer == null)
                {
                    Assembly assembly = Assembly.Load("Pacom.Shared.Events");
                    ITypeLookup typesList = new HashTypeLookup(new List<Assembly>() { assembly });
                    asnEventSerializer = new Asn1DerFormatter(typesList, true, new StreamingContext());
                }
                return asnEventSerializer;
            }
        }

        #region IAlarmsQueue<T> Members

        public event EventHandler<AlarmAddedEventArgs> AlarmAdded = null;

        /// <summary>
        /// Return a copy of the alarms list for area
        /// </summary>
        /// <param name="areaId">Area id, 0 based. Area Id 0 will contain all alarms that don't have an areaId specified, e.g. Device Tamper, etc.</param>
        /// <returns>List of alarms for area or null if no alarms exist for area.</returns>
        public List<T> this[int areaId]
        {
            get
            {
                lock (alarmsMapSync)
                {
                    if (areaId < 0 || alarmsQueue == null || alarmsQueue.Count == 0)
                        return null;
                    List<T> areaAlarms = null;
                    alarmsQueue.TryGetValue(areaId, out areaAlarms);
                    return areaAlarms;
                }
            }
        }

        /// <summary>
        /// Get the alarms count for the queue
        /// </summary>
        public int AlarmCount
        {
            get { return alarmCount; }
        }

        /// <summary>
        /// Get alarms count for area.
        /// </summary>
        /// <param name="areaId">Area Id for which to get the alarms count.</param>
        /// <returns>Alarms count for area.</returns>
        public int Count(int areaId)
        {
            List<T> areaAlarms = this[areaId];
            return areaAlarms != null ? areaAlarms.Count : 0;
        }

        /// <summary>
        /// Get the list of alarms in sorted order with the most recent alarm 1st
        /// </summary>
        public virtual List<T> SortedAlarms
        {
            get { return null; }
        }

        /// <summary>
        /// Check if the eventMessage is reportable and needs to be added to the queue
        /// </summary>
        /// <param name="eventMessage">Event Message to check</param>
        /// <returns>True if the event is reportable, False otherwise.</returns>
        public abstract bool IsReportableEvent(T eventMessage);

        /// <summary>
        /// Remove alarm from areaId list
        /// </summary>
        /// <param name="areaId">Area ID for which first alarm will be removed.</param>
        /// <param name="alarm">Alarm to remove from list</param>
        /// <returns>True if the alarm was successfully removed.</returns>
        public virtual bool RemoveAlarm(int areaId, T alarm)
        {
            // The default is that alarms cannot be removed from the queue. In this case when the 
            // queue reaches its defined capacity the oldest event is removed before the new event 
            // is added.
            return false;
        }

        #endregion

        /// <summary>
        /// Add new alarm to queue. Remove oldest if the maximum allowed count will be exceeded.
        /// </summary>
        /// <param name="alarm">New alarm instance to add</param>
        public virtual void AddAlarm(T alarm)
        {
            lock (alarmsMapSync)
            {
                if (alarmCount < Capacity || removeOldest())
                {
                    IEventContainsArea areaAlarm = alarm as IEventContainsArea;
                    int areaId = 0;
                    if (areaAlarm != null)
                    {
                        // Area Event
                        areaId = areaAlarm.AreaId;
                    }
                    else
                    {
                        // All events that don't have an area (e.g. Device Tamper) will be added to areaId = 0 linked list
                    }
                    List<T> areaAlarms = null;
                    if (alarmsQueue.TryGetValue(areaId, out areaAlarms) == false)
                    {
                        // No alarms exist for this area. Create the list and allocate an initial capacity
                        areaAlarms = new List<T>(50);
                        // Add the new list to alarmsQueue map
                        alarmsQueue.Add(areaId, areaAlarms);
                    }
                    if (areaAlarms != null)
                    {
                        areaAlarms.Add(alarm);
                        alarmCount++;
                        if (AlarmAdded != null)
                            AlarmAdded(this, new AlarmAddedEventArgs(areaId));
                        Logger.LogDebugMessage(LoggerClassPrefixes.AlarmManager, DebugLoggingSubCategory.Alarms, () =>
                        {
                            return string.Format("{0} -> ADD ALARM -> [{1}] -> Alarm Count = [{2}].", (this is UnacknowledgedAlarmsQueue<T>) ? "UNACK QUEUE" : "EVENT QUEUE", alarm.Description(), alarmCount);
                        });
                    }
                }
            }
        }

        /// <summary>
        /// Remove oldest alarm from alarms map.
        /// </summary>
        /// <returns>True if oldest alarm has been successfully removed, False otherwise.</returns>
        private bool removeOldest()
        {
            DateTime oldestTimeStamp = DateTime.MaxValue;
            int areaId = -1;
            T oldestEvent = null;
            foreach (var alarmAreaPair in alarmsQueue)
            {
                var alarmsList = alarmAreaPair.Value;
                if (alarmsList.Count == 0)
                    continue;
                // Get oldest event, this would be the 1st in the list
                var alarm = alarmsList[0];
                if (alarm != null)
                {
                    DateTime currentTimestamp = alarm.UtcTimestamp;
                    if (currentTimestamp < oldestTimeStamp)
                    {
                        oldestTimeStamp = currentTimestamp;
                        areaId = alarmAreaPair.Key;
                        oldestEvent = alarm;
                    }
                }
            }
            if (areaId >= 0 && oldestEvent != null)
            {
                alarmsQueue[areaId].RemoveAt(0);
                alarmCount--;
                if (alarmsQueue[areaId].Count == 0)
                {
                    // No more alarms exist for this area
                    alarmsQueue.Remove(areaId);
                }
                return true;
            }
            return false;
        }

        #region IDisposable Members

        internal virtual void Cleanup() 
        {
            try
            {
                alarmsQueue.Clear();
                alarmsQueue = null;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AlarmManager, () =>
                {
                    return string.Format("Unexpected error during disposing of alarms queue instance. {0}", ex.ToString());
                });
            }
        }

        protected bool disposed = false;
        protected bool disposing = false;

        private void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                if (disposing)
                {
                    this.disposing = true;
                    this.Cleanup();
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
