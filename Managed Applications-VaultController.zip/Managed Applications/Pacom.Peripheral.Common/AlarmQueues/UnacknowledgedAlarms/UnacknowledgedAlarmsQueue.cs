﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Reflection;
using Pacom.Core.Contracts;
using Pacom.Events.EventsCommon;
using Pacom.Peripheral.Common.Status;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Core.Contracts.Messages;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common
{
    public class UnacknowledgedAlarmsQueue<T> : AlarmsQueueBase<T> where T : EventMessageBase
    {
        public UnacknowledgedAlarmsQueue()
            : base()
        {
            Capacity = MaxUnacknowledgedAlarmCount;
        }

        /// <summary>
        /// This list can store only this many alarms. When the list is full the oldest unacknowledged
        /// alarm will be removed before adding a new alarm. 
        /// </summary>
        private const int MaxUnacknowledgedAlarmCount = 1000;

        #region IAlarmsQueue<T> Members

        /// <summary>
        /// Remove alarm from areaId list
        /// </summary>
        /// <param name="areaId">Area ID for which first alarm will be removed.</param>
        /// <param name="alarm">Alarm to remove from list</param>
        /// <returns>True if the alarm was successfully removed.</returns>
        public override bool RemoveAlarm(int areaId, T alarm)
        {
            lock (alarmsMapSync)
            {
                List<T> areaAlarms = null;
                if (alarmsQueue.TryGetValue(areaId, out areaAlarms) == true)
                {
                    if (areaAlarms.Count > 0 && alarm != null)
                    {
                        if (areaAlarms[areaAlarms.Count - 1] == alarm)
                            areaAlarms.RemoveAt(areaAlarms.Count - 1);
                        else
                            areaAlarms.Remove(alarm);
                        if (alarm.ReportableEventType.Has(ReportableEventType.AddToUnAcknowledgedAlarmQueue) == true)
                        {
                            IStatusItem alarmSender = StatusManager.Instance[alarm.Category, (int)alarm.Id];
                            if (alarmSender != null)
                                alarmSender.ResetSuspectCount();
                        }
                        alarmCount--;
                        Logger.LogDebugMessage(LoggerClassPrefixes.AlarmManager, DebugLoggingSubCategory.Alarms, () =>
                        {
                            return string.Format("ACK ALARM -> [{0}] -> Alarm Count = [{1}].", alarm.Description(), alarmCount);
                        });
                        if (alarmCount == 0)
                        {
                            MacroControl.Instance.EnqueueUnacknowledgedAlarmsQueueEmptyEvent();
                        }
                        return true;
                    }
                }
                return false;
            }
        }

        /// <summary>
        /// Check if area is disarmed
        /// </summary>
        /// <param name="areaId">Area Id to check</param>
        /// <returns>True if area is disarmed, False otherwise</returns>
        private bool areaDisarmed(int areaId)
        {
            AreaStatus areaStatus = StatusManager.Instance.Areas[areaId];
            if (areaStatus == null)
                return false;
            return areaStatus.Disarmed;
        }

        /// <summary>
        /// Check if the event needs to be acknowledged by the user. The events that need to be acknowledged are: 
        ///     - Intruder Alarm (Burglar Alarm)
        ///     - Hold-up Alarm (Raid Alarm)
        ///     - Input Trouble Alarm
        ///     - Device Tamper Alarm
        ///     - Device Offline Alarm
        ///     - Power Supply Alarms (AC Fail / Battery Fail / Charger Fail / Temperature Fail)
        ///     - Device Internal Battery Low / Fuse Fail Alarms
        ///     - Controller Offline to Front-End
        /// When adding a new event type if reportable the [ReportableEventType] property must be overriden and the
        /// bit field ReportableEventType.AddToAlarmQueue should be added.
        /// </summary>
        /// <param name="eventMessage">Event Message to check</param>
        /// <returns>True if the event is reportable, False otherwise.</returns>
        public override bool IsReportableEvent(T eventMessage)
        {
            if (eventMessage.ReportableEventType.Has(ReportableEventType.AddToUnAcknowledgedAlarmQueue) == false)
            {
                // The event is not reportable
                return false;
            }

            IRestoreStateEvent restorableEvent = eventMessage as IRestoreStateEvent;
            if (restorableEvent != null && restorableEvent.Restore == true)
            {
                // The Restore events are not reportable
                return false;
            }
            IEventContainsArea areaEvent = eventMessage as IEventContainsArea;
            if (areaEvent == null)
            {
                // A reportable non area event
                return true;
            }
            if (areaDisarmed(areaEvent.AreaId) == false)
            {
                // Area is armed and the event is reportable
                return true;
            }
            if (ConfigurationManager.Instance.ControllerConfiguration.KeypadOperationalMode == KeypadOperationalMode.CustomerSpecific1)
            {
                // Inditex requires events to show on the keypad in day mode
                return true;
            }
            IEventSourceLatched latchedEvent = eventMessage as IEventSourceLatched;
            // Area is disarmed, the event source is latched and the event is reportable
            return latchedEvent != null && latchedEvent.LatchStatus != EventSourceLatchStatus.NotLatched;
        }

        #endregion

        /// <summary>
        /// Save unacknowledged events to ASN1 file. One file will be created for each area.
        /// </summary>
        public void SaveToFile()
        {
            try
            {
                checkUnacknowledgedAlarmsDirectory();
                if (alarmCount == 0)
                    return;
                string alarmsFileName = string.Format("{0}\\alarmsQueue.alm", FileSystemPaths.UnacknowledgedAlarmsQueuePath);
                using (FileStream fileStream = new FileStream(alarmsFileName, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    foreach (var areaAlarms in alarmsQueue)
                    {
                        if (areaAlarms.Value.Count == 0)
                            continue;
                        foreach (EventMessageBase eventMessage in areaAlarms.Value)
                        {
                            EventSerializer.Serialize(fileStream, eventMessage);
                        }
                    }
                }
            }
            catch (IOException ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("IOException while saving [Unacknowledged Alarms Queue] to ASN.1 file: {0}", ex.ToString());
                });
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Unable to save [Unacknowledged Alarms Queue] to ASN.1 file: {0}", ex.ToString());
                });
            }
        }

        /// <summary>
        /// Load unacknowledged events from ASN1 file. There is one file for each area
        /// </summary>
        public void LoadFromFile()
        {
            if (Directory.Exists(FileSystemPaths.UnacknowledgedAlarmsQueuePath) == false)
                return;
            string[] files = Directory.GetFiles(FileSystemPaths.UnacknowledgedAlarmsQueuePath, "*.alm");
            if (files.Length != 1)
            {
                DirectoryExtensions.Recreate(FileSystemPaths.UnacknowledgedAlarmsQueuePath);
                return;
            }

            string alarmsFileName = files[0];
            try
            {
                using (FileStream fileStream = new FileStream(alarmsFileName, FileMode.Open))
                {
                    EventMessageBase message = null;
                    while (fileStream.Position < fileStream.Length)
                    {
                        try
                        {
                            message = (EventMessageBase)EventSerializer.Deserialize(fileStream);
                            if (message == null)
                                continue;
                            AddAlarm((T)message);
                        }
                        catch (Exception ex)
                        {
                            Logger.LogErrorMessage(LoggerClassPrefixes.AlarmManager, () =>
                            {
                                return string.Format("Failed loading event message at position {0} from {1} file. Handled exception : {2}",
                                    fileStream.Position, Path.GetFileName(alarmsFileName), ex.ToString());
                            });
                            continue;
                        }
                    }
                }
            }
            catch (IOException ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AlarmManager, () =>
                {
                    return string.Format("IOException while loading [Unacknowledged Alarms Queue] from ASN.1 file: {0}", ex.ToString());
                });
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AlarmManager, () =>
                {
                    return string.Format("Unable to load [Unacknowledged Alarms Queue] from ASN.1 file: {0}", ex.ToString());
                });
            }
            finally
            {
                try
                {
                    CommonUtilities.DeleteFile(alarmsFileName);
                }
                catch
                {
                }
            }
        }

        /// <summary>
        /// Check unacknowledged alarms directory. If exists remove any files, otherwise create this directory.
        /// </summary>
        private void checkUnacknowledgedAlarmsDirectory()
        {
            if (Directory.Exists(FileSystemPaths.UnacknowledgedAlarmsQueuePath) == true)
            {
                string[] files = Directory.GetFiles(FileSystemPaths.UnacknowledgedAlarmsQueuePath, "*.alm");
                if (files.Length == 0)
                    return;
                foreach (string file in files)
                {
                    CommonUtilities.DeleteFile(file);
                }
            }
            DirectoryExtensions.Recreate(FileSystemPaths.UnacknowledgedAlarmsQueuePath);
        }
    }
}
