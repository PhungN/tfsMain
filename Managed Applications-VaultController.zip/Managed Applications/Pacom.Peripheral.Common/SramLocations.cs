﻿
namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Sram configuration offsets
    /// </summary>
    public class SramLocations
    {
        /// <summary>
        /// Start of card buffer
        /// 
        /// 352 bytes buffers * 1000
        /// 
        /// </summary>
        public const int CardStartOffset = 0;
        public const int CardMemoryLength = 352000;

        /// <summary>
        /// Start of event queue
        /// 
        /// 352 bytes buffers * 1000
        /// 
        /// </summary>
        public const int EventQueueStartOffset = 352000;
        public const int EventQueueMemoryLength = 512000;

        /// <summary>
        /// Start of event queue descriptors
        /// 
        /// Number of descriptors: 2 bytes (Total: 2)
        /// Descriptors: (1 byte source, 2 bytes start, 2 bytes end) 5 bytes * 2002 (Total: 10010)
        /// Systems: (1 byte of (memory source, enable bit) + 2 bytes offset + 2 bytes descriptor number) * 8 (Total: 40)
        /// CRC: 4 bytes (Total: 4)
        /// 
        /// </summary>
        public const int EventQueueDescriptorsOffset = 864000;
        public const int EventQueueDescriptorsMemoryLength = 10016;

        /// <summary>
        /// Start of event queue systems buffer
        /// </summary>
        public const int EventQueueSystemsOffset = 874016;
        public const int EventQueueSystemsMemoryLength = 44;

        /// <summary>
        /// Start of event queue statistics (16 bytes per total counts and 16 bytes per high priority counts)
        /// </summary>
        public const int EventQueueStatisticsOffset = 874060;
        public const int EventQueueStatisticsLength = 32;
        
        /// <summary>
        /// Start of status manager offline storage
        /// </summary>
        public const int StatusOfflineStorageOffset = 874092;
        public const int StatusOfflineStorageLength = 173960;

        //
        // Free space: 244 bytes !!!
        //
        // Free = PacomIsKeyOffset - (UnisonCheckpointTagOffset + UnisonCheckpointTagLength)
        //

        /// <summary>
        /// Start of Unison Checkpoint Tag field. This is a 64 bit integer value (8 bytes in total).
        /// </summary>
        public const int UnisonCheckpointTagOffset = 1048296;
        public const int UnisonCheckpointTagLength = 8;

        /// <summary>
        /// Master Keys Offset
        /// 
        /// MasterKey: 32 bytes
        /// Commisioned: 1 byte
        /// 
        /// Total of 8 records
        /// 
        /// </summary>
        public const int MasterKeysOffset = 1048308;
        public const int MasterKeysMemoryLength = 264;

        /// <summary>
        /// TimeZone offset minutes 1 byte only
        /// </summary>
        public const int TimeZoneOffsetMinutesOffset = 1048572;
        public const int TimeZoneOffsetMinutesMemoryLength = 4;
    }
}
