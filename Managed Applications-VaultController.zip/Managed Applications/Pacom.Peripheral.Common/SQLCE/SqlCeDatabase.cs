﻿using System;
using System.IO;
using System.Data.Common;
using Pacom.Configuration.ConfigurationCommon;
using System.Data.SqlServerCe;

namespace Pacom.Peripheral.Common.SQLCE
{
    /// <summary>
    /// Class preparing and validating the default SQL CE database.
    /// </summary>
    public class SqlCeDatabase : IDisposable
    {
        /// <summary>
        /// Schema version in the default database.
        /// Read the metadata table.
        /// </summary>
        public int DatabaseVersion = 1;

        /// <summary>
        /// Default Constructor
        /// </summary>
        private SqlCeDatabase()
        {
            validateDefaultDatabase();
        }
        
        /// <summary>
        /// Only one instance of the SqlCeDatabase will be created
        /// </summary>
        private static SqlCeDatabase instance = null;
        public static SqlCeDatabase CreateInstance()
        {
            if (instance == null)
                instance = new SqlCeDatabase();
            return instance;
        }

        public static SqlCeDatabase Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.Database, () =>
                    {
                        return "Instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
#endif
                return instance;
            }
        }

        private bool defaultDatabaseIsValid = false;
        private string password2 = "_*&^";
        private string password1 = "%$Pa7om01";
        private string password3 = "%&^$Ee_9%";

        public string Password
        {
            get
            {
                return string.Format("{0}{1}{2}", password1, password2, password3);
            }
        }

        public const string ConnectionStringTemplate = "DataSource=\"{0}\"; Password='{1}'; Max Database Size=500;";

        public string DefaultConnectionString
        {
            get
            {
                return string.Format(ConnectionStringTemplate, FileSystemPaths.DatabaseFilename, Password);
            }
        }

        public bool DefaultDatabaseIsValid
        {
            get
            {
                return defaultDatabaseIsValid;
            }
        }

        /// <summary>
        /// Verify default database. If the database does not exist create it.
        /// </summary>
        private void validateDefaultDatabase()
        {
            try
            {
                // If SD card is not present make the default database not valid
                if (SDCardLocations.IsSDCardMounted() == false)
                {
                    defaultDatabaseIsValid = false;
                    return;
                }

                int count = 0;
                bool repeat = true;
                while (repeat == true)
                {
                    repeat = false;

                    // Too many times tried to create the database
                    if (count > 2)
                    {
                        DeleteDatabase();
                    }
                    else if (count > 5)
                    {
                        defaultDatabaseIsValid = false;
                        return;
                    }
                    count++;

                    if (DatabaseExists() == false)
                    {
                        // Create fresh database
                        CreateDatabase();
                        using (DbConnection connection = OpenDatabase())
                        {
                            connection.Open();

                            // Create table
                            DbCommand cmdCreate = connection.CreateCommand();
                            cmdCreate.CommandText =
                            @"    CREATE TABLE Metadata( " +
                             "      MetatdataKey NVARCHAR(255) NOT NULL UNIQUE, " +
                             "      Value NVARCHAR(255) NULL, " +
                             "      LastUpdated DATETIME DEFAULT GETDATE())";
                            cmdCreate.ExecuteNonQuery();

                            // Create metadata entry
                            DbCommand cmdInserVersion = connection.CreateCommand();
                            cmdInserVersion.CommandText = @"INSERT INTO Metadata(MetatdataKey, Value) VALUES('VERSION', @Version)";
                            cmdInserVersion.AddParameterWithValue("Version", DatabaseVersion);
                            cmdInserVersion.ExecuteNonQuery();

                            // Close the database
                            connection.Close();
                        }                        

                        // All good
                        defaultDatabaseIsValid = true;
                        return;
                    }
                    else
                    {
                        try
                        {
                            using (DbConnection connection = OpenDatabase())
                            {
                                connection.Open();

                                // Query fo rthe metadata table
                                if (connection.TableExists("Metadata") == false)
                                {
                                    // Metadata table does not exist
                                    // Close the connection and recreate the database
                                    connection.Close();
                                    File.Delete(FileSystemPaths.DatabaseFilename);
                                    repeat = true;
                                    continue;
                                }
                                // Query the version
                                DbCommand cmdSelectVersion = connection.CreateCommand();
                                cmdSelectVersion.CommandText = @"SELECT Value FROM Metadata WHERE MetatdataKey = 'VERSION'";
                                object version = cmdSelectVersion.ExecuteScalar();
                                if (version == null || !(version is string))
                                {
                                    // Metadata table exist but the version record is not present
                                    // Close the connection and recreate the database
                                    connection.Close();
                                    File.Delete(FileSystemPaths.DatabaseFilename);
                                    repeat = true;
                                    continue;
                                }
                                if (int.Parse((string)version) == DatabaseVersion)
                                {
                                    defaultDatabaseIsValid = true;
                                    return;
                                }
                                else
                                {
                                    defaultDatabaseIsValid = false;
                                    return;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.LogErrorMessage(LoggerClassPrefixes.Database, () =>
                            {
                                return string.Format("Error while opening database storage. {0}", ex.Message);
                            });
                            // The database could be corrupted when first time is opened
                            // Try to recreate it
                            repeat = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.Database, () =>
                {
                    return string.Format("Error while creating or opening database storage. {0}", ex.Message);
                });
                defaultDatabaseIsValid = false;
            }
        }

        public bool DatabaseExists()
        {
            return File.Exists(FileSystemPaths.DatabaseFilename);
        }

        public static void DeleteDatabase()
        {
            try
            {
                File.Delete(FileSystemPaths.DatabaseFilename);
            }
            catch
            {
            }
        }

        /// <summary>
        /// Create database with specified name and password.
        /// </summary>
        /// <param name="filename">Database name</param>
        /// <param name="password">Database access password</param>
        public void CreateDatabase(string filename, string password)
        {
            string connectionString = string.Format(ConnectionStringTemplate, filename, password);
            if (!File.Exists(filename))
            {
                using (SqlCeEngine en = new SqlCeEngine(connectionString))
                {
                    en.CreateDatabase();
                }
            }
        }

        /// <summary>
        /// Create default database
        /// </summary>
        public void CreateDatabase()
        {
            if (!File.Exists(FileSystemPaths.DatabaseFilename))
            {
                using (SqlCeEngine en = new SqlCeEngine(DefaultConnectionString))
                {
                    en.CreateDatabase();
                }
            }
        }

        /// <summary>
        /// Open database with specified name and password.
        /// </summary>
        /// <param name="filename">Database name</param>
        /// <param name="password">Database access password</param>
        /// <returns></returns>
        public DbConnection OpenDatabase(string filename, string password)
        {
            string connectionString = string.Format(ConnectionStringTemplate, filename, password);
            SqlCeConnection connection = new SqlCeConnection(connectionString);
            return connection;
        }

        /// <summary>
        /// Open default database
        /// </summary>
        /// <returns></returns>
        public DbConnection OpenDatabase()
        {
            SqlCeConnection connection = new SqlCeConnection(DefaultConnectionString);
            return connection;
        }

        #region IDisposable Members

        bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.               
                instance = null;
            }

            // Free any unmanaged objects here.            
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
