﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Data.SqlServerCe;
using System.Data;
using System.IO;

namespace Pacom.Peripheral.Common.SQLCE
{
    /// <summary>
    /// 
    /// </summary>
    public static class SqlCeExtentions
    {
        /// <summary>
        /// Check if table exists
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public static bool TableExists(this DbConnection connection, string tableName)
        {
            if (string.IsNullOrEmpty(tableName.Trim())) throw new ArgumentException("Invalid table name");
            SqlCeConnection ceConnection = (SqlCeConnection)connection;
            if (ceConnection.State != ConnectionState.Open)
            {
                throw new InvalidOperationException("TableExists requires an open and available Connection. The connection's current state is " + connection.State);
            }

            using (SqlCeCommand command = ceConnection.CreateCommand())
            {
                command.CommandType = CommandType.Text;
                command.CommandText = @"SELECT 1 FROM Information_Schema.Tables WHERE TABLE_NAME = @tableName";
                command.Parameters.AddWithValue("tableName", tableName);
                object result = command.ExecuteScalar();
                return result != null;
            }
        }

        /// <summary>
        /// Add parameter with value to the list of parameters.
        /// </summary>
        /// <param name="command"></param>
        /// <param name="parameterName">Parameter name.</param>
        /// <param name="value">Parameter value</param>
        public static void AddParameterWithValue(this DbCommand command, string parameterName, object value)
        {
            SqlCeCommand ceCommand = (SqlCeCommand)command;
            ceCommand.Parameters.AddWithValue(parameterName, value);
        }
    }
}
