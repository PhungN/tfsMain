﻿using System.IO;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class provides logging functionality.
    /// Logging is cached in memory and is written to nonvolatile memory upon USB insertion.
    /// </summary>
    public static partial class Logger
    {
        /// <summary>
        /// Device specific call for creating logs.
        /// </summary>
        public static void CreateDeviceSpecificLogs()
        {
        }

        /// <summary>
        /// Generic class for writing information about how long the system is up, and where it is connected to.
        /// </summary>
        /// <param name="tw"></param>
        public static void WriteUptimeInfo(TextWriter textWriter)
        {
        }

        /// <summary>
        /// Generic class for writing detailed system information.
        /// </summary>
        /// <param name="tw"></param>
        /// <param name="compact"></param>
        public static void WriteSystemInfo(TextWriter textWriter, bool compact)
        {
        }
    }
}
