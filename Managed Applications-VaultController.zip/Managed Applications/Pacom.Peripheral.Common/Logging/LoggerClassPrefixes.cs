﻿
namespace Pacom.Peripheral.Common
{
    public enum LoggerClassPrefixes
    {
        /// <summary>
        /// Logger prefix for Event Queue.
        /// </summary>
        EventQueue,

        /// <summary>
        /// Logger prefix for Controller Application.
        /// </summary>
        HostingApplication,

        /// <summary>
        /// Logger prefix for access control.
        /// </summary>
        AccessControlManager,

        /// <summary>
        /// Logger prefix for alarm manager.
        /// </summary>
        AlarmManager,

        /// <summary>
        /// Logger prefix for classes derived from DeviceLoopDeviceBase class.
        /// </summary>
        DeviceLoopDevice,

        /// <summary>
        /// Logger prefix for Device Loop manager class.
        /// </summary>
        DeviceLoopManager,

        /// <summary>
        /// Logger prefix for Device command set classes
        /// </summary>
        DeviceCommandSet,

        /// <summary>
        /// Logger prefix for Device command list classes
        /// </summary>
        DeviceCommandList,

        /// <summary>
        /// Logger prefix for Device message handler classes
        /// </summary>
        DeviceMessageHandler,

        /// <summary>
        /// Logger prefix for Device Loop Protocol Master Connection over RS485
        /// </summary>
        DeviceLoopRS485MasterConnection,

        /// <summary>
        /// Logger prefix for Device Loop Protocol Master Connection over IP/UDP
        /// </summary>
        DeviceLoopINetMasterConnection,
         
        /// <summary>
        /// Logger prefix for configuration manager.
        /// </summary>
        ConfigurationManager,

        /// <summary>
        /// Logger prefix for Dialup Connection.
        /// </summary>
        DialupConnection,

        /// <summary>
        /// Logger prefix for Dialup Manager.
        /// </summary>
        DialupManager,

        /// <summary>
        /// Logger prefix for Gprs Connection.
        /// </summary>
        GprsConnection,

        /// <summary>
        /// Logger prefix for Local device manager.
        /// </summary>
        LocalDeviceManager,

        /// <summary>
        /// Logger prefix for keypad state machine.
        /// </summary>
        KeypadStateMachine,

        /// <summary>
        /// Logger prefix for Macro Manager
        /// </summary>
        MacroManager,

        /// <summary>
        /// Logger prefix for Status Manager
        /// </summary>
        StatusManager,
        
        /// <summary>
        /// Logger prefix for RS232Connection
        /// </summary>
        RS232Connection,

        /// <summary>
        /// Logger prefix for RS485Connection
        /// </summary>
        RS485Connection,

        /// <summary>
        /// Logger prefix for RS485ExpansionConnection
        /// </summary>
        RS485ExpansionConnection,

        /// <summary>
        /// Logger prefix for TcpIPConnection
        /// </summary>
        TcpIPConnection,

        /// <summary>
        /// Logger prefix for UdpConnection
        /// </summary>
        UdpConnection,

        /// <summary>
        /// Logger prefix for OpenPacomConnection
        /// </summary>
        OpenPacomConnection,

        /// <summary>
        /// Logger prefix for TcpIPManager
        /// </summary>
        TcpIPManager,

        /// <summary>
        /// Logger prefix for card reader interface
        /// </summary>
        CardReaderInterface,
        
        /// <summary>
        /// Logger prefix for one touch button
        /// </summary>
        OneTouchButton,

        /// <summary>
        /// Logger prefix for system logger manager
        /// </summary>
        SysLogManager,

        /// <summary>
        /// Logger prefix for web server
        /// </summary>
        WebServer,

        /// <summary>
        /// Logger prefix for Network Adapter
        /// </summary>
        NetworkAdapter,
   
        /// <summary>
        /// Logger prefix for PACOM Timer debugging
        /// </summary>
        PacomTimer,

        /// <summary>
        /// Logger prefix for front end logger manager
        /// </summary>
        FrontEndManager,

        /// <summary>
        /// Logger prefix for expansion card manager
        /// </summary>
        ExpansionManager,

        /// <summary>
        /// Logger prefix for OSDP Device Loop Protocol Master Connection
        /// </summary>
        OsdpDeviceLoopMasterConnection,

        /// <summary>
        /// Logger prefix for OSDP loop manager
        /// </summary>
        OsdpDeviceLoopManager,

        /// <summary>
        /// Logger prefix for Asis readers
        /// </summary>
        AsisProprietaryReader,

        /// <summary>
        /// Logger prefix for firmware manager
        /// </summary>
        FimrwareManager,

        /// <summary>
        /// Logger prefix for controller database messages
        /// </summary>
        Database,

        /// <summary>
        /// Logger prefix for singleton list
        /// </summary>
        SingletonList,

        /// <summary>
        /// Logger prefix for watchdog timer
        /// </summary>
        WatchdogTimer,

        /// <summary>
        /// Logger prefix for nand flash events
        /// </summary>
        NandFlash,

        /// <summary>
        /// Logger prefix for USB device events
        /// </summary>
        UsbDevice,

        /// <summary>
        /// Logger prefix for I2C bus events
        /// </summary>
        I2cBus,

        /// <summary>
        /// Logger prefix for SPI bus events
        /// </summary>
        SpiBus,
        
        /// <summary>
        /// Logger prefix for general purpose input/output events
        /// </summary>
        GeneralPurposeInputOutput,

        /// <summary>
        /// Logger prefix for card manager
        /// </summary>
        CardManager,

        /// <summary>
        /// Logger prefix for Inovonics EchoStream loop manager
        /// </summary>
        InovonicsDeviceLoopManager,

        /// <summary>
        /// Logger prefix for Inovonics EchoStream Protocol Master Connection over RS232
        /// </summary>
        InovonicsMasterConnection,

        /// <summary>
        /// Logger prefix for Status LED events
        /// </summary>
        StatusLed,

        /// <summary>
        /// Logger prefix for SiaOverIPConnection
        /// </summary>
        SiaOverIPConnection,

        /// <summary>
        /// Logger prefix for UdpIPManager
        /// </summary>
        UdpIPManager,

        /// <summary>
        /// Logger prefix for Peer To Peer Communications
        /// </summary>
        PeerToPeer,

        /// <summary>
        /// Logger prefix for Card Scan Processor.
        /// </summary>
        CardScanProcessor,

        /// <summary>
        /// Logger prefix for Aperio
        /// </summary>
        Aperio,
    }

    internal class LoggerClassPrefixesDescriptions
    {
        internal static string GetString(LoggerClassPrefixes prefix)
        {
            switch (prefix)
            {
                case LoggerClassPrefixes.HostingApplication: return "CONTROLLER: ";
                case LoggerClassPrefixes.EventQueue: return "EVENTQUEUE: ";                
                case LoggerClassPrefixes.AccessControlManager: return "ACCESSCONTROL: ";
                case LoggerClassPrefixes.AlarmManager: return "ALARMMGR: ";
                case LoggerClassPrefixes.DeviceLoopDevice: return "DEVICELOOPDEVICE: ";
                case LoggerClassPrefixes.DeviceLoopManager: return "DEVICELOOPMGR: ";
                case LoggerClassPrefixes.DeviceCommandSet: return "DEVICECOMMANDSET: ";
                case LoggerClassPrefixes.DeviceCommandList: return "DEVICECOMMANDLIST: ";
                case LoggerClassPrefixes.DeviceMessageHandler: return "DEVICEMESSAGEHANDLER: ";
                case LoggerClassPrefixes.DeviceLoopRS485MasterConnection: return "RS485MASTERCONN: ";
                case LoggerClassPrefixes.DeviceLoopINetMasterConnection: return "INETMASTERCONN: ";
                case LoggerClassPrefixes.ConfigurationManager: return "CONFIGMGR: ";
                case LoggerClassPrefixes.DialupConnection: return "DIALUPCON: ";
                case LoggerClassPrefixes.DialupManager: return "DIALUPMGR: ";
                case LoggerClassPrefixes.GprsConnection: return "GPRSCON: ";
                case LoggerClassPrefixes.LocalDeviceManager: return "LOCALDEVICE: ";
                case LoggerClassPrefixes.KeypadStateMachine: return "KEYPADSTATEMACHINE: ";
                case LoggerClassPrefixes.MacroManager: return "MACROMGR: ";
                case LoggerClassPrefixes.StatusManager: return "STATUSMGR: ";
                case LoggerClassPrefixes.RS232Connection: return "RS232CONNECTION: ";
                case LoggerClassPrefixes.RS485Connection: return "RS485CONNECTION: ";
                case LoggerClassPrefixes.RS485ExpansionConnection: return "RS485EXPANSIONCONNECTION: ";
                case LoggerClassPrefixes.TcpIPConnection: return "TCPIPCONNECTION: ";
                case LoggerClassPrefixes.UdpConnection: return "UDPCONNECTION: ";
                case LoggerClassPrefixes.OpenPacomConnection: return "OPENPACOM: ";
                case LoggerClassPrefixes.TcpIPManager: return "TCPIPMGR: ";
                case LoggerClassPrefixes.CardReaderInterface: return "CRI: ";
                case LoggerClassPrefixes.OneTouchButton: return "ONETOUCH: ";
                case LoggerClassPrefixes.SysLogManager: return "SYSLOG: ";        
                case LoggerClassPrefixes.WebServer: return "WEBSERVER: ";
                case LoggerClassPrefixes.NetworkAdapter: return "NET: ";     
                case LoggerClassPrefixes.PacomTimer: return "PACOMTIMER: ";
                case LoggerClassPrefixes.FrontEndManager: return "FRONTENDMGR: ";
                case LoggerClassPrefixes.ExpansionManager: return "EXPNMGR: ";
                case LoggerClassPrefixes.OsdpDeviceLoopMasterConnection: return "OSDPMASTERCONN: ";
                case LoggerClassPrefixes.OsdpDeviceLoopManager: return "OSDPLOOPMGR: ";
                case LoggerClassPrefixes.AsisProprietaryReader: return "APR: ";
                case LoggerClassPrefixes.FimrwareManager: return "FIRMWAREMGR: ";
                case LoggerClassPrefixes.Database: return "DATABASE: ";
                case LoggerClassPrefixes.SingletonList: return "SINGLETON: ";
                case LoggerClassPrefixes.WatchdogTimer: return "WDT: ";
                case LoggerClassPrefixes.NandFlash: return "NAND: ";
                case LoggerClassPrefixes.UsbDevice: return "USBDEVICE: ";
                case LoggerClassPrefixes.I2cBus: return "I2C: ";
                case LoggerClassPrefixes.SpiBus: return "SPI: ";
                case LoggerClassPrefixes.GeneralPurposeInputOutput: return "GPIO: ";
                case LoggerClassPrefixes.CardManager: return "CARDHOLDERMGR: ";
                case LoggerClassPrefixes.InovonicsDeviceLoopManager: return "INOVONICSDEVICELOOPMGR: ";
                case LoggerClassPrefixes.InovonicsMasterConnection: return "INOVONICSSERIALCONN: ";
                case LoggerClassPrefixes.SiaOverIPConnection: return "SIAOVERIP: ";
                case LoggerClassPrefixes.UdpIPManager: return "UDPIPMGR: ";
                case LoggerClassPrefixes.PeerToPeer: return "P2P: ";
                case LoggerClassPrefixes.CardScanProcessor: return "CARDSCANPROCESSOR: ";
                case LoggerClassPrefixes.Aperio: return "APERIO: ";
                default: return "CONTROLLER: ";
            }
        }        
    }
}
