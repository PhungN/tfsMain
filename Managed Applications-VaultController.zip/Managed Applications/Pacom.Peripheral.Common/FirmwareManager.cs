﻿using System;
using Pacom.Core.Contracts;
using System.IO;
using System.Threading;
using SharpCompress.Archive;
using SharpCompress.Common;
using System.Collections.Generic;
using System.Security.Cryptography;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.Utils;
using Pacom.Events.EventsCommon;

namespace Pacom.Peripheral.Common
{
    public class FirmwareManager : IDisposable
    {
        private static FirmwareManager instance = null;
        private ICryptoTransform encryptor;
        private static INandFlash nandFlash;
        private readonly object sync = new object();
        private bool firmwareUpdateInProgress = false;

        /// <summary>
        /// Device loop manger instance
        /// </summary>
        private IDeviceLoopManager deviceLoopManager = null;

        /// <summary>
        /// Triggered when the firmware update operation has changed state.
        /// </summary>
        public event EventHandler<FirmwareUpdateEventArgs> FirmwareUpdateChangedState = null;

        /// <summary>
        /// Triggered when update advances a step closer to completion.
        /// </summary>
        public event EventHandler<FirmwareUpdateStepProgressEventArgs> FirmwareUpdateStepProgress = null;

        private FirmwareManager()
        {
        }

        public static FirmwareManager CreateInstance(INandFlash flash)
        {
            nandFlash = flash;
            if (instance == null)
                instance = new FirmwareManager();
            return instance;
        }

        public static FirmwareManager Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.FimrwareManager, () =>
                    {
                        return "Instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
#endif
                return instance;
            }
        }

        public bool FirmwareUpdateInProgress
        {
            get 
            {
                return firmwareUpdateInProgress;
            }
        }

        public void SetDeviceLoopManager(IDeviceLoopManager manager)
        {
            deviceLoopManager = manager;
        }

        /// <summary>
        /// Triggered when the firmware update for a device has changed state
        /// </summary>
        /// <param name="logicalDeviceId">Device Logical Id</param>
        public void TriggerFirmwareUpdateChangedState(FirmwareUpdateEventArgs eventArgs)
        {
            if (FirmwareUpdateChangedState != null)
                FirmwareUpdateChangedState(null, eventArgs);
        }

        public bool ValidateRequest(string identifier)
        {
            int hashIndex = identifier.IndexOf('#');
            if (hashIndex != -1)
                identifier = identifier.Substring(0, hashIndex);
            if (identifier.Length == 0)
                return false;

            string[] identifierPortions = identifier.Substring(1).ToLower().Split(new char[] { '/' });
            if (identifierPortions.Length != 3)
                return false;
            if (identifierPortions[0] != "firmware")
                return false;
            if (identifierPortions[2].Length != 5)
                return false;
            if (identifierPortions[2][2] != '.')
                return false;
            if (identifierPortions[2][0] < '0' || identifierPortions[2][0] > 'f' ||
                (identifierPortions[2][0] > '9' && identifierPortions[2][0] < 'a'))
                return false;
            if (identifierPortions[2][1] < '0' || identifierPortions[2][1] > 'f' ||
                (identifierPortions[2][1] > '9' && identifierPortions[2][1] < 'a'))
                return false;
            if (identifierPortions[2][3] < '0' || identifierPortions[2][3] > 'f' ||
                (identifierPortions[2][3] > '9' && identifierPortions[2][3] < 'a'))
                return false;
            if (identifierPortions[2][4] < '0' || identifierPortions[2][4] > 'f' ||
                (identifierPortions[2][4] > '9' && identifierPortions[2][4] < 'a'))
                return false;

            try
            {
                Enum.Parse(typeof(HardwareType), identifierPortions[1], true);
            }
            catch
            {
                return false;
            }
            return true;
        }

        public bool ProcessFirmwareDownload(string firmwareFilePath, string identifier)
        {
            lock (sync)
            {
                if (firmwareUpdateInProgress == false)
                    firmwareUpdateInProgress = true;
                else
                    return false;
            }
            try
            {
                int hashIndex = identifier.IndexOf('#');
                if (hashIndex != -1)
                    identifier = identifier.Substring(0, hashIndex);

                string[] identifierPortions = identifier.Substring(1).ToLower().Split(new char[] { '/' });
                FirmwareVersion version = new FirmwareVersion(identifierPortions[2]);
                HardwareType hardwareType = (HardwareType)Enum.Parse(typeof(HardwareType), identifierPortions[1], true);

                if (hardwareType == HardwareType.Pacom8003)
                    return do8003FirmwareUpdate(firmwareFilePath);
                else
                    return doFirmwareUpdate(firmwareFilePath, version, getDeviceTypeFromHardwareType(hardwareType));
            }
            finally
            {
                firmwareUpdateInProgress = false;
            }
        }

        private DeviceType getDeviceTypeFromHardwareType(HardwareType hardwareType)
        {
            switch (hardwareType)
            {
                case HardwareType.Pacom8303: return DeviceType.Pacom8303;
                case HardwareType.Pacom8308: return DeviceType.Pacom8308;
                case HardwareType.Pacom1076DoorController: return DeviceType.Pacom1076DC;
                case HardwareType.Pacom1076InputOutput: return DeviceType.Pacom1076IO;
                case HardwareType.Pacom1064DoorController: return DeviceType.Pacom1064DC;
                case HardwareType.Pacom1064InputOutput: return DeviceType.Pacom1064IO;
                case HardwareType.Pacom8501: return DeviceType.Pacom8501;
                case HardwareType.Pacom8502InputOutput: return DeviceType.Pacom8502;
                case HardwareType.Pacom8603: return DeviceType.Pacom8603;
                case HardwareType.Pacom1076VaultController: return DeviceType.Pacom1076VC;
                default: return DeviceType.PacomController;
            }
        }

        public static string GetFirmwareFileName(DeviceType deviceType)
        {
            switch (deviceType)
            {
                case DeviceType.Pacom1064DC: return "P1064V5DC.epr";
                case DeviceType.Pacom1064IO: return "P1064V5IO.epr";
                case DeviceType.Pacom1076DC: return "P1076DC.epr";
                case DeviceType.Pacom1076IO: return "P1076IO.epr";
                case DeviceType.Pacom8303: return "P8301.epr";
                case DeviceType.Pacom8308: return "P8308.epr";
                case DeviceType.Pacom8501: return "P8501.bin";
                case DeviceType.Pacom8502: return "P8502.epr";
                case DeviceType.Pacom8603: return "P8603.bin";
                case DeviceType.Pacom8105: return "P8105.epr";
				case DeviceType.Pacom1076VC: return "Pacom1076VC.epr";
                default: return string.Empty;
            }
        }

        private bool doFirmwareUpdate(string firmwareFilePath, FirmwareVersion version, DeviceType deviceType)
        {
            try
            {
                TriggerFirmwareUpdateChangedState(new FirmwareUpdateEventArgs(0, deviceType, SoftwareDownloadState.Initialize));

                string firmwareFileName = GetFirmwareFileName(deviceType);
                if (string.IsNullOrEmpty(firmwareFileName) == false)
                {
                    string firmwareDownloadDir = FileSystemPaths.FirmwareDownloadPath + "\\";
                    string firmwareDownloadPath = firmwareDownloadDir + firmwareFileName;
                    CommonUtilities.DeleteFile(firmwareDownloadPath);
                    File.Move(firmwareFilePath, firmwareDownloadPath);
                    if (deviceLoopManager != null)
                    {
                        deviceLoopManager.UpdateFirmware(deviceType, firmwareDownloadDir, firmwareDownloadPath, version);
                        return true;
                    }
                }

                TriggerFirmwareUpdateChangedState(new FirmwareUpdateEventArgs(0, deviceType, SoftwareDownloadState.Failed));

                return false;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.FimrwareManager, () =>
                {
                    return string.Format("Firmware update for device type [{0}] failed: {1}", CommonUtilities.DeviceTypeDisplayName(deviceType), ex.ToString());
                });

                TriggerFirmwareUpdateChangedState(new FirmwareUpdateEventArgs(0, deviceType, SoftwareDownloadState.Failed));

                return false;
            }
        }

        private bool do8003FirmwareUpdate(string firmwareFilePath)
        {
            TriggerFirmwareUpdateChangedState(new FirmwareUpdateEventArgs(
                ConfigurationManager.Instance.ControllerConfiguration.Id, DeviceType.PacomController, SoftwareDownloadState.Start));
            triggerUpdateStepProcess("8003 firmware found.");
            for (int i = 0; i < 3; i++)
            {
                try
                {
                    DirectoryExtensions.Recreate(FileSystemPaths.FirmwareExtractPath);

                    triggerUpdateStepProcess("Decompressing 8003 firmware image.");
                    using (FileStream fileStream = File.OpenRead(firmwareFilePath))
                    {
                        using (IArchive archive = ArchiveFactory.Open(fileStream, Options.LookForHeader))
                        {
                            foreach (IArchiveEntry archiveEntry in archive.Entries)
                            {
                                if (archiveEntry.IsDirectory == false)
                                    archiveEntry.WriteToDirectory(FileSystemPaths.FirmwareExtractPath, ExtractOptions.Overwrite);
                            }
                        }
                        fileStream.Close();
                    }
                    break;
                }
                catch
                {
                }
            }

            bool parseResult = false;
            triggerUpdateStepProcess("Decompressing complete, checking checksums.");
            string[] files = Directory.GetFiles(FileSystemPaths.FirmwareExtractPath);
            if (files.Length == 2)
            {
                foreach (string fileName in files)
                {
                    if (Path.GetFileName(fileName).ToLower() == "meta.ini")
                    {
                        for (int i = 0; i < 3; i++)
                        {
                            try
                            {
                                parseResult = parseDownloadMetaData(fileName);
                                if (parseResult == true)
                                    Status.StatusManager.Instance.Controller.PopulateFirmwareInfo();
                                break;
                            }
                            catch (Exception ex)
                            {
                                Logger.LogErrorMessage(LoggerClassPrefixes.FimrwareManager, () =>
                                {
                                    return string.Format("Update process failed : {0}", ex);
                                });
                                triggerUpdateStepProcess(string.Format("8003 firmware failed. {0}", ex.Message));
                            }
                        }
                        break;
                    }
                }
            }
            TriggerFirmwareUpdateChangedState(new FirmwareUpdateEventArgs(
                ConfigurationManager.Instance.ControllerConfiguration.Id, DeviceType.PacomController,
                parseResult ? SoftwareDownloadState.End : SoftwareDownloadState.Failed));

            return parseResult;
        }

        private void triggerUpdateStepProcess(string message)
        {
            Logger.LogErrorMessage(LoggerClassPrefixes.FimrwareManager, () =>
            {
                return message;
            });
            if (FirmwareUpdateStepProgress != null)
                FirmwareUpdateStepProgress(this, new FirmwareUpdateStepProgressEventArgs(message));
        }

        public void DeleteFilesFromDownload()
        {
            if (Directory.Exists(FileSystemPaths.FirmwareDownloadPath) == true)
            {
                string[] files = Directory.GetFiles(FileSystemPaths.FirmwareDownloadPath);
                foreach (string file in files)
                {
                    File.Delete(file);
                    while (File.Exists(file))
                    {
                        Thread.Sleep(1);
                    }
                }
            }
            DirectoryExtensions.Recreate(FileSystemPaths.FirmwareExtractPath);
        }

        private bool parseDownloadMetaData(string fileName)
        {
            List<KeyValuePair<string, string>> imageDetails = new List<KeyValuePair<string, string>>();
            List<KeyValuePair<string, string>> md5Details = new List<KeyValuePair<string, string>>();

            using (StreamReader sr = new StreamReader(fileName))
            {
                bool imageSection = false;
                bool md5Section = false;

                string line;
                line = sr.ReadLine();
                while (line != null)
                {
                    if (line.Trim().ToLower() == "[image]")
                    {
                        imageSection = true;
                        md5Section = false;
                    }
                    else if (line.Trim().ToLower() == "[md5]")
                    {
                        imageSection = false;
                        md5Section = true;
                    }
                    else
                    {
                        string[] parts = line.Split(new char[] { '=' });
                        if (parts.Length == 2)
                        {
                            if (imageSection)
                                imageDetails.Add(new KeyValuePair<string, string>(parts[0].Trim().ToLower(), parts[1].Trim().ToLower()));
                            else if (md5Section)
                                md5Details.Add(new KeyValuePair<string, string>(parts[0].Trim(), parts[1].Trim()));
                        }
                    }

                    line = sr.ReadLine();
                }
                sr.Close();
            }

            int length = 32 * 1024 * 1024; // 32MB
            int crc = 0;
            FirmwareVersion newVersion = new FirmwareVersion();
            int buildNumber = 0;
            string target = "8003";
            foreach (KeyValuePair<string, string> kvp in imageDetails)
            {
                if (kvp.Key == "length")
                {
                    length = int.Parse(kvp.Value);
                }
                else if (kvp.Key == "crc")
                {
                    crc = int.Parse(kvp.Value);
                }
                else if (kvp.Key == "buildnumber")
                {
                    buildNumber = int.Parse(kvp.Value);
                }
                else if (kvp.Key == "version")
                {
                    newVersion = new FirmwareVersion(kvp.Value);
                }
                else if (kvp.Key == "target")
                {
                    target = kvp.Value;
                }
            }

            if (target != "8003")
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.FimrwareManager,
                                       () => String.Format("Firmware is not for an 8003, is for {0}", target));
                return false;
            }

            if (md5Details.Count > 1)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.FimrwareManager, () =>
                {
                    return "Too many files in update archive!";
                });
                return false;
            }

            foreach (KeyValuePair<string, string> kvp in md5Details)
            {
                if (kvp.Value.Length == 32)
                {
                    byte[] expectedHash = new byte[16];
                    for (int i = 0; i < 32; i += 2)
                    {
                        expectedHash[i / 2] = byte.Parse(kvp.Value.Substring(i, 2), System.Globalization.NumberStyles.HexNumber);
                    }
                    byte[] actualHash = getHash(Path.GetDirectoryName(fileName) + "\\" + kvp.Key);
                    if (expectedHash.SequenceEqual(actualHash) == false)
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.FimrwareManager, () =>
                        {
                            return string.Format("MD5 error during firmware update. Actual MD5 of {0} is {1} but expected is {2}", 
                                kvp.Key, BitConverter.ToString(actualHash).Replace("-", ""), BitConverter.ToString(expectedHash).Replace("-", ""));
                        });
                        return false;
                    }
                }
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.FimrwareManager, () =>
            {
                return "All files valid, firmware update proceeding. Copying...";
            });
            return nandFlash.ApplyFirmwareUpdate(Path.GetDirectoryName(fileName) + "\\" + md5Details[0].Key, length, crc, newVersion, buildNumber);
        }

        private byte[] getHash(string fileName)
        {
            byte[] hash;

            using (MD5 md5Hash = MD5.Create())
            {
                FileStream stream = new FileStream(fileName, FileMode.Open);
                hash = md5Hash.ComputeHash(stream);
                stream.Close();
                stream.Dispose();
            }

            if (encryptor == null)
            {
                RijndaelManaged aesAlgorithm = new RijndaelManaged();
                aesAlgorithm.KeySize = 128;
                aesAlgorithm.Key = new byte[] { 0xC7, 0x71, 0x23, 0x77, 0x2C, 0xD2, 0xED, 0xF4, 0xE6, 0x6F, 0x77, 0x36, 0x48, 0xCF, 0x3, 0xC6 };
                aesAlgorithm.Mode = CipherMode.CBC;
                aesAlgorithm.Padding = PaddingMode.None;
                aesAlgorithm.IV = new byte[] { 0xDA, 0xEB, 0x9D, 0x7A, 0x93, 0x8F, 0x7E, 0x5F, 0xD9, 0x17, 0x7, 0x29, 0xDC, 0x4B, 0x5, 0x8C };
                encryptor = aesAlgorithm.CreateEncryptor();
            }

            byte[] encryptedHash = encryptor.TransformFinalBlock(hash, 0, 16);

            return encryptedHash;
        }

        public void Dispose()
        {
            instance = null;
            GC.SuppressFinalize(this);
        }
    }
}