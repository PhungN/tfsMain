﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Status
{
    public sealed class ReaderStatus : StatusBase<ReaderStatusList>
    {
        private bool online = false;
        private bool radioFault = false;
        private bool batteryFail = false;

        private ReaderOfflineStatusType offlineType;

        private bool tamperActive = false;

        private ReaderMultiBadgingStatus multiBadgingStatus = null;
        public ReaderMultiBadgingStatus MultiBadgingStatus { get { return multiBadgingStatus; } }

        public ReaderMode ModeChange { get; set; }
        public ReaderState StateChange { get; set; }
        public CardStatus CardStatusChange { get; set; }

        public ReaderStatus(ConfigurationBase configuration, DoorStatus door, bool isKeypadParentDevice, ReaderStatusList parent, ReaderStatusStorage previousStatus) :
            base(configuration, parent)
        {
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Adding reader status for Id {0}.", configuration.Id);
            });
#endif
            mode = Reader8003ScheduleLevel.Blocked;
            isolated = false;
            online = Parent.GetReaderInitialOnlineState(this.LogicalId);
            if (this.online == true)
                this.offlineType = ReaderOfflineStatusType.Online;
            else
                this.offlineType = ReaderOfflineStatusType.Offline;
            ParentDoor = door;
            this.isKeypadParentDevice = isKeypadParentDevice;
            if (door == null || door.Enabled == false)
                agentInstance = new ReaderAgent(this);
            else
                agentInstance = new DummyReaderAgent();
            IDeviceLoopDCDevice dcDevice = ConfigurationManager.Instance.GetDeviceConfiguration(ParentDeviceId) as IDeviceLoopDCDevice;
            if (dcDevice != null)
            {
                canUpdateDoorPeripherals = dcDevice.CanReaderUpdateDoorPeripherals(ConfigurationManager.Instance.GetReaderConfiguration(LogicalId));
            }
            tamperActive = false;
            ModeChange = ReaderMode.None;
            StateChange = ReaderState.None;
            CardStatusChange = CardStatus.None;

            IReaderConfiguration readerConfig = configuration as IReaderConfiguration;
            if (readerConfig != null && readerConfig.ReaderCategory != ReaderCategory.Normal && door != null) 
            {
                multiBadgingStatus = new ReaderMultiBadgingStatus(door.LogicalId, this.LogicalId, readerConfig.ReaderCategory);
            }

            if (previousStatus == null || this.Enabled == false)
                return;

            if ((ParentDoor != null && ParentDoor.LogicalId == previousStatus.ParentDoorLogicalId) || (ParentDoor == null && previousStatus.ParentDoorLogicalId == 0))
            {
                mode = previousStatus.Mode;
                forcedDuringDay = previousStatus.ForcedDay;
                forcedDuringIntervalOffset = previousStatus.ForcedIntervalOffset;
                forcedMode = previousStatus.ForcedMode;
                // Update reader forced flag
                DayType scheduleDayType;
                int scheduleIntervalOffset;
                Reader8003ScheduleLevel scheduleLevel;
                getCurrentReaderScheduleMode(out scheduleDayType, out scheduleIntervalOffset, out scheduleLevel);
                if (scheduleDayType != forcedDuringDay || scheduleIntervalOffset != forcedDuringIntervalOffset)
                {
                    // When the schedule interval changes revert to schedule mode
                    forcedMode = ReaderModeForcedType.Normal;
                    forcedDuringDay = DayType.None;
                    forcedDuringIntervalOffset = 0;
                }

                if (previousStatus.OfflineType == ReaderOfflineStatusType.SuspectedOffline)
                {
                    this.online = previousStatus.Online;
                    this.offlineType = previousStatus.OfflineType;
                }

                radioFault = previousStatus.RadioFault;
                batteryFail = previousStatus.BatteryFail;

                RefreshAfterConfigurationChange();
            }
        }

        internal void RefreshAfterConfigurationChange()
        {
            if (isolated)
            {
                IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(LogicalId);
                if (readerConfig != null && readerConfig.AreaId > 0)
                {
                    AreaStatus areaStatus = StatusManager.Instance.Areas[readerConfig.AreaId];
                    if (areaStatus != null)
                        areaStatus.AddPointToIsolatedList(this);
                }
            }
        }

        internal void PostInitialize()
        {
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(LogicalId);
            DoorConfiguration doorConfig = readerConfig.Door;
            if (doorConfig != null)
            {
                var door = StatusManager.Instance.Doors[doorConfig.Id];
                if (ParentDoor != door)
                {
                    ParentDoor = door;

                    if (ParentDoor == null)
                    {
                        if (agentInstance is DummyReaderAgent)
                            agentInstance = new ReaderAgent(this);
                    }
                    else
                    {
                        if (door.Enabled == false && agentInstance is DummyReaderAgent)
                            agentInstance = new ReaderAgent(this);
                    }
                }
            }
            else if (ParentDoor != null)
            {
                ParentDoor = null;
                if (agentInstance is DummyReaderAgent)
                    agentInstance = new ReaderAgent(this);
            }
        }

        /// <summary>
        /// Get / Set reader online / offline status
        /// </summary>
        public bool Online
        {
            get
            {
                return this.online;
            }
            set
            {
                if (Enabled == false)
                    return;

                if (offlineType != ReaderOfflineStatusType.SuspectedOffline &&
                    online == true && value == false) // Device is going offline before restart / configuration change or during normal operation
                {
                    online = false;
                    offlineType = ReaderOfflineStatusType.SuspectedOffline;
                    if (StatusManager.Instance.SystemStatus == SystemStatusType.NormalOperation)
                    {
                        // Device went offline during normal operation
                        notifyReaderSuspectedOffline();
                    }
                }
                else if (offlineType == ReaderOfflineStatusType.SuspectedOffline &&
                         online == false && value == true && // Device is going online
                         StatusManager.Instance.SystemStatus == SystemStatusType.NormalOperation)
                {
                    // Notify frontend that the device is online again.
                    online = true;
                    offlineType = ReaderOfflineStatusType.Online;
                }
                else if (online != value)
                {
                    // Send the alarm events
                    online = value;
                    StatusManager.Instance.Readers.TriggerReaderOfflineStatusChanged(this);
                    StatusManager.Instance.RequestStatusToStorage();
                    if (online == true)
                    {
                        offlineType = ReaderOfflineStatusType.Online;
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Logical Reader {0} is online.", LogicalId);
                        });

                        if (ParentDoor != null)
                        {
                            DoorStatus doorStatus = StatusManager.Instance.Doors[ParentDoor.LogicalId];
                            if (doorStatus != null)
                                doorStatus.RequestCurrentDoorState();
                        }
                    }
                    else
                    {
                        offlineType = ReaderOfflineStatusType.Offline;
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Logical Reader {0} is offline.", LogicalId);
                        });
                    }
                    StateChange = online == true ? ReaderState.Online : ReaderState.Offline;
                }
            }
        }

        /// <summary>
        /// It is time to notify the alarm manager about the reader being in offline state for too long
        /// </summary>
        public void NotifyReaderInTrouble()
        {
            if (offlineType == ReaderOfflineStatusType.SuspectedOffline && online == false)
            {
                // Bring suspected offline to online. Make it first online over the underlining property value.                
                online = true;
                // Make the offline alarm go out.
                this.Online = false;
                offlineType = ReaderOfflineStatusType.Offline;                
            }
        }

        private void notifyReaderSuspectedOffline()
        {
            StatusManager.Instance.Readers.TriggerReaderSuspectedOffline(this);
        }

        /// <summary>
        /// Get / Set tamper active flag
        /// </summary>
        public bool TamperActive
        {
            get { return tamperActive; }
            set
            {
                if (Enabled == false)
                    return;
                if (tamperActive != value)
                {
                    bool previousTamperActive = tamperActive;
                    tamperActive = value;
                    if (Isolated == false)
                    {
                        if (tamperActive == true)
                        {
                            // Enqueue status change to expression manager
                            MacroControl.Instance.EnqueueReaderTamperActive(this.LogicalId);
                        }
                        StateChange = tamperActive == true ? ReaderState.Tamper : ReaderState.TamperReset;
                        StatusManager.Instance.Readers.TriggerTamperChangedStatus(this, previousTamperActive);
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        /// <summary>
        /// Get / Set radio fault flag
        /// </summary>
        public bool RadioFault
        {
            get { return radioFault; }
            set
            {
                if (Enabled == false)
                {
                    return;
                }
                if (radioFault == value)
                {
                    return;
                }

                radioFault = value;
                if (Isolated == true)
                {
                    return;
                }

                StateChange = radioFault == true ? ReaderState.RadioFault : ReaderState.RadioFaultReset;
                StatusManager.Instance.Readers.TriggerRadioFaultChangedStatus(this, radioFault);
                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        /// <summary>
        /// Get / Set battery problem flag
        /// </summary>
        public bool BatteryFail
        {
            get { return batteryFail; }
            set
            {
                if (Enabled == false)
                {
                    return;
                }
                if (batteryFail == value)
                {
                    return;
                }

                batteryFail = value;
                if (Isolated == true)
                {
                    return;
                }

                StateChange = batteryFail == true ? ReaderState.BatteryFail : ReaderState.BatteryFailReset;
                StatusManager.Instance.Readers.TriggerBatteryFailChangedStatus(this, batteryFail);
                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        public ReaderOfflineStatusType OfflineType
        {
            get
            {
                return offlineType;
            }
        }

        public override StatusItemType ItemType
        {
            get { return StatusItemType.ReaderStatus; }
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            ReaderEventState readerState = new ReaderEventState();
            readerState.Id = LogicalId;
            readerState.Isolate = Isolated;
            readerState.Block = Mode == Reader8003ScheduleLevel.Blocked;
            readerState.CardAndPinOperation = Mode == Reader8003ScheduleLevel.CardAndPin;
            readerState.CardOperation = Mode == Reader8003ScheduleLevel.CardOnly;
            readerState.Unlock = Mode == Reader8003ScheduleLevel.Unlocked;
            readerState.Lockout = LockedOut;
            readerState.Offline = Online == false;
            readerState.Tamper = TamperActive;
            return readerState;
        }

        /// <summary>
        /// Get display name for this reader status item instance without any alarms / isolated alarms
        /// </summary>
        /// <returns>Display Name string.</returns>
        public override string DisplayName
        {
            get
            {
                IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(LogicalId);
                if (readerConfig != null)
                    return string.Format("{0}{1} {2}", ConfigurationManager.Instance.ControllerConfiguration.ReaderPrefixText, LogicalId, readerConfig.GetName());
                return string.Empty;
            }
        }

        /// <summary>
        /// Get the string representation of the isolated alarms for this reader
        /// </summary>
        public override string IsolatedAlarmsAsString
        {
            get { return isolated == true ? " " + ConfigurationManager.Instance.ControllerConfiguration.IsolatedText : string.Empty; }
        }

        #region Forced and current reader schedule status

        private void getCurrentReaderScheduleMode(out DayType day, out int intervalOffset, out Reader8003ScheduleLevel level)
        {
            day = DayType.None;
            intervalOffset = 0;
            level = Reader8003ScheduleLevel.CardOnly;

            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(LogicalId);
            if (readerConfig == null || readerConfig.ScheduleId <= 0)
                return;
            ReaderSchedule readerSchedule = ConfigurationManager.Instance.GetReaderSchedule(readerConfig.ScheduleId);
            if (readerSchedule == null)
                return;

            day = readerSchedule.ScheduleDay;
            intervalOffset = readerSchedule.ScheduleIntervalOffset;
            level = readerSchedule.ScheduledLevel;
        }

        private DayType forcedDuringDay = DayType.None;

        public DayType ForcedDuringDay
        {
            get { return forcedDuringDay; }
        }

        private int forcedDuringIntervalOffset = 0;

        public int ForcedDuringIntervalOffset
        {
            get { return forcedDuringIntervalOffset; }
        }

        private ReaderModeForcedType forcedMode = ReaderModeForcedType.Normal;

        public ReaderModeForcedType ForcedMode
        {
            get { return forcedMode; }
        }

        /// <summary>
        /// This method restores reader mode to scheduled.
        /// </summary>
        /// <param name="newForcedMode"></param>
        public void RestoreForcedToNormal()
        {
            if (forcedMode != ReaderModeForcedType.Normal)
            {
                forcedMode = ReaderModeForcedType.Normal;
                forcedDuringDay = DayType.None;
                forcedDuringIntervalOffset = 0;
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("*** Setting reader forced schedule state to Day:{0}, Interval: {1} Mode:{2} ***",
                        forcedDuringDay.ToString(), forcedDuringIntervalOffset, forcedMode.ToString());
                });
#endif
                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        /// <summary>
        /// This method sets reader forced mode to UserForced.
        /// </summary>
        /// <param name="newForcedMode"></param>
        /// <param name="newForcedDuringDay"></param>
        /// <param name="newForcedDuringIntervalOffset"></param>
        public void SetUserForced(DayType newForcedDuringDay, int newForcedDuringIntervalOffset)
        {
            if (forcedMode != ReaderModeForcedType.UserForced)
            {
                forcedMode = ReaderModeForcedType.UserForced;
                forcedDuringDay = newForcedDuringDay;
                forcedDuringIntervalOffset = newForcedDuringIntervalOffset;
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("*** Setting reader forced schedule state to Day:{0}, Interval: {1} Mode:{2} ***",
                        forcedDuringDay.ToString(), forcedDuringIntervalOffset, forcedMode.ToString());
                });
#endif
                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        #endregion

        private bool canUpdateDoorPeripherals = false;
        public bool CanUpdateDoorPeripherals
        {
            get { return canUpdateDoorPeripherals; }
        }

        /// <summary>
        /// Reader lockout timer 
        /// </summary>
        private IPacomTimer lockoutTimer = null;
        
        /// <summary>
        /// Current invalid logon attempts count. This count is reset to 0 every time the lockoutTimer period expires. When
        /// the configured number of invalid attempts has been made the reader will be locked for the configured lockoutTime.
        /// When the lockoutTime expires the lockoutTimer is stopped and the invalid attempts count is reset to 0.
        /// </summary>
        private int invalidLogonAttempts = 0;

        public int InvalidLogonAttempts 
        {
            get { return invalidLogonAttempts; } 
        }

        /// <summary>
        /// An instance of a reader agent. This is only required if a reader has no door.
        /// </summary>
        private IReaderAgentInternal agentInstance = null;
        public IReaderAgent ReaderAgent
        {
            get { return agentInstance; }
        }

#if DEBUG
        /// <summary>
        /// Replace the Dummy Reader Agent with a real ReaderAgent instance in case the parent door 
        /// has been removed or disabled. This will be used when setting up the Reader Agent State 
        /// Machine unit tests because when the Reader Status is automatically created from configuration 
        /// the parent door is assigned and the DoorAgent State Machine will take precedence.
        /// </summary>
        public void SetReaderAgent()
        {
            if (ParentDoor != null && ParentDoor.Enabled == true)
                return;
            if (agentInstance != null && agentInstance is DummyReaderAgent == false)
                return;
            agentInstance = new ReaderAgent(this);
            canUpdateDoorPeripherals = true;
        }
#endif
        /// <summary>
        /// Triggered when access command is requested on the reader.
        /// </summary>
        public event EventHandler<AccessControlCommandRequestEventArgs> AccessControlCommandRequested = null;

        /// <summary>
        /// Broadcast access control commands in one transaction for the reader
        /// </summary>
        internal void TriggerAccessControlCommand(AccessControlCommandRequestEventArgs value)
        {
            if (AccessControlCommandRequested == null || value == null)
            {
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Unable to send access command request from reader {0} !!!", value.LogicalReaderId);
                });
#endif
                return;
            }
            AccessControlCommandRequested(this, value);
        }

        private bool isKeypadParentDevice = false;

        public bool IsKeypadParentDevice
        {
            get { return isKeypadParentDevice; }
        }

        public DoorStatus ParentDoor { get; set; }

        private bool isolated = false;

        /// <summary>
        /// Get reader isolated flag state.
        /// </summary>
        public bool Isolated
        {
            get { return isolated; }
        }

        /// <summary>
        /// Set reader isolated flag state.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public bool SetIsolated(bool value, UserAuditInfo userAuditInfo)
        {
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(LogicalId);
            if (Enabled == false || readerConfig == null)
                return false;

            if (isolated != value)
            {
                isolated = value;
                if (readerConfig.AreaId > 0)
                    StatusManager.Instance.Areas[readerConfig.AreaId].AddPointToIsolatedList(this);

                StateChange = isolated == true ? ReaderState.Isolated : ReaderState.Deisolated;
                StatusManager.Instance.Readers.TriggerChangedIsolatedStatus(this, isolated, userAuditInfo);
                StatusManager.Instance.RequestStatusToStorage();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Isolate reader.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Isolate(UserAuditInfo userAuditInfo)
        {
            SetIsolated(true, userAuditInfo);
        }

        /// <summary>
        /// Deisolate reader.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Deisolate(UserAuditInfo userAuditInfo)
        {
            SetIsolated(false, userAuditInfo);
        }

        /// <summary>
        /// Set isolated flag for any door point for a specified duration.
        /// </summary>
        /// <param name="value">True for isolate, false for normal operation.</param>
        /// <param name="bitField">Not Used.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="durationInSeconds">Not Used.</param>
        /// <returns>True if the point's isolated state was successfully changed, False otherwise.</returns>
        public override bool SetIsolated(bool value, EventSourceLatchOrIsolateType bitField, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            return SetIsolated(value, userAuditInfo);
        }

        private Reader8003ScheduleLevel mode = Reader8003ScheduleLevel.Blocked;

        public Reader8003ScheduleLevel Mode 
        {
            get { return mode; }
        }

        /// <summary>
        /// Set reader mode
        /// </summary>
        /// <param name="value">New reader mode</param>
        /// <param name="forced">Reader mode forced to specific value</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <returns></returns>
        public bool SetMode(Reader8003ScheduleLevel value, bool forced, UserAuditInfo userAuditInfo)
        {
            // 8003 keypad (Pacom8101) does not support CardAndPin - force reader mode to CardOnly in this case
            if (isKeypadParentDevice && value == Reader8003ScheduleLevel.CardAndPin)
                mode = Reader8003ScheduleLevel.CardOnly;

            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(LogicalId);
            if (Enabled == false || readerConfig == null || value == mode || ParentDeviceId < 1)
                return false;

            bool pendingTimedActionRemoved = StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.RestoreReaderModes, LogicalId);

            if (forcedMode == ReaderModeForcedType.Normal && forced == true)
            {
                DayType currentScheduleDay;
                int currentScheduleIntervalOffset;
                Reader8003ScheduleLevel currentLevel;
                getCurrentReaderScheduleMode(out currentScheduleDay, out currentScheduleIntervalOffset, out currentLevel);
                SetUserForced(currentScheduleDay, currentScheduleIntervalOffset);
            }
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
            {
                return string.Format("Reader {0} Mode changed to:{1}. Forced changed to Day:{2}, Interval:{3} Forced Mode:{4}", 
                    LogicalId, mode.ToString(), forcedDuringDay.ToString(), forcedDuringIntervalOffset, forcedMode.ToString());
            });
#endif
            Reader8003ScheduleLevel previousMode = mode;
            if (Isolated == false)
            {
                mode = value;
                StatusManager.Instance.Readers.TriggerReaderModeChanged(this, mode, previousMode, userAuditInfo);
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("ReaderId={0} status changed to [{1}]", LogicalId, mode);
                });
                if (ParentDoor != null && ParentDoor.Enabled == true)
                    ParentDoor.UpdateDoorStatusFromSchedule();
                else
                    agentInstance.UpdateAgentState(DoorAgentContexts.UpdateFromSchedule);
                StatusManager.Instance.RequestStatusToStorage();
                switch (mode)
                {
                    case Reader8003ScheduleLevel.Blocked:
                        ModeChange = ReaderMode.Locked;
                        break;
                    case Reader8003ScheduleLevel.Unlocked:
                        ModeChange = ReaderMode.Unlocked;
                        break;
                    case Reader8003ScheduleLevel.CardOnly:
                        ModeChange = ReaderMode.CardOnly;
                        break;
                    case Reader8003ScheduleLevel.CardAndPin:
                        ModeChange = ReaderMode.CardAndPin;
                        break;
                }
                return true;
            }
            return pendingTimedActionRemoved;
        }

        /// <summary>
        /// Force the reader mode for a single reader for a specified duration.
        /// Use the status list implementation if there is more than 1 reader to force the mode of. 
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="duration">The time for which to</param>
        /// <returns></returns>
        public bool SetMode(Reader8003ScheduleLevel value, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            bool result = SetMode(value, true, userAuditInfo);
            if (result == true && durationInSeconds > 0)
            {
                StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.RestoreReaderModes, LogicalId, userAuditInfo, durationInSeconds);
            }
            return result;
        }

        /// <summary>
        /// Restore reader status mode to the reader scheduled mode (the reader schedule based on the assigned schedule).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public bool RestoreMode(UserAuditInfo userAuditInfo)
        {
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(LogicalId);
            if (readerConfig != null && readerConfig.ScheduleId > 0)
            {
                ReaderSchedule readerSchedule = ConfigurationManager.Instance.ReaderSchedules.FirstOrDefault(sched => sched.Id == readerConfig.ScheduleId);
                if (readerSchedule != null)
                {
                    RestoreForcedToNormal();
                    return SetMode(readerSchedule.ScheduledLevel, false, userAuditInfo);
                }
            }
            return false;
        }

        /// <summary>
        /// Lockout timer procedure
        /// </summary>
        /// <param name="state">Not Used</param>
        private void lockoutTimerProc(object state)
        {
            if (disposed)
                return;
            StatusManager.Instance.Readers.TriggerReaderLockoutRestoreEvent(this);
            lockoutTimer.Stop();
            if (ParentDoor != null && ParentDoor.Enabled == true)
                ParentDoor.KeypadLockoutTimerExpired();
            else
                agentInstance.UpdateAgentState(DoorAgentContexts.KeypadLockoutTimerExpired);
        }

        /// <summary>
        /// Check if the reader is locked-out because of too many invalid login attempts.
        /// </summary>
        public bool LockedOut
        {
            get
            {
                IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(LogicalId);
                if (readerConfig == null)
                    return false;
                return lockoutTimer != null && lockoutTimer.Enabled;
            }
        }

        public void LockedOutCounterReset()
        {
            invalidLogonAttempts = 0;
            if (lockoutTimer == null || lockoutTimer.Enabled == false)
                return;

            lockoutTimer.Stop();
        }

        /// <summary>
        /// Lockout reader and restart lockout timer with the configured lockout time. The reader will be unlocked when the
        /// lockout time expires.
        /// </summary>
        public void SetLockedOut(out bool sendEvent)
        {
            sendEvent = false;
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(LogicalId);
            if (readerConfig == null)
                return;
            invalidLogonAttempts++;
            if (invalidLogonAttempts >= readerConfig.InvalidLogOnAttemptsTillLockout)
            {
                sendEvent = true;
                if (lockoutTimer == null)
                    lockoutTimer = TimerManager.Instance.CreateTimer(lockoutTimerProc);
                lockoutTimer.RunOnce((int)readerConfig.LockoutTime.TotalMilliseconds);
            }
        }
                
        public void SetBuzzerOn()
        {
            if (this.ParentDoor == null)
            {
                using (var transaction = StatusManager.Instance.GetAccessControlTransaction(this))
                {
                    transaction.SetBuzzerOn();
                }
            }
        }

        public void SetBuzzerOff()
        {
            if (this.ParentDoor == null)
            {
                using (var transaction = StatusManager.Instance.GetAccessControlTransaction(this))
                {
                    transaction.SetBuzzerOff();
                }
            }
        }

        public void SetAcceptLedOn()
        {
            if (this.ParentDoor == null)
            {
                using (var transaction = StatusManager.Instance.GetAccessControlTransaction(this))
                {
                    transaction.SetAcceptLedOn();
                }
            }
        }

        public void SetAcceptLedOff()
        {
            if (this.ParentDoor == null)
            {
                using (var transaction = StatusManager.Instance.GetAccessControlTransaction(this))
                {
                    transaction.SetAcceptLedOff();
                }
            }
        }

        public void SetDeniedLedOn()
        {
            if (this.ParentDoor == null)
            {
                using (var transaction = StatusManager.Instance.GetAccessControlTransaction(this))
                {
                    transaction.SetDeniedLedOn();
                }
            }
        }

        public void SetDeniedLedOff()
        {
            if (this.ParentDoor == null)
            {
                using (var transaction = StatusManager.Instance.GetAccessControlTransaction(this))
                {
                    transaction.SetDeniedLedOff();
                }
            }
        }

        /// <summary>
        /// Access door with pin
        /// </summary>
        /// <param name="logicalReaderId"></param>
        /// <param name="keyData"></param>
        public void AccessPinReceived(byte[] keyData)
        {
            if (Enabled == false)
                return;
            
            if (agentInstance.AssignPinTransaction(keyData) == true)
                agentInstance.UpdateAgentState(DoorAgentContexts.EndWaitForPinOnInReader);
        }

        /// <summary>
        /// Access door but wait for pin.
        /// </summary>
        /// <param name="cardFormat"></param>
        /// <param name="logicalReaderId"></param>
        public void AccessWaitForPin(CardNumberHolder cardNumber, Reader8003ScheduleLevel readerMode)
        {
            agentInstance.ClearValidCardTransaction();
            agentInstance.AssignValidCardTransaction(cardNumber, readerMode);
            agentInstance.UpdateAgentState(DoorAgentContexts.WaitForPinOnInReader);
        }

        /// <summary>
        /// Signal door access denied
        /// </summary>
        public void AccessDenied(AccessDeniedReason reason)
        {
            agentInstance.ClearValidCardTransaction();
            agentInstance.UpdateAgentState(DoorAgentContexts.DeniedAccess);
        }

        /// <summary>
        /// Access door with valid card
        /// </summary>
        /// <param name="cardFormat"></param>
        /// <param name="logicalReaderId"></param>
        /// <returns></returns>
        public bool AccessWithValidCard(CardInformation cardInformation, Reader8003ScheduleLevel readerMode, List<CardInformation> cardInformationList, ReaderBadgingType badgingType)
        {
            if (mode == Reader8003ScheduleLevel.Unlocked)
                return false;
            agentInstance.AssignValidCardTransaction(cardInformation, readerMode, cardInformationList, badgingType);
            return agentInstance.UpdateAgentState(DoorAgentContexts.ValidCard);
        }

        public void AccessWithValidCardPending()
        {
            agentInstance.UpdateAgentState(DoorAgentContexts.ValidMultiBadgingCard);
        }

        /// <summary>
        /// Update underlying reader hardware based on the reader agent and mode
        /// </summary>
        public void RequestCurrentReaderState()
        {
            agentInstance.UpdateAgentState(DoorAgentContexts.CurrentDoorStateRequest);
        }

        /// <summary>
        /// Request reset of the reader agent. Mostly after device is marked offline.
        /// </summary>
        public void ResetReaderAgent()
        {
            agentInstance.ClearValidCardTransaction();
            agentInstance.ResetAgent();
        }

        private CardReaderInterface cardReaderInterface = CardReaderInterface.Wiegand;
        public CardReaderInterface Interface 
        {
            get { return cardReaderInterface; }
            set
            {
                if (Enabled == false)
                    return;
                if (cardReaderInterface != value)
                {
                    cardReaderInterface = value;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        private ReaderManufacturer manufacturer = ReaderManufacturer.Unknown;
        public ReaderManufacturer Manufacturer
        {
            get { return manufacturer; }
            set
            {
                if (Enabled == false)
                    return;
                if (manufacturer != value)
                {
                    manufacturer = value;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        private string model = string.Empty;
        public string Model
        {
            get { return model; }
            set
            {
                if (Enabled == false)
                    return;
                if (model != value && value != null)
                {
                    model = value;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        private string hardwareRevision = string.Empty;
        public string HardwareRevision
        {
            get { return hardwareRevision; }
            set
            {
                if (Enabled == false)
                    return;
                if (hardwareRevision != value && value != null)
                {
                    hardwareRevision = value;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        private string serialNumber = string.Empty;
        public string SerialNumber
        {
            get { return serialNumber; }
            set
            {
                if (Enabled == false)
                    return;
                if (value != serialNumber && value != null)
                {
                    if (string.IsNullOrEmpty(serialNumber) == false)
                    {
                        // the serial number has changed
                        Logger.LogWarnMessage(LoggerClassPrefixes.Aperio,
                                              () => string.Format("Detected serial number substitution on reader {0} from {1} to {2}", LogicalId, serialNumber, value));
                    }
                    serialNumber = value;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        private string firmwareVersion = string.Empty;
        public string FirmwareVersion
        {
            get { return firmwareVersion; }
            set
            {
                if (Enabled == false)
                    return;
                if (firmwareVersion != value && value != null)
                {
                    firmwareVersion = value;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            ReaderStatusStorage statusStorage = new ReaderStatusStorage();
            if (statusStorage != null)
            {
                statusStorage.LogicalId = LogicalId;
                statusStorage.ParentDeviceId = ParentDeviceId;
                statusStorage.ParentDoorLogicalId = ParentDoor == null ? 0 : ParentDoor.LogicalId;
                statusStorage.Online = Online;
                statusStorage.OfflineType = OfflineType;
                statusStorage.ForcedMode = ForcedMode;
                statusStorage.ForcedIntervalOffset = ForcedDuringIntervalOffset;
                statusStorage.ForcedDay = ForcedDuringDay;
                statusStorage.Mode = Mode;
                statusStorage.RadioFault = RadioFault;
                statusStorage.BatteryFail = BatteryFail;
            }
            return statusStorage;
        }

        public override string ToString()
        {
            return String.Format("Reader Status [{0}]", this.LogicalId);
        }

        internal override void Cleanup()
        {
            if (lockoutTimer != null)
            {
                lockoutTimerProc(null);
                TimerManager.Instance.RemoveTimer(lockoutTimer);
                lockoutTimer = null;
            }
            if (agentInstance != null)
            {
                agentInstance.Dispose();
                agentInstance = null;
            }

#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Removing reader status with Id {0}.", this.LogicalId);
            });
#endif
        }

        public SecurityLevelDisplayCommand GetSecurityLevelDisplayCommand(out string text)
        {
            if (ParentDoor != null)
            {
                DoorStatus doorStatus = StatusManager.Instance.Doors[ParentDoor.LogicalId];
                if (doorStatus != null && doorStatus.Enabled == true)
                    return doorStatus.GetSecurityLevelDisplayCommand(out text);
            }

            text = "";
            switch (agentInstance.Context)
            {
                case DoorAgentContexts.CurrentDoorStateRequest:
                case DoorAgentContexts.UpdateFromSchedule:
                    if (Mode == Reader8003ScheduleLevel.Blocked)
                        return SecurityLevelDisplayCommand.DoorLocked;
                    else if (Mode == Reader8003ScheduleLevel.Unlocked)
                        return SecurityLevelDisplayCommand.DoorUnlocked;
                    return SecurityLevelDisplayCommand.WaitCard;
                default:
                    return SecurityLevelDisplayCommand.None;
            }
        }
    }
}
