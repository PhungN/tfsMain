﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.AccessControl;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.Utils;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Core.Contracts.Status;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Collection of all output statuses with utility functions
    /// </summary>
    public class InterlockGroupStatusList : StatusListBase<InterlockGroupStatus, InterlockGroupStatusList>
    {
        internal InterlockGroupStatusList() : base() {}


        /// <summary>
        /// Event fired when an interlock has been bypassed, or restored from bypass.
        /// </summary>
        public event EventHandler<InterlockBypassedEventArgs> InterlockBypassedEvent;

        public void TriggerInterlockBypassedEvent(int interlockId, bool bypassed, UserAuditInfo user)
        {
            if (InterlockBypassedEvent == null)
            {
                return;
            }
            InterlockBypassedEvent(this, new InterlockBypassedEventArgs(interlockId, bypassed, user));
        }

        public void Restore(List<int> interlockGroupIds, UserAuditInfo userAuditInfo)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () => "Restore Interlock Groups");
            foreach (int interlockId in interlockGroupIds)
            {
                InterlockGroupStatus interlockGroupStatus = this[interlockId];
                if (interlockGroupStatus != null && interlockGroupStatus.Enabled)
                {
                    interlockGroupStatus.SetBypassed(false, userAuditInfo, 0);
                }
            }
        }

        /// <summary>
        /// Update outputs status list from configuration. Add new output status instances if not already existing
        /// </summary>
        /// <param name="interlockGroups"></param>
        /// <param name="statusStorage">Status storage instance</param>
        internal void UpdateFromConfiguration(Interlock8003Configuration[] interlockGroups, StatusStorageCollection statusStorage)
        {
            foreach (var interlockGroup in interlockGroups)
            {
                Assign(interlockGroup.Id, new InterlockGroupStatus(interlockGroup, this, statusStorage.InterlockGroupStatus.TryGetValue(interlockGroup.Id)));
            }
        }

        /// <summary>
        /// Update Output status list from configuration on configuration change.
        /// </summary>
        internal void UpdateFromConfiguration(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems)
        {
            foreach (var removedItem in removedItems)
            {
                if (removedItem.ConfigurationType == ConfigurationElementType.InterlockGroup)
                    Remove(removedItem.Id);
            }
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.InterlockGroup)
                {
                    Remove(changedItem.Id);
                    try
                    {
                        Assign(changedItem.Id, new InterlockGroupStatus(ConfigurationManager.Instance.GetInterlockGroupConfiguration(changedItem.Id), this, null));
                    }
                    catch
                    {
                    }
                }
            }
            foreach (var newlyAddedItem in newlyAddedItems)
            {
                try
                {
                    if (newlyAddedItem.ConfigurationType == ConfigurationElementType.InterlockGroup)
                    {
                        Assign(newlyAddedItem.Id, new InterlockGroupStatus(ConfigurationManager.Instance.GetInterlockGroupConfiguration(newlyAddedItem.Id), this, null));
                    }
                }
                catch
                {
                }
            }
        }

        internal override void Persist(Asn1DerFormatter asn1Serializer, Stream statusStream)
        {
            foreach (InterlockGroupStatus interlockGroupStatus in Items)
            {
                try
                {
                    asn1Serializer.Serialize(statusStream, interlockGroupStatus.CreateStatusStorage());
                }
                catch (Exception ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Unable to store status for output {0}. {1}", interlockGroupStatus.LogicalId, ex.Message);
                    });
                }
            }
        }
    }
}
