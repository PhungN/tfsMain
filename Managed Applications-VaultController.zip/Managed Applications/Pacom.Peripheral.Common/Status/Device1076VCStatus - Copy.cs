﻿using Pacom.Core.Contracts;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Configuration.ConfigurationCommon;
using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Status
{
    //public enum OpenVaultStatus
    //{
    //    Idle = 0,
    //    TimingDown,
    //    Unlocked,
    //    Hastening,
    //    Alarm,
    //    Open,
    //}

    public sealed class Device1076VCStatus : Device1076DCStatus// DeviceLoopDeviceStatus, IDeviceStatus
    {
        public Device1076VCStatus(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus) :
            base(configuration, parent, previousStatus)
        {
            Status = VaultStatus.Idle;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            Device1076VCEventState deviceState = new Device1076VCEventState();
            InitializeEventState(deviceState);
            deviceState.InternalBatteryFail = MaskedInternalBatteryLow;
            return deviceState;
        }

        //public OpenVaultStatus Status { get; set; }
        public VaultStatus Status { get; set; }
        public VaultInputFlags InputStatus { get; private set; }
        public bool OpenVaultRunning { get { return openVaultTimer != null; } }

        #region private members
        private int waitTime;
        private int accessTime;
        private int preOpenTime;
        private int preAlarmTime;
        private IPacomTimer openVaultTimer = null;
        private IPacomTimer seismicTestTimer = null;
        #endregion

        public bool ExecuteCommand(VaultControllerCommandType commandType)
        {
            if (commandType == VaultControllerCommandType.OpenVault)
            {
                var configuration = ConfigurationManager.Instance.GetDeviceConfiguration(LogicalId) as Device1076VCConfiguration;
                waitTime = (int)configuration.WaitTimeBeforeOpeningVault.TotalMinutes;
                accessTime = configuration.VaultAccessPermanent == true ? 0 : (int)configuration.VaultAccessDuration.TotalMinutes;
                preOpenTime = (int)ConfigurationManager.Instance.ControllerConfiguration.PreOpenTime.TotalMinutes;
                preAlarmTime = (int)ConfigurationManager.Instance.ControllerConfiguration.PreAlarmHastenTime.TotalMinutes;
                openVault((byte)waitTime, (byte)accessTime, (byte)preOpenTime, (byte)preAlarmTime);
                openVaultTimer = TimerManager.Instance.CreateTimer(onOpenVaultTimeout);
                openVaultTimer.RunOnce(waitTime * 60 * 1000);
                Status = VaultStatus.TimingDown;
                StatusManager.Instance.VaultControllers.TriggerStatusChange(LogicalId, VaultStatus.OpenRequest, InputStatus);
                printMessage(string.Format("Opening Vault - Current Status: {0}", Status));
                return true;
            }
            else if (commandType == VaultControllerCommandType.CloseVault)
            {
                if (Status != VaultStatus.Idle)
                {
                    if (closeVault() == true)
                    {
                        killOpenVaultTimer();
                        Status = VaultStatus.Close;
                        var configuration = ConfigurationManager.Instance.GetDeviceConfiguration(LogicalId) as Device1076VCConfiguration;
                        StatusManager.Instance.VaultControllers.TriggerVaultStatusChanged(configuration.VaultControllerNumber, Status, InputStatus);
                    }
                }
            }
            else if (commandType == VaultControllerCommandType.PerformSeismicDetectorTest)
            {
                //sendCommand(2, new byte[] { 1 });
                setOuputState(VaultOutput.SeismicTest);
                printMessage("Seismic Test Started");
                seismicTestTimer = TimerManager.Instance.CreateTimer(onSeismicTestTimeout);
                seismicTestTimer.RunOnce(5000);
                return true;
            }
            return false;
        }

        public void TriggerAlarmResponse(int logicalDeviceId, Dictionary<VaultControllerInputType, bool> alarmsStatus)
        {
            var configuration = ConfigurationManager.Instance.GetDeviceConfiguration(LogicalId) as Device1076VCConfiguration;
            foreach (var alarmStatus in alarmsStatus)
            {
                if (alarmStatus.Key == VaultControllerInputType.SeismicDetector && alarmStatus.Value == false && seismicTestTimer != null)
                {
                    printMessage("Seismic Test Pass");
                    StatusManager.Instance.VaultControllers.TriggerStatusChange(logicalDeviceId, VaultStatus.TestPass, InputStatus);
                    killSeismicTestTimer();
                    sendCommand(2, new byte[] { 0 });
                }

                switch (alarmStatus.Key)
                {
                    case VaultControllerInputType.DoorContact:
                        if (alarmStatus.Value == false && openVaultTimer != null && Status == VaultStatus.Unlocked)
                        {
                            if (configuration.VaultAccessPermanent == true)
                            {
                                killOpenVaultTimer();
                                Status = VaultStatus.Open;
                                StatusManager.Instance.VaultControllers.TriggerStatusChange(logicalDeviceId, VaultStatus.Open, InputStatus);
                                sendCommand(2, new byte[] { 0 });
                            }
                            else
                            {
                                openVaultTimer.Stop();
                                openVaultTimer.RunOnce(preOpenTime * 60 * 1000);
                                Status = VaultStatus.Hastening;
                            }
                            printMessage(string.Format("Current Status: {0}", Status));
                            return;
                        }
                        else if (alarmStatus.Value == true && openVaultTimer != null && Status == VaultStatus.Hastening)
                        {
                            StatusManager.Instance.VaultControllers.TriggerStatusChange(logicalDeviceId, VaultStatus.Close, InputStatus);
                            StatusManager.Instance.VaultControllers.TriggerStatusChange(logicalDeviceId, VaultStatus.Locked, InputStatus);
                            killOpenVaultTimer();
                            Status = VaultStatus.Close;
                            printMessage(string.Format("Current Status: {0}", Status));
                            return;
                        }
                        else if (alarmStatus.Value == true && Status == VaultStatus.Open)
                        {
                            StatusManager.Instance.VaultControllers.TriggerStatusChange(logicalDeviceId, VaultStatus.Close, InputStatus);
                            StatusManager.Instance.VaultControllers.TriggerStatusChange(logicalDeviceId, VaultStatus.Locked, InputStatus);
                            Status = VaultStatus.Close;
                            printMessage(string.Format("Current Status: {0}", Status));
                            return;
                        }
                        else
                        {
                            killOpenVaultTimer();
                            if (alarmStatus.Value == true)
                                InputStatus = InputStatus.ClearFlags(VaultInputFlags.DoorContactAlarm);
                            else
                                InputStatus = InputStatus.SetFlags(VaultInputFlags.DoorContactAlarm);
                            Status = VaultStatus.Close;
                        }
                        break;
                    case VaultControllerInputType.DisplayTamper:
                        if (alarmStatus.Value == true)
                            InputStatus = InputStatus.ClearFlags(VaultInputFlags.DisplayTamperAlarm);
                        else
                            InputStatus = InputStatus.SetFlags(VaultInputFlags.DisplayTamperAlarm);
                        break;
                    case VaultControllerInputType.EmergencyStop:
                        if (alarmStatus.Value == true)
                            InputStatus = InputStatus.ClearFlags(VaultInputFlags.EmergencyStopAlarm);
                        else
                            InputStatus = InputStatus.SetFlags(VaultInputFlags.EmergencyStopAlarm);
                        break;
                    case VaultControllerInputType.Interlock:
                        if (alarmStatus.Value == true)
                            InputStatus = InputStatus.ClearFlags(VaultInputFlags.InterlockAlarm);
                        else
                            InputStatus = InputStatus.SetFlags(VaultInputFlags.InterlockAlarm);
                        break;
                    case VaultControllerInputType.LockSensor:
                        if (alarmStatus.Value == true)
                            InputStatus = InputStatus.ClearFlags(VaultInputFlags.LockSensorAlarm);
                        else
                            InputStatus = InputStatus.SetFlags(VaultInputFlags.LockSensorAlarm);
                        break;
                    case VaultControllerInputType.SeismicDetector:
                        if (alarmStatus.Value == true)
                            InputStatus = InputStatus.ClearFlags(VaultInputFlags.SeismicDetectorAlarm);
                        else
                            InputStatus = InputStatus.SetFlags(VaultInputFlags.SeismicDetectorAlarm);
                        break;
                    case VaultControllerInputType.SolenoidSensor:
                        if (alarmStatus.Value == true)
                            InputStatus = InputStatus.ClearFlags(VaultInputFlags.SolenoidSensorAlarm);
                        else
                            InputStatus = InputStatus.SetFlags(VaultInputFlags.SolenoidSensorAlarm);
                        break;
                }
                StatusManager.Instance.VaultControllers.TriggerInputStatusChange(logicalDeviceId, alarmStatus.Key, alarmStatus.Value);
                StatusManager.Instance.VaultControllers.TriggerVaultStatusChanged(configuration.VaultControllerNumber, Status, InputStatus);
            }
        }

        public void TriggerVaultStatusResponse(int logicalDeviceId, byte status, byte minuteToExpire, byte secondToExpire)
        {
        }

        #region private methods
        private void printMessage(string message)
        {
            DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
            Console.WriteLine(string.Format("[{0}] - {1}", now.ToString("HH:mm:ss"), message));
        }

        private void killOpenVaultTimer()
        {
            if (openVaultTimer != null)
            {
                printMessage("killOpenVaultTimer");
                openVaultTimer.Stop();
                TimerManager.Instance.RemoveTimer(openVaultTimer);
                openVaultTimer = null;
            }
        }

        private void onOpenVaultTimeout(object state)
        {
            if (openVaultTimer == null)
                return;
            openVaultTimer.Stop();
            if (Status == VaultStatus.TimingDown)
            {
                openVaultTimer.RunOnce(preOpenTime * 60 * 1000);
                Status = VaultStatus.Unlocked;
                StatusManager.Instance.VaultControllers.TriggerStatusChange(LogicalId, VaultStatus.Unlock, InputStatus);
            }
            else if (Status == VaultStatus.Unlocked)
            {
                killOpenVaultTimer();
                Status = VaultStatus.Idle;
                StatusManager.Instance.VaultControllers.TriggerStatusChange(LogicalId, VaultStatus.Close, InputStatus);
            }
            printMessage(string.Format("Current Status: {0}", Status));
        }

        private void killSeismicTestTimer()
        {
            if (seismicTestTimer != null)
            {
                seismicTestTimer.Stop();
                TimerManager.Instance.RemoveTimer(seismicTestTimer);
                seismicTestTimer = null;
            }
        }

        private void onSeismicTestTimeout(object state)
        {
            if (seismicTestTimer == null)
                return;
            killSeismicTestTimer();
            printMessage("Seismic Test Ended");
            sendCommand(2, new byte[] { 0 });
            printMessage("Seismic Test Fail");
            StatusManager.Instance.VaultControllers.TriggerStatusChange(LogicalId, VaultStatus.TestFail, InputStatus);
        }

        private enum VaultOutput
        {
            SeismicTest = 1,    // Seismic Test Output
            DoorLock = 2,       // Vault Door Lock Output
            Interlock = 3,      // Interlock Output
            Sounder = 4,        // Sounder Output
        }
        private enum VaultDisplayType
        {
            SC4DlintDisplay = 0,
            SLED_C4Display = 1
        }
        /// <summary>
        /// FC = 2
        /// </summary>
        /// <param name="output"></param>
        private bool setOuputState(VaultOutput output)
        {
            return sendCommand(2, new byte[] { (byte)output });
        }

        /// <summary>
        /// FC = 45
        /// </summary>
        /// <param name="displayType"></param>
        private bool setVaultConfiguration(VaultDisplayType displayType)
        {
            return sendCommand(45, new byte[] { (byte)displayType });
        }

        /// <summary>
        /// FC = 46
        /// This function code is used by the RTU to request opening of the vault.
        /// The message format of the <DATA…> field is:
        /// <46><TIME_WAIT><TIME_ACCESS><TIME_PREOPEN><TIME_PREALARM>
        /// </summary>
        /// <param name="waitTime">time to wait before opening the vault in minutes</param>
        /// <param name="accessTime">time to allow access to the vault in minutes. This value is set from 0 to 254 for 1 to 255 minutes and 255 for permanent access to the vault.</param>
        /// <param name="preOpenTime">pre-opening time in minutes (0-255)</param>
        /// <param name="preAlarmType">pre-alarm time in minutes (0-255)</param>
        private bool openVault(byte waitTime, byte accessTime, byte preOpenTime, byte preAlarmType)
        {
            return sendCommand(46, new byte[] { waitTime, accessTime, preOpenTime, preAlarmType });
        }

        /// <summary>
        /// FC = 48
        /// This function code is used by the RTU to request closing of the Vault.
        /// </summary>
        /// <returns></returns>
        private bool closeVault()
        {
            return sendCommand(48, null);
        }
        /// <summary>
        /// FC = 47
        /// </summary>
        private bool getVaultStatus()
        {
            return sendCommand(47, null);
        }

        /// <summary>
        /// FC = 49
        /// This function code is used by the RTU to set the interlock state of the Vault.
        /// </summary>
        /// <param name="enable"></param>
        public bool SetInterlock(bool enable)
        {
            return sendCommand(49, new byte[] { enable == true ? (byte)1 : (byte)0 });
        }

        private bool sendCommand(byte functionCode, byte[] data)
        {
            var configuration = ConfigurationManager.Instance.GetDeviceConfiguration(LogicalId) as Device1076VCConfiguration;
            var vcDeviceLoopDevice = StatusManager.Instance.DeviceLoopManager[configuration.DeviceLoopAddress - 1] as IDeviceLoopCommand;
            if (vcDeviceLoopDevice != null)
            {
                vcDeviceLoopDevice.SendCommand(functionCode, data);
                return true;
            }
            return false;
        }

        #endregion

    }
}
