﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Serialization.Formatters.Asn1;
using System.Threading;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// This class provides a central state repository for devices, areas, doors, inputs,
    /// outputs, presence zones and reades.
    /// </summary>
    public partial class StatusManager
    {
        public void PrepareDtpUpload(string identifier)
        {
            string uploadFilePath = FileSystemPaths.DataTransferUploadFilePath;

            for (int i = 0; i < 3; i++)
            {
                try
                {
                    if (File.Exists(uploadFilePath))
                        File.Delete(uploadFilePath);
                    break;
                }
                catch
                {
                    Thread.Sleep(1000);
                }
            }

            try
            {
                // Create a 0 length file, just in case we have nothing to upload.
                using (FileStream dataTransferUploadFileStream = new FileStream(uploadFilePath, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                {
                }
            }
#pragma warning disable 0168
#if DEBUG
            catch (Exception ex)
#else
            catch
#endif
#pragma warning restore 0168
            {
            }

            int hashIndex = identifier.IndexOf('#');
            if (hashIndex != -1)
                identifier = identifier.Substring(0, hashIndex);
            if (identifier.Length == 0)
                return;

            if (identifier.ToLower() != "/deviceinformation/")
                return;

            List<DeviceInformation> deviceInformationList = new List<DeviceInformation>();
            using (var configChanger = ConfigurationManager.Instance.CreateConfigurationChanger(ConfigurationElementsAffected.None))
            {
                deviceInformationList.Add(controllerStatus.CreateDeviceInformation());
                Devices.CreateDeviceInformation(deviceInformationList);
                ExpansionCards.CreateDeviceInformation(deviceInformationList);
            }

            try
            {
                StreamingContext context = new StreamingContext();
                Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(true, context);

                using (FileStream fileStream = new FileStream(uploadFilePath, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                {
                    foreach (DeviceInformation deviceInformation in deviceInformationList)
                    {
                        asn1Serializer.Serialize(fileStream, deviceInformation);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Unable to serialize device information. {0}", ex.ToString());
                });
            }
        }
    }
}