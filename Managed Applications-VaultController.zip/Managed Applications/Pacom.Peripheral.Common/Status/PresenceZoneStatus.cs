﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.SQLCE;

namespace Pacom.Peripheral.Common.Status
{
    public sealed class PresenceZoneStatus : StatusBase<PresenceZoneStatusList>
    {
        private readonly IPresenceZoneAntipassbackIdsList antiPassbackList;
        
        public PresenceZoneStatus(ConfigurationBase configuration, PresenceZoneStatusList parent) :
            base(configuration, parent)
        {
            if (SqlCeDatabase.Instance.DefaultDatabaseIsValid == true)
                antiPassbackList = new PresenceZoneAntipassbackIdsListSDCard(configuration.Id);
            else
                antiPassbackList = new PresenceZoneAntipassbackIdsList(configuration.Id);
        }

        public override StatusItemType ItemType
        {
            get { return StatusItemType.PresenceZoneStatus; }
        }

        /// <summary>
        /// Check if this presence zone contains this card / user
        /// </summary>
        /// <param name="antipassbackId">card / user id to search for</param>
        /// <returns>True if the card / user already exists, False otherwise</returns>
        public bool Contains(long antipassbackId)
        {
            return antiPassbackList.Contains(antipassbackId);
        }

        /// <summary>
        /// Add card / user to this presence zone
        /// </summary>
        /// <param name="antipassbackId">card / user to add to presence zone</param>
        public void Add(long antipassbackId)
        {
            antiPassbackList.Add(antipassbackId);
            MacroControl.Instance.EnqueueUserAreaChanged(this.LogicalId);
        }

        /// <summary>
        /// Remove card / user from this presence zone.
        /// </summary>
        /// <param name="antipassbackId">card / user id to remove.</param>
        /// <returns>True if the card / user was successfully removed, False otherwise</returns>
        public void Remove(long antipassbackId)
        {
            antiPassbackList.Remove(antipassbackId);
            MacroControl.Instance.EnqueueUserAreaChanged(this.LogicalId);
        }

        /// <summary>
        /// Count of cards / users in this presence zone
        /// </summary>
        public int CardholderCount
        {
            get { return antiPassbackList.Count; }
        }

        /// <summary>
        /// Isolate presence zone.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Isolate(UserAuditInfo userAuditInfo)
        {
        }

        /// <summary>
        /// Deisolate presence zone.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Deisolate(UserAuditInfo userAuditInfo)
        {
        }

        internal override void Cleanup()
        {
            antiPassbackList.Cleanup();
            base.Cleanup();
        }

        public override string ToString()
        {
            return String.Format("Count Area Status [{0}]", this.LogicalId);
        }
    }
}
