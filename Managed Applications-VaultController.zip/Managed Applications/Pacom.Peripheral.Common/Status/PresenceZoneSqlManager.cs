﻿using System.Data.Common;
using System.Text;
using Pacom.Peripheral.Common.SQLCE;

namespace Pacom.Peripheral.Common
{
    public class PresenceZoneSqlManager
    {
        private DbConnection connection = null;
        private DbCommand command = null;
        private StringBuilder sqlCommand = new StringBuilder();

        private static PresenceZoneSqlManager instance = null;

        private PresenceZoneSqlManager()
        {
            connection = SqlCeDatabase.Instance.OpenDatabase();
            connection.Open();
            command = connection.CreateCommand();

            createTable();
        }

        private void createTable()
        {
            if (connection.TableExists("PresenceZones") == false)
            {
                command.CommandText = "CREATE TABLE PresenceZones(ZoneId INT,UserId BIGINT,PRIMARY KEY (ZoneId, UserId))";
                command.ExecuteNonQuery();
            }
        }

        public static PresenceZoneSqlManager Instance
        {
            get
            {
                return instance;
            }
        }

        public static void CreateInstance()
        {
            instance = new PresenceZoneSqlManager();
        }

        public void AddUser(int zoneId, long userId)
        {
            lock (connection)
            {
                command.Parameters.Clear();
                command.AddParameterWithValue("ZoneId", zoneId);
                command.AddParameterWithValue("UserId", userId);
                command.CommandText = "INSERT INTO PresenceZones (ZoneId,UserId) VALUES (@ZoneId,@UserId)";
                command.ExecuteNonQuery();
            }
        }

        public void RemovePresenceZone(int zoneId)
        {
            lock (connection)
            {
                command.Parameters.Clear();
                command.AddParameterWithValue("ZoneId", zoneId);
                command.CommandText = "DELETE FROM PresenceZones WHERE ZoneId = @ZoneId";
                command.ExecuteNonQuery();
            }
        }

        public void RemoveUser(int zoneId, long userId)
        {
            lock (connection)
            {
                command.Parameters.Clear();
                command.AddParameterWithValue("ZoneId", zoneId);
                command.AddParameterWithValue("UserId", userId);
                command.CommandText = "DELETE FROM PresenceZones WHERE ZoneId = @ZoneId AND UserId = @UserId";
                command.ExecuteNonQuery();
            }
        }

        public void RemoveAll()
        {
            lock (connection)
            {
                command.Parameters.Clear();
                command.CommandText = string.Format(@"DROP TABLE PresenceZones");
                command.ExecuteNonQuery();

                createTable();
            }
        }

        public bool Exists(int zoneId, long userId)
        {
            lock (connection)
            {
                command.Parameters.Clear();
                command.AddParameterWithValue("ZoneId", zoneId);
                command.AddParameterWithValue("UserId", userId);
                command.CommandText = "SELECT TOP(1) 1 FROM PresenceZones WHERE ZoneId = @ZoneId AND UserId = @UserId";
                object userExists = command.ExecuteScalar();
                return userExists != null && (int)userExists == 1;
            }
        }

        public int Count(int zoneId)
        {
            lock (connection)
            {
                command.Parameters.Clear();
                command.AddParameterWithValue("ZoneId", zoneId);
                command.CommandText = "SELECT COUNT(*) FROM PresenceZones WHERE ZoneId = @ZoneId";
                object count = command.ExecuteScalar();
                if (count == null)
                    return 0;
                else
                    return (int)count;
            }
        }
    }
}