﻿namespace Pacom.Peripheral.Common.Status
{
    public class ReportingFloorAccessTime
    {
        public int FloorsAccess { get; private set; }
        public int TimeInSeconds { get; set; }
        public ReportingFloorAccessTime(int floorsAccess, int timeInSeconds)
        {
            FloorsAccess = floorsAccess;
            TimeInSeconds = timeInSeconds;
        }
    }
}
