﻿
namespace Pacom.Peripheral.Common.Status
{
    public class MacroFloorAccessTime
    {
        public int FloorId { get; private set; }
        public int TimeInSeconds { get; set; }
        public MacroFloorAccessTime(int floorId, int timeInSeconds)
        {
            FloorId = floorId;
            TimeInSeconds = timeInSeconds;
        }
    }
}
