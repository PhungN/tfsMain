﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status;

namespace Pacom.Peripheral.Common.Status
{
    public sealed partial class DoorStatus : StatusBase<DoorStatusList>
    {
        public const int NoReader = -1;

        private ReaderStatus inReaderStatus = null;
        private ReaderStatus outReaderStatus = null;

        public override StatusItemType ItemType
        {
            get { return StatusItemType.DoorStatus; }
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            DoorStatusStorage statusStorage = new DoorStatusStorage();
            if (statusStorage != null)
            {
                statusStorage.LogicalId = LogicalId;
                statusStorage.ParentDeviceId = ParentDeviceId;
                statusStorage.EnableStrike = EnableStrike;
                statusStorage.EnableEgress = EnableEgress;
                statusStorage.Isolated = Isolated;
            }
            return statusStorage;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            DoorEventState doorState = new DoorEventState();
            doorState.Id = LogicalId;
            doorState.Ajar = Ajar;
            doorState.Force = Forced;
            doorState.Isolate = Isolated;
            doorState.ContactTrouble = ContactTrouble;
            doorState.StrikeTrouble = StrikeTrouble;
            doorState.SpareTrouble = SpareTrouble;
            doorState.EgressTrouble = EgressTrouble;
            return doorState;
        }

        /// <summary>
        /// Get display name for this door status item instance without any alarms / isolated alarms
        /// </summary>
        /// <returns>Display Name string.</returns>
        public override string DisplayName
        {
            get
            {
                DoorConfiguration doorConfig = ConfigurationManager.Instance.GetDoorConfiguration(LogicalId);
                if (doorConfig != null)
                    return string.Format("{0}{1} {2}", ConfigurationManager.Instance.ControllerConfiguration.DoorPrefixText, LogicalId, doorConfig.GetName());
                return string.Empty;
            }
        }

        private string statusAsString(Common.InputStatus status)
        {
            switch (status)
            {
                case Common.InputStatus.Alarm: return ConfigurationManager.Instance.ControllerConfiguration.AlarmText;
                case Common.InputStatus.Short: return ConfigurationManager.Instance.ControllerConfiguration.ShortCircuitEventText;
                case Common.InputStatus.Open: return ConfigurationManager.Instance.ControllerConfiguration.OpenCircuitEventText;
                case Common.InputStatus.Trouble: return ConfigurationManager.Instance.ControllerConfiguration.TroubleEventText;
                case Common.InputStatus.Secure: return ConfigurationManager.Instance.ControllerConfiguration.SecureText;
                default: return "UNKNOWN";
            }
        }

        /// <summary>
        /// Get the string representation of the alarms for this door in format: [ALARM1 .. ALARMN], e.g. [FORCE AJAR]
        /// </summary>
        public override string AlarmsAsString
        {
            get
            {
                if ((agentInstance.DoorAlarm != DoorAlarms.None || ContactTrouble || StrikeTrouble || SpareTrouble || EgressTrouble) &&
                    (Isolated == false))
                {
                    string alarmString = string.Empty;
                    if (Ajar == true)
                        alarmString += ConfigurationManager.Instance.ControllerConfiguration.DoorAjarText + " ";
                    if (Forced == true)
                        alarmString += ConfigurationManager.Instance.ControllerConfiguration.DoorForcedText + " ";
                    if (ContactTrouble == true)
                        alarmString += statusAsString(contactStatus) + " ";
                    if (StrikeTrouble == true)
                        alarmString += statusAsString(strikeStatus) + " ";
                    if (EgressTrouble == true)
                        alarmString += statusAsString(egressStatus);
                    return " " + alarmString.TrimEnd();
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Get the string representation of the isolated alarms for this door status
        /// </summary>
        public override string IsolatedAlarmsAsString
        {
            get { return isolated == true ? " " + ConfigurationManager.Instance.ControllerConfiguration.IsolatedText : string.Empty; }
        }

        /// <summary>
        /// An instance of door agent for the configured lock type.
        /// </summary>
        private DoorAgentBase agentInstance = null;
        public IDoorAgent DoorAgent
        {
            get { return agentInstance; }
        }

        /// <summary>
        /// Triggered when access command is requested on the door.
        /// </summary>
        public event EventHandler<AccessControlCommandRequestEventArgs> AccessControlCommandRequested = null;

        /// <summary>
        /// Broadcast access control commands in one transaction for the door
        /// </summary>
        internal void TriggerAccessControlCommand(AccessControlCommandRequestEventArgs value)
        {
            if (AccessControlCommandRequested == null || value == null)
            {
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                                                                                                          {
                                                                                                              return string.Format("Unable to send access command request from door to reader {0} !!!", value.LogicalReaderId);
                                                                                                          });
#endif
                return;
            }
            AccessControlCommandRequested(this, value);
        }

        public bool EnableStrike
        {
            get;
            set;
        }

        public bool EnableEgress
        {
            get;
            set;
        }

        public bool AutomaticEgress 
        {
            get;
            set;
        }

        private Common.InputStatus contactStatus = Common.InputStatus.Unknown;
        private Common.InputStatus egressStatus = Common.InputStatus.Unknown;
        private Common.InputStatus strikeStatus = Common.InputStatus.Unknown;
        private Common.InputStatus maskedContactStatus = Common.InputStatus.Unknown;
        private Common.InputStatus maskedEgressStatus = Common.InputStatus.Unknown;
        private Common.InputStatus maskedStrikeStatus = Common.InputStatus.Unknown;

        public DoorStatus(ConfigurationBase configuration, bool enableStrike, bool enableEgress, bool automaticEgress, DoorStatusList parent, DoorStatusStorage previousState) :
            base(configuration, parent)
        {
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                                                                                                      {
                                                                                                          return string.Format("Adding door status for Id {0}.", configuration.Id);
                                                                                                      });
#endif
            isolated = false;
            EnableStrike = enableStrike;
            EnableEgress = enableEgress;
            AutomaticEgress = automaticEgress;

            if (enableStrike == false)
            {
                strikeStatus = Pacom.Peripheral.Common.InputStatus.Secure;
                maskedStrikeStatus = Pacom.Peripheral.Common.InputStatus.Secure;
            }
            if (enableEgress == false)
            {
                egressStatus = Pacom.Peripheral.Common.InputStatus.Secure;
                maskedStrikeStatus = Pacom.Peripheral.Common.InputStatus.Secure;
            }

            // Create Dummy Door Agent as Default
            agentInstance = DoorAgentBase.CreateInstance(DoorLockOperation.Normal, this, null, null) as DoorAgentBase;

            if (previousState == null || this.Enabled == false)
                return;

            if (this.EnableStrike == previousState.EnableStrike && this.EnableEgress == previousState.EnableEgress)
            {
                this.isolated = previousState.Isolated;
                if (isolated)
                {
                    DoorConfiguration doorConfig = ConfigurationManager.Instance.GetDoorConfiguration(LogicalId);
                    if (doorConfig != null && doorConfig.AreaId > 0)
                        StatusManager.Instance.Areas[doorConfig.AreaId].AddPointToIsolatedList(this);
                }
                UpdateInAlarm();
            }
        }

        internal void RefreshAfterConfigurationChange()
        {
            UpdateInAlarm();
        }

        /// <summary>
        /// Get / set door contact status
        /// </summary>
        public Common.InputStatus ContactStatus
        {
            get { return contactStatus; }
            set
            {
                if (Enabled == false)
                    return;
                if (contactStatus != value)
                {
                    Common.InputStatus previousContactStatus = contactStatus;
                    contactStatus = value;
                    if (contactStatus == Pacom.Peripheral.Common.InputStatus.Secure ||
                        contactStatus == Pacom.Peripheral.Common.InputStatus.Alarm)
                    {
                        MaskedContactStatus = contactStatus;

                        if (isolated == false && isTroubleAlarm(previousContactStatus))
                        {
                            // Restore trouble alarm
                            Parent.TriggerChangedTroubleStatus(this, DoorTroubleType.Contact, false);
                            UpdateInAlarm();
                        }
                    }
                    else if (isolated == false)
                    {
                        // Send trouble alarm
                        Parent.TriggerChangedTroubleStatus(this, DoorTroubleType.Contact, true);
                        UpdateInAlarm();
                    }
                }
            }
        }

        internal Common.InputStatus MaskedContactStatus
        {
            get { return maskedContactStatus; }
            private set
            {
                if (maskedContactStatus != value)
                {
                    Common.InputStatus previousContactStatus = maskedContactStatus;
                    maskedContactStatus = value;
                    updatePhysicalDoorContact(maskedContactStatus);
                    if (IsUnlocked == false)
                    {
                        StatusManager.Instance.Doors.TriggerDoorControllerInputStatusChanged(this, ChangedDoorControllerInput.DoorContact, maskedContactStatus, previousContactStatus);
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
                else if (maskedContactStatus != Common.InputStatus.Secure)
                {
                    updatePhysicalDoorContact(maskedContactStatus);
                    Parent.TriggerDoorControllerInputStatusChanged(this, ChangedDoorControllerInput.DoorContact, maskedContactStatus, Common.InputStatus.Unknown);
                }
            }
        }

        /// <summary>
        /// Update physical door contact
        /// </summary>
        /// <param name="doorContactStatus"></param>
        private void updatePhysicalDoorContact(Common.InputStatus doorContactStatus)
        {
            if (physicalDoorContact != doorContactStatus)
            {
                if (AutomaticEgress == true &&                                            // automatic egress feature is enabled
                    physicalDoorContact == Common.InputStatus.Secure &&                   // previous state is closed (old state is secure)
                    doorContactStatus == Common.InputStatus.Alarm &&                      // the door has just been opened (new state is alarm)
                    (agentInstance.OperationState == DoorOperationState.Closed) &&        // the door state machine expects the door to be closed
                    (EnableEgress == false || EgressStatus == Common.InputStatus.Secure)) // egress button isn't enabled, or egress button is OK if it is
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () => string.Format("Door {0} automatic egress", this.LogicalId));

                    // Fake press the egress button
                    Parent.TriggerDoorControllerInputStatusChanged(this, ChangedDoorControllerInput.Egress, Common.InputStatus.Alarm, Common.InputStatus.Secure);
                    // ...and release
                    Parent.TriggerDoorControllerInputStatusChanged(this, ChangedDoorControllerInput.Egress, Common.InputStatus.Secure, Common.InputStatus.Alarm);

                    // If schedule allowed, the fake egress press would have made the door be in the Opening state, so the door contact going Alarm is now OK
                }

                physicalDoorContact = doorContactStatus;
                // Send notification to door agent
                agentInstance.UpdateAgentState(DoorAgentContexts.DoorContact);
            }
        }

        /// <summary>
        /// Get / set egress status
        /// </summary>
        public Common.InputStatus EgressStatus
        {
            get { return egressStatus; }
            set
            {
                if (Enabled == false)
                    return;
                if (EnableEgress == false)
                    return;
                if (egressStatus != value)
                {
                    Common.InputStatus previousEgressStatus = egressStatus;
                    egressStatus = value;
                    if (value == Pacom.Peripheral.Common.InputStatus.Secure ||
                        value == Pacom.Peripheral.Common.InputStatus.Alarm)
                    {
                        MaskedEgressStatus = egressStatus;

                        if (isolated == false && isTroubleAlarm(previousEgressStatus))
                        {
                            // Restore trouble alarm
                            Parent.TriggerChangedTroubleStatus(this, DoorTroubleType.Egress, false);
                            UpdateInAlarm();
                        }
                    }
                    else if (isolated == false)
                    {
                        // Send trouble alarm
                        Parent.TriggerChangedTroubleStatus(this, DoorTroubleType.Egress, true);
                        UpdateInAlarm();
                    }
                }
            }
        }

        internal Common.InputStatus MaskedEgressStatus
        {
            get { return maskedEgressStatus; }
            private set
            {
                if (maskedEgressStatus != value)
                {
                    Common.InputStatus previousEgressStatus = maskedEgressStatus;
                    maskedEgressStatus = value;
                    Parent.TriggerDoorControllerInputStatusChanged(this, ChangedDoorControllerInput.Egress, maskedEgressStatus, previousEgressStatus);
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / set strike status
        /// </summary>
        public Common.InputStatus StrikeStatus
        {
            get { return strikeStatus; }
            set
            {
                if (Enabled == false)
                    return;
                if (EnableStrike == false)
                    return;
                if (strikeStatus != value)
                {
                    Common.InputStatus previousStrikeStatus = strikeStatus;
                    strikeStatus = value;
                    if (value == Pacom.Peripheral.Common.InputStatus.Secure ||
                        value == Pacom.Peripheral.Common.InputStatus.Alarm)
                    {
                        MaskedStrikeStatus = strikeStatus;

                        if (isolated == false && isTroubleAlarm(previousStrikeStatus))
                        {
                            // Restore trouble alarm
                            Parent.TriggerChangedTroubleStatus(this, DoorTroubleType.Strike, false);
                            UpdateInAlarm();
                        }
                    }
                    else if (isolated == false)
                    {
                        // Send trouble alarm
                        Parent.TriggerChangedTroubleStatus(this, DoorTroubleType.Strike, true);
                        UpdateInAlarm();
                    }
                }
            }
        }

        internal Common.InputStatus MaskedStrikeStatus
        {
            get { return maskedStrikeStatus; }
            private set
            {
                if (maskedStrikeStatus != value)
                {
                    Common.InputStatus previousStrikeStatus = maskedStrikeStatus;
                    maskedStrikeStatus = value;
                    Parent.TriggerDoorControllerInputStatusChanged(this, ChangedDoorControllerInput.Strike, maskedStrikeStatus, previousStrikeStatus);
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        private bool isolated = false;

        /// <summary>
        /// Get the state of door Isolated flag
        /// </summary>
        public bool Isolated
        {
            get { return isolated; }
        }

        /// <summary>
        /// Set the state of door Isolated flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public bool SetIsolated(UserAuditInfo userAuditInfo, bool value)
        {
            DoorConfiguration doorConfig = ConfigurationManager.Instance.GetDoorConfiguration(LogicalId);
            if (Enabled == false || doorConfig == null)
                return false;

            if (isolated != value)
            {
                isolated = value;
                if (value)
                {
                    if (doorConfig.AreaId > 0)
                        StatusManager.Instance.Areas[doorConfig.AreaId].AddPointToIsolatedList(this);
                }
                else
                {
                    if (doorConfig.AreaId > 0)
                        StatusManager.Instance.Areas[doorConfig.AreaId].RemovePointFromIsolatedList(this);
                }

                Parent.TriggerChangedIsolatedStatus(this, isolated, userAuditInfo);
                agentInstance.UpdateAgentState(DoorAgentContexts.IsolateDoorChanged);

                if (isolated)
                {
                    // Restore trouble alarms
                    if (isTroubleAlarm(contactStatus))
                        Parent.TriggerChangedTroubleStatus(this, DoorTroubleType.Contact, false);
                    if (isTroubleAlarm(strikeStatus))
                        Parent.TriggerChangedTroubleStatus(this, DoorTroubleType.Strike, false);
                    if (isTroubleAlarm(egressStatus))
                        Parent.TriggerChangedTroubleStatus(this, DoorTroubleType.Egress, false);
                }
                else
                {
                    // Send trouble alarms
                    if (isTroubleAlarm(contactStatus))
                        Parent.TriggerChangedTroubleStatus(this, DoorTroubleType.Contact, true);
                    if (isTroubleAlarm(strikeStatus))
                        Parent.TriggerChangedTroubleStatus(this, DoorTroubleType.Strike, true);
                    if (isTroubleAlarm(egressStatus))
                        Parent.TriggerChangedTroubleStatus(this, DoorTroubleType.Egress, true);
                }
                UpdateInAlarm();
                StatusManager.Instance.RequestStatusToStorage();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Check if this status item has any alarms
        /// </summary>
        public bool inAlarm = false;
        public override bool HasAnyAlarm
        {
            get { return inAlarm; }
        }

        internal void UpdateInAlarm()
        {
            bool currentInAlarmState = false;
            bool previousInAlarmState = inAlarm;

            if ((agentInstance.DoorAlarm != DoorAlarms.None || ContactTrouble ||
                 StrikeTrouble || SpareTrouble || EgressTrouble) && (Isolated == false))
            {
                currentInAlarmState = true;
            }

            if (currentInAlarmState != previousInAlarmState)
            {
                inAlarm = currentInAlarmState;
                if (currentInAlarmState)
                {
                    // Add door to the alarm list
                    DoorConfiguration doorConfig = ConfigurationManager.Instance.GetDoorConfiguration(LogicalId);
                    if (doorConfig != null)
                    {
                        AreaStatus areaStatus = StatusManager.Instance.Areas[doorConfig.AreaId];
                        if (areaStatus != null)
                        {
                            areaStatus.AddPointToArmedList(this);
                            areaStatus.AddPointToDisarmedList(this);

                            if (isolated)
                                areaStatus.AddPointToIsolatedList(this);
                        }
                    }
                }
                else
                {
                    // Remove door from the alarm list
                    DoorConfiguration doorConfig = ConfigurationManager.Instance.GetDoorConfiguration(LogicalId);
                    if (doorConfig != null)
                    {
                        AreaStatus areaStatus = StatusManager.Instance.Areas[doorConfig.AreaId];
                        if (areaStatus != null)
                        {
                            areaStatus.RemovePointFromArmedList(this);
                            areaStatus.RemovePointFromDisarmedList(this);

                            if (isolated)
                                areaStatus.AddPointToIsolatedList(this);
                        }
                    }
                }
            }
            else if (isolated)
            {
                // Add door to the isolated list
                DoorConfiguration doorConfig = ConfigurationManager.Instance.GetDoorConfiguration(LogicalId);
                if (doorConfig != null)
                {
                    AreaStatus areaStatus = StatusManager.Instance.Areas[doorConfig.AreaId];
                    if (areaStatus != null)
                        areaStatus.AddPointToIsolatedList(this);
                }
            }
        }

        /// <summary>
        /// Isolate door.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Isolate(UserAuditInfo userAuditInfo)
        {
            SetIsolated(userAuditInfo, true);
        }

        /// <summary>
        /// Deisolate door.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Deisolate(UserAuditInfo userAuditInfo)
        {
            SetIsolated(userAuditInfo, false);
        }

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        public override bool CanIsolate(UserAccessLevel level)
        {
            if (level == UserAccessLevel.AccessLevel3)
                return true;

            if (isolated == true)
                return false;

            if (isTroubleAlarm(contactStatus) || isTroubleAlarm(strikeStatus) || isTroubleAlarm(egressStatus))
            {
                // Access Level 2 users can't isolate Door Trouble alarms
                return false;
            }

            // Access Level 2 users can isolate Door Ajar / Forced alarms
            return agentInstance.DoorAlarm != DoorAlarms.None;
        }

        /// <summary>
        /// True if this status item can be de-isolated at the specifed access level
        /// </summary>
        public override bool CanDeisolate(UserAccessLevel level)
        {
            if (level == UserAccessLevel.AccessLevel3)
                return true;

            if (isolated == false)
                return false;

            if (isTroubleAlarm(contactStatus) || isTroubleAlarm(strikeStatus) || isTroubleAlarm(egressStatus))
            {
                // Access Level 2 users can't de-isolate Door Trouble alarms
                return false;
            }

            // Access Level 2 users can de-isolate Door Ajar / Forced alarms
            return agentInstance.DoorAlarm != DoorAlarms.None;
        }

        /// <summary>
        /// Set isolated flag for any door point for a specified duration.
        /// </summary>
        /// <param name="value">True for isolate, false for normal operation.</param>
        /// <param name="bitField">Not Used.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="durationInSeconds">The duration for which the point will be isolated, 0 means that the point will be isolated idefinitely</param>
        /// <returns>True if the point's isolated state was successfully changed, False otherwise.</returns>
        public override bool SetIsolated(bool value, EventSourceLatchOrIsolateType bitField, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            bool result = SetIsolated(userAuditInfo, value);
            if (result == true)
            {
                if (value == true && durationInSeconds > 0)
                {
                    // A duration is only supported for the 'isolate for a duration' case.
                    StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.DeisolateDoors, LogicalId, userAuditInfo, durationInSeconds);
                }
                MacroControl.Instance.EnqueueDoorEvent(LogicalId, value == true ? DoorContextStatus.Isolated : DoorContextStatus.Deisolated);
            }
            return result;
        }

        /// <summary>
        /// Get door locked / unlocked state
        /// Returns True if the in reader is in Unlocked State.
        /// </summary>
        public bool IsUnlocked
        {
            get
            {
                if (inReaderStatus == null)
                    return false;

                Reader8003ScheduleLevel mode = StatusManager.Instance.Readers.GetReaderMode(inReaderStatus.LogicalId);
                return mode == Reader8003ScheduleLevel.Unlocked;
            }
        }

        /// <summary>
        /// Get door locked / unlocked state
        /// If either reader is in the blocked state, this will return true.
        /// </summary>
        public bool IsBlocked
        {
            get
            {
                if (inReaderStatus == null)
                    return false;

                Reader8003ScheduleLevel mode = StatusManager.Instance.Readers.GetReaderMode(inReaderStatus.LogicalId);
                if (mode == Reader8003ScheduleLevel.Blocked)
                    return true;

                if (outReaderStatus == null)
                    return false;

                mode = StatusManager.Instance.Readers.GetReaderMode(outReaderStatus.LogicalId);
                if (mode == Reader8003ScheduleLevel.Blocked)
                    return true;

                return false;
            }
        }

        /// <summary>
        /// This door should not be opened because another door in its interlock group(s) is already open.
        /// </summary>
        public bool IsInterlocked
        {
            get
            {
                foreach (InterlockGroupConfiguration interlock in ConfigurationManager.Instance.InterlockGroups)
                {
                    if (interlock.DoorIds.Contains(this.LogicalId) == false)
                    {
                        continue;
                    }
                    if (StatusManager.Instance.InterlockGroups[interlock.Id].IsOpen)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        private Common.InputStatus physicalDoorContact = Common.InputStatus.Unknown;

        /// <summary>
        /// Returns true when the door contact is in alarm. The door is physically open.
        /// </summary>
        public bool IsDoorPhysicallyOpen
        {
            get { return physicalDoorContact == Common.InputStatus.Alarm; }
        }

        /// <summary>
        /// Update door agent state based on curent schedule mode
        /// </summary>
        internal void UpdateDoorStatusFromSchedule()
        {
            agentInstance.UpdateAgentState(DoorAgentContexts.UpdateFromSchedule);
        }

        /// <summary>
        /// Update door agent after a reader lockout time has expired
        /// </summary>
        internal void KeypadLockoutTimerExpired()
        {
            if (agentInstance != null)
            {
                agentInstance.UpdateAgentState(DoorAgentContexts.KeypadLockoutTimerExpired);
            }
        }

        /// <summary>
        /// Update underlying door hardware based on the door agent and status unlocked flag
        /// </summary>
        public void RequestCurrentDoorState()
        {
            if (DoorAgent.DoorAlarm != DoorAlarms.None)
                agentInstance.UpdateAgentState(DoorAgentContexts.DoorContactAlarm);
            else
                agentInstance.UpdateAgentState(DoorAgentContexts.CurrentDoorStateRequest);
        }

        /// <summary>
        /// Is door in ajar alarm.
        /// </summary>
        public bool Ajar
        {
            get { return agentInstance.DoorAlarm == DoorAlarms.Ajar; }
        }

        /// <summary>
        /// Is door in forced alarm.
        /// </summary>
        public bool Forced
        {
            get { return agentInstance.DoorAlarm == DoorAlarms.Forced; }
        }

        public bool ContactTrouble
        {
            get
            {
                if (isolated == false && isTroubleAlarm(contactStatus))
                    return true;
                return false;
            }
        }

        public bool StrikeTrouble
        {
            get
            {
                if (isolated == false && isTroubleAlarm(strikeStatus))
                    return true;
                return false;
            }
        }

        public bool SpareTrouble
        {
            get { return false; }
        }

        public bool EgressTrouble
        {
            get
            {
                if (isolated == false && isTroubleAlarm(egressStatus))
                    return true;
                return false;
            }
        }

        /// <summary>
        /// Access door from egress
        /// </summary>
        /// <returns></returns>
        public bool AccessWithEgress()
        {
            if (Enabled == false || IsUnlocked == true)
                return false;

            agentInstance.ClearCommandTransaction();
            return agentInstance.UpdateAgentState(DoorAgentContexts.Egress);
        }

        /// <summary>
        /// Access door with valid card
        /// </summary>
        /// <param name="cardFormat"></param>
        /// <param name="logicalReaderId"></param>
        /// <returns></returns>
        public bool AccessWithValidCard(CardInformation cardInformation, int logicalReaderId, Reader8003ScheduleLevel readerMode, List<CardInformation> cardInformationList, ReaderBadgingType multiBadgingType)
        {
            if (IsUnlocked == true)
                return false;

            agentInstance.ClearCommandTransaction();
            agentInstance.AssignValidCardTransaction(logicalReaderId, cardInformation, readerMode, cardInformationList, multiBadgingType);
            return agentInstance.UpdateAgentState(DoorAgentContexts.ValidCard);
        }

        public void AccessWithValidCardPending()
        {
            agentInstance.UpdateAgentState(DoorAgentContexts.ValidMultiBadgingCard);
        }

        /// <summary>
        /// Access door from front end command.
        /// </summary>
        /// <param name="durationType">Duration type</param>
        /// <param name="accessDuration">Druration in seconds</param>
        /// <returns></returns>
        public bool AccessFromCommand(DurationType durationType, int accessDuration)
        {
            if (Enabled == false || IsUnlocked == true)
                return false;

            agentInstance.AssignCommandTransaction(durationType, accessDuration * 1000);
            return agentInstance.UpdateAgentState(DoorAgentContexts.AccessCommand);
        }

        /// <summary>
        /// Access door from macro
        /// </summary>
        /// <returns></returns>
        public bool AccessFromMacro()
        {
            if (Enabled == false || IsUnlocked == true)
                return false;

            agentInstance.ClearCommandTransaction();
            return agentInstance.UpdateAgentState(DoorAgentContexts.AccessCommand);
        }

        /// <summary>
        /// Access door from macro with specified duration in seconds.
        /// </summary>
        /// <param name="accessDuration">Duratrion in seconds</param>
        /// <returns></returns>
        public bool AccessFromMacro(int accessDuration)
        {
            if (Enabled == false || IsUnlocked == true)
                return false;

            agentInstance.AssignCommandTransaction(DurationType.SpecifiedDuration, accessDuration * 1000);
            return agentInstance.UpdateAgentState(DoorAgentContexts.AccessCommand);
        }

        public void Lock(UserAuditInfo userAuditInfo)
        {
            if (inReaderStatus != null)
                inReaderStatus.SetMode(Reader8003ScheduleLevel.Blocked, true, userAuditInfo);
            if (outReaderStatus != null)
                outReaderStatus.SetMode(Reader8003ScheduleLevel.Blocked, true, userAuditInfo);

        }

        public void Unlock(UserAuditInfo userAuditInfo)
        {
            if (inReaderStatus != null)
                inReaderStatus.SetMode(Reader8003ScheduleLevel.Unlocked, true, userAuditInfo);
            if (outReaderStatus != null)
                outReaderStatus.SetMode(Reader8003ScheduleLevel.Unlocked, true, userAuditInfo);
        }

        public void Restore(UserAuditInfo userAuditInfo)
        {
            if (inReaderStatus != null)
                inReaderStatus.RestoreMode(userAuditInfo);
            if (outReaderStatus != null)
                outReaderStatus.RestoreMode(userAuditInfo);
        }

        /// <summary>
        /// Access door with pin
        /// </summary>
        /// <param name="logicalReaderId"></param>
        /// <param name="keyData"></param>
        public void AccessPinReceived(int logicalReaderId, byte[] keyData)
        {
            if (Enabled == false || IsUnlocked == true)
                return;

            if (inReaderStatus != null && logicalReaderId == inReaderStatus.LogicalId)
            {
                if (agentInstance.AssignPinTransaction(logicalReaderId, keyData) == true)
                    agentInstance.UpdateAgentState(DoorAgentContexts.EndWaitForPinOnInReader);
            }
            else if (outReaderStatus != null && logicalReaderId == outReaderStatus.LogicalId)
            {
                if (agentInstance.AssignPinTransaction(logicalReaderId, keyData) == true)
                    agentInstance.UpdateAgentState(DoorAgentContexts.EndWaitForPinOnOutReader);
            }
        }

        public CardNumberHolder GetCardNumber(int logicalReaderId)
        {
            return agentInstance.GetCardNumber(logicalReaderId);
        }

        /// <summary>
        /// Access door but wait for pin.
        /// </summary>
        /// <param name="cardFormat"></param>
        /// <param name="logicalReaderId"></param>
        public void AccessWaitForPin(CardNumberHolder cardNumber, int logicalReaderId, Reader8003ScheduleLevel readerMode)
        {
            agentInstance.ClearCommandTransaction();
            if (inReaderStatus != null && logicalReaderId == inReaderStatus.LogicalId)
            {
                agentInstance.ClearValidCardTransaction(inReaderStatus.LogicalId);
                agentInstance.AssignValidCardTransaction(logicalReaderId, cardNumber, readerMode);
                agentInstance.UpdateAgentState(DoorAgentContexts.WaitForPinOnInReader);
            }
            else if (outReaderStatus != null && logicalReaderId == outReaderStatus.LogicalId)
            {
                agentInstance.ClearValidCardTransaction(outReaderStatus.LogicalId);
                agentInstance.AssignValidCardTransaction(logicalReaderId, cardNumber, readerMode);
                agentInstance.UpdateAgentState(DoorAgentContexts.WaitForPinOnOutReader);
            }
        }

        private AccessDeniedReason accessDeniedReason = AccessDeniedReason.None;
        private string accessDeniedReasonText;

        public AccessDeniedReason AccessDeniedReason
        {
            get { return accessDeniedReason; }
            set { accessDeniedReason = value; }
        }

        private string getAccessDeniedReasonText()
        {
            switch (accessDeniedReason)
            {
                case AccessDeniedReason.InvalidCard:
                case AccessDeniedReason.InvalidPin:
                    return ConfigurationManager.Instance.ControllerConfiguration.InvalidCardOrPinText;
                case AccessDeniedReason.InvalidUser:
                    return ConfigurationManager.Instance.ControllerConfiguration.InvalidUserText;
                case AccessDeniedReason.CardExpiredOrBlocked:
                    return ConfigurationManager.Instance.ControllerConfiguration.CardExpiredOrBlockedText;
                case AccessDeniedReason.ReaderLockedOut:
                    return ConfigurationManager.Instance.ControllerConfiguration.ReaderLockedOutText;
                case AccessDeniedReason.DoorInterlocked:
                    return ConfigurationManager.Instance.ControllerConfiguration.DoorInterlockedText;
                default:
                    return null;
            }
        }

        /// <summary>
        /// Signal door access denied
        /// </summary>
        public void AccessDenied(AccessDeniedReason reason)
        {
            accessDeniedReason = reason;
            accessDeniedReasonText = getAccessDeniedReasonText();
            agentInstance.ClearAllValidCardTransactions();
            agentInstance.ClearCommandTransaction();
            agentInstance.UpdateAgentState(DoorAgentContexts.DeniedAccess);
        }

        public void InterlockOpened()
        {
            agentInstance.UpdateAgentState(DoorAgentContexts.InterlockOpened);
        }

        public void InterlockClosed()
        {
            agentInstance.UpdateAgentState(DoorAgentContexts.CurrentDoorStateRequest);
        }

        /// <summary>
        /// Request reset of the door agent. Mostly after device is marked offline.
        /// </summary>
        public void ResetDoorAgent()
        {
            agentInstance.ClearAllValidCardTransactions();
            agentInstance.ClearCommandTransaction();
            agentInstance.ResetDoorAgent();
            UpdateInAlarm();
        }

        public SecurityLevelDisplayCommand GetSecurityLevelDisplayCommand(out string text)
        {
            text = "";
            switch (agentInstance.Context)
            {
                case DoorAgentContexts.AccessCommand:
                    return SecurityLevelDisplayCommand.DoorUnlocked;
                case DoorAgentContexts.InterlockOpened:
                    text = ConfigurationManager.Instance.ControllerConfiguration.DoorInterlockedText;
                    return SecurityLevelDisplayCommand.DoorLocked;
                case DoorAgentContexts.DeniedTimerExpired:
                    return SecurityLevelDisplayCommand.WaitCard;
                case DoorAgentContexts.StrikeTimerExpired:
                    if (Isolated == true || IsDoorPhysicallyOpen == false)
                        return SecurityLevelDisplayCommand.WaitCard;
                    return SecurityLevelDisplayCommand.None;
                case DoorAgentContexts.ValidCard:
                    return SecurityLevelDisplayCommand.AcceptRequest;
                case DoorAgentContexts.ValidMultiBadgingCard:
                    return SecurityLevelDisplayCommand.WaitCard;
                case DoorAgentContexts.Egress:
                    return SecurityLevelDisplayCommand.DoorUnlocked;
                case DoorAgentContexts.DeniedAccess:
                    text = accessDeniedReasonText;
                    return SecurityLevelDisplayCommand.RejectRequest;
                case DoorAgentContexts.ShuntTimerExpired:
                    if (Isolated)
                        return SecurityLevelDisplayCommand.None;
                    if (IsDoorPhysicallyOpen) 
                        return SecurityLevelDisplayCommand.DoorAjar;
                    return SecurityLevelDisplayCommand.WaitCard;
                case DoorAgentContexts.EmbarrassmentTimerExpired:
                    if (Isolated)
                        return SecurityLevelDisplayCommand.WaitCard;
                    return SecurityLevelDisplayCommand.None;
                case DoorAgentContexts.DoorContactAlarm:
                    if (Isolated)
                        return SecurityLevelDisplayCommand.None;
                    else if (DoorAgent.DoorAlarm == DoorAlarms.Ajar)
                        return SecurityLevelDisplayCommand.DoorAjar;
                    else if (DoorAgent.DoorAlarm == DoorAlarms.Forced)
                        return SecurityLevelDisplayCommand.DoorForced;
                    return SecurityLevelDisplayCommand.WaitCard;
                case DoorAgentContexts.DoorContact:
                    if (Isolated)
                        return SecurityLevelDisplayCommand.None;
                    else if (IsDoorPhysicallyOpen)
                        return SecurityLevelDisplayCommand.DoorForced;
                    else if (IsBlocked)
                        return SecurityLevelDisplayCommand.DoorLocked;
                    else if (IsUnlocked)
                        return SecurityLevelDisplayCommand.DoorUnlocked;
                    return SecurityLevelDisplayCommand.WaitCard;
                case DoorAgentContexts.UpdateFromSchedule:
                case DoorAgentContexts.CurrentDoorStateRequest:
                    if (IsBlocked)
                        return SecurityLevelDisplayCommand.DoorLocked;
                    else if (IsUnlocked)
                        return SecurityLevelDisplayCommand.DoorUnlocked;
                    return SecurityLevelDisplayCommand.WaitCard;
                case DoorAgentContexts.IsolateDoorChanged:
                    if (Isolated)
                        return SecurityLevelDisplayCommand.WaitCard;
                    else if (DoorAgent.OperationState == DoorOperationState.Ajar)
                        return SecurityLevelDisplayCommand.DoorAjar;
                    else if (DoorAgent.OperationState == DoorOperationState.Forced)
                        return SecurityLevelDisplayCommand.DoorForced;
                    return SecurityLevelDisplayCommand.WaitCard;
                case DoorAgentContexts.WaitForPinOnInReader:
                case DoorAgentContexts.WaitForPinOnOutReader:
                    return SecurityLevelDisplayCommand.WaitPinCode;
                case DoorAgentContexts.KeypadInactivityInReaderTimerExpired:
                case DoorAgentContexts.KeypadInactivityOutReaderTimerExpired:
                    return SecurityLevelDisplayCommand.WaitCard;
                default:
                    return SecurityLevelDisplayCommand.None;
            }
        }

        private bool isTroubleAlarm(Pacom.Peripheral.Common.InputStatus input)
        {
            if (input == Pacom.Peripheral.Common.InputStatus.Open ||
                input == Pacom.Peripheral.Common.InputStatus.Short ||
                input == Pacom.Peripheral.Common.InputStatus.Trouble)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Triggered when all reader statuses have been created and can be accessed from this door status instance.
        /// The door postinitialize function will be called on auto configuration.
        /// </summary>
        internal void PostInitialize()
        {
            bool initializeAgentRequired = false;
            DoorConfiguration doorConfig = ConfigurationManager.Instance.GetDoorConfiguration(LogicalId);
            if (doorConfig != null)
            {
                // Assign In-reader
                if (doorConfig.InReader != null && doorConfig.InReader.Enabled == true && doorConfig.InReader.ParentDeviceId > 0)
                {
                    var readerStatus = StatusManager.Instance.Readers[doorConfig.ReaderInId];
                    if (readerStatus != inReaderStatus)
                    {
                        inReaderStatus = readerStatus;
                        initializeAgentRequired = true;
                    }
                }
                else if (inReaderStatus != null)
                {
                    inReaderStatus = null;
                    initializeAgentRequired = true;
                }
                // Assign Out-reader
                if (doorConfig.OutReader != null && doorConfig.OutReader.Enabled == true && doorConfig.OutReader.ParentDeviceId > 0 && 
                    doorConfig.ReaderOutId != doorConfig.ReaderInId)
                {
                    var readerStatus = StatusManager.Instance.Readers[doorConfig.ReaderOutId];
                    if (readerStatus != outReaderStatus)
                    {
                        outReaderStatus = readerStatus;
                        initializeAgentRequired = true;
                    }
                }
                else if (outReaderStatus != null)
                {
                    outReaderStatus = null;
                    initializeAgentRequired = true;
                }
            }

            if (initializeAgentRequired)
                initializeAgent();
        }

        /// <summary>
        /// Door agent initialization
        /// </summary>
        private void initializeAgent()
        {
            DoorConfiguration doorConfig = ConfigurationManager.Instance.GetDoorConfiguration(this.LogicalId);
            if (doorConfig == null || doorConfig.Enabled == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Door {0} is not enabled. Unable to create door agent.", this.LogicalId);
                });
            }
            else if (doorConfig.InReader == null || doorConfig.InReader.Enabled == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Door {0} does not have an entry reader assigned. Unable to create door agent.", this.LogicalId);
                });
            }
            else
            {
                agentInstance = DoorAgentBase.CreateInstance(doorConfig.DoorLockOperation, this, inReaderStatus, outReaderStatus) as DoorAgentBase;
            }

            agentInstance.StrikeTime = doorConfig.StrikeTimeInMilliseconds;
            agentInstance.ShuntTime = (int)doorConfig.ShuntTime.TotalMilliseconds;
            agentInstance.EmbarrassmentTime = (int)doorConfig.EmbarrassmentTime.TotalMilliseconds;
            agentInstance.KeypadInactivityTimeout = (int)ConfigurationManager.Instance.ControllerConfiguration.ReaderInactivityTimeout.TotalMilliseconds;
            agentInstance.StoreCardInDegradedMemory = doorConfig.EnableDegradedOperation;

            if (agentInstance.ShuntTime <= agentInstance.EmbarrassmentTime)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Configuration error for door Id {0}: shunt time {1}s must be > than embarrassment time {2}s",
                        doorConfig.Id, doorConfig.ShuntTime.TotalSeconds, doorConfig.EmbarrassmentTime.TotalSeconds);
                });
            }
        }

        /// <summary>
        /// Door agent finalization
        /// </summary>
        private void finalizeAgent()
        {
            if (agentInstance != null)
            {
                agentInstance.Dispose();
                agentInstance = null;
            }
        }

        internal override void Cleanup()
        {
            finalizeAgent();
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Removing door status with Id {0}.", this.LogicalId);
            });
#endif
        }
    }
}
