﻿using System;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.AlarmManagement;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Macros;
using Pacom.Serialization.Formatters.Asn1;
using System.Collections.Generic;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Events.EventsCommon;
using Pacom.Events.EventsCommon.Status;
using Pacom.Common.CompactFramework.Helpers;
using System.IO;
using Pacom.Peripheral.Common.Utils;

using DeviceLoopDeviceStatus = Pacom.Peripheral.Common.Status.DeviceLoopDeviceStatus;
using Pacom.Core.Attributes;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// This class provides a central state repository for devices, areas, doors, inputs,
    /// outputs, presence zones and readers.
    /// </summary>
    public partial class StatusManager : IDisposable
    {
        /// <summary>
        /// Pacom 8003 Controller status
        /// </summary>
        private ControllerStatus controllerStatus = null;

        /// <summary>
        /// Devices status list
        /// </summary>
        private DeviceStatusList devices = null;

        /// <summary>
        /// Areas status list
        /// </summary>
        private AreaStatusList areas = null;

        /// <summary>
        /// Doors status list
        /// </summary>
        private DoorStatusList doors = null;

        /// <summary>
        /// Inputs status list
        /// </summary>
        private InputStatusList inputs = null;

        /// <summary>
        /// Outputs status list
        /// </summary>
        private OutputStatusList outputs = null;

        private ElevatorStatusList elevators = null;

        /// <summary>
        /// Card Readers status list
        /// </summary>
        private ReaderStatusList readers = null;

        /// <summary>
        /// Presence Zone status list
        /// </summary>
        private PresenceZoneStatusList presenceZones = null;

        private ExpansionCardStatusList expansionCards = null;

        private InterlockGroupStatusList interlockGroups = null;

        private VaultControllerStatusList vaultControllers = null;

        private readonly FrontEndConnectionStatus[] frontEndConnectionStatuses = new FrontEndConnectionStatus[ConfigConsts.MaxControllerConnectionTables];

        private SystemStatusType systemStatus;

        private ILocalDeviceManager localDeviceManager = null;
        private IDeviceLoopManager deviceLoopManager = null;
        private IAlarmManager alarmManager = null;

        private DeviceStatusUpdateAgent statusUpdateAgent = null;
        public DeviceStatusUpdateAgent StatusUpdateAgent
        {
            get { return statusUpdateAgent; }
        }

        public event EventHandler<EventArgs> TimeChanged;
        protected void onTimeChanged()
        {
            if (TimeChanged != null)
            {
                TimeChanged(this, new EventArgs());
            }
        }
        /// <summary>
        /// Status Manager only instance
        /// </summary>
        private static StatusManager instance = null;

        /// <summary>
        /// StatusManager instance creation. This should only be called once in order to
        /// create the StatusManager. After that the Instance property should be used to 
        /// access the StatusManager.
        /// </summary>
        /// <returns></returns>
        public static StatusManager CreateInstance(ISram sram, IDataFlash dataFlash, IAccessCardManager accessCardManager)
        {
            if (instance == null)
            {
                instance = new StatusManager(sram, dataFlash, accessCardManager);
            }
            return instance;
        }

        /// <summary>
        /// Status Manager instance accessor
        /// </summary>
        public static StatusManager Instance
        {
            get
            {
                return instance;
            }
        }

        private StatusManager(ISram sram, IDataFlash dataFlash, IAccessCardManager accessCardManager)
        {
#if DEBUG

            // Verify default types
            System.Reflection.Assembly statusAssembly = System.Reflection.Assembly.GetExecutingAssembly();
            foreach (System.Type type in statusAssembly.GetTypes())
            {
                if (type.IsSubclassOf(typeof(StatusStorageBase)) == false)
                    continue;
                
                foreach (System.Reflection.PropertyInfo prop in type.GetProperties())
                {
                    var defPropType = prop.GetCustomAttributes(typeof(System.ComponentModel.DefaultValueAttribute), true).FirstOrDefault();
                    if (defPropType == null)
                        continue;
                    System.ComponentModel.DefaultValueAttribute defProp = defPropType as System.ComponentModel.DefaultValueAttribute;
                    if (defProp == null)
                        continue;
                    
                    // Check the default value type and property type. The enum can have 0 in the default value.
                    if ((prop.PropertyType.IsValueType == false && defProp.Value == null)
                        || (prop.PropertyType == defProp.Value.GetType())
                        || (prop.PropertyType.IsEnum && Enum.GetUnderlyingType(prop.PropertyType) == defProp.Value.GetType()))
                        continue;
                    
                    // Fix the types in the controller storage.
                    System.Diagnostics.Debugger.Break();
                }                                
            }
            
#endif

            DataFlash = dataFlash;
            Sram = sram;

            systemStatus = SystemStatusType.NormalOperation;

            ConfigurationManager.Instance.AfterConfigurationChanging += new EventHandler<ConfigurationChangeEventArgs>(configurationManager_AfterConfigurationChanging);
            ConfigurationManager.Instance.BeforeConfigurationChanged += new EventHandler<ConfigurationChangeEventArgs>(configurationManager_BeforeConfigurationChanged);
            ConfigurationManager.Instance.ConfigurationChanging += new EventHandler<ConfigurationChangeEventArgs>(configurationManager_ConfigurationChanging);

            // Create status instances
            devices = new DeviceStatusList();
            controllerStatus = new ControllerStatus(ConfigurationManager.Instance.ControllerConfiguration, dataFlash, devices, accessCardManager);
            areas = new AreaStatusList();
            doors = new DoorStatusList();
            inputs = new InputStatusList();
            outputs = new OutputStatusList();
            elevators = new ElevatorStatusList();
            readers = new ReaderStatusList();
            presenceZones = new PresenceZoneStatusList();
            interlockGroups = new InterlockGroupStatusList();
            expansionCards = new ExpansionCardStatusList();
            vaultControllers = new VaultControllerStatusList();

            // Device / expansion card status and information update agent - sends updated status / information to SM when devices go online
            statusUpdateAgent = new DeviceStatusUpdateAgent();

            asn1Serializer = new Asn1DerFormatter(typesList, true, context);
            startStatusStorageThread();
            InitializeTimedActions();

            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return "Ready.";
            });
        }

        /// <summary>
        /// Timeout for suspected offline type after device was detected offline.
        /// </summary>
        public const int SuspectedOfflineTimeout = 60;

        /// <summary>
        /// Timeout for suspected offline type after a controller restart or a configuration change.
        /// </summary>
        internal const int ControllerRestartedConfigurationChangedOfflineTimeout = 300;

        internal IDataFlash DataFlash
        {
            get;
            private set;
        }

        internal ISram Sram
        {
            get;
            private set;
        }

        /// <summary>
        /// Pacom 8003 Controller status
        /// </summary>
        public ControllerStatus Controller
        {
            get { return controllerStatus; }
        }

        /// <summary>
        /// Devices status list
        /// </summary>
        public DeviceStatusList Devices
        {
            get { return devices; }
        }

        /// <summary>
        /// Expansion cards status list
        /// </summary>
        public ExpansionCardStatusList ExpansionCards
        {
            get { return expansionCards; }
        }

        /// <summary>
        /// Areas status list
        /// </summary>
        public AreaStatusList Areas
        {
            get { return areas; }
        }

        /// <summary>
        /// Doors status list
        /// </summary>
        public DoorStatusList Doors
        {
            get { return doors; }
        }

        /// <summary>
        /// Inputs status list
        /// </summary>
        public InputStatusList Inputs
        {
            get { return inputs; }
        }

        /// <summary>
        /// Outputs status list
        /// </summary>
        public OutputStatusList Outputs
        {
            get { return outputs; }
        }

        public ElevatorStatusList Elevators
        {
            get { return elevators; }
        }

        /// <summary>
        /// Card Readers status list
        /// </summary>
        public ReaderStatusList Readers
        {
            get { return readers; }
        }

        public VaultControllerStatusList VaultControllers
        {
            get { return vaultControllers; }
        }

        /// <summary>
        /// Get the status item instance for the specified NodeCategory and the item logical Id.
        /// </summary>
        /// <param name="nodeCategory">One of: Input, Output, Device (controller, device loop device, expansion card), Reader, Door, Area, Presence Zone, Interlock Group</param>
        /// <returns>Status item instance or null if no instance found</returns>
        public IStatusItem this[NodeCategory nodeCategory, int logicalId]
        {
            get
            {
                switch (nodeCategory)
                {
                    case NodeCategory.Device:
                        if (logicalId == ConfigurationManager.Instance.ControllerConfiguration.Id)
                        {
                            return Controller;
                        }
                        else
                        {
                            IStatusItem item = devices[logicalId];
                            if (item != null)
                                return item;
                            return expansionCards[logicalId];
                        };
                    case NodeCategory.Input:
                        return inputs[logicalId];
                    case NodeCategory.Output:
                        return outputs[logicalId];
                    case NodeCategory.Elevator:
                        return elevators[logicalId];
                    case NodeCategory.Door:
                        return doors[logicalId];
                    case NodeCategory.Reader:
                        return readers[logicalId];
                    case NodeCategory.Area:
                        return areas[logicalId];
                    case NodeCategory.PresenceZone:
                        return presenceZones[logicalId];
                    case NodeCategory.Interlock:
                        return interlockGroups[logicalId];
                    case NodeCategory.VaultController:
                        return vaultControllers[logicalId];
                    default:
                        return null;
                }
            }
        }

        /// <summary>
        /// Presence Zone status list
        /// </summary>
        public PresenceZoneStatusList PresenceZones
        {
            get { return presenceZones; }
        }

        /// <summary>
        /// Interlock Groups status list
        /// </summary>
        public InterlockGroupStatusList InterlockGroups
        {
            get { return interlockGroups; }
        }

        public FrontEndConnectionStatus GetFrontEndConnectionStatus(int index)
        {
            if (index >= frontEndConnectionStatuses.Length || index < 0)
                return null;

            return frontEndConnectionStatuses[index];
        }

        public CommunicationToFrontEndStatus GetUnmaskedFrontEndOnlineStatus()
        {
            return getFrontEndOnlineStatus(Controller.GetOnlineConnectionTable(0), Controller.GetOnlineConnectionTable(1));
        }

        public CommunicationToFrontEndStatus GetMaskedFrontEndOnlineStatus()
        {
            return getFrontEndOnlineStatus(Controller.GetMaskedOnlineConnectionTable(0), Controller.GetMaskedOnlineConnectionTable(1));
        }

        private CommunicationToFrontEndStatus getFrontEndOnlineStatus(bool onlineConnectionTable1, bool onlineConnectionTable2)
        {
            CommunicationToFrontEndStatus status = CommunicationToFrontEndStatus.None;
            bool connectionTable1Valid = false;
            if (ConfigurationManager.Instance.GetControllerConnectionTable(0) != null)
            {
                connectionTable1Valid = true;
                status |= CommunicationToFrontEndStatus.ConnectionTable1Valid;
            }
            bool connectionTable2Valid = false;
            if (ConfigurationManager.Instance.GetControllerConnectionTable(1) != null)
            {
                connectionTable2Valid = true;
                status |= CommunicationToFrontEndStatus.ConnectionTable2Valid;
            }
            if (onlineConnectionTable1)
            {
                status |= CommunicationToFrontEndStatus.ConnectionTable1Online;
            }
            if (onlineConnectionTable2)
            {
                status |= CommunicationToFrontEndStatus.ConnectionTable2Online;
            }

            if ((connectionTable1Valid == false && connectionTable2Valid == false) ||
                (connectionTable1Valid == true && connectionTable2Valid == true && onlineConnectionTable1 == true && onlineConnectionTable2 == true) ||
                (connectionTable1Valid == false && connectionTable2Valid == true && onlineConnectionTable2 == true) ||
                (connectionTable2Valid == false && connectionTable1Valid == true && onlineConnectionTable1 == true))
            {
                status |= CommunicationToFrontEndStatus.OnlineOnAllConfiguredConnectionTables;
            }
            else if ((connectionTable1Valid == true && connectionTable2Valid == true && onlineConnectionTable1 == false && onlineConnectionTable2 == false) ||
                    (connectionTable1Valid == true && onlineConnectionTable1 == false) ||
                    (connectionTable2Valid == true && onlineConnectionTable2 == false))
            {
                status |= CommunicationToFrontEndStatus.OfflineOnAllConfiguredConnectionTables;
            }
            else
            {
                status |= CommunicationToFrontEndStatus.OnlineOnSomeConfiguredConnectionTables;
            }
            return status;
        }

        internal ILocalDeviceManager LocalDeviceManager
        {
            get { return localDeviceManager; }
        }

        public IDeviceLoopManager DeviceLoopManager
        {
            get { return deviceLoopManager; }
        }

        public IAlarmManager AlarmManager
        {
            get { return alarmManager; }
        }

        public SystemStatusType SystemStatus
        {
            get { return systemStatus; }
            private set
            {
                systemStatus = value;
            }
        }

        /// <summary>
        /// Triggered when a status update event is ready to send to head end.
        /// </summary>
        public event EventHandler StatusEventReady = null;

        /// <summary>
        /// Triggered when device information needs to be sent to head end.
        /// </summary>
        public event EventHandler SendDeviceInformation = null;

        public void SetLocalDevice(ILocalDeviceManager localDeviceManager)
        {
            this.localDeviceManager = localDeviceManager;
            if(outputs.IsEmpty == false)
                outputs.UpdateSchedules();
        }

        public void SetDeviceLoopManager(IDeviceLoopManager deviceLoopManager)
        {
            this.deviceLoopManager = deviceLoopManager;
        }

        public void SetAlarmManager(IAlarmManager alarmManager)
        {
            this.alarmManager = alarmManager;
        }

        /// <summary>
        /// Check if any device alarms are present
        /// </summary>
        public bool AnyDeviceAlarms
        {
            get { return devices.AnyInAlarm || expansionCards.AnyInAlarm; }
        }

        /// <summary>
        /// Update reader/areas/output/elevator schedules when the controller time is updated from the front-end or
        /// otherwise.
        /// </summary>
        public void UpdateSchedules()
        {
            Readers.UpdateStatus();
            Areas.UpdateStatus();
            Outputs.UpdateSchedules();
            Elevators.UpdateSchedules();
            onTimeChanged();
        }

        /// <summary>
        /// Triggered after the configuration changing event handlers were executed and allows the Status Manager to clear 
        /// all it's internal lists.
        /// </summary>
        /// <param name="sender">Not Used</param>
        /// <param name="e">Not Used</param>
        private void configurationManager_AfterConfigurationChanging(object sender, ConfigurationChangeEventArgs e)
        {
            // Update status manager offline storage            
            stopStatusStorageThread();
            RequestStatusToStorage();
        }

        /// <summary>
        /// Triggered before the configuration changed event handlers are called and allows the Status Manager to update
        /// its states list from configuration changes before the device loop is restarted.
        /// </summary>
        /// <param name="sender">Not Used</param>
        /// <param name="e">Not Used</param>
        private void configurationManager_BeforeConfigurationChanged(object sender, ConfigurationChangeEventArgs e)
        {
            if (ConfigurationManager.Instance.ControllerConfiguration == null)
                return;

            updateFromConfiguration(e);
            resumePendingTimedActions();
            
            // At this point the controller is working as expected. Configuration will be applied.
            SystemStatus = SystemStatusType.NormalOperation;
            startStatusStorageThread();
            RequestStatusToStorage();
        }

        private void configurationManager_ConfigurationChanging(object sender, ConfigurationChangeEventArgs e)
        {
            pausePendingTimedActions();
            SystemStatus = SystemStatusType.ConfigurationChanging;
        }

        /// <summary>
        /// Update the Status Manager stored objects from configuration on startup. This is called
        /// the 1st time the configuration is downloaded to controller.
        /// </summary>
        public void UpdateFromConfigurationFirstTime()
        {
            // Attmpt to retrive status from store
            StatusStorageCollection statusStorage = new StatusStorageCollection();
            loadStatusFromStorage(ref statusStorage);

            ConfigurationManager configurationManager = ConfigurationManager.Instance;

            // Create front end connection status instance
            for (int i = 0; i < ConfigConsts.MaxControllerConnectionTables; i++)
            {
                frontEndConnectionStatuses[i] = new FrontEndConnectionStatus(configurationManager.GetControllerConnectionTable(i));
            }

            // Restore controller status
            controllerStatus.RestoreToPreviousState(statusStorage.Controller);

            // Create areas status instances
            areas.UpdateFromConfiguration(configurationManager.AreasAsArray, statusStorage);

            // Create Pacom Device Loop / Inovonics EchoStream devices status instances
            devices.UpdateFromConfiguration(configurationManager.Devices, statusStorage);

            // Create expansion card status instances
            expansionCards.UpdateFromConfiguration(configurationManager.ExpansionCards, statusStorage);

            // Create doors status instances
            doors.UpdateFromConfiguration(configurationManager.Doors, statusStorage);

            // Create inputs status instances
            inputs.UpdateFromConfiguration(configurationManager.Inputs, statusStorage);

            // Create outputs status instances
            outputs.UpdateFromConfiguration(configurationManager.Outputs, statusStorage);

            elevators.UpdateFromConfiguration(configurationManager.Elevators, statusStorage);

            // Create presence zone status instances
            presenceZones.UpdateFromConfiguration(configurationManager.PresenceZones, statusStorage);

            // Create interlock group status instances
            interlockGroups.UpdateFromConfiguration(configurationManager.InterlockGroups, statusStorage);

            // Create card reader status instances
            readers.UpdateFromConfiguration(configurationManager.Readers, statusStorage);

            // Create vault controllers status instances
            vaultControllers.UpdateFromConfiguration(configurationManager.Devices, statusStorage);

            // Setup door agents
            doors.PostInitialize();
            readers.PostInitialize();

            inputs.RefreshAfterConfigurationChange();
            outputs.RefreshAfterConfigurationChange();
            elevators.RefreshAfterConfigurationChange();
            doors.RefreshAfterConfigurationChange();
            readers.RefreshAfterConfigurationChange();
            vaultControllers.RefreshAfterConfigurationChange();

            // Update schedules
            todayDayType = Core.Contracts.DayType.None;
            if (Areas.IsEmpty == false)
                Areas.UpdateStatus();
            if (Readers.IsEmpty == false)
                Readers.UpdateStatus();

            // Update lists from configuration changes
            devices.AfterStatusUpdate();
            expansionCards.AfterStatusUpdate();
            inputs.AfterStatusUpdate();
            readers.AfterStatusUpdate();

            RestoreTimedActions(statusStorage.TimedActions);

            elevators.UpdateFromConfigurationFirstTime();
        }

        private void updateFromConfiguration(ConfigurationChangeEventArgs e)
        {
            ConfigurationManager configurationManager = ConfigurationManager.Instance;

            List<ConfigurationChanges> newlyAddedItems = e.NewlyAddedItems;
            List<ConfigurationChanges> changedItems = e.ChangedItems;
            List<ConfigurationChanges> removedItems = e.RemovedItems;

            // Create front end connection status instance
            for (int i = 0; i < ConfigConsts.MaxControllerConnectionTables; i++)
            {
                frontEndConnectionStatuses[i].Update(configurationManager.GetControllerConnectionTable(i));
            }

            // Restore controller status
            controllerStatus.RefreshAfterConfigurationChange(newlyAddedItems, changedItems, removedItems);

            List<NodeStateBase> partialStatusList = new List<NodeStateBase>();
            // Create areas status instances
            areas.UpdateFromConfiguration(newlyAddedItems, changedItems, removedItems, partialStatusList);

            // Create Pacom Device Loop / Inovonics EchoStream devices status instances
            devices.UpdateFromConfiguration(e, partialStatusList);

            // Create expansion card status instances
            expansionCards.UpdateFromConfiguration(newlyAddedItems, changedItems, removedItems, partialStatusList);

            // Create doors status instances
            doors.UpdateFromConfiguration(newlyAddedItems, changedItems, removedItems, partialStatusList);

            // Create inputs status instances
            inputs.UpdateFromConfiguration(newlyAddedItems, changedItems, removedItems, partialStatusList);

            // Create outputs status instances
            outputs.UpdateFromConfiguration(newlyAddedItems, changedItems, removedItems, partialStatusList);

            elevators.UpdateFromConfiguration(newlyAddedItems, changedItems, removedItems, partialStatusList);

            // Create presence zone status instances
            presenceZones.UpdateFromConfiguration(newlyAddedItems, changedItems, removedItems);

            // Create interlock group status instances
            interlockGroups.UpdateFromConfiguration(newlyAddedItems, changedItems, removedItems);

            // Create card reader status instances
            readers.UpdateFromConfiguration(newlyAddedItems, changedItems, removedItems, partialStatusList);

            vaultControllers.UpdateFromConfiguration(newlyAddedItems, changedItems, removedItems, partialStatusList);

            // Generate a partial status upload for the affected nodes
            if (e.ControllerChanged || e.ConnectionTableAffected)
                SendStatusEvent(ConfigConsts.AllControllerConnectionTables);
            else if (partialStatusList.Count > 0)
                sendStatusEvent(partialStatusList, ConfigConsts.AllControllerConnectionTables, true);

            // Setup door agents
            doors.PostInitialize();
            readers.PostInitialize();

            if (changesInclude(newlyAddedItems, changedItems, ConfigurationElementType.Area))
            {
                // If an area has changed or been added, refresh all the points. Required to maintain area lists.
                inputs.RefreshAfterConfigurationChange();
                outputs.RefreshAfterConfigurationChange();
                elevators.RefreshAfterConfigurationChange();
                doors.RefreshAfterConfigurationChange();
                readers.RefreshAfterConfigurationChange();
            }
            else
            {
                // Otherwise only refresh the points that have changed. Required to maintain area lists.
                inputs.RefreshAfterConfigurationChange(changedItems);
                outputs.RefreshAfterConfigurationChange(changedItems);
                elevators.RefreshAfterConfigurationChange(changedItems);
                doors.RefreshAfterConfigurationChange(changedItems);
                readers.RefreshAfterConfigurationChange(changedItems);
            }

            // Update schedules
            todayDayType = Core.Contracts.DayType.None;
            if (areas.IsEmpty == false)
                areas.UpdateStatus();
            if (readers.IsEmpty == false)
                readers.UpdateStatus();
            if (outputs.IsEmpty == false)
                outputs.UpdateSchedules();
            if (elevators.IsEmpty == false)
                elevators.UpdateSchedules();
            
            // Update lists from configuration changes
            devices.AfterStatusUpdate();
            if (changesInclude(newlyAddedItems, changedItems, ConfigurationElementType.ExpansionCard))
                expansionCards.AfterStatusUpdate();
            inputs.AfterStatusUpdate(newlyAddedItems, changedItems);
            if (changesInclude(newlyAddedItems, changedItems, ConfigurationElementType.Reader))
                readers.AfterStatusUpdate();
        }

        private bool changesInclude(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, ConfigurationElementType configurationElementType)
        {
            foreach (var newlyAddedItem in newlyAddedItems)
            {
                if (newlyAddedItem.ConfigurationType == configurationElementType)
                    return true;
            }
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == configurationElementType)
                    return true;
            }
            return false;
        }

        private static Core.Contracts.DayType todayDayType = Core.Contracts.DayType.None;
        private static DateTime todayDayTypeUpdated = DateTime.MinValue.Date;

        public static Core.Contracts.DayType TodayDayType
        {
            get
            {
                if (todayDayType != Core.Contracts.DayType.None && todayDayTypeUpdated == ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow).Date)
                    return todayDayType;
                else
                {
                    DateTime today = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow).Date;
                    Core.Contracts.DayType result = today.ConvertDayOfWeekToDayType();
                    Core.Access.Calendar calendar = ConfigurationManager.Instance.Calendar;
                    if (calendar != null && calendar.DayTypes != null && calendar.DayTypes.Length > 0)
                    {
                        Core.Access.CalendarRecord[] dayTypes = calendar.DayTypes;

                        foreach (Core.Access.CalendarRecord dayType in dayTypes)
                        {
                            if (dayType.Recurrence == Core.Access.RecurrenceType.OneOff &&
                                today.Day == dayType.Date.Day && today.Month == dayType.Date.Month && today.Year == dayType.Date.Year)
                            {
                                result = dayType.DayType;
                                break;
                            }
                            else if (dayType.Recurrence == Core.Access.RecurrenceType.Annually &&
                                today.Day == dayType.Date.Day && today.Month == dayType.Date.Month)
                            {
                                result = dayType.DayType;
                                break;
                            }
                            else if (dayType.Recurrence == Core.Access.RecurrenceType.Monthly &&
                                today.Day == dayType.Date.Day)
                            {
                                result = dayType.DayType;
                                break;
                            }
                        }
                    }
                    todayDayType = result;
                    todayDayTypeUpdated = today;
                    return result;
                }
            }
        }

        /// <summary>
        /// Signal status manager that the controller is restarting
        /// </summary>
        public void SignalControllerRestarting()
        {
            this.SystemStatus = SystemStatusType.ControllerRestarting;
        }

        /// <summary>
        /// Send status update event to SM on the specified connection
        /// </summary>
        /// <param name="connectionTableIndex">Id of the connection in connection table</param>
        public bool SendStatusEvent(int connectionTableIndex)
        {
            List<NodeStateBase> statusList = new List<NodeStateBase>();
            using (var configChanger = ConfigurationManager.Instance.TryCreateConfigurationReader())
            {
                if (configChanger.LockAcquired == true)
                {
                    // Generate status for the controller
                    statusList.Add(Controller.CreateEventState());

                    // Generate status for all Pacom device loop devices / Inovonics EchoStream devices
                    Devices.CreateEventState(statusList);

                    // Generate status for all expansion cards
                    ExpansionCards.CreateEventState(statusList);

                    // Generate status for all areas
                    Areas.CreateEventState(statusList);

                    // Generate status for all inputs
                    Inputs.CreateEventState(statusList);

                    // Generate status for all outputs
                    Outputs.CreateEventState(statusList);

                    // Generate status for all elevators
                    Elevators.CreateEventState(statusList);

                    // Generate status for all doors
                    Doors.CreateEventState(statusList);

                    // Generate status for all readers
                    Readers.CreateEventState(statusList);
                }
                else
                {
                    return false;
                }
            }
            return sendStatusEvent(statusList, connectionTableIndex, false);
        }
        
        public bool sendStatusEvent(List<NodeStateBase> statusList, int connectionTableIndex, bool partialStatus)
        {
            // If the previous event status update hasn't taken place yet, we don't want to override it with a partial status update so we will
            // force a complete status update.
            if (partialStatus)
            {
                // If we are sending a partial status but there is already a status queued to send, send a full status.
                if (connectionTableIndex == ConfigConsts.AllControllerConnectionTables)
                {
                    if (GetFrontEndConnectionStatus(0).PendingNodeStatusEvent != null ||
                        GetFrontEndConnectionStatus(1).PendingNodeStatusEvent != null)
                    {
                        return SendStatusEvent(connectionTableIndex);
                    }
                }
                else if (GetFrontEndConnectionStatus(connectionTableIndex).PendingNodeStatusEvent != null)
                {
                        return SendStatusEvent(connectionTableIndex);
                }
            }

            NodeStateEvent nodeStateEvent = new NodeStateEvent();
            nodeStateEvent.NodeStates = statusList.ToArray();
            nodeStateEvent.Id = ConfigurationManager.Instance.ControllerConfiguration.SiteId;
            nodeStateEvent.Category = NodeCategory.Site;
            nodeStateEvent.SourceAddress = new LogicalAddress(0, NodeType.Site, (uint)nodeStateEvent.Id, OpenPacomObjectType.Controller, 1).ToString();
            nodeStateEvent.UtcTimestamp = DateTime.UtcNow;
            nodeStateEvent.Partial = partialStatus;

            byte[] data = null;
            try
            {
                StreamingContext context = new StreamingContext();
                Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(true, context);

                using (MemoryStream stream = new MemoryStream())
                {
                    asn1Serializer.Serialize(stream, nodeStateEvent);
                    if (stream.Length > 0)
                    {
                        data = new byte[stream.Length];
                        stream.Position = 0;
                        stream.Read(data, 0, (int)stream.Length);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.EventQueue, () =>
                {
                    return string.Format("Unable to serialize status event. {0}", ex.Message);
                });
            }
            if (data != null)
            {
                if (connectionTableIndex == ConfigConsts.AllControllerConnectionTables)
                {
                    if (GetFrontEndConnectionStatus(0).Enabled)
                        GetFrontEndConnectionStatus(0).PendingNodeStatusEvent = data;
                    else
                        GetFrontEndConnectionStatus(0).PendingNodeStatusEvent = null;
                    if (GetFrontEndConnectionStatus(1).Enabled)
                        GetFrontEndConnectionStatus(1).PendingNodeStatusEvent = data;
                    else
                        GetFrontEndConnectionStatus(1).PendingNodeStatusEvent = null;
                }
                else
                {
                    GetFrontEndConnectionStatus(connectionTableIndex).PendingNodeStatusEvent = data;
                }
                if (StatusEventReady != null)
                    StatusEventReady(this, new EventArgs());
                return true;
            }
            return false;
        }

        /// <summary>
        /// Trigger event when device information needs to be sent to SM.
        /// </summary>
        internal void TriggerSendDeviceInformation()
        {
            if (SendDeviceInformation != null)
                SendDeviceInformation(this, new EventArgs());
        }

        public GlobalAntiPassbackResult CheckGlobalAntiPassback(long userId, int[] enterIntoPresenceZoneIds)
        {
            foreach (int presenceZoneId in enterIntoPresenceZoneIds)
            {
                PresenceZoneConfiguration presenceZoneConfiguration = ConfigurationManager.Instance.GetPresenceZoneConfiguration(presenceZoneId);
                PresenceZoneStatus presenceZoneStatus = PresenceZones[presenceZoneId];
                if (presenceZoneConfiguration != null && presenceZoneStatus != null)
                {
                    if (presenceZoneConfiguration.AntiPassbackType == AntiPassbackType8003.Hard && presenceZoneStatus.Contains(userId))
                    {
                        return GlobalAntiPassbackResult.AccessDenied;
                    }
                }
            }
            return GlobalAntiPassbackResult.AccessGranted;
        }

        public GlobalAntiPassbackResult UpdateGlobalAntiPassback(long userId, int[] enterIntoPresenceZoneIds, int[] exitOutOfPresenceZoneIds)
        {
            GlobalAntiPassbackResult result = GlobalAntiPassbackResult.AccessGranted;
            if (enterIntoPresenceZoneIds != null && enterIntoPresenceZoneIds.Length > 0)
            {
                foreach (int presenceZoneId in enterIntoPresenceZoneIds)
                {
                    PresenceZoneConfiguration presenceZoneConfiguration = ConfigurationManager.Instance.GetPresenceZoneConfiguration(presenceZoneId);
                    PresenceZoneStatus presenceZoneStatus = PresenceZones[presenceZoneId];
                    if (presenceZoneConfiguration != null && presenceZoneStatus != null)
                    {
                        bool containsCardholder = presenceZoneStatus.Contains(userId);
                        if (containsCardholder == true && presenceZoneConfiguration.AntiPassbackType == AntiPassbackType8003.Soft)
                        {
                            // Send soft antipassback failed event
                            result = GlobalAntiPassbackResult.AccessGrantedSoftAntiPassback;
                        }
                        else if (containsCardholder == false)
                        {
                            // Add cardholder to presence zone
                            presenceZoneStatus.Add(userId);
                        }
                    }
                }
            }

            if (exitOutOfPresenceZoneIds != null && exitOutOfPresenceZoneIds.Length > 0)
            {
                // Remove the card / user from Exit presence zone for this reader if found
                foreach (int presenceZoneId in exitOutOfPresenceZoneIds)
                {
                    // Remove card / user from the antipassback list for this presence zone
                    PresenceZoneStatus presenceZoneStatus = PresenceZones[presenceZoneId];
                    if (presenceZoneStatus != null)
                        presenceZoneStatus.Remove(userId);
                }
            }
            return result;
        }

        public void ForgiveCardHolder(long userId)
        {
            // Clear this card / user id from all presence zones
            PresenceZoneStatus[] presenceZones = PresenceZones.Items;
            foreach (var presenceZoneStatus in presenceZones)
            {
                if (presenceZoneStatus != null)
                {
                    presenceZoneStatus.Remove(userId);
                }
            }
        }

        #region IDisposable Members

        bool disposed = false;
        bool disposing = false;

        protected void Dispose(bool disposing)
        {
            try
            {
                if (disposed == false)
                {
                    if (disposing)
                    {
                        this.disposing = true;
                        FinalizeTimedActions();
                        if (ConfigurationManager.Instance != null)
                        {
                            ConfigurationManager.Instance.AfterConfigurationChanging -= new EventHandler<ConfigurationChangeEventArgs>(configurationManager_AfterConfigurationChanging);
                            ConfigurationManager.Instance.BeforeConfigurationChanged -= new EventHandler<ConfigurationChangeEventArgs>(configurationManager_BeforeConfigurationChanged);
                            ConfigurationManager.Instance.ConfigurationChanging -= new EventHandler<ConfigurationChangeEventArgs>(configurationManager_ConfigurationChanging);
                        }
                        stopStatusStorageThread();
                        // Cleanup status lists
                        if (expansionCards != null)
                        {
                            expansionCards.Dispose();
                            expansionCards = null;
                        }
                        if (presenceZones != null)
                        {
                            presenceZones.Dispose();
                            presenceZones = null;
                        }
                        if (readers != null)
                        {
                            readers.Dispose();
                            readers = null;
                        }
                        if (outputs != null)
                        {
                            outputs.Dispose();
                            outputs = null;
                        }
                        if (elevators != null)
                        {
                            elevators.Dispose();
                            elevators = null;
                        }
                        if (inputs != null)
                        {
                            inputs.Dispose();
                            inputs = null;
                        }
                        if (doors != null)
                        {
                            doors.Dispose();
                            doors = null;
                        }
                        if (areas != null)
                        {
                            areas.Dispose();
                            areas = null;
                        }
                        if (devices != null)
                        {
                            devices.Dispose();
                            devices = null;
                        }
                        if (vaultControllers != null)
                        {
                            vaultControllers.Dispose();
                            vaultControllers = null;
                        }
                        requestStatusStoreForProcessing.Close();
                        deviceLoopManager = null;
                        if (statusUpdateAgent != null)
                        {
                            statusUpdateAgent.Dispose();
                            statusUpdateAgent = null;
                        }
                        instance = null;
                    }
                    disposed = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while disposing status manager. {0}", ex.ToString());
                });
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
