﻿
using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.Common.Status
{
    public class ReaderMultiBadgingStatusBase
    {
        private IPacomTimer expiredTimer = null;
        protected int logicalDoorId;
        protected int logicalReaderId;
        private Action timerExpiredAction = null;
        private readonly int shuntTimeMs;
        public bool IsStarted { get { return expiredTimer != null; } }
        public ReaderBadgingType BadgingType { get; private set; }

        public ReaderMultiBadgingStatusBase(int logicalDoorId, int logicalReaderId, ReaderBadgingType badgingType, Action timerExpiredAction)
        {
            var doorConfig = ConfigurationManager.Instance.GetDoorConfiguration(logicalDoorId);
            this.logicalDoorId = logicalDoorId;
            this.logicalReaderId = logicalReaderId;
            shuntTimeMs = (int)doorConfig.ShuntTime.TotalMilliseconds;
            BadgingType = badgingType;
            this.timerExpiredAction = timerExpiredAction;
        }

        public virtual bool Start(Action triggerAction)
        {
            if (expiredTimer == null)
            {
                expiredTimer = TimerManager.Instance.CreateTimer(onTimeExpire);
                expiredTimer.RunOnce(shuntTimeMs);
                if (triggerAction != null)
                    triggerAction();
                return true;
            }
            return false;
        }

        public virtual void Clear()
        {
            killTimer();
        }

        protected void killTimer()
        {
            if (expiredTimer != null)
            {
                expiredTimer.Stop();
                TimerManager.Instance.RemoveTimer(expiredTimer);
                expiredTimer = null;
            }
        }

        private void onTimeExpire(object state)
        {
            if (expiredTimer != null)
            {
                killTimer();
                if (timerExpiredAction != null)
                    timerExpiredAction();
            }
        }
    }
}
