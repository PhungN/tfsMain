﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    public enum ReaderTransactionType
    {
        None = 0,
        Command,
        Egress,
        Card,
    }
}
