﻿
namespace Pacom.Peripheral.Common.Status
{
    public enum DoorAgentContexts
    {
        None,
        DoorContact,
        ShuntTimerExpired,
        EmbarrassmentTimerExpired,
        StrikeTimerExpired,
        DeniedTimerExpired,
        Egress,
        ValidCard,
        ValidMultiBadgingCard,
        AccessCommand,
        DeniedAccess,
        UpdateFromSchedule,
        CurrentDoorStateRequest,
        IsolateDoorChanged,
        WaitForPinOnInReader,
        WaitForPinOnOutReader,
        EndWaitForPinOnInReader,
        EndWaitForPinOnOutReader,
        KeypadInactivityInReaderTimerExpired,
        KeypadInactivityOutReaderTimerExpired,
        KeypadLockoutTimerExpired,

        // Accept / Denied LED Timer Expired
        AcceptLedTimerExpired,
        DeniedLedTimerExpired,
        DoorContactAlarm,

        // Interlock
        InterlockOpened,
    }
}
