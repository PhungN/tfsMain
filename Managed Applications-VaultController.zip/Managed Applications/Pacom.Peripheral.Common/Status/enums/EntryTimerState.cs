﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    public enum EntryTimerState
    {
        NotRunning = 0,
        EntryTimer1Running, // Slow entry timer runs first
        EntryTimer2Running, // Fast entry timer to indicate urgency
        ExtendedEntryTimerRunning, // Used when an off route input extends the entry delay as is the case for BS 8243
    }
}
