﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    public enum ReaderOfflineStatusType
    {
        /// <summary>
        /// The reader is online
        /// </summary>
        Online,

        /// <summary>
        /// The reader is offline
        /// </summary>
        Offline,

        /// <summary>
        /// The reader is offline however alarm will be sent with delay
        /// </summary>
        SuspectedOffline,
    }
}
