﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    [Flags]
    public enum TransactionType
    {
        None = 0,
        StrikeOn = 1,
        StrikeOff = 2,
        BuzzerOn = 4,
        PulseBuzzer = 8,
        BuzzerOff = 16,
        DeniedOn = 32,
        DeniedFlashing = 64,
        DeniedOff = 128,
        AcceptOn = 256,
        AcceptFlashing = 512,
        AcceptOff = 1024
    }
}
