﻿
namespace Pacom.Peripheral.Common.Status
{
    public enum InterlockContextStatus
    {
        None,
        DeniedAccess
    }
}
