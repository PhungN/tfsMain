﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    public enum CardDatabaseStatus
    {
        /// <summary>
        /// No SD card has been found and the card database in SRAM is less than 90% full.
        /// </summary>
        SramDatabaseNotFull = 0,
        /// <summary>
        /// No SD card has been found and the card database in SRAM more than 90% full.
        /// </summary>
        SramDatabase90PercentFull,
        /// <summary>
        /// No SD card has been found and the card database in SRAM full.
        /// </summary>
        SramDatabaseFull,
        /// <summary>
        /// An SD card is present. Card counts are not performed as they are time consuming.
        /// </summary>
        SDCardFitted,
    }
}
