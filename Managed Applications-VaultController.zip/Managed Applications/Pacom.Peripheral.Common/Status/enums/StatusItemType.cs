﻿
namespace Pacom.Peripheral.Common.Status
{
    public enum StatusItemType
    {
        InputStatus,
        DeviceStatus,
        DoorStatus,
        ReaderStatus,
        AreaStatus,
        ExpansionCardStatus,
        FrontEndConnectionStatus,
        OutputStatus,
        PresenceZoneStatus,
        InterlockGroupStatus,
        ElevatorStatus,
        VaultController,
        VaultControllerGroupStatus,
    }
}
