﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// The status of the communications to the front end.
    /// </summary>
    [Flags]
    public enum CommunicationToFrontEndStatus
    {
        None = 0,
        ConnectionTable1Valid = 0x01,
        ConnectionTable2Valid = 0x02,
        ConnectionTable1Online = 0x04,
        ConnectionTable2Online = 0x08,
        OnlineOnAllConfiguredConnectionTables = 0x10,
        OnlineOnSomeConfiguredConnectionTables = 0x20,
        OfflineOnAllConfiguredConnectionTables = 0x40,
    }
}
