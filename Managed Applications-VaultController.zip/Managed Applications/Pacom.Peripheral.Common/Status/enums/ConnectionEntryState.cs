﻿
namespace Pacom.Peripheral.Common.Status
{
    public enum ConnectionEntryState
    {
        Offline = 0,
        Online = 1,
        NotPresent = 2
    }
}
