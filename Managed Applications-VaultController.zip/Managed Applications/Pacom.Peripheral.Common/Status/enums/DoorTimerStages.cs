﻿
namespace Pacom.Peripheral.Common.Status
{
    public enum DoorAlarmTimers
    {
        None,
        ShuntTimerInProgress,
        EmbarrassmentTimerInProgress
    }
}
