﻿
namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Door agent states
    /// </summary>
    public enum DoorOperationState
    {
        Unknown = 0,
        Opening,
        Opened,
        Closed,
        Egress,
        Forced,
        Ajar,        
        UnlockedPermanently,
    }
}
