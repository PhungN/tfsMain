﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    public enum DeviceLoopDeviceOfflineStatusType
    {
        /// <summary>
        /// The device is online
        /// </summary>
        Online,

        /// <summary>
        /// The device is offline
        /// </summary>
        Offline,

        /// <summary>
        /// The device is offline because of configuration changes or the 8003 has just restarted - 
        /// this is temporary and gives devices 5 mins to come back online.
        /// When the 5 mins expires the device will be reported as Offline and any device inputs will be marked as Self Test Failed.
        /// </summary>
        SuspectedOffline,
    }
}
