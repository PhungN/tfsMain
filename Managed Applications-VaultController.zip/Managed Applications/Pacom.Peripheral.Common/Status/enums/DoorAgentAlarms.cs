﻿
namespace Pacom.Peripheral.Common.Status
{
    public enum DoorAlarms
    {
        None,
        Ajar,
        Forced,
    }
}
