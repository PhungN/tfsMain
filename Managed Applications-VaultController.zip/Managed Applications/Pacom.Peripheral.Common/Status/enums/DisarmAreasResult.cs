﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    public enum DisarmAreasResult
    {
        /// <summary>
        /// No areas have been disarmed
        /// </summary>
        NoActionPerformed = 0,
        /// <summary>
        /// No areas have been disarmed as the areas are in the Armed schedule mode and the user doesn't have the outside hours permission
        /// </summary>
        NoActionPerformedDueToInsufficientPermissions = 1,
        /// <summary>
        /// All requested areas have been disarmed
        /// </summary>
        AreasDisarmed = 2,
        /// <summary>
        /// Some areas have been disarmed but others have failed as the areas are in the Armed schedule mode and the user doesn't have the outside hours permission
        /// </summary>
        AreasDisarmedWithSomeFailingDueToInsufficientPermissions = 3,
   }
}
