﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    public enum ExpansionCardOfflineStatusType
    {
        /// <summary>
        /// The device is online
        /// </summary>
        Online,

        /// <summary>
        /// The device is offline
        /// </summary>
        Offline,

        /// <summary>
        /// The device is offline however alarm will be sent with delay
        /// </summary>
        SuspectedOffline,
    }
}
