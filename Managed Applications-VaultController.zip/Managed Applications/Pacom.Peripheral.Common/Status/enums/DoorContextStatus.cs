﻿
namespace Pacom.Peripheral.Common.Status
{
    public enum DoorContextStatus
    {
        None,
        AccessGranted,
        Ajar,
        Alarm,
        Forced,
        Isolated,
        Deisolated,
    }
}
