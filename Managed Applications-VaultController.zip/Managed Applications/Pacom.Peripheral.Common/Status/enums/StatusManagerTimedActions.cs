﻿namespace Pacom.Peripheral.Common.Status
{
    public enum StatusManagerTimedActions
    {
        DeisolateInputs = 1,
        DeisolateOutputs = 2,
        ActivateOutputs = 3,
        DeactivateOutputs = 4,
        RestoreReaderModes = 5,
        DeisolateDoors = 6,
        DeisolateDevices = 7,
        WarnTestMode = 8,
        ExitTestMode = 9,
        RestoreInterlockGroup = 10,
    }
}
