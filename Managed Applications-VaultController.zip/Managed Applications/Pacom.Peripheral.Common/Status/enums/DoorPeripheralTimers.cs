﻿
namespace Pacom.Peripheral.Common.Status
{
    public enum DoorPeripheralTimers
    {
        None,
        StrikeInProgress,
        AccessDeniedInProgress,
    }
}
