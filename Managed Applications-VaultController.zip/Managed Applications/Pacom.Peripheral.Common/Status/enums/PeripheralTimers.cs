﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Door / Reader peripheral timers: Accept / Denied Led & Buzzer
    /// </summary>
    public enum PeripheralTimers
    {
        None = 0,
        AcceptLedInProgress = 1,
        DeniedLedInProgress = 2,
    }
}
