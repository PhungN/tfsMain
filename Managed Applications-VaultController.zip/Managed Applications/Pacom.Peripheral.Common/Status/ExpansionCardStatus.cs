﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Events.EventsCommon.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Events.EventsCommon;
using Pacom.Core.Contracts.Status;

namespace Pacom.Peripheral.Common.Status
{
    public class ExpansionCardStatus : StatusBase<ExpansionCardStatusList>
    {
        /// <summary>
        /// Expansion Card Online / Offline
        /// </summary>
        private bool online = false;
        protected bool maskedOnline = true;

        private ExpansionCardOfflineStatusType offlineType = ExpansionCardOfflineStatusType.SuspectedOffline;

        /// <summary>
        /// Expansion Card fuse failed
        /// </summary>
        private bool fuseFailed = false;
        private bool maskedFuseFailed = false;

        protected string serialNumber = DefaultSerialNumber;
        private string bootloaderVersion = DefaultBootloaderVersion;
        private string firmwareVersion = DefaultFirmwareVersion;

        public ExpansionCardStatus(ConfigurationBase configuration, ExpansionCardStatusList parent, ExpansionCardStatusStorage previousStatus) :
            base(configuration, parent)
        {
            SupportedIsolateFlags = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.FuseFail;
            DeviceConfigurationBase config = configuration as DeviceConfigurationBase;
            if (config != null)
                hardwareType = config.HardwareType;

            if (previousStatus == null || this.Enabled == false)
                return;

            this.isolatedAlarms = previousStatus.IsolatedAlarms;
            this.latchedAlarms = previousStatus.LatchedAlarms;
            this.deviceSubstitution = previousStatus.LatchedAlarms.Has(EventSourceLatchOrIsolateType.DeviceSubstitution);
            this.VerifyMaskedAlarms();
        }

        public override StatusItemType ItemType
        {
            get { return StatusItemType.ExpansionCardStatus; }
        }

        private HardwareType hardwareType = HardwareType.Undefined;

        /// <summary>
        /// Get the device hardware type.
        /// </summary>
        public HardwareType HardwareType
        {
            get { return hardwareType; }
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            ExpansionCardStatusStorage statusStorage = new ExpansionCardStatusStorage();
            if (statusStorage != null)
            {
                InitializeStatusStorage(statusStorage);
            }
            return statusStorage;
        }

        /// <summary>
        /// Initialize the state of status storage instance for all the basic properties
        /// </summary>
        /// <param name="statusStorage">Status Storage instance to initialize</param>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        protected void InitializeStatusStorage(ExpansionCardStatusStorage statusStorage)
        {
            if (statusStorage == null)
                return;
            statusStorage.LogicalId = LogicalId;
            statusStorage.ParentDeviceId = ParentDeviceId;
            statusStorage.IsolatedAlarms = IsolatedAlarms;
            statusStorage.LatchedAlarms = LatchedAlarms;
        }

        /// <summary>
        /// Initialize the state of status storage instance for all the basic properties
        /// </summary>
        /// <param name="statusStorage">Status Storage instance to initialize</param>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        protected virtual void InitializeEventState(DeviceEventState deviceState)
        {
            if (deviceState == null)
                return;
            deviceState.Id = LogicalId;
            deviceState.Offline = MaskedOnline == false;
            deviceState.Tamper = false;
            deviceState.Isolate = IsolatedAlarms;
            deviceState.Latch = LatchedAlarms;
            deviceState.Substitution = CurrentAlarms.Has(EventSourceLatchOrIsolateType.DeviceSubstitution);
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            DeviceEventState deviceState = null;
            switch (hardwareType)
            {
                case HardwareType.Pacom8203ExpansionCard:
                    deviceState = new Device8203ExpansionEventState();
                    ((Device8203ExpansionEventState)deviceState).FuseFail = MaskedFuseFailed;
                    break;
                case HardwareType.Pacom8204ExpansionCard:
                    deviceState = new Device8204ExpansionEventState();
                    break;
                case HardwareType.Pacom8205ExpansionCard:
                    deviceState = new Device8205ExpansionEventState();
                    ((Device8205ExpansionEventState)deviceState).FuseFail = MaskedFuseFailed;
                    break;
                case HardwareType.Pacom8207ExpansionCard:
                    deviceState = new Device8207ExpansionEventState();
                    ((Device8207ExpansionEventState)deviceState).FuseFail = MaskedFuseFailed;
                    break;
                case HardwareType.Pacom8208ExpansionCard:
                    deviceState = new Device8208ExpansionEventState();
                    ((Device8208ExpansionEventState)deviceState).FuseFail = MaskedFuseFailed;
                    break;
                case HardwareType.Pacom8209ExpansionCard:
                    deviceState = new Device8209ExpansionEventState();
                    ((Device8209ExpansionEventState)deviceState).SignalFail = SignalFailState.None;
                    break;
            }
            if (deviceState != null)
            {
                InitializeEventState(deviceState);
            }
            return deviceState;
        }

        public DeviceInformation CreateDeviceInformation()
        {
            DeviceInformation deviceInformation = new DeviceInformation();
            if (deviceInformation != null)
            {
                deviceInformation.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                deviceInformation.Id = LogicalId;
                deviceInformation.HardwareType = HardwareType;
                deviceInformation.SerialNumber = SerialNumber;
                deviceInformation.CurrentFirmwareVersion = FirmwareVersion;
                deviceInformation.AvailableFirmwareVersions = new string[1];
                deviceInformation.AvailableFirmwareVersions[0] = deviceInformation.CurrentFirmwareVersion;
                deviceInformation.ActiveFirmwareVersion = 1;
            }
            return deviceInformation;
        }

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            switch (suspectStatusType)
            {
                case EventSourceLatchOrIsolateType.Offline: return ConfigurationManager.Instance.ControllerConfiguration.LatchOfflineAlarms;
                case EventSourceLatchOrIsolateType.FuseFail: return ConfigurationManager.Instance.ControllerConfiguration.LatchFuseFailAlarms;
                case EventSourceLatchOrIsolateType.DeviceSubstitution: return true;
                default: return false;
            }
        }

        /// <summary>
        /// Get the string representation of the alarms for this point in format: [ALARM1 ALARM2 ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        private string alarmsAsString(EventSourceLatchOrIsolateType alarms)
        {
            if (alarms == EventSourceLatchOrIsolateType.None)
                return string.Empty;
            string alarmsAsString = " ";

            foreach (EventSourceLatchOrIsolateType eventSource in EnumHelper.GetValues<EventSourceLatchOrIsolateType>())
            {
                if (eventSource == EventSourceLatchOrIsolateType.None)
                    continue;

                if (alarms.Has(eventSource) == true)
                    alarmsAsString = string.Format("{0}{1} ", alarmsAsString, ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
            }
            return alarmsAsString;
        }

        /// <summary>
        /// Get the string representation of the alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public override string AlarmsAsString
        {
            get { return alarmsAsString(CurrentAlarms); }
        }

        /// <summary>
        /// Get the string representation of the alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public override string IsolatedAlarmsAsString
        {
            get { return alarmsAsString(isolatedAlarms); }
        }

        /// <summary>
        /// Get the string representation of the latched alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public override string LatchedAlarmsAsString
        {
            get { return alarmsAsString(latchedAlarms); }
        }

        /// <summary>
        /// Get alarm description for [alarmType], implemented for devices only, not needed for other status items.
        /// </summary>
        /// <param name="alarmType">Alarm Type: Offline, Tamper, etc.</param>
        /// <returns></returns>
        public override string AlarmDescription(EventSourceLatchOrIsolateType alarmType)
        {
            return ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(alarmType);
        }

        /// <summary>
        /// Get the array of strings representation for the alarms for this point
        /// </summary>
        private string[] alarmsAsStringArray(EventSourceLatchOrIsolateType alarms)
        {
            if (alarms == EventSourceLatchOrIsolateType.None)
                return new string[0];
            List<string> alarmsList = new List<string>();
            foreach (EventSourceLatchOrIsolateType eventSource in EnumHelper.GetValues<EventSourceLatchOrIsolateType>())
            {
                if (eventSource == EventSourceLatchOrIsolateType.None)
                    continue;

                if (alarms.Has(eventSource) == true)
                    alarmsList.Add(ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
            }
            return alarmsList.ToArray();
        }

        /// <summary>
        /// Get the string array representation of the current alarms for this point
        /// </summary>
        public override string[] AlarmsAsStringArray
        {
            get { return alarmsAsStringArray(CurrentAlarms); }
        }

        /// <summary>
        /// Get the string array representation of the isolated alarms for this point
        /// </summary>
        public override string[] IsolatedAlarmsAsStringArray
        {
            get { return alarmsAsStringArray(isolatedAlarms); }
        }

        /// <summary>
        /// Get the string representation of the latched alarms for this point as an array
        /// </summary>
        public override string[] LatchedAlarmsAsStringArray
        {
            get { return alarmsAsStringArray(latchedAlarms); }
        }

        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get
            {
                return latchedAlarms.HasAny(EventSourceLatchOrIsolateType.Offline | 
                                            EventSourceLatchOrIsolateType.FuseFail |
                                            EventSourceLatchOrIsolateType.DeviceSubstitution);
            }
        }

        /// <summary>
        /// Returns the current latch status for this status item instance and the [latchFlagToCheck]
        /// </summary>
        /// <param name="latchFlagToCheck">The status item laarm flag that needs to be checked for latching</param>
        /// <returns>The latch status for this status item.</returns>
        public override EventSourceLatchStatus GetLatchStatusFor(EventSourceLatchOrIsolateType latchFlagToCheck)
        {
            if ((SupportedIsolateFlags & latchFlagToCheck) == EventSourceLatchOrIsolateType.None &&
                 latchFlagToCheck != EventSourceLatchOrIsolateType.DeviceSubstitution)
                return EventSourceLatchStatus.NotLatched;

            if (latchedAlarms.Has(latchFlagToCheck) == false)
                return EventSourceLatchStatus.NotLatched;

            if (latchFlagToCheck == EventSourceLatchOrIsolateType.DeviceSubstitution)
                return EventSourceLatchStatus.ConfiguredToBeLatched;

            if (ConfigurationManager.Instance.ControllerConfiguration.SuspectDeviceActivation == true)
            {
                return SuspectCount >= ConfigurationManager.Instance.ControllerConfiguration.SuspectDeviceActivationCounter ?
                    EventSourceLatchStatus.SuspectBehaviour : EventSourceLatchStatus.ConfiguredToBeLatched;
            }
            else if (LatchAfterFirstAlarm(latchFlagToCheck) == true)
            {
                return EventSourceLatchStatus.ConfiguredToBeLatched;
            }

            // This code possibly will not be executed, but just for consistency we have result set.
            return EventSourceLatchStatus.NotLatched;
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = EventSourceLatchOrIsolateType.None;
                if (maskedOnline == false)
                    flags |= EventSourceLatchOrIsolateType.Offline;
                if (maskedFuseFailed == true)
                    flags |= EventSourceLatchOrIsolateType.FuseFail;
                if (deviceSubstitution == true)
                    flags |= EventSourceLatchOrIsolateType.DeviceSubstitution;
                return flags;
            }
        }

        /// <summary>
        /// Get display name for this expansion card status item instance without any alarms / isolated alarms
        /// </summary>
        /// <returns>Display Name string.</returns>
        public override string DisplayName
        {
            get
            {
                ExpansionCardDeviceConfigurationBase expansionCardConfig = ConfigurationManager.Instance.GetExpansionCardDeviceConfiguration(LogicalId);
                if (expansionCardConfig != null)
                {
                    IExpansionCardConfigurationBase iExpansionCard = expansionCardConfig as IExpansionCardConfigurationBase;
                    string name = "Unknown";
                    if (iExpansionCard != null)
                        name = iExpansionCard.GetName();
                    return string.Format("{0}{1} {2}", ConfigurationManager.Instance.ControllerConfiguration.DevicePrefixText, LogicalId, name);
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Receive new expansion card status
        /// </summary>
        public void SetStatus(Common.ExpansionCardStatus expansionManagerStatus)
        {
            switch (expansionManagerStatus)
            {
                case Common.ExpansionCardStatus.Online:
                    Online = true;
                    FuseFailed = false;
                    break;
                case Common.ExpansionCardStatus.Offline:
                    online = false;
                    offlineType = ExpansionCardOfflineStatusType.SuspectedOffline;
                    notifyExpansionCardSuspectedOffline();
                    break;
                case Common.ExpansionCardStatus.FuseFail:
                    if (online == false)
                        Online = true;
                    FuseFailed = true;
                    break;
                case Common.ExpansionCardStatus.Unknown:
                    online = false;                    
                    offlineType = ExpansionCardOfflineStatusType.SuspectedOffline;
                    FuseFailed = false;
                    break;
            }
        }

        /// <summary>
        /// Get / Set expansion card online / offline status
        /// </summary>
        public bool Online
        {
            get { return online; }
            private set
            {
                if (Enabled == false)
                    return;
                if (offlineType != ExpansionCardOfflineStatusType.SuspectedOffline &&
                    online == true && value == false) // Device is going offline during normal operation
                {
                    online = false;
                    offlineType = ExpansionCardOfflineStatusType.SuspectedOffline;
                    notifyExpansionCardSuspectedOffline();
                }
                else if (online != value)
                {
                    // Send the alarm events                    
                    if (value == true)
                    {
                        online = true;
                        Parent.ExpansionCardOnlineStatusChanged(this);
                        if (offlineType == ExpansionCardOfflineStatusType.SuspectedOffline)
                            maskedOnline = false; // Revert masked status to opposite state
                        MaskedOnline = true;
                        offlineType = ExpansionCardOfflineStatusType.Online;
                        // Pull the expansion card inputs back to status manager when coming online
                        if (StatusManager.Instance.LocalDeviceManager != null)
                        {
                            StatusManager.Instance.LocalDeviceManager.RestoreExpansionCardInputs(this.LogicalId);
                        }
                    }
                    else
                    {
                        online = false;
                        if (offlineType == ExpansionCardOfflineStatusType.SuspectedOffline)
                            maskedOnline = true; // Revert masked status to opposite state
                        MaskedOnline = false;
                        offlineType = ExpansionCardOfflineStatusType.Offline;
                        notifyExpansionInputsSelfTestFail();
                    }                    
                }
                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        /// <summary>
        /// Get / Set masked device online status, send status changed to front-end if required.
        /// </summary>
        public bool MaskedOnline
        {
            get { return maskedOnline; }
            private set
            {
                if (Enabled == false)
                    return;
                if (maskedOnline != value || value == false)
                {
                    bool previousOnline = maskedOnline;
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false &&
                        SuspectPoint == false &&
                        (LatchedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false || value == false))
                    {
                        maskedOnline = value;
                        if (maskedOnline == false)
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.Offline);
                        Parent.TriggerExpansionCardMaskedOnlineStatusChanged(this);
                        if (maskedOnline == false)
                        {
                            ProcessAlarmConfirmation();
                            CheckTerminateArming();
                        }
                        else
                        {
                            CheckStopFailToArmTimer();
                        }
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        /// <summary>
        /// Get / Set expansion card fuse failed status
        /// </summary>
        public bool FuseFailed
        {
            get { return this.fuseFailed; }
            private set
            {
                if (fuseFailed != value)
                {
                    fuseFailed = value;
                    MaskedFuseFailed = fuseFailed;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set masked power supply fuse failed flag
        /// </summary>
        public bool MaskedFuseFailed
        {
            get { return maskedFuseFailed; }
            private set
            {
                if (Enabled == false)
                    return;
                if (maskedFuseFailed != value || value == true)
                {
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.FuseFail) == false &&
                        SuspectPoint == false &&
                        (LatchedAlarms.Has(EventSourceLatchOrIsolateType.FuseFail) == false || value == true))
                    {
                        maskedFuseFailed = value;
                        if (maskedFuseFailed == true)
                        {
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.FuseFail);
                            CheckTerminateArming();
                        }
                        else
                        {
                            CheckStopFailToArmTimer();
                        }
                        Parent.TriggerFuseFailed(this, maskedFuseFailed);
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        /// <summary>
        /// When a device alarms is received check if there is any area arming task that needs to be terimated
        /// </summary>
        public void CheckTerminateArming()
        {
            foreach (var area in StatusManager.Instance.Areas.Items)
            {
                if (area.Enabled == true)
                    area.CheckTerminateArming();
            }
        }

        /// <summary>
        /// Stop the Fail to Arm timer if no more alarms for an area (area and device alarms)
        /// </summary>
        public void CheckStopFailToArmTimer()
        {
            bool anyDeviceAlarms = StatusManager.Instance.AnyDeviceAlarms;
            if (anyDeviceAlarms == false)
            {
                foreach (var area in StatusManager.Instance.Areas.Items)
                {
                    if (area.Enabled == true && area.HasArmedModeAlarms == false)
                        area.StopFailToArmTimer();
                }
            }
        }

        /// <summary>
        /// Handle alarm sequential confirmation for all enabled and ARMED areas 
        /// </summary>
        protected void ProcessAlarmConfirmation()
        {
            if (ConfigurationManager.Instance.AlarmConfirmationTimeEnabled == true)
            {
                foreach (var area in StatusManager.Instance.Areas.Items)
                {
                    if (area.Enabled == false || area.EnableAlarmConfirmationTime == false)
                        continue;
                    area.ProcessAlarmConfirmation(this);
                }
            }
        }

        /// <summary>
        /// Get the ConfirmedType for current alarm based on area mode and the previous unconfirmed alarm if required.
        /// </summary>
        /// <param name="unconfirmedAlarmSource">The source of an existing unconfirmed alarm, received before the current alarm.</param>
        /// <param name="areaSource">Area from which the alarm has originated</param>
        /// <returns>None, Unconfirmed or Confirmed.</returns>
        public override ConfirmedType GetConfirmedAlarmType(IStatusItem unconfirmedAlarmSource, IStatusItem areaSource)
        {
            if (areaSource == null)
                return ConfirmedType.None;

            AreaStatus areaStatus = areaSource as AreaStatus;
            if (areaStatus == null || (areaStatus.Mode == AreaScheduleLevel.Disarmed && CurrentAlarms.Has(EventSourceLatchOrIsolateType.Offline) == true))
            {
                // BS 8243 Annex H.3.1: A confirmed alarm will not be notified when a failure of communication to multiple devices on 
                //                      a data bus which cannot be identified as a fault (Device Offline), occurs when the system is 
                //                      in un-set state (area is Disarmed).
                return ConfirmedType.None;
            }

            return ConfirmedType.Confirmed;
        }

        /// <summary>
        /// It is time to notify the alarm manager about the device being in offline state for too long
        /// </summary>
        internal void NotifyExpansionCardOffline()
        {
            if (online == false)
            {
                // Bring suspected offline to online. Make it first online over the underlining property value.                
                online = true;
                if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false &&
                    LatchedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false)
                {
                    maskedOnline = true;
                }
                // Make the offline alarm go out.
                offlineType = ExpansionCardOfflineStatusType.SuspectedOffline;
                Online = false;
                notifyExpansionInputsSelfTestFail();
            }
        }

        /// <summary>
        /// Change all inputs for an offline device to Self Test Fail / Fault (see EN 50131-1 claus 8.8.4.1(b) and Table 20)
        /// </summary>
        private void notifyExpansionInputsSelfTestFail()
        {
            ExpansionCardDeviceConfigurationBase expansionCardConfig = ConfigurationManager.Instance.GetExpansionCardDeviceConfiguration(this.LogicalId);
            if (expansionCardConfig != null && expansionCardConfig.CardType == ExpansionCardType.Pacom8204InputCard)
            {
                int[] deviceInputs = StatusManager.Instance.Inputs.GetInputsForExpansionCard(this.LogicalId);
                foreach (int logicalInputId in deviceInputs)
                {
                    InputStatus inputStatus = StatusManager.Instance.Inputs[logicalInputId];
                    if (inputStatus != null)
                    {
                        inputStatus.UnmaskedStatus = Common.InputStatus.SelfTestFail;
                    }
                }
            }
        }

        private void notifyExpansionCardSuspectedOffline()
        {
            Parent.TriggerExpansionSuspectedOffline(this);
        }

        /// <summary>
        /// Get / Set the expansion card current firmware version
        /// </summary>
        public string FirmwareVersion
        {
            get { return firmwareVersion; }
            set
            {
                if (Enabled == false)
                    return;
                if (firmwareVersion.Equals(value) == false)
                {                    
                    firmwareVersion = value.ReplaceAnyNonASCIICharacters();
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set the expansion card bootloader version
        /// </summary>
        public string BootloaderVersion
        {
            get { return bootloaderVersion; }
            set
            {
                if (Enabled == false)
                    return;
                if (bootloaderVersion.Equals(value) == false)
                {
                    bootloaderVersion = value;
                    StatusManager.Instance.RequestStatusToStorage();
            }
        }
        }

        /// <summary>
        /// Get / Set the expansion card serial number
        /// </summary>
        public string SerialNumber
        {
            get { return serialNumber; }
            set
            {
                if (Enabled == false)
                    return;
                if (serialNumber.Equals(value) == false)
                {
                    if (string.Compare(serialNumber, DefaultSerialNumber, true) != 0)
                    {
                        // The previous serial number is not default one it must be a substituted device
                        if (SuspectPoint == false)
                        {
                            // Latch Device Substitution Alarm
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.DeviceSubstitution);
                            deviceSubstitution = true;
                            Parent.TriggerExpansionCardSubstitution(this, false);
                        }
                    }  
                    serialNumber = value.ReplaceAnyNonASCIICharacters();
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        private bool deviceSubstitution = false;
        /// <summary>
        /// Restore device substitution alarm
        /// </summary>
        public void DeviceSubstitutionRestore()
        {
            deviceSubstitution = false;
            // The previous serial number is not default one it must be a substituted device
            Parent.TriggerExpansionCardSubstitution(this, true);
        }

        /// <summary>
        /// Get the state of device Isolated flag
        /// </summary>
        public bool Isolated
        {
            get { return isolatedAlarms != EventSourceLatchOrIsolateType.None; }
        }

        /// <summary>
        /// Set the state of device IsolatedOptions flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="value">New isolated options. If value = EventSourceLatchOrIsolateType.None -> Deisolate all.
        /// If value = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.FuseFail -> Isolate all or any.
        /// When de-isolating if any of the device inputs is in alarm the alarm will be queued into AlarmManager.
        /// </param>
        /// <returns>True if the command was successfully executed</returns>
        public virtual bool SetIsolated(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType value)
        {
            if (Enabled == false)
                return false;
            // Mask-out all flags this device does not support
            value &= SupportedIsolateFlags;

            bool pendingTimedActionRemoved = StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.DeisolateDevices, LogicalId);
            if (isolatedAlarms != value)
            {
                Isolating = true;
                // Offline - Isolate/de-isolate 
                SetIsolated(value, EventSourceLatchOrIsolateType.Offline, true, online);
                // Fuse Failed - Isolate/de-isolate 
                SetIsolated(value, EventSourceLatchOrIsolateType.FuseFail, false, fuseFailed);
                Isolating = false;
                Parent.TriggerChangedIsolatedStatus(this, value, isolatedAlarms, userAuditInfo);
                StatusManager.Instance.RequestStatusToStorage();
                return true;
            }
            return pendingTimedActionRemoved;
        }

        /// <summary>
        /// Set masked status for [optionToCheck] to [newValue]
        /// </summary>
        /// <param name="optionToCheck">Option to chec, e.g.: Offline, FuseFail, etc.</param>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(EventSourceLatchOrIsolateType optionToCheck, bool newValue)
        {
            bool result = true;
            switch (optionToCheck)
            {
                case EventSourceLatchOrIsolateType.Offline:
                    MaskedOnline = newValue;
                    break;
                case EventSourceLatchOrIsolateType.FuseFail:
                    MaskedFuseFailed = newValue;
                    break;
                default:
                    result = false;
                    break;
            }
            return result;
        }

        /// <summary>
        /// Isolate expansion card.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Isolate(UserAuditInfo userAuditInfo)
        {
            SetIsolated(userAuditInfo, SupportedIsolateFlags);
        }

        /// <summary>
        /// Deisolate expansion card.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Deisolate(UserAuditInfo userAuditInfo)
        {
            SetIsolated(userAuditInfo, EventSourceLatchOrIsolateType.None);
        }

        /// <summary>
        /// Isolate device / controller / alarm/s (E.g.: for an expansion card we can isolate Offline / FuseFail or both of them).
        /// Isolated alarms will not be de-isolated. This function appends the [options] to the already isolated alarms. Used when
        /// isolating alarms from the alarm keypad.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="options">Alarm types to isolate: Offline / FuseFail.</param>
        public override void Isolate(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options)
        {
            options |= IsolatedAlarms;
            SetIsolated(userAuditInfo, options);
        }

        /// <summary>
        /// Deisolate device / controller / input / output / etc. specific alarm or
        /// all alarms (E.g.: for an expansion card we can deisolate Offline / FuseFail or both of them).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="options">Alarm types to deisolate: Offline / FuseFail.</param>
        public override void Deisolate(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options)
        {
            SetIsolated(userAuditInfo, options);
        }

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        public override bool CanIsolate(UserAccessLevel level)
        {
            if (CurrentAlarms == EventSourceLatchOrIsolateType.DeviceSubstitution)
                return false;

            return level == UserAccessLevel.AccessLevel3;
        }

        /// <summary>
        /// Set isolated flag for any expansion card point for a specified duration.
        /// </summary>
        /// <param name="value">Not Used.</param>
        /// <param name="bitField">BitField options to isolate/deisolate.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="durationInSeconds">The duration for which the point will be isolated, 0 means that the point will be isolated idefinitely</param>
        /// <returns>True if the point's isolated state was successfully changed, False otherwise.</returns>
        public override bool SetIsolated(bool value, EventSourceLatchOrIsolateType bitField, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            bool result = SetIsolated(userAuditInfo, bitField);
            if (result == true && bitField != EventSourceLatchOrIsolateType.None && durationInSeconds > 0)
            {
                // A duration is only supported for the 'isolate for a duration' case.
                StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.DeisolateDevices, LogicalId, userAuditInfo, durationInSeconds);
            }
            return result;
        }

        /// <summary>
        /// Unlatch input. Keep MaskedStatus alarm state if UnmaskedStatus is not Secure.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        /// <returns>True if input was unlatched, False otherwise.</returns>
        public override bool Unlatch(UserAuditInfo userAuditInfo)
        {
            if (Enabled == false)
                return false;

            if (IsCurrentlyLatched == true)
            {
                ResetIsCurrentlyLatched();
                RestoreAfterUnlatch();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Unlatch device specified alarms if latched. Keep MaskedStatus alarm state if UnmaskedStatus is not Secure.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        /// <param name="options">Latched alarms to unlatch (restore)</param>
        /// <returns>True if the point has been unlatched</returns>
        public override bool Unlatch(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options)
        {
            if (Enabled == false)
                return false;

            if (latchedAlarms.HasAny(options) == true)
            {
                ResetIsCurrentlyLatched(options);
                RestoreAfterUnlatch();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Restore masked online, fuse failed, etc. status if required after unlatching the expansion card alarms. Restore only if the
        /// current instantaneous status is Secure (device online, fuse not failed, etc.).
        /// </summary>
        protected virtual void RestoreAfterUnlatch()
        {
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false && Online == true)
                MaskedOnline = true;
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.FuseFail) == false && FuseFailed == false)
                MaskedFuseFailed = false;
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.DeviceSubstitution) == false && deviceSubstitution == true)
                DeviceSubstitutionRestore();
        }

        /// <summary>
        /// Check masked alarms when we restore status from previous stored state
        /// </summary>
        /// <param name="previousStatus">Previous stored status. Not Used.</param>
        /// <param name="controllerRestarted">Controller was restarted. Not Used.</param>
        protected virtual void VerifyMaskedAlarms()
        {
            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.FuseFail))
            {
                maskedFuseFailed = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.FuseFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.FuseFail))
            {
                maskedFuseFailed = true;
            }

            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.Offline))
            {
                maskedOnline = true;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.Offline);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.Offline))
            {
                maskedOnline = false;
            }
        }

        public ExpansionCardOfflineStatusType OfflineType
        {
            get
            {
                return offlineType;
            }
        }

        public override string ToString()
        {
            return String.Format("Expansion Status [{0}]", this.LogicalId);
        }
    }
}
