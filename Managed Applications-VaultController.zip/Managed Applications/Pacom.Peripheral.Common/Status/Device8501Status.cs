﻿using Pacom.Core.Contracts;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Events.EventsCommon;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    public class Device8501Status : DeviceLoopDeviceStatus, IDevicePowerSupplyStatus
    {
        /// <summary>
        /// Power Supply status
        /// </summary>
        private PowerFailState powerState = PowerFailState.None;
        private PowerFailState maskedPowerState = PowerFailState.None;

        /// <summary>
        /// Battery status
        /// </summary>
        private BatteryFailState batteryState = BatteryFailState.None;
        private BatteryFailState maskedBatteryState = BatteryFailState.None;

        /// <summary>
        /// Battery charger status
        /// </summary>
        private bool batteryChargerFailed = false;
        private bool maskedBatteryChargerFailed = false;

        private const EventSourceLatchOrIsolateType powerSupplyAlarmFlags = EventSourceLatchOrIsolateType.PowerFail | EventSourceLatchOrIsolateType.BatteryFail | EventSourceLatchOrIsolateType.BatteryChargerFail;

        private readonly object sync = new object();

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            switch (suspectStatusType)
            {
                case EventSourceLatchOrIsolateType.Offline: return ConfigurationManager.Instance.ControllerConfiguration.LatchOfflineAlarms;
                case EventSourceLatchOrIsolateType.Tamper: return ConfigurationManager.Instance.ControllerConfiguration.LatchTamperAlarms;
                case EventSourceLatchOrIsolateType.PowerFail: return ConfigurationManager.Instance.ControllerConfiguration.LatchPrimaryPowerSourceAlarms;
                case EventSourceLatchOrIsolateType.BatteryChargerFail: return ConfigurationManager.Instance.ControllerConfiguration.LatchBatteryChargerFailAlarms;
                case EventSourceLatchOrIsolateType.BatteryFail: return ConfigurationManager.Instance.ControllerConfiguration.LatchSecondaryPowerSourceAlarms;
                case EventSourceLatchOrIsolateType.DeviceSubstitution: return true;
                default: return false;
            }
        }

        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get { return base.IsCurrentlyLatched || latchedAlarms.HasAny(powerSupplyAlarmFlags); }
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = base.CurrentAlarms;
                if (maskedPowerState != PowerFailState.None)
                    flags |= EventSourceLatchOrIsolateType.PowerFail;
                if (maskedBatteryState != BatteryFailState.None)
                    flags |= EventSourceLatchOrIsolateType.BatteryFail;
                if (maskedBatteryChargerFailed == true)
                    flags |= EventSourceLatchOrIsolateType.BatteryChargerFail;
                return flags;
            }
        }

        public PowerFailState PowerState
        {
            get { return powerState; }
            set
            {
                if (Enabled == false)
                    return;
                if (powerState != value)
                {
                    powerState = value;
                    SetMaskedPowerState(powerState, false);
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        public PowerFailState MaskedPowerState
        {
            get { return maskedPowerState; }
        }

        public void SetMaskedPowerState(PowerFailState value, bool acFailDelayExpired)
        {
            if (Enabled == false)
                return;

            lock (sync)
            {
                if (value != PowerFailState.Fail)
                    Parent.StopACFailDelay(LogicalId);

                if (maskedPowerState != value || value != PowerFailState.None)
                {
                    // Return immediately if all alarms are isolate, if the point has been flagged as suspect or
                    // if the power supply returns to a no alarm state when all alarm types are latched.
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) || SuspectPoint ||
                        (value == PowerFailState.None && LatchedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail)))
                    {
                        return;
                    }

                    PowerFailState previousMaskedState = maskedPowerState;

                    if (value == PowerFailState.Fail && acFailDelayExpired == false && IsDelayedACFail == true)
                    {
                        // If AC Fail value has changed we can't update the masked value yet if there is an AC Fail delay and it hasn't expired yet
                        Parent.StartACFailDelay(LogicalId);
                    }
                    else
                    {
                        maskedPowerState = value;
                        SendPowerSupplyAlarm(maskedPowerState, previousMaskedState);
                    }
                }
            }
        }

        public BatteryFailState BatteryState
        {
            get { return batteryState; }
            set
            {
                if (Enabled == false)
                    return;
                if (batteryState != value)
                {
                    batteryState = value;
                    MaskedBatteryState = batteryState;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        public BatteryFailState MaskedBatteryState
        {
            get { return maskedBatteryState; }
            set
            {
                if (Enabled == false)
                    return;

                lock (sync)
                {
                    if (maskedBatteryState != value || value != BatteryFailState.None)
                    {
                        // Return immediately if all alarms are isolate, if the point has been flagged as suspect or
                        // if the power supply returns to a no alarm state when all alarm types are latched.
                        if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail) || SuspectPoint ||
                            (value == BatteryFailState.None && LatchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail)))
                        {
                            return;
                        }

                        BatteryFailState previousMaskedState = maskedBatteryState;
                        maskedBatteryState = value;
                        SendPowerSupplyAlarm(maskedBatteryState, previousMaskedState);
                    }
                }
            }
        }

        public bool BatteryChargerFailed
        {
            get { return batteryChargerFailed; }
            set
            {
                if (Enabled == false)
                    return;
                if (batteryChargerFailed != value)
                {
                    batteryChargerFailed = value;
                    MaskedBatteryChargerFailed = batteryChargerFailed;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        public bool MaskedBatteryChargerFailed
        {
            get { return maskedBatteryChargerFailed; }
            set
            {
                if (Enabled == false)
                    return;

                lock (sync)
                {
                    if (maskedBatteryChargerFailed != value || value == true)
                    {
                        // Return immediately if all alarms are isolate, if the point has been flagged as suspect or
                        // if the power supply returns to a no alarm state when all alarm types are latched.
                        if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail) || SuspectPoint ||
                            (value == false && LatchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail)))
                        {
                            return;
                        }

                        bool previousMaskedBatteryChargerFailed = maskedBatteryChargerFailed;
                        maskedBatteryChargerFailed = value;
                        SendPowerSupplyAlarm(maskedBatteryChargerFailed, previousMaskedBatteryChargerFailed);
                    }
                }
            }
        }

        public Device8501Status(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus) :
            base(configuration, parent, previousStatus)
        {
            SupportedIsolateFlags |= EventSourceLatchOrIsolateType.BatteryFail | EventSourceLatchOrIsolateType.PowerFail | EventSourceLatchOrIsolateType.BatteryChargerFail;

            if (previousStatus == null || this.Enabled == false)
                return;

            if (this.HardwareType == previousStatus.HardwareType)
            {
                this.isolatedAlarms = previousStatus.IsolatedAlarms;
                this.latchedAlarms = previousStatus.LatchedAlarms;
                VerifyMaskedAlarms();
            }
        }

        /// <summary>
        /// Set the state of device IsolatedAlarms flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="value">New isolated options. If value = EventSourceLatchOrIsolateType.None -> Deisolate all.
        /// If value = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.Tamper | EventSourceLatchOrIsolateType.InternalBatteryFail -> Isolate all or any.
        /// When de-isolating if any of the device inputs is in alarm the alarm will be queued into AlarmManager.
        /// </param>
        /// <returns>True if the command was successfully executed</returns>
        public override bool SetIsolated(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType value)
        {
            if (base.SetIsolated(userAuditInfo, value) == false)
                return false;

            // Mask-out all flags this device does not support
            value &= SupportedIsolateFlags;
            if (value != isolatedAlarms)
            {
                SetIsolated(value, EventSourceLatchOrIsolateType.PowerFail, powerState);
                SetIsolated(value, EventSourceLatchOrIsolateType.BatteryFail, batteryState);
                SetIsolated(value, EventSourceLatchOrIsolateType.BatteryChargerFail, false, batteryChargerFailed);
                StatusManager.Instance.RequestStatusToStorage();
            }
            return true;
        }

        /// <summary>
        /// Set masked status for PowerFailState
        /// </summary>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(PowerFailState newValue)
        {
            SetMaskedPowerState(newValue, true);
            return true;
        }

        /// <summary>
        /// Set masked status for BatteryFailState
        /// </summary>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(BatteryFailState newValue)
        {
            MaskedBatteryState = newValue;
            return true;
        }

        /// <summary>
        /// Set masked status for [optionToCheck] to [newValue]
        /// </summary>
        /// <param name="optionToCheck">Option to check, e.g.: Offline, Tamper, InternalBatteryFail, ControllerConnection1Offline, ControllerConnection2Offline, etc.</param>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(EventSourceLatchOrIsolateType optionToCheck, bool newValue)
        {
            if (base.SetMaskedStatus(optionToCheck, newValue))
                return true;
            bool result = true;
            switch (optionToCheck)
            {
                case EventSourceLatchOrIsolateType.BatteryChargerFail:
                    MaskedBatteryChargerFailed = newValue;
                    break;
                default:
                    result = false;
                    break;
            }
            return result;
        }

        /// <summary>
        /// Restore masked online, device tamper, etc. status if required after unlatching the device alarms. Restore only if the
        /// current instantaneous status is Secure (device online, tamper secure, etc.).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        protected override void RestoreAfterUnlatch(UserAuditInfo userAuditInfo)
        {
            base.RestoreAfterUnlatch(userAuditInfo);
            if (latchedAlarms.Has(powerSupplyAlarmFlags) == true)
                return;

            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) == false && PowerState == PowerFailState.None)
                SetMaskedPowerState(PowerState, true);
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail) == false && BatteryState == BatteryFailState.None)
                MaskedBatteryState = BatteryState;
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail) == false && BatteryChargerFailed == false)
                MaskedBatteryChargerFailed = BatteryChargerFailed;
        }

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        public override bool CanIsolate(UserAccessLevel level)
        {
            if (CurrentAlarms == EventSourceLatchOrIsolateType.DeviceSubstitution)
                return false;

            if (level == UserAccessLevel.AccessLevel3)
                return true;

            if (CurrentAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) == true)
                return true;
            return false;
        }

        /// <summary>
        /// True if this status item can be de-isolated at the specifed access level
        /// </summary>
        public override bool CanDeisolate(UserAccessLevel level)
        {
            if (level == UserAccessLevel.AccessLevel3)
                return true;

            if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) == true)
                return true;
            return false;
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            DeviceStatusStorage statusStorage = new DeviceStatusStorage();
            if (statusStorage != null)
            {
                InitializeStatusStorage(statusStorage);
            }
            return statusStorage;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            Device8501DCEventState deviceState = new Device8501DCEventState();
            InitializeEventState(deviceState);
            deviceState.PowerFail = MaskedPowerState;
            deviceState.BatteryFail = MaskedBatteryState;
            deviceState.BatteryChargerFail = MaskedBatteryChargerFailed;
            return deviceState;
        }

        /// <summary>
        /// Check masked alarms when we restore status from previous stored state
        /// </summary>
        protected override void VerifyMaskedAlarms()
        {
            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail))
            {
                maskedPowerState = PowerFailState.None;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.PowerFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail))
            {
                if (maskedPowerState == PowerFailState.None)
                    maskedPowerState = PowerFailState.Fail;
            }

            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail))
            {
                maskedBatteryState = BatteryFailState.None;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.BatteryFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail))
            {
                if (maskedBatteryState == BatteryFailState.None)
                    maskedBatteryState = BatteryFailState.Fail;
            }

            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail))
            {
                maskedBatteryChargerFailed = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.BatteryChargerFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail))
            {
                maskedBatteryChargerFailed = true;
            }
        }
    }
}
