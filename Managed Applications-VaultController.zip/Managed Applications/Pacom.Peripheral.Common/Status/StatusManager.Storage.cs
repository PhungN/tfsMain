﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Threading;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// This class provides a central state repository for devices, areas, doors, inputs,
    /// outputs, presence zones and reads. This partial part of the class is responsible for persisting this information.
    /// </summary>
    public partial class StatusManager
    {
        private StreamingContext context = new StreamingContext();
        private ITypeLookup typesList = GetListOfTypes();
        private Asn1DerFormatter asn1Serializer = null;
        private Thread statusStorageThread = null;
        private bool terminateStatusStorageProcessingThread = false;
        private readonly AutoResetEvent requestStatusStoreForProcessing = new AutoResetEvent(false);
        private bool statusStoreProcessing = false;
        private readonly object statusStoreProcessingSync = new object();
        private bool statusStoreClosed = false;
        private bool forceStatusToStore = false;

        #region Status Storage

        private void startStatusStorageThread()
        {
            if (statusStorageThread != null)
                stopStatusStorageThread();

            terminateStatusStorageProcessingThread = false;
            statusStorageThread = new Thread(new ThreadStart(statusStorageProcessingThreadMethod));
            statusStorageThread.Name = "Status Storage Processing Thread";
            statusStorageThread.IsBackground = true;
            statusStorageThread.Priority = ThreadPriority.Lowest;
            statusStorageThread.Start(); 
        }

        private void stopStatusStorageThread()
        {
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
            {
                return "Stopping status storage.";
            });
#endif
            terminateStatusStorageProcessingThread = true;
            requestStatusStoreForProcessing.Set();
            try
            {
                if (statusStorageThread != null)
                    statusStorageThread.JoinOrRestart(20000);
                statusStorageThread = null;
            }
            catch
            {
            }
        }

        private const int statusStorageProcessingWait = 10;
        private const int maxWaitForProcessing = 10;

        private void statusStorageProcessingThreadMethod()
        {
            try
            {
                while (true)
                {
                    if (forceStatusToStore == false)
                    {
                        if (disposing == true || disposed == true || terminateStatusStorageProcessingThread == true)
                            break;
                        requestStatusStoreForProcessing.WaitOne();
                        if (forceStatusToStore == false)
                        {
                            if (disposing == true || disposed == true || terminateStatusStorageProcessingThread == true)
                                break;

                            // Wait here for number of seconds before start saving the status
                            int count = 0;
                            int skipCount = 0;
                            while (count < statusStorageProcessingWait)
                            {
                                if (skipCount < maxWaitForProcessing)
                                {
                                    if (requestStatusStoreForProcessing.WaitOne(1000, false) == true)
                                    {
                                        // Status save requests are still coming. Postpone saving.
                                        count -= 1;
                                        skipCount++;
                                        if (count < 0)
                                            count = 0;
                                    }
                                }
                                else
                                {
                                    Thread.Sleep(1000);
                                }

                                if (forceStatusToStore == true || terminateStatusStorageProcessingThread == true || disposing == true || disposed == true)
                                    break;

                                count++;
                            }
                        }
                    }

                    saveStatusToStorage(false);
                    forceStatusToStore = false;
                }
            }            
            catch
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Status storage thread has been terminated.");
                });
            }
            finally
            {
                statusStorageThread = null;
            }
        }

        /// <summary>
        /// Get the list of types from assembly
        /// </summary>
        /// <returns>Hashed list of types</returns>
        public static HashTypeLookup GetListOfTypes()
        {
            HashTypeLookup lookup = new HashTypeLookup(new List<Assembly>() { });
            lookup.AddType(typeof(Common.Status.StatusStorageBase));
            lookup.AddType(typeof(Common.Status.StatusStorageConfigurationBase));            
            lookup.AddType(typeof(Common.Status.AreaStatusStorage));
            lookup.AddType(typeof(Common.Status.ControllerStatusStorage));
            lookup.AddType(typeof(Common.Status.DoorStatusStorage));
            lookup.AddType(typeof(Common.Status.ExpansionCardStatusStorage));
            lookup.AddType(typeof(Common.Status.GprsExpansionCardStatusStorage));
            lookup.AddType(typeof(Common.Status.InputStatusStorage));
            lookup.AddType(typeof(Common.Status.OutputStatusStorage));
            lookup.AddType(typeof(Common.Status.ReaderStatusStorage));
            lookup.AddType(typeof(Common.Status.DeviceStatusStorageBase));
            lookup.AddType(typeof(Common.Status.DeviceStatusStorage));
            lookup.AddType(typeof(Common.Status.TimedActionStorage));
            lookup.AddType(typeof(Common.Status.ConnectionEntryState));
            lookup.AddType(typeof(Common.Status.ElevatorStatusStorage));
            lookup.AddType(typeof(Common.TestedInputDetailsInternal));
            lookup.AddType(typeof(Common.ConnectionType));
            lookup.AddType(typeof(Pacom.Core.Contracts.HardwareType));
            lookup.AddType(typeof(Pacom.Configuration.ConfigurationCommon.AreaScheduleLevel));
            lookup.AddType(typeof(Common.AreaModeUserForcedType));
            lookup.AddType(typeof(Pacom.Events.EventsCommon.PowerFailState));
            lookup.AddType(typeof(Pacom.Events.EventsCommon.BatteryFailState));
            lookup.AddType(typeof(Common.InputStatus));
            lookup.AddType(typeof(Common.ExpansionCardStatus));
            lookup.AddType(typeof(Common.OutputState));
            lookup.AddType(typeof(Pacom.Configuration.ConfigurationCommon.Reader8003ScheduleLevel));
            lookup.AddType(typeof(Common.ReaderModeForcedType));
            lookup.AddType(typeof(Common.GprsNetworkRegistration));
            lookup.AddType(typeof(Common.GprsNetworkSignalStrength));
            lookup.AddType(typeof(Common.Status.InovonicsDeviceStatusStorage));
            lookup.AddType(typeof(Common.Status.InovonicsReceiverStatusStorage));
            lookup.AddType(typeof(Common.Status.InovonicsRepeaterStatusStorage));
            lookup.AddType(typeof(Common.Status.InovonicsSecurityDeviceStatusStorage));
            lookup.AddType(typeof(Common.Status.InterlockGroupStatusStorage));
            return lookup;
        }

        /// <summary>
        /// Temp code to fill the status storage area.
        /// </summary>
        private void saveStatusToStorage(bool controllerRestarting)
        {
            if (statusStoreClosed == true)
                return;

            // The last status will be saved when controller is restarting
            if (controllerRestarting == true)
                statusStoreClosed = true;

            lock (statusStoreProcessingSync)
            {
                if (statusStoreProcessing == false)
                    statusStoreProcessing = true;
                else
                    return;
            }
            try
            {                
                try
                {
                    using (MemoryStream statusStorage = new MemoryStream())
                    {
                        controllerStatus.Persist(asn1Serializer, statusStorage);
                        areas.Persist(asn1Serializer, statusStorage);
                        devices.Persist(asn1Serializer, statusStorage);
                        doors.Persist(asn1Serializer, statusStorage);
                        expansionCards.Persist(asn1Serializer, statusStorage);
                        inputs.Persist(asn1Serializer, statusStorage);
                        outputs.Persist(asn1Serializer, statusStorage);
                        elevators.Persist(asn1Serializer, statusStorage);
                        readers.Persist(asn1Serializer, statusStorage);
                        presenceZones.Persist(asn1Serializer, statusStorage);
                        pendingTimedActions.Persist(asn1Serializer, statusStorage);
                        interlockGroups.Persist(asn1Serializer, statusStorage);

                        // Save here
                        if (sramWriteData(statusStorage) == false)
                        {
                            ClearStorage();
                            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                            {
                                return "Unable to write status stream to sram.";
                            });
                        }
                        else
                        {
                            int p = ((int)statusStorage.Length * 100) / (SramLocations.StatusOfflineStorageLength - StatusManager.SramPreambleSize);
                            if (statusStorage.Length > 0 && p == 0) p = 1;
                            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                            {
                                return string.Format("Saving status. Status stream size {0} (used {1}%).", statusStorage.Length, p);
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                    {
                        return string.Format("Unable to create status stream. {0}", ex.Message);
                    });

                }               
            }
            finally
            {
                statusStoreProcessing = false;
            }
        }

        public const int SramPreambleSize = 7;
        private const int numberOfBytesToCopy = 1024;
        
        private bool sramWriteData(Stream stream)
        {
            int total = (int)stream.Length;
            if (total <= 0 || stream == null)
                return false;

            if (total + SramPreambleSize > SramLocations.StatusOfflineStorageLength)
                return false;

            byte[] dataSize = new byte[SramPreambleSize];
            dataSize[0] = (byte)'S';
            dataSize[1] = (byte)'T';
            dataSize[2] = (byte)'S';
            dataSize[3] = (byte)total;
            dataSize[4] = (byte)(total >> 8);
            dataSize[5] = (byte)(total >> 16);
            dataSize[6] = (byte)(total >> 24);

            if (Sram.WriteData(SramLocations.StatusOfflineStorageOffset, dataSize) == false)
                return false;

            stream.Position = 0;
            int currentPosition = 0;
            byte[] arrayToCopy = null;
            do
            {
                if ((total - currentPosition) > numberOfBytesToCopy)
                {
                    if (arrayToCopy == null)
                        arrayToCopy = new byte[numberOfBytesToCopy];
                    stream.Read(arrayToCopy, 0, arrayToCopy.Length);
                }
                else
                {
                    arrayToCopy = new byte[(total - currentPosition)];
                    stream.Read(arrayToCopy, 0, arrayToCopy.Length);
                }
                if (Sram.WriteData(SramLocations.StatusOfflineStorageOffset + SramPreambleSize + currentPosition, arrayToCopy) == false)
                    return false;
                currentPosition += arrayToCopy.Length;
            } while ((total - currentPosition) > 0);
            return true;
        }

        private void loadStatusFromStorage(ref StatusStorageCollection statusStorage)
        {
            MemoryStream data;
            try
            {
                if (sramReadData(out data) == false)
                    return;
            }
            catch
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Unable to read information from stream.");
                });
                sramClearData();
                statusStorage.Clear();
                return;
            }

            // Read status stream
            data.Position = 0;
            while (data.Position < data.Length)
            {
                StatusStorageBase statusItem = null;
                try
                {
                    statusItem = (StatusStorageBase)asn1Serializer.Deserialize(data);
                    if (statusItem == null)
                        continue;
                    switch (statusItem.StorageType)
                    {
                        case StorageType.TimedAction:
                            statusStorage.TimedActions.Add((TimedActionStorage)statusItem);
                            break;
                        default:
                            StatusStorageConfigurationBase statusConfigItem = statusItem as StatusStorageConfigurationBase;
                            if (statusConfigItem == null)
                                continue;
                            switch (statusItem.StorageType)
                            {
                                case StorageType.AreaStatusStorage:
                                    statusStorage.AreasStatus.Add(statusConfigItem.LogicalId, (AreaStatusStorage)statusConfigItem);
                                    break;
                                case StorageType.ControllerStatusStorage:
                                    statusStorage.Controller = (ControllerStatusStorage)statusConfigItem;
                                    break;
                                case StorageType.DeviceStatusStorage:
                                    statusStorage.DevicesStatus.Add(statusConfigItem.LogicalId, (DeviceStatusStorageBase)statusConfigItem);
                                    break;
                                case StorageType.DoorStatusStorage:
                                    statusStorage.DoorsStatus.Add(statusConfigItem.LogicalId, (DoorStatusStorage)statusConfigItem);
                                    break;
                                case StorageType.ExpansionCardStatusStorage:
                                    statusStorage.ExpansionCardsStatus.Add(statusConfigItem.LogicalId, (ExpansionCardStatusStorage)statusConfigItem);
                                    break;
                                case StorageType.InputStatusStorage:
                                    statusStorage.InputsStatus.Add(statusConfigItem.LogicalId, (InputStatusStorage)statusConfigItem);
                                    break;
                                case StorageType.OutputStatusStorage:
                                    statusStorage.OutputsStatus.Add(statusConfigItem.LogicalId, (OutputStatusStorage)statusConfigItem);
                                    break;
                                case StorageType.ReaderStatusStorage:
                                    statusStorage.ReadersStatus.Add(statusConfigItem.LogicalId, (ReaderStatusStorage)statusConfigItem);
                                    break;
                                case StorageType.InterlockGroupStatusStorage:
                                    statusStorage.InterlockGroupStatus.Add(statusConfigItem.LogicalId, (InterlockGroupStatusStorage)statusConfigItem);
                                    break;
                                case StorageType.ElevatorStatusStorage:
                                    statusStorage.ElevatorsStatus.Add(statusConfigItem.LogicalId, (ElevatorStatusStorage)statusConfigItem);
                                    break;
                            }
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                    {
                        return string.Format("Unable to read status from stream. Type: {0}, Exception: {1}",
                            statusItem != null ? statusItem.StorageType.ToString() : "N/A", ex.ToString());
                    });
                    sramClearData();
                }
            }
        }

        private bool sramReadData(out MemoryStream data)
        {
            data = null;
            byte[] dataSize = new byte[SramPreambleSize];
            if (Sram.ReadData(SramLocations.StatusOfflineStorageOffset, dataSize) == false)
                return false;

            if (dataSize[0] != (byte)'S' || dataSize[1] != (byte)'T' || dataSize[2] != (byte)'S')
                return false;

            int total = (dataSize[6] << 24) |
                (dataSize[5] << 16) |
                (dataSize[4] << 8) |
                (dataSize[3]);

            if (total > (SramLocations.StatusOfflineStorageLength - SramPreambleSize))
                return false;

            data = new MemoryStream();
            int currentPosition = 0;
            byte[] arrayToCopy = null;
            do
            {
                if ((total - currentPosition) > numberOfBytesToCopy)
                {
                    if (arrayToCopy == null)
                        arrayToCopy = new byte[numberOfBytesToCopy];
                }
                else
                {
                    arrayToCopy = new byte[(total - currentPosition)];
                }
                Sram.ReadData(SramLocations.StatusOfflineStorageOffset + SramPreambleSize + currentPosition, arrayToCopy);
                data.Write(arrayToCopy, 0, arrayToCopy.Length);
                currentPosition += arrayToCopy.Length;
            } while ((total - currentPosition) > 0);
            return true;
        }

        /// <summary>
        /// Clear sram preamble. It marks all status lost.
        /// </summary>
        private void sramClearData()
        {
            byte[] dataSize = new byte[SramPreambleSize];
            dataSize[0] = 0;
            dataSize[1] = 0;
            dataSize[2] = 0;
            dataSize[3] = 0;
            dataSize[4] = 0;
            dataSize[5] = 0;
            dataSize[6] = 0;
            Sram.WriteData(SramLocations.StatusOfflineStorageOffset, dataSize);
        }

        /// <summary>
        /// Clear status manager storage.
        /// </summary>
        public void ClearStorage()
        {
            sramClearData();
        }

        /// <summary>
        /// Request status manager to store its statuses in persisted storage. Separate thread will be used.
        /// </summary>
        public void RequestStatusToStorage()
        {
            requestStatusToStorage(false);
        }

        /// <summary>
        /// Request status manager storage to save status the last time before controller restart.
        /// </summary>
        public void RequestStatusToStorageBeforeRestart()
        {            
            requestStatusToStorage(true);
        }

        /// <summary>
        /// Force status manager to store its statuses in persisted storage immediately.
        /// </summary>
        public void ForceStatusToStorage()
        {
            if (statusStorageThread != null)
            {
                forceStatusToStore = true;
                requestStatusStoreForProcessing.Set();
            }
            else
            {
                saveStatusToStorage(false);
            }
        }

        /// <summary>
        /// Request status manager to store its statuses in persisted storage.
        /// </summary>
        /// <param name="controllerRestarted">When true the saving will occur synchronously with the calling thread. Otherwise separate thread will be used.</param>
        private void requestStatusToStorage(bool controllerRestarting)
        {
            try
            {
                if (statusStorageThread == null)
                {
                    if (SystemStatus != SystemStatusType.ConfigurationChanging)
                    {
                        saveStatusToStorage(controllerRestarting);
                    }
                }
                else
                {
                    if (controllerRestarting == false)
                    {
                        requestStatusStoreForProcessing.Set();
                    }
                    else
                    {
                        stopStatusStorageThread();
                        try
                        {
                            saveStatusToStorage(controllerRestarting);
                        }
                        finally
                        {
                            startStatusStorageThread();
                        }
                    }
                }
            }
            catch
            {
                // In case of any critical errors.
            }
        }

        #endregion
    }
}
