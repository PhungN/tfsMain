﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.AccessControl;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Utils;
using Pacom.Core.Contracts.Status;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Collection of all reader statuses with utility functions
    /// </summary>
    public class ReaderStatusList : StatusListBase<ReaderStatus, ReaderStatusList>, IDisposable
    {
        /// <summary>
        /// Reader Schedule Timer that fires on the StartTime for each schedule record interval for current day and 
        /// will update the ReaderStatus for all readers that follow this schedule.
        /// </summary>
        private IPacomTimer readerScheduleTimer = null;

        private bool disabled { get; set; }

        private DelayedStatusNodesUpdateAgent initialOnlineReaders = null;
        private SuspectedStatusNodesAgent suspectedOfflineReaders = null;

        internal ReaderStatusList()
        {
            readerScheduleTimer = TimerManager.Instance.CreateTimer(readerScheduleTimerProc);
            ConfigurationManager.Instance.ConfigurationChanging += new EventHandler<ConfigurationChangeEventArgs>(configurationManager_ConfigurationChanging);

            // Setup suspected devices list
            suspectedOfflineReaders = new SuspectedStatusNodesAgent();
            suspectedOfflineReaders.CustomAction = suspectedOfflineReadersCustomAction;

            initialOnlineReaders = new DelayedStatusNodesUpdateAgent();
            initialOnlineReaders.CustomAction = suspectedOfflineReadersCustomAction;
        }

        /// <summary>
        /// Triggered when the isolated flag of any of the reader changes.
        /// </summary>
        public event EventHandler<StatusManagerReaderChangedIsolatedEventArgs> ChangedIsolatedStatus = null;

        /// <summary>
        /// Triggered any time the reader mode changes
        /// </summary>
        public event EventHandler<ReaderEventArgs> ReaderModeChangedEvent = null;

        /// <summary>
        /// Triggered when reader is lockout
        /// </summary>
        public event EventHandler<ReaderLockoutEventArgs> ReaderLockoutRestoreEvent = null;

        /// <summary>
        /// Triggered when the tamper status of any reader changes.
        /// </summary>
        public event EventHandler<ReaderTamperChangedStatusEventArgs> TamperChangedStatus = null;

        /// <summary>
        /// Triggered when the radio link status of any reader changes.
        /// </summary>
        public event EventHandler<ItemStatusChangedEventArgs> RadioFaultChangedStatus = null;

        /// <summary>
        /// Triggered when the battery status of any reader changes.
        /// </summary>
        public event EventHandler<ItemStatusChangedEventArgs> BatteryFailChangedStatus = null;

        /// <summary>
        /// Triggered when a reader Online status has changed.
        /// </summary>
        public event EventHandler<ReaderOnlineOfflineEventArgs> ReaderOnlineStatusChanged = null;

        /// <summary>
        /// Triggered when card is not valid for dual/triple entry
        /// </summary>
        public event EventHandler<MultiBadgingEventArgs> InvalidMultiBadgingEvent = null;

        /// <summary>
        /// Force readers status update from reader schedule
        /// </summary>
        internal void UpdateStatus()
        {
            disabled = false;
            ReaderSchedule[] readerSchedules = ConfigurationManager.Instance.ReaderSchedules;
            if (readerSchedules.Length == 0)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("No reader schedules exist. The reader(s) status will not be updated!");
                });
                return;
            }
            readerScheduleTimerProc(null);
        }

        /// <summary>
        /// Triggered when the configuration is changing. We need to stop the reader schedule timer from running.
        /// The timer will be turned back on when the StatusManager is fully updated after the configuration has 
        /// been updated.
        /// </summary>
        /// <param name="sender">Not used</param>
        /// <param name="e">Not used</param>
        private void configurationManager_ConfigurationChanging(object sender, ConfigurationChangeEventArgs e)
        {
            try
            {
                disabled = true;
                readerScheduleTimer.Stop();
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while preparing for configuration change in ReaderStatusList : {0}", ex.ToString());
                });
            }
        }

        /// <summary>
        /// Reader Schedule timer procedure
        /// </summary>
        /// <param name="state">Not Used</param>
        private void readerScheduleTimerProc(object state)
        {
            if (disposed == true)
                return;

            if (disabled == true)
                return;

            int nextTimerDueTime = 0;
            DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
            DateTime nextStartTime = DateTime.MaxValue;
            ReaderSchedule[] readerSchedules = ConfigurationManager.Instance.ReaderSchedules;
            foreach (var readerSchedule in readerSchedules)
            {
                if (readerSchedule != null)
                {
                    DateTime startTime = readerSchedule.RecalculateSchedule(now, this);
                    if (startTime < nextStartTime)
                        nextStartTime = startTime;
                }
            }
            if (nextStartTime <= now)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Next scheduled start time is not in the future: Now = [{0}], NextStartTime = [{1}]",
                        now.ToString("dd/MM/yyyy"), nextStartTime.ToString("dd/MM/yyyy"));
                });
            }
            nextTimerDueTime = (int)((nextStartTime - now).TotalMilliseconds);
            // Set next timer due time
            readerScheduleTimer.RunOnce(nextTimerDueTime);
        }

        internal void ScheduleChangeNotification(ReaderSchedule schedule, Pacom.Core.Contracts.DayType day, int intervalOffset, 
                                                 Reader8003ScheduleLevel level, List<int> affectedReaders)
        {
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
            {
                return string.Format("Reader schedule notification update. Day:{0}, Interval: {1} Mode:{2}", day.ToString(), intervalOffset, level.ToString());
            });
#endif

            foreach (var readerStatus in Items)
            {
                if (affectedReaders.Any(readerId => readerId == readerStatus.LogicalId))
                {
                    if (readerStatus.ForcedMode != ReaderModeForcedType.Normal && (readerStatus.ForcedDuringDay != day || readerStatus.ForcedDuringIntervalOffset != intervalOffset))
                    {
                        readerStatus.RestoreForcedToNormal();
                    }
                    if (readerStatus.ForcedMode == ReaderModeForcedType.Normal)
                    {
                        readerStatus.SetMode(level, false, ConfigurationManager.ScheduleUser);
                    }
                }
            }
        }

        /// <summary>
        /// Block readers in specified area
        /// </summary>
        /// <param name="areaId">Area Id to check against.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public void BlockInArea(int areaId, UserAuditInfo userAuditInfo)
        {
            List<int> readersInAreaForUser = GetReadersInAreaForUser(userAuditInfo.OriginatingUserId, areaId);

            foreach (int readerId in readersInAreaForUser)
            {
                ReaderStatus readerStatus = this[readerId];
                if (readerStatus != null)
                {
                    IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(readerStatus.LogicalId);
                    if (readerConfig != null)
                    {
                        readerStatus.SetMode(Reader8003ScheduleLevel.Blocked, true, userAuditInfo);
                    }
                }
            }
        }

        /// <summary>
        /// Restore readers in specified area
        /// </summary>
        /// <param name="areaId">Area Id to check against.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public void RestoreInArea(int areaId, UserAuditInfo userAuditInfo)
        {
            List<int> readersInAreaForUser = GetReadersInAreaForUser(userAuditInfo.OriginatingUserId, areaId);

            foreach (int readerId in readersInAreaForUser)
            {
                ReaderStatus readerStatus = this[readerId];
                if (readerStatus != null)
                {
                    IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(readerStatus.LogicalId);
                    if (readerConfig != null)
                    {
                        readerStatus.RestoreMode(userAuditInfo);
                    }
                }
            }
        }

        /// <summary>
        /// Force the reader mode for a list of readers for a specified duration.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="duration">The time for which to</param>
        /// <returns></returns>
        public bool SetMode(List<int> readerIds, Reader8003ScheduleLevel value, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            List<int> readersToRestore = new List<int>(readerIds.Count);
            foreach (int readerId in readerIds)
            {
                ReaderStatus status = this[readerId];
                if (status != null && status.Enabled == true)
                {
                    if (status.SetMode(value, true, userAuditInfo) == true)
                        readersToRestore.Add(readerId);
                }
            }
            if (durationInSeconds > 0)
            {
                StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.RestoreReaderModes, readersToRestore, userAuditInfo, durationInSeconds); 
            }
            return (readersToRestore.Count > 0);
        }

        /// <summary>
        /// Restore reader status mode to the reader scheduled mode (the reader schedule based on the assigned schedule).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public bool RestoreMode(List<int> readerIds, UserAuditInfo userAuditInfo)
        {
            bool result = false;
            foreach (int readerId in readerIds)
            {
                ReaderStatus status = this[readerId];
                if (status != null && status.Enabled == true)
                {
                    if (status.RestoreMode(userAuditInfo) == true)
                        result = true;
                }
            }
            return result;
        }

        /// <summary>
        /// Unblock readers in specified area
        /// </summary>
        /// <param name="areaId">Area Id to check against.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public void UnlockInArea(int areaId, UserAuditInfo userAuditInfo)
        {
            List<int> readersInAreaForUser = GetReadersInAreaForUser(userAuditInfo.OriginatingUserId, areaId);

            foreach (int readerId in readersInAreaForUser)
            {
                ReaderStatus readerStatus = this[readerId];
                if (readerStatus != null)
                {
                    IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(readerStatus.LogicalId);
                    if (readerConfig != null)
                    {
                        readerStatus.SetMode(Reader8003ScheduleLevel.Unlocked, true, userAuditInfo);
                    }
                }
            }
        }

        /// <summary>
        /// Change mode for readers in specified area to card only.
        /// </summary>
        /// <param name="areaId">Area Id to check against.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public void CardOnlyInArea(int areaId, UserAuditInfo userAuditInfo)
        {
            List<int> readersInAreaForUser = GetReadersInAreaForUser(userAuditInfo.OriginatingUserId, areaId);

            foreach (int readerId in readersInAreaForUser)
            {
                ReaderStatus readerStatus = this[readerId];
                if (readerStatus != null)
                {
                    IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(readerStatus.LogicalId);
                    if (readerConfig != null)
                    {
                        readerStatus.SetMode(Reader8003ScheduleLevel.CardOnly, true, userAuditInfo);
                    }
                }
            }
        }

        /// <summary>
        /// Change mode for readers in specified area to card and card.
        /// </summary>
        /// <param name="areaId">Area Id to check against.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public void CardAndPinInArea(int areaId, UserAuditInfo userAuditInfo)
        {
            List<int> readersInAreaForUser = GetReadersInAreaForUser(userAuditInfo.OriginatingUserId, areaId);

            foreach (int readerId in readersInAreaForUser)
            {
                ReaderStatus readerStatus = this[readerId];
                if (readerStatus != null)
                {
                    IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(readerStatus.LogicalId);
                    if (readerConfig != null)
                    {
                        readerStatus.SetMode(Reader8003ScheduleLevel.CardAndPin, true, userAuditInfo);
                    }
                }
            }
        }

        /// <summary>
        /// This function evaluates the reader mode with regards to the other reader on the door, if any.
        /// </summary>
        /// <param name="readerId">Read logical Id for evaluation. If door has two readers provide the inReader as default.</param>
        /// <returns>Returns reader schedule level.</returns>
        public Reader8003ScheduleLevel GetReaderMode(int readerId)
        {
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(readerId);
            if (readerConfig == null)
                return Reader8003ScheduleLevel.Blocked;

            if (readerConfig.Door == null || readerConfig.Door.Enabled == false)
            {
                ReaderStatus readerStatus = this[readerId];
                return readerStatus.Mode;
            }
            else if (readerConfig.Door.InReader == null || readerConfig.Door.InReader.Enabled == false)
            {
                return Reader8003ScheduleLevel.Blocked;
            }
            else if (readerConfig.Door.OutReader == null || readerConfig.Door.OutReader.Enabled == false)
            {
                ReaderStatus readerStatus = this[readerId];
                return readerStatus.Mode;
            }
            else
            {
                int inReaderId = readerConfig.Door.InReader.Id;
                int outReaderId = readerConfig.Door.OutReader.Id;
                Reader8003ScheduleLevel inReaderMode = this[inReaderId].Mode;
                Reader8003ScheduleLevel outReaderMode = this[outReaderId].Mode;

                if (inReaderMode == Reader8003ScheduleLevel.Unlocked || outReaderMode == Reader8003ScheduleLevel.Unlocked)
                {
                    if (outReaderMode != Reader8003ScheduleLevel.Unlocked)
                        return outReaderMode;
                    else
                        return inReaderMode;
                }
                else
                {
                    return this[readerId].Mode;
                }
            }
        }

        /// <summary>
        /// Get reader initial online status. If OSDP bus is configured for this controller the initial online state will be false,
        /// and system will wait for online events.
        /// </summary>
        /// <param name="readerLogicalId">Logical reader Id</param>
        /// <returns>True is the reader should become initially online.</returns>
        internal bool GetReaderInitialOnlineState(int readerLogicalId)
        {
            var controllerConfiguration = ConfigurationManager.Instance.ControllerConfiguration;
            for (int i = 0; i < controllerConfiguration.OnboardReaders.Length; i++)
            {
                if (controllerConfiguration.OnboardReaders[i] != null && 
                    controllerConfiguration.OnboardReaders[i].Enabled == true && 
                    controllerConfiguration.OnboardReaders[i].Id == readerLogicalId)
                {
                    if ((controllerConfiguration.RS485Port != null &&
                           controllerConfiguration.RS485Port.PortProtocol == PortProtocol.OpenSupervisedDeviceProtocol) ||
                        controllerConfiguration.ExpansionSlotPortHasSerialConfiguration(0, PortProtocol.OpenSupervisedDeviceProtocol) ||
                        controllerConfiguration.ExpansionSlotPortHasSerialConfiguration(1, PortProtocol.OpenSupervisedDeviceProtocol))
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// Trigger reader Offline state changed.
        /// </summary>
        /// <param name="readerStatus">The reader for which the online status has changed.</param>
        internal void TriggerReaderOfflineStatusChanged(ReaderStatus readerStatus)
        {
            // Remove reader from suspected offline reader list when reader goes online
            if (readerStatus.Online == true)
            {
                suspectedOfflineReaders.RemoveStatusNode(readerStatus.LogicalId);
                initialOnlineReaders.RemoveStatusNode(readerStatus.LogicalId);
            }
            // Trigger common status changed event
            if (ReaderOnlineStatusChanged != null)
            {
                int doorId = 0;
                if (readerStatus.ParentDoor != null)
                    doorId = readerStatus.ParentDoor.LogicalId;
                ReaderOnlineStatusChanged(this, new ReaderOnlineOfflineEventArgs(readerStatus.LogicalId, doorId, readerStatus.Online == false));
            }
        }

        internal void TriggerReaderSuspectedOffline(ReaderStatus readerStatus)
        {
            suspectedOfflineReaders.AddStatusNode(readerStatus.LogicalId, true);        
        }

        /// <summary>
        /// Called after the configuration is ready but after the lists are repopulated.
        /// </summary>
        /// <param name="controllerRestarted">True if controller was restarted</param>
        internal void AfterStatusUpdate()
        {
            // Re-initialize the suspected Offline card readers agent initial time and poll period
            suspectedOfflineReaders.SetInitialTimeAndPollPeriod();
            // Re-initialize the delayed offline readers agent initial time and poll period when 
            // controller restarts / configuration changes
            initialOnlineReaders.SetInitialTimeAndPollPeriod();

            // Add to the list
            List<int> readersToAdd = new List<int>();
            foreach (ReaderStatus reader in this.Items)
            {
                if (reader != null && reader.OfflineType == ReaderOfflineStatusType.SuspectedOffline)
                    readersToAdd.Add(reader.LogicalId);
            }
            initialOnlineReaders.AddStatusNodes(readersToAdd.ToArray());
        }                

        private void suspectedOfflineReadersCustomAction(int[] expiredNodes)
        {
            foreach (int logicalId in expiredNodes)
            {
                ReaderStatus readerStatus = this[logicalId] as ReaderStatus;
                if (readerStatus != null)
                {
                    readerStatus.NotifyReaderInTrouble();
                }
            }
        }
               
        internal void TriggerTamperChangedStatus(ReaderStatus readerStatus, bool previousTamperActive)
        {
            if (TamperChangedStatus != null)
            {
                TamperChangedStatus(this, new ReaderTamperChangedStatusEventArgs(readerStatus, previousTamperActive));
            }
        }

        internal void TriggerRadioFaultChangedStatus(ReaderStatus readerStatus, bool value)
        {
            if (RadioFaultChangedStatus != null)
            {
                RadioFaultChangedStatus(this, new ItemStatusChangedEventArgs(readerStatus.LogicalId, value));
            }
        }

        internal void TriggerBatteryFailChangedStatus(ReaderStatus readerStatus, bool value)
        {
            if (BatteryFailChangedStatus != null)
            {
                BatteryFailChangedStatus(this, new ItemStatusChangedEventArgs(readerStatus.LogicalId, value));
            }
        }

        /// <summary>
        /// Triggered when reader isolated status has changed
        /// </summary>
        /// <param name="readerStatus">The reader status instance that has changed.</param>
        /// <param name="isolated">The new value of the reader isolated status.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        internal void TriggerChangedIsolatedStatus(ReaderStatus readerStatus, bool isolated, UserAuditInfo userAuditInfo)
        {
            if (ChangedIsolatedStatus == null)
                return;
            ChangedIsolatedStatus(this, new StatusManagerReaderChangedIsolatedEventArgs(readerStatus, isolated, userAuditInfo));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="readerStatus"></param>
        /// <param name="mode"></param>
        /// <param name="previousMode"></param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        internal void TriggerReaderModeChanged(ReaderStatus readerStatus, Reader8003ScheduleLevel mode, Reader8003ScheduleLevel previousMode, 
                                               UserAuditInfo userAuditInfo)
        {
            if (ReaderModeChangedEvent != null)
            {
                if (readerStatus.ParentDoor != null)
                    ReaderModeChangedEvent(readerStatus, new ReaderEventArgs(readerStatus.ParentDoor.LogicalId, readerStatus.LogicalId, mode, previousMode, userAuditInfo));
                else
                    ReaderModeChangedEvent(readerStatus, new ReaderEventArgs(0, readerStatus.LogicalId, mode, previousMode, userAuditInfo));
            }
        }

        internal void TriggerReaderLockoutRestoreEvent(ReaderStatus readerStatus)
        {
            if (ReaderLockoutRestoreEvent == null)
                return;

            ReaderLockoutRestoreEvent(readerStatus, new ReaderLockoutEventArgs(readerStatus.LogicalId, false));
        }

        private ReaderStatus createReaderStatus(IReaderConfiguration readerConfiguration, ReaderStatusStorage readerStatusStorage)
        {
            ReaderStatus readerStatus = null;

            IDeviceLoopDCDevice parent = ConfigurationManager.Instance.GetDeviceConfiguration(readerConfiguration.ParentDeviceId) as IDeviceLoopDCDevice;
            if (parent != null)
            {
                int logicalDoorId = ConfigurationManager.Instance.GetLogicalDoorId(readerConfiguration.Id);
                bool isKeypad = ((DeviceConfigurationBase)parent).HardwareType == HardwareType.Pacom8101;
                readerStatus = new ReaderStatus(readerConfiguration as ConfigurationBase, StatusManager.Instance.Doors[logicalDoorId], isKeypad, this, readerStatusStorage);
            }

            return readerStatus;
        }

        /// <summary>
        /// Update readers status list from configuration. Add new reader status instances if not already existing
        /// </summary>
        /// <param name="readers">List of card readers to add</param>
        /// <param name="statusStorage">Status storage instance</param>
        internal void UpdateFromConfiguration(IReaderConfiguration[] readers, StatusStorageCollection statusStorage)
        {
            foreach (var reader in readers)
            {
                ReaderStatus readerStatus = createReaderStatus(reader, statusStorage.ReadersStatus.TryGetValue(reader.Id));
                if (readerStatus != null)
                    Assign(reader.Id, readerStatus);
            }
        }

        /// <summary>
        /// Update Reader status list from configuration on configuration change.
        /// </summary>
        internal void UpdateFromConfiguration(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems, List<NodeStateBase> partialStatusList)
        {
            foreach (var removedItem in removedItems)
            {
                if (removedItem.ConfigurationType == ConfigurationElementType.Reader)
                    Remove(removedItem.Id);
            }
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Reader)
                {
                    Remove(changedItem.Id);
                    try
                    {
                        ReaderStatus readerStatus = createReaderStatus(ConfigurationManager.Instance.GetReaderConfiguration(changedItem.Id), null);
                        if (readerStatus != null)
                        {
                            Assign(changedItem.Id, readerStatus);
                            partialStatusList.Add(this[changedItem.Id].CreateEventState());
                        }
                    }
                    catch
                    {
                    }
                }
            }
            foreach (var newlyAddedItem in newlyAddedItems)
            {
                if (newlyAddedItem.ConfigurationType == ConfigurationElementType.Reader)
                {
                    try
                    {
                        ReaderStatus readerStatus = createReaderStatus(ConfigurationManager.Instance.GetReaderConfiguration(newlyAddedItem.Id), null);
                        if (readerStatus != null)
                        {
                            Assign(newlyAddedItem.Id, readerStatus);
                            partialStatusList.Add(this[newlyAddedItem.Id].CreateEventState());
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }

        internal override void Persist(Asn1DerFormatter asn1Serializer, Stream statusStream)
        {
            foreach (var reader in Items)
            {
                try
                {
                    asn1Serializer.Serialize(statusStream, reader.CreateStatusStorage());
                }
                catch (Exception ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Unable to store status for reader {0}. {1}", reader.LogicalId, ex.Message);
                    });
                }
            }
        }

        /// <summary>
        /// Returns a list of readers in an area that the user has access to.
        /// A 0 length list is returned when the user doesn't have access to any readers or doesn't exist.
        /// null is never returned.
        /// </summary>
        public List<int> GetReadersInAreaForUser(int userId, int areaId)
        {
            List<int> readers = new List<int>();
            if (CommonUtilities.CheckUserAccess(userId, areaId))
            {
                int[] allReaderIds = base.Ids;
                foreach (int readerId in allReaderIds)
                {
                    IReaderConfiguration readerConfiguration = ConfigurationManager.Instance.GetReaderConfiguration(readerId);
                    if (readerConfiguration != null && readerConfiguration.Enabled == true && readerConfiguration.AreaId == areaId)
                    {
                        readers.Add(readerId);
                    }
                }
            }
            return readers;
        }

        /// <summary>
        /// Trigger when all reader statuses have been created.
        /// </summary>
        internal void PostInitialize()
        {
            foreach (var reader in Items)
            {
                reader.PostInitialize();
            }
        }

        internal override void Cleanup()
        {
            ConfigurationManager.Instance.ConfigurationChanging -= new EventHandler<ConfigurationChangeEventArgs>(configurationManager_ConfigurationChanging);
            if (readerScheduleTimer != null)
            {
                TimerManager.Instance.RemoveTimer(readerScheduleTimer);
                readerScheduleTimer = null;
            }
            suspectedOfflineReaders.Dispose();
            suspectedOfflineReaders = null;

            initialOnlineReaders.Dispose();
            initialOnlineReaders = null;
        }

        internal void RefreshAfterConfigurationChange()
        {
            foreach (var reader in Items)
            {
                reader.RefreshAfterConfigurationChange();
            }
        }

        internal void RefreshAfterConfigurationChange(List<ConfigurationChanges> changedItems)
        {
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Reader)
                {
                    ReaderStatus reader = this[changedItem.Id];
                    if (reader != null)
                        reader.RefreshAfterConfigurationChange();
                }
            }
        }

        internal void TriggerInvalidMultiBadgingEvent(MultiBadgingEventArgs e)
        {
            if (InvalidMultiBadgingEvent != null)
            {
                InvalidMultiBadgingEvent(this, e);
            }
        }
    }
}
