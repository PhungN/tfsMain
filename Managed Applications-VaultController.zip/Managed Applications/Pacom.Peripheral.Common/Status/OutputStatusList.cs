﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.Utils;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Core.Contracts.Status;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Collection of all output statuses with utility functions
    /// </summary>
    public class OutputStatusList : StatusListBase<OutputStatus, OutputStatusList>,IDisposable
    {
        private SchedulesStatus outputSchedulesStatus;
        internal OutputStatusList() : base() 
        {
            outputSchedulesStatus = new SchedulesStatus(ConfigurationManager.Instance.OutputSchedules.AsArray);
            outputSchedulesStatus.SchedulesStatusChanged += new EventHandler<SchedulesChangedEventArgs>(OnOutputSchedulesStatusChanged);
            outputSchedulesStatus.SchedulesConfigurationChanged += new EventHandler<SchedulesChangedEventArgs>(OnOutputSchedulesConfigurationChanged);
        }

        /// <summary>
        /// Triggered when the isolated flag of any of the outputs changes.
        /// </summary>
        public event EventHandler<StatusManagerOutputChangedIsolatedEventArgs> ChangedIsolatedStatus = null;

        /// <summary>
        /// Triggered when the output state of any of the outputs changes.
        /// </summary>
        public event EventHandler<StatusManagerOutputChangedActiveEventArgs> ChangeActiveStatus = null;

        /// <summary>
        /// Get output status for output with [logicalOutputid] id
        /// </summary>
        /// <param name="logicalOutputId">Logical output id, 1 based</param>
        /// <returns>Output status instance or null if not found</returns>
        public OutputStatus GetStatus(int logicalOutputId)
        {
            return this[logicalOutputId];
        }

        /// <summary>
        /// Get all enabled outputs in specified area.
        /// </summary>
        /// <param name="areaId">Area id for which enabled outputs will be returned.</param>
        /// <returns>Returns the list of enabled outputs for this area.</returns>
        public List<IStatusItem> GetOutputsInArea(int areaId)
        {
            List<IStatusItem> outputs = new List<IStatusItem>();
            foreach (var output in Items)
            {
                if (output == null || output.Enabled == false)
                    continue;
                OutputConfiguration outputConfig = ConfigurationManager.Instance.GetOutputConfiguration(output.LogicalId);
                if (outputConfig == null || outputConfig.AreaId != areaId)
                    continue;

                outputs.Add(output);
            }
            return outputs;
        }

        /// <summary>
        /// Get all outputs for all areaIds belongs to a user.
        /// </summary>
        /// <param name="user"></param>
        /// <returns>Returns the list of outputs for all areas belongs to this user.</returns>
        public List<IStatusItem> GetOutputsInAreasForUser(IUserConfiguration user)
        {
            var outputStausItems = new List<IStatusItem>();
            foreach (var outputStaus in Items)
            {
                if (outputStaus != null && outputStaus.Enabled == true)
                {
                    OutputConfiguration outputConfig = ConfigurationManager.Instance.GetOutputConfiguration(outputStaus.LogicalId);
                    if (outputConfig != null && user.AreaIds.Contains(outputConfig.AreaId))
                    {
                        outputStausItems.Add(outputStaus);
                    }
                }
            }
            outputStausItems.Sort((x, y) => x.LogicalId.CompareTo(y.LogicalId));
            return outputStausItems;
        }

        /// <summary>
        /// Returns a list of enabled outputs in an area that the user has access to. 
        /// If the user doesn't have access to this area null will be returned.
        /// </summary>
        public List<IStatusItem> GetOutputsInAreaForUser(int userId, int areaId)
        {
            if (CommonUtilities.CheckUserAccess(userId, areaId))
            {
                return GetOutputsInArea(areaId);
            }
            return null;
        }

        /// <summary>
        /// Check if any enabled output is active in specified area.
        /// </summary>
        /// <param name="areaId">Area Id to check against.</param>
        /// <returns></returns>
        public bool IsAnyActiveInArea(int areaId)
        {
            List<IStatusItem> outputsInArea = GetOutputsInArea(areaId);
            foreach (var output in outputsInArea)
            {
                if ((output as OutputStatus).RequestedState == OutputState.Active)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Check if all enabled outputs are active in specified area.
        /// </summary>
        /// <param name="areaId"></param>
        /// <returns></returns>
        public bool AreAllActiveInArea(int areaId)
        {
            List<IStatusItem> outputsInArea = GetOutputsInArea(areaId);
            if (outputsInArea == null || outputsInArea.Count == 0)
                return false;
            foreach (var output in outputsInArea)
            {
                if ((output as OutputStatus).RequestedState == OutputState.Inactive)
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Set output state for all outputs in specified area
        /// </summary>
        /// <param name="logicalOutputId"></param>
        /// <param name="state">True to activate output</param>
        /// <param name="userAuditInfo">User that initiaited activate / deactivate ouput(s) command.</param>
        public void SetStatusForArea(int areaId, bool state, UserAuditInfo userAuditInfo)
        {
            List<IStatusItem> outputsInAreaForUser = GetOutputsInAreaForUser(userAuditInfo.OriginatingUserId, areaId);
            if (outputsInAreaForUser == null || outputsInAreaForUser.Count == 0)
                return;
            foreach (var output in outputsInAreaForUser)
            {
                (output as OutputStatus).SetRequestedState(state, userAuditInfo);
            }
        }

        /// <summary>
        /// Isolate a list of outputs for a specified duration.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited isolate / deisolate ouput(s) command.</param>
        /// <param name="userId">The user who is performing the action.</param>
        /// <returns></returns>
        public bool SetIsolated(List<int> outputIds, bool value, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            if (value == true)
            {
                List<int> outputsToDeisolate = new List<int>(outputIds.Count);
                foreach (int outputId in outputIds)
                {
                    OutputStatus status = this[outputId];
                    if (status != null && status.Enabled == true)
                    {
                        if (status.SetIsolated(true, userAuditInfo) == true)
                            outputsToDeisolate.Add(outputId);
                    }
                }
                if (durationInSeconds > 0)
                {
                    StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.DeisolateOutputs, outputsToDeisolate, userAuditInfo, durationInSeconds);
                }
                return (outputsToDeisolate.Count > 0);
            }
            else
            {
                // Deisolate doesn't support a duration.
                bool result = false;
                foreach (int outputId in outputIds)
                {
                    OutputStatus status = this[outputId];
                    if (status != null && status.Enabled == true)
                    {
                        if (status.SetIsolated(false, userAuditInfo) == true)
                            result = true;
                    }
                }
                return result;
            }
        }

        /// <summary>
        /// Set the output state for a list of outputs for a specified duration.
        /// </summary>
        /// <param name="state">True to activate the output or false to deactivate it.</param>
        /// <param name="userAuditInfo">User that initiaited activate / deactivate ouput(s) command.</param>
        /// <param name="duration">The time for which to</param>
        /// <returns></returns>
        public bool SetRequestedState(List<int> outputIds, bool state, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            List<int> outputsToToggle = new List<int>(outputIds.Count);
            foreach (int outputId in outputIds)
            {
                OutputStatus status = this[outputId];
                if (status != null && status.Enabled == true)
                {
                    if (status.SetRequestedState(state, userAuditInfo) == true)
                        outputsToToggle.Add(outputId);
                }
            }
            if (durationInSeconds > 0)
            {
                StatusManager.Instance.CreateTimedAction(state == true ? StatusManagerTimedActions.DeactivateOutputs : StatusManagerTimedActions.ActivateOutputs, 
                                                         outputsToToggle, userAuditInfo, durationInSeconds); 
            }
            return (outputsToToggle.Count > 0);
        }

        internal void NotifyOutputChange(OutputStatus status)
        {
            if (status.Enabled == false)
                return;
            OutputConfiguration outputConfig = ConfigurationManager.Instance.GetOutputConfiguration(status.LogicalId);
            if (outputConfig != null)
            {
                int slot;
                if (outputConfig.ParentDeviceId == ConfigurationManager.Instance.ControllerConfiguration.Id)
                {
                    NotifyLocalOutputChange(status, outputConfig);
                }
                else if (tryFindExpansionCardFromOutput(outputConfig, out slot) == true)
                {
                    NotifyLocalOutputChange(slot, status, outputConfig);
                }
                else
                {
                    int deviceId = outputConfig.ParentDeviceId;
                    NotifyDeviceLoopOutputChange(deviceId, status);
                }
            }
        }

        /// <summary>
        /// Change onboard output on local device
        /// </summary>
        /// <param name="status"></param>
        /// <param name="outputConfig"></param>
        internal void NotifyLocalOutputChange(OutputStatus status, OutputConfiguration outputConfig)
        {
            if (outputConfig.Enabled == false)
                return;
            try
            {
                bool localOutputState = false;
                if (status.Isolated == false && status.RequestedState == OutputState.Active)
                    localOutputState = true;

                StatusManager.Instance.LocalDeviceManager.SetOutputStatus(outputConfig.PointNumberOnParent - 1, localOutputState);
            }
            catch (Exception)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return "Error while setting local device output.";
                });
            }
        }

        /// <summary>
        /// Try to find output expansion card.
        /// </summary>
        /// <param name="status"></param>
        /// <param name="slot">Output parameter with slot number 0 for expansion 1 and 1 for expansion card 2.</param>
        /// <returns>Returns True when the card is found.</returns>
        private bool tryFindExpansionCardFromOutput(OutputConfiguration outputConfig, out int slot)
        {
            slot = -1;
            try
            {
                var expansionCard = ConfigurationManager.Instance.GetExpansionCardDeviceConfiguration(outputConfig.ParentDeviceId);
                if (expansionCard == null)
                    return false;

                if (expansionCard.ParentDeviceId != ConfigurationManager.Instance.ControllerConfiguration.Id)
                    return false;

                slot = expansionCard.ExpansionCardSlot - 1;
                return true;
            }
            catch
            {
                return false;
            }            
        }

        /// <summary>
        /// Change expansion card output on local device
        /// </summary>
        /// <param name="status"></param>
        /// <param name="outputConfig"></param>
        internal void NotifyLocalOutputChange(int slot, OutputStatus status, OutputConfiguration outputConfig)
        {
            if (outputConfig.Enabled == false)
                return;
            try
            {
                bool localOutputState = false;
                if (status.Isolated == false && status.RequestedState == OutputState.Active)
                    localOutputState = true;

                StatusManager.Instance.LocalDeviceManager.SetExpansionOutputStatus(slot, outputConfig.PointNumberOnParent - 1, localOutputState);
            }
            catch (Exception)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return "Error while setting local device output.";
                });
            }
        }

        /// <summary>
        /// Change outputs on device loop device
        /// </summary>
        /// <param name="logicalDeviceId">Parent device logical Id</param>
        public void NotifyDeviceLoopOutputChange(int logicalDeviceId)
        {
            NotifyDeviceLoopOutputChange(logicalDeviceId, null);
        }

        /// <summary>
        /// Change all outputs or one output on device loop device. When status is provided the single output modification will occure 
        /// when device supports smart messaging.
        /// </summary>
        /// <param name="logicalDeviceId">Parent device logical Id</param>
        /// <param name="changedStatus">Status of the output</param>        
        public void NotifyDeviceLoopOutputChange(int logicalDeviceId, OutputStatus changedStatus)
        {
            try
            {
                if (StatusManager.Instance.DeviceLoopManager == null)
                    return;

                int parentDeviceId = logicalDeviceId;
                int countRepeat = 0;
                while (countRepeat < 2)
                {
                    // Check if the output lives on a device loop device                        
                    DeviceLoopDeviceConfigurationBase deviceLoopDevice = ConfigurationManager.Instance.GetDeviceConfiguration(parentDeviceId) as DeviceLoopDeviceConfigurationBase;
                    if (deviceLoopDevice != null)
                    {                        
                        IDeviceLoopIODevice ioDevice = deviceLoopDevice as IDeviceLoopIODevice;
                        if (ioDevice != null && ioDevice.OutputCount > 0)
                        {
                            int changedIndex = -1;
                            bool[] ouputsStates = new bool[ioDevice.OutputCount];
                            Array.Clear(ouputsStates, 0, ouputsStates.Length);
                            var i = 0;
                            foreach (var deviceOutputConfig in ioDevice.Outputs)
                            {
                                if (deviceOutputConfig != null && deviceOutputConfig.Enabled == true)
                                {
                                    OutputStatus outputStatus = GetStatus(deviceOutputConfig.Id);
                                    if (outputStatus != null && outputStatus.Isolated == false)
                                        ouputsStates[i] = outputStatus.RequestedState == OutputState.Active;

                                    if (changedStatus != null && outputStatus.LogicalId == changedStatus.LogicalId)
                                        changedIndex = i;
                                };
                                i++;
                            }
                            IDeviceLoopDeviceBase device = StatusManager.Instance.DeviceLoopManager[deviceLoopDevice.DeviceLoopAddress - 1];
                            if (device != null)
                                device.SetOutputStatus(ouputsStates, changedIndex);
                            return;
                        }
                    }

                    countRepeat++;
                    if (countRepeat >= 2)
                        return;
                    ExpansionCardDeviceConfigurationBase expansionCard = null;
                    expansionCard = ConfigurationManager.Instance.GetExpansionCardDeviceConfiguration(parentDeviceId);
                    if (expansionCard != null)
                    {
                        parentDeviceId = expansionCard.ParentDeviceId;
                    }
                }
            }
            catch (Exception)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return "Error while setting device loop output.";
                });
            }
        }

        /// <summary>
        /// Triggered when output isolated status has changed
        /// </summary>
        /// <param name="outputStatus">The outputs status instance that has changed.</param>
        /// <param name="isolated">The new value of the output isolated status.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        internal void TriggerChangedIsolatedStatus(OutputStatus outputStatus, bool isolated, UserAuditInfo userAuditInfo)
        {
            if (ChangedIsolatedStatus == null)
                return;
            ChangedIsolatedStatus(this, new StatusManagerOutputChangedIsolatedEventArgs(outputStatus, isolated, userAuditInfo));
        }

        /// <summary>
        /// Triggered when output active status has changed
        /// </summary>
        /// <param name="outputStatus">The outputs status instance that has changed.</param>
        /// <param name="active">The new value of the output active status.</param>
        /// <param name="userAuditInfo">User that initiaited the activate / deactivate output command.</param>
        internal void TriggerChangedActiveStatus(OutputStatus outputStatus, bool active, UserAuditInfo userAuditInfo)
        {
            if (ChangeActiveStatus == null)
                return;
            ChangeActiveStatus(this, new StatusManagerOutputChangedActiveEventArgs(outputStatus, active, userAuditInfo));
        }

        /// <summary>
        /// Update outputs status list from configuration. Add new output status instances if not already existing
        /// </summary>
        /// <param name="outputs">List of outputs to add</param>
        /// <param name="statusStorage">Status storage instance</param>
        /// <param name="controllerRestarted">True if controller restarted</param>
        internal void UpdateFromConfiguration(OutputConfiguration[] outputs, StatusStorageCollection statusStorage)
        {
            foreach (var output in outputs)
            {
                Assign(output.Id, new OutputStatus(output, this, statusStorage.OutputsStatus.TryGetValue(output.Id)));
            }
        }

        /// <summary>
        /// Update Output status list from configuration on configuration change.
        /// </summary>
        internal void UpdateFromConfiguration(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems, List<NodeStateBase> partialStatusList)
        {
            foreach (var removedItem in removedItems)
            {
                if (removedItem.ConfigurationType == ConfigurationElementType.Output)
                    Remove(removedItem.Id);
            }
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Output)
                {
                    var outputStatus = StatusManager.Instance.Outputs[changedItem.Id];
                    if (outputStatus != null && outputStatus.RequestedState == OutputState.Active)
                        outputStatus.SetRequestedState(false, ConfigurationManager.SystemUser);
                    Remove(changedItem.Id);
                    try
                    {
                        Assign(changedItem.Id, new OutputStatus(ConfigurationManager.Instance.GetOutputConfiguration(changedItem.Id), this, null));
                        partialStatusList.Add(this[changedItem.Id].CreateEventState());
                    }
                    catch
                    {
                    }
                }
            }
            foreach (var newlyAddedItem in newlyAddedItems)
            {
                try
                {
                    if (newlyAddedItem.ConfigurationType == ConfigurationElementType.Output)
                    {
                        Assign(newlyAddedItem.Id, new OutputStatus(ConfigurationManager.Instance.GetOutputConfiguration(newlyAddedItem.Id), this, null));
                        partialStatusList.Add(this[newlyAddedItem.Id].CreateEventState());
                    }
                }
                catch
                {
                }
            }
        }

        internal override void Persist(Asn1DerFormatter asn1Serializer, Stream statusStream)
        {
            foreach (var output in Items)
            {
                try
                {
                    asn1Serializer.Serialize(statusStream, output.CreateStatusStorage());
                }
                catch (Exception ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Unable to store status for output {0}. {1}", output.LogicalId, ex.Message);
                    });
                }
            }
        }

        internal void RefreshAfterConfigurationChange()
        {
            foreach (var output in Items)
            {
                output.RefreshAfterConfigurationChange();
            }
        }

        internal void RefreshAfterConfigurationChange(List<ConfigurationChanges> changedItems)
        {
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Output)
                {
                    OutputStatus output = this[changedItem.Id];
                    if (output != null)
                        output.RefreshAfterConfigurationChange();
                }
            }
        }

        internal void UnlatchAll(UserAuditInfo userAuditInfo)
        {
            foreach (var output in Items)
            {
                if (output == null || output.Enabled == false)
                    continue;
                output.Unlatch(userAuditInfo);
            }
        }

        internal override void Cleanup()
        {
            if (outputSchedulesStatus != null)
            {
                outputSchedulesStatus.SchedulesConfigurationChanged -= new EventHandler<SchedulesChangedEventArgs>(OnOutputSchedulesConfigurationChanged);
                outputSchedulesStatus.SchedulesStatusChanged -= new EventHandler<SchedulesChangedEventArgs>(OnOutputSchedulesStatusChanged);
                outputSchedulesStatus.ShutDown();
            }
        }

        private void OnOutputSchedulesStatusChanged(object sender, SchedulesChangedEventArgs e)
        {
            updateOutputs(e.ScheduleIntervalDetailsList);
        }

        private void OnOutputSchedulesConfigurationChanged(object sender, SchedulesChangedEventArgs e)
        {
            updateOutputs(e.ScheduleIntervalDetailsList);
        }

        private void updateOutputs(List<ScheduleIntervalDetails> scheduleIntervalDetailsList)
        {
            if (StatusManager.Instance.LocalDeviceManager != null)
            {
                foreach (var scheduleIntervalDetailsItem in scheduleIntervalDetailsList)
                {
                    int scheduleId = scheduleIntervalDetailsItem.Id;
                    OutputScheduleLevel scheduleLevel = OutputScheduleLevel.Off;
                    if (Enum.IsDefined(typeof(OutputScheduleLevel), scheduleIntervalDetailsItem.Level))
                        scheduleLevel = (OutputScheduleLevel)scheduleIntervalDetailsItem.Level;
                    bool state = scheduleLevel == OutputScheduleLevel.On;
                    foreach (var outputStatus in this.Items)
                    {
                        if (outputStatus != null && outputStatus.Enabled == true)
                        {
                            if (ConfigurationManager.Instance.GetOutputConfiguration(outputStatus.LogicalId).ScheduleId == scheduleId)
                            {
                                outputStatus.SetRequestedState(state, ConfigurationManager.ScheduleUser);
                            }
                        }
                    }
                }
            }
        }

        internal void UpdateSchedules()
        {
            var outputSchedules = ConfigurationManager.Instance.OutputSchedules.AsArray;
            if (outputSchedules.Length == 0)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("No output schedules exist. The output(s) status will not be updated!");
                });
                return;
            }
            outputSchedulesStatus.UpdateSchedules(outputSchedules);
        }
    }
}
