﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Events.EventsCommon;
using Pacom.Events.EventsCommon.Status;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    public abstract class DeviceStatusAbstractBase : StatusBase<DeviceStatusList>, IDeviceStatusBase
    {
        protected bool online = false;
        protected bool maskedOnline = false;
        
        protected bool tamperActive = false;
        protected bool maskedTamperActive = false;

        public DeviceStatusAbstractBase(ConfigurationBase configuration, DeviceStatusList parent)
            : base(configuration, parent)
        {
            SupportedIsolateFlags = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.Tamper;
            DeviceConfigurationBase config = configuration as DeviceConfigurationBase;
            if (config != null)
            {
                hardwareType = config.HardwareType;
                if (config.Enabled)
                    maskedOnline = true;
            }
        }

        public override StatusItemType ItemType
        {
            get { return StatusItemType.DeviceStatus; }
        }

        private HardwareType hardwareType = HardwareType.Undefined;

        /// <summary>
        /// Get the device hardware type.
        /// </summary>
        public HardwareType HardwareType
        {
            get { return hardwareType; }
        }

        public bool IsPowerSupplyDevice
        {
            get
            {
                return HardwareType == HardwareType.Pacom8303 || HardwareType == HardwareType.Pacom8308;
            }
        }

        /// <summary>
        /// Check if this is an Inovonics device.
        /// </summary>
        public bool IsInovonicsDevice
        {
            get 
            {
                if (hardwareType == HardwareType.InovonicsTransceiver ||
                    hardwareType == HardwareType.InovonicsRepeater ||
                    hardwareType == HardwareType.InovonicsSerialReceiver)
                    return true;
                return false; 
            }
        }

        /// <summary>
        /// Initialize the state of status storage instance for all the basic properties
        /// </summary>
        /// <param name="statusStorage">Status Storage instance to initialize</param>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        protected virtual void InitializeStatusStorage(DeviceStatusStorageBase statusStorage)
        {
            if (statusStorage == null)
                return;
            statusStorage.LogicalId = LogicalId;
            statusStorage.ParentDeviceId = ParentDeviceId;
            statusStorage.Online = false;
            statusStorage.IsolatedAlarms = IsolatedAlarms;
            statusStorage.LatchedAlarms = LatchedAlarms;
        }

        /// <summary>
        /// Initialize the state of status storage instance for all the basic properties
        /// </summary>
        /// <param name="statusStorage">Status Storage instance to initialize</param>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        protected virtual void InitializeEventState(DeviceEventState deviceState)
        {
            deviceState.Id = LogicalId;
            deviceState.Offline = MaskedOnline == false;
            deviceState.Tamper = MaskedTamperActive;
            deviceState.Isolate = IsolatedAlarms;
            deviceState.Latch = LatchedAlarms;
        }

        public DeviceInformation CreateDeviceInformation()
        {
            DeviceInformation deviceInformation = IsPowerSupplyDevice ? new PowerSupplyInformation() : new DeviceInformation();
            if (deviceInformation != null)
            {
                InitializeDeviceInformation(deviceInformation);
            }
            return deviceInformation;
        }

        /// <summary>
        /// Initialize device information instance from status / configuration information
        /// </summary>
        /// <param name="deviceInformation">Device Information instance</param>
        protected virtual void InitializeDeviceInformation(DeviceInformation deviceInformation)
        {
            deviceInformation.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            deviceInformation.Id = LogicalId;
            deviceInformation.HardwareType = HardwareType;
            deviceInformation.SerialNumber = SerialNumber;
            deviceInformation.ActiveFirmwareVersion = 1;
        }

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            switch (suspectStatusType)
            {
                case EventSourceLatchOrIsolateType.Offline: return ConfigurationManager.Instance.ControllerConfiguration.LatchOfflineAlarms;
                case EventSourceLatchOrIsolateType.Tamper: return ConfigurationManager.Instance.ControllerConfiguration.LatchTamperAlarms;
                default: return false;
            }
        }

        /// <summary>
        /// Get the string representation of the alarms / isolated alarms / latched alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        protected virtual string AlarmFlagsAsString(EventSourceLatchOrIsolateType alarms)
        {
            if (alarms == EventSourceLatchOrIsolateType.None)
                return string.Empty;
            string alarmsAsString = " ";

            foreach (EventSourceLatchOrIsolateType eventSource in EnumHelper.GetValues<EventSourceLatchOrIsolateType>())
            {
                if (eventSource == EventSourceLatchOrIsolateType.None)
                    continue;

                if (alarms.Has(eventSource) == true)
                    alarmsAsString = string.Format("{0}{1} ", alarmsAsString, ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
            }
            return alarmsAsString;
        }

        /// <summary>
        /// Get the string representation of the alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public override string AlarmsAsString
        {
            get { return AlarmFlagsAsString(CurrentAlarms); }
        }

        /// <summary>
        /// Get the string representation of the alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public override string IsolatedAlarmsAsString
        {
            get { return AlarmFlagsAsString(isolatedAlarms); }
        }

        /// <summary>
        /// Get the string representation of the latched alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public override string LatchedAlarmsAsString
        {
            get { return AlarmFlagsAsString(latchedAlarms); }
        }

        /// <summary>
        /// Get the array of strings representation for the alarms for this point
        /// </summary>
        protected virtual string[] AlarmFlagsAsStringArray(EventSourceLatchOrIsolateType alarms)
        {
            if (alarms == EventSourceLatchOrIsolateType.None)
                return new string[0];
            List<string> alarmsList = new List<string>();
            foreach (EventSourceLatchOrIsolateType eventSource in EnumHelper.GetValues<EventSourceLatchOrIsolateType>())
            {
                if (eventSource == EventSourceLatchOrIsolateType.None)
                    continue;

                if (alarms.Has(eventSource) == true)
                    alarmsList.Add(ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
            }
            return alarmsList.ToArray();
        }

        /// <summary>
        /// Get the string array representation of the current alarms for this point
        /// </summary>
        public override string[] AlarmsAsStringArray
        {
            get { return AlarmFlagsAsStringArray(CurrentAlarms); }
        }

        /// <summary>
        /// Get the string array representation of the isolated alarms for this point
        /// </summary>
        public override string[] IsolatedAlarmsAsStringArray
        {
            get { return AlarmFlagsAsStringArray(isolatedAlarms); }
        }

        /// <summary>
        /// Get the string representation of the latched alarms for this point as an array
        /// </summary>
        public override string[] LatchedAlarmsAsStringArray
        {
            get { return AlarmFlagsAsStringArray(latchedAlarms); }
        }

        /// <summary>
        /// Get alarm description for [alarmType], implemented for devices only, not needed for other status items.
        /// </summary>
        /// <param name="alarmType">Alarm Type: Offline, Tamper, etc.</param>
        /// <returns></returns>
        public override string AlarmDescription(EventSourceLatchOrIsolateType alarmType)
        {
            return ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(alarmType);
        }

        protected EventSourceLatchOrIsolateType DefaultLatchFlags = EventSourceLatchOrIsolateType.Offline |
                                                                    EventSourceLatchOrIsolateType.Tamper;
        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get { return latchedAlarms.HasAny(DefaultLatchFlags); }
        }

        /// <summary>
        /// Returns the current latch status for this status item instance and the [latchFlagToCheck]
        /// </summary>
        /// <param name="latchFlagToCheck">The status item alarm flag that needs to be checked for latching</param>
        /// <returns>The latch status for this status item.</returns>
        public override EventSourceLatchStatus GetLatchStatusFor(EventSourceLatchOrIsolateType latchFlagToCheck)
        {
            if (latchedAlarms.Has(latchFlagToCheck) == false)
                return EventSourceLatchStatus.NotLatched;

            if (ConfigurationManager.Instance.ControllerConfiguration.SuspectDeviceActivation == true)
            {
                return SuspectCount >= ConfigurationManager.Instance.ControllerConfiguration.SuspectDeviceActivationCounter ? 
                    EventSourceLatchStatus.SuspectBehaviour : EventSourceLatchStatus.ConfiguredToBeLatched;
            }
            else if (LatchAfterFirstAlarm(latchFlagToCheck) == true)
            {
                return EventSourceLatchStatus.ConfiguredToBeLatched;
            }

            // This code possibly will not be executed, but just for consistency we have result set.
            return EventSourceLatchStatus.NotLatched;
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = EventSourceLatchOrIsolateType.None;
                if (maskedOnline == false)
                    flags |= EventSourceLatchOrIsolateType.Offline;
                if (maskedTamperActive == true)
                    flags |= EventSourceLatchOrIsolateType.Tamper;
                return flags;
            }
        }

        /// <summary>
        /// Get display name for this device status item instance without any alarms / isolated alarms
        /// </summary>
        /// <returns>Display Name string.</returns>
        public override string DisplayName
        {
            get
            {
                DeviceConfigurationBase deviceConfig = ConfigurationManager.Instance.GetDeviceConfiguration(LogicalId);
                if (deviceConfig != null)
                {
                    IDeviceLoopDeviceConfigurationBase iDevice = deviceConfig as IDeviceLoopDeviceConfigurationBase;
                    string name = "Unknown";
                    if (iDevice != null)
                        name = iDevice.GetName();
                    return string.Format("{0}{1} {2}", ConfigurationManager.Instance.ControllerConfiguration.DevicePrefixText, LogicalId, name);
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Get / Set unmasked device online status
        /// </summary>
        public virtual bool Online
        {
            get { return online; }
            set
            {
                if (Enabled == false)
                    return;
                if (online != value)
                {
                    online = value;
                    Parent.DeviceOnlineStatusChanged(this);
                    MaskedOnline = online;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set masked device online status, send status changed to front-end if required.
        /// </summary>
        public bool MaskedOnline
        {
            get { return maskedOnline; }
            private set
            {
                if (Enabled == false)
                    return;
                if (maskedOnline != value || value == false)
                {
                    bool previousOnline = maskedOnline;
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false &&
                        SuspectPoint == false &&
                        (LatchedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false || value == false))
                    {
                        maskedOnline = value;
                        if (maskedOnline == false)
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.Offline);
                        Parent.TriggerDeviceMaskedOnlineStatusChanged(this);
                        if (maskedOnline == false)
                        {
                            ProcessAlarmConfirmation();
                            CheckTerminateArming();
                        }
                        else
                        {
                            CheckStopFailToArmTimer();
                        }
                        StatusManager.Instance.RequestStatusToStorage();
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Logical Device {0} is {1} to controller.", LogicalId, maskedOnline == true ? "online" : "offline");
                        });
                    }
                }
            }
        }

        /// <summary>
        /// Get / Set unmasked tamper active flag
        /// </summary>
        public bool TamperActive
        {
            get { return tamperActive; }
            set
            {
                if (Enabled == false)
                    return;
                if (tamperActive != value)
                {
                    tamperActive = value;
                    MaskedTamperActive = tamperActive;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set device masked tamper status, send tamper changed event to front-end if required.
        /// </summary>
        public bool MaskedTamperActive
        {
            get { return maskedTamperActive; }
            set
            {
                if (Enabled == false)
                    return;
                if (maskedTamperActive != value || value == true)
                {
                    bool previousTamperActive = maskedTamperActive;
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.Tamper) == false &&
                        SuspectPoint == false &&
                        (LatchedAlarms.Has(EventSourceLatchOrIsolateType.Tamper) == false || value == true))
                    {
                        maskedTamperActive = value;
                        if (maskedTamperActive == true)
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.Tamper);
                        Parent.TriggerChangedMaskedTamperStatus(this, previousTamperActive);
                        if (maskedTamperActive == true)
                        {
                            // Enqueue status change to expression manager
                            MacroControl.Instance.EnqueueDeviceTamperActive(LogicalId);
                            ProcessAlarmConfirmation();
                            CheckTerminateArming();
                        }
                        else
                        {
                            CheckStopFailToArmTimer();
                        }
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        /// <summary>
        /// When a device alarm is received check if there is any area arming task that needs to be terminated
        /// </summary>
        public void CheckTerminateArming()
        {
            foreach (var area in StatusManager.Instance.Areas.Items)
            {
                if (area.Enabled == true)
                    area.CheckTerminateArming();
            }
        }

        /// <summary>
        /// Stop the Fail to Arm timer if no more alarms for an area (area and device alarms)
        /// </summary>
        public void CheckStopFailToArmTimer()
        {
            bool anyDeviceAlarms = StatusManager.Instance.AnyDeviceAlarms;
            if (anyDeviceAlarms == false)
            {
                foreach (var area in StatusManager.Instance.Areas.Items)
                {
                    if (area.Enabled == true && area.HasArmedModeAlarms == false)
                        area.StopFailToArmTimer();
                }
            }
        }

        /// <summary>
        /// Handle alarm sequential confirmation for all enabled and ARMED areas 
        /// </summary>
        protected void ProcessAlarmConfirmation()
        {
            if (ConfigurationManager.Instance.AlarmConfirmationTimeEnabled == true)
            {
                foreach (var area in StatusManager.Instance.Areas.Items)
                {
                    if (area.Enabled == false || area.EnableAlarmConfirmationTime == false)
                        continue;
                    area.ProcessAlarmConfirmation(this);
                }
            }
        }

        /// <summary>
        /// Get the ConfirmedType for current alarm based on area mode and the previous unconfirmed alarm if required.
        /// </summary>
        /// <param name="unconfirmedAlarmSource">The source of an existing unconfirmed alarm, received before the current alarm.</param>
        /// <param name="areaSource">Area from which the alarm has originated</param>
        /// <returns>None, Unconfirmed or Confirmed.</returns>
        public override ConfirmedType GetConfirmedAlarmType(IStatusItem unconfirmedAlarmSource, IStatusItem areaSource)
        {
            if (areaSource == null)
                return ConfirmedType.None;

            AreaStatus areaStatus = areaSource as AreaStatus;
            if (areaStatus == null || (areaStatus.Mode == AreaScheduleLevel.Disarmed && CurrentAlarms.HasAny(Offline) == true))
            {
                // BS 8243 Annex H.3.1: A confirmed alarm will not be notified when a failure of communication to multiple devices on 
                //                      a data bus which cannot be identified as a fault (Device Offline), occurs when the system is 
                //                      in un-set state (area is Disarmed).
                return ConfirmedType.None;
            }

            return ConfirmedType.Confirmed;
        }

        #region IDeviceStatusBase Members

        /// <summary>
        /// Get / Set the device serial number
        /// </summary>
        public abstract string SerialNumber
        {
            get;
            set;
        }

        /// <summary>
        /// It is time to notify the alarm manager about the device being in offline state for too long
        /// </summary>
        public virtual void NotifyDeviceOffline() { }

        #endregion

        /// <summary>
        /// Get the state of device Isolated flag
        /// </summary>
        public bool Isolated
        {
            get { return isolatedAlarms != EventSourceLatchOrIsolateType.None; }
        }

        /// <summary>
        /// Set the state of device IsolatedAlarms flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="value">New isolated options. If value = EventSourceLatchOrIsolateType.None -> Deisolate all.
        /// If value = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.Tamper -> Isolate all or any.
        /// When de-isolating if any of the device inputs is in alarm the alarm will be queued into AlarmManager.
        /// </param>
        /// <returns>True if the command was successfully executed</returns>
        public virtual bool SetIsolated(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType value)
        {
            if (Enabled == false)
                return false;
            // Mask-out all flags this device does not support
            value &= SupportedIsolateFlags;

            bool pendingTimedActionRemoved = StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.DeisolateDevices, LogicalId);
            if (isolatedAlarms != value)
            {
                Isolating = true;
                // Offline - Isolate/de-isolate 
                SetIsolated(value, EventSourceLatchOrIsolateType.Offline, true, online);
                // Tamper - Isolate/de-isolate
                SetIsolated(value, EventSourceLatchOrIsolateType.Tamper, false, tamperActive);
                Isolating = false;
                Parent.TriggerChangedIsolatedStatus(this, value, isolatedAlarms, userAuditInfo);
                StatusManager.Instance.RequestStatusToStorage();
                return true;
            }
            return pendingTimedActionRemoved;
        }

        /// <summary>
        /// Set masked status for [optionToCheck] to [newValue]
        /// </summary>
        /// <param name="optionToCheck">Option to chec, e.g.: Offline, Tamper, etc.</param>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(EventSourceLatchOrIsolateType optionToCheck, bool newValue)
        {
            bool result = true;
            switch (optionToCheck)
            {
                case EventSourceLatchOrIsolateType.Offline:
                    MaskedOnline = newValue;
                    break;
                case EventSourceLatchOrIsolateType.Tamper:
                    MaskedTamperActive = newValue;
                    break;
                default:
                    result = false;
                    break;
            }
            return result;
        }

        /// <summary>
        /// Isolate device
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Isolate(UserAuditInfo userAuditInfo)
        {
            SetIsolated(userAuditInfo, SupportedIsolateFlags);
        }

        /// <summary>
        /// Deisolate device
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Deisolate(UserAuditInfo userAuditInfo)
        {
            SetIsolated(userAuditInfo, EventSourceLatchOrIsolateType.None);
        }

        /// <summary>
        /// Isolate device / controller / alarm/s (E.g.: for a device we can isolate Tamper or Offline or both of them).
        /// Isolated alarms will not be de-isolated. This function appends the [options] to the already isolated alarms. Used when
        /// isolating alarms from the alarm keypad.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="options">Alarm types to isolate: Offline / Tamper / etc.</param>
        public override void Isolate(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options)
        {
            options |= IsolatedAlarms;
            SetIsolated(userAuditInfo, options);
        }

        /// <summary>
        /// Deisolate device / controller / input / output / etc. specific alarm or
        /// all alarms (E.g.: for a device we can deisolate Tamper or Offline or both of them).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="options">Alarm types to deisolate: Offline / Tamper / etc.</param>
        public override void Deisolate(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options)
        {
            SetIsolated(userAuditInfo, options);
        }

        /// <summary>
        /// Set isolated flag for device point for a specified duration.
        /// </summary>
        /// <param name="value">Not Used.</param>
        /// <param name="bitField">BitField options to isolate/deisolate.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="durationInSeconds">The duration for which the point will be isolated, 0 means that the point will be isolated idefinitely</param>
        /// <returns>True if the point's isolated state was successfully changed, False otherwise.</returns>
        public override bool SetIsolated(bool value, EventSourceLatchOrIsolateType bitField, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            bool result = SetIsolated(userAuditInfo, bitField);
            if (result == true && bitField != EventSourceLatchOrIsolateType.None && durationInSeconds > 0)
            {
                // A duration is only supported for the 'isolate for a duration' case.
                StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.DeisolateDevices, LogicalId, userAuditInfo, durationInSeconds);
            }
            return result;
        }

        /// <summary>
        /// Unlatch device. Keep MaskedStatus alarm state if UnmaskedStatus is not Secure.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        /// <returns>True if device was unlatched, False otherwise.</returns>
        public override bool Unlatch(UserAuditInfo userAuditInfo)
        {
            if (Enabled == false)
                return false;

            if (IsCurrentlyLatched == true)
            {
                ResetIsCurrentlyLatched();
                RestoreAfterUnlatch(userAuditInfo);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Unlatch device specified alarms if latched. Keep MaskedStatus alarm state if UnmaskedStatus is not Secure.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        /// <param name="options">Latched alarms to unlatch (restore)</param>
        /// <returns>True if the point has been unlatched</returns>
        public override bool Unlatch(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options)
        {
            if (Enabled == false)
                return false;

            if (latchedAlarms.HasAny(options) == true)
            {
                ResetIsCurrentlyLatched(options);
                RestoreAfterUnlatch(userAuditInfo);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Restore masked online, device tamper, etc. status if required after unlatching the device alarms. Restore only if the
        /// current instantaneous status is Secure (device online, tamper secure, etc.).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        protected virtual void RestoreAfterUnlatch(UserAuditInfo userAuditInfo)
        {
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false && Online == true)
            {
                MaskedOnline = true;
                int[] deviceInputs = StatusManager.Instance.Inputs.GetInputsForDevice(LogicalId);
                if (deviceInputs.Length > 0)
                {
                    foreach (int logicalInputId in deviceInputs)
                    {
                        InputStatus inputStatus = StatusManager.Instance.Inputs[logicalInputId];
                        if (inputStatus != null && inputStatus.Enabled == true && inputStatus.IsCurrentlyLatched == true)
                        {
                            inputStatus.Unlatch(userAuditInfo);
                        }
                    }
                }
            }
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.Tamper) == false && TamperActive == false)
                MaskedTamperActive = false;
        }

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        public override bool CanIsolate(UserAccessLevel level)
        {
            return level == UserAccessLevel.AccessLevel3;
        }

        /// <summary>
        /// Check masked alarms when we restore status from previous stored state
        /// </summary>
        protected virtual void VerifyMaskedAlarms()
        {
            if (SupportedIsolateFlags.Has(EventSourceLatchOrIsolateType.Offline))
            {
                if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.Offline))
                {
                    maskedOnline = true;
                    latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.Offline);
                }
                else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.Offline))
                {
                    maskedOnline = false;
                }
            }

            if (SupportedIsolateFlags.Has(EventSourceLatchOrIsolateType.Tamper))
            {
                if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.Tamper))
                {
                    maskedTamperActive = false;
                    latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.Tamper);
                }
                else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.Tamper))
                {
                    maskedTamperActive = true;
                }
            }
        }

        public override string ToString()
        {
            return String.Format("Device Status [{0}]", LogicalId);
        }

        /// <summary>
        /// True if AC Fail alarms should be sent after the configured delay has expired
        /// </summary>
        protected static bool IsDelayedACFail
        {
            get { return (int)ConfigurationManager.Instance.ControllerConfiguration.PowerFailReportingDelay.TotalSeconds > 0; }
        }

        /// <summary>
        /// Send the changed power supply status to front-end, check if any area currently arming needs to be stopped or 
        /// the fail to arm timer needs to be stopped. Save status to storage.
        /// </summary>
        /// <param name="previousStatus">Previous masked power supply status</param>
        protected void SendPowerSupplyAlarm(PowerFailState maskedPowerState, PowerFailState previousState)
        {
            if (maskedPowerState != PowerFailState.None)
            {
                IncrementSuspectCount(EventSourceLatchOrIsolateType.PowerFail);
                CheckTerminateArming();
            }
            else
            {
                CheckStopFailToArmTimer();
            }

            // Report any power supply alarm to front end
            Parent.TriggerPowerSupplyChangedStatus(this as IDevicePowerSupplyStatus, previousState);
            StatusManager.Instance.RequestStatusToStorage();
        }

        /// <summary>
        /// Send the changed power supply status to front-end, check if any area currently arming needs to be stopped or 
        /// the fail to arm timer needs to be stopped. Save status to storage.
        /// </summary>
        /// <param name="previousStatus">Previous masked power supply status</param>
        protected void SendPowerSupplyAlarm(BatteryFailState maskedBatteryState, BatteryFailState previousState)
        {
            if (maskedBatteryState != BatteryFailState.None)
            {
                IncrementSuspectCount(EventSourceLatchOrIsolateType.BatteryFail);
                CheckTerminateArming();
            }
            else
            {
                CheckStopFailToArmTimer();
            }

            // Report any power supply alarm to front end
            Parent.TriggerPowerSupplyChangedStatus(this as IDevicePowerSupplyStatus, previousState);
            StatusManager.Instance.RequestStatusToStorage();
        }

        /// <summary>
        /// Send the changed power supply status to front-end, check if any area currently arming needs to be stopped or 
        /// the fail to arm timer needs to be stopped. Save status to storage.
        /// </summary>
        /// <param name="previousStatus">Previous masked power supply status</param>
        protected void SendPowerSupplyAlarm(bool maskedBatteryChargerFailed, bool previousMaskedBatteryChargerFailed)
        {
            if (maskedBatteryChargerFailed == true)
            {
                IncrementSuspectCount(EventSourceLatchOrIsolateType.BatteryChargerFail);
                CheckTerminateArming();
            }
            else
            {
                CheckStopFailToArmTimer();
            }

            // Report any power supply alarm to front end
            Parent.TriggerPowerSupplyChangedStatus(this as IDevicePowerSupplyStatus, previousMaskedBatteryChargerFailed);
            StatusManager.Instance.RequestStatusToStorage();
        }
    }
}
