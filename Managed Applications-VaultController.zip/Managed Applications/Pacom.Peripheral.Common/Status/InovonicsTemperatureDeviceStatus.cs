﻿#if INOVONICSTEMPERATUREDEMO
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Events.EventsCommon;

namespace Pacom.Peripheral.Common.Status
{
    public class InovonicsTemperatureDeviceStatus : InovonicsTransceiverOrRepeaterStatusBase
    {
        public InovonicsTemperatureDeviceStatus(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus)
            : base(configuration, parent, previousStatus)
        {
        }

        private int temperature = int.MinValue;
        public int TemperatureReading
        {
            get
            {
                return temperature;
            }
            set
            {
                if (temperature != value)
                {
                    temperature = value;

                    Inovonics8003TemperatureDeviceConfiguration configuration = ConfigurationManager.Instance.GetDeviceConfiguration(LogicalId) as Inovonics8003TemperatureDeviceConfiguration;
                    if (configuration != null)
                    {
                        var input = configuration.Inputs[0];
                        if (input != null)
                            Parent.TriggerAnalogueInputChangedState(this, input.Id, input.AreaId, AnalogueInputUnits.Millicelsius, value);
                    }
                }
            }
        }

        private int humidity = int.MinValue;
        public int HumidityReading
        {
            get
            {
                return humidity;
            }
            set
            {
                if (humidity != value)
                {
                    humidity = value;

                    Inovonics8003TemperatureDeviceConfiguration configuration = ConfigurationManager.Instance.GetDeviceConfiguration(LogicalId) as Inovonics8003TemperatureDeviceConfiguration;
                    if (configuration != null)
                    {
                        var input = configuration.Inputs[1];
                        if (input != null)
                            Parent.TriggerAnalogueInputChangedState(this, input.Id, input.AreaId, AnalogueInputUnits.Millipercent, value);
                    }
                }
            }
        }
    }
}
#endif