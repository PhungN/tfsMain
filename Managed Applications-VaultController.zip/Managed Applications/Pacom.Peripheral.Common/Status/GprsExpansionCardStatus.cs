﻿using System;
using Pacom.Core.Contracts;
using Pacom.Peripheral.CellularManagement;
using System.Net;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    public class GprsExpansionCardStatus : ExpansionCardStatus, IGprsExpansionCardStatus 
    {
        private GprsNetworkRegistration networkRegistration = GprsNetworkRegistration.NotRegistered;
        private GprsNetworkSignalStrength signalStrength = GprsNetworkSignalStrength.AutoConfigurationIncomplete;
        private GprsNetworkSignalStrength maskedSignalStrength = GprsNetworkSignalStrength.Good;
        
        public GprsExpansionCardStatus(ConfigurationBase configuration, ExpansionCardStatusList parent, ExpansionCardStatusStorage previousStatus) :
            base(configuration, parent, previousStatus)
        {
            SupportedIsolateFlags |= EventSourceLatchOrIsolateType.SignalFail;
            ClearCellularModuleStatistics();
            ClearConnectionStatistics();
            maskedSignalStrengthUpdateTimer = TimerManager.Instance.CreateTimer(maskedSignalStrengthUpdateTimerProc);
            dataUsage = GprsDataUsageDetails.CreateInstance(ConfigurationManager.Instance.ControllerConfiguration, previousStatus);

            VerifyMaskedAlarms();
        }

        #region Cellular Module and Connection Statistics
                
        private string cellularCarrier;

        /// <summary>
        /// The current reported mobile service carrier
        /// </summary>
        public string CellularCarrier
        {
            get { return this.cellularCarrier; }
        }

        private CellularAccessTechnology cellularAccessTechnology;

        /// <summary>
        /// The current carrier access technology.
        /// </summary>
        public CellularAccessTechnology CellularAccessTechnology
        {
            get { return this.cellularAccessTechnology; }
        }
                
        private string cellularModuleSerialNumber;

        /// <summary>
        /// Modem module serial number
        /// </summary>
        public string CellularModuleSerialNumber
        {
            get { return this.cellularModuleSerialNumber; }
        }
                
        private string cellularModuleRevision;

        /// <summary>
        /// Modem module revision
        /// </summary>
        public string CellularModuleRevision
        {
            get { return this.cellularModuleRevision; }
        }

        /// <summary>
        /// Modem module model
        /// </summary>
        private string cellularModuleModel;

        public string CellularModuleModel
        {
            get { return this.cellularModuleModel; }
        }
                
        private string cellularModuleManufacturer;

        /// <summary>
        /// Modem module manufacturer
        /// </summary>
        public string CellularModuleManufacturer
        {
            get { return cellularModuleManufacturer; }
        }

        /// <summary>
        /// Clear cellular module statistics
        /// </summary>
        public void ClearCellularModuleStatistics()
        {
            this.cellularCarrier = string.Empty;
            this.cellularAccessTechnology = CellularAccessTechnology.Unknown;
            this.cellularModuleSerialNumber = string.Empty;
            this.cellularModuleRevision = string.Empty;
            this.cellularModuleModel = string.Empty;
            this.cellularModuleManufacturer = string.Empty;
        }

        /// <summary>
        /// Update cellular module statistics
        /// </summary>        
        /// <param name="serialNumber">Module serial number</param>
        /// <param name="revision">Module revision</param>
        /// <param name="model">Module model</param>
        /// <param name="manufacturer">Module manufacturer</param>
        public void UpdateCellularModuleStatistics(string serialNumber, string revision, string model, string manufacturer)
        {
            
            this.cellularModuleSerialNumber = serialNumber;
            this.cellularModuleRevision = revision;
            this.cellularModuleModel = model;
            this.cellularModuleManufacturer = manufacturer;
        }

        /// <summary>
        /// Update cellular carrier
        /// </summary>
        /// <param name="carrier">Module carrier</param>
        /// <param name="act">Carrier access technology</param>
        public void UpdateCellularCarrier(string carrier, CellularAccessTechnology act)
        {
            this.cellularCarrier = carrier;
            this.cellularAccessTechnology = act;
        }

        private TimeSpan connectionDuration;

        /// <summary>
        /// Current connection duration
        /// </summary>
        public TimeSpan ConnectionDuration
        {
            get { return connectionDuration; }
        }
                
        private int connectionTransmittedBytes;

        /// <summary>
        /// Connection transmitted bytes
        /// </summary>
        public int ConnectionTransmittedBytes
        {
            get { return connectionTransmittedBytes; }
        }
                
        private int connectionReceivedBytes;

        /// <summary>
        /// Connection received bytes
        /// </summary>
        public int ConnectionReceivedBytes
        {
            get { return connectionReceivedBytes; }
        }

        private IPAddress connectionIPAddress = IPAddress.None;
        
        /// <summary>
        /// IP address assigned to the connection by remote site.
        /// </summary>
        public IPAddress ConnectionIPAddress
        {
            get { return connectionIPAddress; }
        }

        /// <summary>
        /// Clear current connection statistics
        /// </summary>
        public void ClearConnectionStatistics()
        {
            this.connectionDuration = TimeSpan.Zero;
            this.connectionReceivedBytes = 0;
            this.connectionTransmittedBytes = 0;
            this.connectionIPAddress = IPAddress.None;
            if (dataUsage != null)
            {
                dataUsage.SaveDataUsageOnDisconnect();
                StatusManager.Instance.ForceStatusToStorage();
            }
        }

        /// <summary>
        /// Update current connection statistics
        /// </summary>
        /// <param name="txBytes">Bytes transmitted</param>
        /// <param name="rxBytes">Bytes received</param>
        /// <param name="duration">Current connection duration, If zero the connection is not used.</param>
        public void UpdateConnectionStatistics(int txBytes, int rxBytes, TimeSpan duration)
        {
            this.connectionDuration = duration;
            this.connectionTransmittedBytes = txBytes;
            this.connectionReceivedBytes = rxBytes;
            if (dataUsage != null)
            {
                dataUsage.UpdateUsage(txBytes, rxBytes);
                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        /// <summary>
        /// Update current connection IP address
        /// </summary>
        /// <param name="address"></param>
        public void UpdateConnectionIPAddress(IPAddress address)
        {
            this.connectionIPAddress = address;
        }

        /// <summary>
        /// Get GPRS data usage details
        /// </summary>
        private GprsDataUsageDetails dataUsage = null;
        public IGprsDataUsageDetails IGprsDataUsage
        {
            get { return dataUsage; }
        }

        #endregion

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            switch (suspectStatusType)
            {
                case EventSourceLatchOrIsolateType.Offline: return ConfigurationManager.Instance.ControllerConfiguration.LatchOfflineAlarms;
                case EventSourceLatchOrIsolateType.FuseFail: return ConfigurationManager.Instance.ControllerConfiguration.LatchFuseFailAlarms;
                case EventSourceLatchOrIsolateType.SignalFail: return ConfigurationManager.Instance.ControllerConfiguration.LatchSignalFailAlarms;
                case EventSourceLatchOrIsolateType.DeviceSubstitution: return true;
                default: return false;
            }
        }

        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get { return base.IsCurrentlyLatched || latchedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail); }
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = base.CurrentAlarms;
                if (maskedSignalStrength == GprsNetworkSignalStrength.Poor || maskedSignalStrength == GprsNetworkSignalStrength.NoNetwork || 
                    maskedSignalStrength == GprsNetworkSignalStrength.AutoConfigurationIncomplete)
                    flags |= EventSourceLatchOrIsolateType.SignalFail;
                return flags;
            }
        }

        /// <summary>Poll period when the GPRS is connected and the signal strength is POOR -> in seconds</summary>
        internal const int SignalPoorTimerPeriod = 15 * 60 * 1000;

        /// <summary>Poll period when the GPRS signal strength is No Network -> in seconds</summary>
        internal const int NoNetworkTimerPeriod = 2 * 60 * 1000;

        /// <summary>
        /// Masked Signal Strength update timer - insures that the masked signal strength is updated only when this timer has expired. This timer
        /// period is either 15 or 2 mins (see above)
        /// </summary>
        private IPacomTimer maskedSignalStrengthUpdateTimer = null;

        private readonly object maskedSignalStrengthUpdateLock = new object();

        /// <summary>
        /// Masked Signal Strength update timer procedure
        /// </summary>
        /// <param name="state">Not Used</param>
        private void maskedSignalStrengthUpdateTimerProc(object state)
        {
            if (maskedSignalStrengthUpdateTimer.Enabled == true)
                return;

            updateMaskedSignalStrength();
        }

        /// <summary>
        /// Update Masked Signal Strength
        /// </summary>
        private void updateMaskedSignalStrength()
        {
            lock (maskedSignalStrengthUpdateLock)
            {
                GprsNetworkSignalStrength value = signalStrength;
                bool signalFailed = checkSignalStrength(ref value);
                // Set Masked Signal Strength
                setMaskedSignalStrength(value, signalFailed);
            }
        }

        /// <summary>
        /// Check Signal Strength  
        /// </summary>
        /// <param name="value">Get Signal Strength and update it if required</param>
        /// <returns>True if Signal Strength Failed / False otherwise</returns>
        private bool checkSignalStrength(ref GprsNetworkSignalStrength value)
        {
            if (networkRegistration != GprsNetworkRegistration.Registered && networkRegistration != GprsNetworkRegistration.RegisteredRoaming)
            {
                value = GprsNetworkSignalStrength.AutoConfigurationIncomplete;
            }

            bool signalFailed = false;
            if (value == GprsNetworkSignalStrength.Poor || value == GprsNetworkSignalStrength.NoNetwork ||
                value == GprsNetworkSignalStrength.AutoConfigurationIncomplete)
            {
                signalFailed = true;
            }
            return signalFailed;
        }

        #region IGprsExpansionCardStatus Members

        /// <summary>
        /// Get / Set GPRS modem current network registration state
        /// </summary>
        public GprsNetworkRegistration NetworkRegistration
        {
            get { return networkRegistration; }
            set
            {
                if (networkRegistration != value)
                {
                    networkRegistration = value;
                    MaskedSignalStrength = signalStrength;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set GPRS modem current signal strength 
        /// </summary>
        public GprsNetworkSignalStrength SignalStrength
        {
            get { return signalStrength; }
            set
            {
                if (signalStrength != value)
                {
                    signalStrength = value;
                    MaskedSignalStrength = signalStrength;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        public GprsNetworkSignalStrength MaskedSignalStrength
        {
            get { return maskedSignalStrength; }
            set
            {
                lock (maskedSignalStrengthUpdateLock)
                {
                    if (Enabled == false)
                        return;

                    bool signalFailed = checkSignalStrength(ref value);
                    if (signalFailed == true)
                    {
                        bool isNoNetwork = value == GprsNetworkSignalStrength.NoNetwork || value == GprsNetworkSignalStrength.AutoConfigurationIncomplete;
                        if (maskedSignalStrengthUpdateTimer != null && ((maskedSignalStrengthUpdateTimer.Enabled == false) || 
                                                                        (maskedSignalStrengthUpdateTimer.Enabled == true && isNoNetwork == true)))
                        {
                            int dueTime = NoNetworkTimerPeriod;
                            if (value == GprsNetworkSignalStrength.Poor)
                            {
                                dueTime = SignalPoorTimerPeriod;
                            }
                            maskedSignalStrengthUpdateTimer.RunOnce(dueTime);
                            return;
                        }
                    }
                    if (maskedSignalStrength != value)
                    {
                        // Send Signal Strength restore
                        setMaskedSignalStrength(value, signalFailed);
                    }
                    maskedSignalStrengthUpdateTimer.Stop();
                }
            }
        }

        private void setMaskedSignalStrength(GprsNetworkSignalStrength value, bool signalFailed)
        {
            if (maskedSignalStrength != value || signalFailed == true)
            {
                if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail) == false && SuspectPoint == false &&
                    (LatchedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail) == false || signalFailed == true))
                {
                    GprsNetworkSignalStrength previousSignalStrength = maskedSignalStrength;
                    maskedSignalStrength = value;
                    if (signalFailed)
                    {
                        IncrementSuspectCount(EventSourceLatchOrIsolateType.SignalFail);
                        CheckTerminateArming();
                    }
                    else
                    {
                        CheckStopFailToArmTimer();
                    }

                    // Report any GPRS card alarm to front end if not isolated and not latched
                    Parent.TriggerGprsSignalStrengthChanged(this, previousSignalStrength, maskedSignalStrength);
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        #endregion

        /// <summary>
        /// Set the state of device IsolatedAlarms flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="value">New isolated options. If value = EventSourceLatchOrIsolateType.None -> Deisolate all.
        /// If value = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.FuseFail | EventSourceLatchOrIsolateType.SignalFail -> Isolate all or any.
        /// When de-isolating if any of the device inputs is in alarm the alarm will be queued into AlarmManager.
        /// </param>
        /// <returns>True if the command was successfully executed</returns>
        public override bool SetIsolated(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType value)
        {
            if (base.SetIsolated(userAuditInfo, value) == false)
                return false;

            // Mask-out all flags this device does not support
            value &= SupportedIsolateFlags;
            if (value != isolatedAlarms)
            {
                // Signal Low / No Network alarm - Isolate/de-isolate 
                if (isolatedAlarms.BitChanged(value, EventSourceLatchOrIsolateType.SignalFail) == true)
                {
                    isolatedAlarms = isolatedAlarms.ClearFlag(EventSourceLatchOrIsolateType.SignalFail);
                    bool isolated = isolatedAlarms.BitSetAfter(value, EventSourceLatchOrIsolateType.SignalFail);
                    if (isolated == true)
                    {
                        // Isolate option to check (Signal Low / Fail)
                        ResetSuspectCount();
                        latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.SignalFail);
                        lock (maskedSignalStrengthUpdateLock)
                        {
                            setMaskedSignalStrength(GprsNetworkSignalStrength.Good, false);
                        }
                        isolatedAlarms = isolatedAlarms.SetFlag(EventSourceLatchOrIsolateType.SignalFail);
                    }
                    else
                    {
                        // Deisolate option to check
                        updateMaskedSignalStrength();
                    }
                }
                StatusManager.Instance.RequestStatusToStorage();
            }
            return true;
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            GprsExpansionCardStatusStorage statusStorage = new GprsExpansionCardStatusStorage();
            if (statusStorage != null)
            {
                InitializeStatusStorage(statusStorage);
                if (dataUsage != null)
                {
                    dataUsage.SavePreviousStateToStorage(statusStorage);
                }
            }
            return statusStorage;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            Device8201ExpansionEventState deviceState = new Device8201ExpansionEventState();
            InitializeEventState(deviceState);
            deviceState.FuseFail = MaskedFuseFailed;
            deviceState.SignalFail = CommonUtilities.GprsNetworkSignalStrengthToSignalFailState(MaskedSignalStrength);
            return deviceState;
        }

        /// <summary>
        /// Restore masked online, fuse failed, etc. status if required after unlatching the expansion card alarms. Restore only if the
        /// current instantaneous status is Secure (device online, fuse not failed, etc.).
        /// </summary>
        protected override void RestoreAfterUnlatch()
        {
            base.RestoreAfterUnlatch();
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail) == false)
            {
                updateMaskedSignalStrength();
            }
        }

        /// <summary>
        /// Check masked alarms when we restore status from previous stored state
        /// </summary>
        protected override void VerifyMaskedAlarms()
        {
            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail))
            {
                maskedSignalStrength = GprsNetworkSignalStrength.Good;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.SignalFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail) &&
                maskedSignalStrength != GprsNetworkSignalStrength.Poor && maskedSignalStrength != GprsNetworkSignalStrength.NoNetwork &&
				maskedSignalStrength != GprsNetworkSignalStrength.AutoConfigurationIncomplete)
            {
                maskedSignalStrength = GprsNetworkSignalStrength.NoNetwork;
            }
        }

        public override string ToString()
        {
            return String.Format("GPRS Expansion Status [{0}]", this.LogicalId);
        }

        internal override void Cleanup()
        {
            lock (maskedSignalStrengthUpdateLock)
            {
                if (maskedSignalStrengthUpdateTimer != null)
                {
                    if (maskedSignalStrengthUpdateTimer.Enabled == true)
                    {
                        maskedSignalStrengthUpdateTimer.Stop();
                        maskedSignalStrengthUpdateTimerProc(null);
                    }
                    TimerManager.Instance.RemoveTimer(maskedSignalStrengthUpdateTimer);
                    maskedSignalStrengthUpdateTimer = null;
                }
            }
            if (dataUsage != null)
            {
                dataUsage.Dispose();
                dataUsage = null;
            }
        }

        #region IGprsExpansionCardStatus Members


        #endregion
    }
}
