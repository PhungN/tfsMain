﻿using System;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Status
{
    public class DeviceLoopDeviceStatus : DeviceStatusBase
    {
        private DeviceLoopDeviceOfflineStatusType offlineType = DeviceLoopDeviceOfflineStatusType.Offline;

        public DeviceLoopDeviceStatus(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus)
            : base(configuration, parent)
        {
            online = false;
            offlineType = DeviceLoopDeviceOfflineStatusType.SuspectedOffline;
            bootloaderVersion = DefaultBootloaderVersion;
            tamperActive = false;
            maskedTamperActive = false;
            firmwareVersion = DefaultFirmwareVersion;
            serialNumber = DefaultSerialNumber;

            if (previousStatus == null || this.Enabled == false)
                return;

            this.isolatedAlarms = previousStatus.IsolatedAlarms;
            this.latchedAlarms = previousStatus.LatchedAlarms;
            this.DeviceSubstitution = previousStatus.LatchedAlarms.Has(EventSourceLatchOrIsolateType.DeviceSubstitution);
            DeviceStatusStorage prevStatus = previousStatus as DeviceStatusStorage;
            if (prevStatus != null && prevStatus.OfflineType == DeviceLoopDeviceOfflineStatusType.SuspectedOffline)
            {
                this.online = previousStatus.Online;
                this.offlineType = prevStatus.OfflineType;
            }
            base.VerifyMaskedAlarms();
        }

        /// <summary>
        /// Get / Set device online / offline status
        /// </summary>
        public override bool Online
        {
	        get 
	        { 
		         return base.Online;
	        }
	        set 
	        {
                if (offlineType != DeviceLoopDeviceOfflineStatusType.SuspectedOffline &&
                    online == true && value == false) // Device is going offline
                {
                    online = false;

                    // Device is going offline during normal operation
                    if (StatusManager.Instance.SystemStatus == SystemStatusType.NormalOperation)
                    {
                        offlineType = DeviceLoopDeviceOfflineStatusType.SuspectedOffline;
                        // Bring expansion cards offline
                        setExpansionCardsOffline();
                        // Bring device offline
                        Parent.TriggerDeviceSuspectedOffline(this);
                        resetDeviceDoors();
                    }
                }
                else if (offlineType == DeviceLoopDeviceOfflineStatusType.SuspectedOffline &&
                         online == false && value == true && // Device is going online
                         StatusManager.Instance.SystemStatus == SystemStatusType.NormalOperation)
                {
                    this.maskedOnline = false;
                    base.online = false;
                    base.Online = true;
                    offlineType = DeviceLoopDeviceOfflineStatusType.Online;
                }
                else if (online != value)
                {
                    // Send the alarm events
                    base.Online = value;
                    if (online == true)
                    {
                        offlineType = DeviceLoopDeviceOfflineStatusType.Online;
                    }
                    else
                    {
                        offlineType = DeviceLoopDeviceOfflineStatusType.Offline;
                        // Bring expansion cards offline
                        setExpansionCardsOffline();
                        // Bring device offline
                        notifyDeviceInputsSelfTestFail();
                    }
                }
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Device with Logical Id: [{0}], [Set Online] Status -> Unmasked Online Status is: [{1}], OfflineType is: [{2}]",
                                         LogicalId, Online == true ? "online" : "offline", OfflineType);
                });
#endif
                if (online == false && StatusManager.Instance.SystemStatus == SystemStatusType.ConfigurationChanging)
                    StatusManager.Instance.ForceStatusToStorage();
                else
                    StatusManager.Instance.RequestStatusToStorage();
            }
        }

        private void setExpansionCardsOffline()
        {
            // Bring expansion cards offline
            foreach (var expansionCard in StatusManager.Instance.ExpansionCards.Items)
            {
                if (expansionCard.ParentDeviceId == this.LogicalId)
                {
                    expansionCard.SetStatus(Common.ExpansionCardStatus.Offline);
                }
            }
        }

        /// <summary>
        /// Change all inputs for an offline device to Self Test Fail / Fault (see EN 50131-1 claus 8.8.4.1(b) and Table 20)
        /// </summary>
        private void notifyDeviceInputsSelfTestFail()
        {
            int[] deviceInputs = StatusManager.Instance.Inputs.GetInputsForDevice(this.LogicalId);
            foreach (int logicalInputId in deviceInputs)
            {
                InputStatus inputStatus = StatusManager.Instance.Inputs[logicalInputId];
                if (inputStatus != null)
                {
                    inputStatus.UnmaskedStatus = Common.InputStatus.SelfTestFail;
                }
            }
        }

        private void resetDeviceDoors()
        {
            int[] doorIds = ConfigurationManager.Instance.GetDoorIdsForDevice(LogicalId);
            foreach (int doorId in doorIds)
            {
                DoorStatus doorStatus = StatusManager.Instance.Doors[doorId];
                if (doorStatus != null)
                    doorStatus.ResetDoorAgent();
            }
        }

        private void resetDeviceReaders()
        {
            int[] readerIds = ConfigurationManager.Instance.GetReaderIdsForDevice(LogicalId);
            foreach (int readerId in readerIds)
            {
                ReaderStatus readerStatus = StatusManager.Instance.Readers[readerId];
                if (readerStatus != null)
                    readerStatus.ResetReaderAgent();
            }
        }

        /// <summary>
        /// It is time to notify the alarm manager about the device being in offline state for too long
        /// </summary>
        public override void NotifyDeviceOffline()
        {
            if (online == false)
            {
                // Bring suspected offline to online. Make it first online over the underlining property value.                
                online = true;
                if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false &&
                    LatchedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false)
                {
                    maskedOnline = true;
                }
                // Make the offline alarm go out.
                base.Online = false;
                offlineType = DeviceLoopDeviceOfflineStatusType.Offline;
                notifyDeviceInputsSelfTestFail();
            }
        }

        /// <summary>
        /// Initialize the state of status storage instance for all the basic properties
        /// </summary>
        /// <param name="statusStorage">Status Storage instance to initialize</param>
        protected override void InitializeStatusStorage(DeviceStatusStorageBase statusStorage)
        {
            base.InitializeStatusStorage(statusStorage);
            ((DeviceStatusStorage)statusStorage).OfflineType = DeviceLoopDeviceOfflineStatusType.SuspectedOffline;
        }

        /// <summary>
        /// Initialize device information instance from status / configuration information
        /// </summary>
        /// <param name="deviceInformation">Device Information instance</param>
        protected override void InitializeDeviceInformation(DeviceInformation deviceInformation)
        {
            base.InitializeDeviceInformation(deviceInformation);
            deviceInformation.CurrentFirmwareVersion = FirmwareVersion;
            deviceInformation.AvailableFirmwareVersions = new string[1];
            deviceInformation.AvailableFirmwareVersions[0] = deviceInformation.CurrentFirmwareVersion;
        }

        public DeviceLoopDeviceOfflineStatusType OfflineType
        {
            get { return offlineType; }
        }
    }
}
