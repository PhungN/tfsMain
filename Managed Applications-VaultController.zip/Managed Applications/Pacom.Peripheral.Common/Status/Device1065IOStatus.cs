﻿using Pacom.Core.Contracts;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;

namespace Pacom.Peripheral.Common.Status
{
    public class Device1065IOStatus : Device8501Status
    {
        public Device1065IOStatus(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus) :
            base(configuration, parent, previousStatus)
        {
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            Device1065IOEventState deviceState = new Device1065IOEventState();
            InitializeEventState(deviceState);
            deviceState.PowerFail = MaskedPowerState;
            deviceState.BatteryFail = MaskedBatteryState;
            deviceState.BatteryChargerFail = MaskedBatteryChargerFailed;
            return deviceState;
        }
    }
}
