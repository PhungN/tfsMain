﻿using System;
using System.Collections.Generic;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utils;
using Pacom.Peripheral.Macros;

namespace Pacom.Peripheral.Common.Status
{
    public class AreaStatus : StatusBase<AreaStatusList>
    {
        private readonly object pointStateListsLock = new object();
        private readonly object pointIsolatedListLock = new object();

        private PointsList currentModeAlarmedPoints = null;
        private readonly PointsList disarmedModeAlarmPoints = new PointsList();
        private readonly PointsList armedModeAlarmPoints = new PointsList();
        private readonly PointsList unqualifiedAlarmPoints = new PointsList();
        private readonly PointsList isolatedPoints = new PointsList();

        private readonly bool terminateEntryDelayOnSecond = false;
        private readonly bool useMaximumOfRemainingDelayAndExtendedDuration = false;
        private bool readyToArm = false;

        public int AutomaticArmDelayCount { get; set; }
        private IPacomTimer autoArmDelayTimer = null;
        public bool CanDelayAutomaticArming { get; set; }

        public AreaStatus(AreaConfiguration configuration, AreaStatusList parent, AreaStatusStorage previousStatus) :
            base(configuration, parent)
        {
            entryTimer = TimerManager.Instance.CreateTimer(entryDelayExpiredProc);
            alarmConfirmationTimer = TimerManager.Instance.CreateTimer(alarmConfirmationProc);
            lateToCloseTimer = TimerManager.Instance.CreateTimer(lateToCloseTimerProc);
            failToArmTimer = TimerManager.Instance.CreateTimer(failToArmTimerProc);
            AlarmCancelRequired = false;
            DisableConfirmedAlarms = false;
            resetDelayAutomaticArming();
            if (configuration != null)
            {
                enableAlarmConfirmationTime = configuration.EnableAlarmConfirmationTime;
                terminateEntryDelayOnSecond = configuration.EntryDelayExtensionType == EntryDelayExtensionType.ExtendOnceOnlyTerminateEntryDelayOnSecondAlarm ||
                                              configuration.EntryDelayExtensionType == EntryDelayExtensionType.SetNewEntryDelayToMaximumOfRemainingEntryDelayAndExtendedDurationOnceOnlyAndTerminateEntryDelayOnSecond;
                useMaximumOfRemainingDelayAndExtendedDuration = configuration.EntryDelayExtensionType == EntryDelayExtensionType.SetNewEntryDelayToMaximumOfRemainingEntryDelayAndExtendedDurationOnceOnly ||
                                                                configuration.EntryDelayExtensionType == EntryDelayExtensionType.SetNewEntryDelayToMaximumOfRemainingEntryDelayAndExtendedDurationOnceOnlyAndTerminateEntryDelayOnSecond ||
                                                                configuration.EntryDelayExtensionType == EntryDelayExtensionType.BS8243Compliant;
            }

            if (previousStatus == null || Enabled == false)
            {
                updateCurrentAlarmPointList();
            }
            else
            {
                mode = previousStatus.Mode;
                duressActive = previousStatus.DuressActive;
                updateCurrentAlarmPointList();

                forcedDuringDay = previousStatus.ForcedDay;
                forcedDuringIntervalOffset = previousStatus.ForcedIntervalOffset;
                forcedMode = previousStatus.ForcedMode;
                SetHasConfirmedAlarm(previousStatus.HasConfirmedAlarm, ConfigurationManager.SystemUser, false);

                // Update area forced flag
                DayType scheduleDayType;
                int scheduleIntervalOffset;
                AreaScheduleLevel scheduleLevel;
                getCurrentAreaScheduleMode(out scheduleDayType, out scheduleIntervalOffset, out scheduleLevel);
                if (scheduleDayType != forcedDuringDay || scheduleIntervalOffset != forcedDuringIntervalOffset)
                {
                    // When the schedule interval changes revert to schedule mode
                    forcedMode = AreaModeUserForcedType.Normal;
                    forcedDuringDay = DayType.None;
                    forcedDuringIntervalOffset = 0;
                }
            }
            updateReadyToArm();
            PirTestActive = false;
        }

        public override StatusItemType ItemType
        {
            get { return StatusItemType.AreaStatus; }
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            AreaStatusStorage statusStorage = new AreaStatusStorage();
            if (statusStorage != null)
            {
                statusStorage.LogicalId = LogicalId;
                statusStorage.ParentDeviceId = ParentDeviceId;
                statusStorage.ForcedMode = ForcedMode;
                statusStorage.ForcedIntervalOffset = ForcedDuringIntervalOffset;
                statusStorage.ForcedDay = ForcedDuringDay;
                statusStorage.Mode = Mode;
                statusStorage.DuressActive = InDuress;
                statusStorage.HasConfirmedAlarm = HasConfirmedAlarm;
            }
            return statusStorage;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            AreaEventState areaState = new AreaEventState();
            areaState.Id = LogicalId;
            areaState.Arm = Armed;
            areaState.Duress = InDuress;
            areaState.Test = InTestMode;
            areaState.ConfirmedAlarm = HasConfirmedAlarm;
            return areaState;
        }

        /// <summary>
        /// Get display name for this door status item instance without any alarms / isolated alarms
        /// </summary>
        /// <returns>Display Name string.</returns>
        public override string DisplayName
        {
            get
            {
                AreaConfiguration areaConfig = ConfigurationManager.Instance.GetAreaConfiguration(LogicalId);
                if (areaConfig != null)
                    return areaConfig.GetName();
                return string.Empty;
            }
        }

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            if (suspectStatusType == EventSourceLatchOrIsolateType.AreaConfirmedAlarm)
                return true;
            return false;
        }

        /// <summary>
        /// Indicates that the area status instance "Area Confirmed Alarm" is latched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get { return latchedAlarms.Has(EventSourceLatchOrIsolateType.AreaConfirmedAlarm); }
        }

        /// <summary>
        /// Returns the current latch status for this status item instance and the [latchFlagToCheck]
        /// </summary>
        /// <param name="latchFlagToCheck">The status item laarm flag that needs to be checked for latching</param>
        /// <returns>The latch status for this status item.</returns>
        public override EventSourceLatchStatus GetLatchStatusFor(EventSourceLatchOrIsolateType latchFlagToCheck)
        {
            if (latchFlagToCheck == EventSourceLatchOrIsolateType.None)
                return EventSourceLatchStatus.NotLatched;

            if (latchedAlarms.Has(latchFlagToCheck) == false)
                return EventSourceLatchStatus.NotLatched;

            return EventSourceLatchStatus.ConfiguredToBeLatched;
        }

        /// <summary>
        /// Get "Area Confirmed Alarm" state
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                if (hasConfirmedAlarm == true)
                    return EventSourceLatchOrIsolateType.AreaConfirmedAlarm;
                return EventSourceLatchOrIsolateType.None;
            }
        }

        /// <summary>
        /// Get the string representation of the alarms / isolated alarms / latched alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        protected virtual string AlarmFlagsAsString(EventSourceLatchOrIsolateType alarms)
        {
            if (alarms == EventSourceLatchOrIsolateType.None)
                return string.Empty;
            string alarmsAsString = " ";

            foreach (EventSourceLatchOrIsolateType eventSource in EnumHelper.GetValues<EventSourceLatchOrIsolateType>())
            {
                if (eventSource == EventSourceLatchOrIsolateType.None)
                    continue;

                if (alarms.Has(eventSource) == true)
                    alarmsAsString = string.Format("{0}{1} ", alarmsAsString, ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
            }
            return alarmsAsString;
        }

        /// <summary>
        /// Get the string representation of the alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public override string AlarmsAsString
        {
            get { return AlarmFlagsAsString(CurrentAlarms); }
        }

        /// <summary>
        /// Get the string representation of the latched alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public override string LatchedAlarmsAsString
        {
            get { return AlarmFlagsAsString(latchedAlarms); }
        }

        /// <summary>
        /// Get the array of strings representation for the alarms for this point
        /// </summary>
        protected virtual string[] AlarmFlagsAsStringArray(EventSourceLatchOrIsolateType alarms)
        {
            if (alarms == EventSourceLatchOrIsolateType.None)
                return new string[0];
            List<string> alarmsList = new List<string>();
            foreach (EventSourceLatchOrIsolateType eventSource in EnumHelper.GetValues<EventSourceLatchOrIsolateType>())
            {
                if (eventSource == EventSourceLatchOrIsolateType.None)
                    continue;

                if (alarms.Has(eventSource) == true)
                    alarmsList.Add(ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
            }
            return alarmsList.ToArray();
        }

        /// <summary>
        /// Get the string array representation of the current alarms for this point
        /// </summary>
        public override string[] AlarmsAsStringArray
        {
            get { return AlarmFlagsAsStringArray(CurrentAlarms); }
        }

        /// <summary>
        /// Get the string representation of the latched alarms for this point as an array
        /// </summary>
        public override string[] LatchedAlarmsAsStringArray
        {
            get { return AlarmFlagsAsStringArray(latchedAlarms); }
        }

        #region Forced and current area schedule status

        private void getCurrentAreaScheduleMode(out Core.Contracts.DayType day, out int intervalOffset, out AreaScheduleLevel level)
        {
            day = DayType.None;
            intervalOffset = 0;
            level = AreaScheduleLevel.Armed;

            AreaConfiguration areaConfig = ConfigurationManager.Instance.GetAreaConfiguration(this.LogicalId);
            if (areaConfig == null || areaConfig.NormalScheduleId <= 0)
                return;
            Pacom8003AreaSchedule areaSchedule = ConfigurationManager.Instance.GetAreaSchedule(areaConfig.NormalScheduleId);
            if (areaSchedule == null)
                return;

            day = areaSchedule.ScheduleDay;
            intervalOffset = areaSchedule.ScheduleIntervalOffset;
            level = areaSchedule.ScheduledLevel;
        }

        private Pacom.Core.Contracts.DayType forcedDuringDay = DayType.None;

        public Pacom.Core.Contracts.DayType ForcedDuringDay
        {
            get { return forcedDuringDay; }
        }

        private int forcedDuringIntervalOffset = 0;

        public int ForcedDuringIntervalOffset
        {
            get { return forcedDuringIntervalOffset; }
        }

        private AreaModeUserForcedType forcedMode = AreaModeUserForcedType.Normal;

        public AreaModeUserForcedType ForcedMode
        {
            get { return forcedMode; }
        }

        /// <summary>
        /// This method restores area mode to scheduled.
        /// </summary>
        /// <param name="newForcedMode"></param>
        public void RestoreForcedToNormal()
        {
            if (forcedMode != AreaModeUserForcedType.Normal)
            {
                forcedMode = AreaModeUserForcedType.Normal;
                forcedDuringDay = DayType.None;
                forcedDuringIntervalOffset = 0;
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Setting area forced schedule state to Day:{0}, Interval: {1} Mode:{2}",
                        forcedDuringDay.ToString(), forcedDuringIntervalOffset, forcedMode.ToString());
                });
#endif
                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        /// <summary>
        /// This method sets area forced mode to UserForced.
        /// </summary>
        /// <param name="newForcedMode"></param>
        /// <param name="newForcedDuringDay"></param>
        /// <param name="newForcedDuringIntervalOffset"></param>
        public void SetForcedToUser(Pacom.Core.Contracts.DayType newForcedDuringDay, int newForcedDuringIntervalOffset)
        {
            if (forcedMode != AreaModeUserForcedType.UserForced)
            {
                forcedMode = AreaModeUserForcedType.UserForced;
                forcedDuringDay = newForcedDuringDay;
                forcedDuringIntervalOffset = newForcedDuringIntervalOffset;
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("*** Setting area forced schedule state to Day:{0}, Interval: {1} Mode:{2} ***",
                        forcedDuringDay.ToString(), forcedDuringIntervalOffset, forcedMode.ToString());
                });
#endif
                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        #endregion

        private AreaScheduleLevel mode = AreaScheduleLevel.Armed;

        public AreaScheduleLevel Mode
        {
            get { return mode; }
        }

        /// <summary>
        /// Set area mode: Arm / Disarm
        /// </summary>
        /// <param name="value">New area mode.</param>
        /// <param name="userAuditInfo">User that is changing the area mode.</param>
        /// <returns></returns>
        internal bool SetMode(AreaScheduleLevel value, UserAuditInfo userAuditInfo)
        {
            return SetMode(value, userAuditInfo, null);
        }

        /// <summary>
        /// Set area mode: Arm / Disarm
        /// </summary>
        /// <param name="value">New area mode.</param>
        /// <param name="userAuditInfo">User that is changing the area mode.</param>
        /// <param name="deisolatedPointDisplayNameList">The deisolated points display name list</param>
        /// <returns></returns>
        internal bool SetMode(AreaScheduleLevel value, UserAuditInfo userAuditInfo, List<string> deisolatedPointDisplayNameList)
        {
            if (Enabled == false || mode == value || userAuditInfo == null)
                return false;

            AlarmCancelRequired = false;
            hasEntryDelayedConfirmedAlarm = false;
            bool forced = userAuditInfo.OriginatingUserId == StatusConsts.ScheduleUser;
            if (forcedMode == AreaModeUserForcedType.Normal && forced == true)
            {
                DayType currentScheduleDay;
                int currentScheduleIntervalOffset;
                AreaScheduleLevel currentLevel;
                getCurrentAreaScheduleMode(out currentScheduleDay, out currentScheduleIntervalOffset, out currentLevel);
                SetForcedToUser(currentScheduleDay, currentScheduleIntervalOffset);
            }
            else if (value == AreaScheduleLevel.Disarmed)
            {
                RestoreForcedToNormal();
            }

            if (inTestMode == true)
            {
                SetTestMode(userAuditInfo, false, false);
                Parent.TriggerTestModeExited(this, userAuditInfo);
                inTestMode = false;
                if (PirTestActive)
                {
                    StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.WarnTestMode, new List<int>() { LogicalId });
                    StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.ExitTestMode, new List<int>() { LogicalId });
                }
            }

            mode = value;
            restoreAreaConfirmedAlarm(userAuditInfo);
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
            {
                return string.Format("Area {0} Mode changed to:{1}. Forced changed to Day:{2}, Interval:{3} Forced Mode:{4}",
                    this.LogicalId, mode.ToString(), forcedDuringDay.ToString(), forcedDuringIntervalOffset, forcedMode.ToString());
            });
#endif
            if (mode == AreaScheduleLevel.Disarmed && ConfigurationManager.Instance.ControllerConfiguration.DeisolateAllPointsInAlarmWhenDisarming == true)
            {
                // Deisolate all points in area (inputs / outputs / readers / doors)
                foreach (var pointStatus in isolatedPoints.ToList())
                {
                    if (ConfigurationManager.Instance.IsKeypadInENMode == true && deisolatedPointDisplayNameList != null)
                    {
                        deisolatedPointDisplayNameList.Add(pointStatus.DisplayIsolatedName);
                    }
                    pointStatus.Deisolate(userAuditInfo);
                }

                // Check if all areas are disarmed and if so, deisolate all device
                Parent.DeisolateAllDeviceAlarmsIfRequired(userAuditInfo, deisolatedPointDisplayNameList);
            }
            resetAllSuspectCount();
            discardPendingEventsForArea();
            updateCurrentAlarmPointList();
            StopLateToCloseTimer();
            StopFailToArmTimer();
            Parent.TriggerAreaModeChanged(this, userAuditInfo);
            updateReadyToArm();
            MacroControl.Instance.EnqueueAreaModeChanged(LogicalId, userAuditInfo.OriginatingUserId);
            StatusManager.Instance.RequestStatusToStorage();
            DisableConfirmedAlarms = false;
            resetDelayAutomaticArming();
            return true;
        }

        public bool InDuress
        {
            get
            {
                return duressActive;
            }
        }

        private bool inTestMode = false;
        public bool InTestMode
        {
            get
            {
                return inTestMode;
            }
            set
            {
                inTestMode = value;
            }
        }

        private bool duressActive = false;
        public void SetDuress(bool duressActive)
        {
            if (this.duressActive != duressActive)
            {
                this.duressActive = duressActive;
                Parent.TriggerAreaDuressModeChanged(this, duressActive);
                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        public bool PirTestActive { get; private set; }

        /// <summary>
        /// Set / Reset Test Mode for area
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the Enter / Exit Test Mode area(s) action.</param>
        /// <param name="testModeActive"></param>
        /// <param name="forceEnter">True when PIR inputs test activated from macro</param>
        internal void SetTestMode(UserAuditInfo userAuditInfo, bool testModeActive, bool forceEnter)
        {
            if (Enabled == false || (mode == AreaScheduleLevel.Armed && forceEnter == false) || userAuditInfo == null)
                return;

            PirTestActive = testModeActive && forceEnter;
            if (inTestMode != testModeActive)
            {
                restoreAreaConfirmedAlarm(userAuditInfo);
                discardPendingEventsForArea();

                List<IStatusItem> areaInputs = StatusManager.Instance.Inputs.GetInputsInArea(LogicalId);
                if (areaInputs != null && areaInputs.Count > 0)
                {
                    foreach (var input in areaInputs)
                    {
                        input.ResetSuspectCount();
                        input.Deisolate(userAuditInfo);
                        input.Unlatch(userAuditInfo);

                        InputStatus inputStatus = input as InputStatus;
                        switch (inputStatus.MaskedStatus)
                        {
                            case Common.InputStatus.Alarm:
                            case Common.InputStatus.Short:
                            case Common.InputStatus.Open:
                            case Common.InputStatus.Masking:
                            case Common.InputStatus.RangeReduction:
                            case Common.InputStatus.MaskingAndRangeReduction:
                            case Common.InputStatus.AlarmAndMasking:
                            case Common.InputStatus.AlarmAndRangeReduction:
                            case Common.InputStatus.AlarmAndMaskingAndRangeReduction:
                                StatusManager.Instance.Inputs.TriggerChangedMaskedStatus(inputStatus, Common.InputStatus.Secure, inputStatus.MaskedStatus);
                                break;
                        }
                    }
                }

                List<IStatusItem> areaOutputs = StatusManager.Instance.Outputs.GetOutputsInArea(LogicalId);
                if (areaOutputs != null && areaOutputs.Count > 0)
                {
                    foreach (var outputStatus in areaOutputs)
                    {
                        outputStatus.Deisolate(userAuditInfo);
                        (outputStatus as OutputStatus).SetRequestedState(false, userAuditInfo);
                    }
                }

                inTestMode = testModeActive;
                foreach (var input in areaInputs)
                {
                    InputStatus inputStatus = input as InputStatus;
                    switch (inputStatus.MaskedStatus)
                    {
                        case Common.InputStatus.Alarm:
                        case Common.InputStatus.Short:
                        case Common.InputStatus.Open:
                        case Common.InputStatus.Masking:
                        case Common.InputStatus.RangeReduction:
                        case Common.InputStatus.MaskingAndRangeReduction:
                        case Common.InputStatus.AlarmAndMasking:
                        case Common.InputStatus.AlarmAndRangeReduction:
                        case Common.InputStatus.AlarmAndMaskingAndRangeReduction:
                            StatusManager.Instance.Inputs.TriggerChangedMaskedStatus(inputStatus, inputStatus.MaskedStatus, Common.InputStatus.Secure);
                            break;
                    }
                }

                if (testModeActive)
                {
                    lock (testedListLock)
                    {
                        testedInputs = new List<TestedInputDetailsInternal>();
                        untestedInputs = new List<int>();
                        foreach (var input in areaInputs)
                            untestedInputs.Add(input.LogicalId);
                        StatusManager.Instance.Inputs.ChangedStatus += new EventHandler<StatusManagerInputChangedStatusEventArgs>(onTestInputs_ChangedStatus);
                    }
                }
                else
                {
                    lock (testedListLock)
                    {
                        StatusManager.Instance.Inputs.ChangedStatus -= new EventHandler<StatusManagerInputChangedStatusEventArgs>(onTestInputs_ChangedStatus);
                        testedInputs = null;
                        untestedInputs = null;
                        StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.WarnTestMode, new List<int>() { LogicalId });
                        StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.ExitTestMode, new List<int>() { LogicalId });
                    }
                }

                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        private readonly object testedListLock = new object();
        List<TestedInputDetailsInternal> testedInputs = null;
        List<int> untestedInputs = null;

        internal void GetTestedInputDetails(out TestedInputDetailsInternal[] testedInputs, out int[] untestedInputs)
        {
            lock (testedListLock)
            {
                if (this.testedInputs == null)
                    testedInputs = null;
                else
                    testedInputs = this.testedInputs.ToArray();

                if (this.untestedInputs == null)
                    untestedInputs = null;
                else
                    untestedInputs = this.untestedInputs.ToArray();
            }
        }

        private void onTestInputs_ChangedStatus(object sender, StatusManagerInputChangedStatusEventArgs e)
        {
            if (inTestMode == false)
                return;
            lock (testedListLock)
            {
                int inputId = e.InputStatus.LogicalId;
                if (untestedInputs.Contains(inputId))
                {
                    if ((e.Status == Pacom.Peripheral.Common.InputStatus.Secure && e.PreviousStatus == Pacom.Peripheral.Common.InputStatus.Alarm) ||
                        (e.Status == Pacom.Peripheral.Common.InputStatus.Alarm && e.PreviousStatus == Pacom.Peripheral.Common.InputStatus.Secure))
                    {
                        untestedInputs.Remove(inputId);
                        testedInputs.Add(new TestedInputDetailsInternal() { InputId = inputId, AlarmedState = e.Status });
                        Parent.TriggerInputTested(this);
                    }
                }
            }
        }

        public List<TestedInputDetails> TestedInputs
        {
            get
            {
                List<TestedInputDetails> result;
                lock (testedListLock)
                {
                    if (testedInputs == null)
                    {
                        result = null;
                    }
                    else
                    {
                        result = new List<TestedInputDetails>(testedInputs.Count);
                        foreach (var testedInput in testedInputs)
                        {
                            Status.InputStatus input = StatusManager.Instance.Inputs[testedInput.InputId];
                            if (input != null)
                                result.Add(new TestedInputDetails(input, LogicalId, testedInput.AlarmedState));
                        }
                    }
                }
                return result;
            }
        }

        public List<IStatusItem> UntestedInputs
        {
            get
            {
                List<IStatusItem> result;
                lock (testedListLock)
                {
                    if (untestedInputs == null)
                    {
                        result = null;
                    }
                    else
                    {
                        result = new List<IStatusItem>(untestedInputs.Count);
                        foreach (int inputId in untestedInputs)
                        {
                            Status.InputStatus input = StatusManager.Instance.Inputs[inputId];
                            if (input != null)
                                result.Add(input);
                        }
                    }
                }
                return result;
            }
        }

        /// <summary>
        /// Get area outputs
        /// </summary>
        public List<IStatusItem> GetOutputs
        {
            get { return StatusManager.Instance.Outputs.GetOutputsInArea(LogicalId); }
        }

        /// <summary>
        /// Reset the SuspectCount for all area children (inputs, etc.) and for all devices if the area is disarmed
        /// </summary>
        private void resetAllSuspectCount()
        {
            // Reset SuspectCount for all area inputs
            List<IStatusItem> areaInputs = StatusManager.Instance.Inputs.GetInputsInArea(LogicalId);
            if (areaInputs != null && areaInputs.Count > 0)
            {
                foreach (var inputStatus in areaInputs)
                    inputStatus.ResetSuspectCount();
            }

            // Reset SuspectCount for all devices
            var devices = StatusManager.Instance.Devices.Items;
            foreach (var device in devices)
            {
                if (device.Enabled == true)
                    device.ResetSuspectCount();
            }

            // Reset SuspectCount for controller
            StatusManager.Instance.Controller.ResetSuspectCount();
        }

        private void updateCurrentAlarmPointList()
        {
            if (mode == AreaScheduleLevel.Armed)
                currentModeAlarmedPoints = armedModeAlarmPoints;
            else
                currentModeAlarmedPoints = disarmedModeAlarmPoints;
        }

        /// <summary>
        /// Returns True if area is Armed / False otherwise
        /// </summary>
        public bool Armed
        {
            get { return Mode == AreaScheduleLevel.Armed; }
        }

        /// <summary>
        /// Returns True if area is Disarmed / False otherwise
        /// </summary>
        public bool Disarmed
        {
            get { return Mode == AreaScheduleLevel.Disarmed; }
        }

        /// <summary>
        /// Isolate area.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Isolate(UserAuditInfo userAuditInfo)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return "Area does not implement isolate.";
            });
        }

        /// <summary>
        /// Deisolate area.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Deisolate(UserAuditInfo userAuditInfo)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return "Area does not implement deisolate.";
            });
        }

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        public override bool CanIsolate(UserAccessLevel level)
        {
            return false;
        }

        /// <summary>
        /// True if this status item can be de-isolated at the specifed access level
        /// </summary>
        public override bool CanDeisolate(UserAccessLevel level)
        {
            return false;
        }

        /// <summary>
        /// Unlatch inputs and deactivate any outputs in area.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        /// <returns>True if the area is enabled, false otherwise.</returns>
        public override bool Unlatch(UserAuditInfo userAuditInfo)
        {
            if (Enabled == false)
                return false;

            AreaConfiguration areaConfig = ConfigurationManager.Instance.GetAreaConfiguration(LogicalId);
            if (areaConfig != null)
            {
                if (areaConfig.Inputs != null)
                {
                    foreach (var input in areaConfig.Inputs)
                    {
                        StatusManager.Instance.Inputs[input.Id].Unlatch(userAuditInfo);
                    }
                }
                if (areaConfig.Outputs != null)
                {
                    foreach (var output in areaConfig.Outputs)
                    {
                        StatusManager.Instance.Outputs[output.Id].SetRequestedState(false, userAuditInfo);
                    }
                }
            }
            restoreAreaConfirmedAlarm(userAuditInfo);
            return true;
        }

        /// <summary>
        /// Restore area confirmed alarm or any other alarms
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        /// <param name="options">Latched alarms to unlatch (restore)</param>
        /// <returns>True if the point has been unlatched</returns>
        public override bool Unlatch(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options)
        {
            if (options.Empty() == true)
                return false;

            if (options.Has(EventSourceLatchOrIsolateType.AreaConfirmedAlarm) == true)
            {
                restoreAreaConfirmedAlarm(userAuditInfo);
                return true;
            }
            return Unlatch(userAuditInfo);
        }

        /// <summary>
        /// Return alarmed points for the area mode.
        /// </summary>
        public PointsList AlarmedPoints
        {
            get { return this.currentModeAlarmedPoints; }
        }

        /// <summary>
        /// Return alarmed points for the armed mode.
        /// </summary>
        public PointsList ArmedAlarmedPoints
        {
            get { return this.armedModeAlarmPoints; }
        }

        /// <summary>
        /// Return alarmed points for the disarmed mode.
        /// </summary>
        public PointsList DisarmedAlarmedPoints
        {
            get { return this.disarmedModeAlarmPoints; }
        }

        /// <summary>
        /// Returns points that either are currently or would cause an unqualified alarm in armed mode.
        /// </summary>
        public PointsList UnqualifiedAlarmPoints
        {
            get { return this.unqualifiedAlarmPoints; }
        }

        /// <summary>
        /// Return isolated points for the area.
        /// </summary>
        public PointsList IsolatedPoints
        {
            get { return this.isolatedPoints; }
        }

        /// <summary>
        /// Add point to the armed list for this area.
        /// </summary>
        /// <param name="point"></param>
        internal void AddPointToArmedList(IStatusItem point)
        {
            if (Enabled == false)
                return;

#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Adding {0} point with Id {1} to armed alarm list", point.ItemType.AsDescription(), point.LogicalId);
            });
#endif

            lock (pointStateListsLock)
            {
                bool sendEvent = false;

                if (armedModeAlarmPoints.Count == 0)
                    sendEvent = true;
                unqualifiedAlarmPoints.Remove(point);
                armedModeAlarmPoints.Add(point);

                if (sendEvent == true)
                {
                    if (FailedToArm == false)
                    {
                        ConfigurationManager configuration = ConfigurationManager.Instance;
                        InputConfiguration inputConfig = configuration.GetInputConfiguration(point.LogicalId);
                        if ((configuration.ControllerConfiguration.KeypadOperationalMode == KeypadOperationalMode.CustomerSpecific1 &&
                            inputConfig.ReportPointWhenAreaArmed && inputConfig.AreaId == LogicalId) == false)
                        {
                            Parent.CheckTerminateArming(LogicalId);
                        }
                    }
                    if (mode == AreaScheduleLevel.Armed)
                    {
                        // Send area alarmed event
                        Parent.TriggerAreaAlarmed(this);
                    }
                }
            }
            updateReadyToArm();
        }

        internal void AddPointToUnqualifiedList(IStatusItem point)
        {
            if (Enabled == false)
                return;

#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Adding {0} point with Id {1} to unqualified alarm list", point.ItemType.AsDescription(), point.LogicalId);
            });
#endif

            lock (pointStateListsLock)
            {
                unqualifiedAlarmPoints.Add(point);
            }
            updateReadyToArm();
        }

        /// <summary>
        /// Add point to the disrmed list for thius area.
        /// </summary>
        /// <param name="point"></param>
        internal void AddPointToDisarmedList(IStatusItem point)
        {
            if (Enabled == false)
                return;

#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Adding {0} point with Id {1} to disarmed alarm list", point.ItemType.AsDescription(), point.LogicalId);
            });
#endif

            lock (pointStateListsLock)
            {
                bool sendEvent = false;

                if (disarmedModeAlarmPoints.Count == 0)
                    sendEvent = true;
                disarmedModeAlarmPoints.Add(point);

                if (sendEvent == true && mode == AreaScheduleLevel.Disarmed)
                {
                    // Send area alarmed event
                    Parent.TriggerAreaAlarmed(this);
                }
            }
            updateReadyToArm();
        }

        /// <summary>
        /// Remove point from the armed list for this area.
        /// </summary>
        internal void RemovePointFromArmedList(IStatusItem point)
        {
            if (Enabled == false)
                return;

#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Removing {0} point with Id {1} from armed alarm list", point.ItemType.AsDescription(), point.LogicalId);
            });
#endif

            lock (pointStateListsLock)
            {
                bool sendEvent = false;

                int previousCounter = armedModeAlarmPoints.Count;
                armedModeAlarmPoints.Remove(point);
                unqualifiedAlarmPoints.Remove(point);
                sendEvent = previousCounter == 1 && armedModeAlarmPoints.Count == 0;
                if (sendEvent == true)
                {
                    if (StatusManager.Instance.AnyDeviceAlarms == false)
                    {
                        StopFailToArmTimer();
                    }
                    if (mode == AreaScheduleLevel.Armed)
                    {
                        // Send Area restored event
                        Parent.TriggerAreaRestored(this);
                    }
                }
            }
            updateReadyToArm();
        }

        /// <summary>
        /// Remove point from the disarmed list for this area.
        /// </summary>
        internal void RemovePointFromDisarmedList(IStatusItem point)
        {
            if (Enabled == false)
                return;

#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Removing {0} point with Id {1} from disarmed alarm list", point.ItemType.AsDescription(), point.LogicalId);
            });
#endif

            lock (pointStateListsLock)
            {
                bool sendEvent = false;

                int previousCounter = disarmedModeAlarmPoints.Count;
                disarmedModeAlarmPoints.Remove(point);
                sendEvent = previousCounter == 1 && disarmedModeAlarmPoints.Count == 0;
                if (sendEvent == true && mode == AreaScheduleLevel.Disarmed)
                {
                    // Send Area restored event
                    Parent.TriggerAreaRestored(this);
                }
            }
            updateReadyToArm();
        }

        internal void AddPointToIsolatedList(IStatusItem point)
        {
            if (Enabled == false)
                return;

#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Adding {0} point with Id {1} to isolated list", point.ItemType.AsDescription(), point.LogicalId);
            });
#endif
            lock (pointIsolatedListLock)
            {
                isolatedPoints.Add(point);
            }
        }

        internal void RemovePointFromIsolatedList(IStatusItem point)
        {
            if (Enabled == false)
                return;

#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Removing {0} point with Id {1} from isolated list", point.ItemType.AsDescription(), point.LogicalId);
            });
#endif

            lock (pointIsolatedListLock)
            {
                isolatedPoints.Remove(point);
            }
        }

        /// <summary>
        /// Area is alarmed when any point assigned to it is in alarm state.
        /// </summary>
        public bool Alarmed
        {
            get
            {
                if (Enabled == false)
                    return false;
                return currentModeAlarmedPoints.Count > 0 || CurrentAlarms.Empty() == false;
            }
        }

        private void updateReadyToArm()
        {
            bool previousReadyToArm = readyToArm;
            readyToArm = (mode == AreaScheduleLevel.Disarmed && AlarmedPoints.Count == 0 && ArmedAlarmedPoints.Count == 0);

            if (readyToArm)
            {
                List<IStatusItem> unqualifiedAlarmPoints = UnqualifiedAlarmPoints.ToList();
                RemovePointsToIgnore(unqualifiedAlarmPoints);
                readyToArm = (unqualifiedAlarmPoints.Count == 0);
            }

            if (previousReadyToArm != readyToArm)
                Parent.TriggerReadyToArmChanged(this, readyToArm);
        }

        public static void RemovePointsToIgnore(List<IStatusItem> pointsList)
        {
            for (int i = 0; i < pointsList.Count; i++)
            {
                Pacom.Peripheral.Common.Status.InputStatus inputStatus = pointsList[i] as Pacom.Peripheral.Common.Status.InputStatus;
                if (inputStatus == null)
                    continue;
                InputConfiguration inputConfiguration = ConfigurationManager.Instance.GetInputConfiguration(inputStatus.LogicalId);
                if (inputConfiguration == null)
                    continue;
                if (inputConfiguration.RequiredToBeSecureWhenArming == false)
                {
                    pointsList.RemoveAt(i);
                    i--;
                }
            }
        }

        public bool ReadyToArm
        {
            get { return readyToArm; }
        }

        #region Pending Alarms

        private readonly List<InputStatus> pendingAlarmPoints = new List<InputStatus>();
        private readonly IPacomTimer entryTimer = null;
        private int entryDelay1Remaining = 0;
        private int entryDelay2Remaining = 0;
        private int extendedEntryDelayRemaining = 0;
        private const int entryTimerDueTime = 1000;
        public EntryTimerState EntryTimerState { get; private set; }

        public bool ExitTimerRunning
        {
            get
            {
                return Parent.IsExitDelayRunningForArea(LogicalId);
            }
        }

        internal bool AddPointToPendingList(InputStatus input, bool extendEntryDelay)
        {
            lock (pointStateListsLock)
            {
                bool found = false;
                foreach (InputStatus point in pendingAlarmPoints)
                {
                    if (point == input)
                    {
                        found = true;
                        break;
                    }
                }
                if (found == false)
                {
                    pendingAlarmPoints.Add(input);
                }

                bool useSequentialConfirmation = enableAlarmConfirmationTime == true;
                if (input.TriggersEntryDelay == true && useSequentialConfirmation == true &&
                    input.ConfirmedAlarmType == ConfirmedAlarmType.BS8243Compliant)
                {
                    // The alarm from the input point that triggered the entry delay will be marked as Unconfirmed (BS 8243:2010) if it is the 1st entry delayed alarm 
                    // or the area has no confirmed alarm or confirmation timer is not running or unconfirmed alarm source is null or this input point can't confirm the
                    // previous alarm (8502 input point that triggers entry delay and it's Tamper is alaready in Alarm).
                    if (hasConfirmedAlarm == true || entryTimer.Enabled == true || (ConfirmationTimerRunning == true && unconfirmedAlarmSource != null &&
                                                                                    unconfirmedAlarmSource != input &&
                                                                                    input.GetConfirmedAlarmType(unconfirmedAlarmSource, this) == ConfirmedType.Confirmed))
                    {
                        if (DisableConfirmedAlarms)
                        {
                            input.ConfirmedType = ConfirmedType.Unconfirmed;
                        }
                        else
                        {
                            input.ConfirmedType = ConfirmedType.Confirmed;
                            hasEntryDelayedConfirmedAlarm = true;
                        }
                    }
                    else
                    {
                        input.ConfirmedType = ConfirmedType.Unconfirmed;
                    }
                }

                AreaConfiguration areaConfiguration = ConfigurationManager.Instance.GetAreaConfiguration(LogicalId);
                if (entryTimer.Enabled == false)
                {
                    entryDelay1Remaining = areaConfiguration.EntryDelay1Milliseconds / 1000;
                    entryDelay2Remaining = areaConfiguration.EntryDelay2Milliseconds / 1000;
                    extendedEntryDelayRemaining = 0;
                    terminateEntryDelay = false;
                    entryDelayExtended = false;
                    hasEntryDelayedConfirmedAlarm = ConfirmationTimerRunning && unconfirmedAlarmSource != null && unconfirmedAlarmSource != input &&
                                                    input.GetConfirmedAlarmType(unconfirmedAlarmSource, this) == ConfirmedType.Confirmed;

                    if (entryDelay1Remaining > 0)
                    {
                        EntryTimerState = EntryTimerState.EntryTimer1Running;
                        entryTimer.Change(entryTimerDueTime, entryTimerDueTime);
                    }
                    else if (entryDelay2Remaining > 0)
                    {
                        EntryTimerState = EntryTimerState.EntryTimer2Running;
                        entryTimer.Change(entryTimerDueTime, entryTimerDueTime);
                    }
                    Parent.TriggerAreaChangedEntryDelayedState(this);
                    MacroControl.Instance.EnqueueAreaAlarm(LogicalId, MacroAreaAlarmType.AreaEntryDelay, false);
                    return false;
                }

                if (found == false && input.TriggersEntryDelay == false && DisableConfirmedAlarms == false)
                    hasEntryDelayedConfirmedAlarm = true;
                else if (input.TriggersEntryDelay == true)
                    return false;

                int remainingEntryDelay = entryDelay1Remaining + entryDelay2Remaining + extendedEntryDelayRemaining;
                if (remainingEntryDelay <= 0)
                    return false;

                if (useSequentialConfirmation == true && input.ConfirmedAlarmType == ConfirmedAlarmType.BS8243Compliant)
                {
                    input.ConfirmedType = DisableConfirmedAlarms == true ? ConfirmedType.Unconfirmed : ConfirmedType.Confirmed;
                }

                if (terminateEntryDelay == false && EntryTimerState == EntryTimerState.ExtendedEntryTimerRunning &&
                    areaConfiguration.EntryDelayExtensionType == EntryDelayExtensionType.BS8243Compliant)
                {
                    terminateEntryDelay = true;
                }

                if (terminateEntryDelay == false)
                {
                    terminateEntryDelay = terminateEntryDelayOnSecond;
                    if (extendEntryDelay == true && entryDelayExtended == false)
                    {
                        // Allow for an off route input point to extend the entry delay only once
                        entryDelayExtended = true;
                        int extendBy = areaConfiguration.EntryDelayExtendBy / 1000;

                        entryTimer.Stop();
                        if (useMaximumOfRemainingDelayAndExtendedDuration == false)
                            extendedEntryDelayRemaining = extendBy;
                        else if (remainingEntryDelay < extendBy)
                            extendedEntryDelayRemaining = extendBy - remainingEntryDelay;
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Area [{0}] -> [AddPointToPendingList] -> Entry Delay Extended by Off-Route Input: [{1}]", DisplayName, input.DisplayName);
                        });
                        entryTimer.Change(0, entryTimerDueTime);
                    }
                }
                else
                {
                    // This is the 2nd detector off route that triggered so terminate entry delay and send all alarms
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Area [{0}] -> [AddPointToPendingList] -> Entry Delay Terminated by Off-Route Input: [{1}]", DisplayName, input.DisplayName);
                    });
                    Parent.TriggerAreaChangedEntryDelayedState(this);
                    return true;
                }
            }
            return false;
        }

        private void entryDelayExpiredProc(object state)
        {
            lock (pointStateListsLock)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("... E1:{0} E2:{1} E3:{2}", entryDelay1Remaining, entryDelay2Remaining, extendedEntryDelayRemaining);
                });
                if (EntryTimerState == EntryTimerState.EntryTimer1Running)
                {
                    entryDelay1Remaining--;
                    if (entryDelay1Remaining <= 0)
                        EntryTimerState = EntryTimerState.EntryTimer2Running;
                }
                else if (EntryTimerState == EntryTimerState.EntryTimer2Running)
                {
                    entryDelay2Remaining--;
                    if (entryDelay2Remaining <= 0)
                    {
                        if (extendedEntryDelayRemaining <= 0)
                        {
                            SendPendingEventsForArea();
                            EntryTimerState = EntryTimerState.NotRunning;
                        }
                        else
                        {
                            EntryTimerState = EntryTimerState.ExtendedEntryTimerRunning;
                        }
                    }
                }
                else if (EntryTimerState == EntryTimerState.ExtendedEntryTimerRunning)
                {
                    extendedEntryDelayRemaining--;
                    if (extendedEntryDelayRemaining <= 0)
                    {
                        SendPendingEventsForArea();
                        EntryTimerState = EntryTimerState.NotRunning;
                    }
                }
                Parent.TriggerAreaChangedEntryDelayedState(this);
            }
        }

        public bool EntryDelayTimerActive
        {
            get
            {
                if (EntryTimerState == EntryTimerState.NotRunning)
                    return false;
                return true;
            }
        }

        public bool InputIsInPendingList(InputStatus input)
        {
            lock (pointStateListsLock)
            {
                return pendingAlarmPoints.FirstOrDefault(point => point == input) != null;
            }
        }

        internal void SendPendingEventsForArea()
        {
            entryTimer.Stop();
            lock (pointStateListsLock)
            {
                if (EntryTimerState == EntryTimerState.NotRunning)
                    return;

                clearEntryDelayState();
                EntryTimerState = EntryTimerState.NotRunning;
                bool useSequentialConfirmation = enableAlarmConfirmationTime == true;
                foreach (InputStatus point in pendingAlarmPoints)
                {
                    if (useSequentialConfirmation == true && hasConfirmedAlarm == false && hasEntryDelayedConfirmedAlarm == false &&
                        point.TriggersEntryDelay == true && unconfirmedAlarmSource == null && point.ConfirmedAlarmType == ConfirmedAlarmType.BS8243Compliant)
                    {
                        point.ConfirmedType = ConfirmedType.Unconfirmed;
                        // Update the unconfirmed alarm source if no confirmed alarm sent
                        unconfirmedAlarmSource = point;
                    }

                    // Increment suspect count and try to latch the input if suspect or configured to be latched
                    point.IncrementSuspectCount(EventSourceLatchOrIsolateType.InputAlarms);


                    Pacom.Peripheral.Common.InputStatus newStatus = point.MaskedStatus;
                    point.QualifyAlarm();
                    if (!Common.Status.InputStatus.IsUnqualifiedAlarm(newStatus) && point.IsCurrentlyLatched == false)
                    {
                        // Restore an alarm that has already been restored.
                        point.RestoreQualifiedAlarm(newStatus);
                    }
                    if (alarmConfirmationTimer.Enabled == false && useSequentialConfirmation == true)
                    {
                        // Start alarm confirmation timer at this point because the entry delayed alarm is an uncomnfirmed alarm and
                        // no confirmed alarm exists in the pending queue
                        alarmConfirmationTimer.RunOnce(confirmationTimeout);
                        if (mode == AreaScheduleLevel.Armed)
                            AlarmCancelRequired = true;
                    }
                }
                pendingAlarmPoints.Clear();
                if (useSequentialConfirmation == true && alarmConfirmationTimer.Enabled == true)
                {
                    // Send Area Confirmed Alarm Event
                    lock (confirmedAlarmLock)
                    {
                        if (hasEntryDelayedConfirmedAlarm == true)
                        {
                            hasEntryDelayedConfirmedAlarm = false;
                            SetHasConfirmedAlarm(true, ConfigurationManager.SystemUser);
                            if (Alarmed == true)
                            {
                                // Send Area alarmed event
                                Parent.TriggerAreaAlarmed(this);
                            }
                        }
                    }
                }
            }
        }

        private void clearEntryDelayState()
        {
            terminateEntryDelay = false;
            entryDelayExtended = false;
            entryDelay1Remaining = 0;
            entryDelay2Remaining = 0;
            extendedEntryDelayRemaining = 0;
        }

        private void discardPendingEventsForArea()
        {
            lock (pointStateListsLock)
            {
                pendingAlarmPoints.Clear();
                entryTimer.Stop();
                EntryTimerState = EntryTimerState.NotRunning;
                if (alarmConfirmationTimer.Enabled == true)
                {
                    alarmConfirmationTimer.Stop();
                    unconfirmedAlarmSource = null;
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Area [{0}] -> [discardPendingEventsForArea] -> [STOP] Alarm Confirmation Timer.", DisplayName);
                    });
                }
            }
        }

        #endregion

        #region Sequential Alarm Confirmation

        private readonly object confirmedAlarmLock = new object();
        private IStatusItem unconfirmedAlarmSource = null;
        private IPacomTimer alarmConfirmationTimer = null;
        private bool terminateEntryDelay = false;
        private bool entryDelayExtended = false;
        private bool hasEntryDelayedConfirmedAlarm = false;

        private bool hasConfirmedAlarm = false;
        public bool HasConfirmedAlarm
        {
            get { return hasConfirmedAlarm; }
        }

        public bool DisableConfirmedAlarms
        {
            get;
            set;
        }

        /// <summary>
        /// Process Area Confirmed Alarm: Set / Restore value and Latched flag, Send Area Confirmed Alarm / Restore Event and Stop the
        /// Alarm Confirmation Timer if running. Also store the new value into Status Storage.
        /// </summary>
        /// <param name="newValue">New Area Confirmed Alarm value</param>
        /// <param name="userAuditInfo">User Audit Info</param>
        public void SetHasConfirmedAlarm(bool newValue, UserAuditInfo userAuditInfo)
        {
            SetHasConfirmedAlarm(newValue, userAuditInfo, true);
        }

        /// <summary>
        /// Process Area Confirmed Alarm: Set / Restore value and Latched flag, Send Area Confirmed Alarm / Restore Event and Stop the
        /// Alarm Confirmation Timer if running. Also store the new value into Status Storage.
        /// </summary>
        /// <param name="newValue">New Area Confirmed Alarm value</param>
        /// <param name="userAuditInfo">User Audit Info</param>
        /// <param name="sendEvent">True if the Area COnfirmed Alarm / Restore Event needs to be sent</param>
        public void SetHasConfirmedAlarm(bool newValue, UserAuditInfo userAuditInfo, bool sendEvent)
        {
            if (Enabled == false)
                return;
            if (hasConfirmedAlarm != newValue)
            {
                hasConfirmedAlarm = newValue;
                if (hasConfirmedAlarm == true)
                    IncrementSuspectCount(EventSourceLatchOrIsolateType.AreaConfirmedAlarm);
                else
                    ResetIsCurrentlyLatched(EventSourceLatchOrIsolateType.AreaConfirmedAlarm);
                if (sendEvent == true)
                {
                    Parent.TriggerAreaConfirmedAlarmStateChanged(this, userAuditInfo);
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        string restore = hasConfirmedAlarm == false ? " Restore " : " ";
                        return string.Format("Area [{0}] -> Confirmed Alarm{1}Event Sent. Area [HasConfirmedAlarm] flag was [{2}]", DisplayName, restore, hasConfirmedAlarm ? "Set" : "Reset");
                    });
                    StatusManager.Instance.RequestStatusToStorage();

                    if (alarmConfirmationTimer.Enabled == true)
                    {
                        // Stop alarm confirmation timer
                        alarmConfirmationTimer.Stop();
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Area [{0}] -> Alarm Confirmation Timer Has Been Stopped.", DisplayName);
                        });
                    }
                }
            }
        }

        public bool OffRouteInputPointInAlarm
        {
            get { return hasEntryDelayedConfirmedAlarm; }
        }

        private bool enableAlarmConfirmationTime = false;
        public bool EnableAlarmConfirmationTime
        {
            get { return enableAlarmConfirmationTime; }
        }

        /// <summary>
        /// Check if the alarm confirmation timer is running
        /// </summary>
        public bool ConfirmationTimerRunning
        {
            get
            {
                lock (confirmedAlarmLock)
                {
                    return enableAlarmConfirmationTime == true && alarmConfirmationTimer != null && alarmConfirmationTimer.Enabled == true;
                }
            }
        }

        /// <summary>
        /// Check if the alarm cancel event is required (BS8243 is enabled and an unconfirmed or confirmed alarm was sent in armed mode)
        /// </summary>
        public bool AlarmCancelRequired
        {
            get;
            set;
        }

        /// <summary>
        /// Check what kind of alarm event we should send to SM. This will also tell us if the confirmation
        /// timer needs to be started.
        /// </summary>
        public ConfirmedType GetAlarmConfirmationType(IStatusItem alarmSource)
        {
            lock (confirmedAlarmLock)
            {
                if (enableAlarmConfirmationTime == false)
                    return ConfirmedType.None;

                if (hasConfirmedAlarm == true)
                    return DisableConfirmedAlarms == true ? ConfirmedType.Unconfirmed : ConfirmedType.Confirmed;

                ConfirmedType confirmedType = alarmSource.GetConfirmedAlarmType(unconfirmedAlarmSource, this);
                if (confirmedType != ConfirmedType.Confirmed)
                {
                    // Disarmed Area -> One or more Devices Offline can't generate a confirmed alarm, any inputs that go
                    //                  into Trouble when devices go Offline shouldn't generate a confirmed alarm either.
                    // Any Area Mode -> Any Tamper from the activated detector can't generate a confirmed alarm, for 8502
                    //                  devices the device Tamper and PIR detector Tamper can't generate a confirmed alarm
                    //                  if the detector is activated.
                    return confirmedType;
                }
                if (alarmConfirmationTimer.Enabled == false || (unconfirmedAlarmSource != null && (unconfirmedAlarmSource == alarmSource)))
                    return ConfirmedType.Unconfirmed;
                if (confirmedType == ConfirmedType.Confirmed && DisableConfirmedAlarms == true)
                    confirmedType = ConfirmedType.Unconfirmed;
                return confirmedType;
            }
        }

        /// <summary>
        /// Process alarm confirmation: 
        ///     - start confirmation timer if this is the 1st alarm received; 
        ///     - send the area confirmed alarm event if this is a sequentially confirmed alarm and the confirmation timer is enabled; 
        ///     - if another alarm is sent when area doesn't have confirmed alarm from the same source with the unconfirmed alarm do nothing;
        ///     - if another alarm is sent when the area has confirmed alarm just send it as confirmed alarm without doing anything else;
        /// </summary>
        /// <param name="alarmSource"></param>
        public void ProcessAlarmConfirmation(IStatusItem alarmSource)
        {
            lock (confirmedAlarmLock)
            {
                if (hasConfirmedAlarm == true)
                {
                    if (alarmSource != null)
                    {
#if DEBUG
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Area [{0}] -> [ProcessAlarmConfirmation] -> Has Another Confirmed Alarm(s) from alarm source : {1}", DisplayName, alarmSource.DisplayAlarmedName);
                        });
#endif
                    }
                    return;
                }

                ConfirmedType confirmedType = GetAlarmConfirmationType(alarmSource);
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Area [{0}] -> [ProcessAlarmConfirmation] -> Alarm Confirmation Type is: {1}", DisplayName, confirmedType);
                });
#endif
                if (confirmedType == ConfirmedType.None)
                {
                    // No alarm confirmation required
                    return;
                }

                bool isSameAlarmSource = alarmConfirmationTimer.Enabled == true && unconfirmedAlarmSource != null && unconfirmedAlarmSource == alarmSource;
                if (confirmedType == ConfirmedType.Confirmed && hasConfirmedAlarm == false)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Area [{0}] -> [ProcessAlarmConfirmation] -> Has Confirmed Alarm from alarm source : {1}", DisplayName, alarmSource.DisplayAlarmedName);
                    });
                    SetHasConfirmedAlarm(true, ConfigurationManager.SystemUser);
                    if (Alarmed == true)
                    {
                        // Send Area alarmed event
                        Parent.TriggerAreaAlarmed(this);
                    }
                    return;
                }
                if (confirmedType == ConfirmedType.Unconfirmed && isSameAlarmSource)
                {
                    // The confirmation timer has already been started and we received another alarm from the same point so
                    // there is no need to start the timer again
#if DEBUG
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Area [{0}] -> [ProcessAlarmConfirmation] -> Has Another Unconfirmed Alarm(s) from alarm source : {1}", DisplayName, unconfirmedAlarmSource.DisplayAlarmedName);
                    });
#endif
                    return;
                }
                unconfirmedAlarmSource = alarmSource;
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Area [{0}] -> [ProcessAlarmConfirmation] -> Has 1st Unconfirmed Alarm(s) from alarm source : {1}", DisplayName, unconfirmedAlarmSource.DisplayAlarmedName);
                });
#endif
                if (alarmConfirmationTimer.Enabled == false)
                {
                    // Start confirmation timer
                    alarmConfirmationTimer.RunOnce(confirmationTimeout);
                    if (mode == AreaScheduleLevel.Armed)
                        AlarmCancelRequired = true;
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Area [{0}] -> [ProcessAlarmConfirmation] -> [START] Alarm Confirmation Timer.", DisplayName);
                    });
                }
            }
        }

        private int confirmationTimeout
        {
            get
            {
                AreaConfiguration areaConfiguration = ConfigurationManager.Instance.GetAreaConfiguration(LogicalId);
                if (areaConfiguration == null)
                    return Timeout.Infinite;
                return mode == AreaScheduleLevel.Armed ? (int)areaConfiguration.ArmedAreaAlarmConfirmationTimeout.TotalMilliseconds :
                                                         (int)areaConfiguration.DisarmedAreaAlarmConfirmationTimeout.TotalMilliseconds;
            }
        }

        /// <summary>
        /// Alarm confirmation timer has fired, stop the timer and remove any unconfirmed alarm and 
        /// change the area has confirmed alarm flag to False
        /// </summary>
        /// <param name="state"></param>
        private void alarmConfirmationProc(object state)
        {
            if (disposed == true)
                return;
            lock (confirmedAlarmLock)
            {
                // No confirmed alarm was received in the confirmation time.
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Area [{0}] -> [alarmConfirmationProc] -> Alarm Confirmation Timer Has Expired.", DisplayName);
                });
                hasConfirmedAlarm = false;
                Parent.TriggerAreaAlarmConfirmationTimerExpired(this);
                StatusManager.Instance.RequestStatusToStorage();
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Area [{0}] -> [alarmConfirmationProc] -> Send Area Confirmed Alarm [RESTORE] Event. Area [HasConfirmedAlarm] was RESET.", DisplayName);
                });
#endif
                if (unconfirmedAlarmSource != null)
                {
#if DEBUG
                    if (unconfirmedAlarmSource.CurrentAlarms != EventSourceLatchOrIsolateType.None)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Area [{0}] -> [alarmConfirmationProc] -> Alarm confirmation timer has expired. Unconfirmed alarm source STILL in alarm: {1}", DisplayName, unconfirmedAlarmSource.DisplayAlarmedName);
                        });
                    }
                    else
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Area [{0}] -> [alarmConfirmationProc] -> Alarm confirmation timer has expired. Unconfirmed alarm source RESTORED: {1}", DisplayName, unconfirmedAlarmSource.DisplayName);
                        });
                    }
#endif
                    unconfirmedAlarmSource = null;
                }
            }
        }

        /// <summary>
        /// Restore area confirmed alarm status. Send an Area Confirmed Alarm restore event to SM and stop the
        /// confirmation timer if the user is Engineer or the controller is configured to work in non EN-GRADE4 mode.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        private void restoreAreaConfirmedAlarm(UserAuditInfo userAuditInfo)
        {
            if (ConfigurationManager.Instance.Users.HasEngineeringPermissions(userAuditInfo.OriginatingUserId) == false)
                return;
            lock (confirmedAlarmLock)
            {
                unconfirmedAlarmSource = null;
                hasEntryDelayedConfirmedAlarm = false;
                if (hasConfirmedAlarm == false && alarmConfirmationTimer.Enabled == true)
                {
                    // Alarm confirmation timer must be stopped if running when area confirmed alarm state is restored 
                    // even if the area haven't had a confirmed alarm yet. This is required because the unconfirmedAlarmSource
                    // was already reset.
                    alarmConfirmationTimer.Stop();
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Area [{0}] -> Alarm Confirmation Timer Has Been Stopped. (restoreAreaConfirmedAlarm)", DisplayName);
                    });
                }
                SetHasConfirmedAlarm(false, userAuditInfo);
                StatusManager.Instance.Inputs.RestoreInArea(this, userAuditInfo);
                if (Alarmed == false)
                {
                    // Send Area restored event
                    Parent.TriggerAreaRestored(this);
                }
            }
        }

        #endregion

        #region Area LateToCLose

        IPacomTimer lateToCloseTimer = null;

        /// <summary>
        /// Beep the keypads if late to close every minute
        /// </summary>
        private const int lateToCloseBeepInterval = 60 * 1000;

        public void StartLateToCloseTimer()
        {
            if (mode == AreaScheduleLevel.Armed || lateToCloseTimer.Enabled == true)
                return;
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Area [{0}] -> [START] Late to Close Keypad Beeping Timer.", DisplayName);
            });
            lateToCloseTimer.Change(0, lateToCloseBeepInterval);
        }

        public void StopLateToCloseTimer()
        {
            if (lateToCloseTimer.Enabled == false)
                return;
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Area [{0}] -> [STOP] Late to Close Keypad Beeping Timer.", DisplayName);
            });
            lateToCloseTimer.Stop();
        }

        public bool LateToClose
        {
            get { return lateToCloseTimer != null && lateToCloseTimer.Enabled == true; }
        }

        private void lateToCloseTimerProc(object state)
        {
            if (Parent != null)
                Parent.TriggerAreaLateToCloseBeepKeypadBuzzer(this);
        }

        #endregion

        #region Area Fail to Arm

        IPacomTimer failToArmTimer = null;

        /// <summary>
        /// Beep the keypads that are owned by this area if area failed to arm
        /// </summary>
        private const int failToArmBeepInterval = 10 * 1000;

        /// <summary>
        /// Start the fail to arm timer if area can't be armed because of an alarm that was triggered during the exit delay
        /// </summary>
        public void StartFailToArmTimer()
        {
            if (mode == AreaScheduleLevel.Armed || failToArmTimer.Enabled == true)
                return;
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Area [{0}] -> [START] Fail to Arm Keypad Beeping Timer.", DisplayName);
            });
            failToArmTimer.Change(0, failToArmBeepInterval);
        }

        /// <summary>
        /// Stop the fail to arm timer if all night mode alarms were restored or isolated
        /// </summary>
        public void StopFailToArmTimer()
        {
            if (failToArmTimer.Enabled == false)
                return;
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Area [{0}] -> [STOP] Fail to Arm Keypad Beeping Timer.", DisplayName);
            });
            failToArmTimer.Stop();
            // Beep the keypads one last time
            if (Parent != null && mode == AreaScheduleLevel.Disarmed)
                Parent.TriggerAreaFailToArmBeepKeypadBuzzer(this);
        }

        /// <summary>
        /// Terminate arming if exit delay is running for this area and the area is not already in failed to arm state
        /// </summary>
        /// <returns></returns>
        public bool CheckTerminateArming()
        {
            if (FailedToArm == true)
                return false;
            return Parent.CheckTerminateArming(LogicalId);
        }

        /// <summary>
        /// Check if this area is in Fail to Arm state
        /// </summary>
        public bool FailedToArm
        {
            get { return failToArmTimer != null && failToArmTimer.Enabled == true; }
        }

        /// <summary>
        /// Area has armed mode alarms
        /// </summary>
        public bool HasArmedModeAlarms
        {
            get { return ArmedAlarmedPoints.Count > 0; }
        }

        /// <summary>
        /// Fail to Arm timer procedure, fires every 10 sec
        /// </summary>
        /// <param name="state"></param>
        private void failToArmTimerProc(object state)
        {
            if (Parent != null)
                Parent.TriggerAreaFailToArmBeepKeypadBuzzer(this);
        }

        #endregion

        #region Delay Automatic Arming

        private void killAutoArmDelayTimer()
        {
            if (autoArmDelayTimer != null)
            {
                TimerManager.Instance.RemoveTimer(autoArmDelayTimer);
                autoArmDelayTimer = null;
            }
        }

        public bool DelayAutomaticArming(AreaConfiguration areaConfig)
        {
            killAutoArmDelayTimer();
            autoArmDelayTimer = TimerManager.Instance.CreateTimer(_ =>
            {
                killAutoArmDelayTimer();

                // Check the current schedule
                Pacom8003AreaSchedule schedule = ConfigurationManager.Instance.GetAreaSchedule(areaConfig.NormalScheduleId);
                if (schedule != null && schedule.ScheduledLevel == AreaScheduleLevel.Disarmed)
                {
                    resetDelayAutomaticArming();
                    return;
                }

                int delay1 = (int)(areaConfig.ExitDelay1 + areaConfig.ExitDelay2).TotalSeconds;
                int delay2 = (int)areaConfig.ExitDelay2.TotalSeconds;
                this.Parent.ArmAreas(new List<int>() { areaConfig.Id }, delay1, delay2, ConfigurationManager.ScheduleUser);
                CanDelayAutomaticArming = true;
            });
            autoArmDelayTimer.RunOnce((int)areaConfig.AutomaticArmDelayDuration.TotalMilliseconds);
            return true;
        }

        private void resetDelayAutomaticArming()
        {
            AutomaticArmDelayCount = 0;
            CanDelayAutomaticArming = false;
            killAutoArmDelayTimer();
        }

        public bool HasDelayedAutomaticArm
        {
            get { return autoArmDelayTimer != null; }
        }
        #endregion

        public override string ToString()
        {
            return String.Format("Area Status [{0}]", this.LogicalId);
        }

        private void removeFromArea(ConfigurationChanges itemToRemove)
        {
            if (itemToRemove.ConfigurationType == ConfigurationElementType.Input)
            {
                InputStatus input = StatusManager.Instance.Inputs[itemToRemove.Id];
                if (input != null)
                {
                    RemovePointFromArmedList(input);
                    RemovePointFromDisarmedList(input);
                    RemovePointFromIsolatedList(input);

                    if (pendingAlarmPoints.Count == 1)
                    {
                        if (pendingAlarmPoints[0].LogicalId == itemToRemove.Id)
                            discardPendingEventsForArea();
                    }
                    else
                    {
                        pendingAlarmPoints.Remove(input);
                    }

                    unqualifiedAlarmPoints.Remove(input);
                }
            }
            else if (itemToRemove.ConfigurationType == ConfigurationElementType.Output)
            {
                OutputStatus output = StatusManager.Instance.Outputs[itemToRemove.Id];
                if (output != null)
                    RemovePointFromIsolatedList(output);
            }
            else if (itemToRemove.ConfigurationType == ConfigurationElementType.Door)
            {
                DoorStatus door = StatusManager.Instance.Doors[itemToRemove.Id];
                if (door != null)
                {
                    RemovePointFromArmedList(door);
                    RemovePointFromDisarmedList(door);
                    RemovePointFromIsolatedList(door);
                }
            }
            else if (itemToRemove.ConfigurationType == ConfigurationElementType.Reader)
            {
                ReaderStatus reader = StatusManager.Instance.Readers[itemToRemove.Id];
                if (reader != null)
                    RemovePointFromIsolatedList(reader);
            }
        }

        internal void RemoveFromArea(List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems)
        {
            lock (pointStateListsLock)
            {
                foreach (var changedItem in changedItems)
                {
                    if (changedItem.ConfigurationType == ConfigurationElementType.Input ||
                        changedItem.ConfigurationType == ConfigurationElementType.Output ||
                        changedItem.ConfigurationType == ConfigurationElementType.Reader ||
                        changedItem.ConfigurationType == ConfigurationElementType.Door)
                    {
                        removeFromArea(changedItem);
                    }
                }
                foreach (var removedItem in removedItems)
                {
                    if (removedItem.ConfigurationType == ConfigurationElementType.Input ||
                        removedItem.ConfigurationType == ConfigurationElementType.Output ||
                        removedItem.ConfigurationType == ConfigurationElementType.Reader ||
                        removedItem.ConfigurationType == ConfigurationElementType.Door)
                    {
                        removeFromArea(removedItem);
                    }
                }
                updateReadyToArm();
            }
        }

        internal override void Cleanup()
        {
            killAutoArmDelayTimer();
            entryTimer.Stop();
            TimerManager.Instance.RemoveTimer(entryTimer);
            lock (confirmedAlarmLock)
            {
                if (alarmConfirmationTimer != null)
                {
                    if (alarmConfirmationTimer.Enabled == true)
                    {
                        alarmConfirmationTimer.Stop();
                        alarmConfirmationProc(null);
                    }
                    TimerManager.Instance.RemoveTimer(alarmConfirmationTimer);
                    alarmConfirmationTimer = null;
                    unconfirmedAlarmSource = null;
                }
            }
            if (lateToCloseTimer != null)
            {
                if (lateToCloseTimer.Enabled == true)
                {
                    lateToCloseTimer.Stop();
                }
                TimerManager.Instance.RemoveTimer(lateToCloseTimer);
                lateToCloseTimer = null;
            }
            if (failToArmTimer != null)
            {
                if (failToArmTimer.Enabled == true)
                {
                    failToArmTimer.Stop();
                }
                TimerManager.Instance.RemoveTimer(failToArmTimer);
                failToArmTimer = null;
            }
            lock (pointStateListsLock)
            {
                if (EntryTimerState != EntryTimerState.NotRunning)
                {
                    EntryTimerState = EntryTimerState.EntryTimer2Running;
                    entryDelayExpiredProc(null);
                }
            }
            if (inTestMode == true)
            {
                lock (testedListLock)
                {
                    StatusManager.Instance.Inputs.ChangedStatus -= new EventHandler<StatusManagerInputChangedStatusEventArgs>(onTestInputs_ChangedStatus);
                    testedInputs = null;
                    untestedInputs = null;
                }
            }
            currentModeAlarmedPoints.Clear();
            armedModeAlarmPoints.Clear();
            isolatedPoints.Clear();
        }
    }
}
