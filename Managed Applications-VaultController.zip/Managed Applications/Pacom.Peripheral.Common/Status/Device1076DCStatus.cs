﻿using Pacom.Core.Contracts;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    public class Device1076DCStatus : DeviceLoopDeviceStatus, IDeviceStatus
    {
        /// <summary>
        /// Device internal lithium battery status
        /// </summary>
        private bool internalBatteryLow = false;
        private bool maskedInternalBatteryLow = false;

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            switch (suspectStatusType)
            {
                case EventSourceLatchOrIsolateType.Offline: return ConfigurationManager.Instance.ControllerConfiguration.LatchOfflineAlarms;
                case EventSourceLatchOrIsolateType.Tamper: return ConfigurationManager.Instance.ControllerConfiguration.LatchTamperAlarms;
                case EventSourceLatchOrIsolateType.InternalBatteryFail: return ConfigurationManager.Instance.ControllerConfiguration.LatchInternalBatteryLowAlarms;
                case EventSourceLatchOrIsolateType.DeviceSubstitution: return true;
                default: return false;
            }
        }

        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get { return base.IsCurrentlyLatched || latchedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail); }
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = base.CurrentAlarms;
                if (maskedInternalBatteryLow == true)
                    flags |= EventSourceLatchOrIsolateType.InternalBatteryFail;
                return flags;
            }
        }

        /// <summary>
        /// Get / Set unmasked internal lithium battery status.
        /// </summary>
        public bool InternalBatteryLow
        {
            get { return internalBatteryLow; }
            set
            {
                if (Enabled == false)
                    return;
                if (internalBatteryLow != value)
                {
                    internalBatteryLow = value;
                    MaskedInternalBatteryLow = internalBatteryLow;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set masked internal lithium battery status, send status changed event to front-end if required.
        /// </summary>
        public bool MaskedInternalBatteryLow
        {
            get { return maskedInternalBatteryLow; }
            private set
            {
                if (Enabled == false)
                    return;
                if (maskedInternalBatteryLow != value || value == true)
                {
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail) == false &&
                        SuspectPoint == false &&
                        (LatchedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail) == false || value == true))
                    {
                        maskedInternalBatteryLow = value;
                        if (maskedInternalBatteryLow == true)
                        {
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.InternalBatteryFail);
                            CheckTerminateArming();
                        }
                        else
                        {
                            CheckStopFailToArmTimer();
                        }
                        Parent.TriggerInternalBatteryLowChangedStatus(this);
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        public Device1076DCStatus(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus) :
            base(configuration, parent, previousStatus)
        {
            SupportedIsolateFlags |= EventSourceLatchOrIsolateType.InternalBatteryFail;

            if (previousStatus == null || Enabled == false)
                return;

            if (this.HardwareType == previousStatus.HardwareType)
            {
                this.isolatedAlarms = previousStatus.IsolatedAlarms;
                this.latchedAlarms = previousStatus.LatchedAlarms;
                VerifyMaskedAlarms();
            }
        }

        /// <summary>
        /// Set the state of device IsolatedAlarms flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="value">New isolated options. If value = EventSourceLatchOrIsolateType.None -> Deisolate all.
        /// If value = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.Tamper | EventSourceLatchOrIsolateType.InternalBatteryFail -> Isolate all or any.
        /// When de-isolating if any of the device inputs is in alarm the alarm will be queued into AlarmManager.
        /// </param>
        /// <returns>True if the command was successfully executed</returns>
        public override bool SetIsolated(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType value)
        {
            if (base.SetIsolated(userAuditInfo, value) == false)
                return false;

            // Mask-out all flags this device does not support
            value &= SupportedIsolateFlags;
            if (value != isolatedAlarms)
            {
                // Internal Battery Low - Isolate/de-isolate 
                SetIsolated(value, EventSourceLatchOrIsolateType.InternalBatteryFail, false, internalBatteryLow);
                StatusManager.Instance.RequestStatusToStorage();
            }
            return true;
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            DeviceStatusStorage statusStorage = new DeviceStatusStorage();
            if (statusStorage != null)
            {
                InitializeStatusStorage(statusStorage);
            }
            return statusStorage;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            Device1076DCEventState deviceState = new Device1076DCEventState();
            InitializeEventState(deviceState);
            deviceState.InternalBatteryFail = MaskedInternalBatteryLow;
            return deviceState;
        }

        /// <summary>
        /// Set masked status for [optionToCheck] to [newValue]
        /// </summary>
        /// <param name="optionToCheck">Option to check, e.g.: Offline, Tamper, InternalBatteryFail, etc.</param>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(EventSourceLatchOrIsolateType optionToCheck, bool newValue)
        {
            if (base.SetMaskedStatus(optionToCheck, newValue))
                return true;
            if (optionToCheck == EventSourceLatchOrIsolateType.InternalBatteryFail)
            {
                MaskedInternalBatteryLow = newValue;
            }
            return true;
        }

        /// <summary>
        /// Restore masked online, device tamper, etc. status if required after unlatching the device alarms. Restore only if the
        /// current instantaneous status is Secure (device online, tamper secure, etc.).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        protected override void RestoreAfterUnlatch(UserAuditInfo userAuditInfo)
        {
            base.RestoreAfterUnlatch(userAuditInfo);
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail) == false && InternalBatteryLow == false)
                MaskedInternalBatteryLow = InternalBatteryLow;
        }

        /// <summary>
        /// Check masked alarms when we restore status from previous stored state
        /// </summary>
        protected override void VerifyMaskedAlarms()
        {
            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail))
            {
                maskedInternalBatteryLow = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.InternalBatteryFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail))
            {
                maskedInternalBatteryLow = true;
            }
        }
    }
}
