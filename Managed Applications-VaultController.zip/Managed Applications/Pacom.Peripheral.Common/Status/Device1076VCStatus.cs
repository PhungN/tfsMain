﻿using Pacom.Core.Contracts;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Configuration.ConfigurationCommon;
using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Status
{
    public sealed class Device1076VCStatus : Device1076DCStatus// DeviceLoopDeviceStatus, IDeviceStatus
    {
        public Device1076VCStatus(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus) :
            base(configuration, parent, previousStatus)
        {
            
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            Device1076VCEventState deviceState = new Device1076VCEventState();
            InitializeEventState(deviceState);
            deviceState.InternalBatteryFail = MaskedInternalBatteryLow;
            return deviceState;
        }

        

    }
}
