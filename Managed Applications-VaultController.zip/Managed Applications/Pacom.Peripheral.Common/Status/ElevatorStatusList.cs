﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.Utils;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Core.Contracts.Status;
using Pacom.Core.Contracts;
using Pacom.Core.Access;
using Pacom.Peripheral.Common.AccessControl;
using System.Threading;

namespace Pacom.Peripheral.Common.Status
{
    public class ElevatorStatusList : StatusListBase<ElevatorStatus, ElevatorStatusList>, IDisposable
    {
        /// <summary>
        /// Triggered when elevator controller device Online status has changed.
        /// </summary>
        public event EventHandler<ElevatorNotConfiguredEventArgs> ElevatorNotConfigured = null;
        public event EventHandler<ElevatorInputChangedEventArgs> ElevatorInputChanged = null;

        private SchedulesStatus floorUnlockSchedulesStatus;
        internal ElevatorStatusList()
            : base() 
        {
            floorUnlockSchedulesStatus = new SchedulesStatus(ConfigurationManager.Instance.ElevatorFloorUnlockSchedules.AsArray);
            floorUnlockSchedulesStatus.SchedulesConfigurationChanged += new EventHandler<SchedulesChangedEventArgs>(onFloorUnlockSchedulesConfigurationChanged);
            floorUnlockSchedulesStatus.SchedulesStatusChanged += new EventHandler<SchedulesChangedEventArgs>(onFloorUnlockSchedulesStatusChanged);
        }

        public void UpdateFromConfigurationFirstTime()
        {
            StatusManager.Instance.Devices.ChangedIsolatedStatus += new EventHandler<StatusManagerDeviceChangedIsolatedEventArgs>(onDeviceChangedIsolatedStatus);
        }

        public void UpdateSchedules()
        {
            var floorUnlockSchedules = ConfigurationManager.Instance.ElevatorFloorUnlockSchedules.AsArray;
            if (floorUnlockSchedules.Length == 0)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("No floor unlock schedules exist. The floor(s) status will not be updated!");
                });
                return;
            }
            floorUnlockSchedulesStatus.UpdateSchedules(floorUnlockSchedules);
        }

        private void onFloorUnlockSchedulesStatusChanged(object sender, SchedulesChangedEventArgs e)
        {
            unlockScheduledFloors(e.ScheduleIntervalDetailsList);
        }

        private void onFloorUnlockSchedulesConfigurationChanged(object sender, SchedulesChangedEventArgs e)
        {
            unlockScheduledFloorsList.Clear();
            unlockScheduledFloors(e.ScheduleIntervalDetailsList);
        }

        private void onDeviceChangedIsolatedStatus(object sender, StatusManagerDeviceChangedIsolatedEventArgs e)
        {
            if (e.IsolatedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false && e.PreviousIsolatedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == true)
            {
                var deviceLoopConfiguration = ConfigurationManager.Instance.GetDeviceConfiguration(e.DeviceStatus.LogicalId) as DeviceLoopDeviceConfigurationBase;
                if (deviceLoopConfiguration != null)
                {
                    int deviceAddress = deviceLoopConfiguration.DeviceLoopAddress;
                    if (unlockScheduledFloorsList.ContainsKey(deviceAddress) == true)
                    {
                        IDeviceLoopDeviceBase deviceLoopStatus = StatusManager.Instance.DeviceLoopManager[deviceAddress - 1];
                        if (deviceLoopStatus != null)
                        {
                            IElevatorControllerDeviceLoopCommand elevatorControllerDevice = deviceLoopStatus as IElevatorControllerDeviceLoopCommand;
                            if (elevatorControllerDevice != null)
                            {
                                elevatorControllerDevice.UnlockFloors(unlockScheduledFloorsList[deviceAddress], 0);
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Get Elevator Controller Status for elevator with [logicalId] id
        /// </summary>
        /// <param name="logicalOutputId">Logical id, 1 based</param>
        /// <returns>Elevator Controller status instance or null if not found</returns>
        public ElevatorStatus GetStatus(int logicalId)
        {
            return this[logicalId];
        }

        /// <summary>
        /// Update Elevator Controller status list from configuration. Add new Elevator Controller status instances if not already existing
        /// </summary>
        /// <param name="elevators">List of Elevator Controllers to add</param>
        /// <param name="statusStorage">Status storage instance</param>
        /// <param name="controllerRestarted">True if controller restarted</param>
        internal void UpdateFromConfiguration(IElevatorConfiguration[] elevators, StatusStorageCollection statusStorage)
        {
            foreach (var elevator in elevators)
            {
                Assign(elevator.Id, new ElevatorStatus(elevator as ConfigurationBase, this, statusStorage.ElevatorsStatus.TryGetValue(elevator.Id)));
            }
        }
        
        /// <summary>
        /// Update Elevator Controller status list from configuration on configuration change.
        /// </summary>
        internal void UpdateFromConfiguration(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems, List<NodeStateBase> partialStatusList)
        {
            foreach (var removedItem in removedItems)
            {
                if (removedItem.ConfigurationType == ConfigurationElementType.Elevator)
                    Remove(removedItem.Id);
            }
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Elevator)
                {
                    Remove(changedItem.Id);
                    try
                    {
                        Assign(changedItem.Id, new ElevatorStatus(ConfigurationManager.Instance.GetElevatorConfiguration(changedItem.Id) as ConfigurationBase, this, null));
                        partialStatusList.Add(this[changedItem.Id].CreateEventState());
                        setFloorAccessTime(changedItem.Id);
                    }
                    catch
                    {
                    }
                }
            }
            foreach (var newlyAddedItem in newlyAddedItems)
            {
                try
                {
                    if (newlyAddedItem.ConfigurationType == ConfigurationElementType.Elevator)
                    {
                        Assign(newlyAddedItem.Id, new ElevatorStatus(ConfigurationManager.Instance.GetElevatorConfiguration(newlyAddedItem.Id) as ConfigurationBase, this, null));
                        partialStatusList.Add(this[newlyAddedItem.Id].CreateEventState());
                    }
                }
                catch
                {
                }
            }
        }

        private void setFloorAccessTime(int id)
        {
            var elevator = ConfigurationManager.Instance.GetElevatorConfiguration(id);
            if (elevator != null && elevator.Enabled == true)
            {
                var deviceAddresses = elevator.GetFloorControllerAddresses();
                foreach (var deviceAddress in deviceAddresses)
                {
                    if (deviceAddress > 0)
                    {
                        IDeviceLoopDeviceBase device = StatusManager.Instance.DeviceLoopManager[deviceAddress - 1];
                        if (device != null)
                        {
                            IElevatorControllerDeviceLoopCommand p8501EcDevice = device as IElevatorControllerDeviceLoopCommand;
                            if (p8501EcDevice != null)
                            {
                                p8501EcDevice.SetFloorAccessTime(elevator.EnableApartmentMode == true ? (int)elevator.FloorAccessTime.TotalSeconds : 0);
                            }
                        }
                    }
                }
            }
        }

        internal override void Persist(Asn1DerFormatter asn1Serializer, Stream statusStream)
        {
            foreach (var item in Items)
            {
                try
                {
                    asn1Serializer.Serialize(statusStream, item.CreateStatusStorage());
                }
                catch (Exception ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Unable to store status for elevator controller {0}. {1}", item.LogicalId, ex.Message);
                    });
                }
            }
        }

        internal void RefreshAfterConfigurationChange()
        {
            foreach (var item in Items)
            {
                item.RefreshAfterConfigurationChange();
            }
        }

        internal void RefreshAfterConfigurationChange(List<ConfigurationChanges> changedItems)
        {
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Elevator)
                {
                    ElevatorStatus elevatorStatus = this[changedItem.Id];
                    if (elevatorStatus != null)
                        elevatorStatus.RefreshAfterConfigurationChange();
                }
            }
        }

        public bool IsDeviceConfigured(int deviceAddress)
        {
            foreach (var elevator in ConfigurationManager.Instance.Elevators)
            {
                if (elevator.Enabled == true && elevator.GetFloorControllerAddresses().Contains(deviceAddress) == true)
                    return true;
            }
            return false;
        }

        public int GetFloorAccessTimeForDevice(int deviceAddress)
        {
            foreach (var elevator in ConfigurationManager.Instance.Elevators)
            {
                if (elevator.Enabled == true)
                {
                    int floorAccessTime = elevator.GetFloorAccessTime(deviceAddress);
                    if (floorAccessTime >= 0)
                    {
                        return floorAccessTime;
                    }
                }
            }
            return -1;
        }

        public void TriggerInputStatusChanged(int deviceAddress, int inputId)
        {
            int floorOffset;
            var configuration = getElevatorConfiguration(deviceAddress + 1, out floorOffset);
            if (configuration != null)
            {
                if (configuration.FloorSelectedReporting != ElevatorFloorSelectedReporting.Disabled && configuration.IsValidFloorSelectionReportingSchedule == true)
                {
                    bool sendReport = false;
                    if (configuration.FloorSelectedReporting == ElevatorFloorSelectedReporting.SecureFloors)
                    {
                        if (floorSelectionReportingList.ContainsKey(deviceAddress+1) == true)
                        {
                            var floorAccessTime = floorSelectionReportingList[deviceAddress+1];
                            int floorAccess = (1 << inputId);
                            if ((floorAccess & floorAccessTime.FloorsAccess) == floorAccess)
                            {
                                sendReport = true;
                            }
                        }
                    }
                    else
                    {
                        sendReport = true;
                    }

                    if (ElevatorInputChanged != null && sendReport == true)
                    {
                        floorSelectionReportingList.Remove(deviceAddress);
                        int logicalDeviceId = ConfigurationManager.Instance.ControllerConfiguration.LogicalDeviceId(deviceAddress);
                        if (logicalDeviceId > 0)
                            ElevatorInputChanged.Invoke(this, new ElevatorInputChangedEventArgs(logicalDeviceId, (inputId + 1) + (floorOffset * 16)));
                    }
                }
            }
        }

        private Dictionary<int, int> unlockScheduledFloorsList = new Dictionary<int, int>();

        private void unlockScheduledFloors(List<ScheduleIntervalDetails> scheduleDetailsList)
        {
            foreach (var elevator in ConfigurationManager.Instance.Elevators)
            {
                if (elevator.Enabled == true)
                {
                    int[] deviceAddresses = elevator.GetFloorControllerAddresses();
                    for (int i = 0; i < deviceAddresses.Length; i++)
                    {
                        var deviceAddress = deviceAddresses[i];
                        if (deviceAddress > 0)
                        {
                            int scheduledFloors = elevator is ILegacyElevatorConfiguration ?
                                getGmsScheduledFloors(elevator as ILegacyElevatorConfiguration, (i * 16), scheduleDetailsList, deviceAddress) :
                                getUnisonScheduledFloors(elevator, (i * 16), scheduleDetailsList, deviceAddress);
                            if (unlockScheduledFloorsList.ContainsKey(deviceAddress) == false || unlockScheduledFloorsList[deviceAddress] != scheduledFloors)
                            {
                                unlockScheduledFloorsList[deviceAddress] = scheduledFloors;
                                unlockFloors(deviceAddress, scheduledFloors, 0);
                            }
                        }
                    }
                }
            }
        }

        public void TriggerDeviceNotConfigured(int deviceAddress)
        {
            if (ElevatorNotConfigured != null)
                ElevatorNotConfigured(this, new ElevatorNotConfiguredEventArgs(deviceAddress, 0));
        }

        public void TriggerValidCardAccess(int logicalReaderId, int logicalDoorId, CardInformation cardInformation)
        {
            if(ConfigurationManager.Instance.IsUnisonMode==false && ConfigurationManager.Instance.ValidateReaderSchedule(cardInformation.FloorsAccessTimezoneId) == false)
                return;

            var elevators = ConfigurationManager.Instance.Elevators.Select(elevator => 
            { 
                return elevator.Enabled == true && elevator.ReaderId == logicalReaderId && elevator.IsValidReaderSchedule == true; 
            });
            var doorConfiguration = ConfigurationManager.Instance.GetDoorConfiguration(logicalDoorId);
            int activeTimeInSeconds = doorConfiguration.StrikeTime.TotalSeconds <= 255 ? (int)doorConfiguration.StrikeTime.TotalSeconds : 255;
            foreach (var elevator in elevators)
            {
                int[] elevatorFloorAddress = elevator.GetFloorControllerAddresses();
                for (int i = 0; i < elevatorFloorAddress.Length; i++)
                {
                    var elevatorDeviceAddress = elevatorFloorAddress[i];
                    if (elevatorDeviceAddress > 0)
                    {
                        int floorsAccess = 0;
                        ILegacyElevatorConfiguration legacyConfiguration = elevator as ILegacyElevatorConfiguration;
                        if (legacyConfiguration != null)
                        {
                            int cardFloorsAccess = getFloorsAccess(cardInformation.FloorsAccess, i * 16, 16);
                            floorsAccess = cardFloorsAccess & getFloorsAccess(legacyConfiguration.FloorsServiced, i * 16, 16);
                        }
                        else
                        {
                            if(elevator.FloorIds != null && elevator.FloorIds.Length > 0)
                                floorsAccess = getFloorsAccess(elevator.FloorIds, i * 16 + 1);
                        }
                        if (unlockFloors(elevatorDeviceAddress, floorsAccess, activeTimeInSeconds) == true)
                        {
                            if (elevator.FloorSelectedReporting == ElevatorFloorSelectedReporting.SecureFloors && elevator.FloorSelectedReportingScheduleId > 0)
                                updateFloorSelectionReporting(elevatorDeviceAddress, floorsAccess, activeTimeInSeconds);
                        }
                    }
                }
            }
        }

        private bool unlockFloors(int deviceAddress, int floorsAccess, int activeTimeInSeconds)
        {
            IDeviceLoopDeviceBase device = StatusManager.Instance.DeviceLoopManager[deviceAddress - 1];
            if (device != null)
            {
                var deviceStatus = StatusManager.Instance.Devices[device.LogicalDeviceId];
                if (deviceStatus != null && deviceStatus.IsolatedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false)
                {
                    IElevatorControllerDeviceLoopCommand p8501EcDevice = device as IElevatorControllerDeviceLoopCommand;
                    if (p8501EcDevice != null)
                    {
                        p8501EcDevice.UnlockFloors(floorsAccess, activeTimeInSeconds);
                        return true;
                    }
                }
            }
            return false;
        }

        private int getFloorsAccess(int[] floorIds, int startId)
        {
            var elevatorFloorIds = getFloorScheduleIds().GetKeys();
            int endId = startId + 16;
            int floorsAccess = 0;
            foreach (var floorId in floorIds)
            {
                if (floorId >= startId && floorId < endId && elevatorFloorIds.Contains(floorId))
                    floorsAccess |= (1 << (floorId - startId));
            }
            return floorsAccess;
        }
        
        private int getFloorsAccess(bool[] floorsAccessArray, int start, int count)
        {
            if (floorsAccessArray == null || floorsAccessArray.Length < start + count)
                return 0;
            int floorsAccess = 0;
            for (int i = 0; i < count; i++)
            {
                if (floorsAccessArray[start + i] == true)
                    floorsAccess |= (1 << i);
            }
            return floorsAccess;
        }

        private IElevatorConfiguration getElevatorConfiguration(int floorControllerAddress, out int floorOffset)
        {
            floorOffset = 0;
            foreach (var elevator in ConfigurationManager.Instance.Elevators)
            {
                if (elevator.Enabled)
                {
                    int[] floorControllerAddresses = elevator.GetFloorControllerAddresses();
                    for (int i = 0; i < floorControllerAddresses.Length; i++)
                    {
                        if (floorControllerAddresses[i] == floorControllerAddress)
                        {
                            floorOffset = i;
                            return elevator;
                        }
                    }
                }
            }
            return null;
        }

        private Dictionary<int, int> getFloorScheduleIds()
        {
            Dictionary<int, int> scheduleIds = new Dictionary<int, int>();
            foreach (var floor in ConfigurationManager.Instance.ElevatorFloors)
                scheduleIds[floor.Id] = floor.FloorScheduleId;
            return scheduleIds;
        }

        private int getGmsScheduledFloors(ILegacyElevatorConfiguration elevator, int floorOffset, List<ScheduleIntervalDetails> scheduleDetailsList, int deviceAddress)
        {
            var floorsServiced = elevator.FloorsServiced;
            if (floorsServiced == null || floorsServiced.Length == 0 || floorsServiced.Length != 128)
                return 0;
            int unlockFloors = unlockScheduledFloorsList.ContainsKey(deviceAddress) ? unlockScheduledFloorsList[deviceAddress] : 0;
            var floorScheduleIds = getFloorScheduleIds();
            for (int i = 0; i < 16; i++)
            {
                if (floorsServiced[i + floorOffset] == true)
                {
                    int id = i + floorOffset + 1;
                    if (floorScheduleIds.ContainsKey(id) == true)
                    {
                        int scheduleId = floorScheduleIds[id];
                        foreach (var scheduleDetails in scheduleDetailsList)
                        {
                            if (scheduleDetails.Id == scheduleId)
                            {
                                if (scheduleDetails.Level == 1)
                                    unlockFloors |= (1 << i);
                                else
                                    unlockFloors &= ~(1 << i);
                                break;
                            }
                        }
                    }
                }
            }
            return unlockFloors;
        }

        private int getUnisonScheduledFloors(IElevatorConfiguration elevator, int floorOffset, List<ScheduleIntervalDetails> scheduleDetailsList, int deviceAddress)
        {
            if (elevator.FloorIds == null || elevator.FloorIds.Length == 0)
                return 0;
            int unlockFloors = unlockScheduledFloorsList.ContainsKey(deviceAddress) ? unlockScheduledFloorsList[deviceAddress] : 0;
            var floorScheduleIds = getFloorScheduleIds();
            var floorIds = new List<int>(floorScheduleIds.Keys);
            int startId = floorOffset + 1;
            int endId = startId + 16;
            foreach (var floorId in elevator.FloorIds)
            {
                if (floorId >= startId && floorId < endId && floorIds.Contains(floorId))
                {
                    foreach (var scheduleDetails in scheduleDetailsList)
                    {
                        if (scheduleDetails.Id == floorScheduleIds[floorId])
                        {
                            if (scheduleDetails.Level == 1)
                                unlockFloors |= (1 << (floorId - (floorOffset + 1)));
                            else
                                unlockFloors &= ~(1 << (floorId - (floorOffset + 1)));
                            break;
                        }
                    }
                }
            }
            return unlockFloors;
        }

        #region Reporting
        private Dictionary<int, ReportingFloorAccessTime> floorSelectionReportingList = new Dictionary<int, ReportingFloorAccessTime>();
        private IPacomTimer floorSelectionReportingTimer = null;
        private void updateFloorSelectionReporting(int deviceAddress, int floorsAccess, int activeTimeInSeconds)
        {
            if (floorsAccess > 0 && activeTimeInSeconds > 0)
            {
                floorSelectionReportingList[deviceAddress] = new ReportingFloorAccessTime(floorsAccess, activeTimeInSeconds);
                if (floorSelectionReportingTimer == null)
                    floorSelectionReportingTimer = TimerManager.Instance.CreateTimer(onFloorSelectionReportingTimeout, null, 1000, 1000);
            }
        }

        private void onFloorSelectionReportingTimeout(object state)
        {
            if (floorSelectionReportingList.Count == 0)
            {
                TimerManager.Instance.RemoveTimer(floorSelectionReportingTimer);
                floorSelectionReportingTimer = null;
            }

            foreach (var deviceAddress in floorSelectionReportingList.GetKeys())
            {
                var floorAccessTime = floorSelectionReportingList[deviceAddress];
                floorAccessTime.TimeInSeconds -= 1;
                if (floorAccessTime.TimeInSeconds == 0)
                {
                    floorSelectionReportingList.Remove(deviceAddress);
                }
            }
        }
        #endregion

        #region MacroFloorAccess
        private Dictionary<int, List<MacroFloorAccessTime>> macroFloorAccessTimeList = new Dictionary<int, List<MacroFloorAccessTime>>();
        private IPacomTimer macroFloorAccessTimer = null;

        public void SetAccessFloor(int floorId, int timeInSeconds)
        {
            if (floorId > 0 && floorId <= 128)
            {
                int addressOffset = (floorId - 1) / 16;
                foreach (var elevator in ConfigurationManager.Instance.Elevators)
                {
                    if (elevator != null && elevator.Enabled)
                    {
                        int deviceAddress = elevator.GetFloorControllerAddresses()[addressOffset];
                        if (deviceAddress > 0)
                        {
                            int floorNumberOnDevice = (floorId - 1) % 16;
                            if (macroFloorAccessTimeList.ContainsKey(deviceAddress) == true)
                                macroFloorAccessTimeList[deviceAddress].Add(new MacroFloorAccessTime(floorNumberOnDevice, timeInSeconds));
                            else
                                macroFloorAccessTimeList[deviceAddress] = new List<MacroFloorAccessTime>() { new MacroFloorAccessTime(floorNumberOnDevice, timeInSeconds) };
                            unlockFloors(deviceAddress, getAccessFloorsOnDevice(deviceAddress), 0);
                            if (macroFloorAccessTimer == null)
                                macroFloorAccessTimer = TimerManager.Instance.CreateTimer(onMacroFloorAccessTimeout, null, 1000, 1000);
                        }
                    }
                }
            }
        }

        private int getAccessFloorsOnDevice(int deviceAddress)
        {
            int accessFloors = 0;
            var floorAccessTimeList = macroFloorAccessTimeList[deviceAddress];
            if (floorAccessTimeList != null && floorAccessTimeList.Count > 0)
            {
                foreach (var floor in floorAccessTimeList)
                {
                    accessFloors |= (1 << floor.FloorId);
                }
            }
            if(unlockScheduledFloorsList.ContainsKey(deviceAddress) == true)
                accessFloors |= unlockScheduledFloorsList[deviceAddress];
            return accessFloors;
        }

        private void onMacroFloorAccessTimeout(object state)
        {
            if (macroFloorAccessTimeList.Count == 0)
            {
                TimerManager.Instance.RemoveTimer(macroFloorAccessTimer);
                macroFloorAccessTimer = null;
                return;
            }

            foreach (var deviceAddress in macroFloorAccessTimeList.GetKeys())
            {
                bool updateOutputs = false;
                foreach (var floor in macroFloorAccessTimeList[deviceAddress].ToArray())
                {
                    floor.TimeInSeconds -= 1;
                    if (floor.TimeInSeconds == 0)
                    {
                        macroFloorAccessTimeList[deviceAddress].Remove(floor);
                        updateOutputs = true;
                    }
                }

                if (updateOutputs == true)
                {
                    unlockFloors(deviceAddress, getAccessFloorsOnDevice(deviceAddress), 0);
                    if (macroFloorAccessTimeList[deviceAddress].Count == 0)
                        macroFloorAccessTimeList.Remove(deviceAddress);
                }
            }
        }

        #endregion

        #region CleanUp
        internal override void Cleanup()
        {
            if (macroFloorAccessTimer != null)
            {
                macroFloorAccessTimer.Stop();
                TimerManager.Instance.RemoveTimer(macroFloorAccessTimer);
            }
            StatusManager.Instance.Devices.ChangedIsolatedStatus -= new EventHandler<StatusManagerDeviceChangedIsolatedEventArgs>(onDeviceChangedIsolatedStatus);
            floorUnlockSchedulesStatus.SchedulesStatusChanged -= new EventHandler<SchedulesChangedEventArgs>(onFloorUnlockSchedulesStatusChanged);
            floorUnlockSchedulesStatus.SchedulesConfigurationChanged -= new EventHandler<SchedulesChangedEventArgs>(onFloorUnlockSchedulesConfigurationChanged);
        }
        #endregion
    }
}
