﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Core.Contracts.Status;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Base class for status manager lists
    /// </summary>
    public abstract class StatusListBase<T, TP> : IDisposable
        where T : StatusBase<TP>
    {
        private readonly object statusListSync = new object();

        private readonly SortedList<int, T> statusList = new SortedList<int, T>();

        protected StatusListBase()
        {
        }

        /// <summary>
        /// Assign status object to the specified key
        /// </summary>
        /// <param name="key">Logical Id</param>
        /// <param name="previousStatus">Previous item status</param>
        /// <param name="previousInformation">Previous item information</param>
        internal void Assign(int key, T statusItem)
        {
            if (statusItem != null)
                statusList[key] = statusItem;
        }

        internal void Remove(int key)
        {
            try
            {
                var statusItem = statusList[key];
                statusList.Remove(key);
                statusItem.Dispose();
            }
            catch
            {
            }
        }

        /// <summary>
        /// Returns number of status items managed by this list.
        /// </summary>
        internal bool IsEmpty
        {
            get 
            {
                lock (statusListSync)
                {
                    return statusList.Count == 0;
                }
            }
        }

        /// <summary>
        /// Return the status list elements as an array that can be iterated independently
        /// </summary>
        public T[] Items
        {
            get
            {
                lock (statusListSync)
                {
                    return statusList.Values.ToArray();
                }
            }
        }

        public int[] Ids
        {
            get
            {
                lock (statusListSync)
                {
                    return statusList.Keys.ToArray();
                }
            }
        }

        /// <summary>
        /// Return status object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Logical node id, 1 based</param>
        /// <returns>Node status instance or null if not found</returns>
        public virtual T this[int logicalId]
        {
            get
            {
                lock (statusListSync)
                {
                    if (logicalId < 1 || statusList == null || statusList.Count < 1)
                        return null;
                    T outputItem = null;
                    statusList.TryGetValue(logicalId, out outputItem);
                    return outputItem;
                }
            }
        }

        internal virtual void Persist(Asn1DerFormatter asn1Serializer, Stream statusStream) { }

        /// <summary>
        /// Create event state for all items in the Status List and append them to the "statusList" list
        /// </summary>
        /// <param name="statusList">List to add the created Event State instances to</param>
        public void CreateEventState(List<NodeStateBase> statusList) 
        {
            foreach (var item in Items)
            {
                if (item == null || item.Enabled == false)
                    continue;
                statusList.Add(item.CreateEventState());
            }
        }

        #region IDisposable Members

        internal virtual void Cleanup() 
        {
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
            {
                return string.Format("Clearing list: {0}", this.ToString());
            });
#endif
        }

        protected bool disposed = false;
        protected bool disposing = false;        

        private void Dispose(bool disposing)
        {
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
            {
                return string.Format("Disposing list: {0}", this.ToString());
            });
#endif
            try
            {
                if (disposed == false)
                {
                    if (disposing)
                    {
                        this.disposing = true;
                        this.Cleanup();
                    }
                    disposed = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while disposing status list. {0}", ex.ToString());
                });
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
