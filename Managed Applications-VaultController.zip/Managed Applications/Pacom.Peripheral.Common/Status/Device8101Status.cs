﻿using Pacom.Core.Contracts;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Core.Contracts.Status;

namespace Pacom.Peripheral.Common.Status
{
    public sealed class Device8101Status : DeviceKeypadStatus
    {
        public Device8101Status(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus) :
            base(configuration, parent, previousStatus)
        {
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            Device8101DCEventState deviceState = new Device8101DCEventState();
            InitializeEventState(deviceState);
            deviceState.Lockout = LockedOut;
            deviceState.TooManyInvalidLogonAttempts = CurrentAlarms.Has(EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts);
            return deviceState;
        }
    }
}
