﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Peripheral.Common.Utils;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Core.Contracts.Status;

namespace Pacom.Peripheral.Common.Status
{
    public class ExpansionCardStatusList : StatusListBase<ExpansionCardStatus, ExpansionCardStatusList>
    {
        private SuspectedExpansionCardsAgent suspectedOfflineExpansionCards = null;

        /// <summary>
        /// The expansion cards will be added to this agent suspected list when the controller restarts or when the configuration has changed
        /// </summary>
        private DelayedStatusNodesUpdateAgent initialOnlineExpansionCards = null;

        internal ExpansionCardStatusList()
        {
            suspectedOfflineExpansionCards = new SuspectedExpansionCardsAgent();
            suspectedOfflineExpansionCards.CustomAction = suspectedOfflineExpansionCardsCustomAction;
            initialOnlineExpansionCards = new DelayedStatusNodesUpdateAgent();
            initialOnlineExpansionCards.CustomAction = suspectedOfflineExpansionCardsCustomAction;
        }

        /// <summary>
        /// Triggered when the online status of any of the expansion cards on any of the 8501 devices
        /// or on the controller itself changes.
        /// </summary>
        public event EventHandler<ExpansionCardOnlineOfflineEventArgs> ExpansionCardMaskedOnlineStatusChanged = null;

        /// <summary>
        /// Triggered when the isolated flag of any of the expansion cards changes.
        /// </summary>
        public event EventHandler<StatusManagerExpansionCardChangedIsolatedEventArgs> ChangedIsolatedStatus = null;

        /// <summary>
        /// Triggered when the power supply fuse state changes.
        /// </summary>
        public event EventHandler<ItemStatusChangedEventArgs> FuseFailed = null;

        /// <summary>
        /// Triggered when a expansion card substitution is detected
        /// </summary>
        public event EventHandler<ExpansionCardSubstitutionEventArgs> ExpansionCardSubstitutionDetected = null;

        /// <summary>
        /// Triggered when a the GPRS signal changes
        /// </summary>
        public event EventHandler<GprsSignalStrengthArgs> GprsSignalStrengthChanged = null;

        /// <summary>
        /// Triggered when any of the expansion cards changed its alarm state: Online / Fuse Fail / Signal Fail / etc.
        /// </summary>
        public event EventHandler<ExpansionCardAlarmChangedStateEventArgs> DeviceChangedAlarmState = null;

        /// <summary>
        /// Trigger when expansion card alarm status has changed
        /// </summary>
        /// <param name="statusItem"></param>
        internal void TriggerDeviceChangedAlarmState(ExpansionCardStatus expansionCardStatus)
        {
            if (DeviceChangedAlarmState != null)
            {
                DeviceChangedAlarmState(this, new ExpansionCardAlarmChangedStateEventArgs(expansionCardStatus));
            }
        }

        /// <summary>
        /// Trigger expansion card masked online state changed. This will be subscribed to by the Alarm Manager.
        /// </summary>
        /// <param name="expansionCardStatus">New expansion card status information</param>
        internal void TriggerExpansionCardMaskedOnlineStatusChanged(ExpansionCardStatus expansionCardStatus)
        {
            // Trigger common expansion card online changed event
            if (ExpansionCardMaskedOnlineStatusChanged != null)
            {
                ExpansionCardMaskedOnlineStatusChanged(expansionCardStatus, new ExpansionCardOnlineOfflineEventArgs(expansionCardStatus.LogicalId, expansionCardStatus.MaskedOnline == false));
            }
            TriggerDeviceChangedAlarmState(expansionCardStatus);
        }

        /// <summary>
        /// Trigger expansion card masked online state changed. This will be subscribed to by the Alarm Manager.
        /// </summary>
        /// <param name="expansionCardStatus">New expansion card status information</param>
        internal void ExpansionCardOnlineStatusChanged(ExpansionCardStatus expansionCardStatus)
        {
            // Remove expansion card from suspected offline card list when card goes online
            if (expansionCardStatus.Online == true)
            {
                // Remove expansion card from suspected offline expansion cards list when expansion card goes online
                suspectedOfflineExpansionCards.RemoveStatusNode(expansionCardStatus.LogicalId);
                // Remove expansion card from delayed offline expansion cards list when expansion card goes online (when controller restarts or configuration changes)
                initialOnlineExpansionCards.RemoveStatusNode(expansionCardStatus.LogicalId);
                // Reschedule the timer for expansion card status and information update. When the timer expires the expansion card status and information will
                // be uploaded to SM
                var statusUpdateAgent = StatusManager.Instance.StatusUpdateAgent;
                if (statusUpdateAgent != null)
                    statusUpdateAgent.RescheduleTimer();
            }
        }

        /// <summary>
        /// Triggered when expansion card device isolated status has changed
        /// </summary>
        /// <param name="expansionCardStatus">The expansion card status instance that has changed.</param>
        /// <param name="isolated">The new value of the device isolated status.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        internal void TriggerChangedIsolatedStatus(ExpansionCardStatus expansionCardStatus, EventSourceLatchOrIsolateType isolatedAlarms,
                                                   EventSourceLatchOrIsolateType previousIsolatedAlarms, UserAuditInfo userAuditInfo)
        {
            if (ChangedIsolatedStatus != null)
            {
                ChangedIsolatedStatus(this, new StatusManagerExpansionCardChangedIsolatedEventArgs(expansionCardStatus, isolatedAlarms, previousIsolatedAlarms, userAuditInfo));
            }
            TriggerDeviceChangedAlarmState(null);
        }

        /// <summary>
        /// Trigger expansion card fuse failed / fuse restored event
        /// </summary>
        /// <param name="expansionCardStatus">Expansion card that triggered the fuse failed event.</param>
        /// <param name="fuseFailed">Fuse failed = TRUE / fuse restored = FALSE</param>
        internal void TriggerFuseFailed(ExpansionCardStatus expansionCardStatus, bool fuseFailed)
        {
            if (FuseFailed != null)
            {
                FuseFailed(expansionCardStatus, new ItemStatusChangedEventArgs(expansionCardStatus.LogicalId, fuseFailed));
            }
            TriggerDeviceChangedAlarmState(expansionCardStatus);
        }

        /// <summary>
        /// Trigger an event when expansion card is suspected to go offline
        /// </summary>
        /// <param name="expansionCardStatus"></param>
        internal void TriggerExpansionSuspectedOffline(ExpansionCardStatus expansionCardStatus)
        {
            suspectedOfflineExpansionCards.AddStatusNode(expansionCardStatus.LogicalId, true);
        }

        /// <summary>
        /// Trigger an event when expansion card is substituted.
        /// </summary>
        /// <param name="expansionCardStatus"></param>
        internal void TriggerExpansionCardSubstitution(ExpansionCardStatus expansionCardStatus, bool restore)
        {
            if (ExpansionCardSubstitutionDetected != null)
			{
                ExpansionCardSubstitutionDetected(expansionCardStatus, new ExpansionCardSubstitutionEventArgs(expansionCardStatus.LogicalId, restore));
            }
            TriggerDeviceChangedAlarmState(expansionCardStatus);
        }

        internal void TriggerGprsSignalStrengthChanged(GprsExpansionCardStatus deviceStatus, GprsNetworkSignalStrength previousSignalStrength, GprsNetworkSignalStrength signalStrength)
        {
            if (GprsSignalStrengthChanged != null)
            {
                GprsSignalStrengthChanged(deviceStatus, new GprsSignalStrengthArgs(deviceStatus.LogicalId, previousSignalStrength, signalStrength));
            }
            TriggerDeviceChangedAlarmState(deviceStatus);
        }

        /// <summary>
        /// Isolate a list of expansion cards for a specified duration or deisolate a list of expansion cards.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited activate / deactivate expansion card(s) command.</param>
        /// <returns></returns>
        public bool SetIsolated(List<int> deviceIds, EventSourceLatchOrIsolateType value, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            if (value != EventSourceLatchOrIsolateType.None)
            {
                // Isolate expansion card device alarms
                List<int> devicesToDeisolate = new List<int>(deviceIds.Count);
                foreach (int deviceId in deviceIds)
                {
                    ExpansionCardStatus status = this[deviceId];
                    if (status != null && status.Enabled == true)
                    {
                        if (status.SetIsolated(userAuditInfo, value) == true)
                            devicesToDeisolate.Add(deviceId);
                    }
                }
                if (durationInSeconds > 0 && devicesToDeisolate.Count > 0)
                {
                    StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.DeisolateDevices, devicesToDeisolate, userAuditInfo, durationInSeconds);
                }
                return (devicesToDeisolate.Count > 0);
            }
            else
            {
                // Deisolate expansion card device alarms. It does not support a duration.
                bool result = false;
                foreach (int deviceId in deviceIds)
                {
                    ExpansionCardStatus status = this[deviceId];
                    if (status != null && status.Enabled == true)
                    {
                        if (status.SetIsolated(userAuditInfo, EventSourceLatchOrIsolateType.None) == true)
                            result = true;
                    }
                }
                return result;
            }
        }

        /// <summary>
        /// Get the list of expansion cards that have alarms
        /// </summary>
        /// <returns></returns>
        public List<IStatusItem> GetDevicesWithAlarms()
        {
            List<IStatusItem> alarmedDevices = new List<IStatusItem>();
            foreach (ExpansionCardStatus expansionCard in Items)
            {
                if (expansionCard != null && expansionCard.Enabled == true && expansionCard.CurrentAlarms != EventSourceLatchOrIsolateType.None)
                    alarmedDevices.Add(expansionCard);
            }
            return alarmedDevices;
        }

        /// <summary>
        /// Check if any of the expansion cards has any active alarms
        /// </summary>
        public bool AnyInAlarm
        {
            get
            {
                foreach (ExpansionCardStatus expansionCard in Items)
                {
                    if (expansionCard != null && expansionCard.Enabled == true && expansionCard.Parent.DeviceRestarting(expansionCard.LogicalId) == false && 
                        expansionCard.CurrentAlarms != EventSourceLatchOrIsolateType.None)
                        return true;
                }
                return false;
            }
        }

        /// <summary>
        /// Get the list of expansion cards that have isolated alarms (one or all internal device inputs). E.g.: OFFLINE, FUSE FAIL, etc.  
        /// </summary>
        /// <returns></returns>
        public List<IStatusItem> GetIsolated()
        {
            List<IStatusItem> isolatedDevices = new List<IStatusItem>();
            foreach (ExpansionCardStatus expansionCard in Items)
            {
                if (expansionCard != null && expansionCard.Enabled == true && expansionCard.IsolatedAlarms != EventSourceLatchOrIsolateType.None)
                {
                    isolatedDevices.Add(expansionCard);
                }
            }
            return isolatedDevices;
        }

        /// <summary>
        /// Check if any of the expansion cards has any isolated alarms
        /// </summary>
        public bool AnyIsolated
        {
            get
            {
                foreach (ExpansionCardStatus expansionCard in Items)
                {
                    if (expansionCard != null && expansionCard.Enabled == true && expansionCard.IsolatedAlarms != EventSourceLatchOrIsolateType.None)
                        return true;
                }
                return false;
            }
        }

        private void suspectedOfflineExpansionCardsCustomAction(int[] expiredNodes)
        {
            foreach (int nodeLogicalId in expiredNodes)
            {
                ExpansionCardStatus expansionCardStatus = this[nodeLogicalId] as ExpansionCardStatus;
                if (expansionCardStatus != null)
                {
                    expansionCardStatus.NotifyExpansionCardOffline();
                }
            }
        }

        /// <summary>
        /// Called after the configuration is ready but after the lists are repopulated.
        /// </summary>
        /// <param name="controllerRestarted">True if controller was restarted</param>
        internal void AfterStatusUpdate()
        {
            // Re-initialize the suspected Offline expansion cards agent initial time and poll period
            suspectedOfflineExpansionCards.SetInitialTimeAndPollPeriod();
            // Re-initialize the delayed offline expansion cards agent initial time and poll period when 
            // controller restarts / configuration changes
            initialOnlineExpansionCards.SetInitialTimeAndPollPeriod();

            // Add to the list
            List<int> expCardsToAdd = new List<int>();
            foreach (var expCard in Items)
            {
                if (expCard != null && expCard.Enabled == true &&
                    expCard.OfflineType == ExpansionCardOfflineStatusType.SuspectedOffline)
                {
                    expCardsToAdd.Add(expCard.LogicalId);
                }
            }
            initialOnlineExpansionCards.AddStatusNodes(expCardsToAdd.ToArray());
        }

        /// <summary>
        /// Check if the expansion card is restarting, allow for the expansion card to come online in 5 min.
        /// </summary>
        /// <param name="logicalId">Expansion card logical id</param>
        /// <returns>True if the expansion card is restarting.</returns>
        public bool DeviceRestarting(int logicalId)
        {
            SuspectedStatusNodeDetails[] nodes = initialOnlineExpansionCards.Nodes;
            if (nodes.Length == 0)
                return false;

            return nodes.FirstOrDefault(node => node.LogicalId == logicalId) != null;
        }

        /// <summary>
        /// Update expansion cards status list from configuration. Add new expansion card status instances if not already existing
        /// </summary>
        /// <param name="expansionCards">List of expansion cards configuration to add</param>
        /// <param name="statusStorage">Stataus Storage instance or null if status restore is not required</param>
        internal void UpdateFromConfiguration(ExpansionCardDeviceConfigurationBase[] expansionCards, StatusStorageCollection statusStorage)
        {
            foreach (var expCard in expansionCards)
            {
                ExpansionCardStatusStorage expansionCardStatusStorage = statusStorage.ExpansionCardsStatus.TryGetValue(expCard.Id);
                ExpansionCardStatus expCardStatus = null;
                if (expCard.HardwareType.IsCellular() == false)
                    expCardStatus = new ExpansionCardStatus(expCard, this, expansionCardStatusStorage);
                else
                    expCardStatus = new GprsExpansionCardStatus(expCard, this, expansionCardStatusStorage);
                Assign(expCard.Id, expCardStatus);
            }
        }

        /// <summary>
        /// Update ExpansionCard status list from configuration on configuration change.
        /// </summary>
        internal void UpdateFromConfiguration(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems, List<NodeStateBase> partialStatusList)
        {
            foreach (var removedItem in removedItems)
            {
                if (removedItem.ConfigurationType == ConfigurationElementType.ExpansionCard)
                    Remove(removedItem.Id);
            }
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.ExpansionCard)
                {
                    Remove(changedItem.Id);
                    try
                    {
                        ExpansionCardDeviceConfigurationBase expansionCardConfiguration = ConfigurationManager.Instance.GetExpansionCardDeviceConfiguration(changedItem.Id);
                        if (expansionCardConfiguration != null)
                        {
                            Assign(changedItem.Id, new ExpansionCardStatus(expansionCardConfiguration, this, null));
                            partialStatusList.Add(this[changedItem.Id].CreateEventState());
                        }
                    }
                    catch
                    {
                    }
                }
            }
            foreach (var newlyAddedItem in newlyAddedItems)
            {
                try
                {
                    if (newlyAddedItem.ConfigurationType == ConfigurationElementType.ExpansionCard)
                    {
                        ExpansionCardDeviceConfigurationBase expansionCardConfiguration = ConfigurationManager.Instance.GetExpansionCardDeviceConfiguration(newlyAddedItem.Id);
                        if (expansionCardConfiguration != null)
                        {
                            Assign(newlyAddedItem.Id, new ExpansionCardStatus(expansionCardConfiguration, this, null));
                            partialStatusList.Add(this[newlyAddedItem.Id].CreateEventState());
                        }
                    }
                }
                catch
                {
                }
            }
        }

        /// <summary>
        /// Create device information for all devices and add it to the supplied list
        /// </summary>
        /// <param name="deviceInformationList">Device information list to add to</param>
        public void CreateDeviceInformation(List<DeviceInformation> deviceInformationList)
        {
            foreach (var expCard in Items)
            {
                if (expCard == null || expCard.Enabled == false)
                    continue;
                deviceInformationList.Add(expCard.CreateDeviceInformation());
            }
        }

        internal override void Persist(Asn1DerFormatter asn1Serializer, Stream statusStream)
        {
            foreach (var card in Items)
            {
                try
                {
                    asn1Serializer.Serialize(statusStream, card.CreateStatusStorage());
                }
                catch (Exception ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Unable to store status for expansion card {0}. {1}", card.LogicalId, ex.Message);
                    });
                }
            }
        }

        internal override void Cleanup()
        {
            suspectedOfflineExpansionCards.Dispose();
            suspectedOfflineExpansionCards = null;

            initialOnlineExpansionCards.Dispose();
            initialOnlineExpansionCards = null;
        }
    }
}
