﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Peripheral.Macros;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.Utils;
using Pacom.Core.Contracts;
using Pacom.Core.Contracts.Status;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Collection of all area statuses with utility functions
    /// </summary>
    public class AreaStatusList : StatusListBase<AreaStatus, AreaStatusList>, IDisposable
    {
        internal AreaStatusList()
            : base()
        {
            areaScheduleTimer = TimerManager.Instance.CreateTimer(areaScheduleTimerProc);
            ConfigurationManager.Instance.ConfigurationChanging += new EventHandler<ConfigurationChangeEventArgs>(configurationManager_ConfigurationChanging);
        }

        private const int testModeWarningTime = 120;

        /// <summary>
        /// Triggered when one area mode has changed.
        /// </summary>
        public event EventHandler<AreaChangedStatusEventArgs> AreaChangedMode = null;

        /// <summary>
        /// Triggered when one area duress state has changed.
        /// </summary>
        public event EventHandler<AreaChangedDuressModeEventArgs> AreaChangedDuressMode = null;

        /// <summary>
        /// Triggered when one area confirmed alarm state has changed.
        /// </summary>
        public event EventHandler<AreaConfirmedAlarmEventArgs> AreaConfirmedAlarmState = null;

        /// <summary>
        /// Triggered when area alarm confirmation timer has expired (used when alarm sequential confirmation is required, e.g. BS8243:2010).
        /// </summary>
        public event EventHandler AreaConfirmationTimerExpired = null;

        /// <summary>
        /// Trigger when an area being unset (disarmed), while there's still confirmed/unconfirmed alarms (required for BS8243)
        /// </summary>
        public event EventHandler<AlarmCancelEventArgs> ConfirmedAlarmCancel = null;

        /// <summary>
        /// Triggered when one area has become alarmed or secure.
        /// </summary>
        public event EventHandler<AreaChangedStatusEventArgs> AreaChangedAlarmedState = null;

        /// <summary>
        /// Triggered when one area has either started or completed an entry delay.
        /// </summary>
        public event EventHandler<AreaChangedStatusEventArgs> AreaChangedEntryDelayedState = null;

        /// <summary>
        /// Triggered when an input point has been tested.
        /// </summary>
        public event EventHandler<AlarmAddedEventArgs> InputTested = null;

        /// <summary>
        /// Triggered when an input point has changed state.
        /// </summary>
        public event EventHandler<ReadyToArmEventArgs> ReadyToArmChanged = null;

        /// <summary>
        /// Triggered when one or more areas have entered test mode.
        /// </summary>
        public event EventHandler<AreaTestModeEventArgs> TestModeEntered = null;

        /// <summary>
        /// Triggered when one or more areas have exited from test mode.
        /// </summary>
        public event EventHandler<AreaTestModeEventArgs> TestModeExited = null;

        /// <summary>
        /// Triggered when one or more areas are about to exit from test mode due to a timer expiry.
        /// </summary>
        public event EventHandler<AreaTestModeEventArgs> TestModeWarning = null;

        /// <summary>
        /// Triggered when an area arming is delayed 
        /// </summary>
        public event EventHandler<AreaDelayArmingEventArgs> AreaDelayArmingEvent = null;

        /// <summary>
        /// Triggered when an area delay arming failed
        /// </summary>
        public event EventHandler<AreaDelayArmingEventArgs> AreaFailedArmingDelayEvent = null;

        #region Arm / Disarm area(s) based on area schedule settings

        /// <summary>
        /// Reader Schedule Timer that fires on the StartTime for each schedule record interval for current day and 
        /// will update the ReaderStatus for all readers that follow this schedule.
        /// </summary>
        private IPacomTimer areaScheduleTimer = null;

        private bool disabled { get; set; }

        #endregion

        #region Arm area(s) with delay

        /// <summary>
        /// Event triggered when an area or a list of areas is armed with delay. Up to 2 dealys
        /// can be specified. The keypads will subscribe to this event and any keypad that is online
        /// and has access to any of the areas that will be armed will start the arming process.
        /// </summary>
        public event EventHandler<StartArmingEventArgs> StartArming = null;

        /// <summary>
        /// Event triggered when an area or a list of areas is armed with delay. This event is triggered
        /// at the end of arming process and just before the areas will be armed. This event will notify
        /// any online keypads that they need to stop the arming process, cleanup and then enter the Idle 
        /// state.
        /// </summary>
        public event EventHandler<StopArmingEventArgs> StopArming = null;

        /// <summary>
        /// Event triggered when an area is delayed. This event will notify any online keypad to go to idle state 
        /// </summary>
        public event EventHandler ExitArming = null;

        /// <summary>
        /// Event triggered every time the arm area task armingDelayTimer fires apart from the 1st and last times. 
        /// The keypads that subscribed to this event will beep the buzzer if beep on exit is enabled for areas in
        /// arm area task.
        /// </summary>
        public event EventHandler<CountdownArmingEventArgs> CountdownArming = null;

        /// <summary>
        /// Event triggered when an area or a set of areas is armed with delay and the completion of arming is done in a 2nd step from outisde the
        /// secured premises. If the area(s) are not armed when the arming delay expires this event will be triggered.
        /// </summary>
        public event EventHandler<FailedToArmAreaEventArgs> FailedToArmArea = null;

        /// <summary>
        /// Event triggered when an area does not AutoArm on area schedule change and is not Armed when the schedule change happens. 
        /// </summary>
        public event EventHandler<AreaStatusEventArgs> AreaLateToClose = null;

        /// <summary>
        /// Event triggered when an area is late to close in order to beep the keypad buzzer every 1 minute. 
        /// </summary>
        public event EventHandler<AreaStatusEventArgs> AreaLateToCloseBeepKeypadBuzzer = null;

        /// <summary>
        /// Event triggered when an area fails to arm in order to beep the keypad buzzer. 
        /// </summary>
        public event EventHandler<AreaStatusEventArgs> AreaFailToArmBeepKeypadBuzzer = null;

        public int KeypadId
        {
            get;
            private set;
        }

        /// <summary>
        /// The keypad Id for the keypad on which an user tries to log in to stop the currently area arming task. 
        /// </summary>
        public int UserLoginKeypadId
        {
            get;
            private set;
        }

        private List<ArmAreaTaskHolder> armAreaTasks = new List<ArmAreaTaskHolder>();

        private object areaArmDisarmLock = new object();

        #endregion

        /// <summary>
        /// Trigger area status changed event handler
        /// </summary>
        /// <param name="areaStatus">Area whose status has changed.</param>
        /// <param name="userAuditInfo">User that is changing the area mode.</param>
        internal void TriggerAreaModeChanged(AreaStatus areaStatus, UserAuditInfo userAuditInfo)
        {
            if (AreaChangedMode != null)
                AreaChangedMode(this, new AreaChangedStatusEventArgs(areaStatus, userAuditInfo));
        }

        /// <summary>
        /// Trigger area duress status changed event handler
        /// </summary>
        /// <param name="areaStatus">Area whose status has changed.</param>
        internal void TriggerAreaDuressModeChanged(AreaStatus areaStatus, bool duressActive)
        {
            if (AreaChangedDuressMode != null)
                AreaChangedDuressMode(this, new AreaChangedDuressModeEventArgs(areaStatus, duressActive));
        }

        /// <summary>
        /// Trigger area confirmed alarm state changed: set / restore
        /// </summary>
        /// <param name="areaStatus"></param>
        /// <param name="userAuditInfo">User that is changing the area mode.</param>
        internal void TriggerAreaConfirmedAlarmStateChanged(AreaStatus areaStatus, UserAuditInfo userAuditInfo)
        {
            if (AreaConfirmedAlarmState != null)
                AreaConfirmedAlarmState(areaStatus, new AreaConfirmedAlarmEventArgs(areaStatus, userAuditInfo));
        }

        /// <summary>
        /// Trigger area ready to arm changed event
        /// </summary>
        /// <param name="areaStatus">Area that has became alarmed.</param>
        internal void TriggerReadyToArmChanged(AreaStatus areaStatus, bool readyToArm)
        {
            if (ReadyToArmChanged != null)
                ReadyToArmChanged(this, new ReadyToArmEventArgs(areaStatus, readyToArm));
        }

        /// <summary>
        /// Trigger area alarmed event
        /// </summary>
        /// <param name="areaStatus">Area that has became alarmed.</param>
        internal void TriggerAreaAlarmed(AreaStatus areaStatus)
        {
            if (areaStatus != null)
                MacroControl.Instance.EnqueueAreaAlarm(areaStatus.LogicalId, MacroAreaAlarmType.AreaAlarmed, false);
            if (AreaChangedAlarmedState != null)
                AreaChangedAlarmedState(this, new AreaChangedStatusEventArgs(areaStatus, ConfigurationManager.SystemUser));
        }

        /// <summary>
        /// Triggered when area alarm confirmation timer has expired
        /// </summary>
        /// <param name="areaStatus">Area that has became alarmed.</param>
        internal void TriggerAreaAlarmConfirmationTimerExpired(AreaStatus areaStatus)
        {
            if (areaStatus != null)
                MacroControl.Instance.EnqueueAreaAlarm(areaStatus.LogicalId, MacroAreaAlarmType.None, true);
            if (AreaConfirmationTimerExpired != null)
                AreaConfirmationTimerExpired(areaStatus, new EventArgs());
            // BS 8243: Inhibit active unconfirmed alarm, and notify inhibition to ARC while re-instating IAS / HAS
            if (areaStatus != null)
            {
                foreach (IStatusItem input in StatusManager.Instance.Inputs.GetInputsInArea(areaStatus.LogicalId))
                {
                    InputStatus inputStatus = input as InputStatus;
                    if (inputStatus.ConfirmedAlarmType == ConfirmedAlarmType.BS8243Compliant &&
                        inputStatus.ConfirmedType == ConfirmedType.Unconfirmed &&
                        inputStatus.UnmaskedStatus != Pacom.Peripheral.Common.InputStatus.Secure)
                    {
                        inputStatus.SetIsolated(true, ConfigurationManager.SystemUser); // Inhitbit
                    }
                }
                StatusManager.Instance.Inputs.RestoreInArea(areaStatus, ConfigurationManager.SystemUser);   // Re-instate
            }
        }

        /// <summary>
        /// Triggered if there's any active confirmed/unconfirmed alarms when an area is unset (disarmed).
        /// </summary>
        /// <param name="areaStatus">Area that has became alarmed.</param>
        internal void TriggerConfirmedAlarmCancel(AreaStatus areaStatus)
        {
            if (ConfirmedAlarmCancel != null)
                ConfirmedAlarmCancel(this, new AlarmCancelEventArgs(areaStatus, ConfigurationManager.SystemUser));
        }

        /// <summary>
        /// Trigger area restored to secure state event. All area inputs are in secure state.
        /// </summary>
        /// <param name="areaStatus">Area that is secure.</param>
        internal void TriggerAreaRestored(AreaStatus areaStatus)
        {
            if (areaStatus != null)
                MacroControl.Instance.EnqueueAreaAlarm(areaStatus.LogicalId, MacroAreaAlarmType.AreaRestored, false);
            if (AreaChangedAlarmedState != null)
                AreaChangedAlarmedState(this, new AreaChangedStatusEventArgs(areaStatus, ConfigurationManager.SystemUser));
        }

        /// <summary>
        /// Trigger area restored to secure state event. All area inputs are in secure state.
        /// </summary>
        /// <param name="areaStatus">Area that is secure.</param>
        internal void TriggerAreaChangedEntryDelayedState(AreaStatus areaStatus)
        {
            if (AreaChangedEntryDelayedState != null)
                AreaChangedEntryDelayedState(this, new AreaChangedStatusEventArgs(areaStatus, ConfigurationManager.SystemUser));
        }

        /// <summary>
        /// Returns false and changes nothing if any area is not in day mode.
        /// </summary>
        /// <param name="areaIds"></param>
        /// <param name="durationInMinutes"></param>
        /// <param name="userAuditInfo">User that initiaited the Enter Test Mode area(s) action.</param>
        /// <returns></returns>
        public bool EnterTestMode(List<int> areaIds, int durationInMinutes, UserAuditInfo userAuditInfo, bool forceEnter)
        {
            if (areaIds == null || areaIds.Count == 0)
                return false;

            bool proceedWithTest = true;
            List<int> permittedAreas = GetAreasForUser(userAuditInfo.OriginatingUserId);
            List<int> areasToTest = new List<int>(areaIds.Intersect(permittedAreas).ToArray());

            if (areasToTest.Count != areaIds.Count)
                return false;

            lock (areaArmDisarmLock)
            {
                if (forceEnter == false)
                {
                    foreach (int areaId in areasToTest)
                    {
                        AreaStatus areaStatus = this[areaId];
                        if (areaStatus == null || areaStatus.Mode == AreaScheduleLevel.Armed)
                        {
                            proceedWithTest = false;
                            break;
                        }
                    }
                }

                if (proceedWithTest)
                {
                    foreach (int areaId in areasToTest)
                    {
                        this[areaId].SetTestMode(userAuditInfo, true, forceEnter);
                    }

                    if (durationInMinutes != int.MaxValue)
                    {
                        int durationInSeconds = (durationInMinutes * 60) - testModeWarningTime;
                        if (durationInSeconds < 0)
                            durationInSeconds = 0;
                        StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.WarnTestMode, areasToTest);
                        StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.ExitTestMode, areasToTest);
                        StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.WarnTestMode, areasToTest, userAuditInfo, durationInSeconds);
                    }

                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Test {0} area(s) for {1} mins.", areasToTest.Count, durationInMinutes);
                    });
                }
            }

            if (proceedWithTest)
            {
                if (TestModeEntered != null)
                    TestModeEntered(this, new AreaTestModeEventArgs(areaIds, userAuditInfo));
            }

            return proceedWithTest;
        }

        /// <summary>
        /// Returns false and changes nothing if any area is not in day mode.
        /// </summary>
        /// <param name="areaIds"></param>
        /// <param name="userAuditInfo">User that initiaited the Enter Test Mode area(s) action.</param>
        internal void WarnTestMode(List<int> areaIds, UserAuditInfo userAuditInfo)
        {
            StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.ExitTestMode, areaIds, userAuditInfo, testModeWarningTime);
            if (TestModeWarning != null)
                TestModeWarning(this, new AreaTestModeEventArgs(areaIds, userAuditInfo));
        }

        /// <summary>
        /// Exit test Mode for selected area(s)
        /// </summary>
        /// <param name="areaIds">Areas to Exit Test Mode for.</param>
        /// <param name="userAuditInfo">User that initiaited the Enter Test Mode area(s) action.</param>
        /// <returns></returns>
        public bool ExitTestMode(List<int> areaIds, UserAuditInfo userAuditInfo, bool forceExit)
        {
            if (areaIds == null || areaIds.Count == 0 || userAuditInfo == null)
                return false;

            bool success = false;
            List<int> permittedAreas = GetAreasForUser(userAuditInfo.OriginatingUserId);
            List<int> areasToTest = new List<int>(areaIds.Intersect(permittedAreas).ToArray());

            lock (areaArmDisarmLock)
            {
                foreach (int areaId in areasToTest)
                {
                    if (this[areaId].InTestMode)
                    {
                        this[areaId].SetTestMode(userAuditInfo, false, false);
                        if (forceExit == true)
                            this[areaId].InTestMode = false;
                        success = true;
                    }
                }
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Ending test for {0} area(s).", areasToTest.Count);
                });
            }
            StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.WarnTestMode, areasToTest);
            StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.ExitTestMode, areasToTest);
            if (success == true && TestModeExited != null)
                TestModeExited(this, new AreaTestModeEventArgs(areaIds, userAuditInfo));

            return success;
        }

        internal void DeisolateAllDeviceAlarmsIfRequired(UserAuditInfo userAuditInfo, List<string> deisolatedPointDisplayNameList)
        {
            // Check if all areas are disarmed and if so, deisolate all devices
            foreach (AreaStatus area in Items)
            {
                if (area.Enabled == true && area.Disarmed == false)
                    return;
            }

            List<IStatusItem> isolatedDevices = StatusManager.Instance.Devices.GetIsolated();
            isolatedDevices.AddRange(StatusManager.Instance.ExpansionCards.GetIsolated());

            foreach (IStatusItem item in isolatedDevices)
            {
                if (ConfigurationManager.Instance.IsKeypadInENMode == true && deisolatedPointDisplayNameList != null)
                {
                    // Add all deisolated device alarms to the keypad status list
                    deisolatedPointDisplayNameList.Add(item.DisplayIsolatedName);
                }
                item.Deisolate(userAuditInfo);
            }
        }

        internal void TriggerInputTested(AreaStatus areaStatus)
        {
            if (InputTested != null)
                InputTested(this, new AlarmAddedEventArgs(areaStatus.LogicalId));
        }

        internal void TriggerTestModeExited(AreaStatus areaStatus, UserAuditInfo userAuditInfo)
        {
            if (TestModeExited != null)
                TestModeExited(this, new AreaTestModeEventArgs(new List<int> { areaStatus.LogicalId }, userAuditInfo));
        }

        #region Arm / Disarm area(s) based on area schedule settings

        private bool isAreaScheduleTimerRunning = false;
        /// <summary>
        /// Check area status matches area schedule value. If not then automatically arm / disarm areas that
        /// obey this area schedule.
        /// </summary>
        internal void UpdateStatus()
        {
            isAreaScheduleTimerRunning = false;
            disabled = false;
            Pacom8003AreaSchedule[] areaSchedules = ConfigurationManager.Instance.AreaSchedules;
            if (areaSchedules.Length == 0)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return "No area schedules exist. The area(s) status will not be updated!";
                });
                return;
            }
            areaScheduleTimerProc(null);
        }

        /// <summary>
        /// Triggered when the configuration is changing. We need to stop the reader schedule timer from running.
        /// The timer will be turned back on when the StatusManager is fully updated after the configuration has 
        /// been updated.
        /// </summary>
        /// <param name="sender">Not Used</param>
        /// <param name="e">Not Used</param>
        private void configurationManager_ConfigurationChanging(object sender, ConfigurationChangeEventArgs e)
        {
            try
            {
                disabled = true;
                cleanCompletedArmTasks();
                areaScheduleTimer.Stop();
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while preparing for configuration change in AreaStatusList : {0}", ex.ToString());
                });
            }
        }

        /// <summary>
        /// Reader Schedule timer procedure
        /// </summary>
        /// <param name="state">Not Used</param>
        private void areaScheduleTimerProc(object state)
        {
            if (disposed == true)
                return;

            if (disabled == true)
                return;

            int nextTimerDueTime = 0;
            DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
            DateTime nextStartTime = DateTime.MaxValue;
            Pacom8003AreaSchedule[] areaSchedules = ConfigurationManager.Instance.AreaSchedules;
            foreach (var areaSchedule in areaSchedules)
            {
                if (areaSchedule != null)
                {
                    DateTime startTime = areaSchedule.RecalculateSchedule(now, this, isAreaScheduleTimerRunning);
                    if (startTime < nextStartTime)
                        nextStartTime = startTime;
                }
            }
            if (nextStartTime <= now)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Next area schedule start time is not in the future: Now = [{0}], NextStartTime = [{1}]",
                        now.ToString("dd/MM/yyyy"), nextStartTime.ToString("dd/MM/yyyy"));
                });
            }
            nextTimerDueTime = (int)((nextStartTime - now).TotalMilliseconds);
            // Set next timer due time
            isAreaScheduleTimerRunning = true;
            areaScheduleTimer.RunOnce(nextTimerDueTime);
        }

        internal void ScheduleChangeNotification(Pacom8003AreaSchedule schedule, Pacom.Core.Contracts.DayType day, int intervalOffset, AreaScheduleLevel level,
            List<int> affectedAreas)
        {
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
            {
                return string.Format("Area schedule notification update. Day:{0}, Interval: {1} Mode:{2}",
                    day.ToString(), intervalOffset, level.ToString());
            });
#endif

            var areaStatuses = this.Items.Select(item => affectedAreas.Any(id => id == item.LogicalId));
            if (level == AreaScheduleLevel.Armed)
            {
                // Evaluate if schedule should be applied to the area
                List<int> areasToArmIds = new List<int>();
                foreach (var areaStatus in areaStatuses)
                {
                    switch (areaStatus.ForcedMode)
                    {
                        case AreaModeUserForcedType.Normal:
                            {
                                if (areaStatus.Mode != level)
                                    areasToArmIds.Add(areaStatus.LogicalId);
                            }
                            break;
                        case AreaModeUserForcedType.UserForced:
                            {
                                if (areaStatus.ForcedDuringDay != day || areaStatus.ForcedDuringIntervalOffset != intervalOffset)
                                {
                                    if (areaStatus.Mode != level)
                                        areasToArmIds.Add(areaStatus.LogicalId);

                                    areaStatus.RestoreForcedToNormal();
                                }
                            }
                            break;
                    }
                }
                if (areasToArmIds.Count > 0)
                {
                    addModeFollowAreasForArming(areasToArmIds);
                    TimeSpan exitDelayFull = TimeSpan.MinValue;
                    TimeSpan exitDelay2 = TimeSpan.MinValue;
                    foreach (var areaLogicalId in areasToArmIds)
                    {
                        AreaConfiguration areaConfig = ConfigurationManager.Instance.GetAreaConfiguration(areaLogicalId);
                        if (areaConfig != null)
                        {
                            exitDelayFull = PacomMath.Max(exitDelayFull, areaConfig.ExitDelay1 + areaConfig.ExitDelay2);
                            exitDelay2 = PacomMath.Max(exitDelay2, areaConfig.ExitDelay2);
                        }
                    }
                    this.ArmAreas(areasToArmIds, (int)exitDelayFull.TotalSeconds, (int)exitDelay2.TotalSeconds, ConfigurationManager.ScheduleUser);
                    foreach (var areaId in areasToArmIds)
                    {
                        AreaStatus areaStatus = StatusManager.Instance.Areas[areaId];
                        if (areaStatus != null)
                        {
                            areaStatus.CanDelayAutomaticArming = true;
                        }
                    }
                }
            }
            else
            {
                foreach (var areaStatus in areaStatuses)
                {
                    // Check if area goes back to disaramed mode
                    if (areaStatus.ForcedMode != AreaModeUserForcedType.Normal &&
                        (areaStatus.ForcedDuringDay != day || areaStatus.ForcedDuringIntervalOffset != intervalOffset))
                    {
                        areaStatus.RestoreForcedToNormal();
                    }
                }
            }
        }

        #endregion

        #region Arm area(s) with delay implementation

        /// <summary>
        /// Arms all areas
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the arm all areas action.</param>
        /// <returns>True if the arm task was started, a similar task is already running or all areas are armed.</returns>
        public bool ArmAllAreas(UserAuditInfo userAuditInfo)
        {
            return ArmAreas(new List<int>(Ids), 0, 0, userAuditInfo);
        }

        /// <summary>
        /// Add mode follow areas to areaIds
        /// </summary>
        /// <param name="areaIds"></param>
        /// <param name="delay"></param>
        /// <param name="userAuditInfo"></param>
        /// <returns></returns>
        public bool AddModeFollowAndArmAreas(List<int> areaIds, int delay, UserAuditInfo userAuditInfo)
        {
            addModeFollowAreasForArming(areaIds);
            return ArmAreas(areaIds, delay, 0, userAuditInfo);
        }

        /// <summary>
        /// Arm one or more areas, with delay. Used when arming one or more areas from a keypad, macro, etc.
        /// </summary>
        /// <param name="areasToArmIds">List of ares.</param>
        /// <param name="delay1">Arming full exit delay in seconds.</param>
        /// <param name="delay2">Arming exit delay2 in seconds.</param>
        /// <param name="userAuditInfo">User that initiaited the arm area action.</param>
        /// <returns>True if the arm task was started, a similar task is already running or all areas are armed.</returns>
        public bool ArmAreas(List<int> areasToArmIds, int delay1, int delay2, UserAuditInfo userAuditInfo)
        {
            // Make sure delay1 & delay2 have valid values
            delay1 = Math.Min(Math.Max(delay1, 0), 2 * Area8003Configuration.MaximumEntryExitDelayInSeconds);
            delay2 = Math.Min(Math.Max(delay2, 0), Area8003Configuration.MaximumEntryExitDelayInSeconds);

            if (armAreaTasks.Count > 0)
            {
                cleanCompletedArmTasks();
            }

            lock (areaArmDisarmLock)
            {
                if (areasToArmIds == null || areasToArmIds.Count == 0 || areasToArmIds.AllArmed() == true)
                    return false;

                // Notify the keypads involved that arming is about to happen. Insure the device loop manager is created and there is at least one
                // keypad ONLINE in the device loop.
                if (StatusManager.Instance.DeviceLoopManager != null && StatusManager.Instance.DeviceLoopManager.OneOrMoreKeypadsOnline == true)
                    StatusManager.Instance.DeviceLoopManager.NotifyKeypadsArmingStarted(areasToArmIds, delay1 == 0);

                if (delay1 == 0)
                {
                    // If no delay was supplied then arm the areas immediately
                    DoArmAreas(areasToArmIds, userAuditInfo);
                    return true;
                }

                KeypadId = -1;
                UserLoginKeypadId = -1;
                // If a similar task is already running return True (a similar arm area task is one that contains any of the areas in areasToArmIds list)
                if (armTaskExists(areasToArmIds) == true)
                    return true;

                ArmAreaTaskHolder armAreaTask = new ArmAreaTaskHolder(this, areasToArmIds, delay1, delay2, userAuditInfo);
                if (armAreaTask != null)
                {
                    armAreaTasks.Add(armAreaTask);
                    armAreaTask.StartArming();
                }
            }
            return true;
        }

        public bool DelayAutomaticArm(int areaId)
        {
            if (armAreaTasks == null || armAreaTasks.Count == 0)
                return false;

            AreaStatus areaStatus = StatusManager.Instance.Areas[areaId];
            AreaConfiguration areaConfig = ConfigurationManager.Instance.GetAreaConfiguration(areaId);
            if (areaStatus != null && areaConfig != null && areaConfig.AutoArmArea)
            {
                if (areaStatus.CanDelayAutomaticArming == false)
                    return false;

                if (areaStatus.HasDelayedAutomaticArm == false && areaConfig.AutomaticArmDelayCount != AutomaticArmDelayCount.Unlimited)
                {
                    ++areaStatus.AutomaticArmDelayCount;
                    if (areaStatus.AutomaticArmDelayCount > areaConfig.AutomaticArmDelayCount.GetValue())
                    {
                        if (AreaFailedArmingDelayEvent != null)
                            AreaFailedArmingDelayEvent(this, new AreaDelayArmingEventArgs(areaStatus, ConfigurationManager.ScheduleUser));
                        MacroControl.Instance.EnqueueAreaAlarm(areaStatus.LogicalId, MacroAreaAlarmType.DelayedAutomaticArmFailed, false);
                        return false;
                    }
                }

                lock (areaArmDisarmLock)
                {
                    bool delayArming = false;
                    armAreaTasks.ForEach(armTask =>
                    {
                        if (armTask.StopArming(areaId) == true)
                            delayArming = true;
                    });

                    if (delayArming)
                    {
                        if (AreaDelayArmingEvent != null)
                            AreaDelayArmingEvent(this, new AreaDelayArmingEventArgs(areaStatus, ConfigurationManager.ScheduleUser));
                        bool isThereAnyAreaArming = armAreaTasks.Any(armTask => { return armTask.AreaIds != null && armTask.AreaIds.Count > 0; });
                        if (isThereAnyAreaArming == false)
                            ExitArming(this, EventArgs.Empty);

                        return areaStatus.DelayAutomaticArming(areaConfig);
                    }
                }
            }
            return false;
        }
        /// <summary>
        /// Check if there are any unfinished delayed arm tasks for this keypad.
        /// </summary>
        /// <param name="keypadId">Keypad logical Id to check for.</param>
        /// <returns>True if unfinished arm tasks exist, False otherwise.</returns>
        public bool KeypadArmAreaTasksRunning(Device8003KeypadConfiguration keypadConfig)
        {
            lock (areaArmDisarmLock)
            {
                if (armAreaTasks == null || armAreaTasks.Count == 0)
                    return false;
                return armAreaTasks.Any(request => request.Done() == false && request.AreaIds.Intersect(keypadConfig.AreaIds).Count > 0);
            }
        }

        /// <summary>
        /// Check if any arm area task is still running (exit delay is running)
        /// </summary>
        public bool ExitDelayRunning
        {
            get
            {
                lock (areaArmDisarmLock)
                {
                    if (armAreaTasks == null || armAreaTasks.Count == 0)
                        return false;

                    return armAreaTasks.Any(request => request.Done() == false);
                }
            }
        }

        /// <summary>
        /// Check if any arm area task is still running (exit delay is running)
        /// </summary>
        public bool IsExitDelayRunningForArea(int logicalAreaId)
        {
            lock (areaArmDisarmLock)
            {
                if (armAreaTasks == null || armAreaTasks.Count == 0)
                    return false;

                return armAreaTasks.Any(request => request.Done() == false && request.AreaIds.Contains(logicalAreaId) == true);
            }
        }

        /// <summary>
        /// Remove the completed task from the arm are tasks list and dispose it
        /// </summary>
        /// <param name="taskToDelete">Task to delete</param>
        public void CleanCompletedArmTask(ArmAreaTaskHolder taskToDelete)
        {
            lock (areaArmDisarmLock)
            {
                if (armAreaTasks == null || armAreaTasks.Count == 0)
                    return;

                for (int i = 0; i < armAreaTasks.Count; i++)
                {
                    if (armAreaTasks[i] != null && armAreaTasks[i] == taskToDelete && taskToDelete.Done() == true)
                    {
                        armAreaTasks.RemoveAt(i);
                        taskToDelete.Dispose();
                        taskToDelete = null;
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Clean completed arm area task: {0}", i);
                        });
                        i--;
                    }
                }
            }
        }

        /// <summary>
        /// Clean all completed area tasks that are still in the list
        /// </summary>
        private void cleanCompletedArmTasks()
        {
            lock (areaArmDisarmLock)
            {
                if (armAreaTasks == null || armAreaTasks.Count == 0)
                    return;

                for (int i = 0; i < armAreaTasks.Count; i++)
                {
                    ArmAreaTaskHolder task = armAreaTasks[i];
                    if (task != null && task.Done() == true)
                    {
                        armAreaTasks.RemoveAt(i);
                        task.Dispose();
                        task = null;
                        i--;
                    }
                }
            }
        }

        /// <summary>
        /// Check if same area arming task already running. The task will have to include the same areas as in the areaIds list.
        /// </summary>
        /// <param name="areaIds">Area list to check against.</param>
        /// <returns>True if any of the currently running arm area tasks contain all the areas in areaIds list.</returns>
        private bool armTaskExists(List<int> areaIds)
        {
            if (armAreaTasks == null || armAreaTasks.Count == 0)
                return false;

            areaIds.Sort();
            return armAreaTasks.Any(task =>
                {
                    return task.AreaIds.SequenceEqual(areaIds) == true;
                });
        }

        /// <summary>
        /// Stop any arm tasks containing any of the areas in keypadAreaIds list temporarily. If the user logs in successfully
        /// then the tasks will be stopped and removed otherwise the tasks will be resumed when the inactivity timer expires or
        /// when the keypad enters Idle state.
        /// </summary>
        /// <param name="keypadAreaIds">Area Ids list for the keypad that sends the request to stop arming.</param>
        public void StoppingArmAreas(List<int> keypadAreaIds, int keypadId)
        {
            lock (areaArmDisarmLock)
            {
                if (armAreaTasks == null || armAreaTasks.Count == 0)
                    return;
                UserLoginKeypadId = keypadId;
                armAreaTasks.ForEach(task =>
                    {
                        task.TryStoppingArming(keypadAreaIds);
                    });
            }
        }

        /// <summary>
        /// Resume arm area tasks that have been stopped temporarily.
        /// </summary>
        public void ResumeArmAreas(int keypadId)
        {
            lock (areaArmDisarmLock)
            {
                if (armAreaTasks == null || armAreaTasks.Count == 0)
                    return;
                if (keypadId != UserLoginKeypadId)
                    return;
                armAreaTasks.ForEach(task =>
                {
                    task.ResumeArming();
                });
                UserLoginKeypadId = -1;
            }
        }

        /// <summary>
        /// Stop delayed arm areas command.
        /// </summary>
        public void StopArmAreas(int keypadId)
        {
            lock (areaArmDisarmLock)
            {
                if (armAreaTasks == null || armAreaTasks.Count == 0)
                    return;
                if (UserLoginKeypadId != keypadId)
                    return;
                try
                {
                    UserLoginKeypadId = -1;
                    KeypadId = keypadId;
                    for (int i = 0; i < armAreaTasks.Count; i++)
                    {
                        ArmAreaTaskHolder task = armAreaTasks[i];
                        if (task != null && task.StopArming() == true)
                        {
                            armAreaTasks.RemoveAt(i);
                            task.Dispose();
                            task = null;
                            i--;
                        }
                    }
                }
                finally
                {
                    KeypadId = -1;
                }
            }
        }

        /// <summary>
        /// Terminate all area arming tasks for the area with logicalAreaId
        /// </summary>
        /// <param name="logicalAreaId">Area Logical Id</param>
        /// <returns></returns>
        public bool CheckTerminateArming(int logicalAreaId)
        {
            lock (areaArmDisarmLock)
            {
                if (armAreaTasks == null || armAreaTasks.Count == 0)
                    return false;

                bool result = false;
                for (int i = 0; i < armAreaTasks.Count; i++)
                {
                    ArmAreaTaskHolder task = armAreaTasks[i];
                    if (task != null && task.Done() == false && task.AreaIds.Contains(logicalAreaId) == true)
                    {
                        result = true;
                        task.TerminateArming();
                        armAreaTasks.RemoveAt(i);
                        task.Dispose();
                        task = null;
                        i--;
                    }
                }
                return result;
            }
        }

        private List<int> armingAreaIds = new List<int>();
        /// <summary>
        /// Trigger event when arm area task starts
        /// </summary>
        /// <param name="areaIds">List of areas that will be armed with delay.</param>
        /// <param name="keypadBuzzerPriority">Buzzer beep type and duration.</param>
        internal void TriggerStartArming(List<int> areaIds, KeypadBuzzerPriority keypadBuzzerPriority, bool beepBuzzer)
        {
            if (StartArming == null)
                return;
            armingAreaIds = armingAreaIds.Union(areaIds);
            StartArming(this, new StartArmingEventArgs(areaIds, keypadBuzzerPriority, beepBuzzer));
        }

        /// <summary>
        /// Trigger event when arming area with delay, each time the arm area task timer fires.
        /// </summary>
        /// <param name="keypadBuzzerPriority">Buzzer beep type and duration.</param>
        internal void TriggerCountdownArming(List<int> areaIds, KeypadBuzzerPriority keypadBuzzerPriority, bool beepBuzzer)
        {
            if (CountdownArming == null)
                return;
            CountdownArming(this, new CountdownArmingEventArgs(areaIds, keypadBuzzerPriority, beepBuzzer));
        }

        /// <summary>
        /// Trigger event when arm area task is stopped either at the end of the delayed arm or if forced because
        /// a user stopped the arm area task.
        /// </summary>
        /// <param name="keypadBuzzerPriority">Buzzer beep type and duration.</param>
        /// <param name="forcedStop">True if the arm area task id stopped by a user that logged into one of the keypads.</param>
        internal void TriggerStopArming(List<int> areaIds, KeypadBuzzerPriority keypadBuzzerPriority, bool beepBuzzer)
        {
            if (StopArming == null)
                return;
            armingAreaIds = armingAreaIds.Except(areaIds);
            StopArming(this, new StopArmingEventArgs(areaIds, keypadBuzzerPriority, beepBuzzer));
        }
        
        /// <summary>
        /// Trigger event when area was not armed before the arming delay expired when completion of setting is required in order to meet BS 8243 standard's requirements 
        /// </summary>
        /// <param name="areaId">Area that failed to be armed.</param>
        /// <param name="userAuditInfo">The user that started the arming procedure.</param>
        public void TriggerFailedToArmArea(int areaId, UserAuditInfo userAuditInfo)
        {
            if (FailedToArmArea == null)
                return;
            MacroControl.Instance.EnqueueAreaFailedToArmEvent(areaId, userAuditInfo.OriginatingUserId);
            FailedToArmArea(this, new FailedToArmAreaEventArgs(areaId, userAuditInfo));
        }

        public void TriggerAreaLateToClose(AreaStatus areaStatus)
        {
            if (AreaLateToClose == null)
                return;
            AreaLateToClose(this, new AreaStatusEventArgs(areaStatus));
        }

        public void TriggerAreaLateToCloseBeepKeypadBuzzer(AreaStatus areaStatus)
        {
            if (AreaLateToCloseBeepKeypadBuzzer == null)
                return;
            AreaLateToCloseBeepKeypadBuzzer(this, new AreaStatusEventArgs(areaStatus));
        }

        public void TriggerAreaFailToArmBeepKeypadBuzzer(AreaStatus areaStatus)
        {
            if (AreaFailToArmBeepKeypadBuzzer == null)
                return;
            AreaFailToArmBeepKeypadBuzzer(this, new AreaStatusEventArgs(areaStatus));
        }

        /// <summary>
        /// Filter out area, which is not configured for selected user & not configured for mode follow
        /// </summary>
        /// <param name="areaIds"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        private List<int> getPermittedAreasForUser(List<int> areaIds, int userId)
        {
            List<int> userAreas = GetAreasForUser(userId);
            List<int>  permittedAreas = areaIds.Select(id => 
            {
                return userAreas.Contains(id) == true || ConfigurationManager.Instance.GetAreaConfiguration(id).AreaModeFollowsConfigured == true;
            });
            return permittedAreas;
        }

        /// <summary>
        /// Arm area(s)
        /// </summary>
        /// <param name="areaIds">Area ids list to be armed</param>
        /// <param name="userAuditInfo">User that initiaited the arm area action.</param>
        internal void DoArmAreas(List<int> areaIds, UserAuditInfo userAuditInfo)
        {
            if (areaIds == null || areaIds.Count == 0)
                return;
            
            List<int> areasToArm = getPermittedAreasForUser(areaIds, userAuditInfo.OriginatingUserId);
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("Arm {0} area(s).", areasToArm.Count);
            });

            foreach (int areaId in areasToArm)
            {
                AreaStatus areaStatus = this[areaId];
                if (areaStatus != null)
                {
                    areaStatus.SetMode(AreaScheduleLevel.Armed, userAuditInfo);
                    StatusManager.Instance.Inputs.RestoreInArea(areaStatus, userAuditInfo);
                }
            }
        }

        #endregion

        #region Disarm area(s)

        /// <summary>
        /// Disarms all areas
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the disarm area(s) action.</param>
        /// <returns>Returns True when any area is disarmed</returns>
        public DisarmAreasResult DisarmAllAreas(UserAuditInfo userAuditInfo)
        {
            return DisarmAreas(new List<int>(Ids), userAuditInfo, false);
        }

        /// <summary>
        /// Check if any of the areas in [areaIds] list can be disarmed. Add all areas that cannot be disarmed to [forbiddenAreaIds] list
        /// </summary>
        /// <param name="areaIds">Area list to check</param>
        /// <param name="userAuditInfo">User that initiaited the disarm area(s) action.</param>
        /// <param name="forbiddenAreaIds">Areas for which the user doesn't have permission to disarm</param>
        /// <returns></returns>
        public DisarmAreasResult CanDisarmAreas(List<int> areaIds, UserAuditInfo userAuditInfo, out List<int> forbiddenAreaIds)
        {
            forbiddenAreaIds = null;
            if (areaIds == null || areaIds.Count == 0 || areaIds.AllDisarmed() == true || userAuditInfo == null)
                return DisarmAreasResult.NoActionPerformed;

            forbiddenAreaIds = new List<int>(areaIds.Count);

            int userId = userAuditInfo.OriginatingUserId;
            if (userId > 0 && ConfigurationManager.Instance.Users[userId] != null &&
                              ConfigurationManager.Instance.Users[userId].OutsideHoursAccess == false)
            {
                // The user doesn't have permission to disarm areas with a scheduled mode of Armed.
                // These areas must be first removed from the list.

                foreach (int areaId in areaIds)
                {
                    AreaConfiguration areaConfiguration = ConfigurationManager.Instance.GetAreaConfiguration(areaId);
                    if (areaConfiguration != null && areaConfiguration.NormalSchedule != null && areaConfiguration.NormalSchedule.ScheduledLevel == AreaScheduleLevel.Armed)
                        forbiddenAreaIds.Add(areaConfiguration.Id);
                }
            }

            if (forbiddenAreaIds.Count == 0)
                return DisarmAreasResult.AreasDisarmed;

            if (forbiddenAreaIds.Count == areaIds.Count)
                return DisarmAreasResult.NoActionPerformedDueToInsufficientPermissions;

            if (forbiddenAreaIds.Count < areaIds.Count)
                return DisarmAreasResult.AreasDisarmedWithSomeFailingDueToInsufficientPermissions;

            return DisarmAreasResult.NoActionPerformed;
        }

        /// <summary>
        /// Disarm one or more areas
        /// </summary>
        /// <param name="areasToArmIds">List of areas to disarm</param>
        /// <param name="userAuditInfo">User that initiaited the disarm area(s) action.</param>
        /// <param name="isDuressPin">True - the user logged on with a duress pin on a keypad, do not check the After Hours flag & do not obey the area schedule, False - otherwise</param>
        /// <returns>Returns True when any area is disarmed</returns>
        public DisarmAreasResult DisarmAreas(List<int> areaIds, UserAuditInfo userAuditInfo, bool isDuressPin)
        {
            return DisarmAreas(areaIds, userAuditInfo, isDuressPin, null);
        }

        public DisarmAreasResult AddModeFollowAndDisarmAreas(List<int> areaIds, UserAuditInfo userAuditInfo)
        {
            addModeFollowAreasForDisarming(areaIds);
            return DisarmAreas(areaIds, userAuditInfo, false);
        }

        /// <summary>
        /// Disarm one or more areas
        /// </summary>
        /// <param name="areasToArmIds">List of areas to disarm</param>
        /// <param name="userAuditInfo">User that initiaited the disarm area(s) action.</param>
        /// <param name="isDuressPin">True - the user logged on with a duress pin on a keypad, do not check the After Hours flag & do not obey the area schedule, False - otherwise</param>
        /// <param name="deisolatedPointDisplayNameList">The deisolated points display name list</param>
        /// <returns>Returns True when any area is disarmed</returns>
        public DisarmAreasResult DisarmAreas(List<int> areaIds, UserAuditInfo userAuditInfo, bool isDuressPin, List<string> deisolatedPointDisplayNameList)
        {
            try
            {
                if (areaIds == null || areaIds.Count == 0 || areaIds.AllDisarmed() == true || userAuditInfo == null)
                    return DisarmAreasResult.NoActionPerformed;

                int userId = userAuditInfo.OriginatingUserId;
                List<int> areasToDisarm = getPermittedAreasForUser(areaIds, userId);
                areaIds = areasToDisarm;

                // Clear any finished arm tasks
                cleanCompletedArmTasks();

                bool insufficientPermissions = false;
                if (isDuressPin == false)
                {
                    if (userId > 0 &&
                        ConfigurationManager.Instance.Users[userId] != null &&
                        ConfigurationManager.Instance.Users[userId].OutsideHoursAccess == false)
                    {
                        // The user doesn't have permission to disarm areas with a scheduled mode of Armed.
                        // These areas must be first removed from the list.

                        areasToDisarm = new List<int>(areaIds.Count);
                        foreach (int areaId in areaIds)
                        {
                            AreaConfiguration areaConfiguration = ConfigurationManager.Instance.GetAreaConfiguration(areaId);
                            if (areaConfiguration != null && areaConfiguration.NormalSchedule != null && areaConfiguration.NormalSchedule.ScheduledLevel == AreaScheduleLevel.Armed)
                            {
                                if (insufficientPermissions == false)
                                {
                                    AreaStatus areaStatus = this[areaId];
                                    if (areaStatus != null)
                                    {
                                        if (areaStatus.Armed)
                                            insufficientPermissions = true;
                                    }
                                }
                            }
                            else
                            {
                                areasToDisarm.Add(areaId);
                            }
                        }
                    }
                }

                // Notify the keypads involved that disarming about to happen. Insure the device loop manager is created and there is at least one
                // keypad online in the device loop.
                if (StatusManager.Instance.DeviceLoopManager != null && StatusManager.Instance.DeviceLoopManager.OneOrMoreKeypadsOnline == true)
                    StatusManager.Instance.DeviceLoopManager.NotifyKeypadsDisarmingStarted(areasToDisarm);

                bool areasDisarmed = false;
                lock (areaArmDisarmLock)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Disarm {0} area(s).", areasToDisarm.Count);
                    });
                    foreach (int areaId in areasToDisarm)
                    {
                        AreaStatus areaStatus = this[areaId];
                        if (areaStatus != null)
                        {
                            bool alarmCancelRequired = areaStatus.AlarmCancelRequired;
                            // Check if any area changed its status
                            bool areaDisarmed = areaStatus.SetMode(AreaScheduleLevel.Disarmed, userAuditInfo, deisolatedPointDisplayNameList);
                            StatusManager.Instance.Inputs.RestoreInArea(areaStatus, userAuditInfo);
                            areasDisarmed |= areaDisarmed;
                            if (alarmCancelRequired)
                                TriggerConfirmedAlarmCancel(areaStatus);
                        }
                    }
                }

                if (areasDisarmed == true)
                {
                    if (insufficientPermissions == true)
                        return DisarmAreasResult.AreasDisarmedWithSomeFailingDueToInsufficientPermissions;
                    return DisarmAreasResult.AreasDisarmed;
                }

                if (insufficientPermissions == true)
                    return DisarmAreasResult.NoActionPerformedDueToInsufficientPermissions;

            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Exception Disarming! {0}", ex.ToString());
                });
            }
            return DisarmAreasResult.NoActionPerformed;
        }

        #endregion

        #region Activate/Deactivate Keypad Buzzers
        public bool ActivateKeypadBuzzers(int areaId, int seconds)
        {
            if (StatusManager.Instance.DeviceLoopManager != null && StatusManager.Instance.DeviceLoopManager.OneOrMoreKeypadsOnline == true)
            {
                StatusManager.Instance.DeviceLoopManager.ActivateKeypadBuzzers(areaId, seconds);
                return true;
            }
            return false;
        }

        public bool DeactivateKeypadBuzzers(int areaId)
        {
            if (StatusManager.Instance.DeviceLoopManager != null && StatusManager.Instance.DeviceLoopManager.OneOrMoreKeypadsOnline == true)
            {
                StatusManager.Instance.DeviceLoopManager.DeactivateKeypadBuzzers(areaId);
                return true;
            }
            return false;
        }
        #endregion

        public void DisableConfirmedAlarms(int areaId)
        {
            AreaStatus areaStatus = this[areaId];
            if(areaStatus != null)
                areaStatus.DisableConfirmedAlarms = true;
        }
        /// <summary>
        /// Update area status list from configuration on boot.
        /// </summary>
        /// <param name="areas">List of areas configuration to add</param>
        /// <param name="statusStorage">Stataus Storage instance or null if status restore is not required</param>
        internal void UpdateFromConfiguration(AreaConfiguration[] areas, StatusStorageCollection statusStorage)
        {
            foreach (var area in areas)
            {
                Assign(area.Id, new AreaStatus(area, this, statusStorage.AreasStatus.TryGetValue(area.Id)));
            }
        }

        /// <summary>
        /// Update area status list from configuration on configuration change.
        /// </summary>
        internal void UpdateFromConfiguration(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems, List<NodeStateBase> partialStatusList)
        {
            foreach (var removedItem in removedItems)
            {
                if (removedItem.ConfigurationType == ConfigurationElementType.Area)
                    Remove(removedItem.Id);
            }
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Area)
                {
                    // All other status is lost on configuration change but the area mode is deemed too important to lose.
                    AreaStatusStorage previousStatus = null;
                    try
                    {
                        previousStatus = (AreaStatusStorage)this[changedItem.Id].CreateStatusStorage();
                        previousStatus.HasConfirmedAlarm = false;
                    }
                    catch
                    {
                    }
                    Remove(changedItem.Id);
                    try
                    {
                        Assign(changedItem.Id, new AreaStatus(ConfigurationManager.Instance.GetAreaConfiguration(changedItem.Id), this, previousStatus));
                        partialStatusList.Add(this[changedItem.Id].CreateEventState());
                    }
                    catch
                    {
                    }
                }
            }
            foreach (var newlyAddedItem in newlyAddedItems)
            {
                try
                {
                    if (newlyAddedItem.ConfigurationType == ConfigurationElementType.Area)
                    {
                        Assign(newlyAddedItem.Id, new AreaStatus(ConfigurationManager.Instance.GetAreaConfiguration(newlyAddedItem.Id), this, null));
                        partialStatusList.Add(this[newlyAddedItem.Id].CreateEventState());
                    }
                }
                catch
                {
                }
            }

            foreach (var area in Items)
            {
                area.RemoveFromArea(changedItems, removedItems);
            }
        }

        internal override void Persist(Asn1DerFormatter asn1Serializer, Stream statusStream)
        {
            foreach (var area in Items)
            {
                try
                {
                    asn1Serializer.Serialize(statusStream, area.CreateStatusStorage());
                }
                catch (Exception ex)
                {
                    // This message is left in debug as it may generate error for every entry.
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Unable to store status for area {0}. {1}", area.LogicalId, ex.Message);
                    });
                }
            }
        }

        /// <summary>
        /// Returns an array of areas the user has access to.
        /// A 0 length array is returned when the user doesn't have access to any areas or doesn't exist.
        /// null is never returned.
        /// </summary>
        public List<int> GetAreasForUser(int userId)
        {
            if (userId > 0)
            {
                IUserConfiguration user = ConfigurationManager.Instance.Users[userId];
                if (user != null)
                    return user.AreaIds.ToList();
                return new List<int>();
            }
            return base.Ids.ToList();
        }

        private void addModeFollowAreasForArming(List<int> areaIds)
        {
            var armedAndArmingIds = areaIds.Union(ArmedIds).Union(armingAreaIds);
            foreach (var area in ConfigurationManager.Instance.ModeFollowAreas)
            {
                if (StatusManager.Instance.Areas[area.Id].Armed == false && area.AreaModeFollows.Intersect(armedAndArmingIds).Count == area.AreaModeFollows.Length)
                {
                    if (areaIds.Contains(area.Id) == false && armingAreaIds.Contains(area.Id) == false)
                        areaIds.Add(area.Id);
                }
            }
        }

        private void addModeFollowAreasForDisarming(List<int> areaIds)
        {
            foreach (var area in ConfigurationManager.Instance.ModeFollowAreas)
            {
                if (StatusManager.Instance.Areas[area.Id].Disarmed == false && area.AreaModeFollows.Intersect(areaIds).Count > 0)
                {
                    if (areaIds.Contains(area.Id) == false && armingAreaIds.Contains(area.Id) == false)
                        areaIds.Add(area.Id);
                }
            }
        }

        public List<int> ArmedIds
        {
            get
            {
                List<int> armedIds = new List<int>();
                foreach (var areaStatus in Items)
                {
                    if (areaStatus != null && areaStatus.Enabled == true && areaStatus.Armed == true)
                        armedIds.Add(areaStatus.LogicalId);
                }
                return armedIds;
            }
        }

        internal override void Cleanup()
        {
            ConfigurationManager.Instance.ConfigurationChanging -= new EventHandler<ConfigurationChangeEventArgs>(configurationManager_ConfigurationChanging);
            if (areaScheduleTimer != null)
            {
                TimerManager.Instance.RemoveTimer(areaScheduleTimer);
                areaScheduleTimer = null;
            }

            if (armAreaTasks != null)
            {
                armAreaTasks.Clear();
                armAreaTasks = null;
            }

        }
    }
}
