﻿using System;
using System.Collections.Generic;
using System.Threading;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.Common.Status
{
    public partial class StatusManager
    {
        private readonly SortedList<int, object> accessControlLocks = new SortedList<int, object>();

        /// <summary>
        /// Get access control transaction object. Provide reader logical id as first parameter.
        /// </summary>
        /// <param name="logocalReaderId"></param>
        /// <returns></returns>
        internal AccessControlTransaction GetAccessControlTransaction(ReaderStatus readerStatus)
        {
            return new AccessControlTransaction(readerStatus.LogicalId);
        }
                
        /// <summary>
        /// Access control transaction encapsulating peripheral update on readers and doors.
        /// </summary>
        public class AccessControlTransaction : IDisposable
        {
            private readonly int logicalReaderId = 0;
            private readonly int logicalDoorId = 0;
            private readonly AccessControlCommandRequestEventArgs readerEventArgs = null;
            private readonly AccessControlCommandRequestEventArgs doorEventArgs = null; 

            /// <summary>
            /// Constructor used to create instance allowing for configuration read
            /// </summary>
            /// <param name="owner">Instance of StatusManager</param>
            /// <param name="logicalReaderId">Logical reader id on which the transaction will occur</param>
            internal AccessControlTransaction(int logicalReaderId)
            {
                this.logicalReaderId = logicalReaderId;
                readerEventArgs = new AccessControlCommandRequestEventArgs(logicalReaderId);
                var readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
                // Check if the provided logical reader id is in-reader.
                if (readerConfig != null && readerConfig.Door != null &&
                    readerConfig.Door.InReader != null && readerConfig.Door.InReader.Id == logicalReaderId)
                {
                    logicalDoorId = readerConfig.Door.Id;
                    doorEventArgs = new AccessControlCommandRequestEventArgs(logicalReaderId);
                }

                SortedList<int, object> accessControlLocks = StatusManager.Instance.accessControlLocks;
                if (accessControlLocks.ContainsKey(logicalReaderId) == false)
                    accessControlLocks.Add(logicalReaderId, new object());

                // Enter lock
                Monitor.Enter(accessControlLocks[logicalReaderId]);
            }

            public void SetBuzzerOn()
            {
                readerEventArgs[AccessCommandType.Buzzer] = new AccessCommandBuzzerConfig(CardReaderBuzzerType.BuzzerOn);
            }

            public void SetBuzzerOff()
            {
                readerEventArgs[AccessCommandType.Buzzer] = new AccessCommandBuzzerConfig(CardReaderBuzzerType.BuzzerOff);
            }

            public void SetBuzzerPulse()
            {
                readerEventArgs[AccessCommandType.Buzzer] = new AccessCommandBuzzerConfig(CardReaderBuzzerType.BuzzerPulse);
            }

            public void SetAcceptLedOn()
            {
                readerEventArgs[AccessCommandType.AcceptLed] = new AccessCommandAcceptLedConfig(CardReaderLedType.LedOn);
            }

            public void SetAcceptLedFlashing()
            {
                readerEventArgs[AccessCommandType.AcceptLed] = new AccessCommandAcceptLedConfig(CardReaderLedType.LedFlashing);
            }

            public void SetAcceptLedOff()
            {
                readerEventArgs[AccessCommandType.AcceptLed] = new AccessCommandAcceptLedConfig(CardReaderLedType.LedOff);
            }

            public void SetDeniedLedOn()
            {
                readerEventArgs[AccessCommandType.DeniedLed] = new AccessCommandDeniedLedConfig(CardReaderLedType.LedOn);
            }

            public void SetDeniedLedFlashing()
            {
                readerEventArgs[AccessCommandType.DeniedLed] = new AccessCommandDeniedLedConfig(CardReaderLedType.LedFlashing);
            }

            public void SetDeniedLedOff()
            {
                readerEventArgs[AccessCommandType.DeniedLed] = new AccessCommandDeniedLedConfig(CardReaderLedType.LedOff);
            }

            public void StoreCardInDegradedMode(CardNumberHolder cardNumber)
            {
                readerEventArgs[AccessCommandType.StoreCardForDegradedMode] = new AccessCommandStoreCardInDegrededMemoryConfig(cardNumber);
            }

            /// <summary>
            /// Mark access control transaction to turn strike on.
            /// </summary>
            public void StrikeOn()
            {
                if (doorEventArgs != null)
                    doorEventArgs[AccessCommandType.Strike] = new AccessCommandStrikeConfig(AccessCommandStrikeType.On);
            }

            /// <summary>
            /// Mark access control transaction to turn strike off.
            /// </summary>
            public void StrikeOff()
            {
                if (doorEventArgs != null)
                    doorEventArgs[AccessCommandType.Strike] = new AccessCommandStrikeConfig(AccessCommandStrikeType.Off);
            }

            #region IDisposable Members

            /// <summary>
            /// Commit the transaction
            /// </summary>
            public void Dispose()
            {
                try
                {
                    // Access control commands for reader.
                    if (readerEventArgs.Count > 0)
                        StatusManager.Instance.Readers[logicalReaderId].TriggerAccessControlCommand(readerEventArgs);
                    // Access control commands for door.                    
                    if (doorEventArgs != null && doorEventArgs.Count > 0)
                        StatusManager.Instance.Doors[logicalDoorId].TriggerAccessControlCommand(doorEventArgs);
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                    {
                        return string.Format("Unable to commit access control transaction. {0}", ex.ToString());
                    });
                }
                // Exit lock here
                Monitor.Exit(StatusManager.Instance.accessControlLocks[logicalReaderId]);
            }
            #endregion
        }
    }
}
