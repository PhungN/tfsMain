﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.Common.Status
{
    public class ReaderMultiBadgingStatus : ReaderMultiBadgingStatusBase
    {
        private readonly int maxCount;
        private List<CardInformation> cardInformationList = null;
        public ReaderMultiBadgingStatus(int logicalDoorId, int logicalReaderId, ReaderCategory readerCategory)
            : base(logicalDoorId, logicalReaderId, readerCategory == ReaderCategory.DualEntry ? ReaderBadgingType.DualEntry : ReaderBadgingType.TripleEntry, () =>
            {
                StatusManager.Instance.Readers.TriggerInvalidMultiBadgingEvent(new MultiBadgingEventArgs(logicalDoorId, logicalReaderId, cardInformationList));
            })
        {
            maxCount = readerCategory == ReaderCategory.DualEntry ? 2 : 3;
        }

        /// <summary>
        /// IN GMS Mode, a valid access card requires that the user has the flag "Dual User Control" in the 
        /// Card Details tab of the user.  That is, if a reader is set to "Dual User Control" then access will only be granted 
        /// when two valid cards are used where the user has "Dual Acces Control" enabled.  
        /// FOr Triple Access, three different cards with "Dual Access Control" are required for access.
        /// In Unison Mode there is no such mode yet, so the requirement is simply to support two different 
        /// valid access cards for Dual Entry and three different valid access cards for Triple Entry.
        /// </summary>
        /// <param name="cardInformation"></param>
        /// <returns></returns>
        public bool IsValidCard(CardInformation cardInformation)
        {
            bool isGmsMode = ConfigurationManager.Instance.IsUnisonMode == false;
            if (isGmsMode == true && cardInformation.UserFlags.Has(LegacyCardUserFlags.DualUserControl) == false)
            {
                killTimer();
                return false;
            }
            return true;
        }

        /// <summary>
        /// save first card and start timer
        /// </summary>
        /// <param name="cardInformation"></param>
        public bool Start(CardInformation cardInformation, Action triggerAction)
        {
            if (base.Start(triggerAction) == true)
            {
                cardInformationList = new List<CardInformation>() { cardInformation };
                return true;
            }
            return false;
        }

        /// <summary>
        /// if card already badge, kill timer and activate failed action
        /// else save card and 
        ///     if cards reach maxCards, kill timer and activate success action
        ///     else activate pending action
        /// </summary>
        /// <param name="cardInformation"></param>
        /// <returns></returns>
        public bool AddCard(CardInformation cardInformation, Action pendingAction, Action<List<CardInformation>> accessGrantedAction, Action accessDeniedAction)
        {
            foreach (var card in cardInformationList)
            {
                if (card.CardNumber.Equals(cardInformation.CardNumber) == true)
                {
                    killTimer();
                    accessDeniedAction();
                    return false;
                }
            }
            cardInformationList.Add(cardInformation);
            if (cardInformationList.Count == maxCount)
            {
                killTimer();
                accessGrantedAction(new List<CardInformation>(cardInformationList));
            }
            else
            {
                pendingAction();
            }

            return true;
        }
    }



    
}
