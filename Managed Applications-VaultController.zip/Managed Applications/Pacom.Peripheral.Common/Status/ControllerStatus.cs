﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Serialization.Formatters.Asn1;

namespace Pacom.Peripheral.Common.Status
{
    public sealed class ControllerStatus : DeviceStatusBase, IDeviceStatus, IDevicePowerSupplyStatus
    {
        /// <summary>
        /// Triggered when the controller Online status has changed.
        /// </summary>
        public event EventHandler<ControllerOnlineOfflineEventArgs> ControllerOnlineStatusChanged = null;

        /// <summary>
        /// Triggered when the controller masked Online status has changed.
        /// </summary>
        public event EventHandler<ControllerOnlineOfflineEventArgs> ControllerMaskedOnlineStatusChanged = null;

        /// <summary>
        /// Triggered when the controller event queue is full.
        /// </summary>
        public event EventHandler<EventArgs> ControllerEventQueueFull = null;

        /// <summary>
        /// Triggered when the controller LAN connect / disconnect status has changed.
        /// </summary>
        public event EventHandler<ControllerLanConnectDisconnectEventArgs> ControllerLanConnectStatusChanged = null;

        /// <summary>
        /// Triggered when the controller card database status has changed.
        /// </summary>
        public event EventHandler<CardDatabaseUtilizationChangedEventArgs> ControllerCardDatabaseUtilizationChanged = null;

        /// <summary>
        /// Triggered when the generate/perform remote maintenance command from frontend
        /// </summary>
        public event EventHandler<RemoteMaintenanceStatusEventArgs> RemoteMaintenanceStatusRequested = null;

        private IDataFlash dataFlash = null;

        private IAccessCardManager accessCardManager = null;

        private readonly object sync = new object();

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="configuration"></param>
        public ControllerStatus(ConfigurationBase configuration, IDataFlash dataFlash, DeviceStatusList parent, IAccessCardManager accessCardManager) :
            base(configuration, parent)
        {
            this.dataFlash = dataFlash;
            this.accessCardManager = accessCardManager;
            SupportedIsolateFlags = EventSourceLatchOrIsolateType.PowerFail | EventSourceLatchOrIsolateType.BatteryFail |
                                    EventSourceLatchOrIsolateType.ReportingFail | EventSourceLatchOrIsolateType.Tamper |
                                    EventSourceLatchOrIsolateType.BatteryChargerFail | EventSourceLatchOrIsolateType.InternalBatteryFail;
            serialNumber = "";
            MACAddress = "00:00:00:00:00:00";
            RunningImage = BootImage8003.Image1;
            Image1FirmwareVersion = "01.00";
            Image2FirmwareVersion = "01.00";
            Image1BuildNumber = 1;
            Image2BuildNumber = 1;
            BuildNumber = 1;
            populateFirmwareInfo(true);

            List<ConfigurationChanges> temp = new List<ConfigurationChanges>();
            temp.Add(new ConfigurationChanges(){ ConfigurationType = ConfigurationElementType.ControllerConnectionTable });
            RefreshAfterConfigurationChange(temp, temp, temp);
            DeviceLoopChecksumErrors = 0;
        }

        /// <summary>
        /// Set initial values for first entry status storage.
        /// </summary>
        /// <param name="firstTable">First connection table instance</param>
        /// <param name="secondTable">First connection table instance</param>
        private void setInitialOnlineFirstConnectionEntry(ControllerConnectionTable firstTable, ControllerConnectionTable secondTable)
        {
            if (firstTable == null)
                onlineFirstConnectionEntry[0] = ConnectionEntryState.NotPresent;
            else
                onlineFirstConnectionEntry[0] = ConnectionEntryState.Offline;

            if (secondTable == null)
                onlineFirstConnectionEntry[1] = ConnectionEntryState.NotPresent;
            else
                onlineFirstConnectionEntry[1] = ConnectionEntryState.Offline;
        }

        private int[] deviceLoopPowerSupplies = null;

        /// <summary>
        /// Serial number read offset in NAND DataFlash
        /// </summary>
        private const int serialNumberOffset = 0x52800;

        /// <summary>
        /// Controller internal lithium battery status
        /// </summary>
        private bool internalBatteryLow = false;
        private bool maskedInternalBatteryLow = false;

        /// <summary>
        /// Controller power supply status
        /// </summary>
        private PowerFailState statusPinPowerState = PowerFailState.None;
        private PowerFailState maskedPowerState = PowerFailState.None;

        /// <summary>
        /// Battery status
        /// </summary>
        private BatteryFailState statusPinBatteryState = BatteryFailState.None;
        private BatteryFailState maskedBatteryState = BatteryFailState.None;

        /// <summary>
        /// Battery charger status
        /// </summary>
        private bool statusPinChargerFailedState = false;
        private bool maskedBatteryChargerFailed = false;

        /// <summary>
        /// Controller online on to the front end
        /// </summary>
        private bool[] onlineConnectionTable = new bool[ConfigConsts.MaxControllerConnectionTables];
        private int[] onlineConnectionEntry = new int[ConfigConsts.MaxControllerConnectionTables];
        private bool[] maskedOnlineConnectionTable = new bool[ConfigConsts.MaxControllerConnectionTables];

        /// <summary>
        /// Controller primary entry status. True indicates that the controller is using primary entry to the front end.
        /// </summar>
        private ConnectionEntryState[] onlineFirstConnectionEntry = new ConnectionEntryState[ConfigConsts.MaxControllerConnectionTables];

        /// <summary>
        /// Get controller maximum user access level from all the enabled keypads.
        /// </summary>
        public UserAccessLevel CurrentUserAccessLevel
        {
            get
            {
                int accessLevel = 0;
                var items = StatusManager.Instance.Devices.Items;
                for (int i = 0; i < items.Length; i++)
                {
                    DeviceKeypadStatus keypad = items[i] as DeviceKeypadStatus;
                    if (keypad != null && keypad.Enabled == true && (int)keypad.AccessLevel > accessLevel)
                        accessLevel = (int)keypad.AccessLevel;
                }
                return (UserAccessLevel)accessLevel;
            }
        }

        /// <summary>
        /// Get / Set current running firmware image string
        /// </summary>
        public BootImage8003 RunningImage { get; private set; }

        /// <summary>
        /// Device MAC address as string
        /// </summary>
        public string MACAddress { get; private set; }

        /// <summary>
        /// Get / Set Image1 firmware version string
        /// </summary>
        public string Image1FirmwareVersion { get; private set; }

        /// <summary>
        /// Get / Set Image1 build number
        /// </summary>
        public int Image1BuildNumber { get; private set; }

        /// <summary>
        /// Get / Set Image2 firmware version string
        /// </summary>
        public string Image2FirmwareVersion { get; private set; }

        /// <summary>
        /// Get / Set Image2 build number
        /// </summary>
        public int Image2BuildNumber { get; private set; }

        CardDatabaseStatus cardDatabaseStatus;
        public CardDatabaseStatus CardDatabaseStatus
        {
            get { return cardDatabaseStatus; }
            set
            {
                if (Enabled == false)
                    return;
                if (cardDatabaseStatus != value)
                {
                    if (value != CardDatabaseStatus.SDCardFitted && ControllerCardDatabaseUtilizationChanged != null)
                        ControllerCardDatabaseUtilizationChanged(this, new CardDatabaseUtilizationChangedEventArgs(value, cardDatabaseStatus));
                    cardDatabaseStatus = value;
                }
            }
        }

        /// <summary>
        /// Get / Set Internal battery low flag
        /// </summary>
        public bool InternalBatteryLow
        {
            get { return internalBatteryLow; }
            set
            {
                if (Enabled == false)
                    return;
                if (internalBatteryLow != value)
                {
                    internalBatteryLow = value;
                    MaskedInternalBatteryLow = value;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set masked Internal battery low flag
        /// </summary>
        public bool MaskedInternalBatteryLow
        {
            get { return maskedInternalBatteryLow; }
            private set
            {
                if (Enabled == false)
                    return;
                if (maskedInternalBatteryLow != value || value == true)
                {
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail) == false &&
                        SuspectPoint == false &&
                        (LatchedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail) == false || value == true))
                    {
                        maskedInternalBatteryLow = value;
                        if (maskedInternalBatteryLow == true)
                        {
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.InternalBatteryFail);
                            CheckTerminateArming();
                        }
                        else
                        {
                            CheckStopFailToArmTimer();
                        }
                        StatusManager.Instance.Devices.TriggerInternalBatteryLowChangedStatus(this);
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        /// <summary>
        /// Get / Set current firmware build number
        /// </summary>
        public int BuildNumber { get; private set; }

        /// <summary>
        /// Controller status pin is used for reading the power supply status
        /// </summary>
        public bool UseStatusPinForPowerSupplyStatus
        {
            get { return deviceLoopPowerSupplies.Length == 0; }
        }

        public PowerFailState PowerState
        {
            get
            {
                if (UseStatusPinForPowerSupplyStatus)
                    return statusPinPowerState;
                else
                    return maskedPowerState;
            }
            set
            {
                if (UseStatusPinForPowerSupplyStatus && statusPinPowerState != value)
                {
                    statusPinPowerState = value;
                    SetMaskedPowerState(statusPinPowerState, false);
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        public BatteryFailState BatteryState
        {
            get
            {
                if (UseStatusPinForPowerSupplyStatus)
                    return statusPinBatteryState;
                else
                    return maskedBatteryState;
            }
            set
            {
                if (UseStatusPinForPowerSupplyStatus && statusPinBatteryState != value)
                {
                    statusPinBatteryState = value;
                    MaskedBatteryState = value;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        public bool BatteryChargerFailed
        {
            get
            {
                if (UseStatusPinForPowerSupplyStatus)
                    return statusPinChargerFailedState;
                else
                    return maskedBatteryChargerFailed;
            }
            set
            {
                if (UseStatusPinForPowerSupplyStatus && statusPinChargerFailedState != value)
                {
                    statusPinChargerFailedState = value;
                    MaskedBatteryChargerFailed = value;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        public PowerFailState MaskedPowerState
        {
            get { return maskedPowerState; }
        }

        public void SetMaskedPowerState(PowerFailState value, bool acFailDelayExpired)
        {
            if (Enabled == false)
                return;

            lock (sync)
            {
                if (UseStatusPinForPowerSupplyStatus)
                {
                    if (value != PowerFailState.Fail)
                        StatusManager.Instance.Devices.StopACFailDelay(LogicalId);

                    if (maskedPowerState != value || value != PowerFailState.None)
                    {
                        // Return immediately if all alarms are isolate, if the point has been flagged as suspect or
                        // if the power supply returns to a no alarm state when all alarm types are latched.
                        if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) || SuspectPoint ||
                            (value == PowerFailState.None && LatchedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail)))
                        {
                            return;
                        }

                        PowerFailState previousMaskedState = maskedPowerState;

                        if (value == PowerFailState.Fail && acFailDelayExpired == false && IsDelayedACFail == true)
                        {
                            // If AC Fail value has changed we can't update the masked value yet if there is an AC Fail delay and it hasn't expired yet
                            StatusManager.Instance.Devices.StartACFailDelay(LogicalId);
                        }
                        else
                        {
                            maskedPowerState = value;

                            SendPowerSupplyAlarm(maskedPowerState, previousMaskedState);
                        }
                    }
                }
                else
                {
                    if (SuspectPoint && value != PowerFailState.None)
                        return;

                    if (maskedPowerState == value)
                        return;

                    PowerFailState previousMaskedState = maskedPowerState;
                    maskedPowerState = value;

                    SendPowerSupplyAlarm(maskedPowerState, previousMaskedState);
                }
            }
        }

        public BatteryFailState MaskedBatteryState
        {
            get { return maskedBatteryState; }
            set
            {
                if (Enabled == false)
                    return;

                lock (sync)
                {
                    if (UseStatusPinForPowerSupplyStatus)
                    {
                        if (maskedBatteryState != value || value != BatteryFailState.None)
                        {
                            // Return immediately if all alarms are isolate, if the point has been flagged as suspect or
                            // if the power supply returns to a no alarm state when all alarm types are latched.
                            if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail) || SuspectPoint ||
                                (value == BatteryFailState.None && LatchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail)))
                            {
                                return;
                            }

                            BatteryFailState previousMaskedState = maskedBatteryState;
                            maskedBatteryState = value;

                            SendPowerSupplyAlarm(maskedBatteryState, previousMaskedState);
                        }
                    }
                    else
                    {
                        if (SuspectPoint && value != BatteryFailState.None)
                            return;

                        if (maskedBatteryState == value)
                            return;

                        BatteryFailState previousMaskedState = maskedBatteryState;
                        maskedBatteryState = value;

                        SendPowerSupplyAlarm(maskedBatteryState, previousMaskedState);
                    }
                }
            }
        }

        public bool MaskedBatteryChargerFailed
        {
            get { return maskedBatteryChargerFailed; }
            set
            {
                if (Enabled == false)
                    return;

                lock (sync)
                {
                    if (UseStatusPinForPowerSupplyStatus)
                    {
                        if (maskedBatteryChargerFailed != value || value == true)
                        {
                            // Return immediately if all alarms are isolate, if the point has been flagged as suspect or
                            // if the power supply returns to a no alarm state when all alarm types are latched.
                            if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail) || SuspectPoint ||
                                (value == false && LatchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail)))
                            {
                                return;
                            }

                            bool previousMaskedState = maskedBatteryChargerFailed;
                            maskedBatteryChargerFailed = value;

                            SendPowerSupplyAlarm(maskedBatteryChargerFailed, previousMaskedState);
                        }
                    }
                    else
                    {
                    if (SuspectPoint && value == true)
                        return;

                    if (maskedBatteryChargerFailed == value)
                        return;

                    bool previousMaskedBatteryChargerFailed = maskedBatteryChargerFailed;
                    maskedBatteryChargerFailed = value;

                    SendPowerSupplyAlarm(maskedBatteryChargerFailed, previousMaskedBatteryChargerFailed);
                }
            }
        }
        }

        /// <summary>
        /// Update controller power supply status from all power supply devices on the device loop
        /// </summary>
        public void UpdateDeviceLoopPowerSupplyStatus()
        {
            lock (sync)
            {
                PowerFailState deviceLoopPowerSupplyPowerState = PowerFailState.None;
                BatteryFailState deviceLoopPowerSupplyBatteryState = BatteryFailState.None;
                bool deviceLoopPowerSupplyBatteryChargerFailed = false;

                if (deviceLoopPowerSupplies.Length == 1)
                {
                    IDevicePowerSupplyStatus status = StatusManager.Instance.Devices[deviceLoopPowerSupplies[0]] as IDevicePowerSupplyStatus;
                    if (status != null)
                    {
                        deviceLoopPowerSupplyPowerState = status.MaskedPowerState;
                        deviceLoopPowerSupplyBatteryState = status.MaskedBatteryState;
                        deviceLoopPowerSupplyBatteryChargerFailed = status.MaskedBatteryChargerFailed;
                    }
                }
                else if (deviceLoopPowerSupplies.Length > 1)
                {
                    foreach (int powerSupplyId in deviceLoopPowerSupplies)
                    {
                        IDevicePowerSupplyStatus status = StatusManager.Instance.Devices[powerSupplyId] as IDevicePowerSupplyStatus;
                        if (status != null)
                        {
                            deviceLoopPowerSupplyPowerState |= status.MaskedPowerState;
                            deviceLoopPowerSupplyBatteryState |= status.MaskedBatteryState;
                            if (status.MaskedBatteryChargerFailed)
                                deviceLoopPowerSupplyBatteryChargerFailed = true;
                        }
                    }
                }

                SetMaskedPowerState(deviceLoopPowerSupplyPowerState, true);
                MaskedBatteryState = deviceLoopPowerSupplyBatteryState;
                MaskedBatteryChargerFailed = deviceLoopPowerSupplyBatteryChargerFailed;
            }
        }

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            switch (suspectStatusType)
            {
                case EventSourceLatchOrIsolateType.Tamper:
                    return ConfigurationManager.Instance.ControllerConfiguration.LatchTamperAlarms;
                case EventSourceLatchOrIsolateType.PowerFail:
                    if (UseStatusPinForPowerSupplyStatus)
                        return ConfigurationManager.Instance.ControllerConfiguration.LatchPrimaryPowerSourceAlarms;
                    else
                        return false;
                case EventSourceLatchOrIsolateType.BatteryChargerFail:
                    if (UseStatusPinForPowerSupplyStatus)
                        return ConfigurationManager.Instance.ControllerConfiguration.LatchBatteryChargerFailAlarms;
                    else
                        return false;
                case EventSourceLatchOrIsolateType.BatteryFail:
                    if (UseStatusPinForPowerSupplyStatus)
                        return ConfigurationManager.Instance.ControllerConfiguration.LatchSecondaryPowerSourceAlarms;
                    else
                        return false;
                case EventSourceLatchOrIsolateType.InternalBatteryFail:
                    return ConfigurationManager.Instance.ControllerConfiguration.LatchInternalBatteryLowAlarms;
                case EventSourceLatchOrIsolateType.ReportingFail:
                    return ConfigurationManager.Instance.ControllerConfiguration.LatchReportingFailAlarms;
                default: return false;
            }
        }

        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// Need to check if the controller is a suspect point as Battery charger failed events don't latch but can cause a suspect point.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get
            {
                return latchedAlarms.HasAny(EventSourceLatchOrIsolateType.PowerFail | EventSourceLatchOrIsolateType.BatteryFail |
                                            EventSourceLatchOrIsolateType.BatteryChargerFail | 
                                            EventSourceLatchOrIsolateType.ReportingFail | EventSourceLatchOrIsolateType.Tamper |
                                            EventSourceLatchOrIsolateType.InternalBatteryFail) || SuspectPoint;
            }
        }

        /// <summary>
        /// Get all controller alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = EventSourceLatchOrIsolateType.None;
                if (maskedTamperActive == true)
                    flags |= EventSourceLatchOrIsolateType.Tamper;
                if (UseStatusPinForPowerSupplyStatus == true)
                {
                    if (maskedPowerState != PowerFailState.None)
                        flags |= EventSourceLatchOrIsolateType.PowerFail;
                    if (maskedBatteryState != BatteryFailState.None)
                        flags |= EventSourceLatchOrIsolateType.BatteryFail;
                    if (maskedBatteryChargerFailed == true)
                        flags |= EventSourceLatchOrIsolateType.BatteryChargerFail;
                }
                if (maskedInternalBatteryLow == true)
                    flags |= EventSourceLatchOrIsolateType.InternalBatteryFail;
                if (maskedOnlineConnectionTable[0] == false)
                    flags |= EventSourceLatchOrIsolateType.ReportingFail;
                if (maskedOnlineConnectionTable[1] == false)
                    flags |= EventSourceLatchOrIsolateType.ReportingFail;
                return flags;
            }
        }

        /// <summary>
        /// Get the string representation of the alarms / isolated alarms / latched alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        protected override string AlarmFlagsAsString(EventSourceLatchOrIsolateType alarms)
        {
            if (alarms == EventSourceLatchOrIsolateType.None)
                return string.Empty;
            string alarmsAsString = " ";

            foreach (EventSourceLatchOrIsolateType eventSource in EnumHelper.GetValues<EventSourceLatchOrIsolateType>())
            {
                if (eventSource == EventSourceLatchOrIsolateType.None)
                    continue;

                if (alarms.Has(eventSource) == true)
                {
                    if (eventSource != EventSourceLatchOrIsolateType.ReportingFail)
                        alarmsAsString = string.Format("{0}{1} ", alarmsAsString, ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
                    else
                    {
                        // Controller Offline on Connection 1 or / and 2
                        if (maskedOnlineConnectionTable[0] == false)
                            alarmsAsString = string.Format("{0}{1} 1 ", alarmsAsString, ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
                        if (maskedOnlineConnectionTable[1] == false)
                            alarmsAsString = string.Format("{0}{1} 2 ", alarmsAsString, ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
                    }
                }
            }
            return alarmsAsString;
        }

        /// <summary>
        /// Get the string representation of the alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public override string IsolatedAlarmsAsString
        {
            get
            {
                if (isolatedAlarms == EventSourceLatchOrIsolateType.None)
                    return string.Empty;
                string alarmsAsString = " ";

                foreach (EventSourceLatchOrIsolateType eventSource in EnumHelper.GetValues<EventSourceLatchOrIsolateType>())
                {
                    if (eventSource == EventSourceLatchOrIsolateType.None)
                        continue;

                    if (isolatedAlarms.Has(eventSource) == true)
                    {
                        if (eventSource != EventSourceLatchOrIsolateType.ReportingFail)
                            alarmsAsString = string.Format("{0}{1} ", alarmsAsString, ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
                        else
                        {
                            // Controller Offline on Connection 1 or / and 2
                            if (onlineConnectionTable[0] == false)
                                alarmsAsString = string.Format("{0}{1} 1 ", alarmsAsString, ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
                            if (onlineConnectionTable[1] == false)
                                alarmsAsString = string.Format("{0}{1} 2 ", alarmsAsString, ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
                        }
                    }
                }
                return alarmsAsString;
            }
        }

        /// <summary>
        /// Get the array of strings representation for the alarms for this point
        /// </summary>
        protected override string[] AlarmFlagsAsStringArray(EventSourceLatchOrIsolateType alarms)
        {
            if (alarms == EventSourceLatchOrIsolateType.None)
                return new string[0];
            List<string> alarmsList = new List<string>();
            foreach (EventSourceLatchOrIsolateType eventSource in EnumHelper.GetValues<EventSourceLatchOrIsolateType>())
            {
                if (eventSource == EventSourceLatchOrIsolateType.None)
                    continue;

                if (alarms.Has(eventSource) == true)
                {
                    if (eventSource != EventSourceLatchOrIsolateType.ReportingFail)
                        alarmsList.Add(ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
                    else
                    {
                        // Controller Offline on Connection 1 or / and 2
                        if (maskedOnlineConnectionTable[0] == false)
                            alarmsList.Add(string.Format("{0} 1", ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource)));
                        if (maskedOnlineConnectionTable[1] == false)
                            alarmsList.Add(string.Format("{0} 2", ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource)));
                    }
                }
            }
            return alarmsList.ToArray();
        }

        /// <summary>
        /// Get the array of strings representation for the isolated alarms for this point
        /// </summary>
        public override string[] IsolatedAlarmsAsStringArray
        {
            get
            {
                if (isolatedAlarms == EventSourceLatchOrIsolateType.None)
                    return new string[0];
                List<string> alarmsList = new List<string>();
                foreach (EventSourceLatchOrIsolateType eventSource in EnumHelper.GetValues<EventSourceLatchOrIsolateType>())
                {
                    if (eventSource == EventSourceLatchOrIsolateType.None)
                        continue;

                    if (isolatedAlarms.Has(eventSource) == true)
                    {
                        if (eventSource != EventSourceLatchOrIsolateType.ReportingFail)
                            alarmsList.Add(ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource));
                        else
                        {
                            // Controller Offline on Connection 1 or / and 2
                            if (onlineConnectionTable[0] == false)
                                alarmsList.Add(string.Format("{0} 1", ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource)));
                            if (onlineConnectionTable[1] == false)
                                alarmsList.Add(string.Format("{0} 2", ConfigurationManager.Instance.ControllerConfiguration.GetDeviceAlarmDescription(eventSource)));
                        }
                    }
                }
                return alarmsList.ToArray();
            }
        }

        /// <summary>
        /// Set the state of device IsolatedAlarms flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="value">New isolated options. If value = EventSourceLatchOrIsolateType.None -> Deisolate all.
        /// If value = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.Tamper -> Isolate all or any.
        /// When de-isolating if any of the device inputs is in alarm the alarm will be queued into AlarmManager.
        /// </param>
        /// <returns>True if the command was successfully executed</returns>
        public override bool SetIsolated(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType value)
        {
            if (Enabled == false)
                return false;

            // Mask-out all flags this device does not support
            value &= SupportedIsolateFlags;
            bool pendingTimedActionRemoved = StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.DeisolateDevices, LogicalId);
            if (isolatedAlarms != value)
            {
                Isolating = true;
                // Tamper - Isolate/de-isolate
                SetIsolated(value, EventSourceLatchOrIsolateType.Tamper, false, tamperActive);
                // Internal Battery Low - Isolate/de-isolate 
                SetIsolated(value, EventSourceLatchOrIsolateType.InternalBatteryFail, false, InternalBatteryLow);

                // Controller Connection - Isolate/de-isolate 
                SetIsolated(value, EventSourceLatchOrIsolateType.ReportingFail, true, false);

                if (UseStatusPinForPowerSupplyStatus == true)
                {
                    SetIsolated(value, EventSourceLatchOrIsolateType.PowerFail, statusPinPowerState);
                    SetIsolated(value, EventSourceLatchOrIsolateType.BatteryFail, statusPinBatteryState);
                    SetIsolated(value, EventSourceLatchOrIsolateType.BatteryChargerFail, false, statusPinChargerFailedState);
                }
                else
                {
                    isolateDeisolatePowerSupplyDevice(userAuditInfo, value);
                }
                Isolating = false;
                StatusManager.Instance.Devices.TriggerChangedIsolatedStatus(this, value, isolatedAlarms, userAuditInfo);
                StatusManager.Instance.RequestStatusToStorage();
                return true;
            }
            return pendingTimedActionRemoved;
        }

        private bool isolateDeisolatePowerSupplyDevice(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType value)
        {
            EventSourceLatchOrIsolateType isolateType = EventSourceLatchOrIsolateType.None;
            if (value.Has(EventSourceLatchOrIsolateType.PowerFail))
                isolateType |= EventSourceLatchOrIsolateType.PowerFail;
            if (value.Has(EventSourceLatchOrIsolateType.BatteryChargerFail))
                isolateType |= EventSourceLatchOrIsolateType.BatteryChargerFail;
            if (value.Has(EventSourceLatchOrIsolateType.BatteryFail))
                isolateType |= EventSourceLatchOrIsolateType.BatteryFail;
            isolatedAlarms &= ~(EventSourceLatchOrIsolateType.PowerFail | EventSourceLatchOrIsolateType.BatteryChargerFail | EventSourceLatchOrIsolateType.BatteryFail);
            isolatedAlarms |= isolateType;
            foreach (int id in deviceLoopPowerSupplies)
            {
                PowerSupplyDeviceStatus powerSupplyDeviceStatus = StatusManager.Instance.Devices[id] as PowerSupplyDeviceStatus;
                if (powerSupplyDeviceStatus != null)
                    powerSupplyDeviceStatus.SetIsolated(userAuditInfo, isolateType);
            }
            return true;
        }

        /// <summary>
        /// Set masked status for [optionToCheck] to [newValue]
        /// </summary>
        /// <param name="optionToCheck">Option to check, e.g.: Offline, Tamper, InternalBatteryFail, ControllerConnection1Offline, ControllerConnection2Offline, etc.</param>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(EventSourceLatchOrIsolateType optionToCheck, bool newValue)
        {
            if (base.SetMaskedStatus(optionToCheck, newValue))
                return true;
            bool result = true;
            switch (optionToCheck)
            {
                case EventSourceLatchOrIsolateType.InternalBatteryFail:
                    MaskedInternalBatteryLow = newValue;
                    break;
                case EventSourceLatchOrIsolateType.BatteryChargerFail:
                    MaskedBatteryChargerFailed = newValue;
                    break;
                case EventSourceLatchOrIsolateType.ReportingFail:
                    if (newValue == false)
                    {
                        SetMaskedOnlineConnectionTable(0, GetOnlineConnectionTable(0));
                        SetMaskedOnlineConnectionTable(1, GetOnlineConnectionTable(1));
                    }
                    else
                    {
                        SetMaskedOnlineConnectionTable(0, true);
                        SetMaskedOnlineConnectionTable(1, true);
                    }
                    break;
                default:
                    result = false;
                    break;
            }
            return result;
        }

        /// <summary>
        /// Set masked status for PowerFailState
        /// </summary>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(PowerFailState newValue)
        {
            SetMaskedPowerState(newValue, true);
            return true;
        }

        /// <summary>
        /// Set masked status for BatteryFailState
        /// </summary>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(BatteryFailState newValue)
        {
            MaskedBatteryState = newValue;
            return true;
        }

        /// <summary>
        /// Restore masked online, device tamper, etc. status if required after unlatching the device alarms. Restore only if the
        /// current instantaneous status is Secure (device online, tamper secure, etc.).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        protected override void RestoreAfterUnlatch(UserAuditInfo userAuditInfo)
        {
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.Tamper) == false && TamperActive == false)
                MaskedTamperActive = false;
            if (UseStatusPinForPowerSupplyStatus)
            {
                if (latchedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) == false && statusPinPowerState == PowerFailState.None)
                    SetMaskedPowerState(PowerState, true);
                if (latchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail) == false && statusPinBatteryState == BatteryFailState.None)
                    MaskedBatteryState = BatteryState;
                if (latchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail) == false && statusPinChargerFailedState == false)
                    MaskedBatteryChargerFailed = BatteryChargerFailed;
            }
            else
            {
                UpdateDeviceLoopPowerSupplyStatus();
            }
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail) == false && InternalBatteryLow == false)
                MaskedInternalBatteryLow = InternalBatteryLow;
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.ReportingFail) == false &&
                GetOnlineConnectionTable(0) == true)
                SetMaskedOnlineConnectionTable(0, true);
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.ReportingFail) == false &&
                GetOnlineConnectionTable(1) == true)
                SetMaskedOnlineConnectionTable(1, true);
        }

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        public override bool CanIsolate(UserAccessLevel level)
        {
            if (level == UserAccessLevel.AccessLevel3)
                return true;

            if (CurrentAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) == true)
                return true;
            return false;
        }

        /// <summary>
        /// True if this status item can be de-isolated at the specifed access level
        /// </summary>
        public override bool CanDeisolate(UserAccessLevel level)
        {
            if (level == UserAccessLevel.AccessLevel3)
                return true;

            if (IsolatedAlarms.HasAny(EventSourceLatchOrIsolateType.PowerFail | EventSourceLatchOrIsolateType.ReportingFail) == true)
                return true;
            return false;
        }

        private bool lanDisconnected = false;
        public bool LanDisconnected
        {
            get { return lanDisconnected; }
            set
            {
                if (Enabled == false)
                    return;
                if (value != lanDisconnected)
                {
                    lanDisconnected = value;
                    Logger.LogWarnMessage(LoggerClassPrefixes.StatusManager, () =>
                    {
                        return string.Format("LAN {0} Event Sent.", lanDisconnected ? "Disconnected" : "Connected");
                    });
                    if (ControllerLanConnectStatusChanged != null)
                    {
                        ControllerLanConnectStatusChanged(this, new ControllerLanConnectDisconnectEventArgs(lanDisconnected == false));
                    }
                }
            }
        }

        /// <summary>
        /// Get / Set controller serial number. Get the serial number from the Data Flash memory.
        /// </summary>
        public override string SerialNumber
        {
            get
            {
                if (string.IsNullOrEmpty(serialNumber) == true)
                {
                    if (dataFlash != null)
                    {
                        byte[] serialNum = new byte[16];
                        for (int i = 0; i < 100; i++)
                        {
                            if (dataFlash.ReadData(serialNumberOffset, serialNum) == true)
                            {
                                if (serialNum[0] != 0)
                                    break;
                            }
                            System.Threading.Thread.Sleep(10);
                        }
                        if (serialNum[0] == 0)
                            serialNumber = "0000-0000-000000";
                        else
                            serialNumber = ASCIIEncoding.ASCII.GetString(serialNum, 0, serialNum.Length).ReplaceAnyNonASCIICharacters();
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Controller Serial Number ({0})", serialNumber);
                        });
                    }
                }
                return serialNumber;
            }
            set { }
        }

        private int hardwareVersion = 0;

        /// <summary>
        /// Returns the PCB version number. This is set when the PCB is produced via 0 Ohm links.
        /// </summary>
        public int HardwareVersion
        {
            get { return hardwareVersion; }
            set { hardwareVersion = value; }
        }

        /// <summary>
        /// Get / Set 8003 controller running image firmware version as a string
        /// </summary>
        public string RunningImageVersion
        {
            get
            {
                if (RunningImage == BootImage8003.Image1)
                    return this.Image1FirmwareVersion;
                else
                    return this.Image2FirmwareVersion;
            }
        }

        #region Event Queue Status Notification

        private bool eventQueueFull = false;

        /// <summary>
        /// Indicates if the controller event queue is full.
        /// </summary>
        public bool EventQueueFull
        {
            get
            {
                return eventQueueFull;
            }
            set
            {
                if (eventQueueFull != value)
                {
                    eventQueueFull = value;
                    if (eventQueueFull == true && ControllerEventQueueFull != null)
                        ControllerEventQueueFull(this, new EventArgs());
                }
            }
        }

        #endregion

        /// <summary>
        /// Repopulate firmware information.
        /// </summary>
        public void PopulateFirmwareInfo()
        {
            populateFirmwareInfo(false);
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            ControllerStatusStorage statusStorage = new ControllerStatusStorage();
            if (statusStorage != null)
            {
                statusStorage.LogicalId = LogicalId;
                statusStorage.ParentDeviceId = 0;
                statusStorage.IsolatedAlarms = IsolatedAlarms;
                statusStorage.LatchedAlarms = LatchedAlarms;
                statusStorage.DateLastArmed = LastArmed;
                statusStorage.DateLastDisarmed = LastDisarmed;
            }
            return statusStorage;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            Device8003EventState deviceState = new Device8003EventState();
            InitializeEventState(deviceState);
            deviceState.Offline = false;

            deviceState.PowerFail = MaskedPowerState;
            deviceState.BatteryFail = MaskedBatteryState;
            deviceState.BatteryChargerFail = maskedBatteryChargerFailed;
            deviceState.InternalBatteryFail = MaskedInternalBatteryLow;
            deviceState.ReportingFailConnectionTable1 = GetMaskedOnlineConnectionTable(0) == false;
            deviceState.ReportingFailConnectionTable2 = GetMaskedOnlineConnectionTable(1) == false;
            deviceState.ReportingFail = deviceState.ReportingFailConnectionTable1 || deviceState.ReportingFailConnectionTable2;
            deviceState.LanDisconnect = LanDisconnected;

            switch (cardDatabaseStatus)
            {
                case CardDatabaseStatus.SramDatabase90PercentFull:
                    deviceState.DatabaseNearFull = true;
                    break;
                case CardDatabaseStatus.SramDatabaseFull:
                    deviceState.DatabaseFull = true;
                    break;
            }
            return deviceState;
        }

        /// <summary>
        /// Initialize device information instance from status / configuration information
        /// </summary>
        /// <param name="deviceInformation">Device Information instance</param>
        protected override void InitializeDeviceInformation(DeviceInformation deviceInformation)
        {
            base.InitializeDeviceInformation(deviceInformation);
            deviceInformation.HardwareVersion = HardwareVersion.ToString();
            deviceInformation.CurrentFirmwareVersion = String.Format("{0} build {1}", FirmwareVersion, BuildNumber);
            if (Image1FirmwareVersion != null && Image1FirmwareVersion.Length > 0 &&
                Image2FirmwareVersion != null && Image2FirmwareVersion.Length > 0)
            {
                deviceInformation.AvailableFirmwareVersions = new string[2];
                deviceInformation.AvailableFirmwareVersions[0] = String.Format("{0} build {1}", Image1FirmwareVersion, Image1BuildNumber);
                deviceInformation.AvailableFirmwareVersions[1] = String.Format("{0} build {1}", Image2FirmwareVersion, Image2BuildNumber);
            }
            else
            {
                deviceInformation.AvailableFirmwareVersions = new string[1];
                deviceInformation.AvailableFirmwareVersions[0] = deviceInformation.CurrentFirmwareVersion;
            }
            if (RunningImage == BootImage8003.Image1)
                deviceInformation.ActiveFirmwareVersion = 1;
            else
                deviceInformation.ActiveFirmwareVersion = 2;
            deviceInformation.MaxDoors = LicenseManager.Instance.MaximumDoorCount;
            deviceInformation.MaxInputs = LicenseManager.Instance.MaximumInputCount;
            deviceInformation.MaxOutputs = LicenseManager.Instance.MaximumOutputCount;
            deviceInformation.MACAddress = StatusManager.Instance.Controller.MACAddress;

            accessCardManager.PopulateCardInformation(deviceInformation);
        }

        private void populateFirmwareInfo(bool isFirstTime)
        {
            DataFlashConfig dataFlashConfig = new DataFlashConfig(dataFlash);

            // Do not change the Running image state during operation, only at bootup.
            if (isFirstTime == true)
                RunningImage = dataFlashConfig.BootImage;

            if (RunningImage == BootImage8003.Image1)
            {
                RunningImage = BootImage8003.Image1;
                if (dataFlashConfig.BootImageConfig[0] != null)
                {
                    this.FirmwareVersion = dataFlashConfig.BootImageConfig[0].ImageVersion.ToString();
                    BuildNumber = dataFlashConfig.BootImageConfig[0].BuildNumber;
                }
            }
            else
            {
                RunningImage = BootImage8003.Image2;
                if (dataFlashConfig.BootImageConfig[1] != null)
                {
                    this.FirmwareVersion = dataFlashConfig.BootImageConfig[1].ImageVersion.ToString();
                    BuildNumber = dataFlashConfig.BootImageConfig[1].BuildNumber;
                }
            }

            if (dataFlashConfig.BootImageConfig[0] != null)
            {
                Image1FirmwareVersion = dataFlashConfig.BootImageConfig[0].ImageVersion.ToString();
                Image1BuildNumber = dataFlashConfig.BootImageConfig[0].BuildNumber;
            }
            if (dataFlashConfig.BootImageConfig[1] != null)
            {
                Image2FirmwareVersion = dataFlashConfig.BootImageConfig[1].ImageVersion.ToString();
                Image2BuildNumber = dataFlashConfig.BootImageConfig[1].BuildNumber;
            }

            this.MACAddress = string.Format("{0}:{1}:{2}:{3}:{4}:{5}",
                dataFlashConfig.MacAddress[0].ToString("X").PadLeft(2, '0'),
                dataFlashConfig.MacAddress[1].ToString("X").PadLeft(2, '0'),
                dataFlashConfig.MacAddress[2].ToString("X").PadLeft(2, '0'),
                dataFlashConfig.MacAddress[3].ToString("X").PadLeft(2, '0'),
                dataFlashConfig.MacAddress[4].ToString("X").PadLeft(2, '0'),
                dataFlashConfig.MacAddress[5].ToString("X").PadLeft(2, '0'));
        }

        /// <summary>
        /// Check masked alarms when we restore status from previous stored state
        /// </summary>
        protected override void VerifyMaskedAlarms()
        {
            base.VerifyMaskedAlarms();
            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail))
            {
                maskedPowerState = PowerFailState.None;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.PowerFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail))
            {
                if (maskedPowerState == PowerFailState.None)
                    maskedPowerState = PowerFailState.Fail;
            }

            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail))
            {
                maskedBatteryState = BatteryFailState.None;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.BatteryFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail))
            {
                if (maskedBatteryState == BatteryFailState.None)
                    maskedBatteryState = BatteryFailState.Fail;
            }

            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail))
            {
                maskedBatteryChargerFailed = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.BatteryChargerFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail))
            {
                maskedBatteryChargerFailed = true;
            }

            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail))
            {
                maskedInternalBatteryLow = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.InternalBatteryFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail))
            {
                maskedInternalBatteryLow = true;
            }

            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.Tamper))
            {
                maskedTamperActive = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.Tamper);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.Tamper))
            {
                maskedTamperActive = true;
            }

            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.ReportingFail))
            {
                maskedOnlineConnectionTable[0] = true;
                maskedOnlineConnectionTable[1] = true;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.ReportingFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.ReportingFail))
            {
                if (ConfigurationManager.Instance.GetControllerConnectionTable(0) != null)
                    maskedOnlineConnectionTable[0] = false;
                if (ConfigurationManager.Instance.GetControllerConnectionTable(1) != null)
                    maskedOnlineConnectionTable[1] = false;
            }
        }

        internal void RefreshAfterConfigurationChange(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems)
        {
            // update Controller Power Supply List
            List<int> controllerPowerSupplies = new List<int>();
            foreach (var device in ConfigurationManager.Instance.Devices)
            {
                if (device.Enabled == false)
                {
                    continue;
                }
                if (device.HardwareType == HardwareType.Pacom8303)
                {
                    Pacom8303Configuration pacom8303Configuration = device as Pacom8303Configuration;
                    if (pacom8303Configuration != null && pacom8303Configuration.ControllersPowerSupply == true)
                    {
                        controllerPowerSupplies.Add(device.Id);
                    }
                }
                else if (device.HardwareType == HardwareType.Pacom8308)
                {
                    Pacom8308Configuration pacom8308Configuration = device as Pacom8308Configuration;
                    if (pacom8308Configuration != null && pacom8308Configuration.ControllersPowerSupply == true)
                    {
                        controllerPowerSupplies.Add(device.Id);
                    }
                }
            }
            deviceLoopPowerSupplies = controllerPowerSupplies.ToArray();

            bool connectionTableChanges = false;
            foreach (var removedItem in removedItems)
            {
                if (removedItem.ConfigurationType == ConfigurationElementType.ControllerConnectionTable)
                {
                    connectionTableChanges = true;
                    break;
                }
            }
            if (connectionTableChanges == false)
            {
                foreach (var changedItem in changedItems)
                {
                    if (changedItem.ConfigurationType == ConfigurationElementType.ControllerConnectionTable)
                    {
                        connectionTableChanges = true;
                        break;
                    }
                }
            }
            if (connectionTableChanges == false)
            {
                foreach (var newlyAddedItem in newlyAddedItems)
                {
                    if (newlyAddedItem.ConfigurationType == ConfigurationElementType.ControllerConnectionTable)
                    {
                        connectionTableChanges = true;
                        break;
                    }
                }
            }

            if (connectionTableChanges)
            {
                ControllerConnectionTable firstControllerConnectionTable = ConfigurationManager.Instance.GetControllerConnectionTable(0);
                ControllerConnectionTable secondControllerConnectionTable = ConfigurationManager.Instance.GetControllerConnectionTable(1);

                // Set initial online connection table status
                if (firstControllerConnectionTable == null)
                    onlineConnectionTable[0] = true;
                else
                    onlineConnectionTable[0] = false;
                if (secondControllerConnectionTable == null)
                    onlineConnectionTable[1] = true;
                else
                    onlineConnectionTable[1] = false;

                maskedOnlineConnectionTable[0] = onlineConnectionTable[0];
                maskedOnlineConnectionTable[1] = onlineConnectionTable[1];

                // Set initial online primary connection entry status
                setInitialOnlineFirstConnectionEntry(firstControllerConnectionTable, secondControllerConnectionTable);
            }
        }

        internal void RestoreToPreviousState(ControllerStatusStorage previousStatus)
        {
            if (previousStatus == null)
                return;

            this.isolatedAlarms = previousStatus.IsolatedAlarms;
            this.latchedAlarms = previousStatus.LatchedAlarms;
            this.LastArmed = previousStatus.DateLastArmed;
            this.LastDisarmed = previousStatus.DateLastDisarmed;
            VerifyMaskedAlarms();
        }

        internal void Persist(Asn1DerFormatter asn1Serializer, Stream statusStream)
        {
            try
            {
                asn1Serializer.Serialize(statusStream, CreateStatusStorage());
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Unable to store status for controller {0}. {1}", this.LogicalId, ex.Message);
                });
            }
        }

        /// <summary>
        /// Get / Set controller online / offline status
        /// Unused. Always returns true. Use GetOnlineConnectionTable / SetOnlineConnectionTable instead.
        /// </summary>
        public override bool Online
        {
            get
            {
                return true;
            }
            set
            {
            }
        }

        public const int OfflineOnConnectionTable = -1;
        /// <summary>
        /// Set controller online / offline status
        /// </summary>
        public void SetOnlineConnectionTable(int controllerConnectionTableIndex, bool online, int connectionEntryIndex)
        {
            if (Enabled == false)
                return;
            if (onlineConnectionTable[controllerConnectionTableIndex] != online)
            {
                onlineConnectionTable[controllerConnectionTableIndex] = online;
                onlineConnectionEntry[controllerConnectionTableIndex] = connectionEntryIndex;
                SetMaskedOnlineConnectionTable(controllerConnectionTableIndex, online);
                StatusManager.Instance.RequestStatusToStorage();

                if (ControllerOnlineStatusChanged != null)
                    ControllerOnlineStatusChanged(this, new ControllerOnlineOfflineEventArgs(controllerConnectionTableIndex, online == false));

                if (online == true)
                    MacroControl.Instance.EnqueueFrontEndConnectionRestoredEvent();
            }
        }

        /// <summary>
        /// Set controller primary connection entry status
        /// </summary>
        /// <param name="controllerConnectionTableIndex"></param>
        /// <param name="online"></param>
        public void SetFirstConnectionEntryStatus(int controllerConnectionTableIndex, bool online)
        {
            if (Enabled == false)
                return;

            ConnectionEntryState newValue = online ? ConnectionEntryState.Online : ConnectionEntryState.Offline;

            if (onlineFirstConnectionEntry[controllerConnectionTableIndex] != ConnectionEntryState.NotPresent
                && onlineFirstConnectionEntry[controllerConnectionTableIndex] != newValue)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Connection Table {0} Primary Entry is {1}", controllerConnectionTableIndex + 1, online);
                });

                onlineFirstConnectionEntry[controllerConnectionTableIndex] = newValue;
                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        /// <summary>
        /// Set controller masked online / offline status
        /// </summary>
        public void SetMaskedOnlineConnectionTable(int controllerConnectionTableIndex, bool online)
        {
            if (Enabled == false)
                return;
            if (maskedOnlineConnectionTable[controllerConnectionTableIndex] != online || online == false)
            {
                bool isolated = IsolatedAlarms.Has(EventSourceLatchOrIsolateType.ReportingFail);
                bool latched = LatchedAlarms.Has(EventSourceLatchOrIsolateType.ReportingFail);
                if ((isolated == false && SuspectPoint == false && (latched == false || online == false)) ||
                    (latched == true && maskedOnlineConnectionTable[controllerConnectionTableIndex] == true))
                {
                    maskedOnlineConnectionTable[controllerConnectionTableIndex] = online;

                    if (online == false)
                        IncrementSuspectCount(EventSourceLatchOrIsolateType.ReportingFail);
                    if (ControllerMaskedOnlineStatusChanged != null)
                    {
                        ControllerMaskedOnlineStatusChanged(this, new ControllerOnlineOfflineEventArgs(controllerConnectionTableIndex, online == false));
                        StatusManager.Instance.Devices.TriggerDeviceChangedAlarmState(this);
                    }
                    if (online == false)
                    {
                        ProcessAlarmConfirmation();
                        CheckTerminateArming();
                    }
                    else
                    {
                        CheckStopFailToArmTimer();
                    }

                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get controller online / offline status
        /// </summary>
        public bool GetOnlineConnectionTable(int controllerConnectionTableIndex)
        {
            return onlineConnectionTable[controllerConnectionTableIndex];
        }

        public int GetOnlineConnectionIndex(int controllerConnectionTableIndex)
        {
            return onlineConnectionEntry[controllerConnectionTableIndex];
        }

        /// <summary>
        /// Get controller primary connection entry status
        /// </summary>
        public ConnectionEntryState GetFirstConnectionEntryStatus(int controllerConnectionTableIndex)
        {
            return onlineFirstConnectionEntry[controllerConnectionTableIndex];
        }

        /// <summary>
        /// Get controller online / offline status
        /// </summary>
        public bool GetMaskedOnlineConnectionTable(int controllerConnectionTableIndex)
        {
            return maskedOnlineConnectionTable[controllerConnectionTableIndex];
        }

        public override string ToString()
        {
            return String.Format("Controller Status");
        }

        /// <summary>
        /// Restore EVERYTHING: controller, device loop devices, expansion cards, inputs, outputs.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        public bool UnlatchAll(UserAuditInfo userAuditInfo)
        {
            // Unlatch all areas
            AreaStatus[] areas = StatusManager.Instance.Areas.Items;
            if (areas.Length > 0)
            {
                foreach (var area in areas)
                {
                    area.Unlatch(userAuditInfo);
                }
            }

            // Unlatch all inputs and outputs
            // Unlatching the areas will cover the inputs and outputs in areas but the remaining 
            // inputs and outputs should be unlatched also
            StatusManager.Instance.Inputs.UnlatchAll(userAuditInfo);
            StatusManager.Instance.Outputs.UnlatchAll(userAuditInfo);

            // Unlatch all devices
            DeviceStatusAbstractBase[] devices = StatusManager.Instance.Devices.Items;
            if (devices.Length > 0)
            {
                foreach (var device in devices)
                {
                    device.Unlatch(userAuditInfo);
                }
            }

            // Unlatch all expansion cards
            ExpansionCardStatus[] expansionCards = StatusManager.Instance.ExpansionCards.Items;
            if (expansionCards.Length > 0)
            {
                foreach (var expansionCard in expansionCards)
                {
                    expansionCard.Unlatch(userAuditInfo);
                }
            }

            this.Unlatch(userAuditInfo);
            return true;
        }

        public bool TriggerRemoteMaintenanceStatusRequest(RemoteMaintenanceStatusEventArgs e)
        {
            if (RemoteMaintenanceStatusRequested != null)
            {
                RemoteMaintenanceStatusRequested(this, e);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Last system Armed date
        /// </summary>
        public DateTime LastArmed { get; set; }

        /// <summary>
        /// Last system Armed date
        /// </summary>
        public DateTime LastDisarmed { get; set; }

        /// <summary>
        /// Device Loop Checksum error count
        /// </summary>
        public ushort DeviceLoopChecksumErrors { get; set; }
    }
}
