﻿using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;

namespace Pacom.Peripheral.Common.Status
{
    public class InovonicsSecurityDeviceStatus : InovonicsTransceiverOrRepeaterStatusBase
    {
        /// <summary>
        /// Smoke Detector Device Clean Required Status
        /// </summary>
        private bool sensorCleanRequired = false;
        private bool maskedSensorCleanRequired = false;

        public InovonicsSecurityDeviceStatus(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus)
            : base(configuration, parent, previousStatus)
        {
            SupportedIsolateFlags |= EventSourceLatchOrIsolateType.SensorCleanRequired;

            InovonicsSecurityDeviceStatusStorage inovonicsPreviousStatus = previousStatus as InovonicsSecurityDeviceStatusStorage;
            if (inovonicsPreviousStatus == null || Enabled == false)
                return;

            if (HardwareType == inovonicsPreviousStatus.HardwareType)
            {
                this.sensorCleanRequired = inovonicsPreviousStatus.SensorCleanRequired;
                this.maskedSensorCleanRequired = inovonicsPreviousStatus.MaskedSensorCleanRequired;
                VerifyMaskedAlarms();
            }
        }

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            if (base.LatchAfterFirstAlarm(suspectStatusType) == true)
                return true;
            if (suspectStatusType == EventSourceLatchOrIsolateType.SensorCleanRequired)
                return ConfigurationManager.Instance.ControllerConfiguration.LatchInternalBatteryLowAlarms;
            return false;
        }

        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get { return base.IsCurrentlyLatched || latchedAlarms.HasAny(EventSourceLatchOrIsolateType.SensorCleanRequired); }
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = base.CurrentAlarms;
                if (maskedSensorCleanRequired == true)
                    flags |= EventSourceLatchOrIsolateType.SensorCleanRequired;
                return flags;
            }
        }

        /// <summary>
        /// Get / Set unmasked smoke detector sensor clean required status.
        /// </summary>
        public bool SensorCleanRequired
        {
            get { return sensorCleanRequired; }
            set
            {
                if (Enabled == false)
                    return;
                if (sensorCleanRequired != value)
                {
                    sensorCleanRequired = value;
                    MaskedSensorCleanRequired = sensorCleanRequired;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set masked smoke detector sensor clean required status, send status changed event to front-end if required.
        /// </summary>
        public bool MaskedSensorCleanRequired
        {
            get { return maskedSensorCleanRequired; }
            set
            {
                if (Enabled == false)
                    return;
                if (maskedSensorCleanRequired != value || value == true)
                {
                    bool prevCleanRequired = maskedSensorCleanRequired;
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.SensorCleanRequired) == false &&
                        SuspectPoint == false &&
                        (LatchedAlarms.Has(EventSourceLatchOrIsolateType.SensorCleanRequired) == false || value == true))
                    {
                        maskedSensorCleanRequired = value;
                        if (maskedSensorCleanRequired == true)
                        {
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.SensorCleanRequired);
                            CheckTerminateArming();
                        }
                        else
                        {
                            CheckStopFailToArmTimer();
                        }
                        Parent.TriggerSensorCleanRequiredChangedStatus(this);
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        /// <summary>
        /// Set the state of device IsolatedAlarms flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="value">New isolated options. If value = EventSourceLatchOrIsolateType.None -> Deisolate all.
        /// If value = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.Tamper -> Isolate all or any.
        /// When de-isolating if any of the device inputs is in alarm the alarm will be queued into AlarmManager.
        /// </param>
        /// <returns>True if the command was successfully executed</returns>
        public override bool SetIsolated(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType value)
        {
            if (base.SetIsolated(userAuditInfo, value) == false)
                return false;

            // Mask-out all flags this device does not support
            value &= SupportedIsolateFlags;
            if (value != isolatedAlarms)
            {
                // Sensor clean - Isolate/de-isolate 
                SetIsolated(value, EventSourceLatchOrIsolateType.SensorCleanRequired, false, sensorCleanRequired);
                StatusManager.Instance.RequestStatusToStorage();
            }
            return true;
        }

        /// <summary>
        /// Set masked status for [optionToCheck] to [newValue]
        /// </summary>
        /// <param name="optionToCheck">Option to check, e.g.: Offline, Tamper, InternalBatteryFail, etc.</param>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(EventSourceLatchOrIsolateType optionToCheck, bool newValue)
        {
            if (base.SetMaskedStatus(optionToCheck, newValue))
                return true;
            if (optionToCheck == EventSourceLatchOrIsolateType.SensorCleanRequired)
                MaskedSensorCleanRequired = newValue;
            return true;
        }

        /// <summary>
        /// Restore masked online, device tamper, etc. status if required after unlatching the device alarms. Restore only if the
        /// current instantaneous status is Secure (device online, tamper secure, etc.).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        protected override void RestoreAfterUnlatch(UserAuditInfo userAuditInfo)
        {
            base.RestoreAfterUnlatch(userAuditInfo);
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.SensorCleanRequired) == false && SensorCleanRequired == false)
                MaskedSensorCleanRequired = SensorCleanRequired;
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            InovonicsSecurityDeviceStatusStorage statusStorage = new InovonicsSecurityDeviceStatusStorage();
            if (statusStorage != null)
            {
                InitializeStatusStorage(statusStorage, false);
                statusStorage.SensorCleanRequired = SensorCleanRequired;
                statusStorage.MaskedSensorCleanRequired = MaskedSensorCleanRequired;
            }
            return statusStorage;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            DeviceInovonicsSecurityDeviceEventState deviceState = new DeviceInovonicsSecurityDeviceEventState();
            InitializeEventState(deviceState);
            deviceState.InternalBatteryLow = MaskedInternalBatteryLow;
            deviceState.SensorCleanRequired = MaskedSensorCleanRequired;
            deviceState.SignalLevel = SignalLevel;
            deviceState.SignalMargin = SignalMargin;
            return deviceState;
        }

        /// <summary>
        /// Check masked alarms when we restore status from previous stored state
        /// </summary>
        protected override void VerifyMaskedAlarms()
        {
            base.VerifyMaskedAlarms();
            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.SensorCleanRequired))
            {
                maskedSensorCleanRequired = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.SensorCleanRequired);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.SensorCleanRequired))
            {
                maskedSensorCleanRequired = true;
            }
        }
    }
}
