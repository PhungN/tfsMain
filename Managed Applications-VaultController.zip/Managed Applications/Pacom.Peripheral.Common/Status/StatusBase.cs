﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common;
using Pacom.Core.Contracts;
using Pacom.Core.Attributes;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts.Status;

namespace Pacom.Peripheral.Common.Status
{
    public abstract class StatusBase<T> : IStatusItem, IDisposable
    {
        public const string DefaultSerialNumber = "0000-0000-000000";
        public const string DefaultFirmwareVersion = "01.00";
        public const string DefaultBootloaderVersion = "01.00";

        public bool Enabled { get; private set; }
        public int LogicalId { get; set; }
        public int ParentDeviceId { get; set; }
        public bool Isolating { get; protected set; }

        protected StatusBase(ConfigurationBase configuration, T parent)
        {
            this.parent = parent;
            suspectCount = 0;
            isolatedAlarms = EventSourceLatchOrIsolateType.None;
            latchedAlarms = EventSourceLatchOrIsolateType.None;
            Isolating = false;
            if (configuration == null)
            {
                LogicalId = 0;
                Enabled = false;
            }
            else
            {
                LogicalId = configuration.Id;
                Enabled = true;
                if (configuration is NodeConfiguration)
                {
                    NodeConfiguration node = (NodeConfiguration)configuration;
                    Enabled = node.Enabled;
                    ParentDeviceId = node.ParentDeviceId;
                }
            }
        }

        private T parent = default(T);

        internal protected T Parent
        {
            get { return this.parent; }
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public virtual StatusStorageConfigurationBase CreateStatusStorage()
        {
            return null;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public virtual NodeStateBase CreateEventState()
        {
            return null;
        }

        /// <summary>
        /// Status item instance isolate/deisolate alarm options
        /// </summary>
        protected EventSourceLatchOrIsolateType isolatedAlarms = EventSourceLatchOrIsolateType.None;

        /// <summary>
        /// Isolate / Deisolate options supported by this device. E.g.: device supports Offline and Tamper isolation.
        /// </summary>
        private EventSourceLatchOrIsolateType supportedIsolateFlags = EventSourceLatchOrIsolateType.None;
        public EventSourceLatchOrIsolateType SupportedIsolateFlags
        {
            get { return supportedIsolateFlags; }
            set { supportedIsolateFlags = value; }
        }

        /// <summary>
        /// Get latched status flags for this instance: e.g. -> if this is a device status instance then this will
        /// return the Offline and Tamper alarms latched status. The latched status bits will be set if and 
        /// only if the coresponding alarm has changed between Secure and Alarm for MaxAlarmCountBeforeLatchingCurrentStatus
        /// times.
        /// </summary>
        protected EventSourceLatchOrIsolateType latchedAlarms = EventSourceLatchOrIsolateType.None;
        public EventSourceLatchOrIsolateType LatchedAlarms
        {
            get { return latchedAlarms; }
        }

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated. Base implementation returns False. 
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected virtual bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            return false;
        }

        /// <summary>
        /// Returns the current latch status for this status item instance and the [latchFlagToCheck]
        /// </summary>
        /// <param name="latchFlagToCheck">The status item laarm flag that needs to be checked for latching</param>
        /// <returns>The latch status for this status item.</returns>
        public virtual EventSourceLatchStatus GetLatchStatusFor(EventSourceLatchOrIsolateType latchFlagToCheck)
        {
            return EventSourceLatchStatus.NotLatched;
        }

        /// <summary>
        /// Get the string representation of the alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public virtual string AlarmsAsString
        {
            get { return string.Empty; }
        }

        /// <summary>
        /// Get the string array representation of the current alarms for this point
        /// </summary>
        public virtual string[] AlarmsAsStringArray
        {
            get { return new string[0]; }
        }

        /// <summary>
        /// Get the string representation of the isolated alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public virtual string IsolatedAlarmsAsString
        {
            get { return string.Empty; }
        }

        /// <summary>
        /// Get the string array representation of the isolated alarms for this point
        /// </summary>
        public virtual string[] IsolatedAlarmsAsStringArray
        {
            get { return new string[0]; }
        }

        /// <summary>
        /// Get the string representation of the latched alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public virtual string LatchedAlarmsAsString
        {
            get { return string.Empty; }
        }

        /// <summary>
        /// Get the string array representation of the latched alarms for this point
        /// </summary>
        public virtual string[] LatchedAlarmsAsStringArray
        {
            get { return new string[0]; }
        }

        /// <summary>
        /// Update the isolatedOptions flag for one isolate option only: e.g.: Offline, Tamper, etc.
        /// </summary>
        /// <param name="newIsolateOptions">New isolated options</param>
        /// <param name="optionToCheck">One option to isolate.</param>
        /// <param name="secureValue">Option secure value: Offline = true, Tamper = false, etc.</param>
        /// <param name="unmaskedValue">Unmasked option value</param>
        protected void SetIsolated(EventSourceLatchOrIsolateType newIsolateOptions, EventSourceLatchOrIsolateType optionToCheck, bool secureValue, bool unmaskedValue)
        {
            if (isolatedAlarms.BitChanged(newIsolateOptions, optionToCheck) == true)
            {
                isolatedAlarms = isolatedAlarms.ClearFlag(optionToCheck);
                bool isolated = isolatedAlarms.BitSetAfter(newIsolateOptions, optionToCheck);
                if (isolated == true)
                {
                    // Isolate option to check (e.g.: Offline / Tamper / etc.)
                    ResetSuspectCount();
                    latchedAlarms = latchedAlarms.ClearFlag(optionToCheck);
                    SetMaskedStatus(optionToCheck, secureValue);
                    isolatedAlarms = isolatedAlarms.SetFlag(optionToCheck);
                }
                else
                {
                    // Deisolate option to check
                    SetMaskedStatus(optionToCheck, unmaskedValue);
                }
            }
        }

        /// <summary>
        /// Set masked status for [optionToCheck] to [newValue]
        /// </summary>
        /// <param name="optionToCheck">Option to chec, e.g.: Offline, Tamper, etc.</param>
        /// <param name="newValue">New masked status value.</param>
        protected virtual bool SetMaskedStatus(EventSourceLatchOrIsolateType optionToCheck, bool newValue)
        {
            return false;
        }

        /// <summary>
        /// Reset currently latched flag
        /// </summary>
        protected void ResetIsCurrentlyLatched()
        {
            ResetSuspectCount();
            latchedAlarms = EventSourceLatchOrIsolateType.None;
            StatusManager.Instance.RequestStatusToStorage();
        }

        /// <summary>
        /// Reset specified latched flag(s)
        /// </summary>
        /// <param name="options">Latched alarms to unlatch (restore)</param>
        protected void ResetIsCurrentlyLatched(EventSourceLatchOrIsolateType options)
        {
            ResetSuspectCount();
            latchedAlarms = latchedAlarms.ClearFlag(options);
            StatusManager.Instance.RequestStatusToStorage();
        }

        #region IStatusItem Members

        public abstract StatusItemType ItemType
        {
            get;
        }

        public EventSourceLatchOrIsolateType IsolatedAlarms
        {
            get { return isolatedAlarms; }
        }

        /// <summary>
        /// Check if this status itme has multiple isolated alarms
        /// </summary>
        public bool HasMultipleIsolatedAlarms
        {
            get
            {
                if (isolatedAlarms == EventSourceLatchOrIsolateType.None)
                    return false;

                int count = 0;
                foreach (EventSourceLatchOrIsolateType eventSource in EnumHelper.GetValues<EventSourceLatchOrIsolateType>())
                {
                    if (eventSource == EventSourceLatchOrIsolateType.None)
                        continue;

                    if (isolatedAlarms.Has(eventSource) == true)
                        count++;
                    if (count > 1)
                        return true;
                }
                return false;
            }
        }

        /// <summary>
        /// Device Offline flags
        /// </summary>
        protected const EventSourceLatchOrIsolateType Offline = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.ReportingFail;

        /// <summary>
        /// Get the ConfirmedType for current alarm based on area mode and the previous unconfirmed alarm if required.
        /// </summary>
        /// <param name="unconfirmedAlarmSource">The source of an existing unconfirmed alarm, received before the current alarm.</param>
        /// <param name="areaSource">Area from which the alarm has originated</param>
        /// <returns>None, Unconfirmed or Confirmed.</returns>
        public virtual ConfirmedType GetConfirmedAlarmType(IStatusItem unconfirmedAlarmSource, IStatusItem areaSource)
        {
            return ConfirmedType.None;
        }

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        public virtual bool CanIsolate(UserAccessLevel level)
        {
            return level == UserAccessLevel.AccessLevel3;
        }

        /// <summary>
        /// True if this status item can be de-isolated at the specifed access level
        /// </summary>
        public virtual bool CanDeisolate(UserAccessLevel level)
        {
            return level == UserAccessLevel.AccessLevel3;
        }

        /// <summary>
        /// Isolate status item state.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public abstract void Isolate(UserAuditInfo userAuditInfo);

        /// <summary>
        /// Deisolate status item state.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public abstract void Deisolate(UserAuditInfo userAuditInfo);

        /// <summary>
        /// Isolate device / controller / input / output / etc. specific alarm or
        /// all alarms (E.g.: for a device we can isolate Tamper or Offline or both of them).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="options">Alarm types to isolate: Offline / Tamper / etc.</param>
        public virtual void Isolate(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options)
        {
            Isolate(userAuditInfo);
        }

        /// <summary>
        /// Deisolate device / controller / input / output / etc. specific alarm or
        /// all alarms (E.g.: for a device we can deisolate Tamper or Offline or both of them).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="options">Alarm types to deisolate: Offline / Tamper / etc.</param>
        public virtual void Deisolate(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options)
        {
            Deisolate(userAuditInfo);
        }

        /// <summary>
        /// Set isolated flag for a single status item (device, expansion card, input, door, output, reader, etc.) for a specified duration.
        /// </summary>
        /// <param name="value">True for isolate, false for normal operation when the [bitFieldValue] is not used.</param>
        /// <param name="bitField">BitField options to isolate/deisolate when the [boolValue] is not used</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="durationInSeconds">The duration for which the point will be isolated, 0 means that the point will be isolated idefinitely</param>
        /// <returns>True if the point's isolated state was successfully changed, False otherwise.</returns>
        public virtual bool SetIsolated(bool value, EventSourceLatchOrIsolateType bitField, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("[{0}] instance does not implement SetIsolated() method.", ItemType);
            });
            return false;
        }

        /// <summary>
        /// Unlatch point's alarms if latched
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        /// <returns>True if the point has been unlatched</returns>
        public virtual bool Unlatch(UserAuditInfo userAuditInfo)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("[{0}] instance does not implement Unlatch(userId) method.", ItemType);
            });
            return false;
        }

        /// <summary>
        /// Unlatch point specified alarms if latched
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        /// <param name="options">Latched alarms to unlatch (restore)</param>
        /// <returns>True if the point has been unlatched</returns>
        public virtual bool Unlatch(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("[{0}] instance does not implement Unlatch(userId, options) method.", ItemType);
            });
            return false;
        }

        /// <summary>
        /// Current Suspect alarms count for this status item instance. 
        /// </summary>
        protected int suspectCount = 0;
        protected int SuspectCount
        {
            get { return suspectCount; }
        }

        public bool SuspectPoint
        {
            get
            {
                return suspectCount >= ConfigurationManager.Instance.ControllerConfiguration.SuspectDeviceActivationCounter && 
                        ConfigurationManager.Instance.ControllerConfiguration.SuspectDeviceActivation == true;
            }
        }

        /// <summary>
        /// Increment suspect count for specified [suspectStatusType]. 
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type for which the count will be incremented</param>
        public void IncrementSuspectCount(EventSourceLatchOrIsolateType suspectStatusType)
        {
            if (ConfigurationManager.Instance.ControllerConfiguration.SuspectDeviceActivation == true || LatchAfterFirstAlarm(suspectStatusType) == true)
            {
                suspectCount++;
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("INC SUSPECT COUNT -> [{0}] FOR STATUS ITEM = [{1}].", suspectCount, DisplayName);
                });
                if (suspectCount >= ConfigurationManager.Instance.ControllerConfiguration.SuspectDeviceActivationCounter || LatchAfterFirstAlarm(suspectStatusType) == true)
                {
                    latchedAlarms = latchedAlarms.SetFlag(suspectStatusType);
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("ALARM LATCHED -> [{0}] FOR STATUS ITEM = [{1}].", suspectStatusType, DisplayName);
                    });
                }
            }
            else
            {
                suspectCount = 0;
            }
        }

        /// <summary>
        /// Reset suspect count for this status item instance. 
        /// </summary>
        public void ResetSuspectCount()
        {
            suspectCount = 0;
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return string.Format("RESET SUSPECT COUNT -> [{0}] FOR STATUS ITEM = [{1}].", suspectCount, DisplayName);
            });
        }

        /// <summary>
        /// Get all current alarms. The default is None. Only devices are implementing this.
        /// </summary>
        public virtual EventSourceLatchOrIsolateType CurrentAlarms
        {
            get { return EventSourceLatchOrIsolateType.None; }
        }

        /// <summary>
        /// Check if this status itme has multiple alarms
        /// </summary>
        public bool HasMultipleAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType alarms = CurrentAlarms;
                if (alarms == EventSourceLatchOrIsolateType.None)
                    return false;

                int count = 0;
                foreach (EventSourceLatchOrIsolateType eventSource in EnumHelper.GetValues<EventSourceLatchOrIsolateType>())
                {
                    if (eventSource == EventSourceLatchOrIsolateType.None)
                        continue;

                    if (alarms.Has(eventSource) == true)
                        count++;
                    if (count > 1)
                        return true;
                }
                return false;
            }
        }

        /// <summary>
        /// Check if this status item has any alarms
        /// </summary>
        public virtual bool HasAnyAlarm
        {
            get { return CurrentAlarms.Empty() == false; }
        }

        /// <summary>
        /// Indicates that the status item instance is in latched state when this value is true.
        /// The status item has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public virtual bool IsCurrentlyLatched
        {
            get { return latchedAlarms != EventSourceLatchOrIsolateType.None; }
        }

        /// <summary>
        /// Get display name for this status item instance without any alarms / isolated alarms
        /// </summary>
        /// <returns>Display Name string.</returns>
        public virtual string DisplayName
        {
            get { return string.Empty; }
        }

        /// <summary>
        /// Get status item display when alarms are present
        /// </summary>
        /// <returns>Status item display name including any alarms</returns>
        public string DisplayAlarmedName
        {
            get { return string.Format("{0}{1}", DisplayName, AlarmsAsString).Trim(); }
        }

        /// <summary>
        /// Get status item display when isolated alarms are present
        /// </summary>
        /// <returns>Status item display name including any isolated alarms</returns>
        public string DisplayIsolatedName
        {
            get { return string.Format("{0}{1}", DisplayName, IsolatedAlarmsAsString).Trim(); }
        }

        /// <summary>
        /// Get alarm description for only one [alarmType], implemented for devices only, not needed for other status items. Used when 
        /// isolating / deisolating a single device alarm at a time.
        /// </summary>
        /// <param name="alarmType">Alarm Type: Offline, Tamper, etc.</param>
        /// <returns></returns>
        public virtual string AlarmDescription(EventSourceLatchOrIsolateType alarmType)
        {
            return string.Empty;
        }

        #endregion

        internal virtual void RestoreToInitialState(bool controllerRestarted) { }

        #region IDisposable Members

        internal virtual void Cleanup() { }

        protected bool disposed = false;

        private void Dispose(bool disposing)
        {
            try
            {
                if (disposed == false)
                {
                    if (disposing)
                    {
                        this.Cleanup();
                    }
                    disposed = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return ex.ToString();
                });
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
