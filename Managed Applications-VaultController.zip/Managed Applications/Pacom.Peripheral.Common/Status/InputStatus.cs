﻿using System;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using System.Threading;
using System.Collections.Generic;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status;

namespace Pacom.Peripheral.Common.Status
{
    public sealed class InputStatus : StatusBase<InputStatusList>
    {
        private bool isolated = false;

        /// <summary>
        /// Input has latched flag set in configuration
        /// </summary>
        private bool isConfiguredToBeLatched = false;

        /// <summary>
        /// Is input configured to report trouble alarms
        /// </summary>
        private bool noTroubleAlarms = true;

        /// <summary>
        /// Is input configured to report Amarm as SelfTestFail
        /// </summary>
        private bool reportAlarmAsSelfTestFail = false;

        private Common.InputStatus maskedStatus = Common.InputStatus.Secure;
        private Common.InputStatus latchedMaskedStatus = Common.InputStatus.Secure;
        private Common.InputStatus unmaskedStatus = Common.InputStatus.Unknown;

        private int analogValue = 0;
        private bool areaHasEntryDelay = false;
        private InputCategory inputCategory = InputCategory.Normal;

        private ConfirmedType confirmedType = ConfirmedType.None;
        public ConfirmedType ConfirmedType
        {
            get { return confirmedType; }
            set { confirmedType = value; }
        }

        private ConfirmedAlarmType confirmedAlarmType = ConfirmedAlarmType.Normal;
        public ConfirmedAlarmType ConfirmedAlarmType
        {
            get { return confirmedAlarmType; }
            set { confirmedAlarmType = value; }
        }

        private bool triggersEntryDelay = false;
        public bool TriggersEntryDelay
        {
            get { return triggersEntryDelay; }
        }

        public InputStatus(ConfigurationBase configuration, InputStatusList parent, InputStatusStorage previousStatus) :
            base(configuration, parent)
        {
            InputConfiguration inputConfig = (InputConfiguration)configuration;
            if (inputConfig != null)
            {
                noTroubleAlarms = inputConfig.NoTamper;
                reportAlarmAsSelfTestFail = inputConfig.ReportAlarmAsSelfTestFail;
                isConfiguredToBeLatched = inputConfig.Latched;
                inputCategory = inputConfig.InputCategory;
                confirmedAlarmType = inputConfig.ConfirmedAlarmType;
                triggersEntryDelay = inputConfig.EntryDelayRunningActionType == EntryDelayRunningActionType.StartsEntryDelay;
                AreaConfiguration areaConfiguration = ConfigurationManager.Instance.GetAreaConfiguration(inputConfig.AreaId);
                if (areaConfiguration != null && areaConfiguration.EntryDelay > 0)
                    areaHasEntryDelay = true;

                if (previousStatus == null || this.Enabled == false)
                    return;
                LastAutomaticIntegrityCheckTriggeredTime = previousStatus.LastAutomaticIntegrityCheckTriggeredTime;
                if (this.isConfiguredToBeLatched == previousStatus.IsConfiguredToBeLatched &&
                    this.noTroubleAlarms == previousStatus.IsConfiguredToNotReportTroubleAlarms)
                {
                    ResetSuspectCount();
                    this.latchedAlarms = this.latchedAlarms.SetOrResetFlag(EventSourceLatchOrIsolateType.InputAlarms, previousStatus.IsCurrentlyLatched);
                    this.isolated = previousStatus.Isolated;

                    if (isolated)
                    {
                        maskedStatus = Pacom.Peripheral.Common.InputStatus.Secure;
                        latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.InputAlarms);
                    }
                    else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.InputAlarms) && maskedStatus == Common.InputStatus.Secure)
                    {
                        if (previousStatus.MaskedStatus != Common.InputStatus.Secure &&
                            previousStatus.MaskedStatus != Common.InputStatus.Unknown && IsUnqualifiedAlarm(previousStatus.MaskedStatus) == false)
                        {
                            maskedStatus = previousStatus.MaskedStatus;
                        }
                        else
                        {
                            maskedStatus = Pacom.Peripheral.Common.InputStatus.Alarm;
                        }
                    }
                    RefreshAfterConfigurationChange();
                }

                AutomaticIntegrityCheckTriggered = false;
                TestCompleted = false;
                TestFailed = false;
                TestWasSuccessful = false;
            }
        }

        internal void RefreshAfterConfigurationChange()
        {
            InputConfiguration inputConfig = ConfigurationManager.Instance.GetInputConfiguration(LogicalId);
            if (inputConfig != null && inputConfig.AreaId > 0)
            {
                AreaStatus areaStatus = StatusManager.Instance.Areas[inputConfig.AreaId];
                if (areaStatus == null)
                    return;

                if (EvaluateInputAlarmOperation(inputConfig, AreaScheduleLevel.Armed) == AlarmPointOperation.Add)
                    areaStatus.AddPointToArmedList(this);
                if (EvaluateInputAlarmOperation(inputConfig, AreaScheduleLevel.Disarmed) == AlarmPointOperation.Add)
                    areaStatus.AddPointToDisarmedList(this);
                if (isolated)
                    areaStatus.AddPointToIsolatedList(this);
            }
        }

        public override StatusItemType ItemType
        {
            get { return StatusItemType.InputStatus; }
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            InputEventState inputStatus = new InputEventState();
            inputStatus.Id = LogicalId;
            inputStatus.Isolate = Isolated;
            inputStatus.Latch = IsCurrentlyLatched;

            bool areaInTestMode = false;
            InputConfiguration inputConfiguration = ConfigurationManager.Instance.GetInputConfiguration(LogicalId);
            if (inputConfiguration != null && inputConfiguration.AreaId > 0)
            {
                AreaStatus area = StatusManager.Instance.Areas[inputConfiguration.AreaId];
                if (area != null)
                    areaInTestMode = area.InTestMode;
            }

            if (areaInTestMode)
            {
                switch (MaskedStatus)
                {
                    case Common.InputStatus.Alarm:
                        inputStatus.ActiveTest = true;
                        break;
                    case Common.InputStatus.Short:
                        inputStatus.ShortCircuitTest = true;
                        break;
                    case Common.InputStatus.Open:
                        inputStatus.OpenCircuitTest = true;
                        break;
                    case Common.InputStatus.Trouble:
                        inputStatus.TroubleTest = true;
                        break;
                    case Common.InputStatus.Masking:
                        inputStatus.MaskTest = true;
                        break;
                    case Common.InputStatus.RangeReduction:
                        inputStatus.RangeReductionTest = true;
                        break;
                    case Common.InputStatus.MaskingAndRangeReduction:
                        inputStatus.MaskTest = true;
                        inputStatus.RangeReductionTest = true;
                        break;
                    case Common.InputStatus.AlarmAndMasking:
                        inputStatus.ActiveTest = true;
                        inputStatus.MaskTest = true;
                        break;
                    case Common.InputStatus.AlarmAndRangeReduction:
                        inputStatus.ActiveTest = true;
                        inputStatus.RangeReductionTest = true;
                        break;
                    case Common.InputStatus.AlarmAndMaskingAndRangeReduction:
                        inputStatus.ActiveTest = true;
                        inputStatus.MaskTest = true;
                        inputStatus.RangeReductionTest = true;
                        break;
                    case Common.InputStatus.SelfTestFail:
                        inputStatus.TestFailTest = true;
                        break;
                }
            }
            else
            {
                switch (MaskedStatus)
                {
                    case Common.InputStatus.Alarm:
                        inputStatus.Active = true;
                        break;
                    case Common.InputStatus.Short:
                        inputStatus.ShortCircuit = true;
                        break;
                    case Common.InputStatus.Open:
                        inputStatus.OpenCircuit = true;
                        break;
                    case Common.InputStatus.Trouble:
                        inputStatus.Trouble = true;
                        break;
                    case Common.InputStatus.Masking:
                        inputStatus.Mask = true;
                        break;
                    case Common.InputStatus.RangeReduction:
                        inputStatus.RangeReduction = true;
                        break;
                    case Common.InputStatus.MaskingAndRangeReduction:
                        inputStatus.Mask = true;
                        inputStatus.RangeReduction = true;
                        break;
                    case Common.InputStatus.AlarmAndMasking:
                        inputStatus.Active = true;
                        inputStatus.Mask = true;
                        break;
                    case Common.InputStatus.AlarmAndRangeReduction:
                        inputStatus.Active = true;
                        inputStatus.RangeReduction = true;
                        break;
                    case Common.InputStatus.AlarmAndMaskingAndRangeReduction:
                        inputStatus.Active = true;
                        inputStatus.Mask = true;
                        inputStatus.RangeReduction = true;
                        break;
                    case Common.InputStatus.SelfTestFail:
                        inputStatus.TestFail = true;
                        break;
                }
            }
            return inputStatus;
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            InputStatusStorage statusStorage = new InputStatusStorage();
            if (statusStorage != null)
            {
                statusStorage.LogicalId = LogicalId;
                statusStorage.ParentDeviceId = ParentDeviceId;
                statusStorage.Isolated = Isolated;
                statusStorage.IsConfiguredToBeLatched = isConfiguredToBeLatched;
                statusStorage.IsCurrentlyLatched = IsCurrentlyLatched;
                statusStorage.IsConfiguredToNotReportTroubleAlarms = NoTroubleAlarms;
                statusStorage.LastAutomaticIntegrityCheckTriggeredTime = LastAutomaticIntegrityCheckTriggeredTime;
            }
            return statusStorage;
        }

        /// <summary>
        /// Get / Set input unmasked status. Triggers Input Changed Status event if
        /// the input is not isolated or masked.
        /// </summary>
        public Common.InputStatus UnmaskedStatus
        {
            get { return unmaskedStatus; }
            set
            {
                if (Enabled == false)
                    return;
                if (unmaskedStatus != value)
                {
                    InputConfiguration inputConfig = ConfigurationManager.Instance.GetInputConfiguration(LogicalId);
                    if (inputConfig != null && inputConfig.Enabled && inputConfig.AutomaticIntegrityCheckEnabled == true)
                    {
                        if (unmaskedStatus == Common.InputStatus.Secure && value != Common.InputStatus.Secure && value != Common.InputStatus.SelfTestFail)
                        {
                            AutomaticIntegrityCheckTriggered = true;
                            LastAutomaticIntegrityCheckTriggeredTime = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
                        }
                    }

                    Common.InputStatus previousStatus = unmaskedStatus;
                    unmaskedStatus = value;
                    // Trigger unmasked inputs status has changed
                    StatusManager.Instance.Inputs.TriggerChangedUnmaskedStatus(this, previousStatus);
                    // Propagate to masked input state
                    MaskedStatus = unmaskedStatus;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set input masked status. 
        /// </summary>
        public Common.InputStatus MaskedStatus
        {
            get { return maskedStatus; }
            set
            {
                if (Enabled == false)
                    return;

                // On unknown status do not update
                if (value == Common.InputStatus.Unknown)
                    return;

                Common.InputStatus previousMaskedStatus = maskedStatus;

                AlarmPointOperation armedOperation = AlarmPointOperation.None;
                AlarmPointOperation disarmedOperation = AlarmPointOperation.None;
                AreaStatus areaStatus = null;
                bool reportInputStateChange = false;
                bool reportInputStateDuringArmedChange = false;
                bool reportInputStateDuringDisarmedChange = false;
                bool resetCurrentlyLatched;
                bool extendEntryDelay = false;
                bool entryDelayTerminated = false;
                bool forceTerminateEntryDelay = false;
                InputConfiguration inputConfig = ConfigurationManager.Instance.GetInputConfiguration(LogicalId);
                if (inputConfig != null)
                {
                    areaStatus = StatusManager.Instance.Areas[inputConfig.AreaId];
                    if (areaStatus != null)
                    {
                        InputForceOperation forcedOperationDuringArmed;
                        armedOperation = EvaluateInputAlarmOperation(inputConfig, AreaScheduleLevel.Armed, value,
                            previousMaskedStatus, IsCurrentlyLatched, SuspectPoint, Isolated, areaHasEntryDelay, inputConfig.EntryDelayRunningActionType, areaStatus.EntryTimerState, areaStatus.ExitTimerRunning,
                            areaStatus.ConfirmationTimerRunning, (areaStatus.HasConfirmedAlarm || areaStatus.OffRouteInputPointInAlarm), out forcedOperationDuringArmed, out reportInputStateDuringArmedChange,
                            out resetCurrentlyLatched, out extendEntryDelay, out forceTerminateEntryDelay);
                        if (armedOperation == AlarmPointOperation.AddToUnqualified && inputConfig.ConfirmedAlarmType == ConfirmedAlarmType.BS8243Compliant)
                        {
                            switch (value)
                            {
                                case Common.InputStatus.Trouble:
                                    previousUnqualifiedAlarm = Common.InputStatus.UnqualifiedTroubleAlarm; break;
                                case Common.InputStatus.Open:
                                    previousUnqualifiedAlarm = Common.InputStatus.UnqualifiedOpenCircuit; break;
                                case Common.InputStatus.Short:
                                    previousUnqualifiedAlarm = Common.InputStatus.UnqualifiedShortCircuit; break;
                                case Common.InputStatus.Masking:
                                    previousUnqualifiedAlarm = Common.InputStatus.UnqualifiedMasking; break;
                                case Common.InputStatus.RangeReduction:
                                    previousUnqualifiedAlarm = Common.InputStatus.UnqualifiedRangeReduction; break;
                                case Common.InputStatus.MaskingAndRangeReduction:
                                    previousUnqualifiedAlarm = Common.InputStatus.UnqualifiedMaskingAndRangeReduction; break;
                                case Common.InputStatus.AlarmAndMasking:
                                    previousUnqualifiedAlarm = Common.InputStatus.UnqualifiedAlarmAndMasking; break;
                                case Common.InputStatus.AlarmAndRangeReduction:
                                    previousUnqualifiedAlarm = Common.InputStatus.UnqualifiedAlarmAndRangeReduction; break;
                                case Common.InputStatus.AlarmAndMaskingAndRangeReduction:
                                    previousUnqualifiedAlarm = Common.InputStatus.UnqualifiedAlarmAndMaskingAndRangeReduction; break;
                                default:
                                    previousUnqualifiedAlarm = Common.InputStatus.UnqualifiedAlarm; break;
                            }
                        }

                        if (resetCurrentlyLatched)
                            ResetIsCurrentlyLatched();

                        InputForceOperation forcedOperationDuringDisarmed;
                        bool dummyExtendEntryDelay = false;
                        bool dummyTerminateEntryDelay = false;
                        disarmedOperation = EvaluateInputAlarmOperation(inputConfig, AreaScheduleLevel.Disarmed, value,
                            previousMaskedStatus, IsCurrentlyLatched, SuspectPoint, Isolated, areaHasEntryDelay, inputConfig.EntryDelayRunningActionType, areaStatus.EntryTimerState, false,
                            areaStatus.ConfirmationTimerRunning, (areaStatus.HasConfirmedAlarm || areaStatus.OffRouteInputPointInAlarm), out forcedOperationDuringDisarmed, out reportInputStateDuringDisarmedChange,
                            out resetCurrentlyLatched, out dummyExtendEntryDelay, out dummyTerminateEntryDelay);

                        // Apply force command
                        if (areaStatus.Mode == AreaScheduleLevel.Armed)
                        {
                            switch (forcedOperationDuringArmed)
                            {
                                case InputForceOperation.ForcedToAlarm:
                                    value = Common.InputStatus.Alarm;
                                    break;
                                case InputForceOperation.ForcedToSecure:
                                    value = Common.InputStatus.Secure;
                                    break;
                                case InputForceOperation.ForcedToUnqualifiedAlarm:
                                    value = previousUnqualifiedAlarm;
                                    break;
                                case InputForceOperation.ForcedToSelfTestFail:
                                    value = Common.InputStatus.SelfTestFail;
                                    break;
                            }
                            reportInputStateChange = reportInputStateDuringArmedChange;
                            if (reportInputStateChange)
                            {
                                if (value != Common.InputStatus.Secure)
                                {
                                    // Abort the entry delay due to an abnormal alarm.
                                    areaStatus.SendPendingEventsForArea();
                                    // Update previous masked status as we may have transitioned from
                                    // an UnqualifiedAlarm to an Alarm.
                                    previousMaskedStatus = maskedStatus;
                                }
                            }
                            else if (IsUnqualifiedAlarm(value) && SuspectPoint == false)
                            {
                                entryDelayTerminated = areaStatus.AddPointToPendingList(this, extendEntryDelay);
                            }
                            if (forceTerminateEntryDelay)
                                areaStatus.SendPendingEventsForArea(); // Abort the entry delay due to BS8243 point during extended entry delay
                        }
                        else
                        {
                            switch (forcedOperationDuringDisarmed)
                            {
                                case InputForceOperation.ForcedToAlarm:
                                    value = Common.InputStatus.Alarm;
                                    break;
                                case InputForceOperation.ForcedToSecure:
                                    value = Common.InputStatus.Secure;
                                    break;
                                case InputForceOperation.ForcedToSelfTestFail:
                                    value = Common.InputStatus.SelfTestFail;
                                    break;
                            }
                            reportInputStateChange = reportInputStateDuringDisarmedChange;
                        }
                    }
                    else
                    {
                        InputForceOperation forcedOperationNoMode;
                        bool dummyTerminateEntryDelay = false;
                        EvaluateInputAlarmOperation(inputConfig, null, value,
                            previousMaskedStatus, IsCurrentlyLatched, SuspectPoint, Isolated, areaHasEntryDelay, inputConfig.EntryDelayRunningActionType, EntryTimerState.NotRunning, false,
                            false, false, out forcedOperationNoMode, out reportInputStateChange, out resetCurrentlyLatched, out extendEntryDelay, out dummyTerminateEntryDelay);

                        switch (forcedOperationNoMode)
                        {
                            case InputForceOperation.ForcedToAlarm:
                                value = Common.InputStatus.Alarm;
                                break;
                            case InputForceOperation.ForcedToSecure:
                                value = Common.InputStatus.Secure;
                                break;
                            case InputForceOperation.ForcedToSelfTestFail:
                                value = Common.InputStatus.SelfTestFail;
                                break;
                        }

                        if (resetCurrentlyLatched)
                            ResetIsCurrentlyLatched();
                    }
                }

                if (areaStatus != null)
                {
                    switch (disarmedOperation)
                    {
                        case AlarmPointOperation.Add:
                            areaStatus.AddPointToDisarmedList(this);
                            break;
                        case AlarmPointOperation.AddToUnqualified:
                        case AlarmPointOperation.Remove:
                            areaStatus.RemovePointFromDisarmedList(this);
                            break;
                    }
                    switch (armedOperation)
                    {
                        case AlarmPointOperation.Add:
                            areaStatus.AddPointToArmedList(this);
                            break;
                        case AlarmPointOperation.AddToUnqualified:
                            areaStatus.AddPointToUnqualifiedList(this);
                            break;
                        case AlarmPointOperation.Remove:
                            areaStatus.RemovePointFromArmedList(this);
                            break;
                    }
                }
                if (reportInputStateChange == true || (IsUnqualifiedAlarm(value) && SuspectPoint == false))
                {
                    maskedStatus = value;

                    // Enqueue status to expression manager
                    if (maskedStatus.ContainsAlarm() == true)
                    {
                        MacroControl.Instance.EnqueueAnyInputAlarm(this.LogicalId);
                    }
                    else if (maskedStatus.ContainsTrouble() == true)
                    {
                        MacroControl.Instance.EnqueueAnyInputTrouble(this.LogicalId);
                    }


                    bool inAlarm = isAlarm(maskedStatus, previousMaskedStatus);
                    if (inAlarm == true && SuspectPoint == false &&
                       ((areaStatus != null && areaStatus.InTestMode == false) || (areaStatus == null)))
                    {
                        // Increment suspect count and try to latch the input if suspect or configured to be latched
                        IncrementSuspectCount(EventSourceLatchOrIsolateType.InputAlarms);
                    }

                    if (entryDelayTerminated == true && areaStatus != null && areaStatus.InTestMode == false)
                    {
                        areaStatus.SendPendingEventsForArea();
                    }
                    else
                    {
                        if (areaStatus != null && areaStatus.InTestMode == false && confirmedAlarmType == ConfirmedAlarmType.BS8243Compliant &&
                            inAlarm == true && !IsUnqualifiedAlarm(value) && value != Common.InputStatus.SelfTestFail)
                        {
                            // Get confirmed type for this input point
                            confirmedType = areaStatus.GetAlarmConfirmationType(this);
                            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                            {
                                return string.Format("Area [{0}] -> Alarm Confirmation Type is: {1}", areaStatus.DisplayName, confirmedType);
                            });
                            StatusManager.Instance.Inputs.TriggerChangedMaskedStatus(this, maskedStatus, previousMaskedStatus);
                            areaStatus.ProcessAlarmConfirmation(this);
                        }
                        else
                        {
                            if (!IsUnqualifiedAlarm(value) && (areaStatus == null || (areaStatus != null && areaStatus.InputIsInPendingList(this) == false)))
                                confirmedType = ConfirmedType.None;
                            if (reportInputStateChange)
                                StatusManager.Instance.Inputs.TriggerChangedMaskedStatus(this, maskedStatus, previousMaskedStatus);
                        }
                    }
                    StatusManager.Instance.RequestStatusToStorage();
                }
                else
                {
                    StatusManager.Instance.Inputs.TriggerUnreportedMaskedStatus(this, value, previousMaskedStatus);
                }
            }
        }

        public static bool IsUnqualifiedAlarm(Common.InputStatus inputStatus)
        {
            switch (inputStatus)
            {
                case Common.InputStatus.UnqualifiedAlarm:
                case Common.InputStatus.UnqualifiedTroubleAlarm:
                case Common.InputStatus.UnqualifiedOpenCircuit:
                case Common.InputStatus.UnqualifiedShortCircuit:
                case Common.InputStatus.UnqualifiedMasking:
                case Common.InputStatus.UnqualifiedRangeReduction:
                case Common.InputStatus.UnqualifiedMaskingAndRangeReduction:
                case Common.InputStatus.UnqualifiedAlarmAndMasking:
                case Common.InputStatus.UnqualifiedAlarmAndRangeReduction:
                case Common.InputStatus.UnqualifiedAlarmAndMaskingAndRangeReduction:
                    return true;
            }
            return false;
        }

        private static bool isAlarm(Common.InputStatus status, Common.InputStatus previousStatus)
        {
            if (status == Common.InputStatus.Secure || IsUnqualifiedAlarm(status))
                return false;

            switch (previousStatus)
            {
                case Common.InputStatus.AlarmAndMasking:
                    if (status == Common.InputStatus.Alarm || status == Common.InputStatus.Masking)
                        return false;
                    break;
                case Common.InputStatus.AlarmAndMaskingAndRangeReduction:
                    if (status == Common.InputStatus.Alarm || status == Common.InputStatus.Masking ||
                        status == Common.InputStatus.RangeReduction || status == Common.InputStatus.AlarmAndMasking ||
                        status == Common.InputStatus.AlarmAndRangeReduction || status == Common.InputStatus.MaskingAndRangeReduction)
                        return false;
                    break;
                case Common.InputStatus.AlarmAndRangeReduction:
                    if (status == Common.InputStatus.Alarm || status == Common.InputStatus.RangeReduction)
                        return false;
                    break;
                case Common.InputStatus.MaskingAndRangeReduction:
                    if (status == Common.InputStatus.Masking || status == Common.InputStatus.RangeReduction)
                        return false;
                    break;
            }

            return true;
        }

        /// <summary>
        /// Get the ConfirmedType for current alarm based on area mode and the previous unconfirmed alarm if required.
        /// </summary>
        /// <param name="unconfirmedAlarmSource">The source of an existing unconfirmed alarm, received before the current alarm.</param>
        /// <param name="areaSource">Area from which the alarm has originated</param>
        /// <returns>None, Unconfirmed or Confirmed.</returns>
        public override ConfirmedType GetConfirmedAlarmType(IStatusItem unconfirmedAlarmSource, IStatusItem areaSource)
        {
            if (areaSource == null)
                return ConfirmedType.None;

            AreaStatus areaStatus = areaSource as AreaStatus;
            if (areaStatus == null || confirmedAlarmType == ConfirmedAlarmType.Normal)
                return ConfirmedType.None;

            DeviceStatusAbstractBase deviceStatus = StatusManager.Instance.Devices[ParentDeviceId];
            if (deviceStatus != null)
            {
                if (areaStatus.Mode == AreaScheduleLevel.Disarmed && deviceStatus.CurrentAlarms.HasAny(Offline) == true &&
                    maskedStatus == Common.InputStatus.Trouble)
                {
                    // BS 8243 Annex H.3.1: A confirmed alarm will not be notified when a failure of communication to multiple devices on 
                    //                      a data bus which cannot be identified as a fault (Device Offline), occurs when the system is 
                    //                      in un-set state (area is Disarmed). This input in Trouble state cannot confirm an alarm if its 
                    //                      parent device is Offline and the system is unset.
                    return ConfirmedType.None;
                }
                else if (deviceStatus.CurrentAlarms.Has(EventSourceLatchOrIsolateType.Tamper) == true)
                {
                    // BS 8243 Annex H.3.1-H.3.2: Don't confirm alarm if the parent device is an 8502 and has a Tamper alarm and this input 
                    //                            is in Alarm.
                    if (deviceStatus is Device8502Status)
                        return ConfirmedType.Unconfirmed;
                }
            }

            if (maskedStatus.ContainsAlarm() == false && (maskedStatus.ContainsMasking() == true || maskedStatus.ContainsRangeReduction() == true))
            {
                // BS 8243: See Alan Townsend's email -> Two ‘masked’ detectors, should not generate a confirmed alarm. 
                // See chapter §5.4 - Design and configuration of sequential confirmation I&HASs in BS 8243:2010 document
                return ConfirmedType.None;
            }
            return (this.ConfirmedAlarmType == ConfirmedAlarmType.BS8243Compliant && areaStatus.DisableConfirmedAlarms == true) ? ConfirmedType.Unconfirmed : ConfirmedType.Confirmed;
        }

        /// <summary>
        /// Get operation for the area point list
        /// </summary>
        /// <returns></returns>
        internal AlarmPointOperation EvaluateInputAlarmOperation(InputConfiguration inputConfiguration, AreaScheduleLevel areaMode)
        {
            bool reportInputStateChange;
            bool resetCurrentlyLatched;
            InputForceOperation forcedOperation;
            bool extendEntryDelay;
            bool dummyTerminateEntryDelay;

            return EvaluateInputAlarmOperation(
                inputConfiguration,
                areaMode,
                maskedStatus,
                Common.InputStatus.Unknown,
                IsCurrentlyLatched,
                SuspectPoint,
                Isolated,
                areaHasEntryDelay,
                inputConfiguration.EntryDelayRunningActionType, 
                EntryTimerState.NotRunning,
                false,
                false,
                false,
                out forcedOperation,
                out reportInputStateChange,
                out resetCurrentlyLatched,
                out extendEntryDelay,
                out dummyTerminateEntryDelay);
        }

        /// <summary>
        /// Get operation for masked input status update.
        /// </summary>
        /// <returns></returns>
        public static AlarmPointOperation EvaluateInputAlarmOperation(
            InputConfiguration inputConfiguration,
            AreaScheduleLevel? areaMode,
            Common.InputStatus currentUnmaskedStatus,
            Common.InputStatus previousMaskedStatus,
            bool isCurrentlyLatched,
            bool suspectPoint,
            bool isIsolated,
            bool areaHasEntryDelay,
            EntryDelayRunningActionType entryDelayRunningAction,
            EntryTimerState entryTimerState,
            bool exitTimerRunning,
            bool confirmationTimerRunning,
            bool areaHasConfirmedAlarms,
            out InputForceOperation forcedOperation,
            out bool reportInputStateChange,
            out bool resetCurrentlyLatched,
            out bool extendEntryDelay,
            out bool forceTerminateEntryDelay)
        {
            resetCurrentlyLatched = false;
            reportInputStateChange = false;
            forcedOperation = InputForceOperation.None;
            extendEntryDelay = false;
            AlarmPointOperation resultOperation = AlarmPointOperation.None;
            forceTerminateEntryDelay = false;

            Common.InputStatus newStatus = currentUnmaskedStatus;

            if ((isCurrentlyLatched == true || suspectPoint == true) &&
                (previousMaskedStatus == Common.InputStatus.Secure ||
                (IsUnqualifiedAlarm(previousMaskedStatus) && entryTimerState == EntryTimerState.NotRunning)))
            {
                resetCurrentlyLatched = true;
                isCurrentlyLatched = false;
                suspectPoint = false;
            }

            if (isIsolated)
            {
                newStatus = Common.InputStatus.Secure;
            }
            else if (areaHasConfirmedAlarms == true && inputConfiguration.ConfirmedAlarmType == ConfirmedAlarmType.BS8243Compliant &&
                (inputConfiguration.EntryDelayRunningActionType == EntryDelayRunningActionType.ReportAtConclusionOfEntryDelay ||
                 inputConfiguration.EntryDelayRunningActionType == EntryDelayRunningActionType.ExtendEntryDelayAndReportAtConclusionOfExtendedEntryDelay)
                 && IsUnqualifiedAlarm(previousMaskedStatus) == false && areaMode.HasValue && 
                 ((areaMode.Value == AreaScheduleLevel.Armed && inputConfiguration.ReportPointWhenAreaArmed) ||
                  (areaMode.Value == AreaScheduleLevel.Disarmed && inputConfiguration.ReportPointWhenAreaDisarmed)))
            {
                if (entryTimerState == EntryTimerState.ExtendedEntryTimerRunning)
                    forceTerminateEntryDelay = true;
                newStatus = previousMaskedStatus;
                isCurrentlyLatched = false;        // Setting this here ensures that latched points don't report again.
            }
            else if (suspectPoint == false)
            {
                if (inputConfiguration.NoTamper == true && IsAnyTroubleAlarm(currentUnmaskedStatus))
                    newStatus = Common.InputStatus.Alarm;
                if (inputConfiguration.ReportAlarmAsSelfTestFail == true && newStatus == Common.InputStatus.Alarm)
                    newStatus = Common.InputStatus.SelfTestFail;
            }

            // If a point doesn't belong to an area and neither of the 2 reporting options (report when armed, report when disarmed) are selected
            // then don't report the alarm. This is required for BS8243 to allow an unsetting macro to take place without reporting an alarm.
            // If either / both of the 2 reporting options are selected, the alarm should continue to report.
            if (areaMode.HasValue == false && newStatus == Common.InputStatus.Alarm &&
                inputConfiguration.ReportPointWhenAreaArmed == false && inputConfiguration.ReportPointWhenAreaDisarmed == false)
                newStatus = Common.InputStatus.Secure;

            if (areaMode.HasValue && newStatus == Pacom.Peripheral.Common.InputStatus.Alarm)
            {
                if ((areaMode.Value == AreaScheduleLevel.Armed && inputConfiguration.ReportPointWhenAreaArmed == false) ||
                    (areaMode.Value == AreaScheduleLevel.Disarmed && inputConfiguration.ReportPointWhenAreaDisarmed == false))
                {
                    newStatus = Common.InputStatus.Secure;
                }
            }

            if (suspectPoint && isIsolated == false)
                newStatus = previousMaskedStatus;
            Common.InputStatus unqualifiedStatus = Common.InputStatus.Unknown;
            if (newStatus == Common.InputStatus.Alarm)
                unqualifiedStatus = Common.InputStatus.UnqualifiedAlarm;
            else if (inputConfiguration.ConfirmedAlarmType == ConfirmedAlarmType.BS8243Compliant)
            {
                switch (newStatus)
                {
                    case Common.InputStatus.Trouble: 
                        unqualifiedStatus = Common.InputStatus.UnqualifiedTroubleAlarm; break;
                    case Common.InputStatus.Open: 
                        unqualifiedStatus = Common.InputStatus.UnqualifiedOpenCircuit; break;
                    case Common.InputStatus.Short: 
                        unqualifiedStatus = Common.InputStatus.UnqualifiedShortCircuit; break;
                    case Common.InputStatus.Masking:
                        unqualifiedStatus = Common.InputStatus.UnqualifiedMasking; break;
                    case Common.InputStatus.RangeReduction:
                        unqualifiedStatus = Common.InputStatus.UnqualifiedRangeReduction; break;
                    case Common.InputStatus.MaskingAndRangeReduction:
                        unqualifiedStatus = Common.InputStatus.UnqualifiedMaskingAndRangeReduction; break;
                    case Common.InputStatus.AlarmAndMasking:
                        unqualifiedStatus = Common.InputStatus.UnqualifiedAlarmAndMasking; break;
                    case Common.InputStatus.AlarmAndRangeReduction:
                        unqualifiedStatus = Common.InputStatus.UnqualifiedAlarmAndRangeReduction; break;
                    case Common.InputStatus.AlarmAndMaskingAndRangeReduction:
                        unqualifiedStatus = Common.InputStatus.UnqualifiedAlarmAndMaskingAndRangeReduction; break;
                }
            }
            if ((previousMaskedStatus != newStatus || (suspectPoint == false && isCurrentlyLatched == true)) &&
                (IsUnqualifiedAlarm(unqualifiedStatus)) &&
                suspectPoint == false && areaMode.HasValue && areaMode.Value == AreaScheduleLevel.Armed)
            {
                if (InputConfiguration.IsUnqualifiedAlarmDuringEntryDelay
                        (entryDelayRunningAction, entryTimerState, confirmationTimerRunning, areaHasEntryDelay, out extendEntryDelay) == true ||
                    (entryDelayRunningAction != EntryDelayRunningActionType.ReportImmediately && exitTimerRunning == true))
                {
                    newStatus = unqualifiedStatus;
                }
            }

            if (IsUnqualifiedAlarm(newStatus))
            {
                forcedOperation = InputForceOperation.ForcedToUnqualifiedAlarm;
            }
            else if ((previousMaskedStatus != newStatus && (isCurrentlyLatched == false || isIsolated == true)) ||
                (suspectPoint == false && isCurrentlyLatched == true && (newStatus != Common.InputStatus.Secure && !IsUnqualifiedAlarm(newStatus))))
            {
                if (newStatus == Common.InputStatus.Secure && currentUnmaskedStatus != Common.InputStatus.Secure)
                    forcedOperation = InputForceOperation.ForcedToSecure;
                else if (newStatus == Common.InputStatus.Alarm && currentUnmaskedStatus != Common.InputStatus.Alarm)
                    forcedOperation = InputForceOperation.ForcedToAlarm;
                else if (newStatus == Common.InputStatus.SelfTestFail && currentUnmaskedStatus != Common.InputStatus.SelfTestFail)
                    forcedOperation = InputForceOperation.ForcedToSelfTestFail;

                reportInputStateChange = true;
            }

            if (isIsolated == false && IsUnqualifiedAlarm(newStatus))
                resultOperation = AlarmPointOperation.AddToUnqualified;
            else if ((isCurrentlyLatched == false || isIsolated == true) &&
                (newStatus == Common.InputStatus.Secure || IsUnqualifiedAlarm(newStatus)) &&
                (isIsolated == true || suspectPoint == false))
                resultOperation = AlarmPointOperation.Remove;
            else
                resultOperation = AlarmPointOperation.Add;

            return resultOperation;
        }

        /// <summary>
        /// Indicates that the input is in latched state when this value is true.
        /// Changed to alarm and stays as alarm, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get { return latchedAlarms.Has(EventSourceLatchOrIsolateType.InputAlarms); }
        }

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            return isConfiguredToBeLatched == true;
        }

        /// <summary>
        /// Returns the current latch status for this status item instance and the [latchFlagToCheck]
        /// </summary>
        /// <param name="latchFlagToCheck">The status item laarm flag that needs to be checked for latching</param>
        /// <returns>The latch status for this status item.</returns>
        public override EventSourceLatchStatus GetLatchStatusFor(EventSourceLatchOrIsolateType latchFlagToCheck)
        {
            if (latchedAlarms.Has(latchFlagToCheck) == false)
                return EventSourceLatchStatus.NotLatched;

            if (SuspectPoint)
                return EventSourceLatchStatus.SuspectBehaviour;
            if (isConfiguredToBeLatched)
                return EventSourceLatchStatus.ConfiguredToBeLatched;
            return EventSourceLatchStatus.NotLatched;
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = EventSourceLatchOrIsolateType.None;
                if (maskedStatus != Common.InputStatus.Secure)
                    flags |= EventSourceLatchOrIsolateType.InputAlarms;
                return flags;
            }
        }

        public string StatusAsString(Common.InputStatus status)
        {
            Pacom8003Configuration configuration = ConfigurationManager.Instance.ControllerConfiguration;
            if (configuration == null)
                return "UNKNOWN";

            Common.InputStatus newStatus = status;
            if (IsCurrentlyLatched == false)
            {
                if (noTroubleAlarms == true && IsAnyTroubleAlarm(status))
                    newStatus = Common.InputStatus.Alarm;
                else if (reportAlarmAsSelfTestFail == true && status == Common.InputStatus.Alarm)
                    newStatus = Common.InputStatus.SelfTestFail;
            }
            return configuration.GetInputStatusDescription(newStatus);
        }

        /// <summary>
        /// Get the string representation of the alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] / [ALARM] / [ALARM MASK RANGE]
        /// </summary>
        public override string AlarmsAsString
        {
            get
            {
                Common.InputStatus status = maskedStatus;
                if (status == Common.InputStatus.Secure)
                    status = unmaskedStatus;
                return " " + StatusAsString(status);
            }
        }

        /// <summary>
        /// Get the string representation of the alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public override string IsolatedAlarmsAsString
        {
            get
            {
                if (isolated == true)
                    return " " + StatusAsString(unmaskedStatus);
                return string.Empty;
            }
        }

        /// <summary>
        /// Get the string representation of the latched alarms for this point in format: [ALARM1 .. ALARMN], e.g. [SHORT] or [OFFLINE TAMPER]
        /// </summary>
        public override string LatchedAlarmsAsString
        {
            get
            {
                if (IsCurrentlyLatched == false)
                    return string.Empty;
                return AlarmsAsString;
            }
        }

        public string[] StatusAsStringArray(Common.InputStatus status)
        {
            Pacom8003Configuration configuration = ConfigurationManager.Instance.ControllerConfiguration;
            if (configuration == null)
                return new string[1] { "UNKNOWN" };

            Common.InputStatus newStatus = status;
            if (IsCurrentlyLatched == false)
            {
                if (noTroubleAlarms == true && IsAnyTroubleAlarm(status))
                    newStatus = Common.InputStatus.Alarm;
                else if (reportAlarmAsSelfTestFail == true && status == Common.InputStatus.Alarm)
                    newStatus = Common.InputStatus.SelfTestFail;
            }
            switch (newStatus)
            {
                case Common.InputStatus.Short: return new string[1] { configuration.ShortCircuitEventText };
                case Common.InputStatus.Open: return new string[1] { configuration.OpenCircuitEventText };
                case Common.InputStatus.Trouble: return new string[1] { configuration.TroubleEventText };
                case Common.InputStatus.SelfTestFail: return new string[1] { configuration.SelfTestFailEventText };
                default:
                    List<string> statusList = new List<string>();
                    if (newStatus.ContainsAlarm() == true)
                        statusList.Add(configuration.AlarmText);
                    if (newStatus.ContainsMasking() == true)
                        statusList.Add(configuration.MaskEventText);
                    if (newStatus.ContainsRangeReduction() == true)
                        statusList.Add(configuration.RangeReductionEventText);
                    if (statusList.Count == 0)
                        return new string[1] { configuration.SecureText };
                    return statusList.ToArray();
            }
        }

        /// <summary>
        /// Get the string array representation of the current alarms for this point
        /// </summary>
        public override string[] AlarmsAsStringArray
        {
            get
            {
                Common.InputStatus status = maskedStatus;
                if (status == Common.InputStatus.Secure)
                    status = unmaskedStatus;
                return StatusAsStringArray(status);
            }
        }

        /// <summary>
        /// Get the string array representation of the current alarms for this point
        /// </summary>
        public string[] MaskedAlarmsAsStringArray
        {
            get { return StatusAsStringArray(maskedStatus); }
        }

        /// <summary>
        /// Get the string array representation of the isolated alarms for this point
        /// </summary>
        public override string[] IsolatedAlarmsAsStringArray
        {
            get
            {
                if (isolated == true)
                    return StatusAsStringArray(unmaskedStatus);
                return new string[0];
            }
        }

        /// <summary>
        /// Get the string representation of the latched alarms for this point as an array
        /// </summary>
        public override string[] LatchedAlarmsAsStringArray
        {
            get
            {
                if (IsCurrentlyLatched == false)
                    return new string[0];
                return StatusAsStringArray(maskedStatus);
            }
        }

        /// <summary>
        /// Get display name for this expansion card status item instance without any alarms / isolated alarms
        /// </summary>
        /// <returns>Display Name string.</returns>
        public override string DisplayName
        {
            get
            {
                InputConfiguration inputConfig = ConfigurationManager.Instance.GetInputConfiguration(LogicalId);
                if (inputConfig != null)
                    return string.Format("{0}{1} {2}", ConfigurationManager.Instance.ControllerConfiguration.InputPrefixText, LogicalId, inputConfig.GetName());
                return string.Empty;
            }
        }

        /// <summary>
        /// Get configured to be latched
        /// </summary>
        public bool ConfiguredToBeLatched
        {
            get { return isConfiguredToBeLatched; }
        }

        /// <summary>
        /// Gets True when input should not report trouble alarms
        /// </summary>
        public bool NoTroubleAlarms
        {
            get { return noTroubleAlarms; }
        }

        /// <summary>
        /// Returns True when input reports Alarm as SelfTestFail
        /// </summary>
        public bool ReportAlarmAsSelfTestFail
        {
            get { return reportAlarmAsSelfTestFail; }
        }

        /// <summary>
        /// Get input isolated flag state.
        /// </summary>
        public bool Isolated
        {
            get { return isolated; }
        }

        /// <summary>
        /// Set input isolated flag state.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public bool SetIsolated(bool value, UserAuditInfo userAuditInfo)
        {
            InputConfiguration inputConfig = ConfigurationManager.Instance.GetInputConfiguration(LogicalId);
            if (Enabled == false || inputConfig == null)
                return false;

            bool pendingTimedActionRemoved = StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.DeisolateInputs, LogicalId);

            if (isolated != value)
            {
                Isolating = true;
                if (value)
                {
                    latchedMaskedStatus = Common.InputStatus.Secure;
                    if (IsCurrentlyLatched == true &&
                        (ConfigurationManager.Instance.ControllerConfiguration.KeypadOperationalMode == KeypadOperationalMode.EN50131Grade4) &&
                        (maskedStatus == Common.InputStatus.Open ||
                         maskedStatus == Common.InputStatus.SelfTestFail ||
                         maskedStatus == Common.InputStatus.Short ||
                         maskedStatus == Common.InputStatus.Trouble))
                    {
                        // Save the Latched maskedStatus if Self Test Fail (Fault) alarm or Tamper so we can restore it when
                        // the input point is de-isolated (this is required because any Detector Fault alarm or Tamper alarm can 
                        // only be restored by a Level 3 User (EN 50131-1, §8.3.9, Table 6 - Restoring)
                        latchedMaskedStatus = maskedStatus;
                    }
                    ResetIsCurrentlyLatched();
                    MaskedStatus = Common.InputStatus.Secure;
                    isolated = value;
                    if (inputConfig.AreaId > 0)
                        StatusManager.Instance.Areas[inputConfig.AreaId].AddPointToIsolatedList(this);
                }
                else
                {
                    isolated = value;
                    if (unmaskedStatus == Common.InputStatus.Secure)
                    {
                        // If the stored latchedMaskedStatus is not Secure than we need to restore the MaskedStatus to this value
                        // so a Level 3 User can manually restore it when required. We must not automatically Unlatch a Fault alarm
                        // when deisolating the input during area Disarm in EN-GRADE4 mode of operation (EN 50131-1, §8.3.9, Table 6 - Restoring)
                        MaskedStatus = latchedMaskedStatus;
                    }
                    else
                    {
                        MaskedStatus = unmaskedStatus;
                    }
                    latchedMaskedStatus = Common.InputStatus.Secure;
                    if (inputConfig.AreaId > 0)
                        StatusManager.Instance.Areas[inputConfig.AreaId].RemovePointFromIsolatedList(this);
                }
                Isolating = false;
                StatusManager.Instance.Inputs.TriggerChangedIsolatedStatus(this, value, userAuditInfo);
                StatusManager.Instance.RequestStatusToStorage();
                return true;
            }

            return pendingTimedActionRemoved;
        }

        /// <summary>
        /// Isolate input.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Isolate(UserAuditInfo userAuditInfo)
        {
            SetIsolated(true, userAuditInfo);
        }

        /// <summary>
        /// Deisolate input.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Deisolate(UserAuditInfo userAuditInfo)
        {
            SetIsolated(false, userAuditInfo);
        }

        /// <summary>
        /// Set isolated flag for any input point for a specified duration.
        /// </summary>
        /// <param name="value">True for isolate, False for normal operation.</param>
        /// <param name="bitField">Not Used.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="durationInSeconds">The duration for which the point will be isolated, 0 means that the point will be isolated idefinitely</param>
        /// <returns>True if the point's isolated state was successfully changed, False otherwise.</returns>
        public override bool SetIsolated(bool value, EventSourceLatchOrIsolateType bitField, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            bool result = SetIsolated(value, userAuditInfo);
            if (result == true && value == true && durationInSeconds > 0)
            {
                // A duration is only supported for the 'isolate for a duration' case.
                StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.DeisolateInputs, LogicalId, userAuditInfo, durationInSeconds);
            }
            return result;
        }

        private bool isIntruderDetector(InputCategory inputCategory)
        {
            if (inputCategory == InputCategory.Pir ||
                inputCategory == InputCategory.PirPerimeter ||
                inputCategory == InputCategory.Perimeter ||
                inputCategory == InputCategory.Vibration ||
                inputCategory == InputCategory.Vault ||
                inputCategory == InputCategory.Raid)
                return true;
            return false;
        }

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        public override bool CanIsolate(UserAccessLevel level)
        {
            if (level == UserAccessLevel.AccessLevel3)
                return true;

            if ((isIntruderDetector(inputCategory) == true) &&
                (maskedStatus == Common.InputStatus.SelfTestFail))
                return true;
            if (inputCategory == InputCategory.Tamper)
                return false;
            if (IsCurrentlyLatched == false && noTroubleAlarms == true && IsAnyTroubleAlarm(maskedStatus))
                return true;
            return maskedStatus != Common.InputStatus.SelfTestFail &&
                   maskedStatus != Common.InputStatus.Open &&
                   maskedStatus != Common.InputStatus.Short &&
                   maskedStatus != Common.InputStatus.Trouble;
        }

        /// <summary>
        /// True if this status item can be de-isolated at the specifed access level
        /// </summary>
        public override bool CanDeisolate(UserAccessLevel level)
        {
            if (level == UserAccessLevel.AccessLevel3)
                return true;

            if ((isIntruderDetector(inputCategory) == true) &&
                (unmaskedStatus == Common.InputStatus.SelfTestFail))
                return true;
            if (inputCategory == InputCategory.Tamper)
                return false;
            if (IsCurrentlyLatched == false && noTroubleAlarms == true && IsAnyTroubleAlarm(unmaskedStatus))
                return true;
            return unmaskedStatus != Common.InputStatus.SelfTestFail &&
                   unmaskedStatus != Common.InputStatus.Open &&
                   unmaskedStatus != Common.InputStatus.Short &&
                   unmaskedStatus != Common.InputStatus.Trouble;
        }

        /// <summary>
        /// Get / set the input status analog value. Only used by 8501 devices that send
        /// an analog input state changed command to controller with the input's analog 
        /// value instead of the input's status (secure, alarm, open, short, etc.).
        /// </summary>
        public int AnalogValue
        {
            get { return analogValue; }
            set
            {
                if (Enabled == false)
                    return;
                if (analogValue != value)
                {
                    analogValue = value;
                    unmaskedStatus = Common.InputStatus.Analog;
                    if (isolated == false)
                    {
                        StatusManager.Instance.Inputs.TriggerChangedUnmaskedStatus(this, unmaskedStatus);
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        /// <summary>
        /// Unlatch input. Keep MaskedStatus alarm state if UnmaskedStatus is not Secure.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        /// <returns>True if input was unlatched, False otherwise.</returns>
        public override bool Unlatch(UserAuditInfo userAuditInfo)
        {
            InputConfiguration inputConfig = ConfigurationManager.Instance.GetInputConfiguration(LogicalId);
            if (Enabled == false || inputConfig == null)
                return false;

            if (IsCurrentlyLatched == false)
                return false;

            if (ConfigurationManager.Instance.ControllerConfiguration.KeypadOperationalMode == KeypadOperationalMode.EN50131Grade4)
            {
                // Self Test Fail (Fault) alarm and tamper alarms can only be unlatched by a Level 3 User in EN-GRADE 3/4 operation modes, all other
                // alarms can be unlatched at Level 2, see EN 50131-1, §8.3.9, Table 6 - Restoring.
                bool isEngineer = ConfigurationManager.Instance.Users.HasEngineeringPermissions(userAuditInfo.OriginatingUserId);
                if (isEngineer == false &&
                    (maskedStatus == Common.InputStatus.Open ||
                     maskedStatus == Common.InputStatus.SelfTestFail ||
                     maskedStatus == Common.InputStatus.Short ||
                     maskedStatus == Common.InputStatus.Trouble))
                    return false;
            }

            ResetIsCurrentlyLatched();
            if (UnmaskedStatus == Common.InputStatus.Secure)
            {
                if (IsUnqualifiedAlarm(MaskedStatus))
                {
                    // This is a special case as the point is latched and the alarm has been sent to the head end but because it is an entry delayed point,
                    // it has gone back to an unqualified alarm when it was triggered a subsequent time. As unqualified alarm -> secure doesn't trigger any
                    // restore messages to the head end, we need to force some to go down.
                    MaskedStatus = Common.InputStatus.Secure;
                    StatusManager.Instance.Inputs.TriggerChangedMaskedStatus(this, maskedStatus, Pacom.Peripheral.Common.InputStatus.AlarmAndMaskingAndRangeReduction);
                    StatusManager.Instance.Inputs.TriggerChangedMaskedStatus(this, maskedStatus, Pacom.Peripheral.Common.InputStatus.Open);
                    StatusManager.Instance.Inputs.TriggerChangedMaskedStatus(this, maskedStatus, Pacom.Peripheral.Common.InputStatus.Short);
                    StatusManager.Instance.Inputs.TriggerChangedMaskedStatus(this, maskedStatus, Pacom.Peripheral.Common.InputStatus.Trouble);
                }
                else
                {
                    MaskedStatus = Common.InputStatus.Secure;
                }
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Input [{0}] was [RESTORED].", DisplayName);
                });
            }

            StatusManager.Instance.RequestStatusToStorage();
            return true;
        }

        /// <summary>
        /// Unlatch input alarms if latched. Keep MaskedStatus alarm state if UnmaskedStatus is not Secure.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        /// <param name="options">Latched alarms to unlatch (restore)</param>
        /// <returns>True if the point has been unlatched</returns>
        public override bool Unlatch(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options)
        {
            return Unlatch(userAuditInfo);
        }

        /// <summary>
        /// Check if the current input status is in one of the trouble alarms
        /// </summary>
        /// <param name="status"></param>
        /// <returns></returns>
        public static bool IsAnyTroubleAlarm(Common.InputStatus status)
        {
            return status == Common.InputStatus.Open ||
                   status == Common.InputStatus.Short ||
                   status == Common.InputStatus.Trouble ||
                   status == Common.InputStatus.Masking ||
                   status == Common.InputStatus.RangeReduction ||
                   status == Common.InputStatus.AlarmAndMasking ||
                   status == Common.InputStatus.AlarmAndRangeReduction ||
                   status == Common.InputStatus.MaskingAndRangeReduction ||
                   status == Common.InputStatus.AlarmAndMaskingAndRangeReduction;
        }

        Common.InputStatus previousUnqualifiedAlarm = Common.InputStatus.UnqualifiedAlarm;
        internal void QualifyAlarm()
        {
            Common.InputStatus previousMaskedStatus = maskedStatus;
            switch (previousUnqualifiedAlarm)
            {
                case Common.InputStatus.UnqualifiedTroubleAlarm: 
                    maskedStatus = Common.InputStatus.Trouble; break;
                case Common.InputStatus.UnqualifiedOpenCircuit:
                    maskedStatus = Common.InputStatus.Open; break;
                case Common.InputStatus.UnqualifiedShortCircuit: 
                    maskedStatus = Common.InputStatus.Short; break;
                case Common.InputStatus.UnqualifiedMasking:
                    maskedStatus = Common.InputStatus.Masking; break;
                case Common.InputStatus.UnqualifiedRangeReduction:
                    maskedStatus = Common.InputStatus.RangeReduction; break;
                case Common.InputStatus.UnqualifiedMaskingAndRangeReduction:
                    maskedStatus = Common.InputStatus.MaskingAndRangeReduction; break;
                case Common.InputStatus.UnqualifiedAlarmAndMasking:
                    maskedStatus = Common.InputStatus.AlarmAndMasking; break;
                case Common.InputStatus.UnqualifiedAlarmAndRangeReduction:
                    maskedStatus = Common.InputStatus.AlarmAndRangeReduction; break;
                case Common.InputStatus.UnqualifiedAlarmAndMaskingAndRangeReduction:
                    maskedStatus = Common.InputStatus.AlarmAndMaskingAndRangeReduction; break;
                default: 
                    maskedStatus = Common.InputStatus.Alarm; break;
            }
            InputConfiguration inputConfig = ConfigurationManager.Instance.GetInputConfiguration(LogicalId);
            if (inputConfig != null)
            {
                AreaStatus areaStatus = StatusManager.Instance.Areas[inputConfig.AreaId];
                if (areaStatus != null)
                    areaStatus.AddPointToArmedList(this);
            }
            StatusManager.Instance.Inputs.TriggerChangedMaskedStatus(this, maskedStatus, previousMaskedStatus);
            StatusManager.Instance.RequestStatusToStorage();
        }

        internal void RestoreQualifiedAlarm(Pacom.Peripheral.Common.InputStatus newStatus)
        {
            Pacom.Peripheral.Common.InputStatus previousMaskedStatus = maskedStatus;
            maskedStatus = newStatus;
            InputConfiguration inputConfig = ConfigurationManager.Instance.GetInputConfiguration(LogicalId);
            if (inputConfig != null)
            {
                AreaStatus areaStatus = StatusManager.Instance.Areas[inputConfig.AreaId];
                if (areaStatus != null)
                    areaStatus.RemovePointFromArmedList(this);
            }
            StatusManager.Instance.Inputs.TriggerChangedMaskedStatus(this, maskedStatus, previousMaskedStatus);
            StatusManager.Instance.RequestStatusToStorage();
        }

        public override string ToString()
        {
            return String.Format("Input Status [{0}]", this.LogicalId);
        }

        public bool AutomaticIntegrityCheckTriggered { get; set; }
        public DateTime LastAutomaticIntegrityCheckTriggeredTime { get; set; }
        public bool TestWasSuccessful { get; set; }
        public bool TestCompleted { get; set; }
        public bool TestFailed { get; set; }
    }
}
