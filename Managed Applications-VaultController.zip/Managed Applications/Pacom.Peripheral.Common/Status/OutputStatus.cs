﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using System.Threading;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status;

namespace Pacom.Peripheral.Common.Status
{
    public sealed class OutputStatus : StatusBase<OutputStatusList>
    {
        private OutputState requestedState = OutputState.Inactive;

        public OutputState RequestedState 
        {
            get { return requestedState; }
        }

        private bool isolated = false;

        public bool Isolated 
        {
            get { return isolated; }
        }

        public OutputStatus(ConfigurationBase configuration, OutputStatusList parent, OutputStatusStorage previousStatus) :
            base(configuration, parent)
        {
            requestedState = OutputState.Inactive;
            isolated = false;

            if (previousStatus == null || this.Enabled == false)
                return;

            isolated = previousStatus.Isolated;

            RefreshAfterConfigurationChange();
        }

        internal void RefreshAfterConfigurationChange()
        {
            if (isolated)
            {
                OutputConfiguration outputConfig = ConfigurationManager.Instance.GetOutputConfiguration(LogicalId);
                if (outputConfig != null && outputConfig.AreaId > 0)
                {
                    AreaStatus areaStatus = StatusManager.Instance.Areas[outputConfig.AreaId];
                    if (areaStatus != null)
                        areaStatus.AddPointToIsolatedList(this);
                }
            }
        }

        public override StatusItemType ItemType
        {
            get { return StatusItemType.OutputStatus; }
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            OutputStatusStorage statusStorage = new OutputStatusStorage();
            if (statusStorage != null)
            {
                statusStorage.LogicalId = LogicalId;
                statusStorage.ParentDeviceId = ParentDeviceId;
                statusStorage.Isolated = Isolated;
            }
            return statusStorage;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            OutputEventState outputState = new OutputEventState();
            outputState.Id = LogicalId;
            outputState.Isolate = Isolated;
            outputState.Active = RequestedState == OutputState.Active;
            return outputState;
        }

        /// <summary>
        /// Get display name for this output status item instance without any alarms / isolated alarms
        /// </summary>
        /// <returns>Display Name string.</returns>
        public override string DisplayName
        {
            get
            {
                OutputConfiguration outputConfig = ConfigurationManager.Instance.GetOutputConfiguration(LogicalId);
                if (outputConfig != null)
                    return string.Format("{0}{1} {2}", ConfigurationManager.Instance.ControllerConfiguration.OutputPrefixText, LogicalId, outputConfig.GetName());
                return string.Empty;
            }
        }

        /// <summary>
        /// Get the string representation of this output's state in format: ACTIVE->ON / INACTIVE->OFF
        /// </summary>
        public override string AlarmsAsString
        {
            get 
            {
                string outputStateString = " ";
                if (RequestedState == OutputState.Active)
                    outputStateString += ConfigurationManager.Instance.ControllerConfiguration.OnText;
                else
                    outputStateString += ConfigurationManager.Instance.ControllerConfiguration.OffText;
                return outputStateString;
            }
        }

        /// <summary>
        /// Get the string representation of the isolated alarms for this output status
        /// </summary>
        public override string IsolatedAlarmsAsString
        {
            get { return isolated == true ? " " + ConfigurationManager.Instance.ControllerConfiguration.IsolatedText : string.Empty; }
        }

        /// <summary>
        /// Set output isolate flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <returns>True when operation is executed succesfully.</returns>
        public bool SetIsolated(bool isolate, UserAuditInfo userAuditInfo)
        {
            OutputConfiguration outputConfig = ConfigurationManager.Instance.GetOutputConfiguration(LogicalId);

            bool pendingTimedActionRemoved = false;
            if (Enabled == true && outputConfig != null)
            {
                pendingTimedActionRemoved = StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.DeisolateOutputs, LogicalId);

                if (isolated != isolate)
                {
                    StatusManager.Instance.Outputs.TriggerChangedIsolatedStatus(this, isolate, userAuditInfo);
                    // On isolate we have to deactivate the output.
                    if (isolate == true)
                    {
                        SetRequestedState(false, userAuditInfo);
                        if (outputConfig.AreaId > 0)
                            StatusManager.Instance.Areas[outputConfig.AreaId].AddPointToIsolatedList(this);
                    }
                    else
                    {
                        if (outputConfig.AreaId > 0)
                            StatusManager.Instance.Areas[outputConfig.AreaId].RemovePointFromIsolatedList(this);
                    }
                    isolated = isolate;
                    StatusManager.Instance.RequestStatusToStorage();
                    return true;
                }
            }
            return pendingTimedActionRemoved;
        }

        /// <summary>
        /// Isolate output.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Isolate(UserAuditInfo userAuditInfo)
        {
            SetIsolated(true, userAuditInfo);
        }

        /// <summary>
        /// Deisolate output.
        /// </summary>
        /// <param name="userId"></param>
        public override void Deisolate(UserAuditInfo userAuditInfo)
        {
            SetIsolated(false, userAuditInfo);
        }

        /// <summary>
        /// Set isolated flag for any output point for a specified duration.
        /// </summary>
        /// <param name="value">True for isolate, false for normal operation.</param>
        /// <param name="bitField">Not Used.</param>
        /// <param name="userId">The user who is performing the action.</param>
        /// <param name="durationInSeconds">The duration for which the point will be isolated, 0 means that the point will be isolated idefinitely</param>
        /// <returns>True if the point's isolated state was successfully changed, False otherwise.</returns>
        public override bool SetIsolated(bool value, EventSourceLatchOrIsolateType bitField, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            bool result = SetIsolated(value, userAuditInfo);
            if (result == true && value == true && durationInSeconds > 0)
            {
                // A duration is only supported for the 'isolate for a duration' case.
                StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.DeisolateOutputs, LogicalId, userAuditInfo, durationInSeconds);
            }
            return result;
        }

        /// <summary>
        /// Set output state
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the activate / deactivate output command.</param>
        /// <param name="state">True to activate output</param>
        public bool SetRequestedState(bool state, UserAuditInfo userAuditInfo)
        {
            bool result = false;
            OutputConfiguration outputConfig = ConfigurationManager.Instance.GetOutputConfiguration(LogicalId);

            bool pendingTimedActionRemoved = false;
            if (Enabled == true && outputConfig != null && isolated == false)
            {
                pendingTimedActionRemoved = StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.ActivateOutputs, LogicalId);
                pendingTimedActionRemoved |= StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.DeactivateOutputs, LogicalId);

                if ((RequestedState == OutputState.Active && state == true) || (RequestedState == OutputState.Inactive && state == false))
                    return pendingTimedActionRemoved;

                OutputState stateBeingRequested;
                if (state == true)
                    stateBeingRequested = OutputState.Active;
                else
                    stateBeingRequested = OutputState.Inactive;
                if (stateBeingRequested != requestedState)
                {
                    requestedState = stateBeingRequested;
                    StatusManager.Instance.Outputs.TriggerChangedActiveStatus(this, requestedState == OutputState.Active, userAuditInfo);
                    StatusManager.Instance.Outputs.NotifyOutputChange(this);
                    StatusManager.Instance.RequestStatusToStorage();
                }
                result = true;
            }
            return (result | pendingTimedActionRemoved);
        }

        /// <summary>
        /// Set output state for a single output for a specified duration.
        /// Use the status list implementation if there is more than 1 output set the state for. 
        /// </summary>
        /// <param name="state">True to activate the output or false to deactivate it.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <returns></returns>
        public bool SetRequestedState(bool state, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            bool result = SetRequestedState(state, userAuditInfo);
            if (result == true && durationInSeconds > 0)
            {
                StatusManagerTimedActions activateDeactivate = state == true ? StatusManagerTimedActions.DeactivateOutputs : StatusManagerTimedActions.ActivateOutputs;
                StatusManager.Instance.CreateTimedAction(activateDeactivate, LogicalId, userAuditInfo, durationInSeconds);
            }
            return result;
        }
        
        public override string ToString()
        {
            return String.Format("Output Status [{0}]", this.LogicalId);
        }
    }
}
