﻿using System;
using System.Collections.Generic;
using Pacom.Events.EventsCommon;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Serialization.Formatters.Asn1;
using System.IO;
using Pacom.Peripheral.Common.Utils;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Core.Contracts.Status;
using Pacom.Peripheral.Common.LcdKeypadStateMachine;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Collection of all device statuses with utility functions
    /// </summary>
    public class DeviceStatusList : StatusListBase<DeviceStatusAbstractBase, DeviceStatusList>
    {
        /// <summary>
        /// Pacom Device Loop Devices       -> Will be added to this agent when the controller restarts or when the configuration has changed.
        ///                                 -> Will provide delayed Offline reporting on controller restart / configuration change
        /// </summary>
        protected SuspectedStatusNodesAgent deviceOnlineStatusUpdateAgent = null;

        /// <summary>
        /// Inovonics EchoStream Devices    -> Add any Inovonics devices to this agent when the controller is restarted or when the configuration has changed.
        ///                                 -> Will provide delayed Offline reporting on controller restart / configuration change
        /// </summary>
        protected DelayedInovonicsStatusNodesUpdateAgent inovonicsDeviceOnlineStatusUpdateAgent = null;

        /// <summary>
        /// Delayed Power Fail reporting agent for all devices that support AC supply status reporting (controller, 8303 power supply, 8501 
        /// and Inovonics High-Power repeaters).
        /// </summary>
        protected PowerFailReportingAgent powerFailReportingDevices = null;

        /// <summary>
        /// Pacom device loop devices suspectred Offline
        /// </summary>
        private SuspectedStatusNodesAgent suspectedOfflineDevices = null;

        internal DeviceStatusList()
            : base()
        {
            // Used to delay Masked Offline by 60 seconds when device goes offline
            // (allows 8603 / 8501 to restart after a firmware download without going offline)
            suspectedOfflineDevices = new SuspectedStatusNodesAgent();
            suspectedOfflineDevices.CustomAction = suspectedOfflineDevicesCustomAction;

            // Used to delay AC FAIL by PowerFailReportingDelay
            powerFailReportingDevices = new PowerFailReportingAgent();
            powerFailReportingDevices.CustomAction = powerFailReportingDevicesCustomAction;

            // Used to delay Masked Offline by 5 minutes on restart / configuration change
            deviceOnlineStatusUpdateAgent = new DelayedStatusNodesUpdateAgent();
            deviceOnlineStatusUpdateAgent.CustomAction = suspectedOfflineDevicesCustomAction;

            // Used to delay Masked Offline by SupervisionWindow on restart / configuration change
            inovonicsDeviceOnlineStatusUpdateAgent = new DelayedInovonicsStatusNodesUpdateAgent();
            inovonicsDeviceOnlineStatusUpdateAgent.CustomAction = suspectedOfflineDevicesCustomAction;
        }

        /// <summary>
        /// Triggered when any device Masked Online status has changed (includes Inovonics one-way device / high-power repeater or the serial receiver).
        /// </summary>
        public event EventHandler<DeviceOnlineOfflineEventArgs> DeviceMaskedOnlineStatusChanged = null;

        /// <summary>
        /// Triggered when the tamper status of any Inovonics device changes.
        /// </summary>
        public event EventHandler<TamperChangedStatusEventArgs> TamperChangedStatus = null;

        /// <summary>
        /// Triggered when the listen-in device establish/hangup call
        /// </summary>
        public event EventHandler<ListenInDeviceStatusEventArgs> ListenInDeviceStatus = null;

        /// <summary>
        /// Triggered when the isolated flag of any of the devices changes.
        /// </summary>
        public event EventHandler<StatusManagerDeviceChangedIsolatedEventArgs> ChangedIsolatedStatus = null;

        /// <summary>
        /// Triggered for any device that has an internal battery when the battery low status changes (including Inovonics one-way device / high-popwer repeater).
        /// </summary>
        public event EventHandler<ItemStatusChangedEventArgs> InternalBatteryLowChanged = null;

        /// <summary>
        /// Triggered when the power supply status of any of the power supply / controller devices changes.
        /// </summary>
        public event EventHandler<PowerSupplyChangedPowerStateEventArgs> PowerSupplyPowerStateChangedStatus = null;

        /// <summary>
        /// Triggered when the power supply status of any of the power supply / controller devices changes.
        /// </summary>
        public event EventHandler<PowerSupplyChangedBatteryStateEventArgs> PowerSupplyBatteryStateChangedStatus = null;

        /// <summary>
        /// Triggered when the power supply status of any of the power supply / controller devices changes.
        /// </summary>
        public event EventHandler<PowerSupplyChangedBatteryChargerStateEventArgs> PowerSupplyBatteryChargerStateChangedStatus = null;

        /// <summary>
        /// Triggered when any of the devices changed its alarm state: Online / Tamper / Fuse Fail / Temperature Fail / etc.
        /// </summary>
        public event EventHandler<DeviceAlarmChangedStateEventArgs> DeviceChangedAlarmState = null;
        
        /// <summary>
        /// Triggered when the power supply battery pre-warning event needs to be sent.
        /// </summary>
        public event EventHandler PowerSupplyBatteryPreWarning = null;

        /// <summary>
        /// Triggered when the power supply fuse state changes.
        /// </summary>
        public event EventHandler<ItemStatusChangedEventArgs> FuseFailed = null;

        /// <summary>
        /// Triggered when a power supply device's temperature goes out of allowed range. 
        /// </summary>
        public event EventHandler<ItemStatusChangedEventArgs> PowerSupplyTemperatureFail = null;

        /// <summary>
        /// Triggered when a power supply battery test is about to end.
        /// </summary>
        public event EventHandler<PowerSupplyEventArgs> PowerSupplyBatteryTestEnd = null;

        /// <summary>
        /// Triggered when a power supply battery test is about to start.
        /// </summary>
        public event EventHandler<PowerSupplyEventArgs> PowerSupplyBatteryTestStart = null;

        /// <summary>
        /// Triggered when a power supply battery test has failed.
        /// </summary>
        public event EventHandler<PowerSupplyBatteryTestFailEventArgs> PowerSupplyBatteryTestFail = null;

        /// <summary>
        /// Triggered when the keypad user is locked out.
        /// </summary>
        public event EventHandler<ItemStatusChangedEventArgs> OnKeypadUserLockedOutChangedStatus = null;

        public event EventHandler<ItemStatusAreaChangedEventArgs> KeypadTooManyInvalidLogonAttempts = null;
        /// <summary>
        /// Triggered when the keypad user logs in with a valid User Id and the duress PIN.
        /// </summary>
        public event EventHandler<DeviceUserIdEventArgs> OnKeypadUserLoginDuressPin = null;

        /// <summary>
        /// Triggered when an invalid User ID / PIN is entered on a 8101 keypad.
        /// </summary>
        public event EventHandler<DeviceUserIdEventArgs> ReportInvalidUserIdPin = null;

        /// <summary>
        /// Triggered when out of schedule user logon is entered on a 8101 keypad.
        /// </summary>
        public event EventHandler<DeviceUserIdEventArgs> ReportUserOutOfSchedule = null;

        /// <summary>
        /// Triggered when an Engineer User Logs On into a keypad
        /// </summary>
        public event EventHandler<EngineerLogOnEventArgs> EngineerLogOn = null;

        /// <summary>
        /// Triggered when a device substitution is detected
        /// </summary>
        public event EventHandler<DeviceSubstitutionEventArgs> DeviceSubstitutionDetected = null;

        /// <summary>
        /// Triggered when an Inovonics one-way Smoke / Heat Detector requires cleanup.
        /// </summary>
        public event EventHandler<ItemStatusChangedEventArgs> ReceiverCleanRequiredChanged = null;

        /// <summary>
        /// Triggered when the Inovonics Serial Receiver / High-Power Repeater is jammed.
        /// </summary>
        public event EventHandler<ItemStatusChangedEventArgs> ReceiverJammedChanged = null;

        public event EventHandler<GraphicsKeypadBitmapLoadingEventArgs> GraphicsKeypadBitmapLoading = null;

#if INOVONICSTEMPERATUREDEMO
        /// <summary>
        /// Triggered when the Inovonics Analogue changes value.
        /// </summary>
        public event EventHandler<AnalogueInputChangedStateEventArgs> AnalogueInputChangedState = null;
#endif
        /// <summary>
        /// Trigger device Online state changed.
        /// </summary>
        /// <param name="deviceStatus">The device for which the online status has changed.</param>
        internal void DeviceOnlineStatusChanged(IDeviceStatusBase deviceStatus)
        {
            if (deviceStatus.Online == true)
            {
                if (deviceStatus.IsInovonicsDevice == false)
                {
                    // Remove device from suspected offline device list when device goes online
                    suspectedOfflineDevices.RemoveStatusNode(deviceStatus.LogicalId);
                    deviceOnlineStatusUpdateAgent.RemoveStatusNode(deviceStatus.LogicalId);
                }
                else
                {
                    // Remove device from delayed offline device list when device goes online (when controller restarts or configuration changes)
                    inovonicsDeviceOnlineStatusUpdateAgent.RemoveStatusNode(deviceStatus.LogicalId);
                }
                // Reschedule the timer for device status and information update. When the timer expires the device status and information will
                // be uploaded to SM
                if (StatusManager.Instance.StatusUpdateAgent != null)
                {
                    StatusManager.Instance.StatusUpdateAgent.RescheduleTimer();
                }
                // Skip - Inovonics devices don't have any outputs
                if (deviceStatus.IsInovonicsDevice == false)
                {
                    // Set device outputs
                    StatusManager.Instance.Outputs.NotifyDeviceLoopOutputChange(deviceStatus.LogicalId);
                }
            }
        }

        /// <summary>
        /// Remove Inovonics device from delayed Offline list if found
        /// </summary>
        /// <param name="logicalId">Device logical Id</param>
        internal void RemoveInovonicsDeviceFromDelayedOfflineList(int logicalId)
        {
            inovonicsDeviceOnlineStatusUpdateAgent.RemoveStatusNode(logicalId);
        }

        private void suspectedOfflineDevicesCustomAction(int[] expiredNodes)
        {
            foreach (int logicalId in expiredNodes)
            {
                IDeviceStatusBase deviceStatus = this[logicalId];
                if (deviceStatus != null)
                {
                    deviceStatus.NotifyDeviceOffline();
                }
            }
        }

        internal void TriggerDeviceSuspectedOffline(DeviceStatusBase deviceStatus)
        {
            suspectedOfflineDevices.AddStatusNode(deviceStatus.LogicalId, true);
        }

        /// <summary>
        /// Called after the configuration is ready but after the lists are repopulated.
        /// </summary>
        /// <param name="controllerRestarted">True if controller was restarted</param>
        internal void AfterStatusUpdate()
        {
            // Re-initialize the suspected Offline devices agent initial time and poll period
            suspectedOfflineDevices.SetInitialTimeAndPollPeriod();

            // Re-initialize the devices Online / Offline agent initial time and poll period. 
            // For Pacom Devices        -> handles controller restarts / configuration changes
            deviceOnlineStatusUpdateAgent.SetInitialTimeAndPollPeriod();

            // Re-initialize the devices Online / Offline agent initial time and poll period. 
            // For Inovonics Devices    -> handles one-way device Offline
            inovonicsDeviceOnlineStatusUpdateAgent.SetInitialTimeAndPollPeriod();

            // Set initial time and poll period for handling AC Fail reporting for all devices that
            // can report AC Fail (including the Inovonics High-Power Repeaters).
            powerFailReportingDevices.SetInitialTimeAndPollPeriod();


            // Add to the list
            List<int> devicesToAdd = new List<int>();
            foreach (var device in this.Items)
            {
                if (device.Enabled == false || device.IsInovonicsDevice == true)
                    continue;
                DeviceLoopDeviceStatus deviceStatus = device as DeviceLoopDeviceStatus;
                if (deviceStatus != null && deviceStatus.Online == false && device.MaskedOnline == true)
                {
                    devicesToAdd.Add(device.LogicalId);
                }
            }
            if (devicesToAdd.Count > 0)
            {
                deviceOnlineStatusUpdateAgent.AddStatusNodes(devicesToAdd.ToArray());
            }

            devicesToAdd.Clear();
            foreach (var device in this.Items)
            {
                if (device.Enabled == false || device.IsInovonicsDevice == false || device.Online == true || device.MaskedOnline == false)
                    continue;
                devicesToAdd.Add(device.LogicalId);
            }
            if (devicesToAdd.Count > 0)
            {
                inovonicsDeviceOnlineStatusUpdateAgent.AddStatusNodes(devicesToAdd.ToArray());
            }
        }

        /// <summary>
        /// Check if the device is restarting, allow for device to come online in 5 min. If the grace period expires without the device coming online
        /// the device will report offline.
        /// </summary>
        /// <param name="logicalId">Device logical Id.</param>
        /// <returns>True if the device is still in the grace period, False otherwise.</returns>
        public bool DeviceRestarting(int logicalId)
        {
            SuspectedStatusNodeDetails[] nodes = null;
            IDeviceStatusBase deviceStatus = this[logicalId];
            if (deviceStatus == null || logicalId == ConfigurationManager.Instance.ControllerConfiguration.Id)
                return false;

            if (deviceStatus.IsInovonicsDevice == false)
            {
                nodes = deviceOnlineStatusUpdateAgent.Nodes;
                if (nodes.Length > 0)
                {
                    return nodes.FirstOrDefault(node => node.LogicalId == logicalId) != null;
                }
            }

            nodes = inovonicsDeviceOnlineStatusUpdateAgent.Nodes;
            if (nodes.Length > 0)
            {
                return nodes.FirstOrDefault(node => node.LogicalId == logicalId) != null;
            }
            return false;
        }

        #region Trigger Event Handlers

        /// <summary>
        /// Trigger device power supply status changed event handler for all devices that implement IDevicePowerSupplyStatus interface:
        /// e.g. 8303 FirePower power supply, 8003 controller, 8501 IO device, Inovonics High-Power Repeater, etc.
        /// </summary>
        public void TriggerPowerSupplyChangedStatus(IDevicePowerSupplyStatus powerSupplyDeviceStatus, PowerFailState previousMaskedState)
        {
            if (powerSupplyDeviceStatus == null || PowerSupplyPowerStateChangedStatus == null)
                return;

            PowerSupplyPowerStateChangedStatus(powerSupplyDeviceStatus, new PowerSupplyChangedPowerStateEventArgs(powerSupplyDeviceStatus.LogicalId, powerSupplyDeviceStatus.MaskedPowerState, previousMaskedState));
            TriggerDeviceChangedAlarmState((IDeviceStatusBase)powerSupplyDeviceStatus);
        }

        /// <summary>
        /// Trigger device power supply status changed event handler for all devices that implement IDevicePowerSupplyStatus interface:
        /// e.g. 8303 FirePower power supply, 8003 controller, 8501 IO device, Inovonics High-Power Repeater, etc.
        /// </summary>
        public void TriggerPowerSupplyChangedStatus(IDevicePowerSupplyStatus powerSupplyDeviceStatus, BatteryFailState previousMaskedState)
        {
            if (powerSupplyDeviceStatus == null || PowerSupplyBatteryStateChangedStatus == null)
                return;

            PowerSupplyBatteryStateChangedStatus(powerSupplyDeviceStatus, new PowerSupplyChangedBatteryStateEventArgs(powerSupplyDeviceStatus.LogicalId, powerSupplyDeviceStatus.MaskedBatteryState, previousMaskedState));
            TriggerDeviceChangedAlarmState((IDeviceStatusBase)powerSupplyDeviceStatus);
        }

        /// <summary>
        /// Trigger device power supply status changed event handler for all devices that implement IDevicePowerSupplyStatus interface:
        /// e.g. 8303 FirePower power supply, 8003 controller, 8501 IO device, Inovonics High-Power Repeater, etc.
        /// </summary>
        public void TriggerPowerSupplyChangedStatus(IDevicePowerSupplyStatus powerSupplyDeviceStatus, bool previousMaskedBatteryChargerFailed)
        {
            if (powerSupplyDeviceStatus == null || PowerSupplyBatteryChargerStateChangedStatus == null)
                return;

            PowerSupplyBatteryChargerStateChangedStatus(powerSupplyDeviceStatus, new PowerSupplyChangedBatteryChargerStateEventArgs(powerSupplyDeviceStatus.LogicalId, powerSupplyDeviceStatus.MaskedBatteryChargerFailed, previousMaskedBatteryChargerFailed));
            TriggerDeviceChangedAlarmState((IDeviceStatusBase)powerSupplyDeviceStatus);
        }

        public void StartACFailDelay(int logicalId)
        {
            // New AC fail event. Save the device id so we can send the event if required when the delay expires.
            powerFailReportingDevices.AddStatusNode(logicalId);
        }

        public void StopACFailDelay(int logicalId)
        {
            // Flag not set anymore. Remove device.
            powerFailReportingDevices.RemoveStatusNode(logicalId);
        }

        private void powerFailReportingDevicesCustomAction(int[] expiredNodes)
        {
            foreach (int logicalId in expiredNodes)
            {
                IDevicePowerSupplyStatus powerDeviceStatus = null;
                // The controller needs special attention
                if (logicalId == StatusManager.Instance.Controller.LogicalId)
                {
                    if (StatusManager.Instance.Controller.UseStatusPinForPowerSupplyStatus == true)
                    {
                        // For Controller report AC Fail only if the Status Pin is used.
                        powerDeviceStatus = StatusManager.Instance.Controller;
                    }
                }
                else
                    powerDeviceStatus = this[logicalId] as IDevicePowerSupplyStatus;
                if (powerDeviceStatus != null)
                    powerDeviceStatus.SetMaskedPowerState(PowerFailState.Fail, true);
            }
        }

        /// <summary>
        /// Trigger device Masked Online state changed.
        /// </summary>
        /// <param name="deviceStatus">The device for which the masked online status has changed.</param>
        public void TriggerDeviceMaskedOnlineStatusChanged(IDeviceStatusBase deviceStatus)
        {
            // Trigger masked online status changed event
            if (DeviceMaskedOnlineStatusChanged != null)
            {
                DeviceMaskedOnlineStatusChanged(deviceStatus, new DeviceOnlineOfflineEventArgs(deviceStatus.LogicalId, deviceStatus.MaskedOnline == false));
            }
            TriggerDeviceChangedAlarmState(deviceStatus);
        }

        /// <summary>
        /// Trigger when device alarm status has changed
        /// </summary>
        /// <param name="deviceStatus"></param>
        public void TriggerDeviceChangedAlarmState(IDeviceStatusBase deviceStatus)
        {
            if (DeviceChangedAlarmState != null)
            {
                DeviceChangedAlarmState(this, new DeviceAlarmChangedStateEventArgs(deviceStatus));
            }
        }

        /// <summary>
        /// Trigger tamper changed status event handler
        /// </summary>
        /// <param name="deviceStatus">The device for which the tamper status has changed.</param>
        /// <param name="previousTamperActive">Previous TamperActive status.</param>
        public void TriggerChangedMaskedTamperStatus(IDeviceStatusBase deviceStatus, bool previousMaskedTamperActive)
        {
            if (TamperChangedStatus != null)
            {
                TamperChangedStatus(deviceStatus, new TamperChangedStatusEventArgs(deviceStatus, previousMaskedTamperActive));
            }
            TriggerDeviceChangedAlarmState(deviceStatus);
        }

        public void TriggerListenInDeviceStatus(int logicalDeviceId, ListenInDeviceConnectStatus connectStatus, UserAuditInfo userInfo)
        {
            if (ListenInDeviceStatus != null)
            {
                ListenInDeviceStatus(this, new ListenInDeviceStatusEventArgs(logicalDeviceId, connectStatus, userInfo));
            }
        }

        /// <summary>
        /// Triggered when device isolated status has changed
        /// </summary>
        /// <param name="deviceStatus">The devices status instance that has changed.</param>
        /// <param name="isolated">The new value of the device isolated status.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public void TriggerChangedIsolatedStatus(IDeviceStatusBase deviceStatus, EventSourceLatchOrIsolateType isolatedAlarms,
                                                 EventSourceLatchOrIsolateType previousIsolatedAlarms, UserAuditInfo userAuditInfo)
        {
            if (ChangedIsolatedStatus != null)
            {
                ChangedIsolatedStatus(this, new StatusManagerDeviceChangedIsolatedEventArgs(deviceStatus, isolatedAlarms, previousIsolatedAlarms, userAuditInfo));
            }
            TriggerDeviceChangedAlarmState(null);
        }

        /// <summary>
        /// Trigger one-way device / high-power repeater low battery status changed event handler
        /// </summary>
        /// <param name="deviceStatus">Inovonics device status.</param>
        public void TriggerInternalBatteryLowChangedStatus(IDeviceStatus deviceStatus)
        {
            if (InternalBatteryLowChanged != null)
            {
                InternalBatteryLowChanged(deviceStatus, new ItemStatusChangedEventArgs(deviceStatus.LogicalId, deviceStatus.MaskedInternalBatteryLow));
            }
            TriggerDeviceChangedAlarmState(deviceStatus);
        }

        /// <summary>
        /// Triggered when device substitution is detected.
        /// </summary>
        /// <param name="deviceStatus"></param>
        public void TriggerDeviceSubstitution(IDeviceStatusBase deviceStatus, bool restore)
        {
            // Send event to expression manager.
            MacroControl.Instance.EnqueueDeviceSubstitution(deviceStatus.LogicalId);

            // Notify other subsystems via event
            if (DeviceSubstitutionDetected != null)
            {
                DeviceSubstitutionDetected(deviceStatus, new DeviceSubstitutionEventArgs(deviceStatus.LogicalId, restore));
            }
            TriggerDeviceChangedAlarmState(deviceStatus);
        }

        /// <summary>
        /// Trigger fuse failed / fuse restored event
        /// </summary>
        /// <param name="deviceStatus">Device that generated the event.</param>
        /// <param name="fuseFailed">Fuse failed = TRUE / fuse restored = FALSE</param>
        internal void TriggerFuseFailed(IDeviceStatusBase deviceStatus, bool fuseFailed)
        {
            if (FuseFailed != null)
            {
                FuseFailed(deviceStatus, new ItemStatusChangedEventArgs(deviceStatus.LogicalId, fuseFailed));
            }
            TriggerDeviceChangedAlarmState(deviceStatus);
        }

        /// <summary>
        /// Trigger power supply / controller battery pre-warning event
        /// </summary>
        /// <param name="deviceStatus">Power supply / controller status instance.</param>
        internal void TriggerPowerSupplyBatteryPreWarningEvent(DeviceStatusBase deviceStatus)
        {
            if (PowerSupplyBatteryPreWarning != null)
            {
                // Signal the front end that the device power supply status has changed
                PowerSupplyBatteryPreWarning(deviceStatus, new EventArgs());
            }
        }

        /// <summary>
        /// Trigger device temperature out of range (8303 power supply)
        /// </summary>
        /// <param name="deviceStatus">Device Status instance</param>
        public void TriggerTemperatureFailEvent(IDeviceStatusBase deviceStatus, bool failed)
        {
            if (PowerSupplyTemperatureFail != null)
            {
                PowerSupplyTemperatureFail(deviceStatus, new ItemStatusChangedEventArgs(deviceStatus.LogicalId, failed));
            }
            TriggerDeviceChangedAlarmState(deviceStatus);
        }

        /// <summary>
        /// Trigger power supply battery test end.
        /// </summary>
        /// <param name="LogicalDeviceId">Power supply device logical id.</param>
        public void TriggerBatteryTestEndEvent(int logicalDeviceId)
        {
            if (PowerSupplyBatteryTestEnd != null)
            {
                PowerSupplyBatteryTestEnd(this, new PowerSupplyEventArgs(logicalDeviceId));
            }
            IDeviceLocalPowerSupplyStatus powerSupply = this[logicalDeviceId] as IDeviceLocalPowerSupplyStatus;
            if (powerSupply != null)
            {
                powerSupply.BatteryTestInProgress = false;
            }
        }

        /// <summary>
        /// Trigger power supply battery test start.
        /// </summary>
        /// <param name="LogicalDeviceId">Power supply device logical id.</param>
        public void TriggerBatteryTestStartEvent(int logicalDeviceId)
        {
            if (PowerSupplyBatteryTestStart != null)
            {
                PowerSupplyBatteryTestStart(this, new PowerSupplyEventArgs(logicalDeviceId));
            }
            IDeviceLocalPowerSupplyStatus powerSupply = this[logicalDeviceId] as IDeviceLocalPowerSupplyStatus;
            if (powerSupply != null)
            {
                powerSupply.BatteryTestInProgress = true;
            }
        }

        /// <summary>
        /// Trigger power supply battery test fail.
        /// </summary>
        /// <param name="LogicalDeviceId">Power supply device logical id.</param>
        /// <param name="powerSupplyStatus">The current unmasked status of the power supply.</param>
        /// <param name="acFail">True if the mains power is not attached to the device and it would therefore be inappropriate to test the battery.</param>
        /// <param name="invalidDuration">True if the specified duration is out of bounds.</param>
        public void TriggerBatteryTestFailEvent(int logicalDeviceId, PowerFailState powerState, bool batteryChargerFailed, bool invalidDuration)
        {
            if (PowerSupplyBatteryTestFail != null)
            {
                BatteryTestFailReason reason = BatteryTestFailReason.None;
                if (invalidDuration)
                    reason = BatteryTestFailReason.InvalidDuration;
                else if (batteryChargerFailed)
                    reason = BatteryTestFailReason.NoBattery; // the closest reason we have
                else if (powerState != PowerFailState.None)
                    reason = BatteryTestFailReason.ACFail;
                else
                    reason = BatteryTestFailReason.NoBattery;

                PowerSupplyBatteryTestFail(this, new PowerSupplyBatteryTestFailEventArgs(logicalDeviceId, reason));
            }
        }

        /// <summary>
        /// Check if any battery load test is still in progress
        /// </summary>
        public bool AnyBatteryTestInProgress
        {
            get
            {
                foreach (DeviceStatusBase device in Items)
                {
                    IDeviceLocalPowerSupplyStatus powerSupply = device as IDeviceLocalPowerSupplyStatus;
                    if (powerSupply != null && powerSupply.BatteryTestInProgress == true)
                        return true;
                }
                return false;
            }
        }

        /// <summary>
        /// Trigger 8101 keypad lockout changed event handler.
        /// </summary>
        /// <param name="deviceKeypadStatus">Changed keypad device status.</param>
        internal void TriggerKeypadLockedOutChangedStatus(IDeviceStatusBase deviceKeypadStatus, bool lockedOut)
        {
            if (OnKeypadUserLockedOutChangedStatus != null)
            {
                // Signal event that one of the keypads have just entered into or exited out of locked out state.
                OnKeypadUserLockedOutChangedStatus(this, new ItemStatusChangedEventArgs(deviceKeypadStatus.LogicalId, lockedOut));
            }
        }

        /// <summary>
        /// Trigger 8101 keypad too many invalid logon attempts event handler
        /// </summary>
        /// <param name="deviceStatus">Keypad device status</param>
        /// <param name="areaId">Device owner area Id</param>
        /// <param name="status">Alarm = True / Restore = False</param>
        internal void TriggerTooManyInvalidLogonAttempts(IDeviceStatusBase deviceStatus, int areaId, bool status)
        {
            if (KeypadTooManyInvalidLogonAttempts != null)
            {
                KeypadTooManyInvalidLogonAttempts(deviceStatus, new ItemStatusAreaChangedEventArgs(deviceStatus.LogicalId, areaId, status));
            }
            TriggerDeviceChangedAlarmState(deviceStatus);
        }

        /// <summary>
        /// Trigger invalid user Id / Pin entered on keypad event.
        /// </summary>
        /// <param name="deviceStatus">Keypad device status</param>
        /// <param name="areaId">Device owner area Id</param>
        /// <param name="userId">Logged On User Id</param>
        internal void TriggerReportInvalidUserIdPin(IDeviceStatusBase deviceStatus, int areaId, int userId)
        {
            if (ReportInvalidUserIdPin != null)
            {
                ReportInvalidUserIdPin(this, new DeviceUserIdEventArgs(deviceStatus.LogicalId, userId, areaId));
            }
        }

        /// <summary>
        /// Trigger User Out of Scheduled.
        /// </summary>
        /// <param name="deviceStatus">Keypad device status</param>
        /// <param name="areaId">Device owner area Id</param>
        /// <param name="userId">Logged On User Id</param>
        internal void TriggerReportUserOutOfSchedule(IDeviceStatusBase deviceStatus, int areaId, int userId)
        {
            if (ReportUserOutOfSchedule != null)
            {
                ReportUserOutOfSchedule(this, new DeviceUserIdEventArgs(deviceStatus.LogicalId, userId, areaId));
            }
        }

        /// <summary>
        /// Trigger 8101 user login duress when a user logs in with valid User Id and duress PIN. 
        /// </summary>
        /// <param name="deviceStatus">Changed keypad device status.</param>
        /// <param name="areaId">Area Id in which the keypad is located.</param>
        /// <param name="userId">Logged On User Id</param>
        internal void TriggerKeypadUserLoginDuressPin(IDeviceStatusBase deviceStatus, int areaId, int userId)
        {
            if (OnKeypadUserLoginDuressPin != null)
            {
                OnKeypadUserLoginDuressPin(this, new DeviceUserIdEventArgs(deviceStatus.LogicalId, userId, areaId));
            }
        }

        public void TriggerGraphicsKeypadBitmapLoading(int logicalId, int bitmapId)
        {
            if (GraphicsKeypadBitmapLoading != null)
            {
                GraphicsKeypadBitmapLoading(this, new GraphicsKeypadBitmapLoadingEventArgs(logicalId, bitmapId));
            }
        }
        /// <summary>
        /// Trigger Engineer has logged on event
        /// </summary>
        /// <param name="deviceStatus">Keypad on which the engineer has logged in</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="groupId">User Group Id</param>
        /// <param name="logOn">LogOn = True / LogOff = False</param>
        internal void TriggerEngineerLogOn(IDeviceStatusBase deviceStatus, UserAuditInfo userAuditInfo, int areaId, int groupId, bool logOn)
        {
            if (EngineerLogOn != null)
            {
                EngineerLogOn(this, new EngineerLogOnEventArgs(deviceStatus.LogicalId, areaId, userAuditInfo, groupId, logOn));
            }
        }

#if INOVONICSTEMPERATUREDEMO
        internal void TriggerAnalogueInputChangedState(IDeviceStatusBase deviceStatus, int inputId, int areaId, AnalogueInputUnits units, int analogueValue)
        {
            if (AnalogueInputChangedState != null)
            {
                AnalogueInputChangedState(this, new AnalogueInputChangedStateEventArgs(inputId, areaId, units, analogueValue));
            }
        }
#endif

        #endregion Trigger Event Handlers

        #region Trigger Inovonics Event Handlers

        /// <summary>
        /// Trigger one-way smoke detector device sensor clean required status changed event handler
        /// </summary>
        /// <param name="deviceStatus">Inovonics device status.</param>
        public void TriggerSensorCleanRequiredChangedStatus(InovonicsSecurityDeviceStatus deviceStatus)
        {
            if (ReceiverCleanRequiredChanged != null)
                ReceiverCleanRequiredChanged(deviceStatus, new ItemStatusChangedEventArgs(deviceStatus.LogicalId, deviceStatus.MaskedSensorCleanRequired));
            TriggerDeviceChangedAlarmState(deviceStatus);
        }

        /// <summary>
        /// Trigger Serial Receiver / High-Power Repeater - Receiver Jammed status changed event handler
        /// </summary>
        /// <param name="deviceStatus">Inovonics device status.</param>
        public void TriggerReceiverJammedChangedStatus(DeviceStatusAbstractBase deviceStatus, bool maskedReceiverJammed)
        {
            if (ReceiverJammedChanged != null)
                ReceiverJammedChanged(deviceStatus, new ItemStatusChangedEventArgs(deviceStatus.LogicalId, maskedReceiverJammed));
            TriggerDeviceChangedAlarmState(deviceStatus);
        }

        #endregion Trigger Inovonics Event Handlers

        /// <summary>
        /// Create device status from device configuration
        /// </summary>
        /// <param name="deviceConfig">Device configuration instance</param>
        /// <returns></returns>
        protected DeviceStatusAbstractBase CreateDeviceStatus(DeviceConfigurationBase deviceConfig, DeviceStatusStorageBase deviceStatusStorage)
        {
            switch (deviceConfig.HardwareType)
            {
                case HardwareType.Pacom8303:
                    return new PowerSupplyDeviceStatus(deviceConfig, this, deviceStatusStorage);
                case HardwareType.Pacom8308:
                    return new PowerSupply8308DeviceStatus(deviceConfig, this, deviceStatusStorage);
                case HardwareType.Pacom8501:
                    return new Device8501Status(deviceConfig, this, deviceStatusStorage);
                case HardwareType.Pacom1065ElevatorController:
                    return new Device8501ECStatus(deviceConfig, this, deviceStatusStorage);
                case HardwareType.Pacom8603:
                    return new Device8603Status(deviceConfig, this, deviceStatusStorage);
                case HardwareType.Pacom8502InputOutput:
                    return new Device8502Status(deviceConfig, this, deviceStatusStorage);
                case HardwareType.Pacom8101:
                case HardwareType.Pacom8101A:
                    return new Device8101Status(deviceConfig, this, deviceStatusStorage);
                case HardwareType.Pacom1076DoorController:
                    return new Device1076DCStatus(deviceConfig, this, deviceStatusStorage);
                case HardwareType.Pacom1076VaultController:
                    return new Device1076VCStatus(deviceConfig, this, deviceStatusStorage);
                case HardwareType.Pacom1065InputOutput:
                    return new Device1065IOStatus(deviceConfig, this, deviceStatusStorage);
                case HardwareType.InovonicsSerialReceiver:
                    return new InovonicsReceiverStatus(deviceConfig, this, deviceStatusStorage);
                case HardwareType.InovonicsRepeater:
                    return new InovonicsRepeaterStatus(deviceConfig, this, deviceStatusStorage);
                case HardwareType.InovonicsTransceiver:
                    {
#if INOVONICSTEMPERATUREDEMO
                        if (deviceConfig is InovonicsTemperatureDeviceConfiguration)
                            return new InovonicsTemperatureDeviceStatus(deviceConfig, this);
#endif
                        return new InovonicsSecurityDeviceStatus(deviceConfig, this, deviceStatusStorage);
                    }
                default:
                    return new DeviceLoopDeviceStatus(deviceConfig, this, deviceStatusStorage);
            }
        }

        /// <summary>
        /// Update devices list from configuration. Add new device status instances if not already existing
        /// </summary>
        /// <param name="devices">List of device loop device configuration to add</param>
        /// <param name="statusStorage">Stataus Storage instance or null if status restore is not required</param>
        internal void UpdateFromConfiguration(DeviceConfigurationBase[] devices, StatusStorageCollection statusStorage)
        {
            foreach (var device in devices)
            {
                DeviceStatusStorageBase deviceStatusStorage = statusStorage.DevicesStatus.TryGetValue(device.Id);
                Assign(device.Id, CreateDeviceStatus(device, deviceStatusStorage));
            }
        }

        /// <summary>
        /// Update Device status list from configuration on configuration change.
        /// </summary>
        internal void UpdateFromConfiguration(ConfigurationChangeEventArgs e, List<NodeStateBase> partialStatusList)
        {
            int controllerId = ConfigurationManager.Instance.ControllerConfiguration.Id;
            foreach (var removedItem in e.RemovedItems)
            {
                if (removedItem.ConfigurationType == ConfigurationElementType.Device && removedItem.Id != controllerId)
                    Remove(removedItem.Id);
            }
            foreach (var changedItem in e.ChangedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Device && changedItem.Id != controllerId)
                {
                    Remove(changedItem.Id);
                    try
                    {
                        DeviceConfigurationBase deviceConfiguration = ConfigurationManager.Instance.GetDeviceConfiguration(changedItem.Id);
                        if (deviceConfiguration != null)
                        {
                            Assign(changedItem.Id, CreateDeviceStatus(deviceConfiguration, null));
                            partialStatusList.Add(this[changedItem.Id].CreateEventState());
                        }
                    }
                    catch
                    {
                    }
                }
            }
            foreach (var newlyAddedItem in e.NewlyAddedItems)
            {
                try
                {
                    if (newlyAddedItem.ConfigurationType == ConfigurationElementType.Device && newlyAddedItem.Id != controllerId)
                    {
                        DeviceConfigurationBase deviceConfiguration = ConfigurationManager.Instance.GetDeviceConfiguration(newlyAddedItem.Id);
                        if (deviceConfiguration != null)
                        {
                            Assign(newlyAddedItem.Id, CreateDeviceStatus(deviceConfiguration, null));
                            partialStatusList.Add(this[newlyAddedItem.Id].CreateEventState());
                        }
                    }
                }
                catch
                {
                }
            }

            // If the controller configuration has changed, every device will be affected
            if (e.ControllerChanged)
            {
                DeviceStatusAbstractBase[] allDevices = Items;
                foreach (DeviceStatusAbstractBase deviceStatus in allDevices)
                {
                    try
                    {
                        deviceStatus.Online = false;
                    }
                    catch
                    {
                    }
                }
            }
            else
            {
                foreach (int affectedDeviceId in e.AffectedDevices)
                {
                    try
                    {
                        IDeviceStatusBase deviceStatus = this[affectedDeviceId];
                        if (deviceStatus != null)
                            deviceStatus.Online = false;
                    }
                    catch
                    {
                    }
                }
            }
        }

        /// <summary>
        /// Create device information for all devices and add it to the supplied list
        /// </summary>
        /// <param name="deviceInformationList">Device information list to add to</param>
        public void CreateDeviceInformation(List<DeviceInformation> deviceInformationList)
        {
            foreach (var device in Items)
            {
                if (device == null || device.Enabled == false)
                    continue;
                DeviceInformation deviceInfo = device.CreateDeviceInformation();
                if (device.IsPowerSupplyDevice)
                {
                    IDeviceLocalPowerSupplyStatus powerSupplyStatus = device as IDeviceLocalPowerSupplyStatus;
                    if (powerSupplyStatus != null)
                    {
                        powerSupplyStatus.UpdatePowerSupplyInformation(deviceInfo as PowerSupplyInformation);
                    }
                }
                deviceInformationList.Add(deviceInfo);
            }
        }

        /// <summary>
        /// Get the list of devices that have alarms
        /// </summary>
        /// <returns></returns>
        public List<IStatusItem> GetDevicesWithAlarms()
        {
            List<IStatusItem> alarmedDevices = new List<IStatusItem>();
            foreach (DeviceStatusAbstractBase device in Items)
            {
                if (device != null && device.Enabled == true && device.CurrentAlarms != EventSourceLatchOrIsolateType.None)
                {
                    alarmedDevices.Add(device);
                }
            }
            if (StatusManager.Instance.Controller.CurrentAlarms != EventSourceLatchOrIsolateType.None)
                alarmedDevices.Add(StatusManager.Instance.Controller);
            return alarmedDevices;
        }

        /// <summary>
        /// Check if any of the devices has any active alarms
        /// </summary>
        public bool AnyInAlarm
        {
            get
            {
                foreach (DeviceStatusAbstractBase device in Items)
                {
                    if (device != null && device.Enabled == true && device.CurrentAlarms != EventSourceLatchOrIsolateType.None)
                        return true;
                }
                return StatusManager.Instance.Controller.CurrentAlarms != EventSourceLatchOrIsolateType.None;
            }
        }

        /// <summary>
        /// Get the list of devices that have isolated alarms (one or all internal device inputs). E.g.: OFFLINE, TAMPER, etc.  
        /// </summary>
        /// <returns></returns>
        public List<IStatusItem> GetIsolated()
        {
            List<IStatusItem> isolatedDevices = new List<IStatusItem>();
            foreach (DeviceStatusAbstractBase device in Items)
            {
                if (device != null && device.Enabled == true && device.IsolatedAlarms != EventSourceLatchOrIsolateType.None)
                {
                    isolatedDevices.Add(device);
                }
            }
            if (StatusManager.Instance.Controller.IsolatedAlarms != EventSourceLatchOrIsolateType.None)
                isolatedDevices.Add(StatusManager.Instance.Controller);
            return isolatedDevices;
        }

        /// <summary>
        /// Check if any of the devices has any isolated alarms
        /// </summary>
        public bool AnyIsolated
        {
            get
            {
                foreach (DeviceStatusAbstractBase device in Items)
                {
                    if (device != null && device.Enabled == true && device.IsolatedAlarms != EventSourceLatchOrIsolateType.None)
                        return true;
                }
                return StatusManager.Instance.Controller.IsolatedAlarms != EventSourceLatchOrIsolateType.None;
            }
        }

        /// <summary>
        /// Isolate a list of devices for a specified duration or deisolate a list of devices.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <returns></returns>
        public bool SetIsolated(List<int> deviceIds, EventSourceLatchOrIsolateType value, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            if (value != EventSourceLatchOrIsolateType.None)
            {
                // Isolate device alarms
                List<int> devicesToDeisolate = new List<int>(deviceIds.Count);
                foreach (int deviceId in deviceIds)
                {
                    DeviceStatusAbstractBase status = this[deviceId];
                    if (status != null && status.Enabled == true)
                    {
                        if (status.SetIsolated(userAuditInfo, value) == true)
                            devicesToDeisolate.Add(deviceId);
                    }
                }
                if (durationInSeconds > 0 && devicesToDeisolate.Count > 0)
                {
                    StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.DeisolateDevices, devicesToDeisolate, userAuditInfo, durationInSeconds);
                }
                return (devicesToDeisolate.Count > 0);
            }
            else
            {
                // Deisolate device alarms - doesn't support a duration.
                bool result = false;
                foreach (int deviceId in deviceIds)
                {
                    DeviceStatusAbstractBase status = this[deviceId];
                    if (status != null && status.Enabled == true)
                    {
                        if (status.SetIsolated(userAuditInfo, EventSourceLatchOrIsolateType.None) == true)
                            result = true;
                    }
                }
                return result;
            }
        }

        internal override void Persist(Asn1DerFormatter asn1Serializer, Stream statusStream)
        {
            foreach (var device in Items)
            {
                try
                {
                    asn1Serializer.Serialize(statusStream, device.CreateStatusStorage());
                }
                catch (Exception ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Unable to store status for device {0}. {1}", device.DisplayName, ex.Message);
                    });
                }
            }
        }

        internal override void Cleanup()
        {
            suspectedOfflineDevices.Dispose();
            suspectedOfflineDevices = null;

            deviceOnlineStatusUpdateAgent.Dispose();
            deviceOnlineStatusUpdateAgent = null;

            inovonicsDeviceOnlineStatusUpdateAgent.Dispose();
            inovonicsDeviceOnlineStatusUpdateAgent = null;

            powerFailReportingDevices.Dispose();
            powerFailReportingDevices = null;

            base.Cleanup();
        }
    }
}
