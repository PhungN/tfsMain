﻿using System;
using System.IO;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.Utils;
using Pacom.Serialization.Formatters.Asn1;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Collection of all input statuses with utility functions
    /// </summary>
    public class InputStatusList : StatusListBase<InputStatus, InputStatusList>
    {
        /// <summary>
        /// Triggered when the status of any of the inputs changes.
        /// </summary>
        public event EventHandler<StatusManagerInputChangedStatusEventArgs> ChangedStatus = null;

        /// <summary>
        /// Triggered when the masked status of any of the inputs changes.
        /// </summary>
        public event EventHandler<StatusManagerInputChangedMaskedStatusEventArgs> ChangedMaskedStatus = null;

        /// <summary>
        /// Triggered when the masked status of any of the inputs changes, but not reporting to frontend.
        /// </summary>
        public event EventHandler<StatusManagerInputChangedMaskedStatusEventArgs> UnreportedMaskedStatus = null;

        /// <summary>
        /// Triggered when the isolated flag of any of the inputs changes.
        /// </summary>
        public event EventHandler<StatusManagerInputChangedIsolatedEventArgs> ChangedIsolatedStatus = null;

        public event EventHandler<InputTestSuccessEventArgs> InputTestSuccess = null;

        /// <summary>
        /// Trigger input changed status event handler
        /// </summary>
        /// <param name="inputStatus">The Input Status that changed.</param>
        /// <param name="previousStatus">Previous input status.</param>
        internal void TriggerChangedUnmaskedStatus(InputStatus inputStatus, Common.InputStatus previousStatus)
        {
            if (ChangedStatus == null)
                return;
            ChangedStatus(this, new StatusManagerInputChangedStatusEventArgs(inputStatus, previousStatus));
        }

        /// <summary>
        /// Triggered when input masked status has changed
        /// </summary>
        /// <param name="inputStatus">The inputs status instance that has changed.</param>
        /// <param name="maskedStatus">The new value of the input masked status.</param>
        /// <param name="previousMaskedStatus">The previous value of the input masked status.</param>
        public void TriggerChangedMaskedStatus(InputStatus inputStatus, Common.InputStatus maskedStatus, Common.InputStatus previousMaskedStatus)
        {
            if (ChangedMaskedStatus == null)
                return;
            ChangedMaskedStatus(this, new StatusManagerInputChangedMaskedStatusEventArgs(inputStatus, maskedStatus, previousMaskedStatus));
        }

        /// <summary>
        /// Triggered when input masked status has changed, but not reporting to frontend
        /// </summary>
        /// <param name="inputStatus">The inputs status instance that has changed.</param>
        /// <param name="maskedStatus">The new value of the input masked status.</param>
        /// <param name="previousMaskedStatus">The previous value of the input masked status.</param>
        public void TriggerUnreportedMaskedStatus(InputStatus inputStatus, Common.InputStatus maskedStatus, Common.InputStatus previousMaskedStatus)
        {
            if (UnreportedMaskedStatus == null)
                return;
            UnreportedMaskedStatus(this, new StatusManagerInputChangedMaskedStatusEventArgs(inputStatus, maskedStatus, previousMaskedStatus));
        }

        /// <summary>
        /// Triggered when input test failed or cancelled
        /// </summary>
        /// <param name="inputStatus"></param>
        /// <param name="testCancelled"></param>
        public void TriggerInputTestFailed(InputStatus inputStatus, bool testCancelled)
        {
            if (ChangedMaskedStatus == null)
                return;
            ChangedMaskedStatus(this, new StatusManagerInputChangedMaskedStatusEventArgs(inputStatus, Common.InputStatus.SelfTestFail, inputStatus.MaskedStatus, testCancelled));
        }

        /// <summary>
        /// Triggered when input isolated status has changed
        /// </summary>
        /// <param name="inputStatus">The inputs status instance that has changed.</param>
        /// <param name="isolated">The new value of the input isolated status.</param>
        /// <param name="userAuditInfo">User that initiated the isolate / deisolate command.</param>
        internal void TriggerChangedIsolatedStatus(InputStatus inputStatus, bool isolated, UserAuditInfo userAuditInfo)
        {
            if (ChangedIsolatedStatus == null)
                return;
            ChangedIsolatedStatus(this, new StatusManagerInputChangedIsolatedEventArgs(inputStatus, isolated, userAuditInfo));
        }

        public void TriggerInputTestSuccess(int logicalInputId, UserAuditInfo userAuditInfo)
        {
            if (InputTestSuccess != null)
            {
                InputTestSuccess(this, new InputTestSuccessEventArgs(logicalInputId, userAuditInfo));
            }
        }

        /// <summary>
        /// Get status for physical input id on device
        /// </summary>
        /// <param name="deviceId">Physical device Id: 0..127</param>
        /// <param name="InputId">Input point Id on device, 0 based</param>
        /// <returns>Input Status</returns>
        public InputStatus GetStatus(int deviceId, int inputId)
        {
            int logicalInputId = ConfigurationManager.Instance.ControllerConfiguration.LogicalInputId(deviceId, inputId);
            return this[logicalInputId];
        }

        /// <summary>
        /// Get input status for input with [logicalInputid] id
        /// </summary>
        /// <param name="logicalInputId">Logical input id, 1 based</param>
        /// <returns>Input status instance or null if not found</returns>
        public InputStatus GetStatus(int logicalInputId)
        {
            return this[logicalInputId];
        }

        /// <summary>
        /// Isolate inputs in specified area
        /// </summary>
        /// <param name="areaId"></param>
        /// <param name="userAuditInfo">User that initiated the isolate / deisolate command.</param>
        public void IsolateInArea(int areaId, UserAuditInfo userAuditInfo)
        {
            List<IStatusItem> inputsInArea = GetInputsInAreaForUser(userAuditInfo.OriginatingUserId, areaId);
            if (inputsInArea == null || inputsInArea.Count == 0)
                return;
            foreach (var input in inputsInArea)
            {
                (input as InputStatus).SetIsolated(true, userAuditInfo);
            }
        }

        /// <summary>
        /// Restore inputs in area.
        /// </summary>
        /// <param name="areaId">Area id.</param>
        /// <param name="userAuditInfo">User that initiated the restore inputs in area action.</param>
        public void RestoreInArea(AreaStatus areaStatus, UserAuditInfo userAuditInfo)
        {
            List<IStatusItem> areaInputs = GetInputsInArea(areaStatus.LogicalId);
            if (areaInputs != null && areaInputs.Count > 0)
            {
                foreach (IStatusItem input in areaInputs)
                {
                    InputStatus inputStatus = input as InputStatus;
                    inputStatus.Unlatch(userAuditInfo);
                    inputStatus.MaskedStatus = inputStatus.UnmaskedStatus;
                }
            }
        }

        /// <summary>
        /// Deisolate inputs in specified area
        /// </summary>
        /// <param name="areaId">Logical Area Id</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate action.</param>
        public void DeisolateInArea(int areaId, UserAuditInfo userAuditInfo)
        {
            List<IStatusItem> inputsInArea = GetInputsInAreaForUser(userAuditInfo.OriginatingUserId, areaId);
            if (inputsInArea == null || inputsInArea.Count == 0)
                return;
            foreach (var input in inputsInArea)
            {
                (input as InputStatus).SetIsolated(false, userAuditInfo);
            }
        }

        /// <summary>
        /// Isolate a list of inputs for a specified duration.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate action.</param>
        /// <returns></returns>
        public bool SetIsolated(List<int> inputIds, bool value, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            if (value == true)
            {
                List<int> inputsToDeisolate = new List<int>(inputIds.Count);
                foreach (int inputId in inputIds)
                {
                    InputStatus status = this[inputId];
                    if (status != null && status.Enabled == true)
                    {
                        if (status.SetIsolated(true, userAuditInfo) == true)
                            inputsToDeisolate.Add(inputId);
                    }
                }
                if (durationInSeconds > 0)
                {
                    StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.DeisolateInputs, inputsToDeisolate, userAuditInfo, durationInSeconds);
                }
                return (inputsToDeisolate.Count > 0);
            }
            else
            {
                // Deisolate doesn't support a duration.
                bool result = false;
                foreach (int inputId in inputIds)
                {
                    InputStatus status = this[inputId];
                    if (status != null && status.Enabled == true)
                    {
                        if (status.SetIsolated(false, userAuditInfo) == true)
                            result = true;
                    }
                }
                return result;
            }
        }

        /// <summary>
        /// Unlatched inputs in specified area
        /// </summary>
        /// <param name="areaId"></param>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        public void UnlatchedInArea(int areaId, UserAuditInfo userAuditInfo)
        {
            List<IStatusItem> inputsInArea = GetInputsInAreaForUser(userAuditInfo.OriginatingUserId, areaId);
            if (inputsInArea == null || inputsInArea.Count == 0)
                return;
            foreach (var input in inputsInArea)
            {
                input.Unlatch(userAuditInfo);
            }
        }

        /// <summary>
        /// Get all enabled inputs in specified area.
        /// </summary>
        /// <param name="areaId">Area id for which enabled inputs will be returned.</param>
        /// <returns>Returns the list of enabled inputs for this area.</returns>
        public List<IStatusItem> GetInputsInArea(int areaId)
        {
            List<IStatusItem> inputs = new List<IStatusItem>();
            foreach (var input in Items)
            {
                if (input == null || input.Enabled == false)
                    continue;
                InputConfiguration inputConfig = ConfigurationManager.Instance.GetInputConfiguration(input.LogicalId);
                if (inputConfig == null || inputConfig.AreaId != areaId)
                    continue;

                inputs.Add(input);
            }
            return inputs;
        }

        /// <summary>
        /// Get all inputs for all areaIds belongs to a user.
        /// </summary>
        /// <param name="user"></param>
        /// <returns>Returns the list of inputs for all areas belongs to this user.</returns>
        public List<IStatusItem> GetInputsInAreasForUser(IUserConfiguration user)
        {
           var inputStausItems = new List<IStatusItem>();
            foreach (var inputStatus in Items)
            {
                if (inputStatus != null && inputStatus.Enabled == true)
                {
                    InputConfiguration inputConfig = ConfigurationManager.Instance.GetInputConfiguration(inputStatus.LogicalId);
                    if (inputConfig != null && user.AreaIds.Contains(inputConfig.AreaId))
                    {
                        inputStausItems.Add(inputStatus);
                    }
                }
            }
            inputStausItems.Sort((x, y) => x.LogicalId.CompareTo(y.LogicalId));
            return inputStausItems;
        }

        /// <summary>
        /// Returns a list of enabled inputs in an area that the user has access to. 
        /// If the user doesn't have access to this area null will be returned.
        /// </summary>
        public List<IStatusItem> GetInputsInAreaForUser(int userId, int areaId)
        {
            if (CommonUtilities.CheckUserAccess(userId, areaId))
            {
                return GetInputsInArea(areaId);
            }
            return null;
        }

        /// <summary>
        /// Get logical inputs ids assigned to specified device.
        /// </summary>
        /// <param name="logicalDeviceId">Logical device id for which configured inputs will be returned.</param>
        /// <returns>Returns logical inputs ids for specified device id.</returns>
        public int[] GetInputsForDevice(int logicalDeviceId)
        {
            List<int> deviceInputs = new List<int>();
            foreach (var input in ConfigurationManager.Instance.Inputs)
            {
                if (input != null && input.ParentDeviceId == logicalDeviceId)
                    deviceInputs.Add(input.Id);
            }         
            return deviceInputs.ToArray();
        }

        /// <summary>
        /// Get all the AutomaticIntegrityCheckEnabled inputs that has not been triggered
        /// </summary>
        /// <param name="requestFromKeypad"></param>
        /// <param name="areaIds"></param>
        /// <returns></returns>
        public List<IStatusItem> GetPirNotTriggeredInputs(bool requestFromKeypad, params int[] areaIds)
        {
            DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
            List<IStatusItem> inputItems = new List<IStatusItem>();
            foreach (var area in areaIds)
            {
                var areaConfig = ConfigurationManager.Instance.GetAreaConfiguration(area);
                if (areaConfig != null)
                {
                    foreach (var input in GetInputsInArea(area))
                    {
                        var inputConfig = ConfigurationManager.Instance.GetInputConfiguration(input.LogicalId);
                        if (inputConfig != null && inputConfig.Enabled && inputConfig.AutomaticIntegrityCheckEnabled)
                        {
                            if (requestFromKeypad == true && inputConfig.DisplayFailuresOnKeypadDuringArming == false)
                                continue;
                            var inputStatus = input as InputStatus;
                            if (inputStatus != null && inputStatus.AutomaticIntegrityCheckTriggered == false)
                            {
                                DateTime lastTriggeredTime = inputStatus.LastAutomaticIntegrityCheckTriggeredTime;
                                if((now - lastTriggeredTime).TotalHours > (Math.Max(inputConfig.PermittedInactivityInDays, 1)*24) - 8)
                                    inputItems.Add(input);
                            }
                        }
                    }
                }
            }
            return inputItems;
        }

        /// <summary>
        /// Check if there's at least one AutomaticIntegrityCheckEnabled input has been triggered.
        /// </summary>
        /// <param name="areaIds"></param>
        /// <returns></returns>
        public bool HasAnyPirNotTriggered(params int[] areaIds)
        {
            if (LicenseManager.Instance.RemoteMaintenance == true)
            {
                foreach (var area in areaIds)
                {
                    var areaConfig = ConfigurationManager.Instance.GetAreaConfiguration(area);
                    if (areaConfig != null)
                    {
                        foreach (var input in GetInputsInArea(area))
                        {
                            var inputConfig = ConfigurationManager.Instance.GetInputConfiguration(input.LogicalId);
                            if (inputConfig != null && inputConfig.Enabled && inputConfig.AutomaticIntegrityCheckEnabled)
                            {
                                var inputStatus = input as InputStatus;
                                if (inputStatus != null && inputStatus.AutomaticIntegrityCheckTriggered == false)
                                    return true;
                            }
                        }
                    }
                }
            }
            return false;
        }

        public void ClearPirNotTriggeredStatus(int areaId)
        {
            var areaConfig = ConfigurationManager.Instance.GetAreaConfiguration(areaId);
            if (areaConfig != null)
            {
                foreach (var input in GetInputsInArea(areaId))
                {
                    var inputConfig = ConfigurationManager.Instance.GetInputConfiguration(input.LogicalId);
                    if (inputConfig != null && inputConfig.Enabled && inputConfig.AutomaticIntegrityCheckEnabled)
                    {
                        var inputStatus = input as InputStatus;
                        if (inputStatus != null)
                            inputStatus.AutomaticIntegrityCheckTriggered = false;
                    }
                }
            }
        }

        /// <summary>
        /// Get logical inputs ids assigned to specified input expansion card.
        /// </summary>
        /// <param name="logicalDeviceId">Logical expansion card id for which configured inputs will be returned.</param>
        /// <returns>Returns logical inputs ids for specified expansion card id.</returns>
        public int[] GetInputsForExpansionCard(int logicalExpansionCardId)
        {
            List<int> expansionCardInputs = new List<int>();
            foreach (var input in ConfigurationManager.Instance.Inputs)
            {
                if (input != null && input.ParentDeviceId == logicalExpansionCardId)
                    expansionCardInputs.Add(input.Id);
            }
            return expansionCardInputs.ToArray();
        }

        /// <summary>
        /// Check if any enabled input that belongs to an area is in alarm
        /// </summary>
        /// <param name="logicalAreaId">Logical area id</param>
        /// <returns>Returns true if any masked input in an area is not in the secure state.</returns>
        public bool IsAnyActiveInArea(int logicalAreaId)
        {
            List<IStatusItem> areaInputs = GetInputsInArea(logicalAreaId);
            if (areaInputs != null && areaInputs.Count > 0)
            {
                foreach (var input in areaInputs)
                {
                    if ((input as InputStatus).MaskedStatus == Common.InputStatus.Alarm)
                        return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Check if all enabled inputs assigned to an area are in alarm
        /// </summary>
        /// <param name="logicalAreaId">Logical area id</param>
        /// <returns>Returns true if all masked inputs in an area are not in the secure state.</returns>
        public bool AreAllActiveInArea(int logicalAreaId)
        {
            List<IStatusItem> areaInputs = GetInputsInArea(logicalAreaId);
            if (areaInputs != null && areaInputs.Count > 0)
            {
                foreach (var input in areaInputs)
                {
                    InputStatus inputStatus = input as InputStatus;
                    if (inputStatus.MaskedStatus == Common.InputStatus.Secure || inputStatus.MaskedStatus == Common.InputStatus.UnqualifiedAlarm)
                        return false;
                }
                return true;
            }
            return false;
        }

        /// <summary>
        /// Called after the configuration is ready but after the lists are repopulated.
        /// </summary>
        /// <param name="controllerRestarted">True if controller was restarted</param>
        internal void AfterStatusUpdate()
        {
            InputStatus[] inputsStatus = Items;
            foreach (var inputStatus in inputsStatus)
            {
                if (inputStatus.Enabled == true)
                    inputStatus.MaskedStatus = inputStatus.UnmaskedStatus;
            }
        }

        private bool changed(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, InputStatus inputsStatus)
        {
            foreach (var newlyAddedItem in newlyAddedItems)
            {
                if (newlyAddedItem.ConfigurationType == ConfigurationElementType.Input && newlyAddedItem.Id == inputsStatus.LogicalId)
                    return true;
            }
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Input && changedItem.Id == inputsStatus.LogicalId)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Called after the configuration is ready but after the lists are repopulated.
        /// </summary>
        /// <param name="controllerRestarted">True if controller was restarted</param>
        internal void AfterStatusUpdate(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems)
        {
            InputStatus[] inputsStatus = Items;
            foreach (var inputStatus in inputsStatus)
            {
                if (inputStatus.Enabled == true && changed(newlyAddedItems, changedItems, inputStatus))
                    inputStatus.MaskedStatus = inputStatus.UnmaskedStatus;
            }
        }

        /// <summary>
        /// Update inputs status list from configuration. Add new input status instances if not already existing
        /// </summary>
        /// <param name="inputs">List of inputs to add</param>
        /// <param name="statusStorage">Status storage instance</param>
        /// <param name="controllerRestarted">True if controller restarted</param>
        internal void UpdateFromConfiguration(InputConfiguration[] inputs, StatusStorageCollection statusStorage)
        {
            foreach (var input in inputs)
            {
                InputStatusStorage inputStatusStorage = statusStorage.InputsStatus.TryGetValue(input.Id);
                Assign(input.Id, new InputStatus(input, this, inputStatusStorage));
            }
        }

        /// <summary>
        /// Update Input status list from configuration on configuration change.
        /// </summary>
        internal void UpdateFromConfiguration(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems, List<NodeStateBase> partialStatusList)
        {
            foreach (var removedItem in removedItems)
            {
                if (removedItem.ConfigurationType == ConfigurationElementType.Input)
                    Remove(removedItem.Id);
            }
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Input)
                {
                    Remove(changedItem.Id);
                    try
                    {
                        Assign(changedItem.Id, new InputStatus(ConfigurationManager.Instance.GetInputConfiguration(changedItem.Id), this, null));
                        partialStatusList.Add(this[changedItem.Id].CreateEventState());
                    }
                    catch
                    {
                    }
                }
            }
            foreach (var newlyAddedItem in newlyAddedItems)
            {
                try
                {
                    if (newlyAddedItem.ConfigurationType == ConfigurationElementType.Input)
                    {
                        Assign(newlyAddedItem.Id, new InputStatus(ConfigurationManager.Instance.GetInputConfiguration(newlyAddedItem.Id), this, null));
                        partialStatusList.Add(this[newlyAddedItem.Id].CreateEventState());
                    }
                }
                catch
                {
                }
            }
        }

        internal override void Persist(Asn1DerFormatter asn1Serializer, Stream statusStream)
        {
            foreach (var input in Items)
            {
                try
                {
                    asn1Serializer.Serialize(statusStream, input.CreateStatusStorage());
                }
                catch (Exception ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Unable to store status for input {0}. {1}", input.LogicalId, ex.Message);
                    });
                }
            }
        }

        internal void RefreshAfterConfigurationChange()
        {
            foreach (var input in Items)
            {
                input.RefreshAfterConfigurationChange();
            }
        }

        internal void RefreshAfterConfigurationChange(List<ConfigurationChanges> changedItems)
        {
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Input)
                {
                    InputStatus input = this[changedItem.Id];
                    if (input != null)
                        input.RefreshAfterConfigurationChange();
                }
            }
        }

        internal void UnlatchAll(UserAuditInfo userAuditInfo)
        {
            foreach (var input in Items)
            {
                if (input == null || input.Enabled == false)
                    continue;
                input.Unlatch(userAuditInfo);
            }
        }
    }
}
