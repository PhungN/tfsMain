﻿using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;

namespace Pacom.Peripheral.Common.Status
{
    public sealed class Device8502Status : DeviceLoopDeviceStatus
    {
        public Device8502Status(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus) :
            base(configuration, parent, previousStatus)
        {
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            Device8502EventState deviceState = new Device8502EventState();
            InitializeEventState(deviceState);
            return deviceState;
        }

        /// <summary>
        /// Get the ConfirmedType for current alarm based on area mode and the previous unconfirmed alarm if required.
        /// </summary>
        /// <param name="unconfirmedAlarmSource">The source of an existing unconfirmed alarm, received before the current alarm.</param>
        /// <param name="areaSource">Area from which the alarm has originated</param>
        /// <returns>None, Unconfirmed or Confirmed.</returns>
        public override ConfirmedType GetConfirmedAlarmType(IStatusItem unconfirmedAlarmSource, IStatusItem areaSource)
        {
            if (areaSource == null)
                return ConfirmedType.None;

            AreaStatus areaStatus = areaSource as AreaStatus;
            if (areaStatus == null || (areaStatus.Mode == AreaScheduleLevel.Disarmed && CurrentAlarms.Has(EventSourceLatchOrIsolateType.Offline) == true))
            {
                // BS 8243 Annex H.3.1: A confirmed alarm will not be notified when a failure of communication to multiple devices on 
                //                      a data bus which cannot be identified as a fault (Device Offline), occurs when the system is 
                //                      in un-set state (area is Disarmed).
                return ConfirmedType.None;
            }

            if (unconfirmedAlarmSource != null && CurrentAlarms.Has(EventSourceLatchOrIsolateType.Tamper) == true)
            {
                if (unconfirmedAlarmSource.ItemType != StatusItemType.InputStatus)
                    return ConfirmedType.Confirmed;

                InputStatus inputStatus = unconfirmedAlarmSource as InputStatus;
                if (inputStatus != null && inputStatus.ParentDeviceId == LogicalId && inputStatus.MaskedStatus != Common.InputStatus.Secure)
                {
                    if (inputStatus.ConfirmedAlarmType == ConfirmedAlarmType.BS8243Compliant)
                    {
                        // BS 8243 Annex H.3.1-H.3.2: Only Tamper not from an activated detector can confirm an intruder / hold-up alarm
                        return ConfirmedType.Unconfirmed;
                    }
                    return ConfirmedType.None;
                }
            }

            return ConfirmedType.Confirmed;
        }
    }
}
