﻿using Pacom.Core.Contracts;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Events.EventsCommon;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    public sealed class Device8501ECStatus : Device8501Status
    {
        public Device8501ECStatus(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus) :
            base(configuration, parent, previousStatus)
        {
            
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            Device8501ECEventState deviceState = new Device8501ECEventState();
            InitializeEventState(deviceState);
            deviceState.PowerFail = MaskedPowerState;
            deviceState.BatteryFail = MaskedBatteryState;
            deviceState.BatteryChargerFail = MaskedBatteryChargerFailed;
            return deviceState;
        }
    }
}
