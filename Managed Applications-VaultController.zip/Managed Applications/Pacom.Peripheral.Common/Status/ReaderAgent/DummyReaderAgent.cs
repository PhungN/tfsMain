﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.Common.Status
{
    internal class DummyReaderAgent : IReaderAgentInternal
    {
        internal DummyReaderAgent()
        {
        }

        #region IReaderAgent Members

        public void ClearValidCardTransaction()
        {
        }

        public void AssignValidCardTransaction(CardNumberHolder newValidCard, Reader8003ScheduleLevel readerMode)
        {
        }

        public void AssignValidCardTransaction(CardInformation cardInformation, Reader8003ScheduleLevel readerMode, List<CardInformation> cardInformationList, ReaderBadgingType badgingType)
        {
        }

        public bool AssignPinTransaction(byte[] pinData)
        {
            return false;
        }

        public bool UpdateAgentState(DoorAgentContexts context)
        {
            SendAccessControlTransactionEvent(TransactionType.None);
            return false;
        }

        public void ResetAgent()
        {
        }

        public DoorOperationState OperationState
        {
            get { return DoorOperationState.Unknown; }
            set { }
        }

        public ReaderStatus ReaderStatus
        {
            get { return null; }
        }

        /// <summary>
        /// Broadcast the last door peripheral transaction. The Door Agent unit tests subscribe to this event in order to get the last
        /// door peripheral transaction and compare it with the expected value.
        /// </summary>
        public event EventHandler<AccessControlTransactionEventArgs> LastAccessControlTransactionEvent = null;

        /// <summary>
        /// Send access control transaction event so any subscribers can receive the value of the last access control transaction
        /// for this reader.
        /// </summary>
        /// <param name="transactionType">Access Control Transaction Value</param>
        public void SendAccessControlTransactionEvent(TransactionType transactionType)
        {
#if DEBUG
            if (LastAccessControlTransactionEvent != null)
            {
                LastAccessControlTransactionEvent(this, new AccessControlTransactionEventArgs(transactionType));
            }
#endif
        }

        public bool StrikeActivated
        {
            get { return false; }
        }

        public int StrikeTime
        {
            get { return 0; }
            set { }
        }

        public int KeypadInactivityTimeout
        {
            get { return 0; }
        }

        /// <summary>
        /// Get duration to activate card reader LED for denied card [ms]
        /// </summary>
        public int AccessDeniedDuration
        {
            get { return 0; }
        }

        public ReaderTransaction ReaderTransaction
        {
            get { return null; }
        }

        public bool IsKeypadInactivityTimerInProgress
        {
            get { return false; }
        }

        public bool IsDeniedAccessTimerInProgress
        {
            get { return false; }
        }

        public DoorPeripheralTimers PeripheralTimers
        {
            get { return DoorPeripheralTimers.None; }
            set { }
        }

        public void Dispose()
        {
        }

        public DoorAgentContexts Context { get; set; }

        #endregion
    }
}
