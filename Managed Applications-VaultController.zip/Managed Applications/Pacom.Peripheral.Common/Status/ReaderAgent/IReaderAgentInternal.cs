﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.Common.Status
{
    internal interface IReaderAgentInternal : IReaderAgent, IDisposable
    {
        void AssignValidCardTransaction(CardNumberHolder newValidCard, Reader8003ScheduleLevel readerMode);
        void AssignValidCardTransaction(CardInformation cardInformation, Reader8003ScheduleLevel readerMode, List<CardInformation> cardInformationList, ReaderBadgingType badgingType);
        bool AssignPinTransaction(byte[] pinData);
    }
}
