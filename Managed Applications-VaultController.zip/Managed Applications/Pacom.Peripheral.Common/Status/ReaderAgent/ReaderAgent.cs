﻿using System;
using System.Text;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.AccessControl;
using TT = Pacom.Peripheral.Common.Status.TransactionType;

namespace Pacom.Peripheral.Common.Status
{
    internal class ReaderAgent : IReaderAgentInternal
    {
        internal ReaderAgent(ReaderStatus reader)
        {
            this.readerStatus = reader;
            accessControlTransaction = new ReaderAccessControlTransactionAgent(this, readerStatus);
            deactivateStrikeDeniedAccessTimer = TimerManager.Instance.CreateTimer(deactivateStrikeDeniedAccessProc);
            keypadInactivityTimer = TimerManager.Instance.CreateTimer(keypadInactivityTimerProc);
        }

        private ReaderStatus readerStatus = null;

        protected ReaderAccessControlTransactionAgent accessControlTransaction = null;

        /// <summary>
        /// Broadcast the last door peripheral transaction. The Door Agent unit tests subscribe to this event in order to get the last
        /// door peripheral transaction and compare it with the expected value.
        /// </summary>
        public event EventHandler<AccessControlTransactionEventArgs> LastAccessControlTransactionEvent = null;

        /// <summary>
        /// Send access control transaction event so any subscribers can receive the value of the last access control transaction
        /// for this reader.
        /// </summary>
        /// <param name="transactionType">Access Control Transaction Value</param>
        public void SendAccessControlTransactionEvent(TransactionType transactionType)
        {
#if DEBUG
            if (LastAccessControlTransactionEvent != null)
            {
                LastAccessControlTransactionEvent(this, new AccessControlTransactionEventArgs(transactionType));
            }
#endif
        }

        private StringBuilder readerStatusLogText = new StringBuilder();

        /// <summary>
        /// Timer used for deactivating the strike or the denied mode on the door
        /// </summary>
        private IPacomTimer deactivateStrikeDeniedAccessTimer = null;

        private IPacomTimer keypadInactivityTimer = null;

        #region Agent transactions

        private ReaderTransaction readerTransaction = new ReaderTransaction();
        public ReaderTransaction ReaderTransaction
        {
            get { return readerTransaction; }
        }

        public void ClearValidCardTransaction()
        {
            readerTransaction.Clear();
        }

        public void AssignValidCardTransaction(CardNumberHolder newValidCard, Reader8003ScheduleLevel readerMode)
        {
            readerTransaction.Card = newValidCard;
            readerTransaction.TransactionType = ReaderTransactionType.Card;
        }

        public void AssignValidCardTransaction(CardInformation cardInformation, Reader8003ScheduleLevel readerMode)
        {
            AssignValidCardTransaction(cardInformation, readerMode, null, ReaderBadgingType.Normal);
        }

        public void AssignValidCardTransaction(CardInformation cardInformation, Reader8003ScheduleLevel readerMode, List<CardInformation> cardInformationList, ReaderBadgingType badgingType)
        {
            if (readerMode == Reader8003ScheduleLevel.CardOnly || readerTransaction.IsSameCardAs(cardInformation.CardNumber))
            {
                readerTransaction.Card = cardInformation.CardNumber;
                readerTransaction.CardInformation = cardInformation;
                readerTransaction.MultiBadgingCardInformationList = cardInformationList;
                readerTransaction.BadgingType = badgingType;
                readerTransaction.TransactionType = ReaderTransactionType.Card;
                readerTransaction.SetValid();
            }
        }

        public bool AssignPinTransaction(byte[] pinData)
        {
            // Do not allow pin being assigned without card being scanned.
            if (readerTransaction.IsCardAssigned)
            {
                readerTransaction.Pin = pinData;
                return true;
            }
            return false;
        }

        #endregion

        private int keypadInactivityTimeout = 20000;

        /// <summary>
        /// Keypad inactivity time, time allowed for the pin entry.
        /// </summary>
        public int KeypadInactivityTimeout
        {
            get { return keypadInactivityTimeout; }
            set { keypadInactivityTimeout = value; }
        }

        /// <summary>
        /// Strike Time in milliseconds
        /// </summary>
        private int strikeTime = DoorAgentBase.DefaultAccessDeniedTimeout;
        public int StrikeTime
        {
            get { return strikeTime; }
            set { }
        }

        public int AccessDeniedDuration
        {
            get 
            {
                if (accessControlTransaction != null)
                    return accessControlTransaction.DeniedLedTime;
                return DoorAgentBase.DefaultAccessDeniedTimeout; 
            }
        }

        private DoorOperationState readerState = DoorOperationState.Unknown;
        public DoorOperationState OperationState
        {
            get { return readerState; }
            set { readerState = value; }
        }

        /// <summary>
        /// Return value of the update agent state function
        /// </summary>
        private bool strikeActivated = false;
        public bool StrikeActivated
        {
            get { return strikeActivated; }
        }

        private readonly object agentStateTransitionLock = new object();

        public DoorAgentContexts Context { get; set; }

        /// <summary>
        /// Update Reader Agent State
        /// </summary>
        /// <param name="context">Reader Agent Context</param>
        /// <returns>True if Door Strike Activated / False Otherwise</returns>
        public bool UpdateAgentState(DoorAgentContexts context)
        {
            Context = context;
            lock (agentStateTransitionLock)
            {
                strikeActivated = false;
                SendAccessControlTransactionEvent(TT.None);
                switch (context)
                {
                    case DoorAgentContexts.ValidCard:
                        UpdateAntipassback();
                        if (readerState != DoorOperationState.Unknown && readerState != DoorOperationState.Closed &&
                            readerState != DoorOperationState.Opening)
                            break;

                        accessControlTransaction.CreateAndSendTransaction(context);
                        if (readerState == DoorOperationState.Unknown || readerState == DoorOperationState.Closed)
                        {
                            if (IsDeniedAccessTimerInProgress == true)
                                StopStrikeDeniedAccessTimer();
                        }
                        readerState = DoorOperationState.Opening;
                        StartStrikeTimer();
                        strikeActivated = true;
                        break;

                    case DoorAgentContexts.DeniedAccess:
                        if (readerState != DoorOperationState.Closed && readerState != DoorOperationState.Opening)
                            break;

                        if (readerState == DoorOperationState.Opening)
                            StopStrikeDeniedAccessTimer();
                        accessControlTransaction.CreateAndSendTransaction(context);
                        readerState = DoorOperationState.Closed;
                        StartDeniedAccessTimer();
                        break;

                    case DoorAgentContexts.StrikeTimerExpired:
                        if (readerState == DoorOperationState.Opening)
                        {
                            accessControlTransaction.CreateAndSendTransaction(context);
                            readerState = DoorOperationState.Closed;
                            ClearValidCardTransaction();
                        }
                        break;

                    case DoorAgentContexts.DeniedTimerExpired:
                    case DoorAgentContexts.KeypadLockoutTimerExpired:
                        accessControlTransaction.CreateAndSendTransaction(context);
                        break;

                    case DoorAgentContexts.UpdateFromSchedule:
                        if (readerStatus.Mode == Reader8003ScheduleLevel.Unlocked)
                        {
                            StopStrikeDeniedAccessTimer();
                            accessControlTransaction.CreateAndSendTransaction(context);
                            readerState = DoorOperationState.UnlockedPermanently;
                            strikeActivated = true;
                        }
                        else if (readerStatus.Mode == Reader8003ScheduleLevel.Blocked)
                        {
                            readerState = DoorOperationState.Closed;
                            accessControlTransaction.CreateAndSendTransaction(context);
                        }
                        else
                        {
                            if (readerState == DoorOperationState.UnlockedPermanently)
                                readerState = DoorOperationState.Closed;
                            accessControlTransaction.CreateAndSendTransaction(context);
                        }
                        break;

                    case DoorAgentContexts.CurrentDoorStateRequest:
                        if (readerStatus.Mode == Reader8003ScheduleLevel.Unlocked)
                        {
                            readerState = DoorOperationState.UnlockedPermanently;
                            accessControlTransaction.CreateAndSendTransaction(context);
                        }
                        else
                        {
                            StopStrikeDeniedAccessTimer();
                            readerState = DoorOperationState.Closed;
                            accessControlTransaction.CreateAndSendTransaction(context);
                        }
                        break;

                    case DoorAgentContexts.WaitForPinOnInReader:
                    case DoorAgentContexts.WaitForPinOnOutReader:
                        StopStrikeDeniedAccessTimer();
                        StartKeypadInactivityReaderTimer();
                        accessControlTransaction.CreateAndSendTransaction(context);
                        break;

                    case DoorAgentContexts.EndWaitForPinOnInReader:
                    case DoorAgentContexts.EndWaitForPinOnOutReader:
                        if (IsKeypadInactivityTimerInProgress)
                        {
                            accessControlTransaction.CreateAndSendTransaction(context);
                            StopKeypadInactivityTimer();
                            NotifyPinHasBeenEntered();
                        }
                        break;

                    case DoorAgentContexts.KeypadInactivityInReaderTimerExpired:
                    case DoorAgentContexts.KeypadInactivityOutReaderTimerExpired:
                        accessControlTransaction.CreateAndSendTransaction(context);
                        NotifyKeypadInactivityTimeoutExpired();
                        ClearValidCardTransaction();
                        break;
                }

                // Produce door agent status log
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    readerStatusLogText.Length = 0;
                    readerStatusLogText.Append("[ReaderAgent] Reader Id:");
                    readerStatusLogText.Append(readerStatus.LogicalId.ToString());
                    readerStatusLogText.Append(" Context:");
                    readerStatusLogText.Append(DoorAgentBase.GetDoorAgentContextsAsText(context));
                    readerStatusLogText.Append(" State:");
                    readerStatusLogText.Append(readerState.ToString());
                    if (readerPeripheralTimers != DoorPeripheralTimers.None)
                    {
                        readerStatusLogText.Append(" PeripheralTimer:");
                        readerStatusLogText.Append(DoorAgentBase.GetDoorPeripheralTimerAsText(readerPeripheralTimers));
                    }
                    if (IsKeypadInactivityTimerInProgress)
                        readerStatusLogText.Append(" KeyReaderTimer:Yes");
                    if (strikeActivated)
                        readerStatusLogText.Append(" StrikeActive:Yes");

                    string text;
                    SecurityLevelDisplayCommand displayCommand = readerStatus.GetSecurityLevelDisplayCommand(out text);
                    readerStatusLogText.Append(" SecurityLevelDisplay:" + displayCommand.ToString() +
                                             (string.IsNullOrEmpty(text) ? "" : ("-\"" + text + "\"")));

                    string message = readerStatusLogText.ToString();
                    readerStatusLogText.Length = 0;
                    return message;
                });

                return strikeActivated;
            }
        }

        public void ResetAgent()
        {
            ClearValidCardTransaction();
            StopStrikeDeniedAccessTimer();
            if (readerStatus.Mode == Reader8003ScheduleLevel.Unlocked)
                readerState = DoorOperationState.UnlockedPermanently;
            else
                readerState = DoorOperationState.Closed;
            accessControlTransaction.CreateAndSendTransaction(DoorAgentContexts.None);
        }

        private void UpdateAntipassback()
        {
            if (readerTransaction.Valid)
            {
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Antipassback: Update for reader {0} with {1}.",
                        readerStatus.LogicalId, readerTransaction.Card.ToString());
                });
#endif
                StatusManager.Instance.Doors.TriggerUpdateAntipassbackInfo(0, readerStatus.LogicalId, readerTransaction.CardInformation);
            }
        }

        private void NotifyPinHasBeenEntered()
        {
            if (readerTransaction.IsCardAssigned && readerTransaction.IsPinAssigned)
                StatusManager.Instance.Doors.TriggerCardAndPinEntered(0, readerStatus.LogicalId, readerTransaction.Card, readerTransaction.Pin);
        }

        private void NotifyKeypadInactivityTimeoutExpired()
        {
            if (readerTransaction.IsCardAssigned)
                StatusManager.Instance.Doors.TriggerKeypadInactivityTimeoutExpired(0, readerStatus.LogicalId);
        }

        #region Keypad Reader Inactivity Management

        private void StartKeypadInactivityReaderTimer()
        {
            keypadInactivityTimerInProgress = true;
            keypadInactivityTimer.RunOnce(this.keypadInactivityTimeout);
        }

        private void StopKeypadInactivityTimer()
        {
            keypadInactivityTimer.Stop();
            keypadInactivityTimerInProgress = false;
        }

        /// <summary>
        /// Keypad Inactivity Timer On Reader In Progress
        /// </summary>
        private bool keypadInactivityTimerInProgress = false;
        public bool IsKeypadInactivityTimerInProgress
        {
            get { return keypadInactivityTimerInProgress; }
        }

        private void keypadInactivityTimerProc(object state)
        {
            if (disposing == true || disposed == true)
                return;
            keypadInactivityTimerInProgress = false;
            UpdateAgentState(DoorAgentContexts.KeypadInactivityInReaderTimerExpired);
        }

        #endregion

        #region Strike and Denied Access Managment

        private DoorPeripheralTimers readerPeripheralTimers = DoorPeripheralTimers.None;
        public DoorPeripheralTimers PeripheralTimers
        {
            get { return readerPeripheralTimers; }
            set { readerPeripheralTimers = value; }
        }

        private void StopStrikeDeniedAccessTimer()
        {
            deactivateStrikeDeniedAccessTimer.Stop();
            readerPeripheralTimers = DoorPeripheralTimers.None;
        }

        private void StartStrikeTimer(int strikeTimeValue)
        {
            readerPeripheralTimers = DoorPeripheralTimers.StrikeInProgress;
            deactivateStrikeDeniedAccessTimer.RunOnce(strikeTimeValue);
        }

        private void StartStrikeTimer()
        {
            readerPeripheralTimers = DoorPeripheralTimers.StrikeInProgress;
            deactivateStrikeDeniedAccessTimer.RunOnce(strikeTime);
        }

        private void StartDeniedAccessTimer()
        {
            readerPeripheralTimers = DoorPeripheralTimers.AccessDeniedInProgress;
            deactivateStrikeDeniedAccessTimer.RunOnce(AccessDeniedDuration);
        }

        /// <summary>
        /// Check if Access Denied is in progress
        /// </summary>
        public bool IsDeniedAccessTimerInProgress
        {
            get { return readerPeripheralTimers == DoorPeripheralTimers.AccessDeniedInProgress; }
        }

        private void deactivateStrikeDeniedAccessProc(object state)
        {
            if (disposing == true || disposed == true)
                return;

            switch (readerPeripheralTimers)
            {
                case DoorPeripheralTimers.StrikeInProgress:
                    readerPeripheralTimers = DoorPeripheralTimers.None;
                    UpdateAgentState(DoorAgentContexts.StrikeTimerExpired);
                    break;
                case DoorPeripheralTimers.AccessDeniedInProgress:
                    readerPeripheralTimers = DoorPeripheralTimers.None;
                    UpdateAgentState(DoorAgentContexts.DeniedTimerExpired);
                    break;
            }
        }

        #endregion

        #region IDisposable Members

        bool disposed = false;

        bool disposing = false;

        private void Dispose(bool disposing)
        {
            try
            {
                if (disposed == false)
                {
                    if (disposing)
                    {
                        this.disposing = true;

                        if (deactivateStrikeDeniedAccessTimer != null)
                        {
                            TimerManager.Instance.RemoveTimer(deactivateStrikeDeniedAccessTimer);
                            deactivateStrikeDeniedAccessTimer = null;
                        }

                        if (accessControlTransaction != null)
                        {
                            accessControlTransaction.Dispose();
                            accessControlTransaction = null;
                        }
                        readerState = DoorOperationState.Unknown;
                        
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Reader agent for ReaderId={0} - Successfully Destroyed.", readerStatus.LogicalId);
                        });
                    }
                    disposed = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while disposing reader agent. {0}", ex.ToString());
                });
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
