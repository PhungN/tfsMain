﻿using Pacom.Core.Contracts;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    public class InovonicsRepeaterStatus : InovonicsTransceiverOrRepeaterStatusBase, IDevicePowerSupplyStatus
    {
        /// <summary>
        /// Power Supply status
        /// </summary>
        private PowerFailState powerState = PowerFailState.None;
        private PowerFailState maskedPowerState = PowerFailState.None;

        /// <summary>
        /// Serial Receiver Receiver Jammed status
        /// </summary>
        private bool receiverJammed = false;
        private bool maskedReceiverJammed = false;

        private const EventSourceLatchOrIsolateType flags = EventSourceLatchOrIsolateType.PowerFail | EventSourceLatchOrIsolateType.SignalFail;

        private readonly object sync = new object();

        public InovonicsRepeaterStatus(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus)
            : base(configuration, parent, previousStatus)
        {
            SupportedIsolateFlags |= flags;

            InovonicsRepeaterStatusStorage inovonicsPreviousStatus = previousStatus as InovonicsRepeaterStatusStorage;
            if (inovonicsPreviousStatus == null || this.Enabled == false)
                return;

            if (HardwareType == previousStatus.HardwareType)
            {
                this.powerState = inovonicsPreviousStatus.PowerState;
                this.maskedPowerState = inovonicsPreviousStatus.MaskedPowerState;
                this.receiverJammed = inovonicsPreviousStatus.ReceiverJammed;
                this.maskedReceiverJammed = inovonicsPreviousStatus.MaskedReceiverJammed;
                VerifyMaskedAlarms();
            }
        }

                /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            if (base.LatchAfterFirstAlarm(suspectStatusType) == true)
                return true;
            if (suspectStatusType == EventSourceLatchOrIsolateType.PowerFail)
                return ConfigurationManager.Instance.ControllerConfiguration.LatchPrimaryPowerSourceAlarms;
            if (suspectStatusType == EventSourceLatchOrIsolateType.SignalFail)
                return ConfigurationManager.Instance.ControllerConfiguration.LatchSignalFailAlarms;

            return false;
        }

        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get { return base.IsCurrentlyLatched || latchedAlarms.HasAny(flags); }
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = base.CurrentAlarms;
                if (maskedPowerState != PowerFailState.None)
                    flags |= EventSourceLatchOrIsolateType.PowerFail;
                if (maskedReceiverJammed == true)
                    flags |= EventSourceLatchOrIsolateType.SignalFail;
                return flags;
            }
        }

        /// <summary>
        /// Get / Set unmasked receiver jammed status.
        /// </summary>
        public bool ReceiverJammed
        {
            get { return receiverJammed; }
            set
            {
                if (Enabled == false)
                    return;
                if (receiverJammed != value)
                {
                    receiverJammed = value;
                    MaskedReceiverJammed = receiverJammed;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set masked receiver jammed status, send status changed event to front-end if required.
        /// </summary>
        public bool MaskedReceiverJammed
        {
            get { return maskedReceiverJammed; }
            set
            {
                if (Enabled == false)
                    return;
                if (maskedReceiverJammed != value || value == true)
                {
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail) == false &&
                        SuspectPoint == false &&
                        (LatchedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail) == false || value == true))
                    {
                        maskedReceiverJammed = value;
                        if (maskedReceiverJammed == true)
                        {
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.SignalFail);
                            CheckTerminateArming();
                        }
                        else
                        {
                            CheckStopFailToArmTimer();
                        }
                        Parent.TriggerReceiverJammedChangedStatus(this, maskedReceiverJammed);
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        public PowerFailState PowerState
        {
            get { return powerState; }
            set
            {
                if (Enabled == false)
                    return;
                if (powerState != value)
                {
                    powerState = value;
                    SetMaskedPowerState(powerState, false);
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        public bool ACFail
        {
            get
            {
                if (powerState == PowerFailState.None)
                    return false;
                return true;
            }
            set
            {
                if (value)
                    PowerState = PowerFailState.Fail;
                else
                    PowerState = PowerFailState.None;
            }
        }

        public PowerFailState MaskedPowerState
        {
            get { return maskedPowerState; }
        }

        public void SetMaskedPowerState(PowerFailState value, bool acFailDelayExpired)
        {
            if (Enabled == false)
                return;

            lock (sync)
            {
                if (value != PowerFailState.Fail)
                    Parent.StopACFailDelay(LogicalId);

                if (maskedPowerState != value || value != PowerFailState.None)
                {
                    // Return immediately if all alarms are isolate, if the point has been flagged as suspect or
                    // if the power supply returns to a no alarm state when all alarm types are latched.
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) || SuspectPoint ||
                        (value == PowerFailState.None && LatchedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail)))
                    {
                        return;
                    }

                    PowerFailState previousMaskedState = maskedPowerState;

                    if (value == PowerFailState.Fail && acFailDelayExpired == false && IsDelayedACFail == true)
                    {
                        // If AC Fail value has changed we can't update the masked value yet if there is an AC Fail delay and it hasn't expired yet
                        Parent.StartACFailDelay(LogicalId);
                    }
                    else
                    {
                        maskedPowerState = value;
                        SendPowerSupplyAlarm(maskedPowerState, previousMaskedState);
                    }
                }
            }
        }

        public BatteryFailState MaskedBatteryState
        {
            get { return BatteryFailState.None; }
        }

        public bool MaskedBatteryChargerFailed
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Set the state of device IsolatedAlarms flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="value">New isolated options. If value = EventSourceLatchOrIsolateType.None -> Deisolate all.
        /// If value = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.Tamper -> Isolate all or any.
        /// When de-isolating if any of the device inputs is in alarm the alarm will be queued into AlarmManager.
        /// </param>
        /// <returns>True if the command was successfully executed</returns>
        public override bool SetIsolated(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType value)
        {
            if (base.SetIsolated(userAuditInfo, value) == false)
                return false;

            // Mask-out all flags this device does not support
            value &= SupportedIsolateFlags;
            if (value != isolatedAlarms)
            {
                SetIsolated(value, EventSourceLatchOrIsolateType.PowerFail, powerState);
                SetIsolated(value, EventSourceLatchOrIsolateType.SignalFail, false, receiverJammed);
                StatusManager.Instance.RequestStatusToStorage();
            }
            return true;
        }

        /// <summary>
        /// Update the isolatedOptions flag for one isolate option only: e.g.: Offline, Tamper, etc.
        /// </summary>
        /// <param name="newIsolateOptions">New isolated options</param>
        /// <param name="optionToCheck">One option to isolate.</param>
        /// <param name="secureValue">Option secure value: Offline = true, Tamper = false, etc.</param>
        /// <param name="unmaskedValue">Unmasked option value</param>
        protected void SetIsolated(EventSourceLatchOrIsolateType newIsolateOptions, EventSourceLatchOrIsolateType optionToCheck, PowerFailState unmaskedValue)
        {
            if (isolatedAlarms.BitChanged(newIsolateOptions, optionToCheck) == true)
            {
                isolatedAlarms = isolatedAlarms.ClearFlag(optionToCheck);
                bool isolated = isolatedAlarms.BitSetAfter(newIsolateOptions, optionToCheck);
                if (isolated == true)
                {
                    // Isolate option to check (e.g.: Offline / Tamper / etc.)
                    ResetSuspectCount();
                    latchedAlarms = latchedAlarms.ClearFlag(optionToCheck);
                    SetMaskedPowerState(PowerFailState.None, true);
                    isolatedAlarms = isolatedAlarms.SetFlag(optionToCheck);
                }
                else
                {
                    // Deisolate option to check
                    SetMaskedPowerState(unmaskedValue, true);
                }
            }
        }

        /// <summary>
        /// Set masked status for [optionToCheck] to [newValue]
        /// </summary>
        /// <param name="optionToCheck">Option to check, e.g.: Offline, Tamper, InternalBatteryFail, etc.</param>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(EventSourceLatchOrIsolateType optionToCheck, bool newValue)
        {
            if (base.SetMaskedStatus(optionToCheck, newValue))
                return true;
            if (optionToCheck == EventSourceLatchOrIsolateType.SignalFail)
                MaskedReceiverJammed = newValue;
            return true;
        }

        /// <summary>
        /// Restore masked online, device tamper, etc. status if required after unlatching the device alarms. Restore only if the
        /// current instantaneous status is Secure (device online, tamper secure, etc.).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        protected override void RestoreAfterUnlatch(UserAuditInfo userAuditInfo)
        {
            base.RestoreAfterUnlatch(userAuditInfo);
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) == false && PowerState == PowerFailState.None)
                SetMaskedPowerState(PowerState, true);
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail) == false && ReceiverJammed == false)
                MaskedReceiverJammed = ReceiverJammed;
        }

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        public override bool CanIsolate(UserAccessLevel level)
        {
            if (level == UserAccessLevel.AccessLevel3)
                return true;

            if (CurrentAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) == true)
                return true;
            return false;
        }

        /// <summary>
        /// True if this status item can be de-isolated at the specifed access level
        /// </summary>
        public override bool CanDeisolate(UserAccessLevel level)
        {
            if (level == UserAccessLevel.AccessLevel3)
                return true;

            if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) == true)
                return true;
            return false;
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            InovonicsRepeaterStatusStorage statusStorage = new InovonicsRepeaterStatusStorage();
            if (statusStorage != null)
            {
                InitializeStatusStorage(statusStorage, false);
                statusStorage.PowerState = PowerState;
                statusStorage.MaskedPowerState = MaskedPowerState;
                statusStorage.ReceiverJammed = ReceiverJammed;
                statusStorage.MaskedReceiverJammed = MaskedReceiverJammed;
            }
            return statusStorage;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            DeviceInovonicsRepeaterEventState deviceState = new DeviceInovonicsRepeaterEventState();
            InitializeEventState(deviceState);
            deviceState.InternalBatteryLow = MaskedInternalBatteryLow;
            deviceState.PowerFail = MaskedPowerState;
            deviceState.ReceiverJammed = MaskedReceiverJammed;
            deviceState.SignalLevel = SignalLevel;
            deviceState.SignalMargin = SignalMargin; 
            return deviceState;
        }

        /// <summary>
        /// Check masked alarms when we restore status from previous stored state
        /// </summary>
        protected override void VerifyMaskedAlarms()
        {
            base.VerifyMaskedAlarms();
            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail))
            {
                maskedPowerState = PowerFailState.None;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.PowerFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail))
            {
                if (maskedPowerState == PowerFailState.None)
                    maskedPowerState = PowerFailState.Fail;
            }
            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail))
            {
                maskedReceiverJammed = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.SignalFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail))
            {
                maskedReceiverJammed = true;
            }
        }
    }
}
