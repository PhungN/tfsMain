﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using System.Security.Cryptography;
using Pacom.Peripheral.Common.Status.FrontEndConnection;

namespace Pacom.Peripheral.Common.Status
{
    public class FrontEndConnectionStatus : StatusBase<Object>
    {
        private const int nextCommandSessionIdListLength = 10;
        List<ProtocolServiceIdAndCommandSessionId> nextCommandSessionIdList = new List<ProtocolServiceIdAndCommandSessionId>(nextCommandSessionIdListLength);

        public FrontEndConnectionStatus(ControllerConnectionTable controllerConnectionTable)
            : base(controllerConnectionTable, null)
        {
            NextConnectionTime = new TimeLimit();
            NextEventSessionId = 0;
            LastValidCommandId = -1;
            CommandSessionValidTill = new TimeLimit();
            CommandSessionAuthenticator = null;
            CommandSessionEncryptor = null;
            CommandSessionDecryptor = null;
            PendingNodeStatusEvent = null;
            siaSequenceNumber = 1;
        }

        public override StatusItemType ItemType
        {
            get { return StatusItemType.FrontEndConnectionStatus; }
        }

        public TimeLimit NextConnectionTime { get; set; }

        public UInt32 NextEventSessionId { get; set; }

        public UInt32 GetNextCommandSessionId(uint protocolServiceId)
        {
            ProtocolServiceIdAndCommandSessionId nextCommandSessionId;
            lock (nextCommandSessionIdList)
            {
                for (int i = 0; i < nextCommandSessionIdList.Count; i++)
                {
                    nextCommandSessionId = nextCommandSessionIdList[i];
                    if (nextCommandSessionId.ProtocolServiceId == protocolServiceId)
                    {
                        if (i != (nextCommandSessionIdList.Count - 1))
                        {
                            nextCommandSessionIdList.RemoveAt(i);
                            nextCommandSessionIdList.Add(nextCommandSessionId);
                        }
                        return nextCommandSessionId.CommandSessionId;
                    }
                }
                if (nextCommandSessionIdList.Count == nextCommandSessionIdListLength)
                    nextCommandSessionIdList.RemoveAt(0);
                nextCommandSessionId = new ProtocolServiceIdAndCommandSessionId();
                nextCommandSessionId.ProtocolServiceId = protocolServiceId;
                nextCommandSessionId.CommandSessionId = (uint)(new Random().Next());
                nextCommandSessionIdList.Add(nextCommandSessionId);
                return nextCommandSessionId.CommandSessionId;
            }
        }

        public void SetNextCommandSessionId(uint protocolServiceId, uint commandSessionId)
        {
            ProtocolServiceIdAndCommandSessionId nextCommandSessionId;
            lock (nextCommandSessionIdList)
            {
                for (int i = 0; i < nextCommandSessionIdList.Count; i++)
                {
                    nextCommandSessionId = nextCommandSessionIdList[i];
                    if (nextCommandSessionId.ProtocolServiceId == protocolServiceId)
                    {
                        if (i != (nextCommandSessionIdList.Count - 1))
                        {
                            nextCommandSessionIdList.RemoveAt(i);
                            nextCommandSessionIdList.Add(nextCommandSessionId);
                        }
                        nextCommandSessionId.CommandSessionId = commandSessionId;
                        return;
                    }
                }
                if (nextCommandSessionIdList.Count == nextCommandSessionIdListLength)
                    nextCommandSessionIdList.RemoveAt(0);
                nextCommandSessionId = new ProtocolServiceIdAndCommandSessionId();
                nextCommandSessionId.ProtocolServiceId = protocolServiceId;
                nextCommandSessionId.CommandSessionId = commandSessionId;
                nextCommandSessionIdList.Add(nextCommandSessionId);
            }
        }

        public int LastValidCommandId { get; set; }

        public int NextResponseId { get; set; }

        public TimeLimit CommandSessionValidTill { get; set; }

        public UInt32 NextDataTransferSessionId { get; set; }

        public IMacGenerator CommandSessionAuthenticator { get; set; }

        public ICryptoTransform CommandSessionEncryptor { get; set; }

        public ICryptoTransform CommandSessionDecryptor { get; set; }

        public UInt32 CurrentCommandSessionId { get; set; }

        public byte[] PendingNodeStatusEvent { get; set; }

        /// <summary>
        /// SIA DC-09 unique message sequence number
        /// </summary>
        private int siaSequenceNumber = 1;
        public int SiaSequenceNumber 
        {
            get { return siaSequenceNumber; }
        }

        /// <summary>
        /// Increment SIA DC-09 sequence number. Get next available sequence number for the message that will 
        /// be encoded and sent to the CSR. The sequence numbers are in the range [1 - 9999]. When the seqence 
        /// number reaches 9999 the next sequence number will be reset to 1.
        /// </summary>
        public void IncrementSiaSequenceNumber()
        {
            // Increment sequence number
            if (++siaSequenceNumber > 9999)
            {
                // Reset sequence number
                siaSequenceNumber = 1;
            }
        }

        internal void Update(ControllerConnectionTable controllerConnectionTable)
        {
            if (controllerConnectionTable != null)
                base.LogicalId = controllerConnectionTable.Id;
            else
                base.LogicalId = 0;
        }

        /// <summary>
        /// Isolate Front end connection
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Isolate(UserAuditInfo userAuditInfo)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return "Front end connection does not implement isolate.";
            });
        }

        /// <summary>
        /// Deisolate Front end connection.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        public override void Deisolate(UserAuditInfo userAuditInfo)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return "Front end connection does not implement deisolate.";
            });
        }

        public override string ToString()
        {
            return String.Format("Front end Connection Status");
        }
    }
}
