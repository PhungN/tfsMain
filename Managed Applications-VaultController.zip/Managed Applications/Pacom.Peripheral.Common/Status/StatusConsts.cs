﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    public class StatusConsts
    {
        private StatusConsts() { }

        /// <summary>
        /// Undefined user.
        /// </summary>
        public const int UndefinedUser = -1;

        /// <summary>
        /// User id used by schedule to switch mode.
        /// </summary>
        public const int ScheduleUser = -2;

        /// <summary>
        /// User id used by macros.
        /// </summary>
        public const int MacroUser = -3;

        /// <summary>
        /// User id used by commands from the front end.
        /// </summary>
        public const int FrontEndUser = -4;

        /// <summary>
        /// Web access User Id - used when changing configuration, etc. from the controller WebServer
        /// </summary>
        public const int WebServerUser = -5;

        /// <summary>
        /// System User Id - used when initializing controller / auto-configuring devices / etc.
        /// </summary>
        public const int SystemUser = -6;

        /// <summary>
        /// Undefined group.
        /// </summary>
        public const int UndefinedGroup = -1;

        /// <summary>
        /// Undefined logical Id.
        /// </summary>
        public const int UndefinedLogicalId = -1;

        /// <summary>
        /// Undefined device Id.
        /// </summary>
        public const int UndefinedDeviceId = -1;
    }
}
