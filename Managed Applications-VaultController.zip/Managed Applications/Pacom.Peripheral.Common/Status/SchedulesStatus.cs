﻿using System;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Status
{
    public class SchedulesStatus
    {
        private IPacomTimer schedulesTimer = null;
        public Schedule[] Schedules { get; set; }
        public event EventHandler<SchedulesChangedEventArgs> SchedulesStatusChanged = null;
        public event EventHandler<SchedulesChangedEventArgs> SchedulesConfigurationChanged = null;

        public SchedulesStatus(Schedule[] schedules)
        {
            Schedules = schedules;
            schedulesTimer = TimerManager.Instance.CreateTimer(schedulesTimerProc);
            recalculateSchedules(false);
        }

        private void schedulesTimerProc(object state)
        {
            recalculateSchedules(true);
        }

        public void UpdateSchedules(Schedule[] schedules)
        {
            Schedules = schedules;
            recalculateSchedules(false);
        }

        public void ShutDown()
        {
            if (schedulesTimer != null)
            {
                schedulesTimer.Stop();
                TimerManager.Instance.RemoveTimer(schedulesTimer);
            }
        }

        private void recalculateSchedules(bool isTimeout)
        {
            DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
            var scheduleIntervalDetailsList = new List<ScheduleIntervalDetails>();
            ScheduleIntervalDetails nextScheduleIntervalDetails = null;
            foreach (var schedule in Schedules)
            {
                if (schedule != null)
                {
                    var scheduleIntervalDetails = getScheduleIntervalDetails(schedule, now);
                    if (scheduleIntervalDetails != null)
                    {
                        scheduleIntervalDetailsList.Add(scheduleIntervalDetails);
                        if (nextScheduleIntervalDetails == null)
                            nextScheduleIntervalDetails = scheduleIntervalDetails;
                        else if (nextScheduleIntervalDetails.EndTime.TimeOfDay > scheduleIntervalDetails.EndTime.TimeOfDay)
                            nextScheduleIntervalDetails = scheduleIntervalDetails;
                    }
                }
            }
            if (nextScheduleIntervalDetails != null)
            {
                var nextScheduleTime = (int)(nextScheduleIntervalDetails.EndTime.TimeOfDay.TotalMilliseconds - now.TimeOfDay.TotalMilliseconds);
                if (nextScheduleTime <= 0)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                    {
                        return string.Format("Next scheduled start time is not in the future: Now = [{0}], NextStartTime = [{1}]",
                            now.ToString("dd/MM/yyyy HH:mm:ss.fff"), nextScheduleIntervalDetails.EndTime.ToString("dd/MM/yyyy HH:mm:ss.fff"));
                    });
                    schedulesTimer.RunOnce(1000);
                    return;
                }
                schedulesTimer.RunOnce(nextScheduleTime);
                if (isTimeout == true)
                {
                    if (SchedulesStatusChanged != null)
                    {
                        var scheduleList = scheduleIntervalDetailsList.Select(item => { return item.StartTime.Hour == now.Hour && item.StartTime.Minute == now.Minute; });
                        SchedulesStatusChanged.Invoke(this, new SchedulesChangedEventArgs(scheduleList));
                    }
                }
                else if (SchedulesConfigurationChanged != null)
                {
                    SchedulesConfigurationChanged.Invoke(this, new SchedulesChangedEventArgs(scheduleIntervalDetailsList));
                }
            }

        }

        private ScheduleIntervalDetails getScheduleIntervalDetails(Schedule schedule, DateTime now)
        {
            var scheduleRecord = ConfigurationManager.Instance.GetTodaySchedule(schedule);
            if (scheduleRecord != null)
            {
                DateTime midNight = new DateTime(now.Year, now.Month, now.Day, 23, 59, 59, 999);
                List<ScheduleInterval> scheduleIntervals = new List<ScheduleInterval>(scheduleRecord.Intervals);
                if (scheduleIntervals.Count == 0 || scheduleIntervals[0].StartTime.TimeOfDay.TotalMinutes > 0)
                {
                    scheduleIntervals.Insert(0, new ScheduleInterval()
                    {
                        StartTime = new DateTime(now.Year, now.Month, now.Day, 0, 0, 0),
                        Level = 0
                    });
                }
                for (int n = 0; n < scheduleIntervals.Count; n++)
                {
                    var scheduleInterval = scheduleIntervals[n];
                    DateTime startTime = scheduleInterval.StartTime;
                    DateTime endTime = (n + 1 < scheduleIntervals.Count) ? scheduleIntervals[n + 1].StartTime : midNight;
                    if (now.TimeOfDay >= startTime.TimeOfDay && now.TimeOfDay <= endTime.TimeOfDay)
                    {
                        return new ScheduleIntervalDetails(schedule.Id, startTime, endTime, scheduleInterval.Level);
                    }
                }
            }
            return null;
        }
    }
    
}
