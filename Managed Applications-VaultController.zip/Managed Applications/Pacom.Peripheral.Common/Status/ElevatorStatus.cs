﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using System.Threading;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status;

namespace Pacom.Peripheral.Common.Status
{
    public sealed class ElevatorStatus : StatusBase<ElevatorStatusList>
    {
        public ElevatorStatus(ConfigurationBase configuration, ElevatorStatusList parent, ElevatorStatusStorage previousStatus) :
            base(configuration, parent)
        {
            RefreshAfterConfigurationChange();
        }

        internal void RefreshAfterConfigurationChange()
        {
            
        }

        public override StatusItemType ItemType
        {
            get { return StatusItemType.ElevatorStatus; }
        }

        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            ElevatorStatusStorage statusStorage = new ElevatorStatusStorage();
            statusStorage.LogicalId = LogicalId;
            statusStorage.ParentDeviceId = ParentDeviceId;
            return statusStorage;
        }

        public override NodeStateBase CreateEventState()
        {
            ElevatorEventState elevatorEventState = new ElevatorEventState();
            elevatorEventState.Id = LogicalId;
            return elevatorEventState;
        }

        public override void Isolate(UserAuditInfo userAuditInfo)
        {
        }

        public override void Deisolate(UserAuditInfo userAuditInfo)
        {
        }

        public override string DisplayName
        {
            get
            {
                var elevator = ConfigurationManager.Instance.GetElevatorConfiguration(LogicalId);
                if (elevator != null)
                    return string.Format("{0}{1} {2}", ConfigurationManager.Instance.ControllerConfiguration.ElevatorControllerPrefixText, LogicalId, elevator.GetName());
                return string.Empty;
            }
        }

        public override string ToString()
        {
            return String.Format("Elevator Status [{0}]", this.LogicalId);
        }
    }
}

