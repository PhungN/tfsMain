﻿using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Events.EventsCommon;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Status
{
    public sealed class PowerSupplyDeviceStatus : DeviceLoopDeviceStatus, IDevicePowerSupplyStatus, IDeviceLocalPowerSupplyStatus
    {
        /// <summary>
        /// Power Supply status
        /// </summary>
        private PowerFailState powerState = PowerFailState.None;
        private PowerFailState maskedPowerState = PowerFailState.None;

        /// <summary>
        /// Battery status
        /// </summary>
        private BatteryFailState batteryState = BatteryFailState.None;
        private BatteryFailState maskedBatteryState = BatteryFailState.None;

        /// <summary>
        /// Battery charger status
        /// </summary>
        private bool batteryChargerFailed = false;
        private bool maskedBatteryChargerFailed = false;

        /// <summary>
        /// Power Supply fuse failed
        /// </summary>
        private bool fuseFailed = false;
        private bool maskedFuseFailed = false;

        /// <summary>
        /// Power Supply temperature is outside the configured range
        /// </summary>
        private bool temperatureFailed = false;
        private bool maskedTemperatureFailed = false;

        private bool isControllerPowerSupply = false;
        private bool batteryTestInProgress = false;

        private readonly object sync = new object();

        public PowerSupplyDeviceStatus(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus) :
            base(configuration, parent, previousStatus)
        {
            SupportedIsolateFlags |= EventSourceLatchOrIsolateType.PowerFail | EventSourceLatchOrIsolateType.BatteryFail |
                                     EventSourceLatchOrIsolateType.BatteryChargerFail | EventSourceLatchOrIsolateType.FuseFail | 
                                     EventSourceLatchOrIsolateType.TemperatureFail;
            Pacom8303Configuration config = configuration as Pacom8303Configuration;
            if (config != null)
                isControllerPowerSupply = config.ControllersPowerSupply;

            if (previousStatus == null || this.Enabled == false)
                return;

            if (this.HardwareType == previousStatus.HardwareType)
            {
                this.isolatedAlarms = previousStatus.IsolatedAlarms;
                this.latchedAlarms = previousStatus.LatchedAlarms;
                VerifyMaskedAlarms();
            }
        }

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            switch (suspectStatusType)
            {
                case EventSourceLatchOrIsolateType.Offline: return ConfigurationManager.Instance.ControllerConfiguration.LatchOfflineAlarms;
                case EventSourceLatchOrIsolateType.Tamper: return ConfigurationManager.Instance.ControllerConfiguration.LatchTamperAlarms;
                case EventSourceLatchOrIsolateType.PowerFail: return ConfigurationManager.Instance.ControllerConfiguration.LatchPrimaryPowerSourceAlarms;
                case EventSourceLatchOrIsolateType.BatteryFail: return ConfigurationManager.Instance.ControllerConfiguration.LatchSecondaryPowerSourceAlarms;
                case EventSourceLatchOrIsolateType.BatteryChargerFail: return ConfigurationManager.Instance.ControllerConfiguration.LatchBatteryChargerFailAlarms;
                case EventSourceLatchOrIsolateType.FuseFail: return ConfigurationManager.Instance.ControllerConfiguration.LatchFuseFailAlarms;
                case EventSourceLatchOrIsolateType.TemperatureFail: return ConfigurationManager.Instance.ControllerConfiguration.LatchTemperatureAlarms;
                case EventSourceLatchOrIsolateType.DeviceSubstitution: return true;
                default: return false;
            }
        }

        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get
            {
                return base.IsCurrentlyLatched || 
                    latchedAlarms.HasAny(EventSourceLatchOrIsolateType.PowerFail | EventSourceLatchOrIsolateType.BatteryFail |
                                         EventSourceLatchOrIsolateType.BatteryChargerFail | EventSourceLatchOrIsolateType.FuseFail | 
                                         EventSourceLatchOrIsolateType.TemperatureFail);
            }
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = base.CurrentAlarms;
                if (maskedPowerState != PowerFailState.None)
                    flags |= EventSourceLatchOrIsolateType.PowerFail;
                if (maskedBatteryState != BatteryFailState.None)
                    flags |= EventSourceLatchOrIsolateType.BatteryFail;
                if (maskedBatteryChargerFailed == true)
                    flags |= EventSourceLatchOrIsolateType.BatteryChargerFail;
                if (maskedFuseFailed == true)
                    flags |= EventSourceLatchOrIsolateType.FuseFail;
                if (maskedTemperatureFailed == true)
                    flags |= EventSourceLatchOrIsolateType.TemperatureFail;
                return flags;
            }
        }

        public PowerFailState PowerState
        {
            get { return powerState; }
            set
            {
                if (Enabled == false)
                    return;
                if (powerState != value)
                {
                    powerState = value;
                    SetMaskedPowerState(powerState, false);
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        public PowerFailState MaskedPowerState
        {
            get { return maskedPowerState; }
        }

        public void SetMaskedPowerState(PowerFailState value, bool acFailDelayExpired)
        {
            if (Enabled == false)
                return;

            lock (sync)
            {
                if (value != PowerFailState.Fail)
                    Parent.StopACFailDelay(LogicalId);

                if (maskedPowerState != value || value != PowerFailState.None)
                {
                    // Return immediately if all alarms are isolate, if the point has been flagged as suspect or
                    // if the power supply returns to a no alarm state when all alarm types are latched.
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) || SuspectPoint ||
                        (value == PowerFailState.None && LatchedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail)))
                    {
                        return;
                    }

                    PowerFailState previousMaskedState = maskedPowerState;

                    if (value == PowerFailState.Fail && acFailDelayExpired == false && IsDelayedACFail == true)
                    {
                        // If AC Fail value has changed we can't update the masked value yet if there is an AC Fail delay and it hasn't expired yet
                        Parent.StartACFailDelay(LogicalId);
                    }
                    else
                    {
                        maskedPowerState = value;

                        SendPowerSupplyAlarm(maskedPowerState, previousMaskedState);
                        if (isControllerPowerSupply == true)
                            StatusManager.Instance.Controller.UpdateDeviceLoopPowerSupplyStatus();
                    }
                }
            }
        }

        public BatteryFailState BatteryState
        {
            get { return batteryState; }
            set
            {
                if (Enabled == false)
                    return;
                if (batteryState != value)
                {
                    batteryState = value;
                    MaskedBatteryState = batteryState;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        public BatteryFailState MaskedBatteryState
        {
            get { return maskedBatteryState; }
            set
            {
                if (Enabled == false)
                    return;

                lock (sync)
                {
                    if (maskedBatteryState != value || value != BatteryFailState.None)
                    {
                        // Return immediately if all alarms are isolate, if the point has been flagged as suspect or
                        // if the power supply returns to a no alarm state when all alarm types are latched.
                        if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail) || SuspectPoint ||
                            (value == BatteryFailState.None && LatchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail)))
                        {
                            return;
                        }

                        BatteryFailState previousMaskedState = maskedBatteryState;
                        maskedBatteryState = value;

                        SendPowerSupplyAlarm(maskedBatteryState, previousMaskedState);
                        if (isControllerPowerSupply == true)
                            StatusManager.Instance.Controller.UpdateDeviceLoopPowerSupplyStatus();
                    }
                }
            }
        }

        public bool BatteryChargerFailed
        {
            get { return batteryChargerFailed; }
            set
            {
                if (Enabled == false)
                    return;
                if (batteryChargerFailed != value)
                {
                    batteryChargerFailed = value;
                    MaskedBatteryChargerFailed = batteryChargerFailed;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        public bool MaskedBatteryChargerFailed
        {
            get { return maskedBatteryChargerFailed; }
            set
            {
                if (Enabled == false)
                    return;

                lock (sync)
                {
                    if (maskedBatteryChargerFailed != value || value == true)
                    {
                        // Return immediately if all alarms are isolate, if the point has been flagged as suspect or
                        // if the power supply returns to a no alarm state when all alarm types are latched.
                        if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail) || SuspectPoint ||
                            (value == false && LatchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail)))
                        {
                            return;
                        }

                        bool previousMaskedBatteryChargerFailed = maskedBatteryChargerFailed;
                        maskedBatteryChargerFailed = value;

                        SendPowerSupplyAlarm(maskedBatteryChargerFailed, previousMaskedBatteryChargerFailed);
                        if (isControllerPowerSupply == true)
                            StatusManager.Instance.Controller.UpdateDeviceLoopPowerSupplyStatus();
                    }
                }
            }
        }

        /// <summary>
        /// Get / Set power supply fuse failed flag
        /// </summary>
        public bool FuseFailed
        {
            get { return fuseFailed; }
            set
            {
                if (Enabled == false)
                    return;
                if (fuseFailed != value)
                {
                    fuseFailed = value;
                    MaskedFuseFailed = fuseFailed;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set masked power supply fuse failed flag
        /// </summary>
        public bool MaskedFuseFailed
        {
            get { return maskedFuseFailed; }
            private set
            {
                if (Enabled == false)
                    return;
                if (maskedFuseFailed != value || value == true)
                {
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.FuseFail) == false &&
                        SuspectPoint == false &&
                        (LatchedAlarms.Has(EventSourceLatchOrIsolateType.FuseFail) == false || value == true))
                    {
                        maskedFuseFailed = value;
                        if (maskedFuseFailed == true)
                        {
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.FuseFail);
                            CheckTerminateArming();
                        }
                        else
                        {
                            CheckStopFailToArmTimer();
                        }
                        Parent.TriggerFuseFailed(this, maskedFuseFailed);
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        /// <summary>
        /// Get / Set power supply temperature out of range flag.
        /// </summary>
        public bool TemperatureFailed
        {
            get { return temperatureFailed; }
            set
            {
                if (Enabled == false)
                    return;
                if (temperatureFailed != value)
                {
                    temperatureFailed = value;
                    MaskedTemperatureFailed = temperatureFailed;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set masked power supply temperature out of range flag.
        /// </summary>
        public bool MaskedTemperatureFailed
        {
            get { return maskedTemperatureFailed; }
            private set
            {
                if (Enabled == false)
                    return;
                if (maskedTemperatureFailed != value || value == true)
                {
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.TemperatureFail) == false &&
                        SuspectPoint == false &&
                        (LatchedAlarms.Has(EventSourceLatchOrIsolateType.TemperatureFail) == false || value == true))
                    {
                        maskedTemperatureFailed = value;
                        if (maskedTemperatureFailed == true)
                        {
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.TemperatureFail);
                            CheckTerminateArming();
                        }
                        else
                        {
                            CheckStopFailToArmTimer();
                        }
                        Parent.TriggerTemperatureFailEvent(this, maskedTemperatureFailed);
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        /// <summary>
        /// Send battery pre-warning event when AC Failed and the pre-warninging timer expired. The power supply instance will call
        /// this function.
        /// </summary>
        public void SendBatteryPreWarningEvent()
        {
            Parent.TriggerPowerSupplyBatteryPreWarningEvent(this);
            if (isControllerPowerSupply == true)
                Parent.TriggerPowerSupplyBatteryPreWarningEvent(StatusManager.Instance.Controller);
        }

        /// <summary>
        /// Set the state of device IsolatedAlarms flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="value">New isolated options. If value = EventSourceLatchOrIsolateType.None -> Deisolate all.
        /// If value = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.Tamper | EventSourceLatchOrIsolateType.InternalBatteryFail -> Isolate all or any.
        /// When de-isolating if any of the device inputs is in alarm the alarm will be queued into AlarmManager.
        /// </param>
        /// <returns>True if the command was successfully executed</returns>
        public override bool SetIsolated(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType value)
        {
            if (base.SetIsolated(userAuditInfo, value) == false)
                return false;

            // Mask-out all flags this device does not support
            value &= SupportedIsolateFlags;
            if (value != isolatedAlarms)
            {
                // Fuse Failed - Isolate/de-isolate 
                SetIsolated(value, EventSourceLatchOrIsolateType.FuseFail, false, fuseFailed);
                // Temperature Failed - Isolate/de-isolate
                SetIsolated(value, EventSourceLatchOrIsolateType.TemperatureFail, false, temperatureFailed);

                // AC Fail / Battery Fail / Charger Fail - Isolate/de-isolate
                SetIsolated(value, EventSourceLatchOrIsolateType.PowerFail, powerState);
                SetIsolated(value, EventSourceLatchOrIsolateType.BatteryFail, batteryState);
                SetIsolated(value, EventSourceLatchOrIsolateType.BatteryChargerFail, false, batteryChargerFailed);

                // If this is a power supply for the controller then restore the alarms on the controller also
                if (isControllerPowerSupply && (value.HasAny(EventSourceLatchOrIsolateType.PowerFail | EventSourceLatchOrIsolateType.BatteryFail | 
                                                EventSourceLatchOrIsolateType.BatteryChargerFail)))
                {
                    StatusManager.Instance.Controller.Unlatch(userAuditInfo, value & (EventSourceLatchOrIsolateType.PowerFail | EventSourceLatchOrIsolateType.BatteryFail |
                                                EventSourceLatchOrIsolateType.BatteryChargerFail));
                }
                StatusManager.Instance.RequestStatusToStorage();
            }
            return true;
        }

        /// <summary>
        /// Set masked status for [optionToCheck] to [newValue]
        /// </summary>
        /// <param name="optionToCheck">Option to check, e.g.: Offline, Tamper, FuseFail, TemperatureFail, etc.</param>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(EventSourceLatchOrIsolateType optionToCheck, bool newValue)
        {
            if (base.SetMaskedStatus(optionToCheck, newValue))
                return true;
            bool result = true;
            switch (optionToCheck)
            {
                case EventSourceLatchOrIsolateType.FuseFail:
                    MaskedFuseFailed = newValue;
                    break;
                case EventSourceLatchOrIsolateType.TemperatureFail:
                    MaskedTemperatureFailed = newValue;
                    break;
                case EventSourceLatchOrIsolateType.BatteryChargerFail:
                    MaskedBatteryChargerFailed = newValue;
                    break;
                default:
                    result = false;
                    break;
            }
            return result;
        }

        /// <summary>
        /// Set masked status for PowerFailState
        /// </summary>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(PowerFailState newValue)
        {
            SetMaskedPowerState(newValue, true);
            return true;
        }

        /// <summary>
        /// Set masked status for BatteryFailState
        /// </summary>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(BatteryFailState newValue)
        {
            MaskedBatteryState = newValue;
            return true;
        }

        /// <summary>
        /// Restore masked online, device tamper, etc. status if required after unlatching the device alarms. Restore only if the
        /// current instantaneous status is Secure (device online, tamper secure, etc.).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        protected override void RestoreAfterUnlatch(UserAuditInfo userAuditInfo)
        {
            base.RestoreAfterUnlatch(userAuditInfo);

            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) == false && PowerState == PowerFailState.None)
            {
                SetMaskedPowerState(PowerState, true);

                // If this is a controller power supply we also need to restore the controller as the controller can become suspect
                // from alarms that originate in the power supply.
                if (isControllerPowerSupply)
                    StatusManager.Instance.Controller.Unlatch(userAuditInfo, EventSourceLatchOrIsolateType.PowerFail);
            }
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail) == false && BatteryState == BatteryFailState.None)
            {
                MaskedBatteryState = BatteryState;

                // If this is a controller power supply we also need to restore the controller as the controller can become suspect
                // from alarms that originate in the power supply.
                if (isControllerPowerSupply)
                    StatusManager.Instance.Controller.Unlatch(userAuditInfo, EventSourceLatchOrIsolateType.BatteryFail);
            }
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail) == false && BatteryChargerFailed == false)
            {
                MaskedBatteryChargerFailed = BatteryChargerFailed;

                // If this is a controller power supply we also need to restore the controller as the controller can become suspect
                // from alarms that originate in the power supply.
                if (isControllerPowerSupply)
                    StatusManager.Instance.Controller.Unlatch(userAuditInfo, EventSourceLatchOrIsolateType.BatteryChargerFail);
            }
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.FuseFail) == false && FuseFailed == false)
                MaskedFuseFailed = FuseFailed;
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.TemperatureFail) == false && TemperatureFailed == false)
                MaskedTemperatureFailed = TemperatureFailed;
        }

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        public override bool CanIsolate(UserAccessLevel level)
        {
            if (CurrentAlarms == EventSourceLatchOrIsolateType.DeviceSubstitution)
                return false;

            if (level == UserAccessLevel.AccessLevel3)
                return true;

            if (CurrentAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) == true)
                return true;
            return false;
        }

        /// <summary>
        /// True if this status item can be de-isolated at the specifed access level
        /// </summary>
        public override bool CanDeisolate(UserAccessLevel level)
        {
            if (level == UserAccessLevel.AccessLevel3)
                return true;

            if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail) == true)
                return true;
            return false;
        }

        public void UpdatePowerSupplyInformation(PowerSupplyInformation powerSupplyInfo)
        {
            if (Online == true && powerSupplyInfo != null)
            {
                if (temperatureStatus.CurrentValue != int.MinValue)
                {
                    powerSupplyInfo.Temperature = PowerSupplyUtils.TemperatureInMilliCelcius(temperatureStatus.CurrentValue);
                    powerSupplyInfo.TemperatureMinimum = PowerSupplyUtils.TemperatureInMilliCelcius(temperatureStatus.MinValue);
                    powerSupplyInfo.TemperatureMaximum = PowerSupplyUtils.TemperatureInMilliCelcius(temperatureStatus.MaxValue);
                }
                if (batteryVoltageStatus.CurrentValue != int.MinValue)
                {
                    powerSupplyInfo.BatteryVoltage = PowerSupplyUtils.BatteryVoltageInMilliVolts(batteryVoltageStatus.CurrentValue);
                    powerSupplyInfo.BatteryVoltageMinimum = PowerSupplyUtils.BatteryVoltageInMilliVolts(batteryVoltageStatus.MinValue);
                    powerSupplyInfo.BatteryVoltageMaximum = PowerSupplyUtils.BatteryVoltageInMilliVolts(batteryVoltageStatus.MaxValue);
                }
                if (powerSupplyVoltageStatus.CurrentValue != int.MinValue)
                {
                    powerSupplyInfo.PowerSupplyVoltage = PowerSupplyUtils.InputVoltageInMilliVolts(powerSupplyVoltageStatus.CurrentValue);
                    powerSupplyInfo.PowerSupplyVoltageMinimum = PowerSupplyUtils.InputVoltageInMilliVolts(powerSupplyVoltageStatus.MinValue);
                    powerSupplyInfo.PowerSupplyVoltageMaximum = PowerSupplyUtils.InputVoltageInMilliVolts(powerSupplyVoltageStatus.MaxValue);
                }
            }
        }

        public int TemperatureAdcReading
        {
            get { return temperatureStatus.CurrentValue; }
            set { temperatureStatus.CurrentValue = value; }
        }

        public int BatteryVoltageAdcReading
        {
            get { return batteryVoltageStatus.CurrentValue; }
            set { batteryVoltageStatus.CurrentValue = value; }
        }

        public int ACVoltageAdcReading
        {
            get { return powerSupplyVoltageStatus.CurrentValue; }
            set { powerSupplyVoltageStatus.CurrentValue = value; }
        }

        public bool BatteryTestInProgress 
        {
            get { return batteryTestInProgress; }
            set
            {
                batteryTestInProgress = value;
                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        private Storage.PowerReadingStatus temperatureStatus = new Storage.PowerReadingStatus();
        private Storage.PowerReadingStatus batteryVoltageStatus = new Storage.PowerReadingStatus();
        private Storage.PowerReadingStatus powerSupplyVoltageStatus = new Storage.PowerReadingStatus();

        /// <summary>
        /// Start battery load test immediately if possible. If the battery load test is currently running return False.
        /// </summary>
        /// <returns>True if the battery load test can start, False otherwise</returns>
        public bool StartBatteryLoadTest()
        {
            Pacom8303Configuration config = ConfigurationManager.Instance.GetDeviceConfiguration(LogicalId) as Pacom8303Configuration;
            if (config != null)
            {
                int deviceId = config.DeviceLoopAddress - 1;
                if (deviceId >= 0)
                {
                    IPowerSupplyDevice powerSupply = StatusManager.Instance.DeviceLoopManager.GetPowerSupply(deviceId);
                    if (powerSupply != null)
                        return powerSupply.StartBatteryLoadTest();
                }
            }
            return false;
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            DeviceStatusStorage statusStorage = new DeviceStatusStorage();
            if (statusStorage != null)
            {
                InitializeStatusStorage(statusStorage);
            }
            return statusStorage;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            Device8303PowerSupplyEventState deviceState = new Device8303PowerSupplyEventState();
            InitializeEventState(deviceState);

            deviceState.PowerFail = MaskedPowerState;
            deviceState.BatteryFail = MaskedBatteryState;
            deviceState.TemperatureFail = MaskedTemperatureFailed;
            deviceState.BatteryChargerFail = maskedBatteryChargerFailed;
            deviceState.FuseFail = MaskedFuseFailed;
            deviceState.BatteryTestInProgress = BatteryTestInProgress;
            return deviceState;
        }

        /// <summary>
        /// Check masked alarms when we restore status from previous stored state
        /// </summary>
        protected override void VerifyMaskedAlarms()
        {
            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail))
            {
                maskedPowerState = PowerFailState.None;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.PowerFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.PowerFail))
            {
                if (maskedPowerState == PowerFailState.None)
                    maskedPowerState = PowerFailState.Fail;
            }

            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail))
            {
                maskedBatteryState = BatteryFailState.None;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.BatteryFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryFail))
            {
                if (maskedBatteryState == BatteryFailState.None)
                    maskedBatteryState = BatteryFailState.Fail;
            }

            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail))
            {
                maskedBatteryChargerFailed = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.BatteryChargerFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.BatteryChargerFail))
            {
                maskedBatteryChargerFailed = true;
            }

            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.FuseFail))
            {
                maskedFuseFailed = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.FuseFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.FuseFail))
            {
                maskedFuseFailed = true;
            }

            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.TemperatureFail))
            {
                maskedTemperatureFailed = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.TemperatureFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.TemperatureFail))
            {
                maskedTemperatureFailed = true;
            }
        }
    }
}
