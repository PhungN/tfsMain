﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Status
{
    public class ArmAreaTaskHolder : IDisposable
    {
        /// <summary>
        /// Exit timer fires every second
        /// </summary>
        private const int exitTimerDueTime = 1000;

        /// <summary>
        /// Arm area(s) with delay timer
        /// </summary>
        private IPacomTimer armingDelayTimer = null;

        private List<int> areaIds = null;

        private int remainingArmingDelay = 0;

        private int elapsedArmingDelay = 0;

        private int armingDelay2 = 0;

        private UserAuditInfo userAuditInfo = null;

        private AreaStatusList parent = null;

        private bool stopping = false;

        /// <summary>Area Ids list lock</summary>
        private readonly object areaIdsSync = new object();

        private bool isSameExitDelay = true;

        public ArmAreaTaskHolder(AreaStatusList parent, List<int> areaIds, int delay1, int delay2, UserAuditInfo userInfo)
        {
            this.areaIds = areaIds;
            setIsSameExitDelay();
            remainingArmingDelay = delay1;
            elapsedArmingDelay = 0;
            armingDelay2 = delay2;
            userAuditInfo = userInfo;
            this.parent = parent;
            armingDelayTimer = TimerManager.Instance.CreateTimer(armingDelayTimerProc);
        }

        private void setIsSameExitDelay()
        {
            isSameExitDelay = true;
            if (areaIds.Count <= 1)
                return;

            int exitDelay = 0;
            bool firstTime = true;
            for (int i = 0; i < areaIds.Count; i++)
            {
                AreaConfiguration areaConfig = ConfigurationManager.Instance.GetAreaConfiguration(areaIds[i]);
                if (areaConfig != null)
                {
                    if (firstTime == true)
                    {
                        firstTime = false;
                        exitDelay = areaConfig.ExitDelaySeconds;
                        continue;
                    }

                    if (areaConfig.ExitDelaySeconds != exitDelay)
                    {
                        isSameExitDelay = false;
                        break;
                    }
                }
            }
        }

        public List<int> AreaIds
        {
            get 
            {
                lock (areaIdsSync)
                {
                    return areaIds;
                }
            }
        }

        public bool Done()
        {
            return remainingArmingDelay <= 0;
        }

        private bool firstTime = false;
        public void StartArming()
        {
            firstTime = true;
            armingDelayTimer.Change(0, exitTimerDueTime);
        }

        /// <summary>
        /// Check if the arm area task contains any of the ares in [areaIds] list and set the stopping flag to True if not yet set.
        /// </summary>
        /// <param name="areaIds">Area ids list to check against.</param>
        public void TryStoppingArming(List<int> areaIds)
        {
            if (stopping == false && AreaIds.Intersect(areaIds).Count > 0)
            {
                stopping = true;
            }
        }

        /// <summary>
        /// Stop arm area task and notify keypads. If stopping is False return immediately.
        /// </summary>
        public bool StopArming()
        {
            if (stopping == false)
                return false;

            if (armingDelayTimer.Enabled == true)
                armingDelayTimer.Stop();
            remainingArmingDelay = 0;
            elapsedArmingDelay = 0;
            armingDelay2 = 0;
            stopping = false;
            if (parent != null)
            {
                List<int> ids = AreaIds;
                parent.TriggerStopArming(ids, getBuzzerTypeAndDuration(ids), getBeepBuzzer());
            }
            return true;
        }

        public bool StopArming(int areaId)
        {
            lock (areaIdsSync)
            {
                if (areaIds.Contains(areaId) == true)
                {
                    areaIds.Remove(areaId);
                    if (areaIds.Count == 0)
                    {
                        if (armingDelayTimer.Enabled == true)
                            armingDelayTimer.Stop();
                        remainingArmingDelay = 0;
                        elapsedArmingDelay = 0;
                        armingDelay2 = 0;
                    }
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Resume arm area task
        /// </summary>
        public void ResumeArming()
        {
            stopping = false;
        }

        /// <summary>
        /// Terminate current arm area task and trigger Failed to Arm event
        /// </summary>
        public void TerminateArming()
        {
            if (destroying == true)
                return;
            armingDelayTimer.Stop();
            
            List<int> ids = AreaIds;
            remainingArmingDelay = 0;
            elapsedArmingDelay = 0;
            armingDelay2 = 0;
            stopping = false;
            Logger.LogWarnMessage(LoggerClassPrefixes.StatusManager, () =>
            {
                return string.Format("Area(s): {0} failed to arm.", areaIdsToString(ids));
            });
            if (parent == null)
                return;

            parent.TriggerStopArming(ids, getBuzzerTypeAndDuration(ids), getBeepBuzzer());
            // Send Arm Failed event to SM for each area in the task
            foreach (var areaId in ids)
            {
                AreaStatus areaStatus = parent[areaId];
                if (areaStatus != null && areaStatus.Armed == false)
                {
                    parent.TriggerFailedToArmArea(areaId, userAuditInfo);
                    areaStatus.StartFailToArmTimer();
                }
            }
        }

        /// <summary>
        /// Timer that will drive the arming delay display for all keypads that are online and can arm any of the areas that were
        /// part of the area arm request.
        /// </summary>
        /// <param name="state">Not Used</param>
        private void armingDelayTimerProc(object state)
        {
            if (destroying == true || parent == null)
                return;

            if (firstTime == false)
            {
                if (remainingArmingDelay > 0)
                {
                    remainingArmingDelay -= 1;
                    elapsedArmingDelay += 1;
                }
            }
            else
            {
                firstTime = false;
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Start Arming area(s): {0}", areaIdsToString());
                });
                parent.TriggerStartArming(areaIds, getBuzzerTypeAndDuration(areaIds), getBeepBuzzer());
                if (remainingArmingDelay > 0)
                    return;
            }

            bool allAreasArmed = areaIds.AllArmed();
            if (Done() == true || allAreasArmed == true)
            {
                armingDelayTimer.Stop();
                if (allAreasArmed == false)
                {
                    bool failedToArm = remainingArmingDelay == 0 && ConfigurationManager.Instance.ControllerConfiguration.CompletionOfSettingRequired == true;
                    if (failedToArm == true)
                    {
                        // Send Arm Failed event to SM for each area in the task
                        foreach (var areaId in areaIds)
                        {
                            AreaStatus areaStatus = parent[areaId];
                            if (areaStatus != null && areaStatus.Armed == false)
                            {
                                parent.TriggerFailedToArmArea(areaId, userAuditInfo);
                                areaStatus.StartFailToArmTimer();
                            }
                        }
                        Logger.LogWarnMessage(LoggerClassPrefixes.StatusManager, () =>
                        {
                            return string.Format("Area(s): {0} failed to arm.", areaIdsToString());
                        });
                    }
                    else
                    {
                        MacroControl.Instance.EnqueueKeyPadEvent(StatusConsts.UndefinedLogicalId, StatusConsts.UndefinedUser);
                        parent.DoArmAreas(areaIds, userAuditInfo);
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return logArmSuccessMessage(areaIds);
                        });
                    }
                }
                else
                {
                    remainingArmingDelay = 0;
                    elapsedArmingDelay = 0;
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Area(s): {0} have already been armed. Arm area task will be canceled.", areaIdsToString());
                    });
                }
                parent.TriggerStopArming(areaIds, getBuzzerTypeAndDuration(areaIds), getBeepBuzzer());
                if (destroying == false)
                {
                    parent.CleanCompletedArmTask(this);
                }
            }
            else
            {
                if (isSameExitDelay == false)
                {
                    // Get all areas that need to be armed because their exit delay(s) have elapsed
                    List<int> toArmAreaIds = getAreasThatRequireArming();
                    if (toArmAreaIds.Count > 0)
                    {
                        List<int> remainingAreaIds = areaIds.Except(toArmAreaIds);
                        lock (areaIdsSync)
                        {
                            areaIds = remainingAreaIds;
                        }
                        setIsSameExitDelay();

                        parent.DoArmAreas(toArmAreaIds, userAuditInfo);
                        parent.TriggerStopArming(toArmAreaIds, getBuzzerTypeAndDuration(toArmAreaIds), getBeepBuzzer());
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return logArmSuccessMessage(toArmAreaIds);
                        });
                    }
                }
                if (areaIds.Count > 0)
                {
                    parent.TriggerCountdownArming(areaIds, getBuzzerTypeAndDuration(areaIds), getBeepBuzzer());
                }
            }
        }

        private string logArmSuccessMessage(List<int> toArmIds)
        {
            string areaText = "Area";
            string wereText = "was";
            if (toArmIds.Count > 1)
            {
                areaText = "Areas";
                wereText = "were";
            }
            return string.Format("{0}: {1} {2} successfully armed.", areaText, areaIdsToString(toArmIds), wereText);
        }

        /// <summary>
        /// Get the list of area Ids that require arming. These are the areas for which the exit delay is at
        /// most equal with the elapsed arming delay. This will allow for areas with different exit delays to
        /// be armed when the exit delay expires instead of when the maximum exit delay for all areas in arm
        /// area task expires.
        /// </summary>
        /// <returns></returns>
        private List<int> getAreasThatRequireArming()
        {
            List<int> elapsedAreas = new List<int>();
            areaIds.ForEach(areaId =>
            {
                AreaConfiguration areaConfig = ConfigurationManager.Instance.GetAreaConfiguration(areaId);
                if (areaConfig != null && areaConfig.ExitDelaySeconds <= elapsedArmingDelay)
                {
                    elapsedAreas.Add(areaId);
                }
            });
            return elapsedAreas;
        }

        private bool getBeepBuzzer()
        {
            return ((remainingArmingDelay > armingDelay2 && remainingArmingDelay % 5 == 0) ||
                    (remainingArmingDelay <= armingDelay2 && remainingArmingDelay % 2 == 0));
        }

        /// <summary>
        /// Get keypad buzzer type and duration when arming area(s)
        /// </summary>
        /// <returns></returns>
        private KeypadBuzzerPriority getBuzzerTypeAndDuration(List<int> ids)
        {
            bool beep = ids.Any(areaId =>
            {
                AreaConfiguration areaConfig = ConfigurationManager.Instance.GetAreaConfiguration(areaId);
                return (areaConfig != null) ? areaConfig.BeepOnExit == true : false;
            });
            KeypadBuzzerPriority buzzerTypeAndDuration = KeypadBuzzerPriority.NoBeeping;
            if (beep == true)
                buzzerTypeAndDuration = remainingArmingDelay > armingDelay2 ? KeypadBuzzerPriority.ExitDelay1 : KeypadBuzzerPriority.ExitDelay2;
            return buzzerTypeAndDuration;
        }

        private string areaIdsToString()
        {
            return areaIdsToString(areaIds);
        }

        private string areaIdsToString(List<int> ids)
        {
            string result = "";
            ids.ForEach(areaId =>
            {
                result += areaId + ";";
            });
            result = result.TrimEnd(new char[] { ';' });
            return result;
        }

        #region IDisposable Members

        bool disposed = false;
        bool disposing = false;

        private bool destroying
        {
            get { return disposing == true || disposed == true; }
        }

        private void Dispose(bool disposing)
        {
            if (disposed == true)
                return;

            try
            {
                this.disposing = true;
                if (disposing)
                {
                    if (armingDelayTimer != null)
                    {
                        TimerManager.Instance.RemoveTimer(armingDelayTimer);
                        armingDelayTimer = null;
                    }
                    parent = null;
                }
                disposed = true;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while disposing arm area task holder. {0}", ex.ToString());
                });
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
