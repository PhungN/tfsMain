﻿using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Status
{
    public abstract class DeviceKeypadStatus : DeviceLoopDeviceStatus
    {
        private bool lockedOut = false;

        private List<string> deisolatedPointDisplayNameList = null;
        public List<string> DeisolatedPointDisplayNameList
        {
            get { return deisolatedPointDisplayNameList; }
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = base.CurrentAlarms;
                if (tooManyInvalidLogonAttempts == true)
                    flags |= EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts;
                return flags;
            }
        }

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            switch (suspectStatusType)
            {
                case EventSourceLatchOrIsolateType.Offline: return ConfigurationManager.Instance.ControllerConfiguration.LatchOfflineAlarms;
                case EventSourceLatchOrIsolateType.Tamper: return ConfigurationManager.Instance.ControllerConfiguration.LatchTamperAlarms;
                case EventSourceLatchOrIsolateType.DeviceSubstitution:
                case EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts: return true;
                default: return false;
            }
        }

        /// <summary>
        /// Returns the current latch status for this status item instance and the [latchFlagToCheck]
        /// </summary>
        /// <param name="latchFlagToCheck">The status item alarm flag that needs to be checked for latching</param>
        /// <returns>The latch status for this status item.</returns>
        public override EventSourceLatchStatus GetLatchStatusFor(EventSourceLatchOrIsolateType latchFlagToCheck)
        {
            if (latchFlagToCheck != EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts)
                return base.GetLatchStatusFor(latchFlagToCheck);

            return latchedAlarms.Has(EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts) == true ? EventSourceLatchStatus.ConfiguredToBeLatched :
                                                                                                          EventSourceLatchStatus.NotLatched;
        }

        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get { return base.IsCurrentlyLatched || latchedAlarms.Has(EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts); }
        }

        /// <summary>
        /// Get / Set lockedOut keypad status
        /// </summary>
        public bool LockedOut
        {
            get { return lockedOut; }
            set
            {
                if (Enabled == false)
                    return;
                if (lockedOut != value)
                {
                    lockedOut = value;
                    Parent.TriggerKeypadLockedOutChangedStatus(this, lockedOut);
                }
            }
        }

        /// <summary>
        /// Too many invalid logon attempts alarm set / restore
        /// </summary>
        private bool tooManyInvalidLogonAttempts = false;
        public bool TooManyInvalidLogonAttempts
        {
            get { return tooManyInvalidLogonAttempts; }
            set
            {
                if (Enabled == false)
                    return;
                if (tooManyInvalidLogonAttempts != value || value == true)
                {
                    if (SuspectPoint == false && (LatchedAlarms.Has(EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts) == false || value == true))
                    {
                        tooManyInvalidLogonAttempts = value;
                        if (tooManyInvalidLogonAttempts == true)
                        {
                            // Latch Too Many Invalid Logon Attempts alarm
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts);
                        }
                        // The previous serial number is not default one it must be a substituted device
                        Parent.TriggerTooManyInvalidLogonAttempts(this, AreaId, tooManyInvalidLogonAttempts);
                    }
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Restore masked online, device tamper, etc. status if required after unlatching the device alarms. Restore only if the
        /// current instantaneous status is Secure (device online, tamper secure, etc.).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        protected override void RestoreAfterUnlatch(UserAuditInfo userAuditInfo)
        {
            base.RestoreAfterUnlatch(userAuditInfo);
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts) == true)
                return;

            if (tooManyInvalidLogonAttempts == true)
                TooManyInvalidLogonAttempts = false;
        }

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        public override bool CanIsolate(UserAccessLevel level)
        {
            if (CurrentAlarms == EventSourceLatchOrIsolateType.DeviceSubstitution ||
                CurrentAlarms == EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts)
                return false;

            EventSourceLatchOrIsolateType remainingAlarms = CurrentAlarms.ClearFlag(EventSourceLatchOrIsolateType.DeviceSubstitution | 
                                                                                    EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts);
            if (remainingAlarms.Empty() == true)
                return false;

            return level == UserAccessLevel.AccessLevel3;
        }

        /// <summary>
        /// Get / Set the current keypad user access level
        /// </summary>
        private UserAccessLevel accessLevel = UserAccessLevel.AccessLevel1;
        public UserAccessLevel AccessLevel
        {
            get { return accessLevel; }
        }

        /// <summary>
        /// Set / Reset User Access Level
        /// </summary>
        /// <param name="value"></param>
        /// <param name="userAuditInfo">User that logged on into an 8101 keypad.</param>
        /// <param name="groupId">User Group</param>
        public void SetAccessLevel(UserAccessLevel value, UserAuditInfo userAuditInfo, int groupId)
        {
            if (Enabled == false)
                return;
            if (accessLevel != value)
            {
                UserAccessLevel previousAccessLevel = accessLevel;
                accessLevel = value;
                if (accessLevel == UserAccessLevel.AccessLevel3 && previousAccessLevel == UserAccessLevel.AccessLevel2)
                {
                    // Send Engineer LogOn event to front-end
                    Parent.TriggerEngineerLogOn(this, userAuditInfo, AreaId, groupId, true);
#if DEBUG
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Engineer [{0}] LOGON, on keypad [{1}].", userAuditInfo.OriginatingUserId, DisplayName);
                    });
#endif
                    return;
                }

                if (previousAccessLevel == UserAccessLevel.AccessLevel3)
                {
                    // Send Engineer LogOn Restore event to front-end
                    Parent.TriggerEngineerLogOn(this, userAuditInfo, AreaId, groupId, false);
#if DEBUG
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Engineer [{0}] LOGOFF, from keypad [{1}].", userAuditInfo.OriginatingUserId, DisplayName);
                    });
#endif
                }
            }
        }

        /// <summary>
        /// Get keypad owner Area Id
        /// </summary>
        public int AreaId
        {
            get;
            private set;
        }

        public DeviceKeypadStatus(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus) :
            base(configuration, parent, previousStatus)
        {
            Device8003KeypadConfiguration keypadConfig = ConfigurationManager.Instance.GetDeviceConfiguration(LogicalId) as Device8003KeypadConfiguration;
            if (keypadConfig != null)
                AreaId = keypadConfig.AreaId;
            deisolatedPointDisplayNameList = new List<string>();

            if (previousStatus == null || this.Enabled == false)
                return;

            if (this.HardwareType == previousStatus.HardwareType)
                tooManyInvalidLogonAttempts = previousStatus.LatchedAlarms.Has(EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts);
        }

        private const int contal8105KeypadLineWidth = 24;
        /// <summary>
        /// Get / Set the device serial number
        /// </summary>
        public override string SerialNumber
        {
            get { return serialNumber; }
            set
            {
                if (Enabled == false)
                    return;
                base.SerialNumber = value;
                if (DeviceSubstitution == false && (serialNumber.StartsWith("057C") == true || serialNumber.StartsWith("073C") == true))
                {
                    // Update 8105 Contal Keypad display line width
                    IKeypadStateMachine keypad = getKeypad();
                    if (keypad != null)
                    {
                        keypad.SetDisplayWidth(contal8105KeypadLineWidth);
                    }
                }
            }
        }

        /// <summary>
        /// Report any invalid user login attempt
        /// </summary>
        /// <param name="userId">User Id</param>
        public void ReportInvalidUserIdPin(int userId)
        {
            if (Enabled == false)
                return;

            Parent.TriggerReportInvalidUserIdPin(this, AreaId, userId);
        }

        /// <summary>
        /// Report User Out of Schedule
        /// </summary>
        /// <param name="userId">User Id</param>
        public void ReportUserOutOfSchedule(int userId)
        {
            if (Enabled == false)
                return;
            Parent.TriggerReportUserOutOfSchedule(this, AreaId, userId);
        }

        /// <summary>
        /// Report a user that logged into a keypad device with a valid User Id and the duress PIN instead of the
        /// normal PIN.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="areaId">Keypad Area Id</param>
        public void ReportDuressPin(int userId, int areaId)
        {
            if (Enabled == false)
                return;

            Parent.TriggerKeypadUserLoginDuressPin(this, areaId, userId);
        }

        /// <summary>
        /// Display user messages on keypad
        /// </summary>
        /// <param name="userMessages">List of messages to display on keypad</param>
        public virtual void DisplayUserMessages(string[] userMessages)
        {
            IKeypadStateMachine keypad = getKeypad();
            if (keypad == null)
                return;
            keypad.SetUserMessages(userMessages);
        }

        private IKeypadStateMachine getKeypad()
        {
            Device8003KeypadConfiguration configuration = ConfigurationManager.Instance.GetDeviceConfiguration(LogicalId) as Device8003KeypadConfiguration;
            if (configuration != null)
            {
                int deviceId = configuration.DeviceLoopAddress - 1;
                if (deviceId >= 0)
                {
                    return StatusManager.Instance.DeviceLoopManager.GetKeypad(deviceId);
                }
            }
            return null;
        }

        public void ClearDeisolatedPointDisplayNameList()
        {
            deisolatedPointDisplayNameList.Clear();
        }

        internal override void Cleanup()
        {
            if (deisolatedPointDisplayNameList != null)
            {
                deisolatedPointDisplayNameList.Clear();
                deisolatedPointDisplayNameList = null;
            }
        } 
    }
}
