﻿using System;
using System.Text;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.AccessControl;
using TT = Pacom.Peripheral.Common.Status.TransactionType;

namespace Pacom.Peripheral.Common.Status
{
    internal abstract class DoorAgentBase : IDoorAgent, IDisposable
    {

        /*
        /// The following are the basics of door agent:
        ///
        ///             __________________________________________________________
        ///            / Access time extends strike, embarrassment and shunt time
        ///           |                        
        ///           |                        
        ///           |                                             ___________________________
        ///           |                                            / Door opened too long time
        ///           |                                           /    (Pulse Buzzer, etc.)
        ///           |                                          /
        ///   /|      |                                         /                           _____________________
        ///  / | Door |                                        /                           /    Ajar alarm
        /// /  |      |                                       /                           /  (Continuous Buzzer)
        /// |  |   ___|____                                  /                           /
        /// |  /  /        \                                 |------------------------->|
        /// | /  /          \                                |                          |
        /// |/  /            \                               |                          |
        /// X  /              \                              |                          |
        /// | /                \                             |                          |                                   Timeline
        /// o-------------------o----------------------------o--------------------------X---------------------------------- - - - - - >
        /// |                   |                            |                          |
        /// |                   |                            |                          |
        /// |------------------>X . . |                      |                          |
        /// |    Strike Time    |                            |                          |
        /// |                   |                            |                          |
        /// |----------------------------------------------->|                          |
        /// |                   |    Embarrassment Time      |                          |
        /// |                   |    (Access Warn Time)      |                          |
        /// |-------------------------------------------------------------------------->|
        /// |                   |                   Shunt Time
        /// |                   |
        /// X                   X-- Door open
        /// Door activation
        /// ---------------
        /// Card swipe
        /// Egress
        /// Macro
        /// Command
        /// 
        /// 
        /// Idle LED state
        /// 
        /// | In Reader Mode | Out Reader Mode | LED Colour |
        /// |----------------|-----------------|------------|
        /// |   Unlocked     |   Not Present   |   Green    |
        /// |   Blocked      |   Not Present   |   Red      |
        /// |   Card         |   Not Present   |   Black    |
        /// |   Card + Pin   |   Not Present   |   Black    |
        /// |   Unlocked     |   Unlocked      |   Green    |
        /// |   Blocked      |   Unlocked      |   Red      |
        /// |   Card         |   Unlocked      |   Black    |
        /// |   Card + Pin   |   Unlocked      |   Black    |
        /// |   Unlocked     |   Blocked       |   Red      |
        /// |   Blocked      |   Blocked       |   Red      |
        /// |   Card         |   Blocked       |   Red      |
        /// |   Card + Pin   |   Blocked       |   Red      |
        /// |   Unlocked     |   Card          |   Black    |
        /// |   Blocked      |   Card          |   Red      |
        /// |   Card         |   Card          |   Black    |
        /// |   Card + Pin   |   Card          |   Black    |
        /// |   Unlocked     |   Card + Pin    |   Black    |
        /// |   Blocked      |   Card + Pin    |   Red      |
        /// |   Card         |   Card + Pin    |   Black    |
        /// |   Card + Pin   |   Card + Pin    |   Black    |
        /// |----------------|-----------------|------------|
        /// 
*/

        public static IDoorAgent CreateInstance(DoorLockOperation lockOpearation, DoorStatus door, ReaderStatus inReader, ReaderStatus outReader)
        {
            if (inReader == null && outReader == null)
            {
                return new DoorAgentDummy(door, inReader, outReader);
            }
            switch (lockOpearation)
            {
                case DoorLockOperation.MagneticLock: return new DoorAgentMagnetic(door, inReader, outReader);
                case DoorLockOperation.DoorBoltMode: return new DoorAgentBolt(door, inReader, outReader);
                case DoorLockOperation.Normal:
                default: return new DoorAgentNormal(door, inReader, outReader);
            }
        }

        protected DoorAgentBase(DoorLockOperation lockOpearation, DoorStatus door, ReaderStatus inReader, ReaderStatus outReader)
        {
            this.doorStatus = door;
            this.inReaderStatus = inReader;
            this.outReaderStatus = outReader;
            this.doorLockOperation = lockOpearation;

            deactivateStrikeDeniedAccessTimer = TimerManager.Instance.CreateTimer(deactivateStrikeDeniedAccessProc);
            shuntEmbarrassmentTimer = TimerManager.Instance.CreateTimer(shuntEmbarrassmentTimerProc);
            keypadInactivityInReaderTimer = TimerManager.Instance.CreateTimer(keypadInactivityInReaderTimerProc);
            keypadInactivityOutReaderTimer = TimerManager.Instance.CreateTimer(keypadInactivityOutReaderTimerProc);
        }

        /// <summary>
        /// Default time of the denied mode on the door
        /// </summary>
        internal static int DefaultAccessDeniedTimeout = 3000;

        public int AccessDeniedDuration
        {
            get 
            {
                if (accessControlTransaction != null)
                    return accessControlTransaction.DeniedLedTime;
                return DefaultAccessDeniedTimeout; 
            }
        }

        internal static int NoAdditionalTime = 0;

        protected const bool DoorModeUnlocked = true;
        protected const bool DoorModeAccessControlled = false;

        protected ReaderStatus inReaderStatus;
        public ReaderStatus InReaderStatus
        {
            get { return inReaderStatus; }
        }

        public bool IsInReaderAssigned
        {
            get { return inReaderStatus != null; }
        }

        protected ReaderStatus outReaderStatus;
        public ReaderStatus OutReaderStatus
        {
            get { return outReaderStatus; }
        }

        public bool IsOutReaderAssigned
        {
            get { return outReaderStatus != null; }
        }

        protected DoorLockOperation doorLockOperation = DoorLockOperation.Normal;
        public DoorLockOperation DoorLockOperation
        {
            get { return doorLockOperation; }
        }
        
        protected DoorStatus doorStatus;

        protected DoorAccessControlTransactionAgent accessControlTransaction = null;

        /// <summary>
        /// Broadcast the last door peripheral transaction. The Door Agent unit tests subscribe to this event in order to get the last
        /// door peripheral transaction and compare it with the expected value.
        /// </summary>
        public event EventHandler<AccessControlTransactionEventArgs> LastAccessControlTransactionEvent = null;

        /// <summary>
        /// Send access control transaction event so any subscribers can receive the value of the last access control transaction
        /// for this door.
        /// </summary>
        /// <param name="transactionType">Access Control Transaction Value</param>
        public void SendAccessControlTransactionEvent(TT transactionType)
        {
#if DEBUG
            if (LastAccessControlTransactionEvent != null)
            {
                LastAccessControlTransactionEvent(this, new AccessControlTransactionEventArgs(transactionType));
            }
#endif
        }

        private StringBuilder doorStatusLogText = new StringBuilder();

        /// <summary>
        /// Timer used for deactivating the strike or the denied mode on the door
        /// </summary>
        protected IPacomTimer deactivateStrikeDeniedAccessTimer = null;

        /// <summary>
        /// Shunt / embarrassment timer, started when the door has opened and the door contacts are in Alarm, ends either
        /// when the shunt + embarrassment timeouts expire or when the door is closed.
        /// </summary>
        protected IPacomTimer shuntEmbarrassmentTimer = null;

        protected IPacomTimer keypadInactivityInReaderTimer = null;

        protected IPacomTimer keypadInactivityOutReaderTimer = null;

        #region Agent transactions

        private ReaderTransaction inReaderTransaction = new ReaderTransaction();
        public ReaderTransaction InReaderTransaction
        {
            get { return inReaderTransaction; }
        }

        private ReaderTransaction outReaderTransaction = new ReaderTransaction();
        public ReaderTransaction OutReaderTransaction
        {
            get { return outReaderTransaction; }
        }

        protected DurationType transactionDurationType = DurationType.PreconfiguredDuration;

        /// <summary>
        /// When door is open by command this is the duration type.
        /// </summary>
        public DurationType TransactionDurationType
        {
            get { return transactionDurationType; }
        }

        protected int transactionAccessDuration = NoAdditionalTime;

        /// <summary>
        /// When door is open by command this is the duration in seconds.
        /// </summary>
        public int TransactionAccessDuration
        {
            get { return transactionAccessDuration; }
        }

        internal void ClearValidCardTransaction(int logicalReaderId)
        {
            if (IsInReaderAssigned && logicalReaderId == inReaderStatus.LogicalId)
            {
                if (IsOutReaderAssigned && outReaderStatus.LockedOut)
                    outReaderTransaction.Clear();
                inReaderTransaction.Clear();
            }
            else if (IsOutReaderAssigned && logicalReaderId == outReaderStatus.LogicalId)
            {
                if (IsInReaderAssigned && inReaderStatus.LockedOut)
                    inReaderTransaction.Clear();
                outReaderTransaction.Clear();
            }
        }

        internal void ClearAllValidCardTransactions()
        {
            if (IsInReaderAssigned)
                ClearValidCardTransaction(inReaderStatus.LogicalId);
            if (IsOutReaderAssigned)
                ClearValidCardTransaction(outReaderStatus.LogicalId);
        }

        internal void ClearCommandTransaction()
        {
            transactionDurationType = DurationType.PreconfiguredDuration;
            transactionAccessDuration = NoAdditionalTime;
        }

        internal CardNumberHolder GetCardNumber(int logicalReaderId)
        {
            if (IsInReaderAssigned && inReaderStatus.LogicalId == logicalReaderId)
            {
                return inReaderTransaction.Card;
            }
            else if (IsOutReaderAssigned && outReaderStatus.LogicalId == logicalReaderId)
            {
                return outReaderTransaction.Card;
            }
            return null;
        }

        internal void AssignValidCardTransaction(int logicalReaderId, CardNumberHolder newValidCard, Reader8003ScheduleLevel readerMode)
        {
            if (IsInReaderAssigned && inReaderStatus.LogicalId == logicalReaderId)
            {
                // Prevent same card in both trnsactions
                if ((outReaderTransaction.IsCardAssigned == false) ||
                    (outReaderTransaction.IsCardAssigned && outReaderTransaction.Card.Equals(newValidCard) == false))
                {
                    inReaderTransaction.Card = newValidCard;
                    inReaderTransaction.TransactionType = ReaderTransactionType.Card;
                }
            }
            else if (IsOutReaderAssigned && outReaderStatus.LogicalId == logicalReaderId)
            {
                // Prevent same card in both trnsactions
                if (inReaderTransaction.IsCardAssigned == false ||
                    (inReaderTransaction.IsCardAssigned && inReaderTransaction.IsSameCardAs(newValidCard) == false))
                {
                    outReaderTransaction.Card = newValidCard;
                    outReaderTransaction.TransactionType = ReaderTransactionType.Card;
                }
            }
        }

        internal void AssignValidCardTransaction(int logicalReaderId, CardInformation cardInformation, Reader8003ScheduleLevel readerMode, List<CardInformation> cardInformationList, ReaderBadgingType badgingType)
        {
            if (IsInReaderAssigned && inReaderStatus.LogicalId == logicalReaderId)
            {
                // Prevent same card in both trnsactions
                if ((outReaderTransaction.IsCardAssigned == false) ||
                    (outReaderTransaction.IsCardAssigned && outReaderTransaction.Card.Equals(cardInformation.CardNumber) == false))
                {
                    if (readerMode == Reader8003ScheduleLevel.CardOnly || inReaderTransaction.IsSameCardAs(cardInformation.CardNumber))
                    {
                        inReaderTransaction.Card = cardInformation.CardNumber;
                        inReaderTransaction.CardInformation = cardInformation;
                        inReaderTransaction.MultiBadgingCardInformationList = cardInformationList;
                        inReaderTransaction.BadgingType = badgingType;
                        inReaderTransaction.TransactionType = ReaderTransactionType.Card;
                        inReaderTransaction.SetValid();
                    }
                }
            }
            else if (IsOutReaderAssigned && outReaderStatus.LogicalId == logicalReaderId)
            {
                // Prevent same card in both trnsactions
                if (inReaderTransaction.IsCardAssigned == false ||
                    (inReaderTransaction.IsCardAssigned && inReaderTransaction.IsSameCardAs(cardInformation.CardNumber) == false))
                {
                    if (readerMode == Reader8003ScheduleLevel.CardOnly || outReaderTransaction.IsSameCardAs(cardInformation.CardNumber))
                    {
                        outReaderTransaction.Card = cardInformation.CardNumber;
                        outReaderTransaction.CardInformation = cardInformation;
                        outReaderTransaction.MultiBadgingCardInformationList = cardInformationList;
                        outReaderTransaction.BadgingType = badgingType;
                        outReaderTransaction.TransactionType = ReaderTransactionType.Card;
                        outReaderTransaction.SetValid();
                    }
                }
            }
        }

        internal void AssignCommandTransaction(DurationType type, int value)
        {
            transactionAccessDuration = value;
            transactionDurationType = type;

            updateReaderTransactionType(ReaderTransactionType.Command);
        }

        internal bool AssignPinTransaction(int logicalReaderId, byte[] pinData)
        {
            // 1) Check if pin is entered on the same reader as card was scanned.
            // 2) Do not allow pin being assigned without card being scanned.
            if (IsInReaderAssigned && inReaderStatus.LogicalId == logicalReaderId && inReaderTransaction.IsCardAssigned)
            {
                inReaderTransaction.Pin = pinData;
                return true;
            }
            else if (IsOutReaderAssigned && outReaderStatus.LogicalId == logicalReaderId && outReaderTransaction.IsCardAssigned)
            {
                outReaderTransaction.Pin = pinData;
                return true;
            }
            return false;
        }

        #endregion

        private int shuntTime = 0;

        /// <summary>
        /// Shunt time for masking any alarms while the door is open
        /// </summary>
        public int ShuntTime
        {
            get { return shuntTime; }
            set { shuntTime = value; }
        }

        private int embarrassmentTime = 0;

        /// <summary>
        /// Embarrassment time, extra time allowed for closing the door during which the buzzer will beep.
        /// </summary>
        public int EmbarrassmentTime
        {
            get { return embarrassmentTime; }
            set { embarrassmentTime = value; }
        }

        private int keypadInactivityTimeout = 0;

        /// <summary>
        /// Keypad inactivity time, time allowed for the pin entry.
        /// </summary>
        public int KeypadInactivityTimeout
        {
            get { return keypadInactivityTimeout; }
            set { keypadInactivityTimeout = value; }
        }

        /// <summary>
        /// Time difference between "Shunt Time" - "Embarrassment Time" during which the buzzer should signal upcoming ajar alarm.
        /// </summary>
        public int DoorOpenTooLongTime
        {
            get
            {
                int doorOpenTooLongTime = shuntTime - embarrassmentTime;
                if (doorOpenTooLongTime < 0)
                    doorOpenTooLongTime = 0;
                return doorOpenTooLongTime;
            }
        }

        private bool storeCardInDegradedMemory = false;

        /// <summary>
        /// When True mark cards for this door to be stored in degraded memory.
        /// </summary>
        public bool StoreCardInDegradedMemory
        {
            get { return storeCardInDegradedMemory; }
            set { storeCardInDegradedMemory = value; }
        }

        private int strikeTime = 0;

        /// <summary>
        /// Strike Time in milliseconds
        /// </summary>
        public int StrikeTime
        {
            get { return strikeTime; }
            set { strikeTime = value; }
        }

        /// <summary>
        /// Deactivate Strike Timeout - Bolt Door Only
        /// </summary>
        public virtual int DeactivateStrikeTimeout
        {
            get { return strikeTime; }
        }

        /// <summary>
        /// Use the property OperationState to update this, so that things such as
        /// interlocks work correctly.
        /// </summary>
        private DoorOperationState doorState = DoorOperationState.Unknown;
      
        public DoorOperationState OperationState
        {
            get { return doorState; }
            set
            {
                // Need to save old value and update before telling subscribers
                DoorOperationState oldState = doorState;
                doorState = value;
                doorStatus.Parent.TriggerDoorStateChanged(doorStatus.LogicalId, oldState, doorState);
            }
        }

        /// <summary>
        /// Return value of the update agent state function
        /// </summary>
        protected bool strikeActivated = false;
        public bool StrikeActivated
        {
            get { return strikeActivated; }
        }

        private readonly object agentStateTransitionLock = new object();

        public DoorAgentContexts Context { get; private set; }

        /// <summary>
        /// Update Agent State
        /// </summary>
        /// <param name="context">Force Door Agent Context</param>
        /// <returns>True if Door Strike Activated / False Otherwise</returns>
        public virtual bool UpdateAgentState(DoorAgentContexts context)
        {
            Context = context;
            lock (agentStateTransitionLock)
            {
                strikeActivated = false;
                SendAccessControlTransactionEvent(TT.None);
                DoorOperationState newDoorState = DoorOperationState.Unknown;
                switch (context)
                {
                    case DoorAgentContexts.DoorContactAlarm:
                        accessControlTransaction.CreateAndSendTransaction(context);
                        break;
                    case DoorAgentContexts.DoorContact:
                        if (doorStatus.IsDoorPhysicallyOpen == true)
                        {
                            if (OperationState == DoorOperationState.Unknown || OperationState == DoorOperationState.Closed)
                            {
                                SetDoorAlarm(DoorAlarms.Forced);

                                // Handle reader keypad waiting for pin when door was forced - Accept LED OFF and send AccessDeniedInactivityTimeout event to Front End
                                if (IsKeypadInactivityTimerOnInReaderInProgress == true || IsKeypadInactivityTimerOnOutReaderInProgress == true)
                                {
                                    ClearCommandTransaction();
                                    if (IsKeypadInactivityTimerOnInReaderInProgress == true)
                                    {
                                        StopKeypadInactivityInReaderTimer();
                                        NotifyKeypadInactivityTimeoutExpiredOnInReader();
                                        ClearValidCardTransaction(inReaderStatus.LogicalId);
                                    }
                                    if (IsKeypadInactivityTimerOnOutReaderInProgress == true)
                                    {
                                        StopKeypadInactivityOutReaderTimer();
                                        NotifyKeypadInactivityTimeoutExpiredOnOutReader();
                                        ClearValidCardTransaction(outReaderStatus.LogicalId);
                                    }
                                }
                                accessControlTransaction.CreateAndSendTransaction(context);
                                OperationState = DoorOperationState.Forced;
                            }
                            else if (OperationState == DoorOperationState.Opening)
                            {
                                UpdateAntipassback();
                                accessControlTransaction.CreateAndSendTransaction(context);
                                ExecuteOnDoorOpenWhenOpening();
                                OperationState = DoorOperationState.Opened;
                            }
                            else if (OperationState == DoorOperationState.Opened)
                            {
                                accessControlTransaction.CreateAndSendTransaction(context);
                                ExecuteOnDoorOpenWhenOpened();
                            }
                        }
                        else
                        {
                            ExecuteOnDoorBeforeClose();
                            StopStrikeDeniedAccessTimer();
                            if (doorStatus.IsUnlocked)
                            {
                                accessControlTransaction.CreateAndSendTransaction(context);
                                OperationState = DoorOperationState.UnlockedPermanently;
                                strikeActivated = true;
                            }
                            else if (OperationState == DoorOperationState.Forced)
                            {
                                accessControlTransaction.CreateAndSendTransaction(context);
                                OperationState = DoorOperationState.Closed;
                            }
                            else
                            {
                                accessControlTransaction.CreateAndSendTransaction(context);
                                ExecuteOnDoorCloseWhenOtherwise();
                            }
                            ClearAllValidCardTransactions();
                            ResetDoorAlarms();
                        }
                        break;

                    case DoorAgentContexts.Egress:
                        if (OperationState == DoorOperationState.Egress || OperationState == DoorOperationState.UnlockedPermanently)
                            break;

                        newDoorState = DoorOperationState.Opening;
                        if (OperationState == DoorOperationState.Forced || OperationState == DoorOperationState.Ajar || OperationState == DoorOperationState.Opened)
                        {
                            newDoorState = DoorOperationState.Opened;
                        }
                        accessControlTransaction.CreateAndSendTransaction(context);
                        OperationState = newDoorState;
                        StartStrikeTimer();
                        StartEmbarrassmentTimer(NoAdditionalTime);
                        strikeActivated = OperationState == DoorOperationState.Opening;
                        updateReaderTransactionType(ReaderTransactionType.Egress);
                        break;

                    case DoorAgentContexts.ValidCard:
                        if (OperationState == DoorOperationState.Egress || OperationState == DoorOperationState.UnlockedPermanently)
                            break;

                        newDoorState = OperationState;
                        accessControlTransaction.CreateAndSendTransaction(context, inReaderTransaction.Valid, outReaderTransaction.Valid);
                        if (OperationState == DoorOperationState.Unknown || OperationState == DoorOperationState.Closed)
                        {
                            newDoorState = DoorOperationState.Opening;
                            if (IsDeniedAccessTimerInProgress == true)
                            {
                                StopStrikeDeniedAccessTimer();
                            }
                        }
                        else if (OperationState == DoorOperationState.Forced || OperationState == DoorOperationState.Ajar || OperationState == DoorOperationState.Opened)
                        {
                            newDoorState = DoorOperationState.Opened;
                        }
                        StartStrikeTimer();
                        StartEmbarrassmentTimer(NoAdditionalTime);
                        strikeActivated = newDoorState == DoorOperationState.Opening;
                        if (OperationState == DoorOperationState.Opened)
                            UpdateAntipassback();
                        OperationState = newDoorState;
                        break;
                    case DoorAgentContexts.ValidMultiBadgingCard:
                        accessControlTransaction.CreateAndSendTransaction(context);
                        break;
                    case DoorAgentContexts.DeniedAccess:
                        if (OperationState != DoorOperationState.Unknown && OperationState != DoorOperationState.Closed &&
                            OperationState != DoorOperationState.Opening)
                            break;

                        newDoorState = OperationState;
                        if (OperationState == DoorOperationState.Opening)
                        {
                            newDoorState = DoorOperationState.Closed;
                            StopDoorAlarmTimers();
                            StopStrikeDeniedAccessTimer();
                            ResetDoorAlarms();
                        }
                        accessControlTransaction.CreateAndSendTransaction(context);
                        StartDeniedAccessTimer();
                        OperationState = newDoorState;
                        break;

                    case DoorAgentContexts.AccessCommand:
                        if (OperationState == DoorOperationState.Unknown || OperationState == DoorOperationState.Closed ||
                            OperationState == DoorOperationState.UnlockedPermanently || OperationState == DoorOperationState.Opening)
                        {
                            int accessTime = transactionDurationType == DurationType.SpecifiedDuration ? transactionAccessDuration : 
                                                                                                         NoAdditionalTime;
                            if (transactionDurationType != DurationType.Permanent)
                            {
                                accessControlTransaction.CreateAndSendTransaction(context);
                                OperationState = DoorOperationState.Opening;
                                StartStrikeTimer(strikeTime + accessTime);
                                StartEmbarrassmentTimer(accessTime);
                                strikeActivated = true;
                            }
                        }
                        else if (OperationState == DoorOperationState.Forced || OperationState == DoorOperationState.Ajar || 
                                 OperationState == DoorOperationState.Opened)
                        {
                            accessControlTransaction.CreateAndSendTransaction(context);
                            OperationState = DoorOperationState.Opened;
                            StopDoorAlarmTimers();
                            StartEmbarrassmentTimer(transactionAccessDuration);
                            transactionAccessDuration = NoAdditionalTime;
                            strikeActivated = true;
                        }
                        break;

                    case DoorAgentContexts.ShuntTimerExpired:
                        if (OperationState == DoorOperationState.Opened)
                        {
                            accessControlTransaction.CreateAndSendTransaction(context);
                            OperationState = DoorOperationState.Ajar;
                            SetDoorAlarm(DoorAlarms.Ajar);
                        }
                        break;

                    case DoorAgentContexts.EmbarrassmentTimerExpired:
                        if (OperationState == DoorOperationState.Opened)
                        {
                            accessControlTransaction.CreateAndSendTransaction(context);
                            StartShuntTimer(transactionAccessDuration);
                        }
                        break;

                    case DoorAgentContexts.StrikeTimerExpired:
                        accessControlTransaction.CreateAndSendTransaction(context);
                        ExecuteOnStrikeTimerExpired();
                        break;

                    case DoorAgentContexts.DeniedTimerExpired:
                    case DoorAgentContexts.KeypadLockoutTimerExpired:
                        if (OperationState == DoorOperationState.Closed)
                        {
                            accessControlTransaction.CreateAndSendTransaction(context);
                        }
                        break;

                    case DoorAgentContexts.UpdateFromSchedule:
                        if (doorStatus.IsUnlocked)
                        {
                            StopDoorAlarmTimers();
                            StopStrikeDeniedAccessTimer();
                            accessControlTransaction.CreateAndSendTransaction(context);
                            if (OperationState == DoorOperationState.Forced)
                            {
                                ResetDoorAlarms();
                            }
                            OperationState = DoorOperationState.UnlockedPermanently;
                            strikeActivated = true;
                        }
                        else if (doorStatus.IsBlocked)
                        {
                            accessControlTransaction.CreateAndSendTransaction(context);
                            if (doorStatus.IsDoorPhysicallyOpen == true)
                            {
                                SetDoorAlarm(DoorAlarms.Forced);
                                OperationState = DoorOperationState.Forced;
                            }
                            else
                            {
                                OperationState = DoorOperationState.Closed;
                            }
                        }
                        else
                        {
                            accessControlTransaction.CreateAndSendTransaction(context);
                            if (doorStatus.IsDoorPhysicallyOpen == true)
                            {
                                OperationState = DoorOperationState.Forced;
                                SetDoorAlarm(DoorAlarms.Forced);
                            }
                            else
                            {
                                OperationState = DoorOperationState.Closed;
                            }
                        }
                        break;

                    case DoorAgentContexts.CurrentDoorStateRequest:
                        switch (doorStatus.IsUnlocked)
                        {
                            case DoorModeUnlocked:
                                accessControlTransaction.CreateAndSendTransaction(context);
                                OperationState = DoorOperationState.UnlockedPermanently;
                                break;

                            case DoorModeAccessControlled:
                                if (OperationState == DoorOperationState.Unknown || OperationState == DoorOperationState.Closed)
                                {
                                    accessControlTransaction.CreateAndSendTransaction(context);
                                    StopDoorAlarmTimers();
                                    StopStrikeDeniedAccessTimer();
                                    OperationState = doorStatus.IsDoorPhysicallyOpen == true ? DoorOperationState.Forced :
                                                                                          DoorOperationState.Closed;
                                }
                                else if (OperationState == DoorOperationState.Forced || OperationState == DoorOperationState.Opening)
                                {
                                    accessControlTransaction.CreateAndSendTransaction(context);
                                }
                                break;
                        }
                        break;

                    case DoorAgentContexts.IsolateDoorChanged:
                        accessControlTransaction.CreateAndSendTransaction(context);
                        IsolateDoorAlarms(doorStatus.Isolated);
                        break;

                    case DoorAgentContexts.WaitForPinOnInReader:
                        if (OperationState != DoorOperationState.Opening && doorPeripheralTimers != DoorPeripheralTimers.StrikeInProgress)
                        {
                            StopStrikeDeniedAccessTimer();
                        }
                        StartKeypadInactivityInReaderTimer();
                        accessControlTransaction.CreateAndSendTransaction(context);
                        break;

                    case DoorAgentContexts.WaitForPinOnOutReader:
                        if (OperationState != DoorOperationState.Opening && doorPeripheralTimers != DoorPeripheralTimers.StrikeInProgress)
                        {
                            StopStrikeDeniedAccessTimer();
                        }
                        StartKeypadInactivityOutReaderTimer();
                        accessControlTransaction.CreateAndSendTransaction(context);
                        break;

                    case DoorAgentContexts.EndWaitForPinOnInReader:
                        if (IsKeypadInactivityTimerOnInReaderInProgress)
                        {
                            StopKeypadInactivityInReaderTimer();
                            NotifyPinHasBeenEnteredOnInReader();
                            ClearCommandTransaction();
                        }
                        break;

                    case DoorAgentContexts.EndWaitForPinOnOutReader:
                        if (IsKeypadInactivityTimerOnOutReaderInProgress)
                        {
                            StopKeypadInactivityOutReaderTimer();
                            NotifyPinHasBeenEnteredOnOutReader();
                            ClearCommandTransaction();
                        }
                        break;

                    case DoorAgentContexts.KeypadInactivityInReaderTimerExpired:
                        accessControlTransaction.CreateAndSendTransaction(context);
                        NotifyKeypadInactivityTimeoutExpiredOnInReader();
                        ClearCommandTransaction();
                        ClearValidCardTransaction(inReaderStatus.LogicalId);
                        break;

                    case DoorAgentContexts.KeypadInactivityOutReaderTimerExpired:
                        accessControlTransaction.CreateAndSendTransaction(context);
                        NotifyKeypadInactivityTimeoutExpiredOnOutReader();
                        ClearCommandTransaction();
                        ClearValidCardTransaction(outReaderStatus.LogicalId);
                        break;

                    case DoorAgentContexts.InterlockOpened:
                        accessControlTransaction.CreateAndSendTransaction(context);
                        break;
                }

                // Produce door agent status log                
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    doorStatusLogText.Length = 0;
                    doorStatusLogText.Append("[DoorAgent] Door Id:");
                    doorStatusLogText.Append(doorStatus.LogicalId.ToString());
                    doorStatusLogText.Append(" Type:");
                    doorStatusLogText.Append(GetDoorLockOperationAsText(doorLockOperation));
                    doorStatusLogText.Append(" Context:");
                    doorStatusLogText.Append(GetDoorAgentContextsAsText(context));
                    doorStatusLogText.Append(" State:");
                    doorStatusLogText.Append(OperationState.ToString());
                    if (doorAlarmTimers != DoorAlarmTimers.None)
                    {
                        doorStatusLogText.Append(" AlarmTimer:");
                        doorStatusLogText.Append(GetDoorAlarmTimersAsText(doorAlarmTimers));
                    }
                    if (doorPeripheralTimers != DoorPeripheralTimers.None)
                    {
                        doorStatusLogText.Append(" PeripheralTimer:");
                        doorStatusLogText.Append(GetDoorPeripheralTimerAsText(doorPeripheralTimers));
                    }
                    if (IsKeypadInactivityTimerOnInReaderInProgress)
                        doorStatusLogText.Append(" KeyInReaderTimer:Yes");
                    if (IsKeypadInactivityTimerOnOutReaderInProgress)
                        doorStatusLogText.Append(" KeyOutReaderTimer:Yes");
                    if (strikeActivated)
                        doorStatusLogText.Append(" StrikeActive:Yes");

                    string text;
                    SecurityLevelDisplayCommand displayCommand = doorStatus.GetSecurityLevelDisplayCommand(out text);
                    doorStatusLogText.Append(" SecurityLevelDisplay:" + displayCommand.ToString() +
                                             (string.IsNullOrEmpty(text) ? "" : ("-\"" + text + "\"")));

                    string message = doorStatusLogText.ToString();
                    doorStatusLogText.Length = 0;
                    return message;
                });

                return strikeActivated;
            }
        }

        private void updateReaderTransactionType(ReaderTransactionType readerTransactionType)
        {
            if (IsOutReaderAssigned && outReaderTransaction.TransactionType == ReaderTransactionType.None)
            {
                // We have an out reader and it's not busy with something else, so assign to the outreader
                outReaderTransaction.TransactionType = readerTransactionType;
            }
            else if (IsInReaderAssigned && inReaderTransaction.TransactionType == ReaderTransactionType.None)
            {
                // Out reader is busy, but we have an in reader and it's not busy with something else, so assign to the inreader
                inReaderTransaction.TransactionType = readerTransactionType;
            }
            else
            {
                // All available readers are busy, so take over one for this (out preferred over in)
                if (IsOutReaderAssigned)
                {
                    outReaderTransaction.Clear();
                    outReaderTransaction.TransactionType = readerTransactionType;
                }
                else
                {
                    inReaderTransaction.Clear();
                    inReaderTransaction.TransactionType = readerTransactionType;
                }
            }
        }

        internal virtual void ExecuteOnDoorOpenWhenOpening()
        {
            sendAccessTaken();
        }

        internal virtual void ExecuteOnDoorOpenWhenOpened()
        {
            OperationState = DoorOperationState.Closed;
        }

        internal virtual void ExecuteOnDoorBeforeClose()
        {
            StopDoorAlarmTimers();
        }

        internal virtual void ExecuteOnDoorCloseWhenOtherwise()
        {
            OperationState = DoorOperationState.Closed;
        }

        internal virtual void ExecuteOnStrikeTimerExpired()
        {
            if (OperationState == DoorOperationState.Opening)
            {
                CloseDoorSendAccessNotTakenAndClearValidCardTransactions();
            }
        }

        internal void sendAccessTaken()
        {
            if (IsInReaderAssigned)
            {
                if (inReaderTransaction.TransactionType == ReaderTransactionType.Egress)
                {
                    doorStatus.Parent.TriggerAccessTaken(doorStatus.LogicalId, inReaderStatus.LogicalId, null, -1);
                }
                else if (inReaderTransaction.TransactionType == ReaderTransactionType.Card)
                {
                    doorStatus.Parent.TriggerAccessTaken(doorStatus.LogicalId, inReaderStatus.LogicalId, inReaderTransaction);
                }
            }

            if (IsOutReaderAssigned)
            {
                if (outReaderTransaction.TransactionType == ReaderTransactionType.Egress)
                {
                    doorStatus.Parent.TriggerAccessTaken(doorStatus.LogicalId, outReaderStatus.LogicalId, null, -1);
                }
                else if (outReaderTransaction.TransactionType == ReaderTransactionType.Card)
                {
                    doorStatus.Parent.TriggerAccessTaken(doorStatus.LogicalId, outReaderStatus.LogicalId, outReaderTransaction);
                }
            }
        }

        internal void CloseDoorSendAccessNotTakenAndClearValidCardTransactions()
        {
            OperationState = DoorOperationState.Closed;
            if (IsInReaderAssigned)
            {
                if (inReaderTransaction.TransactionType == ReaderTransactionType.Egress)
                {
                    doorStatus.Parent.TriggerAccessNotTaken(doorStatus.LogicalId, inReaderStatus.LogicalId, null, -1);
                }
                else if (inReaderTransaction.TransactionType == ReaderTransactionType.Card)
                {
                    doorStatus.Parent.TriggerAccessNotTaken(doorStatus.LogicalId, inReaderStatus.LogicalId, inReaderTransaction);
                }
            }

            if (IsOutReaderAssigned)
            {
                if (outReaderTransaction.TransactionType == ReaderTransactionType.Egress)
                {
                    doorStatus.Parent.TriggerAccessNotTaken(doorStatus.LogicalId, outReaderStatus.LogicalId, null, -1);
                }
                else if (outReaderTransaction.TransactionType == ReaderTransactionType.Card)
                {
                    doorStatus.Parent.TriggerAccessNotTaken(doorStatus.LogicalId, outReaderStatus.LogicalId, outReaderTransaction);
                }
            }

            ClearAllValidCardTransactions();
        }

        internal void ResetDoorAgent()
        {
            ClearCommandTransaction();
            ClearAllValidCardTransactions();
            StopDoorAlarmTimers();
            StopStrikeDeniedAccessTimer();
            if (doorStatus.IsUnlocked)
                OperationState = DoorOperationState.UnlockedPermanently;
            else
                OperationState = DoorOperationState.Closed;
            if (accessControlTransaction != null)
                accessControlTransaction.CreateAndSendTransaction(DoorAgentContexts.None);
        }

        protected void UpdateAntipassback()
        {
            if (IsInReaderAssigned && inReaderTransaction.Valid)
            {
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Antipassback: Update for in-reader on door {0} with {1}.",
                        doorStatus.LogicalId, inReaderTransaction.Card.ToString());
                });
#endif
                doorStatus.Parent.TriggerUpdateAntipassbackInfo(doorStatus.LogicalId, inReaderStatus.LogicalId, inReaderTransaction.CardInformation);
            }

            if (IsOutReaderAssigned && outReaderTransaction.Valid)
            {
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                {
                    return string.Format("Antipassback: Update for out-reader on door {0} with {1}.",
                        doorStatus.LogicalId, outReaderTransaction.Card.ToString());
                });
#endif
                doorStatus.Parent.TriggerUpdateAntipassbackInfo(doorStatus.LogicalId, outReaderStatus.LogicalId, outReaderTransaction.CardInformation);
            }
        }

        protected void NotifyPinHasBeenEnteredOnInReader()
        {
            if (IsInReaderAssigned && inReaderTransaction.IsCardAssigned && inReaderTransaction.IsPinAssigned)
                doorStatus.Parent.TriggerCardAndPinEntered(doorStatus.LogicalId, inReaderStatus.LogicalId, inReaderTransaction.Card, inReaderTransaction.Pin);
        }

        protected void NotifyPinHasBeenEnteredOnOutReader()
        {
            if (IsOutReaderAssigned && outReaderTransaction.IsPinAssigned && outReaderTransaction.IsPinAssigned)
                doorStatus.Parent.TriggerCardAndPinEntered(doorStatus.LogicalId, outReaderStatus.LogicalId, outReaderTransaction.Card, outReaderTransaction.Pin);
        }

        protected void NotifyKeypadInactivityTimeoutExpiredOnInReader()
        {
            if (IsInReaderAssigned && inReaderTransaction.IsCardAssigned)
                doorStatus.Parent.TriggerKeypadInactivityTimeoutExpired(doorStatus.LogicalId, inReaderStatus.LogicalId);
        }

        protected void NotifyKeypadInactivityTimeoutExpiredOnOutReader()
        {
            if (IsOutReaderAssigned && outReaderTransaction.IsCardAssigned)
                doorStatus.Parent.TriggerKeypadInactivityTimeoutExpired(doorStatus.LogicalId, outReaderStatus.LogicalId);
        }

        internal static string GetDoorLockOperationAsText(DoorLockOperation value)
        {
            switch (value)
            {
                case DoorLockOperation.Normal: return "Normal";
                case DoorLockOperation.MagneticLock: return "Magnetic";
                case DoorLockOperation.DoorBoltMode: return "Bolt";
                default: return "Unknown";
            }
        }

        internal static string GetDoorAgentContextsAsText(DoorAgentContexts value)
        {
            switch (value)
            {
                case DoorAgentContexts.None: return "None";
                case DoorAgentContexts.DoorContact: return "DoorContact";
                case DoorAgentContexts.ShuntTimerExpired: return "ShuntTimer";
                case DoorAgentContexts.EmbarrassmentTimerExpired: return "EmbTimer";
                case DoorAgentContexts.StrikeTimerExpired: return "StrikeTimer";
                case DoorAgentContexts.DeniedTimerExpired: return "DeniedTimer";
                case DoorAgentContexts.Egress: return "Egress";
                case DoorAgentContexts.ValidCard: return "ValidCard";
                case DoorAgentContexts.AccessCommand: return "Command";
                case DoorAgentContexts.DeniedAccess: return "Denied";
                case DoorAgentContexts.UpdateFromSchedule: return "Schedule";
                case DoorAgentContexts.CurrentDoorStateRequest: return "DeviceRequest";
                case DoorAgentContexts.IsolateDoorChanged: return "Isolate";
                case DoorAgentContexts.WaitForPinOnInReader: return "WaitForPinInReader";
                case DoorAgentContexts.WaitForPinOnOutReader: return "WaitForPinOutReader";
                case DoorAgentContexts.EndWaitForPinOnInReader: return "EndWaitPinInReader";
                case DoorAgentContexts.EndWaitForPinOnOutReader: return "EndWaitPinOutReader";
                case DoorAgentContexts.KeypadInactivityInReaderTimerExpired: return "KeyInactivInTimer";
                case DoorAgentContexts.KeypadInactivityOutReaderTimerExpired: return "KeyInactivOutTimer";
                default: return "Unknown";
            }
        }

        internal static string GetDoorOperationStateAsText(DoorOperationState value)
        {
            switch (value)
            {
                case DoorOperationState.Opening: return "Opening";
                case DoorOperationState.Opened: return "Opened";
                case DoorOperationState.Closed: return "Closed";
                case DoorOperationState.Egress: return "Egress";
                case DoorOperationState.Forced: return "Forced";
                case DoorOperationState.Ajar: return "Ajar";
                case DoorOperationState.UnlockedPermanently: return "UnlockedPerm";
                default: return "Unknown";
            }
        }

        internal static string GetDoorAlarmTimersAsText(DoorAlarmTimers value)
        {
            switch (value)
            {
                case DoorAlarmTimers.None: return "None";
                case DoorAlarmTimers.EmbarrassmentTimerInProgress: return "Embarrassment";
                case DoorAlarmTimers.ShuntTimerInProgress: return "Shunt";
                default: return "Unknown";
            }
        }

        internal static string GetDoorPeripheralTimerAsText(DoorPeripheralTimers value)
        {
            switch (value)
            {
                case DoorPeripheralTimers.None: return "None";
                case DoorPeripheralTimers.AccessDeniedInProgress: return "AccDenied";
                case DoorPeripheralTimers.StrikeInProgress: return "Strike";
                default: return "Unknown";
            }
        }

        #region Agent Alarm Managment

        protected DoorAlarms doorAlarm = DoorAlarms.None;
        private DoorAlarms lastDoorAlarmSent = DoorAlarms.None;

        /// <summary>
        /// Returns the current door alarm
        /// </summary>
        public DoorAlarms DoorAlarm 
        { 
            get { return doorAlarm; } 
        }

        /// <summary>
        /// Returns the last door alarm sent
        /// </summary>
        public DoorAlarms LastDoorAlarmSent
        {
            get { return lastDoorAlarmSent; }
        }

        /// <summary>
        /// Set door alarm: Ajar / Forced and broadcast it.
        /// </summary>
        /// <param name="alarm">Alarm: One of Ajar / Forced</param>
        protected void SetDoorAlarm(DoorAlarms alarm)
        {
            if (alarm == DoorAlarms.None)
                return;

            bool notifyArea = true;
            // If alarm is already present do not notify area
            if (doorAlarm != DoorAlarms.None)
                notifyArea = false;

            resetDoorAlarms(false);
            doorAlarm = alarm;
            lastDoorAlarmSent = alarm;
            if (doorStatus.Isolated == false)
            {
                if (alarm == DoorAlarms.Forced) 
                    doorStatus.Parent.TriggerDoorForced(doorStatus, false);
                else
                    doorStatus.Parent.TriggerDoorAjar(doorStatus, false);
            }

            if (notifyArea == true)
                doorStatus.UpdateInAlarm();
        }

        protected void IsolateDoorAlarms(bool isolate)
        {
            lastDoorAlarmSent = isolate ? DoorAlarms.None : doorAlarm;
            if (doorAlarm == DoorAlarms.Ajar)
                doorStatus.Parent.TriggerDoorAjar(doorStatus, isolate);
            else if (doorAlarm == DoorAlarms.Forced)
                doorStatus.Parent.TriggerDoorForced(doorStatus, isolate);
        }

        protected void ResetDoorAlarms()
        {
            resetDoorAlarms(true);
        }

        private void resetDoorAlarms(bool notifyArea)
        {
            bool presentAlarmDetected = false;
            if (lastDoorAlarmSent == DoorAlarms.Forced)
            {
                if (doorStatus.Isolated == false)
                    doorStatus.Parent.TriggerDoorForced(doorStatus, true);
                presentAlarmDetected = true;
            }
            else if (lastDoorAlarmSent == DoorAlarms.Ajar)
            {
                if (doorStatus.Isolated == false)
                    doorStatus.Parent.TriggerDoorAjar(doorStatus, true);
                presentAlarmDetected = true;
            }
            doorAlarm = DoorAlarms.None;
            lastDoorAlarmSent = DoorAlarms.None;

            if (notifyArea == true && presentAlarmDetected == true)
                doorStatus.UpdateInAlarm();
        }

        #endregion

        #region Agent Timer Managment

        protected DoorAlarmTimers doorAlarmTimers = DoorAlarmTimers.None;
        public DoorAlarmTimers DoorAlarmTimers
        {
            get { return doorAlarmTimers; }
        }

        protected void StopDoorAlarmTimers()
        {
            shuntEmbarrassmentTimer.Stop();
            doorAlarmTimers = DoorAlarmTimers.None;
        }

        protected void StartShuntTimer(int additionalTime)
        {
            doorAlarmTimers = DoorAlarmTimers.ShuntTimerInProgress;
            shuntEmbarrassmentTimer.RunOnce(DoorOpenTooLongTime + additionalTime);
        }

        protected void StartEmbarrassmentTimer(int additionalTime)
        {
            doorAlarmTimers = DoorAlarmTimers.EmbarrassmentTimerInProgress;
            shuntEmbarrassmentTimer.RunOnce(embarrassmentTime + additionalTime);
        }

        private void shuntEmbarrassmentTimerProc(object state)
        {
            if (disposing == true || disposed == true)
                return;

            switch (doorAlarmTimers)
            {
                case DoorAlarmTimers.ShuntTimerInProgress:
                    doorAlarmTimers = DoorAlarmTimers.None;
                    UpdateAgentState(DoorAgentContexts.ShuntTimerExpired);
                    break;
                case DoorAlarmTimers.EmbarrassmentTimerInProgress:
                    doorAlarmTimers = DoorAlarmTimers.None;
                    UpdateAgentState(DoorAgentContexts.EmbarrassmentTimerExpired);
                    break;
            }
        }

        #endregion

        #region Keypad Reader Inactivity Managment

        private bool keypadInactivityInReaderTimerInProgress = false;

        private bool keypadInactivityOutReaderTimerInProgress = false;

        protected void StartKeypadInactivityInReaderTimer()
        {
            keypadInactivityInReaderTimerInProgress = true;
            keypadInactivityInReaderTimer.RunOnce(this.keypadInactivityTimeout);
        }

        protected void StartKeypadInactivityOutReaderTimer()
        {
            keypadInactivityOutReaderTimerInProgress = true;
            keypadInactivityOutReaderTimer.RunOnce(this.keypadInactivityTimeout);
        }

        protected void StopKeypadInactivityInReaderTimer()
        {
            keypadInactivityInReaderTimer.Stop();
            keypadInactivityInReaderTimerInProgress = false;
        }

        protected void StopKeypadInactivityOutReaderTimer()
        {
            keypadInactivityOutReaderTimer.Stop();
            keypadInactivityOutReaderTimerInProgress = false;
        }

        public bool IsKeypadInactivityTimerOnInReaderInProgress
        {
            get { return keypadInactivityInReaderTimerInProgress; }
        }

        public bool IsKeypadInactivityTimerOnOutReaderInProgress
        {
            get { return keypadInactivityOutReaderTimerInProgress; }
        }

        private void keypadInactivityInReaderTimerProc(object state)
        {
            if (disposing == true || disposed == true)
                return;
            keypadInactivityInReaderTimerInProgress = false;
            UpdateAgentState(DoorAgentContexts.KeypadInactivityInReaderTimerExpired);
        }

        private void keypadInactivityOutReaderTimerProc(object state)
        {
            if (disposing == true || disposed == true)
                return;
            keypadInactivityOutReaderTimerInProgress = false;
            UpdateAgentState(DoorAgentContexts.KeypadInactivityOutReaderTimerExpired);
        }

        #endregion

        #region Strike and Denied Access Managment

        protected DoorPeripheralTimers doorPeripheralTimers = DoorPeripheralTimers.None;
        public DoorPeripheralTimers PeripheralTimers
        {
            get { return doorPeripheralTimers; }
            set { doorPeripheralTimers = value; }
        }

        protected void StopStrikeDeniedAccessTimer()
        {
            deactivateStrikeDeniedAccessTimer.Stop();
            doorPeripheralTimers = DoorPeripheralTimers.None;
        }

        protected void StartStrikeTimer(int strikeTimeValue)
        {
            doorPeripheralTimers = DoorPeripheralTimers.StrikeInProgress;
            deactivateStrikeDeniedAccessTimer.RunOnce(strikeTimeValue);
        }

        protected void StartStrikeTimer()
        {
            doorPeripheralTimers = DoorPeripheralTimers.StrikeInProgress;
            deactivateStrikeDeniedAccessTimer.RunOnce(strikeTime);
        }

        protected void StartDeniedAccessTimer()
        {
            doorPeripheralTimers = DoorPeripheralTimers.AccessDeniedInProgress;
            deactivateStrikeDeniedAccessTimer.RunOnce(AccessDeniedDuration);
        }

        public bool IsDeniedAccessTimerInProgress
        {
            get { return doorPeripheralTimers == DoorPeripheralTimers.AccessDeniedInProgress; }
        }

        private void deactivateStrikeDeniedAccessProc(object state)
        {
            if (disposing == true || disposed == true)
                return;

            switch (doorPeripheralTimers)
            {
                case DoorPeripheralTimers.StrikeInProgress:
                    doorPeripheralTimers = DoorPeripheralTimers.None;
                    UpdateAgentState(DoorAgentContexts.StrikeTimerExpired);
                    break;
                case DoorPeripheralTimers.AccessDeniedInProgress:
                    doorPeripheralTimers = DoorPeripheralTimers.None;
                    UpdateAgentState(DoorAgentContexts.DeniedTimerExpired);
                    break;
            }
        }

        #endregion

        #region IDisposable Members

        bool disposed = false;

        bool disposing = false;

        protected void Dispose(bool disposing)
        {
            try
            {
                if (disposed == false)
                {
                    if (disposing)
                    {
                        this.disposing = true;

                        if (shuntEmbarrassmentTimer != null)
                        {
                            TimerManager.Instance.RemoveTimer(shuntEmbarrassmentTimer);
                            shuntEmbarrassmentTimer = null;
                        }
                        if (deactivateStrikeDeniedAccessTimer != null)
                        {
                            TimerManager.Instance.RemoveTimer(deactivateStrikeDeniedAccessTimer);
                            deactivateStrikeDeniedAccessTimer = null;
                        }

                        if (accessControlTransaction != null)
                        {
                            accessControlTransaction.Dispose();
                            accessControlTransaction = null;
                        }
                        OperationState = DoorOperationState.Unknown;

                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Door agent for DoorId={0} - Successfully Destroyed.", doorStatus.LogicalId);
                        });
                    }
                    disposed = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while disposing door agent. {0}", ex.ToString());
                });
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
