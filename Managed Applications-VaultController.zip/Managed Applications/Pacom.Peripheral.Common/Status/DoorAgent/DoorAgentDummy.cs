﻿using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Dummy door agent without any action.
    /// </summary>
    internal class DoorAgentDummy : DoorAgentBase
    {
        internal DoorAgentDummy(DoorStatus door, ReaderStatus inReader, ReaderStatus outReader)
            : base(DoorLockOperation.Normal, door, inReader, outReader) { }

        public override bool UpdateAgentState(DoorAgentContexts context) { return false; }

    }
}
