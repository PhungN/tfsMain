﻿using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Normal door lock operation. The strike output is released when the door contact activates or when the strike time expires.
    /// </summary>
    internal class DoorAgentNormal : DoorAgentBase
    {
        internal DoorAgentNormal(DoorStatus door, ReaderStatus inReader, ReaderStatus outReader)
            : base(DoorLockOperation.Normal, door, inReader, outReader) 
        {
            accessControlTransaction = new DoorAccessControlTransactionAgent(this, doorStatus);
        }
    }
}
