﻿using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Magnetic door lock operation. The strike output is released when the door contact deactivates after being activated or when the strike time expires.
    /// </summary>
    internal class DoorAgentMagnetic : DoorAgentBase
    {
        internal DoorAgentMagnetic(DoorStatus door, ReaderStatus inReader, ReaderStatus outReader)
            : base(DoorLockOperation.MagneticLock, door, inReader, outReader) 
        {
            accessControlTransaction = new DoorAccessControlTransactionAgent(this, doorStatus);
        }
    }
}
