﻿using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Door bolt mode operation. The strike output is released when the strike time expires or if the door contact 
    /// has been activated and is still active when the strike time expires, released when the door contact deactivates.
    /// </summary>
    internal class DoorAgentBolt : DoorAgentBase
    {
        /// <summary>
        /// Timeout required to deactivate the strike after the door was opened.
        /// </summary>
        protected const int DefaultDeactivateStrikeTimeout = 3000;

        internal DoorAgentBolt(DoorStatus door, ReaderStatus inReader, ReaderStatus outReader)
            : base(DoorLockOperation.DoorBoltMode, door, inReader, outReader) 
        {
            accessControlTransaction = new DoorAccessControlTransactionAgent(this, doorStatus);
        }

        /// <summary>
        /// Get Default Deactivate Strike Timeout For Bolt Door
        /// </summary>
        public override int DeactivateStrikeTimeout
        {
            get { return DefaultDeactivateStrikeTimeout; }
        }

        internal override void ExecuteOnDoorOpenWhenOpening()
        {
            StartStrikeTimer(DefaultDeactivateStrikeTimeout);
            base.ExecuteOnDoorOpenWhenOpening();
        }

        internal override void ExecuteOnDoorOpenWhenOpened() { }

        internal override void ExecuteOnDoorBeforeClose() { }

        internal override void ExecuteOnDoorCloseWhenOtherwise()
        {
            StartStrikeTimer(DefaultDeactivateStrikeTimeout);
        }

        internal override void ExecuteOnStrikeTimerExpired()
        {
            if (doorStatus.IsDoorPhysicallyOpen == true)
            {
                StartStrikeTimer(DefaultDeactivateStrikeTimeout);
            }
            else
            {
                CloseDoorSendAccessNotTakenAndClearValidCardTransactions();
            }
        }
    }
}
