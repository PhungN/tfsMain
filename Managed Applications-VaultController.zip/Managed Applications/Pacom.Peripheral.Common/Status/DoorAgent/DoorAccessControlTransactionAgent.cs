﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using TT = Pacom.Peripheral.Common.Status.TransactionType;

namespace Pacom.Peripheral.Common.Status
{
    public class DoorAccessControlTransactionAgent : IDisposable
    {
        protected class AcceptLedConfig
        {
            public AcceptLedConfig(DoorAccessControlTransactionAgent owner)
            {
                Owner = owner;
            }

            public DoorAccessControlTransactionAgent Owner
            {
                get;
                private set;
            }

            public TT OnOffFlashing()
            {
                switch (Owner.Context)
                {
                    case DoorAgentContexts.InterlockOpened:
                        return interlocked();
                    case DoorAgentContexts.ValidCard:
                    case DoorAgentContexts.Egress:
                        Owner.StartPeripheralsTimer(PeripheralTimers.AcceptLedInProgress);
                        if (Owner.DoorStatus.Isolated)
                            return TT.AcceptOff;
                        return Owner.DoorConfiguration.FlashAcceptLed ? TT.AcceptFlashing : TT.AcceptOn;
                    case DoorAgentContexts.DoorContact:
                        if (Owner.DoorStatus.IsDoorPhysicallyOpen == true)
                        {
                            if (Owner.DoorAgent.OperationState == DoorOperationState.Unknown || Owner.DoorAgent.OperationState == DoorOperationState.Closed)
                            {
                                return Owner.DoorStatus.Isolated ? TT.AcceptOff : doorForced();
                            }
                            else if (Owner.DoorAgent.OperationState == DoorOperationState.Opened)
                            {
                                return closeDoor();
                            }
                        }
                        else
                        {
                            return Owner.DoorStatus.IsUnlocked ? doorUnlock() : closeDoor();
                        }
                        break;
                    case DoorAgentContexts.AccessCommand:
                        if (Owner.DoorAgent.OperationState == DoorOperationState.Unknown || Owner.DoorAgent.OperationState == DoorOperationState.Closed ||
                            Owner.DoorAgent.OperationState == DoorOperationState.UnlockedPermanently || Owner.DoorAgent.OperationState == DoorOperationState.Opening)
                        {
                            if (Owner.DoorAgent.TransactionDurationType != DurationType.Permanent)
                            {
                                Owner.StartPeripheralsTimer(PeripheralTimers.AcceptLedInProgress);
                                return Owner.DoorConfiguration.FlashAcceptLed ? TT.AcceptFlashing : TT.AcceptOn;
                            }
                        }
                        else if (Owner.DoorAgent.OperationState == DoorOperationState.Forced || Owner.DoorAgent.OperationState == DoorOperationState.Ajar ||
                                 Owner.DoorAgent.OperationState == DoorOperationState.Opened)
                        {
                            Owner.StartPeripheralsTimer(PeripheralTimers.AcceptLedInProgress);
                            return Owner.DoorConfiguration.FlashAcceptLed ? TT.AcceptFlashing : TT.AcceptOn;
                        }
                        break;
                    case DoorAgentContexts.ShuntTimerExpired:
                        bool isDefaultAcceptLedBehaviour = Owner.DoorConfiguration.AcceptLedAjarAndForcedBehaviour == LedBehaviour.Off;
                        if (isDefaultAcceptLedBehaviour == true || Owner.DoorStatus.Isolated == true)
                            return TT.AcceptOff;
                        else
                            return Owner.DoorConfiguration.AcceptLedAjarAndForcedBehaviour == LedBehaviour.Flashing ? TT.AcceptFlashing : TT.AcceptOn;
                    case DoorAgentContexts.EmbarrassmentTimerExpired:
                        switch (Owner.DoorConfiguration.AcceptLedAccessWarningBehaviour)
                        {
                            case LedBehaviour.Off: return TT.AcceptOff;
                            case LedBehaviour.On: return Owner.DoorStatus.Isolated ? TT.AcceptOff : TT.AcceptOn;
                            case LedBehaviour.Flashing: return Owner.DoorStatus.Isolated ? TT.AcceptOff : TT.AcceptFlashing;
                        }
                        break;
                    case DoorAgentContexts.DeniedTimerExpired:
                    case DoorAgentContexts.KeypadLockoutTimerExpired:
                        return closeDoor();
                    case DoorAgentContexts.StrikeTimerExpired:
                        switch (Owner.DoorAgent.DoorLockOperation)
                        {
                            case DoorLockOperation.Normal:
                            case DoorLockOperation.MagneticLock:
                                return Owner.DoorAgent.OperationState == DoorOperationState.Opening ? closeDoor() : TT.None;
                            case DoorLockOperation.DoorBoltMode:
                                return Owner.DoorStatus.IsDoorPhysicallyOpen == false ? closeDoor() : TT.None;
                            default:
                                return TT.None;
                        }
                    case DoorAgentContexts.UpdateFromSchedule:
                        if (Owner.DoorStatus.IsUnlocked == true)
                            return doorUnlock();
                        else
                        {
                            if (Owner.DoorStatus.IsDoorPhysicallyOpen == true)
                            {
                                return doorForcedNew();
                            }
                            return TT.None;
                        }
                    case DoorAgentContexts.CurrentDoorStateRequest:
                        if (Owner.DoorStatus.IsUnlocked)
                            return doorUnlock();
                        else if (Owner.DoorAgent.OperationState == DoorOperationState.Unknown || Owner.DoorAgent.OperationState == DoorOperationState.Closed)
                        {
                            if (Owner.DoorStatus.IsDoorPhysicallyOpen == true)
                            {
                                return doorForcedNew();
                            }
                        }
                        else if (Owner.DoorAgent.OperationState == DoorOperationState.Forced)
                        {
                            return doorForcedNew();
                        }
                        else if (Owner.DoorAgent.OperationState == DoorOperationState.Opening)
                        {
                            return Owner.DoorConfiguration.FlashAcceptLed ? TT.AcceptFlashing : TT.AcceptOn;
                        }
                        return TT.None;
                    case DoorAgentContexts.DoorContactAlarm:
                        return doorForced();
                    case DoorAgentContexts.IsolateDoorChanged:
                        if (Owner.DoorStatus.Isolated == false && (Owner.DoorAgent.OperationState == DoorOperationState.Ajar || Owner.DoorAgent.OperationState == DoorOperationState.Forced))
                            return doorForced();
                        else
                            return TT.None;
                }
                return TT.None;
            }

            private TransactionType interlocked()
            {
                switch (Owner.DoorConfiguration.AcceptLedInterlockBehaviour)
                {
                    default:
                        return TransactionType.AcceptOn;
                    case LedBehaviour.Off:
                        return TransactionType.AcceptOff;
                    case LedBehaviour.Flashing:
                        return TransactionType.AcceptFlashing;
                }
            }

            private TT closeDoor()
            {
                if ((Owner.DoorAgent.IsInReaderAssigned && Owner.DoorAgent.InReaderStatus.LockedOut) || 
                    (Owner.DoorAgent.IsOutReaderAssigned && Owner.DoorAgent.OutReaderStatus.LockedOut))
                    return TT.AcceptOff;
                else if (Owner.DoorAgent.IsKeypadInactivityTimerOnInReaderInProgress == true || Owner.DoorAgent.IsKeypadInactivityTimerOnOutReaderInProgress == true)
                    return TT.AcceptFlashing;
                else
                    return TT.AcceptOff;
            }

            private TT doorForced()
            {
                Owner.StopPeripheralsTimer();
                TT tt = TT.None;
                bool isDefaultAcceptLedBehaviour = Owner.DoorConfiguration.AcceptLedAjarAndForcedBehaviour == LedBehaviour.Off;
                if (isDefaultAcceptLedBehaviour == true)
                {
                    tt = TT.AcceptOff;
                }
                else
                {
                    tt = Owner.DoorConfiguration.AcceptLedAjarAndForcedBehaviour == LedBehaviour.Flashing ? TT.AcceptFlashing : TT.AcceptOn;
                }
                return tt;
            }

            private TT doorForcedNew()
            {
                switch (Owner.DoorConfiguration.AcceptLedAjarAndForcedBehaviour)
                {
                    case LedBehaviour.Off: return TT.AcceptOff;
                    case LedBehaviour.On: return TT.AcceptOn;
                    case LedBehaviour.Flashing: return TT.AcceptFlashing;
                }
                return TT.None;
            }

            private TT doorUnlock()
            {
                switch (Owner.DoorConfiguration.AcceptLedUnlockBehaviour)
                {
                    case LedBehaviour.Off: return TT.AcceptOff;
                    case LedBehaviour.On: return TT.AcceptOn;
                    case LedBehaviour.Flashing: return TT.AcceptFlashing;
                }
                return TT.None;
            }
        }

        protected class DeniedLedConfig
        {
            public DeniedLedConfig(DoorAccessControlTransactionAgent owner)
            {
                Owner = owner;
            }

            public DoorAccessControlTransactionAgent Owner
            {
                get;
                private set;
            }

            public TT OnOffFlashing()
            {
                switch (Owner.Context)
                {
                    case DoorAgentContexts.InterlockOpened:
                        return interlocked();
                    case DoorAgentContexts.DeniedAccess:
                        Owner.StartPeripheralsTimer(PeripheralTimers.DeniedLedInProgress);
                        return Owner.DoorConfiguration.FlashDeniedLed ? TT.DeniedFlashing : TT.DeniedOn;
                    case DoorAgentContexts.DoorContactAlarm:
                        return doorForced();
                    case DoorAgentContexts.DoorContact:
                        if (Owner.DoorStatus.IsDoorPhysicallyOpen == true)
                        {
                            if (Owner.DoorAgent.OperationState == DoorOperationState.Unknown || Owner.DoorAgent.OperationState == DoorOperationState.Closed)
                            {
                                return Owner.DoorStatus.Isolated ? TT.DeniedOff : doorForced();
                            }
                            else if (Owner.DoorAgent.OperationState == DoorOperationState.Opened)
                            {
                                return closeDoor();
                            }
                        }
                        else
                        {
                            return closeDoor();
                        }
                        break;
                    case DoorAgentContexts.ShuntTimerExpired:
                        return Owner.DoorStatus.Isolated ? TT.DeniedOff : doorForced();
                    case DoorAgentContexts.EmbarrassmentTimerExpired:
                        switch (Owner.DoorConfiguration.DeniedLedAccessWarningBehaviour)
                        {
                            case LedBehaviour.Off: return TT.DeniedOff;
                            case LedBehaviour.On: return Owner.DoorStatus.Isolated ? TT.DeniedOff : TT.DeniedOn;
                            case LedBehaviour.Flashing: return Owner.DoorStatus.Isolated ? TT.DeniedOff : TT.DeniedFlashing;
                        }
                        break;
                    case DoorAgentContexts.DeniedTimerExpired:
                    case DoorAgentContexts.KeypadLockoutTimerExpired:
                        return closeDoor();
                    case DoorAgentContexts.StrikeTimerExpired:
                        switch (Owner.DoorAgent.DoorLockOperation)
                        {
                            case DoorLockOperation.Normal:
                            case DoorLockOperation.MagneticLock:
                                return Owner.DoorAgent.OperationState == DoorOperationState.Opening ? closeDoor() : TT.None;
                            case DoorLockOperation.DoorBoltMode:
                                return Owner.DoorStatus.IsDoorPhysicallyOpen == false ? closeDoor() : TT.None;
                            default:
                                return TT.None;
                        }
                    case DoorAgentContexts.UpdateFromSchedule:
                        if (Owner.DoorStatus.IsBlocked == true && Owner.DoorStatus.IsDoorPhysicallyOpen == false)
                            return doorLock();
                        else
                        {
                            if (Owner.DoorStatus.IsDoorPhysicallyOpen == true)
                            {
                                return doorForcedNoTimer();
                            }
                            return TT.None;
                        }
                    case DoorAgentContexts.CurrentDoorStateRequest:
                        if (Owner.DoorStatus.IsBlocked)
                            return doorLock();
                        else if (Owner.DoorAgent.OperationState == DoorOperationState.Unknown || Owner.DoorAgent.OperationState == DoorOperationState.Closed)
                        {
                            if (Owner.DoorStatus.IsDoorPhysicallyOpen == true)
                            {
                                return doorForcedNoTimer();
                            }
                            return TT.None;
                        }
                        else
                            return doorForced();
                    case DoorAgentContexts.IsolateDoorChanged:
                        if (Owner.DoorStatus.Isolated == false && (Owner.DoorAgent.OperationState == DoorOperationState.Ajar || Owner.DoorAgent.OperationState == DoorOperationState.Forced))
                            return doorForced();
                        else
                            return TT.None;

                }
                return TT.None;
            }
            
            private TransactionType interlocked()
            {
                switch (Owner.DoorConfiguration.DeniedLedInterlockBehaviour)
                {
                    default:
                        return TransactionType.DeniedOn;
                    case LedBehaviour.Off:
                        return TransactionType.DeniedOff;
                    case LedBehaviour.Flashing:
                        return TransactionType.DeniedFlashing;
                }
            }

            private TT closeDoor()
            {
                if ((Owner.DoorAgent.IsInReaderAssigned && Owner.DoorAgent.InReaderStatus.LockedOut) || 
                    (Owner.DoorAgent.IsOutReaderAssigned && Owner.DoorAgent.OutReaderStatus.LockedOut))
                {
                    return doorLock();
                }
                else if (Owner.DoorAgent.IsKeypadInactivityTimerOnInReaderInProgress == true ||
                         Owner.DoorAgent.IsKeypadInactivityTimerOnOutReaderInProgress == true)
                {
                    return TT.DeniedOff;
                }
                else
                {
                    return Owner.DoorStatus.IsBlocked ? doorLock() : TT.DeniedOff;
                }
            }

            private TT doorForced()
            {
                Owner.StopPeripheralsTimer();
                return doorForcedNoTimer();
            }

            private TT doorForcedNoTimer()
            {
                switch (Owner.DoorConfiguration.DeniedLedAjarAndForcedBehaviour)
                {
                    case LedBehaviour.Off: return TT.DeniedOff;
                    case LedBehaviour.On: return TT.DeniedOn;
                    case LedBehaviour.Flashing: return TT.DeniedFlashing;
                }
                return TT.None;
            }

            private TT doorLock()
            {
                switch (Owner.DoorConfiguration.DeniedLedLockBehaviour)
                {
                    case LedBehaviour.Off: return TT.DeniedOff;
                    case LedBehaviour.On: return TT.DeniedOn;
                    case LedBehaviour.Flashing: return TT.DeniedFlashing;
                }
                return TT.None;
            }
        }

        protected class BuzzerConfig
        {
            public BuzzerConfig(DoorAccessControlTransactionAgent owner)
            {
                Owner = owner;
            }

            public DoorAccessControlTransactionAgent Owner
            {
                get;
                private set;
            }

            public TT OffOnPulse()
            {
                switch (Owner.Context)
                {
                    case DoorAgentContexts.InterlockOpened:
                        return interlocked();
                    case DoorAgentContexts.ValidCard:
                        return Owner.DoorStatus.Isolated ? TT.BuzzerOff : validCard();
                    case DoorAgentContexts.Egress:
                        return egress();
                    case DoorAgentContexts.DeniedAccess:
                        return deniedAccess();
                    case DoorAgentContexts.DoorContactAlarm:
                        return doorForced();
                    case DoorAgentContexts.DoorContact:
                        if (Owner.DoorAgent.OperationState == DoorOperationState.Unknown || Owner.DoorAgent.OperationState == DoorOperationState.Closed)
                        {
                            return Owner.DoorStatus.Isolated ? TT.BuzzerOff : doorForced();
                        }
                        break;
                    case DoorAgentContexts.AccessCommand:
                        bool isDefaultBuzzer = Owner.DoorConfiguration.BuzzerValidCardBehaviour == BuzzerBehaviour.NoBuzzer;
                        if (Owner.DoorAgent.OperationState == DoorOperationState.Unknown || Owner.DoorAgent.OperationState == DoorOperationState.Closed ||
                            Owner.DoorAgent.OperationState == DoorOperationState.UnlockedPermanently || Owner.DoorAgent.OperationState == DoorOperationState.Opening)
                        {
                            if (Owner.DoorAgent.TransactionDurationType != DurationType.Permanent)
                            {
                                if (isDefaultBuzzer == true)
                                    return TT.BuzzerOff;
                                else
                                {
                                    // Use Valid Card Buzzer On or Pulse for Egress
                                    return Owner.DoorConfiguration.BuzzerValidCardBehaviour == BuzzerBehaviour.Continuous ? TT.BuzzerOn : TT.PulseBuzzer;
                                }
                            }
                        }
                        else if (Owner.DoorAgent.OperationState == DoorOperationState.Forced || Owner.DoorAgent.OperationState == DoorOperationState.Ajar ||
                                 Owner.DoorAgent.OperationState == DoorOperationState.Opened)
                        {
                            if (isDefaultBuzzer == true)
                                return TT.BuzzerOff;
                            else
                            {
                                // Use Valid Card Buzzer On or Pulse for Egress
                                return Owner.DoorConfiguration.BuzzerValidCardBehaviour == BuzzerBehaviour.Continuous ? TT.BuzzerOn : TT.PulseBuzzer;
                            }
                        }
                        break;
                    case DoorAgentContexts.ShuntTimerExpired:
                        return doorForced();
                    case DoorAgentContexts.EmbarrassmentTimerExpired:
                        return Owner.DoorStatus.Isolated ? TT.BuzzerOff : accessWarning();
                    case DoorAgentContexts.StrikeTimerExpired:
                        switch (Owner.DoorAgent.DoorLockOperation)
                        {
                            case DoorLockOperation.Normal:
                            case DoorLockOperation.MagneticLock:
                                return Owner.DoorAgent.OperationState == DoorOperationState.Opening ? TT.BuzzerOff : TT.None;
                            case DoorLockOperation.DoorBoltMode:
                                return Owner.DoorStatus.IsDoorPhysicallyOpen == false ? TT.BuzzerOff : TT.None;
                            default:
                                return TT.None;
                        }
                    case DoorAgentContexts.IsolateDoorChanged:
                        if (Owner.DoorAgent.OperationState == DoorOperationState.Ajar || Owner.DoorAgent.OperationState == DoorOperationState.Forced)
                            return doorForced();
                        return accessWarning();
                    case DoorAgentContexts.UpdateFromSchedule:
                        if (Owner.DoorStatus.IsDoorPhysicallyOpen == true)
                        {
                            return doorForced();
                        }
                        return TT.None;
                    case DoorAgentContexts.CurrentDoorStateRequest:
                        if (Owner.DoorAgent.OperationState == DoorOperationState.Unknown || Owner.DoorAgent.OperationState == DoorOperationState.Closed)
                        {
                            if (Owner.DoorStatus.IsDoorPhysicallyOpen == true)
                            {
                                return doorForced();
                            }
                        }
                        else if (Owner.DoorAgent.OperationState == DoorOperationState.Forced)
                        {
                            return doorForced();
                        }
                        return TT.None;
                }
                return TT.None;
            }

            private TransactionType interlocked()
            {
                switch (Owner.DoorConfiguration.BuzzerInterlockBehaviour)
                {
                    case BuzzerBehaviour.Continuous:
                        return TT.BuzzerOn;
                    case BuzzerBehaviour.Pulse:
                        return TT.PulseBuzzer;
                    default:
                        return TT.BuzzerOff;
                }
            }

            private TT doorForced()
            {
                if (Owner.DoorStatus.Isolated == true)
                    return TT.BuzzerOff;
                switch (Owner.DoorConfiguration.BuzzerAjarAndForcedBehaviour)
                {
                    case BuzzerBehaviour.NoBuzzer: return TT.BuzzerOff;
                    case BuzzerBehaviour.Continuous: return TT.BuzzerOn;
                    case BuzzerBehaviour.Pulse: return TT.PulseBuzzer;
                }
                return TT.BuzzerOff;
            }

            /// <summary>
            /// Get buzzer behaviour for egress context. Check for default buzzer valid card behaviour 1st.
            /// </summary>
            /// <returns></returns>
            private TT egress()
            {
                TT buzzer = TT.None;
                bool isDefaultBuzzer = Owner.DoorConfiguration.BuzzerValidCardBehaviour == BuzzerBehaviour.NoBuzzer;
                if (isDefaultBuzzer == true)
                {
                    if (Owner.DoorAgent.OperationState == DoorOperationState.Forced || Owner.DoorAgent.OperationState == DoorOperationState.Ajar ||
                        Owner.DoorAgent.OperationState == DoorOperationState.Opened)
                    {
                        buzzer = TT.BuzzerOff;
                    }
                }
                else
                {
                    // Use Valid Card Buzzer On or Pulse for Egress
                    buzzer = Owner.DoorConfiguration.BuzzerValidCardBehaviour == BuzzerBehaviour.Continuous ? TT.BuzzerOn : TT.PulseBuzzer;
                }
                return buzzer;
            }

            /// <summary>
            /// Get buzzer behaviour for valid card context. When BuzzerValidCardBehaviour == NoBuzzer the behaviour is the same with
            /// the legacy one: transcation type = None apart from when the denied access timer is in progress or when the current door 
            /// state is forced / ajar / opened when the transaction type = BuzzerOff. Otherwise the buzzer will beep continously or
            /// pulse for the accept Led duration or until stopped because of door agent context change.
            /// </summary>
            /// <returns></returns>
            private TT validCard()
            {
                TT buzzer = TT.None;
                bool isDefaultBuzzer = Owner.DoorConfiguration.BuzzerValidCardBehaviour == BuzzerBehaviour.NoBuzzer;
                if (isDefaultBuzzer == true)
                {
                    if (Owner.DoorAgent.OperationState == DoorOperationState.Unknown || Owner.DoorAgent.OperationState == DoorOperationState.Closed)
                    {
                        if (Owner.DoorAgent.IsDeniedAccessTimerInProgress == true)
                        {
                            buzzer = TT.BuzzerOff;
                        }
                    }
                    else if (Owner.DoorAgent.OperationState == DoorOperationState.Forced || Owner.DoorAgent.OperationState == DoorOperationState.Ajar ||
                             Owner.DoorAgent.OperationState == DoorOperationState.Opened)
                    {
                        buzzer = TT.BuzzerOff;
                    }
                }
                else
                {
                    // Valid Card Buzzer On or Pulse
                    buzzer = Owner.DoorConfiguration.BuzzerValidCardBehaviour == BuzzerBehaviour.Continuous ? TT.BuzzerOn : TT.PulseBuzzer;
                }
                return buzzer;
            }

            /// <summary>
            /// Get buzzer behaviour for denied access context. Check for default buzzer denied access behaviour 1st.
            /// </summary>
            /// <returns></returns>
            private TT deniedAccess()
            {
                TT buzzer = TT.None;
                bool isDefaultBuzzer = Owner.DoorConfiguration.BuzzerInvalidCardBehaviour == BuzzerBehaviour.NoBuzzer;
                if (isDefaultBuzzer == true)
                {
                    if (Owner.DoorAgent.OperationState == DoorOperationState.Opening)
                    {
                        buzzer = TT.BuzzerOff;
                    }
                }
                else
                {
                    // Use Invalid Card Buzzer On or Pulse for Denied Access
                    buzzer = Owner.DoorConfiguration.BuzzerInvalidCardBehaviour == BuzzerBehaviour.Continuous ? TT.BuzzerOn : TT.PulseBuzzer;
                }
                return buzzer;
            }

            private TT accessWarning()
            {
                switch (Owner.DoorConfiguration.BuzzerAccessWarningBehaviour)
                {
                    case BuzzerBehaviour.NoBuzzer: return TT.BuzzerOff;
                    case BuzzerBehaviour.Continuous: return TT.BuzzerOn;
                    case BuzzerBehaviour.Pulse: return TT.PulseBuzzer;
                }
                return TT.None;
            }
        }

        public DoorAccessControlTransactionAgent(IDoorAgent doorAgent, DoorStatus doorStatus)
        {
            DoorAgent = doorAgent;
            DoorStatus = doorStatus;
            DoorConfiguration = ConfigurationManager.Instance.GetDoorConfiguration(DoorStatus.LogicalId);

            // Set Accept Led default duration
            acceptLedTime = DoorAgent.EmbarrassmentTime;
            peripheralsTimer = TimerManager.Instance.CreateTimer(peripheralsTimerProc);
            if (DoorConfiguration != null)
            {
                acceptLedTime = (int)DoorConfiguration.AcceptLedDuration.TotalMilliseconds;
                deniedLedTime = (int)DoorConfiguration.DeniedLedDuration.TotalMilliseconds;
            }
        }

        /// <summary>
        /// Door Agent instanace
        /// </summary>
        public IDoorAgent DoorAgent
        {
            get;
            private set;
        }

        public DoorStatus DoorStatus
        {
            get;
            private set;
        }

        protected DoorConfiguration DoorConfiguration
        {
            get;
            private set;
        }

        private AcceptLedConfig acceptLed = null;
        protected AcceptLedConfig AcceptLed
        {
            get
            {
                if (acceptLed == null)
                {
                    acceptLed = new AcceptLedConfig(this);
                }
                return acceptLed;
            }
        }

        private DeniedLedConfig deniedLed = null;
        protected DeniedLedConfig DeniedLed
        {
            get
            {
                if (deniedLed == null)
                {
                    deniedLed = new DeniedLedConfig(this);
                }
                return deniedLed;
            }
        }

        private BuzzerConfig buzzer = null;
        protected BuzzerConfig Buzzer
        {
            get
            {
                if (buzzer == null)
                {
                    buzzer = new BuzzerConfig(this);
                }
                return buzzer;
            }
        }

        /// <summary>
        /// Accept / Denied LED and Buzzer Timer used for: Valid / Invalid Card / Door Lock / Unlock / Access Warning (Embarrassment / Shunt / Door Forced / Door Ajar)
        /// </summary>
        protected IPacomTimer peripheralsTimer = null;

        /// <summary>
        /// Current Door Agent Context
        /// </summary>
        protected DoorAgentContexts Context = DoorAgentContexts.None;

        /// <summary>
        /// Get the transaction that will need to be sent to door peripherals for current
        /// context, door status and door state 
        /// </summary>
        /// <param name="context">Door Agent Context</param>
        /// <returns>Transaction Type</returns>
        protected TT ConfigureTransaction(DoorAgentContexts context)
        {
            TT tt = TT.None;
            switch (context)
            {
                case DoorAgentContexts.InterlockOpened:
                    tt = AcceptLed.OnOffFlashing() | DeniedLed.OnOffFlashing() | Buzzer.OffOnPulse();
                    break;
                case DoorAgentContexts.DoorContactAlarm:
                    tt = DeniedLed.OnOffFlashing() | Buzzer.OffOnPulse() | AcceptLed.OnOffFlashing();
                    break;
                case DoorAgentContexts.DoorContact:
                    if (DoorStatus.IsDoorPhysicallyOpen == true)
                    {
                        if (DoorAgent.OperationState == DoorOperationState.Unknown || DoorAgent.OperationState == DoorOperationState.Closed)
                        {
                            tt = AcceptLed.OnOffFlashing() | DeniedLed.OnOffFlashing() | Buzzer.OffOnPulse();
                        }
                        else if (DoorAgent.OperationState == DoorOperationState.Opening)
                        {
                            if (DoorAgent.DoorLockOperation == DoorLockOperation.Normal)
                                tt = TT.StrikeOff;
                        }
                        else if (DoorAgent.OperationState == DoorOperationState.Opened)
                        {
                            if (DoorAgent.DoorLockOperation != DoorLockOperation.DoorBoltMode)
                            {
                                tt = AcceptLed.OnOffFlashing() | DeniedLed.OnOffFlashing() | TT.BuzzerOff | TT.StrikeOff;
                            }
                        }
                    }
                    else
                    {
                        if (DoorStatus.IsUnlocked == true)
                        {
                            tt = AcceptLed.OnOffFlashing() | TT.BuzzerOff | TT.DeniedOff | TT.StrikeOn;
                        }
                        else if (DoorAgent.OperationState == DoorOperationState.Forced)
                        {
                            tt = AcceptLed.OnOffFlashing() | DeniedLed.OnOffFlashing() | TT.BuzzerOff | TT.StrikeOff;
                        }
                        else
                        {
                            if (DoorAgent.DoorLockOperation != DoorLockOperation.DoorBoltMode)
                            {
                                tt = AcceptLed.OnOffFlashing() | DeniedLed.OnOffFlashing() | TT.BuzzerOff | TT.StrikeOff;
                            }
                        }
                    }
                    break;

                case DoorAgentContexts.Egress:
                    if (DoorAgent.OperationState == DoorOperationState.Opening)
                        tt = TT.None;
                    else
                        tt = AcceptLed.OnOffFlashing() | Buzzer.OffOnPulse() | TT.DeniedOff | TT.StrikeOn;
                    break;

                case DoorAgentContexts.ValidCard:
                    tt = AcceptLed.OnOffFlashing() | Buzzer.OffOnPulse() | TT.DeniedOff | TT.StrikeOn;
                    break;

                case DoorAgentContexts.ValidMultiBadgingCard:
                    tt = TT.AcceptOff | TT.DeniedOff | TT.BuzzerOff;
                    break;

                case DoorAgentContexts.DeniedAccess:
                    if (DoorAgent.OperationState == DoorOperationState.Opening)
                        tt = TT.StrikeOff;
                    tt = TT.AcceptOff | DeniedLed.OnOffFlashing() | Buzzer.OffOnPulse() | tt;
                    break;

                case DoorAgentContexts.AccessCommand:
                    tt = AcceptLed.OnOffFlashing() | Buzzer.OffOnPulse();
                    if (DoorAgent.OperationState == DoorOperationState.Unknown || DoorAgent.OperationState == DoorOperationState.Closed ||
                        DoorAgent.OperationState == DoorOperationState.UnlockedPermanently || DoorAgent.OperationState == DoorOperationState.Opening)
                    {
                        if (DoorAgent.TransactionDurationType != DurationType.Permanent)
                        {
                            tt |= TT.DeniedOff | TT.StrikeOn;
                        }
                    }
                    else if (DoorAgent.OperationState == DoorOperationState.Forced || DoorAgent.OperationState == DoorOperationState.Ajar ||
                             DoorAgent.OperationState == DoorOperationState.Opened)
                    {
                        if (DoorAgent.DoorLockOperation == DoorLockOperation.DoorBoltMode)
                            tt |= TT.DeniedOff | TT.StrikeOn;
                        else
                            tt |= TT.DeniedOff | TT.StrikeOff;
                    }
                    break;

                case DoorAgentContexts.ShuntTimerExpired:
                    if (DoorAgent.OperationState == DoorOperationState.Opened)
                    {
                        tt = AcceptLed.OnOffFlashing() | DeniedLed.OnOffFlashing() | Buzzer.OffOnPulse();
                    }
                    break;

                case DoorAgentContexts.EmbarrassmentTimerExpired:
                    if (peripheralTimers == PeripheralTimers.AcceptLedInProgress)
                        StopPeripheralsTimer();
                    if (DoorAgent.OperationState == DoorOperationState.Opened)
                    {
                        tt = AcceptLed.OnOffFlashing() | DeniedLed.OnOffFlashing() | Buzzer.OffOnPulse();
                    }
                    break;

                case DoorAgentContexts.StrikeTimerExpired:
                    if (DoorStatus.IsDoorPhysicallyOpen == false)
                        StopPeripheralsTimer();
                    tt = AcceptLed.OnOffFlashing() | DeniedLed.OnOffFlashing() | Buzzer.OffOnPulse();
                    switch (DoorAgent.DoorLockOperation)
                    {
                        case DoorLockOperation.Normal:
                            if (DoorAgent.OperationState == DoorOperationState.Opening)
                            {
                                tt |= TT.StrikeOff;
                            }
                            break;
                        case DoorLockOperation.MagneticLock:
                            if (DoorAgent.OperationState == DoorOperationState.Opening ||
                                DoorAgent.OperationState == DoorOperationState.Opened)
                            {
                                tt |= TT.StrikeOff;
                            }
                            break;
                        case DoorLockOperation.DoorBoltMode:
                            if (DoorStatus.IsDoorPhysicallyOpen == false)
                            {
                                tt |= TT.StrikeOff;
                            }
                            break;
                    }
                    break;

                case DoorAgentContexts.DeniedTimerExpired:
                case DoorAgentContexts.KeypadLockoutTimerExpired:
                    if (peripheralTimers == PeripheralTimers.DeniedLedInProgress)
                        StopPeripheralsTimer();
                    tt = AcceptLed.OnOffFlashing() | DeniedLed.OnOffFlashing() | TT.BuzzerOff | TT.StrikeOff; 
                    break;

                case DoorAgentContexts.UpdateFromSchedule:
                    if (DoorStatus.IsUnlocked)
                    {
                        tt = AcceptLed.OnOffFlashing() | TT.BuzzerOff | TT.DeniedOff | TT.StrikeOn;
                    }
                    else if (DoorStatus.IsBlocked)
                    {
                        if (DoorStatus.IsDoorPhysicallyOpen == true)
                        {
                            // Door Forced
                            tt = DeniedLed.OnOffFlashing() | (DoorStatus.Isolated ? TT.BuzzerOff : Buzzer.OffOnPulse()) | AcceptLed.OnOffFlashing() | TT.StrikeOff;
                        }
                        else
                        {
                            tt = DeniedLed.OnOffFlashing() | TT.BuzzerOff | TT.AcceptOff | TT.StrikeOff;
                        }
                    }
                    else
                    {
                        if (DoorStatus.IsDoorPhysicallyOpen == true)
                        {
                            // Door Forced
                            tt = DoorStatus.Isolated ? TT.BuzzerOff : Buzzer.OffOnPulse() | AcceptLed.OnOffFlashing() | DeniedLed.OnOffFlashing() | TT.StrikeOff;
                        }
                        else
                        {
                            tt = TT.BuzzerOff | TT.AcceptOff | (DoorStatus.IsBlocked ? DeniedLed.OnOffFlashing() : TT.DeniedOff) | TT.StrikeOff;
                        }
                    }
                    break;

                case DoorAgentContexts.CurrentDoorStateRequest:
                    switch (DoorStatus.IsUnlocked)
                    {
                        case true:
                            tt = AcceptLed.OnOffFlashing() | TT.BuzzerOff | TT.DeniedOff | TT.StrikeOn;
                            break;

                        case false:
                            if (DoorAgent.OperationState == DoorOperationState.Unknown || DoorAgent.OperationState == DoorOperationState.Closed)
                            {
                                if (DoorStatus.IsDoorPhysicallyOpen == true)
                                {
                                    // Door Forced
                                    tt = DoorStatus.Isolated ? TT.BuzzerOff : Buzzer.OffOnPulse() | AcceptLed.OnOffFlashing() | DeniedLed.OnOffFlashing() | TT.StrikeOff;
                                }
                                else
                                {
                                    tt = TT.BuzzerOff | TT.AcceptOff | (DoorStatus.IsBlocked ? DeniedLed.OnOffFlashing() : TT.DeniedOff) | TT.StrikeOff;
                                }
                            }
                            else if (DoorAgent.OperationState == DoorOperationState.Forced)
                            {
                                tt = DoorStatus.Isolated ? TT.BuzzerOff : Buzzer.OffOnPulse() | AcceptLed.OnOffFlashing() | DeniedLed.OnOffFlashing();
                            }
                            else if (DoorAgent.OperationState == DoorOperationState.Opening)
                            {
                                tt = AcceptLed.OnOffFlashing() | TT.DeniedOff | TT.StrikeOn;
                            }
                            break;
                    }
                    break;

                case DoorAgentContexts.IsolateDoorChanged:
                    if (DoorStatus.Isolated == true)
                    {
                        if (DoorAgent.OperationState == DoorOperationState.Unknown || DoorAgent.OperationState == DoorOperationState.Ajar ||
                            DoorAgent.OperationState == DoorOperationState.Forced || DoorAgent.DoorAlarmTimers == DoorAlarmTimers.ShuntTimerInProgress)
                        {
                            tt = TT.BuzzerOff | TT.DeniedOff | TT.AcceptOff;
                        }
                    }
                    else
                    {
                        if (DoorAgent.OperationState == DoorOperationState.Ajar || DoorAgent.OperationState == DoorOperationState.Forced)
                        {
                            tt = Buzzer.OffOnPulse() | DeniedLed.OnOffFlashing() | AcceptLed.OnOffFlashing();
                        }
                    }
                    break;

                case DoorAgentContexts.WaitForPinOnInReader:
                case DoorAgentContexts.WaitForPinOnOutReader:
                    tt = TT.BuzzerOff | TT.AcceptFlashing | TT.DeniedOff;
                    break;

                case DoorAgentContexts.EndWaitForPinOnInReader:
                    if (DoorAgent.IsKeypadInactivityTimerOnInReaderInProgress)
                    {
                        if (DoorAgent.OperationState == DoorOperationState.Unknown || DoorAgent.OperationState == DoorOperationState.Closed ||
                            DoorAgent.OperationState == DoorOperationState.Opening)
                        {
                            if (DoorAgent.IsKeypadInactivityTimerOnOutReaderInProgress == false)
                                tt = TT.AcceptOff;
                        }
                    }
                    break;

                case DoorAgentContexts.EndWaitForPinOnOutReader:
                    if (DoorAgent.IsKeypadInactivityTimerOnOutReaderInProgress)
                    {
                        if (DoorAgent.OperationState == DoorOperationState.Unknown || DoorAgent.OperationState == DoorOperationState.Closed ||
                            DoorAgent.OperationState == DoorOperationState.Opening)
                        {
                            if (DoorAgent.IsKeypadInactivityTimerOnInReaderInProgress == false)
                                tt = TT.AcceptOff;
                        }
                    }
                    break;

                case DoorAgentContexts.KeypadInactivityInReaderTimerExpired:
                case DoorAgentContexts.KeypadInactivityOutReaderTimerExpired:
                    if (DoorAgent.OperationState == DoorOperationState.Unknown || DoorAgent.OperationState == DoorOperationState.Closed)
                    {
                        tt = TT.AcceptOff;
                    }
                    break;

                case DoorAgentContexts.AcceptLedTimerExpired:
                    tt = TT.AcceptOff | TT.BuzzerOff;
                    break;

                case DoorAgentContexts.DeniedLedTimerExpired:
                    tt = TT.DeniedOff | TT.BuzzerOff;
                    break;

                case DoorAgentContexts.None:
                    // Idle Transaction
                    tt = TT.BuzzerOff | TT.AcceptOff | (DoorStatus.IsBlocked ? TT.DeniedOn : TT.DeniedOff) | TT.StrikeOff;
                    break;
            }
            return tt;
        }

        /// <summary>
        /// Build and Run Access Control Transaction. Build the LED / Buzzer access transaction and 
        /// start / stop / restart any of the accept / denied led timers or card reader error control 
        /// timer. 
        /// </summary>
        public void CreateAndSendTransaction(DoorAgentContexts context)
        {
            CreateAndSendTransaction(context, false, false);
        }

        /// <summary>
        /// Build and Run Access Control Transaction. Build the LED / Buzzer access transaction and 
        /// start / stop / restart any of the accept / denied led timers or card reader error control 
        /// timer. 
        /// </summary>
        public void CreateAndSendTransaction(DoorAgentContexts context, bool inReaderTransactionValid, bool outReaderTransactionValid)
        {
            Context = context;
            TT type = ConfigureTransaction(context);
            DoorAgent.SendAccessControlTransactionEvent(type);
            if (type != TT.None && DoorAgent.IsInReaderAssigned)
            {
                using (var transaction = StatusManager.Instance.GetAccessControlTransaction(DoorAgent.InReaderStatus))
                {
                    if (type.Has(TT.StrikeOn)) transaction.StrikeOn();
                    if (type.Has(TT.StrikeOff)) transaction.StrikeOff();
                    if (type.Has(TT.BuzzerOn)) transaction.SetBuzzerOn();
                    if (type.Has(TT.PulseBuzzer)) transaction.SetBuzzerPulse();
                    if (type.Has(TT.BuzzerOff)) transaction.SetBuzzerOff();
                    if (type.Has(TT.DeniedOn)) transaction.SetDeniedLedOn();
                    if (type.Has(TT.DeniedFlashing)) transaction.SetDeniedLedFlashing();
                    if (type.Has(TT.DeniedOff)) transaction.SetDeniedLedOff();
                    if (type.Has(TT.AcceptOn)) transaction.SetAcceptLedOn();
                    if (type.Has(TT.AcceptFlashing)) transaction.SetAcceptLedFlashing();
                    if (type.Has(TT.AcceptOff)) transaction.SetAcceptLedOff();
                    if (inReaderTransactionValid || outReaderTransactionValid) transaction.StoreCardInDegradedMode(null);
                }
                if (DoorAgent.IsOutReaderAssigned)
                {
                    using (var transaction = StatusManager.Instance.GetAccessControlTransaction(DoorAgent.OutReaderStatus))
                    {
                        if (type.Has(TT.BuzzerOn)) transaction.SetBuzzerOn();
                        if (type.Has(TT.PulseBuzzer)) transaction.SetBuzzerPulse();
                        if (type.Has(TT.BuzzerOff)) transaction.SetBuzzerOff();
                        if (type.Has(TT.DeniedOn)) transaction.SetDeniedLedOn();
                        if (type.Has(TT.DeniedFlashing)) transaction.SetDeniedLedFlashing();
                        if (type.Has(TT.DeniedOff)) transaction.SetDeniedLedOff();
                        if (type.Has(TT.AcceptOn)) transaction.SetAcceptLedOn();
                        if (type.Has(TT.AcceptFlashing)) transaction.SetAcceptLedFlashing();
                        if (type.Has(TT.AcceptOff)) transaction.SetAcceptLedOff();
                        if (inReaderTransactionValid || outReaderTransactionValid) transaction.StoreCardInDegradedMode(null);
                    }
                }
            }
        }

        PeripheralTimers peripheralTimers = PeripheralTimers.None;

        #region Accept LED, Denied LED & Buzzer Control

        private int acceptLedTime = 0;
        protected void StopPeripheralsTimer()
        {
            peripheralTimers = PeripheralTimers.None;
            peripheralsTimer.Stop();
        }

        protected void StartPeripheralsTimer(PeripheralTimers timerType)
        {
            if (peripheralsTimer.Enabled == true)
            {
                StopPeripheralsTimer();
            }
            int timeoutValue = timerType == PeripheralTimers.AcceptLedInProgress ? acceptLedTime : deniedLedTime;
            if (timeoutValue <= 0)
                return;
            peripheralTimers = timerType;
            peripheralsTimer.RunOnce(timeoutValue);
        }

        private void peripheralsTimerProc(object state)
        {
            if (disposing || disposed)
                return;
            if (peripheralTimers == PeripheralTimers.AcceptLedInProgress)
            {
                if (DoorAgent.DoorAlarmTimers == DoorAlarmTimers.EmbarrassmentTimerInProgress)
                {
                    CreateAndSendTransaction(DoorAgentContexts.AcceptLedTimerExpired);
                }
            }
            else if (peripheralTimers == PeripheralTimers.DeniedLedInProgress)
            {
                if (DoorAgent.PeripheralTimers == DoorPeripheralTimers.AccessDeniedInProgress)
                {
                    CreateAndSendTransaction(DoorAgentContexts.DeniedLedTimerExpired);
                }
            }
            peripheralTimers = PeripheralTimers.None;
        }

        private int deniedLedTime = DoorAgentBase.DefaultAccessDeniedTimeout;
        public int DeniedLedTime
        {
            get { return deniedLedTime; }
        }

        #endregion

        #region IDisposable Members

        bool disposed = false;

        bool disposing = false;

        protected void Dispose(bool disposing)
        {
            try
            {
                if (disposed == false)
                {
                    if (disposing)
                    {
                        this.disposing = true;

                        if (peripheralsTimer != null)
                        {
                            TimerManager.Instance.RemoveTimer(peripheralsTimer);
                            peripheralsTimer = null;
                        }
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                        {
                            return string.Format("Door agent access control transaction holder for DoorId={0} - Successfully Destroyed.", DoorStatus.LogicalId);
                        });

                        DoorStatus = null;
                        DoorAgent = null;
                    }
                    disposed = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while disposing door agent access control transaction holder. {0}", ex.ToString());
                });
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
