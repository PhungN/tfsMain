﻿using System;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    public sealed class InterlockGroupStatus : StatusBase<InterlockGroupStatusList>
    {
        /// <summary>
        /// Is this interlock group bypassed (i.e. disabled)
        /// </summary>
        public bool Bypassed { get; private set; }

        /// <summary>
        /// Is this interlock open?
        /// </summary>
        public bool IsOpen { get; set; }

        public void SetBypassedFromExpression(bool bypass, int seconds)
        {
            if (Enabled == false)
            {
                return;
            }

            SetBypassed(bypass, ConfigurationManager.MacroUser, seconds);
        }

        public void SetBypassedFromFrontEnd(bool bypass, int seconds)
        {
            if (Enabled == false)
            {
                return;
            }

            SetBypassed(bypass, ConfigurationManager.FrontEndUser, seconds);
        }

        public void SetBypassed(bool bypassed, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            InterlockGroupConfiguration interlockGroupConfiguration = ConfigurationManager.Instance.GetInterlockGroupConfiguration(this.LogicalId);

            if (interlockGroupConfiguration != null && interlockGroupConfiguration.Enabled == true)
            {
                StatusManager.Instance.RemoveTimedAction(StatusManagerTimedActions.RestoreInterlockGroup, this.LogicalId);

                if (Bypassed != bypassed)
                {
                    Bypassed = bypassed;
                    StatusManager.Instance.InterlockGroups.TriggerInterlockBypassedEvent(this.LogicalId, Bypassed, userAuditInfo);
                }
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () => string.Format("InterlockGroupStatus[{0}].Bypassed = {1}", this.LogicalId, Bypassed));

                if (Bypassed && durationInSeconds > 0)
                {
                    // A duration is only supported for the 'bypass for a duration' case.
                    StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.RestoreInterlockGroup, this.LogicalId, userAuditInfo, durationInSeconds);
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () => string.Format("  created timed action to restore after {0} seconds", durationInSeconds));
                }
                StatusManager.Instance.RequestStatusToStorage();
            }
        }

        public InterlockGroupStatus(ConfigurationBase configuration, InterlockGroupStatusList parent, InterlockGroupStatusStorage previousStatus) :
            base(configuration, parent)
        {
            Bypassed = false;
            if (previousStatus == null || this.Enabled == false)
                return;

            Bypassed = previousStatus.Bypassed;
        }

        public override StatusItemType ItemType
        {
            get { return StatusItemType.InterlockGroupStatus; }
        }

        public override void Isolate(UserAuditInfo userAuditInfo)
        {
        }

        public override void Deisolate(UserAuditInfo userAuditInfo)
        {
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            InterlockGroupStatusStorage statusStorage = new InterlockGroupStatusStorage
                                                        {
                                                            LogicalId = LogicalId,
                                                            ParentDeviceId = ParentDeviceId,
                                                            Bypassed = Bypassed
                                                        };
            return statusStorage;
        }
        
        public override string ToString()
        {
            return String.Format("Interlock Group [{0}]", this.LogicalId);
        }
    }
}
