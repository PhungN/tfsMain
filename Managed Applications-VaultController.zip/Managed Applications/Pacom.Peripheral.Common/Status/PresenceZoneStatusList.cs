﻿using System;
using System.IO;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Configuration.ConfigurationCommon;
using System.Collections.Generic;
using Pacom.Peripheral.Common.SQLCE;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Collection of all presence zone statuses with utility functions
    /// </summary>
    public class PresenceZoneStatusList : StatusListBase<PresenceZoneStatus, PresenceZoneStatusList>
    {
        /// <summary>
        /// Update presence zone status list from configuration. Add new presence zone status instances if not already existing
        /// </summary>
        /// <param name="presenceZones">List of presence zones to add</param>
        /// <param name="statusStorage">Status storage instance</param>
        /// <param name="controllerRestarted">True if controller restarted</param>
        internal void UpdateFromConfiguration(PresenceZoneConfiguration[] presenceZones, StatusStorageCollection statusStorage)
        {
            if (SqlCeDatabase.Instance.DefaultDatabaseIsValid == true)
            {
                PresenceZoneSqlManager.CreateInstance();

                // Delete any file based persistence
                string[] files = Directory.GetFiles(FileSystemPaths.ConfigurationDirectory, string.Format(FileSystemPaths.PresenceZoneStatusFilePath, "*").Replace(FileSystemPaths.ConfigurationDirectory, ""));
                if (files.Length > 0)
                {
                    PresenceZoneSqlManager.Instance.RemoveAll();
                    foreach (string file in files)
                    {
                        File.Delete(file);
                    }
                }
            }

            foreach (var presenceZone in presenceZones)
            {
                Assign(presenceZone.Id, new PresenceZoneStatus(presenceZone, this));
            }
        }

        /// <summary>
        /// Update PresenceZone status list from configuration on configuration change.
        /// </summary>
        internal void UpdateFromConfiguration(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems)
        {
            foreach (var removedItem in removedItems)
            {
                if (removedItem.ConfigurationType == ConfigurationElementType.PresenceZone)
                {
                    Remove(removedItem.Id);
                    if (SqlCeDatabase.Instance.DefaultDatabaseIsValid == true)
                        PresenceZoneSqlManager.Instance.RemovePresenceZone(removedItem.Id);
                    else if (File.Exists(string.Format(FileSystemPaths.PresenceZoneStatusFilePath, removedItem.Id.ToString())))
                        File.Delete(string.Format(FileSystemPaths.PresenceZoneStatusFilePath, removedItem.Id.ToString()));
                }
            }
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.PresenceZone)
                {
                    Remove(changedItem.Id);
                    try
                    {
                        Assign(changedItem.Id, new PresenceZoneStatus(ConfigurationManager.Instance.GetPresenceZoneConfiguration(changedItem.Id), this));
                    }
                    catch
                    {
                    }
                }
            }
            foreach (var newlyAddedItem in newlyAddedItems)
            {
                try
                {
                    if (newlyAddedItem.ConfigurationType == ConfigurationElementType.PresenceZone)
                        Assign(newlyAddedItem.Id, new PresenceZoneStatus(ConfigurationManager.Instance.GetPresenceZoneConfiguration(newlyAddedItem.Id), this));
                }
                catch
                {
                }
            }
        }

        internal override void Persist(Asn1DerFormatter asn1Serializer, Stream statusStream)
        {
        }

        internal override void Cleanup()
        {
            foreach (var item in Items)
            {
                item.Cleanup();
            }

            base.Cleanup();
        }
    }
}
