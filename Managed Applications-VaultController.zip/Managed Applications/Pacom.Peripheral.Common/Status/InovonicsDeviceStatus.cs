﻿using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Events.EventsCommon.Status;

namespace Pacom.Peripheral.Common.Status
{
    public abstract class InovonicsTransceiverOrRepeaterStatusBase : DeviceStatusAbstractBase, IInovonicsDeviceStatus, IDeviceStatus
    {
        private const string DefaultInovonicsSerialNumber = "00000001";

        private bool internalBatteryLow = false;
        private bool maskedInternalBatteryLow = false;
        private InovonicsDeviceType deviceType = InovonicsDeviceType.Undefined;

        /// <summary>
        /// Signal Level in dB, 0-99
        /// </summary>
        protected int signalLevel = 0;

        /// <summary>
        /// Signal Margin in dB, 0-99
        /// </summary>
        protected int signalMargin = 0;

        public InovonicsTransceiverOrRepeaterStatusBase(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus)
            : base(configuration, parent)
        {
            InovonicsDeviceConfigurationBase config = configuration as InovonicsDeviceConfigurationBase;
            if (config != null)
                deviceType = config.DeviceType;

            SupportedIsolateFlags |= EventSourceLatchOrIsolateType.InternalBatteryFail;

            InovonicsReceiverStatusStorage inovonicsPreviousStatus = previousStatus as InovonicsReceiverStatusStorage;
            if (inovonicsPreviousStatus == null || Enabled == false)
                return;

            if (DeviceType == inovonicsPreviousStatus.DeviceType)
            {
                isolatedAlarms = inovonicsPreviousStatus.IsolatedAlarms;
                latchedAlarms = inovonicsPreviousStatus.LatchedAlarms;
                tamperActive = inovonicsPreviousStatus.TamperActive;
                maskedTamperActive = inovonicsPreviousStatus.MaskedTamperActive;
                internalBatteryLow = inovonicsPreviousStatus.InternalBatteryLow;
                maskedInternalBatteryLow = inovonicsPreviousStatus.MaskedInternalBatteryLow;
                signalLevel = inovonicsPreviousStatus.SignalLevel;
                signalMargin = inovonicsPreviousStatus.SignalMargin;
                base.VerifyMaskedAlarms();
            }
        }

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            if (base.LatchAfterFirstAlarm(suspectStatusType) == true)
                return true;
            if (suspectStatusType == EventSourceLatchOrIsolateType.InternalBatteryFail)
                return ConfigurationManager.Instance.ControllerConfiguration.LatchInternalBatteryLowAlarms;
            return false;
        }

        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get { return base.IsCurrentlyLatched || latchedAlarms.HasAny(EventSourceLatchOrIsolateType.InternalBatteryFail); }
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = base.CurrentAlarms;
                if (MaskedInternalBatteryLow == true)
                    flags |= EventSourceLatchOrIsolateType.InternalBatteryFail;
                return flags;
            }
        }

        public override string SerialNumber
        {
            get { return DefaultInovonicsSerialNumber; }
            set
            {
            }
        }

        public InovonicsDeviceType DeviceType
        {
            get { return deviceType; }
        }

        /// <summary>
        /// Get / Set unmasked device online status
        /// </summary>
        public override bool Online
        {
            get
            {
                return base.Online;
            }
            set
            {
                bool previousOnline = online;
                base.Online = value;
                // Check if Online Status has changed
                if (previousOnline != online && online == false && DeviceType.IsRepeater() == false)
                {
                    notifyDeviceInputsSelfTestFail();
                }
                if (online == true && previousOnline == online)
                {
                    // Try to remove Inovonics device from delayed Offline list. This is required because the Inovonics device will not
                    // go Offline when the configuration is changed like the Pacom device loop devices
                    Parent.RemoveInovonicsDeviceFromDelayedOfflineList(LogicalId);
                }
            }
        }

        /// <summary>
        /// Change all device inputs to Self Test Fail if the device is Offline
        /// </summary>
        private void notifyDeviceInputsSelfTestFail()
        {
            // Change all inputs for an offline end-device to Self Test Fail / Fault (see EN 50131-1 claus 8.8.4.1(b) and Table 20)
            IInputDeviceConfigurationBase ioDevice = ConfigurationManager.Instance.GetDeviceConfiguration(LogicalId) as IInputDeviceConfigurationBase;
            if (ioDevice != null)
            {
                foreach (var input in ioDevice.Inputs)
                {
                    if (input == null)
                        continue;
                    InputStatus inputStatus = StatusManager.Instance.Inputs[input.Id];
                    if (inputStatus != null)
                    {
                        inputStatus.UnmaskedStatus = Common.InputStatus.SelfTestFail;
                    }
                }
            }
        }

        /// <summary>
        /// It is time to notify the alarm manager about the device being in offline state for too long
        /// </summary>
        public override void NotifyDeviceOffline()
        {
            if (online == false)
            {
                // Force device online ptoperty to TRUE first so we can trigger a device Offline event.                
                online = true;
                if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false &&
                    LatchedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false)
                {
                    maskedOnline = true;
                }
                // Make the offline alarm go out.
                base.Online = false;
                notifyDeviceInputsSelfTestFail();
            }
        }

        /// <summary>
        /// Get / Set unmasked internal lithium battery status.
        /// </summary>
        public bool InternalBatteryLow
        {
            get { return internalBatteryLow; }
            set
            {
                if (Enabled == false)
                    return;
                if (internalBatteryLow != value)
                {
                    internalBatteryLow = value;
                    MaskedInternalBatteryLow = internalBatteryLow;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set masked internal lithium battery status, send status changed event to front-end if required.
        /// </summary>
        public bool MaskedInternalBatteryLow
        {
            get { return maskedInternalBatteryLow; }
            set
            {
                if (Enabled == false)
                    return;
                if (maskedInternalBatteryLow != value || value == true)
                {
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail) == false &&
                        SuspectPoint == false && (LatchedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail) == false || value == true))
                    {
                        maskedInternalBatteryLow = value;
                        if (maskedInternalBatteryLow == true)
                        {
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.InternalBatteryFail);
                            CheckTerminateArming();
                        }
                        else
                        {
                            CheckStopFailToArmTimer();
                        }
                        Parent.TriggerInternalBatteryLowChangedStatus(this);
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        /// <summary>
        /// Device Signal Level - the value indicate the signal’s relative strength, ranging from 0-99.
        /// The higher the value, the stronger the signal strength. 
        /// Calculation is based on the algorithm described in "Commercial Mesh Network Developer Guide.pdf" 
        /// document, chapter 2.4.
        /// </summary>
        public int SignalLevel
        {
            get { return signalLevel; }
            set
            {
                if (Enabled == false)
                    return;
                if (signalLevel != value)
                {
                    if (value > signalLevel)
                    {
                        signalLevel = value;
                    }
                    else if (signalLevel > 0)
                    {
                        signalLevel--;
                    }
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Device Signal Margin - The signal margin is the measurement of the decibel level of the message,
        /// minus the decibel level of any interfering signals, ranges from 0-99. The higher the value, the
        /// better the signal quality.
        /// Calculation is based on the algorithm described in "Commercial Mesh Network Developer Guide.pdf" 
        /// document, chapter 2.4.
        /// </summary>
        public int SignalMargin
        {
            get { return signalMargin; }
            set
            {
                if (Enabled == false)
                    return;
                if (signalMargin != value)
                {
                    if (value > signalMargin)
                    {
                        signalMargin = value;
                    }
                    else if (signalMargin > 0)
                    {
                        signalMargin--;
                    }
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Set the state of device IsolatedAlarms flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="value">New isolated options. If value = EventSourceLatchOrIsolateType.None -> Deisolate all.
        /// If value = EventSourceLatchOrIsolateType.InternalBatteryFail -> Isolate all or any.
        /// When de-isolating if any of the device inputs is in alarm the alarm will be queued into AlarmManager.
        /// </param>
        /// <returns>True if the command was successfully executed</returns>
        public override bool SetIsolated(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType value)
        {
            if (base.SetIsolated(userAuditInfo, value) == false)
                return false;

            // Mask-out all flags this device does not support
            value &= SupportedIsolateFlags;
            if (value != isolatedAlarms)
            {
                // Internal Battery Low - Isolate/de-isolate 
                SetIsolated(value, EventSourceLatchOrIsolateType.InternalBatteryFail, false, internalBatteryLow);
                StatusManager.Instance.RequestStatusToStorage();
            }
            return true;
        }

        /// <summary>
        /// Set masked status for [optionToCheck] to [newValue]
        /// </summary>
        /// <param name="optionToCheck">Option to check, e.g.: Offline, Tamper, InternalBatteryFail, etc.</param>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(EventSourceLatchOrIsolateType optionToCheck, bool newValue)
        {
            if (base.SetMaskedStatus(optionToCheck, newValue))
                return true;
            if (optionToCheck == EventSourceLatchOrIsolateType.InternalBatteryFail)
            {
                MaskedInternalBatteryLow = newValue;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Restore masked online, device tamper, etc. status if required after unlatching the device alarms. Restore only if the
        /// current instantaneous status is Secure (device online, tamper secure, etc.).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        protected override void RestoreAfterUnlatch(UserAuditInfo userAuditInfo)
        {
            base.RestoreAfterUnlatch(userAuditInfo);
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail) == false && InternalBatteryLow == false)
                MaskedInternalBatteryLow = InternalBatteryLow;
        }

        /// <summary>
        /// Initialize the state of status storage instance for all the basic properties
        /// </summary>
        /// <param name="statusStorage">Status Storage instance to initialize</param>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        protected void InitializeStatusStorage(InovonicsDeviceStatusStorage statusStorage, bool controllerRestarting)
        {
            base.InitializeStatusStorage(statusStorage);
            statusStorage.HardwareType = HardwareType;
            statusStorage.DeviceType = deviceType;
            statusStorage.InternalBatteryLow = internalBatteryLow;
            statusStorage.MaskedInternalBatteryLow = maskedInternalBatteryLow;
            statusStorage.SignalLevel = signalLevel;
            statusStorage.SignalMargin = signalMargin;
        }

        /// <summary>
        /// Initialize device information instance from status / configuration information
        /// </summary>
        /// <param name="deviceInformation">Device Information instance</param>
        protected override void InitializeDeviceInformation(DeviceInformation deviceInformation)
        {
            base.InitializeDeviceInformation(deviceInformation);
            deviceInformation.DeviceType = deviceType;
        }

        /// <summary>
        /// Check masked alarms when we restore status from previous stored state
        /// </summary>
        protected override void VerifyMaskedAlarms()
        {
            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail))
            {
                maskedInternalBatteryLow = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.InternalBatteryFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.InternalBatteryFail))
            {
                maskedInternalBatteryLow = true;
            }
        }
    }
}
