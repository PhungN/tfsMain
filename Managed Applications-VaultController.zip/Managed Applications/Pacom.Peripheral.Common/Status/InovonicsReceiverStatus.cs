﻿using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Events.EventsCommon;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    public class InovonicsReceiverStatus : DeviceStatusAbstractBase, IInovonicsDeviceStatus
    {
        private const string DefaultInovonicsSerialNumber = "00000001";

        /// <summary>
        /// Serial Receiver Receiver Jammed status
        /// </summary>
        private bool receiverJammed = false;
        private bool maskedReceiverJammed = false;

        private const EventSourceLatchOrIsolateType flags = EventSourceLatchOrIsolateType.SignalFail;

        public InovonicsReceiverStatus(ConfigurationBase configuration, DeviceStatusList parent, DeviceStatusStorageBase previousStatus)
            : base(configuration, parent)
        {
            SupportedIsolateFlags |= flags;

            InovonicsReceiverStatusStorage inovonicsPreviousStatus = previousStatus as InovonicsReceiverStatusStorage;
            if (inovonicsPreviousStatus == null || this.Enabled == false)
                return;

            if (HardwareType == inovonicsPreviousStatus.HardwareType)
            {
                isolatedAlarms = inovonicsPreviousStatus.IsolatedAlarms;
                latchedAlarms = inovonicsPreviousStatus.LatchedAlarms;
                tamperActive = inovonicsPreviousStatus.TamperActive;
                maskedTamperActive = inovonicsPreviousStatus.MaskedTamperActive;

                receiverJammed = inovonicsPreviousStatus.ReceiverJammed;
                maskedReceiverJammed = inovonicsPreviousStatus.MaskedReceiverJammed;
                VerifyMaskedAlarms();
            }
        }

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            if (base.LatchAfterFirstAlarm(suspectStatusType) == true)
                return true;
            if (suspectStatusType == EventSourceLatchOrIsolateType.SignalFail)
                return ConfigurationManager.Instance.ControllerConfiguration.LatchSignalFailAlarms;
            return false;
        }

        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get { return base.IsCurrentlyLatched || latchedAlarms.HasAny(flags); }
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = base.CurrentAlarms;
                if (maskedReceiverJammed == true)
                    flags |= EventSourceLatchOrIsolateType.SignalFail;
                return flags;
            }
        }

        public override string SerialNumber
        {
            get { return DefaultInovonicsSerialNumber; }
            set
            {
            }
        }

        public InovonicsDeviceType DeviceType
        {
            get { return InovonicsDeviceType.ES4000; }
        }

        /// <summary>
        /// Get / Set unmasked receiver jammed status.
        /// </summary>
        public bool ReceiverJammed
        {
            get { return receiverJammed; }
            set
            {
                if (Enabled == false)
                    return;
                if (receiverJammed != value)
                {
                    receiverJammed = value;
                    MaskedReceiverJammed = receiverJammed;
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        /// <summary>
        /// Get / Set masked receiver jammed status, send status changed event to front-end if required.
        /// </summary>
        public bool MaskedReceiverJammed
        {
            get { return maskedReceiverJammed; }
            set
            {
                if (Enabled == false)
                    return;
                if (maskedReceiverJammed != value || value == true)
                {
                    if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail) == false &&
                        SuspectPoint == false &&
                        (LatchedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail) == false || value == true))
                    {
                        maskedReceiverJammed = value;
                        if (maskedReceiverJammed == true)
                        {
                            IncrementSuspectCount(EventSourceLatchOrIsolateType.SignalFail);
                            CheckTerminateArming();
                        }
                        else
                        {
                            CheckStopFailToArmTimer();
                        }
                        Parent.TriggerReceiverJammedChangedStatus(this, maskedReceiverJammed);
                        StatusManager.Instance.RequestStatusToStorage();
                    }
                }
            }
        }

        /// <summary>
        /// Get / Set unmasked device online status
        /// </summary>
        public override bool Online
        {
            get
            {
                return base.Online;
            }
            set
            {
                bool previousOnline = online;
                base.Online = value;
                // Check if Online Status has changed
                if (online == true && previousOnline == online)
                {
                    // Try to remove Inovonics device from delayed Offline list. This is required because the Inovonics device will not
                    // go Offline when the configuration is changed like the Pacom device loop devices
                    Parent.RemoveInovonicsDeviceFromDelayedOfflineList(LogicalId);
                }
            }
        }

        public override void NotifyDeviceOffline()
        {
            if (online == false)
            {
                // Force device online ptoperty to TRUE first so we can trigger a device Offline event.                
                online = true;
                if (IsolatedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false &&
                    LatchedAlarms.Has(EventSourceLatchOrIsolateType.Offline) == false)
                {
                    maskedOnline = true;
                }
                // Make the offline alarm go out.
                base.Online = false;
            }
        }

        /// <summary>
        /// Set the state of device IsolatedAlarms flag
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="value">New isolated options. If value = EventSourceLatchOrIsolateType.None -> Deisolate all.
        /// If value = EventSourceLatchOrIsolateType.Offline | EventSourceLatchOrIsolateType.Tamper -> Isolate all or any.
        /// When de-isolating if any of the device inputs is in alarm the alarm will be queued into AlarmManager.
        /// </param>
        /// <returns>True if the command was successfully executed</returns>
        public override bool SetIsolated(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType value)
        {
            if (base.SetIsolated(userAuditInfo, value) == false)
                return false;

            // Mask-out all flags this device does not support
            value &= SupportedIsolateFlags;
            if (value != isolatedAlarms)
            {
                // Receiver Jammed - Isolate/de-isolate 
                SetIsolated(value, EventSourceLatchOrIsolateType.SignalFail, false, receiverJammed);
                StatusManager.Instance.RequestStatusToStorage();
            }
            return true;
        }

        /// <summary>
        /// Set masked status for [optionToCheck] to [newValue]
        /// </summary>
        /// <param name="optionToCheck">Option to check, e.g.: Offline, Tamper, InternalBatteryFail, etc.</param>
        /// <param name="newValue">New masked status value.</param>
        protected override bool SetMaskedStatus(EventSourceLatchOrIsolateType optionToCheck, bool newValue)
        {
            if (base.SetMaskedStatus(optionToCheck, newValue))
                return true;
            if (optionToCheck == EventSourceLatchOrIsolateType.SignalFail)
                MaskedReceiverJammed = newValue;
            return true;
        }

        /// <summary>
        /// Restore masked online, device tamper, etc. status if required after unlatching the device alarms. Restore only if the
        /// current instantaneous status is Secure (device online, tamper secure, etc.).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        protected override void RestoreAfterUnlatch(UserAuditInfo userAuditInfo)
        {
            base.RestoreAfterUnlatch(userAuditInfo);
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail) == false && ReceiverJammed == false)
                MaskedReceiverJammed = ReceiverJammed;
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            InovonicsReceiverStatusStorage statusStorage = new InovonicsReceiverStatusStorage();
            if (statusStorage != null)
            {
                InitializeStatusStorage(statusStorage);
                statusStorage.HardwareType = HardwareType;
                statusStorage.ReceiverJammed = ReceiverJammed;
                statusStorage.MaskedReceiverJammed = MaskedReceiverJammed;
            }
            return statusStorage;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            DeviceInovonicsSerialReceiverEventState deviceState = new DeviceInovonicsSerialReceiverEventState();
            InitializeEventState(deviceState);
            deviceState.ReceiverJammed = MaskedReceiverJammed;
            return deviceState;
        }

        /// <summary>
        /// Check masked alarms when we restore status from previous stored state
        /// </summary>
        protected override void VerifyMaskedAlarms()
        {
            base.VerifyMaskedAlarms();
            if (isolatedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail))
            {
                maskedReceiverJammed = false;
                latchedAlarms = latchedAlarms.ClearFlag(EventSourceLatchOrIsolateType.SignalFail);
            }
            else if (latchedAlarms.Has(EventSourceLatchOrIsolateType.SignalFail))
            {
                maskedReceiverJammed = true;
            }
        }
    }
}
