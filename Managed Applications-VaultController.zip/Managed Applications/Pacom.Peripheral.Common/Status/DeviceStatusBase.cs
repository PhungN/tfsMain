﻿using Pacom.Core.Contracts;
using Pacom.Core.Contracts.Status;
using Pacom.Events.EventsCommon.Status;
using Pacom.Events.EventsCommon.Status.Device;
using Pacom.Events.EventsCommon;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    public abstract class DeviceStatusBase : DeviceStatusAbstractBase
    {
        protected string serialNumber = DefaultSerialNumber;
        protected string bootloaderVersion = DefaultBootloaderVersion;
        protected string firmwareVersion = DefaultFirmwareVersion;

        public DeviceStatusBase(ConfigurationBase configuration, DeviceStatusList parent)
            : base(configuration, parent)
        {
        }

        /// <summary>
        /// Update the isolatedOptions flag for one isolate option only: e.g.: Offline, Tamper, etc.
        /// </summary>
        /// <param name="newIsolateOptions">New isolated options</param>
        /// <param name="optionToCheck">One option to isolate.</param>
        /// <param name="secureValue">Option secure value: Offline = true, Tamper = false, etc.</param>
        /// <param name="unmaskedValue">Unmasked option value</param>
        protected void SetIsolated(EventSourceLatchOrIsolateType newIsolateOptions, EventSourceLatchOrIsolateType optionToCheck, PowerFailState unmaskedValue)
        {
            if (isolatedAlarms.BitChanged(newIsolateOptions, optionToCheck) == true)
            {
                isolatedAlarms = isolatedAlarms.ClearFlag(optionToCheck);
                bool isolated = isolatedAlarms.BitSetAfter(newIsolateOptions, optionToCheck);
                if (isolated == true)
                {
                    // Isolate option to check (e.g.: Offline / Tamper / etc.)
                    ResetSuspectCount();
                    latchedAlarms = latchedAlarms.ClearFlag(optionToCheck);
                    SetMaskedStatus(PowerFailState.None);
                    isolatedAlarms = isolatedAlarms.SetFlag(optionToCheck);
                }
                else
                {
                    // Deisolate option to check
                    SetMaskedStatus(unmaskedValue);
                }
            }
        }

        /// <summary>
        /// Update the isolatedOptions flag for one isolate option only: e.g.: Offline, Tamper, etc.
        /// </summary>
        /// <param name="newIsolateOptions">New isolated options</param>
        /// <param name="optionToCheck">One option to isolate.</param>
        /// <param name="secureValue">Option secure value: Offline = true, Tamper = false, etc.</param>
        /// <param name="unmaskedValue">Unmasked option value</param>
        protected void SetIsolated(EventSourceLatchOrIsolateType newIsolateOptions, EventSourceLatchOrIsolateType optionToCheck, BatteryFailState unmaskedValue)
        {
            if (isolatedAlarms.BitChanged(newIsolateOptions, optionToCheck) == true)
            {
                isolatedAlarms = isolatedAlarms.ClearFlag(optionToCheck);
                bool isolated = isolatedAlarms.BitSetAfter(newIsolateOptions, optionToCheck);
                if (isolated == true)
                {
                    // Isolate option to check (e.g.: Offline / Tamper / etc.)
                    ResetSuspectCount();
                    latchedAlarms = latchedAlarms.ClearFlag(optionToCheck);
                    SetMaskedStatus(BatteryFailState.None);
                    isolatedAlarms = isolatedAlarms.SetFlag(optionToCheck);
                }
                else
                {
                    // Deisolate option to check
                    SetMaskedStatus(unmaskedValue);
                }
            }
        }

        /// <summary>
        /// Set masked status for PowerFailState
        /// </summary>
        /// <param name="newValue">New masked status value.</param>
        protected virtual bool SetMaskedStatus(PowerFailState newValue)
        {
            return false;
        }

        /// <summary>
        /// Set masked status for BatteryFailState
        /// </summary>
        /// <param name="newValue">New masked status value.</param>
        protected virtual bool SetMaskedStatus(BatteryFailState newValue)
        {
            return false;
        }

        /// <summary>
        /// True if we need to latch after the 1st alarm was generated.
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type to check</param>
        /// <returns></returns>
        protected override bool LatchAfterFirstAlarm(EventSourceLatchOrIsolateType suspectStatusType)
        {
            switch (suspectStatusType)
            {
                case EventSourceLatchOrIsolateType.Offline: return ConfigurationManager.Instance.ControllerConfiguration.LatchOfflineAlarms;
                case EventSourceLatchOrIsolateType.Tamper: return ConfigurationManager.Instance.ControllerConfiguration.LatchTamperAlarms;
                case EventSourceLatchOrIsolateType.DeviceSubstitution: return true;
                default: return false;
            }
        }

        /// <summary>
        /// Indicates that the device status instance is in latched state when this value is true.
        /// The device status has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        public override bool IsCurrentlyLatched
        {
            get { return latchedAlarms.HasAny(DefaultLatchFlags | EventSourceLatchOrIsolateType.DeviceSubstitution); }
        }

        /// <summary>
        /// Returns the current latch status for this status item instance and the [latchFlagToCheck]
        /// </summary>
        /// <param name="latchFlagToCheck">The status item alarm flag that needs to be checked for latching</param>
        /// <returns>The latch status for this status item.</returns>
        public override EventSourceLatchStatus GetLatchStatusFor(EventSourceLatchOrIsolateType latchFlagToCheck)
        {
            EventSourceLatchStatus latchStatus = base.GetLatchStatusFor(latchFlagToCheck);
            if (latchStatus != EventSourceLatchStatus.NotLatched)
                return latchStatus;

            return latchFlagToCheck == EventSourceLatchOrIsolateType.DeviceSubstitution ? EventSourceLatchStatus.ConfiguredToBeLatched :
                                                                                          latchStatus;
        }

        /// <summary>
        /// Get all device alarms
        /// </summary>
        public override EventSourceLatchOrIsolateType CurrentAlarms
        {
            get
            {
                EventSourceLatchOrIsolateType flags = base.CurrentAlarms;
                if (deviceSubstitution == true)
                    flags |= EventSourceLatchOrIsolateType.DeviceSubstitution;
                return flags;
            }
        }

        /// <summary>
        /// Get / Set the device current firmware version
        /// </summary>
        public string FirmwareVersion
        {
            get { return firmwareVersion; }
            set
            {
                if (Enabled == false)
                    return;
                if (firmwareVersion.Equals(value) == false)
                    firmwareVersion = value.ReplaceAnyNonASCIICharacters();
            }
        }

        /// <summary>
        /// Get / Set the device bootloader version
        /// </summary>
        public string BootloaderVersion
        {
            get { return bootloaderVersion; }
            set
            {
                if (Enabled == false)
                    return;
                if (bootloaderVersion.Equals(value) == false)
                    bootloaderVersion = value;
            }
        }

        /// <summary>
        /// Get / Set the device serial number
        /// </summary>
        public override string SerialNumber
        {
            get { return serialNumber; }
            set
            {
                if (Enabled == false)
                    return;
                if (serialNumber.Equals(value) == false)
                {
                    if (string.Compare(serialNumber, DefaultSerialNumber, true) != 0)
                    {
                        // The previous serial number is not default one it must be a substituted device
                        TriggerSubstitution();
                    }
                    serialNumber = value.ReplaceAnyNonASCIICharacters();
                    StatusManager.Instance.RequestStatusToStorage();
                }
            }
        }

        private bool deviceSubstitution = false;
        protected bool DeviceSubstitution
        {
            get { return deviceSubstitution; }
            set { deviceSubstitution = value; }
        }

        public void TriggerSubstitution()
        {
            if (SuspectPoint == false)
            {
                // Latch Device Substitution Alarm
                IncrementSuspectCount(EventSourceLatchOrIsolateType.DeviceSubstitution);
                deviceSubstitution = true;
                Parent.TriggerDeviceSubstitution(this, false);
            }
        }

        /// <summary>
        /// Restore device substitution alarm
        /// </summary>
        public void DeviceSubstitutionRestore()
        {
            deviceSubstitution = false;
            // The previous serial number is not default one it must be a substituted device
            Parent.TriggerDeviceSubstitution(this, true);
        }

        /// <summary>
        /// Restore masked online, device tamper, etc. status if required after unlatching the device alarms. Restore only if the
        /// current instantaneous status is Secure (device online, tamper secure, etc.).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        protected override void RestoreAfterUnlatch(UserAuditInfo userAuditInfo)
        {
            base.RestoreAfterUnlatch(userAuditInfo);
            if (latchedAlarms.Has(EventSourceLatchOrIsolateType.DeviceSubstitution) == false && deviceSubstitution == true)
                DeviceSubstitutionRestore();
        }

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        public override bool CanIsolate(UserAccessLevel level)
        {
            if (CurrentAlarms == EventSourceLatchOrIsolateType.DeviceSubstitution)
                return false;

            return level == UserAccessLevel.AccessLevel3;
        }

        /// <summary>
        /// Create Status Storage instance for this class
        /// </summary>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        /// <returns></returns>
        public override StatusStorageConfigurationBase CreateStatusStorage()
        {
            DeviceStatusStorage statusStorage = new DeviceStatusStorage();
            if (statusStorage != null)
            {
                InitializeStatusStorage(statusStorage);
            }
            return statusStorage;
        }

        /// <summary>
        /// Create Item Status Event State instance for this class
        /// </summary>
        /// <returns></returns>
        public override NodeStateBase CreateEventState()
        {
            DeviceEventState deviceState = null;
            switch (HardwareType)
            {
                case HardwareType.Pacom1068InputOutput:
                    deviceState = new Device1068EventState();
                    break;
                case HardwareType.Pacom1064InputOutput:
                    deviceState = new Device1064IOEventState();
                    break;
                case HardwareType.Pacom1064DoorController:
                    deviceState = new Device1064DCEventState();
                    break;
                case HardwareType.Pacom1076InputOutput:
                    deviceState = new Device1076IOEventState();
                    break;
            }
            if (deviceState != null)
            {
                InitializeEventState(deviceState);
            }
            return deviceState;
        }

        /// <summary>
        /// Initialize the state of status storage instance for all the basic properties
        /// </summary>
        /// <param name="statusStorage">Status Storage instance to initialize</param>
        /// <param name="controllerRestarting">True if controller is restarting, False otherwise</param>
        protected override void InitializeEventState(DeviceEventState deviceState)
        {
            base.InitializeEventState(deviceState);
            deviceState.Substitution = CurrentAlarms.Has(EventSourceLatchOrIsolateType.DeviceSubstitution);
        }
    }
}
