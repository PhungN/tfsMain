﻿using System;
using System.IO;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.AccessControl;
using Pacom.Serialization.Formatters.Asn1;
using System.Collections.Generic;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Core.Contracts.Status;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Collection of all door statuses with utility functions
    /// </summary>
    public class DoorStatusList : StatusListBase<DoorStatus, DoorStatusList>
    {
        /// <summary>
        /// Triggered when the status of any of the door inputs on any of the door controller devices
        /// or on the controller itself changes.
        /// </summary>
        public event EventHandler<DoorInputChangedStatusEventArgs> InputChangedStatus = null;

        /// <summary>
        /// Door ajar event triggered when the door is open after embarrassment time has expired.
        /// </summary>
        public event EventHandler<DoorAjarForcedEventArgs> DoorAjarEvent = null;

        /// <summary>
        /// Door forced event triggered when the door contact is no longer secure and the door agent state is Closed.
        /// </summary>
        public event EventHandler<DoorAjarForcedEventArgs> DoorForcedEvent = null;

        /// <summary>
        /// Triggered when the isolated flag of any of the doors changes.
        /// </summary>
        public event EventHandler<StatusManagerDoorChangedIsolatedEventArgs> ChangedIsolatedStatus = null;

        /// <summary>
        /// Triggered when the trouble flag of any of the doors changes.
        /// </summary>
        public event EventHandler<StatusManagerDoorChangedTroubleEventArgs> ChangedTroubleStatus = null;

        /// <summary>
        /// Triggered when there is need to update anti-passback information
        /// </summary>
        public event EventHandler<OnUpdateAntipassbackEventArgs> OnUpdateAntipassbackInfo = null;

        /// <summary>
        /// Triggered when card has been entered but after keypad inactivity timer expired.
        /// The pin was not provided in time.
        /// </summary>
        public event EventHandler<ReaderKeypadEventArgs> KeypadInactivityTimeoutExpired = null;

        /// <summary>
        /// Triggered when the door finished processing a scanned card and pin entered and 
        /// needs to pass the result to the access control manager. The AccessControlManager 
        /// will subscribe to this event.
        /// </summary>
        public event EventHandler<CardAndPinEnteredEventArgs> CardAndPinEntered = null;

        /// <summary>
        /// Triggered when a valid access takes place but the door is not opened before the
        /// strike time expires.
        /// </summary>
        public event EventHandler<CardAccessEventArgs> AccessNotTaken = null;

        public event EventHandler<MultiBadgingCardAccessEventArgs> MultiBadgingAccessNotTaken = null;

        /// <summary>
        /// Triggered when a valid access takes place and the door is opened.
        /// </summary>
        public event EventHandler<CardAccessEventArgs> AccessTaken = null;

        /// <summary>
        /// Triggered when a valid access takes place and the door is opened, in a 
        /// multi-badging configuration.
        /// </summary>
        public event EventHandler<MultiBadgingCardAccessEventArgs> MultiBadgingAccessTaken = null;

        /// <summary>
        /// Triggered when the state of the door has changed
        /// </summary>
        public event EventHandler<DoorStateChangedEventArgs> DoorStateChanged = null;

        /// <summary>
        /// Triggered when keypad inactivity timer has expired.
        /// </summary>
        /// <param name="logicalDoorId">Logical door id</param>
        /// <param name="logicalReaderId">Logical reader id</param>
        internal void TriggerKeypadInactivityTimeoutExpired(int logicalDoorId, int logicalReaderId)
        {
            if (KeypadInactivityTimeoutExpired == null)
                return;
            KeypadInactivityTimeoutExpired(this, new ReaderKeypadEventArgs(logicalReaderId, logicalDoorId, this[logicalDoorId].GetCardNumber(logicalReaderId)));
        }

        /// <summary>
        /// Triggered when card and pin has been entered
        /// </summary>
        /// <param name="logicalDoorId">Logical door id</param>
        /// <param name="logicalReaderId">Logical reader id</param>
        /// <param name="cardNumber">Legacy card number</param>
        /// <param name="pinDigits">Byte array with pin data</param>
        internal void TriggerCardAndPinEntered(int logicalDoorId, int logicalReaderId, CardNumberHolder cardNumber, byte[] pinDigits )
        {
            if (CardAndPinEntered == null)
                return;
            CardAndPinEntered(this, new CardAndPinEnteredEventArgs(cardNumber, pinDigits, logicalReaderId, logicalDoorId));
        }

        /// <summary>
        /// Trigger door controller input status changed event handler that will be subscribed to by the access control manager
        /// </summary>
        /// <param name="doorStatus">The new status value for the changed door input.</param>
        /// <param name="changedInput">The door controller input that changed status, enum member</param>
        /// <param name="status">Door input current status.</param>
        /// <param name="previousInputStatus">Previous input status value</param>
        internal void TriggerDoorControllerInputStatusChanged(DoorStatus doorStatus, ChangedDoorControllerInput changedInput, Common.InputStatus status,
                                                              Common.InputStatus previousInputStatus)
        {
            if (InputChangedStatus == null)
                return;
            InputChangedStatus(this, new DoorInputChangedStatusEventArgs(doorStatus, changedInput, status, previousInputStatus));
        }

        /// <summary>
        /// Trigger door ajar alarm event.
        /// </summary>
        /// <param name="doorStatus">Ajar door's status</param>
        /// <param name="contactSecure"></param>
        internal void TriggerDoorAjar(DoorStatus doorStatus, bool contactSecure)
        {
            if (DoorAjarEvent == null)
                return;

            DoorAjarEvent(this, new DoorAjarForcedEventArgs(doorStatus.LogicalId, contactSecure));
            if(contactSecure == false)
                MacroControl.Instance.EnqueueDoorEvent(doorStatus.LogicalId, DoorContextStatus.Ajar);
        }

        /// <summary>
        /// Trigger door forced event.
        /// </summary>
        /// <param name="doorStatus">Forced door's status</param>
        internal void TriggerDoorForced(DoorStatus doorStatus, bool contactSecure)
        {
            if (doorStatus.Enabled == false)
                return;

            if (DoorForcedEvent == null)
                return;

            DoorForcedEvent(this, new DoorAjarForcedEventArgs(doorStatus.LogicalId, contactSecure));
            if(contactSecure == false)
                MacroControl.Instance.EnqueueDoorEvent(doorStatus.LogicalId, DoorContextStatus.Forced);
        }

        /// <summary>
        /// Triggered when door isolated status has changed
        /// </summary>
        /// <param name="doorStatus">The doors status instance that has changed.</param>
        /// <param name="isolated">The new value of the door isolated status.</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        internal void TriggerChangedIsolatedStatus(DoorStatus doorStatus, bool isolated, UserAuditInfo userAuditInfo)
        {
            if (ChangedIsolatedStatus == null)
                return;
            ChangedIsolatedStatus(this, new StatusManagerDoorChangedIsolatedEventArgs(doorStatus, isolated, userAuditInfo));
        }

        /// <summary>
        /// Triggered when door trouble status has changed
        /// </summary>
        /// <param name="doorStatus">The doors status instance that has changed.</param>
        /// <param name="trouble">The new value of the door trouble status.</param>
        internal void TriggerChangedTroubleStatus(DoorStatus doorStatus, DoorTroubleType troubleType, bool trouble)
        {
            if (ChangedTroubleStatus == null)
                return;
            ChangedTroubleStatus(this, new StatusManagerDoorChangedTroubleEventArgs(doorStatus, troubleType, trouble));
        }

        /// <summary>
        /// Trigger antipassback information update 
        /// </summary>
        /// <param name="logicalDoorId"></param>
        /// <param name="logicalReaderId"></param>
        /// <param name="cardFormat"></param>
        internal void TriggerUpdateAntipassbackInfo(int logicalDoorId, int logicalReaderId, CardInformation cardInformation)
        {
            if (OnUpdateAntipassbackInfo == null)
                return;
            OnUpdateAntipassbackInfo(this, new OnUpdateAntipassbackEventArgs(logicalDoorId, logicalReaderId, cardInformation));
        }

        /// <summary>
        /// Triggered when a door is not opened after a valid access event
        /// </summary>
        internal void TriggerAccessNotTaken(int logicalDoorId, int logicalReaderId, CardNumberHolder card, int userId)
        {
            if (AccessNotTaken == null)
                return;
            AccessNotTaken(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, card, userId));
        }

        /// <summary>
        /// Triggered when a door is opened after a valid access event
        /// </summary>
        internal void TriggerAccessTaken(int logicalDoorId, int logicalReaderId, CardNumberHolder card, int userId)
        {
            if (AccessTaken == null)
                return;
            AccessTaken(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, card, userId));
        }

        internal void TriggerDoorStateChanged(int logicalId, DoorOperationState oldState, DoorOperationState newState)
        {
            if (DoorStateChanged == null)
                return;
            DoorStateChanged(this, new DoorStateChangedEventArgs(logicalId, oldState, newState));
        }

        internal void TriggerAccessNotTaken(int logicalDoorId, int logicalReaderId, ReaderTransaction readerTransaction)
        {
            if (AccessNotTaken == null)
                return;
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
            if (readerConfig == null || readerConfig.Enabled == false)
                return;
            if (readerTransaction.BadgingType == ReaderBadgingType.Normal)
            {
                AccessNotTaken(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, readerTransaction.Card, readerTransaction.CardInformation.UserId));
            }
            else if (readerTransaction.MultiBadgingCardInformationList != null)
            {
                if (MultiBadgingAccessNotTaken != null)
                {
                    MultiBadgingAccessNotTaken(this, new MultiBadgingCardAccessEventArgs(logicalDoorId, logicalReaderId, readerTransaction.MultiBadgingCardInformationList, readerTransaction.BadgingType));
                }
            }
        }

        internal void TriggerAccessTaken(int logicalDoorId, int logicalReaderId, ReaderTransaction readerTransaction)
        {
            if (AccessTaken == null)
                return;
            IReaderConfiguration readerConfig = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
            if (readerConfig == null || readerConfig.Enabled == false)
                return;
            if (readerTransaction.BadgingType == ReaderBadgingType.Normal)
            {
                AccessTaken(this, new CardAccessEventArgs(logicalDoorId, logicalReaderId, readerTransaction.Card, readerTransaction.CardInformation.UserId));
            }
            else if (readerTransaction.MultiBadgingCardInformationList != null)
            {
                if (MultiBadgingAccessTaken != null)
                {
                    MultiBadgingAccessTaken(this, new MultiBadgingCardAccessEventArgs(logicalDoorId, logicalReaderId, readerTransaction.MultiBadgingCardInformationList, readerTransaction.BadgingType));
                }
            }
        }

        /// <summary>
        /// Isolate a list of doors for a specified duration.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <returns></returns>
        public bool SetIsolated(List<int> doorIds, bool value, UserAuditInfo userAuditInfo, int durationInSeconds)
        {
            if (value == true)
            {
                List<int> doorsToDeisolate = new List<int>(doorIds.Count);
                foreach (int doorId in doorIds)
                {
                    DoorStatus status = this[doorId];
                    if (status != null && status.Enabled == true)
                    {
                        if (status.SetIsolated(userAuditInfo, true) == true)
                            doorsToDeisolate.Add(doorId);
                    }
                }
                if (durationInSeconds > 0)
                {
                    StatusManager.Instance.CreateTimedAction(StatusManagerTimedActions.DeisolateOutputs, doorsToDeisolate, userAuditInfo, durationInSeconds);
                }
                return (doorsToDeisolate.Count > 0);
            }
            else
            {
                // Deisolate doesn't support a duration.
                bool result = false;
                foreach (int doorId in doorIds)
                {
                    DoorStatus status = this[doorId];
                    if (status != null && status.Enabled == true)
                    {
                        if (status.SetIsolated(userAuditInfo, false) == true)
                            result = true;
                    }
                }
                return result;
            }
        }

        /// <summary>
        /// Trigger when all reader statuses have been created.
        /// </summary>
        internal void PostInitialize()
        {
            foreach (var door in Items)
            {
                door.PostInitialize();
            }
        }

        private DoorStatus createDoorStatus(DoorConfiguration doorConfiguration, DoorStatusStorage doorStatusStorage)
        {
            DoorStatus doorStatus = null;

            if (doorConfiguration.InReader != null)
            {
                IDeviceLoopDCDevice parent = ConfigurationManager.Instance.GetDeviceConfiguration(doorConfiguration.InReader.ParentDeviceId) as IDeviceLoopDCDevice;
                if (parent != null)
                {
                    int pointNumberOnParent = 0;
                    for (int i = 0; i < parent.Doors.Length; i++)
                    {
                        if (parent.Doors[i] != null && parent.Doors[i].Id == doorConfiguration.Id)
                        {
                            pointNumberOnParent = i;
                            break;
                        }
                    }
                    doorStatus = new DoorStatus(doorConfiguration, parent.IsStrikeEnabledForDoor(pointNumberOnParent), doorConfiguration.EnableEgressOperation, doorConfiguration.AutomaticEgress, this, doorStatusStorage);
                }
            }

            return doorStatus;
        }

        /// <summary>
        /// Update doors list from configuration. Add new door status instances if not already existing
        /// </summary>
        /// <param name="doors">List of doors configuration to add</param>
        /// <param name="statusStorage">Stataus Storage instance or null if status restore is not required</param>
        internal void UpdateFromConfiguration(DoorConfiguration[] doors, StatusStorageCollection statusStorage)
        {
            foreach (var door in doors)
            {
                DoorStatus doorStatus = createDoorStatus(door, statusStorage.DoorsStatus.TryGetValue(door.Id));
                if (doorStatus != null)
                    Assign(door.Id, doorStatus);
            }
        }

        /// <summary>
        /// Update Door status list from configuration on configuration change.
        /// </summary>
        internal void UpdateFromConfiguration(List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems, List<NodeStateBase> partialStatusList)
        {
            foreach (var removedItem in removedItems)
            {
                if (removedItem.ConfigurationType == ConfigurationElementType.Door)
                    Remove(removedItem.Id);
            }
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Door)
                {
                    Remove(changedItem.Id);
                    try
                    {
                        DoorStatus doorStatus = createDoorStatus(ConfigurationManager.Instance.GetDoorConfiguration(changedItem.Id), null);
                        if (doorStatus != null)
                        {
                            Assign(changedItem.Id, doorStatus);
                            partialStatusList.Add(this[changedItem.Id].CreateEventState());
                        }
                    }
                    catch
                    {
                    }
                }
            }
            foreach (var newlyAddedItem in newlyAddedItems)
            {
                if (newlyAddedItem.ConfigurationType == ConfigurationElementType.Door)
                {
                    try
                    {
                        DoorStatus doorStatus = createDoorStatus(ConfigurationManager.Instance.GetDoorConfiguration(newlyAddedItem.Id), null);
                        if (doorStatus != null)
                        {
                            Assign(newlyAddedItem.Id, doorStatus);
                            partialStatusList.Add(this[newlyAddedItem.Id].CreateEventState());
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }

        internal override void Persist(Asn1DerFormatter asn1Serializer, Stream statusStream)
        {
            foreach (var door in Items)
            {
                try
                {
                    asn1Serializer.Serialize(statusStream, door.CreateStatusStorage());
                }
                catch (Exception ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                    {
                        return string.Format("Unable to store status for door {0}. {1}", door.LogicalId, ex.Message);
                    });
                }
            }
        }

        internal void RefreshAfterConfigurationChange()
        {
            foreach (var door in Items)
            {
                door.RefreshAfterConfigurationChange();
            }
        }

        internal void RefreshAfterConfigurationChange(List<ConfigurationChanges> changedItems)
        {
            foreach (var changedItem in changedItems)
            {
                if (changedItem.ConfigurationType == ConfigurationElementType.Door)
                {
                    DoorStatus door = this[changedItem.Id];
                    if (door != null)
                        door.RefreshAfterConfigurationChange();
                }
            }
        }

        /// <summary>
        /// Get all doors for all areaIds that belongs to a user.
        /// </summary>
        /// <param name="user"></param>
        /// <returns>Returns the list of doors for all areas belongs to this user.</returns>
        public List<IStatusItem> GetDoorsInAreasForUser(IUserConfiguration user)
        {
           var doorStausItems = new List<IStatusItem>();
            foreach (var doorStaus in Items)
            {
                if (doorStaus != null && doorStaus.Enabled == true)
                {
                    var door = ConfigurationManager.Instance.GetDoorConfiguration(doorStaus.LogicalId);
                    if (door != null && user.AreaIds.Contains(door.AreaId))
                    {
                        doorStausItems.Add(doorStaus);
                    }
                }
            }
            doorStausItems.Sort((x, y) => x.LogicalId.CompareTo(y.LogicalId));
            return doorStausItems;
        }
    }
}
