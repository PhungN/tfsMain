﻿using System.IO;

namespace Pacom.Peripheral.Common
{
    public class SDCardLocations
    {
        public const string SDCardMountingDirectory = "\\SDRegion";

        public static bool IsSDCardMounted()
        {
            return Directory.Exists(SDCardLocations.SDCardMountingDirectory);                
        }
    }
}
