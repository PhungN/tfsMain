﻿
namespace Pacom.Peripheral.CellularManagement
{
    public enum CellularAccessTechnology
    {
        Unknown = -1,
        GSM = 0,      // 2G
        UMTS = 2,     // 3G
        LTE4G = 7,    // LTE/4G (E-UTRAN)
        LTECatM1 = 8, // LTE Cat M1
        LTECatNB1 = 9 // LTE Cat NB1
    }
}
