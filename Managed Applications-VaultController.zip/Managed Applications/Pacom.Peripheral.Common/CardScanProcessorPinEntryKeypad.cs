﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Handles the keypad for a single reader
    /// </summary>
    internal class CardScanProcessorPinEntryKeypad
    {
        /// <summary>
        /// Keys accumulated so far, but not passed on for processing
        /// </summary>
        private readonly List<byte> keys = new List<byte>();

        /// <summary>
        /// Keypad timeout, to automatically clear keys after a delay
        /// </summary>
        private readonly TimeLimit keypressTimeout;

        /// <summary>
        /// Delay before clearing accumulated keys
        /// </summary>
        private static int inactivityTimeoutInSeconds;

        /// <summary>
        /// The reader that we are associated with
        /// </summary>
        private readonly int readerId;

        /// <summary>
        /// PIN length, at which keys are automatically processed
        /// </summary>
        private static int pinLength;

        public delegate void ProcessPinDataDelegate(int logicalReaderId, byte[] keys);

        /// <summary>
        /// Callback to process PIN/keypad data
        /// </summary>
        private readonly ProcessPinDataDelegate processPinData;

        /// <summary>
        /// Create keypad for a reader
        /// </summary>
        /// <param name="readerId">Associated reader's logical ID</param>
        /// <param name="pinLengthSetting">Expected PIN length</param>
        /// <param name="inactivityTimeoutInSecondsSetting">Inactivity timeout (seconds)</param>
        /// <param name="processPinData">Callback function to process PIN entry</param>
        public CardScanProcessorPinEntryKeypad(int readerId, int pinLengthSetting, int inactivityTimeoutInSecondsSetting, ProcessPinDataDelegate processPinData)
        {
            keypressTimeout = new TimeLimit();
            this.processPinData = processPinData;
            this.readerId = readerId;
            pinLength = pinLengthSetting;
            inactivityTimeoutInSeconds = inactivityTimeoutInSecondsSetting;
        }

        /// <summary>
        /// Add a keypress to the list of waiting keys
        /// </summary>
        private void addKeyPress(byte key)
        {
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.CardScanProcessor, DebugLoggingSubCategory.AccessControl, () => string.Format("Reader Id {0} keypress: {1:x2}", readerId, key));
#endif
            keys.Add(key);
        }

        /// <summary>
        /// Remove the last key added
        /// </summary>
        private void deleteLastKeyPress()
        {
            if (keys.Count > 0)
            {
                keys.RemoveAt(keys.Count - 1);
            }
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.CardScanProcessor, DebugLoggingSubCategory.AccessControl, () => string.Format("Reader Id {0} clear last, {1} keys left", readerId, keys.Count));
#endif
        }

        /// <summary>
        /// Clear all saved keypresses
        /// </summary>
        private void clearAll()
        {
            keys.Clear();
        }

        /// <summary>
        /// If it has been too long since the last keypress, clear accumulated keys. Restart timer for next inter-key interval check
        /// </summary>
        private void keyTimeoutCheck()
        {
            uint elapsed;
            if (keypressTimeout.IsTimeUp(inactivityTimeoutInSeconds * 1000, out elapsed))
            {
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.CardScanProcessor, DebugLoggingSubCategory.AccessControl, () => string.Format("Reader Id {0}, {1} seconds elapsed, clearing all keys", readerId, elapsed / 1000));
#endif

                clearAll();
            }
            keypressTimeout.Reset();
        }


        /// <summary>
        /// Process a keypress
        /// </summary>
        /// <param name="key">Key to process</param>
        public void ProcessKey(byte key)
        {
            // Guessing that some of the mystery codes may be tamper and heartbeat indications
            // 0x00 -> 0x09 = Digits 0-9 on keypad
            // 0x0a = "*"/Clear/Delete button
            // 0x0b = "#"/Enter button
            // 0x0c = ?
            // 0x0d = ?
            // 0x0e = ?
            // 0x0f = ?

            keyTimeoutCheck();

            switch (key)
            {
                case 0x0a: // CLEAR
                {
                    deleteLastKeyPress();
                    return;
                }
                case 0x0b: // ENTER
                {
                    sendKeys();
                    return;
                }
                case 0x0e:
                case 0x0f:
                {
                    // Silently ignore
                    return;
                }
                default:
                {
                    // "Regular" key 
                    addKeyPress(key);

                    if (keys.Count >= pinLength)
                    {
                        sendKeys();
                    }
                    return;
                }
            }
        }

        /// <summary>
        /// Time to send the keys we've collected
        /// </summary>
        private void sendKeys()
        {
            if (keys.Count == 0)
            {
                return;
            }

            // Call the callback with the keys we've got
            processPinData(readerId, keys.ToArray());
            clearAll();
        }
    }
}
