﻿using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    public abstract class NodeConfigurationListBase<T> : ConfigurationListBase<T> where T : INodeConfiguration
    {
        protected NodeConfigurationListBase() : base()
        {
        }

        /// <summary>
        /// Get enabled configuration items count
        /// </summary>
        public int EnabledCount
        {
            get
            {
                return configurationItemList.Count(item => item.Value.Enabled == true);
            }
        }
    }
}
