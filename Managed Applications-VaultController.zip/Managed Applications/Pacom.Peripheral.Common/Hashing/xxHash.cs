﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Calculate perfect hash for byte array. Uses C# implementation for: https://github.com/Cyan4973/xxHash
    /// </summary>
    public class xxHash
    {
        const uint PRIME32_1 = 2654435761U;
        const uint PRIME32_2 = 2246822519U;
        const uint PRIME32_3 = 3266489917U;
        const uint PRIME32_4 = 668265263U;
        const uint PRIME32_5 = 374761393U;

        public static uint CalculateHash(byte[] buffer)
        {
            uint h32;
            int index = 0;
            int len = buffer.Length;

            if (len >= 16)
            {
                int limit = len - 16;
                unchecked
                {
                    uint v1 = PRIME32_1 + PRIME32_2;
                    uint v2 = PRIME32_2;
                    uint v3 = 0;
                    uint v4 = 0 - PRIME32_1;

                    do
                    {
                        v1 = calcSubHash(v1, buffer, index);
                        index += 4;
                        v2 = calcSubHash(v2, buffer, index);
                        index += 4;
                        v3 = calcSubHash(v3, buffer, index);
                        index += 4;
                        v4 = calcSubHash(v4, buffer, index);
                        index += 4;
                    } while (index <= limit);

                    h32 = rotateLeft(v1, 1) + rotateLeft(v2, 7) + rotateLeft(v3, 12) + rotateLeft(v4, 18);
                }
            }
            else
            {
                h32 = PRIME32_5;
            }

            h32 += (uint)len;

            while (index <= len - 4)
            {
                h32 += BitConverter.ToUInt32(buffer, index) * PRIME32_3;
                h32 = rotateLeft(h32, 17) * PRIME32_4;
                index += 4;
            }

            while(index<len)
            {
                h32 += buffer[index] * PRIME32_5;
                h32 = rotateLeft(h32, 11) * PRIME32_1;
                index++;
            }

            h32 ^= h32 >> 15;
            h32 *= PRIME32_2;
            h32 ^= h32 >> 13;
            h32 *= PRIME32_3;
            h32 ^= h32 >> 16;

            return h32;
        }

        private static uint calcSubHash(uint value, byte[] buf, int index)
        {
            uint read_value = BitConverter.ToUInt32(buf, index);
            value += read_value * PRIME32_2;
            value = rotateLeft(value, 13);
            value *= PRIME32_1;
            return value;
        }

        private static uint rotateLeft(uint value, int count)
        {
            return (value << count) | (value >> (32 - count));
        }

    }
}
