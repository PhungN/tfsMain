﻿using System;

namespace Pacom.Peripheral.Common
{
    public class xxHash64
    {
        const ulong PRIME64_1 = 11400714785074694791UL;
        const ulong PRIME64_2 = 14029467366897019727UL;
        const ulong PRIME64_3 =  1609587929392839161UL;
        const ulong PRIME64_4 =  9650029242287828579UL;
        const ulong PRIME64_5 =  2870177450012600261UL;

        public static ulong CalculateHash(byte[] buffer)
        {
            ulong h64;
            int index = 0;
            int len = buffer.Length;

            if (len >= 32)
            {
                int limit = len - 32;
                unchecked
                {
                    ulong v1 = PRIME64_1 + PRIME64_2;
                    ulong v2 = PRIME64_2;
                    ulong v3 = 0;
                    ulong v4 = 0 - PRIME64_1;

                    do
                    {
                        v1 = calcSubHash(v1, buffer, index);
                        index += 8;
                        v2 = calcSubHash(v2, buffer, index);
                        index += 8;
                        v3 = calcSubHash(v3, buffer, index);
                        index += 8;
                        v4 = calcSubHash(v4, buffer, index);
                        index += 8;
                    } while (index <= limit);

                    h64 = rotateLeft(v1, 1) + rotateLeft(v2, 7) + rotateLeft(v3, 12) + rotateLeft(v4, 18);
                    h64 = mergeRound(h64, v1);
                    h64 = mergeRound(h64, v2);
                    h64 = mergeRound(h64, v3);
                    h64 = mergeRound(h64, v4);
                }
            }
            else
            {
                h64 = PRIME64_5;
            }

            h64 += (ulong)len;

            while (index <= len - 8)
            {
                ulong k1 = calcSubHash(0, buffer, index);
                h64 ^= k1;
                h64 = rotateLeft(h64, 27) * PRIME64_1 + PRIME64_4;
                index += 8;
            }

            if (index <= len - 4)
            {
                uint k2 = BitConverter.ToUInt32(buffer, index);
                h64 ^= (ulong)k2 * PRIME64_1;
                index += 4;
            }

            while (index < len)
            {
                h64 ^= buffer[index] * PRIME64_5;
                h64 = rotateLeft(h64, 11) * PRIME64_1;
                index++;
            }

            h64 ^= h64 >> 33;
            h64 *= PRIME64_2;
            h64 ^= h64 >> 29;
            h64 *= PRIME64_3;
            h64 ^= h64 >> 32;

            return h64;
        }

        private static ulong calcSubHash(ulong value, byte[] buf, int index)
        {
            ulong read_value = BitConverter.ToUInt64(buf, index);
            value += read_value * PRIME64_2;
            value = rotateLeft(value, 31);
            value *= PRIME64_1;
            return value;
        }

        private static ulong calcSubHash(ulong acc, ulong value)
        {
            acc += value * PRIME64_2;
            acc = rotateLeft(value, 31);
            acc *= PRIME64_1;
            return acc;
        }

        private static ulong mergeRound(ulong acc, ulong value)
        {
            value = calcSubHash(0, value);
            acc ^= value;
            acc = acc * PRIME64_1 + PRIME64_4;
            return acc;
        }

        private static ulong rotateLeft(ulong value, int count)
        {
            return (value << count) | (value >> (64 - count));
        }
    }
}
