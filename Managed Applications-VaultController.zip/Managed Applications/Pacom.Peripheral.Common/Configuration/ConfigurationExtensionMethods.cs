﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    public static class ConfigurationExtensionMethods
    {
        /// <summary>
        /// Extension method for converting legacy cards format concrete type instance to base type instance for serialization
        /// </summary>
        /// <param name="cardFormats">List of legacy card formats to convert</param>
        /// <param name="configurationItems">List of configuration items to add the converted card formats to.</param>
        public static void SetDefaults(this ControllerConnection8003Entry connectionEntry)
        {
            setDefaultsUsingReflection(connectionEntry);
        }

        private static void setDefaultsUsingReflection(object o)
        {
            foreach (PropertyInfo property in o.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (property.CanWrite)
                {       
                    DefaultValueAttribute defaultAttribute = (DefaultValueAttribute)property.GetCustomAttributes(typeof(DefaultValueAttribute), false).FirstOrDefault();
                    if (defaultAttribute != null)
                    {
                        if (property.PropertyType == typeof(TimeSpan))
                        {   // Timespans should be cast from milliseconds.
                            property.SetValue(o, new TimeSpan(0, 0, 0, 0, (int)defaultAttribute.Value), null);
                        }
                        else
                        {
                            property.SetValue(o, defaultAttribute.Value, null);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Get locale aware day name for [dateTime] from controller configuration
        /// </summary>
        /// <param name="controllerConfig">Controller configuration instance</param>
        /// <param name="dateTime">DateTime for which to get the localized day name.</param>
        /// <returns>Localized day name as string</returns>
        public static string LocalizedDayName(this Pacom8003Configuration controllerConfig, DateTime dateTime)
        {
            switch (dateTime.DayOfWeek)
            {
                case DayOfWeek.Monday: return controllerConfig.MondayText;
                case DayOfWeek.Tuesday: return controllerConfig.TuesdayText;
                case DayOfWeek.Wednesday: return controllerConfig.WednesdayText;
                case DayOfWeek.Thursday: return controllerConfig.ThursdayText;
                case DayOfWeek.Friday: return controllerConfig.FridayText;
                case DayOfWeek.Saturday: return controllerConfig.SaturdayText;
                case DayOfWeek.Sunday: return controllerConfig.SundayText;
                default: return string.Empty;
            }
        }

        /// <summary>
        /// Returns true for EN grade 3 or 4 configurations of the keypad
        /// </summary>
        /// <param name="keypadOperationalMode"></param>
        /// <returns></returns>
        public static bool IsEN(this KeypadOperationalMode keypadOperationalMode)
        {
            if (keypadOperationalMode == KeypadOperationalMode.EN50131Grade4)
                return true;
            return false;
        }
    }
}
