﻿using System;
using System.IO;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class LegacyCardFormatList : ConfigurationListBase<LegacyCardFormat>, IConfigurationList
    {
        internal LegacyCardFormatList() : base() { }

        /// <summary>
        /// Get next legacy card format Id
        /// </summary>
        public int NextCardFormatId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
