﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public class ConfigurationChangeInProgressEventManager
    {
        private static readonly object sync = new object();
        private List<ConfigurationChangeInProgressEventProcessing> configurationChangeEvents = new List<ConfigurationChangeInProgressEventProcessing>();
        private ConfigurationChangeInProgressEventManager()
        {
        }

        private static ConfigurationChangeInProgressEventManager instance = null;
        public static ConfigurationChangeInProgressEventManager Instance
        {
            get
            {
                lock(sync)
                {
                    if (instance == null)
                        instance = new ConfigurationChangeInProgressEventManager();
                }
                return instance;
            }
        }

        public void Add(string identifier, UserAuditInfo userAuditInfo)
        {
            bool exist = false;
            foreach (var item in configurationChangeEvents)
            {
                if (item.Identifier.ToUpper() == identifier.ToUpper())
                {
                    exist = true;
                    item.Update();
                    break;
                }
            }
            if (exist == false)
            {
                ConfigurationChangeInProgressEventProcessing eventProgress = new ConfigurationChangeInProgressEventProcessing(identifier, userAuditInfo, Remove);
                configurationChangeEvents.Add(eventProgress);
            }
        }

        public void Remove(string identifier)
        {
            for (int i = 0; i < configurationChangeEvents.Count; i++)
            {
                var item = configurationChangeEvents[i];
                if (item.Identifier.ToUpper() == identifier.ToUpper())
                {
                    item.Dispose();
                    configurationChangeEvents.RemoveAt(i);
                    break;
                }
            }
        }

        public void Clear()
        {
            foreach (var item in configurationChangeEvents)
            {
                item.Dispose();
            }
            configurationChangeEvents.Clear();
        }
    }
}
