﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class ReaderSchedule : Schedule, IDisposable
    {
        private Dictionary<DayType, ScheduleRecord> schedulesMap = new Dictionary<DayType, ScheduleRecord>();

        /// <summary>
        /// Current schedule level - set every time the reader schedule timer fires.
        /// </summary>
        private Reader8003ScheduleLevel scheduledLevel = Reader8003ScheduleLevel.Blocked;
        public Reader8003ScheduleLevel ScheduledLevel
        {
            get { return scheduledLevel; }
        }

        private int scheduleIntervalOffset = 0;

        /// <summary>
        /// Current schedule interval - set to the interval index plus one. 0 means no interval has been reached.
        /// </summary>
        public int ScheduleIntervalOffset
        {
            get { return scheduleIntervalOffset; }
        }

        private DayType scheduleDay = DayType.None;

        /// <summary>
        /// Current schedule day
        /// </summary>
        public DayType ScheduleDay
        {
            get { return scheduleDay; }
        }

        public ReaderSchedule()
        {
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Schedules == null || Schedules.Length == 0)
                return;

            foreach (var scheduleRecord in Schedules)
            {
                schedulesMap[scheduleRecord.DayType] = scheduleRecord;
            }

            DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
            RecalculateSchedule(now, null);
        }

        /// <summary>
        /// Update the reader(s) status from reader schedule
        /// </summary>
        /// <param name="now">Current date/time</param>
        /// <returns>Next start date/time</returns>
        internal DateTime RecalculateSchedule(DateTime now, ReaderStatusList readers)
        {
            DayType todayDay = StatusManager.TodayDayType;
            DateTime nextStartTime = DateTime.MaxValue;
            Reader8003ScheduleLevel level = Reader8003ScheduleLevel.CardOnly;
            ScheduleRecord scheduleRecord = null;

            int newIntervalId = -1;
            DayType newDayType = DayType.None;
            if (schedulesMap.TryGetValue(todayDay, out scheduleRecord) == true)
            {
                if ((scheduleRecord.Intervals != null && scheduleRecord.Intervals.Length > 0) == false)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("Reader Schedule for {0}, doesn't contain any intervals.", todayDay.ToString());
                    });
                }
                newDayType = todayDay;
                // A schedule record was found for this day, look for the schedule interval the current time of day falls in and get the
                // schedule level.
                if (scheduleRecord.Intervals.Length > 0)
                {
                    int maxIntervalId = scheduleRecord.Intervals.Length - 1;
                    for (int i = 0; i <= maxIntervalId; i++)
                    {
                        ScheduleInterval scheduleInterval = scheduleRecord.Intervals[i];
                        if (scheduleInterval == null)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                            {
                                return string.Format("Reader Schedule interval for day {0} is invalid.", 
                                    Common.LoggerClassPrefixes.ConfigurationManager, todayDay.ToString());
                            });
                        }

                        if (now.Hour > scheduleInterval.StartTime.Hour ||
                            (now.Hour == scheduleInterval.StartTime.Hour && now.Minute >= scheduleInterval.StartTime.Minute))
                        {
                            newIntervalId = i;
                            if (Enum.IsDefined(typeof(Reader8003ScheduleLevel), scheduleInterval.Level))
                                level = (Reader8003ScheduleLevel)scheduleInterval.Level;
                            else
                                level = (Reader8003ScheduleLevel)0;
                            if (newIntervalId < maxIntervalId)
                            {
                                TimeSpan timeOfDay = scheduleRecord.Intervals[i + 1].StartTime.TimeOfDay;
                                nextStartTime = new DateTime(now.Year, now.Month, now.Day, timeOfDay.Hours, timeOfDay.Minutes, timeOfDay.Seconds, DateTimeKind.Local);
                            }
                            else
                            {
                                nextStartTime = new DateTime(now.Year, now.Month, now.Day, 23, 59, 59, DateTimeKind.Local);
                            }
                        }
                        else
                        {
                            // This time schedule record has one schedule interval only and current time is smaller then the interval StartTime.
                            if (newIntervalId == -1)
                            {
                                TimeSpan timeOfDay = scheduleInterval.StartTime.TimeOfDay;
                                nextStartTime = new DateTime(now.Year, now.Month, now.Day, timeOfDay.Hours, timeOfDay.Minutes, timeOfDay.Seconds, DateTimeKind.Local);
                            }
                            break;
                        }
                    }
                }
            }

            if (nextStartTime == DateTime.MaxValue)
            {
                // Get next timer due time
                nextStartTime = new DateTime(now.Year, now.Month, now.Day, 23, 59, 59, DateTimeKind.Local);
            }

            // Offset the interval Id by one. Zero means there was no interval schedule found.
            newIntervalId++;

            scheduledLevel = level;
            scheduleIntervalOffset = newIntervalId;
            scheduleDay = newDayType;

            if (readers != null)
            {
                // Aggregate readers that obey this reader schedule
                aggregateReaders(newDayType, newIntervalId, level, readers);
            }

            return nextStartTime;
        }

        /// <summary>
        /// Notify reader status list that a schedule change has occurred.
        /// </summary>
        /// <param name="day">None - no day has been found or it is the day of the week the interval applies.</param>
        /// <param name="intervalOffset">0 - no intervals are applied yet. Value 1 and more is a offset within the day intervals minus one. </param>
        /// <param name="level">Reader schedule level</param>
        /// <param name="readers">Readers Status List instance or null</param>
        private void aggregateReaders(DayType day, int intervalOffset, Reader8003ScheduleLevel level, ReaderStatusList readers)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
            {
                return string.Format("Schedule update readers status for reader scheduleId={0}", Id);
            });
            List<int> readerIds = new List<int>();
            foreach (var readerConfig in ConfigurationManager.Instance.Readers)
            {
                if (readerConfig.Enabled == true && readerConfig.ScheduleId == Id)
                {
                    if (readerIds.Contains(readerConfig.Id) == false)
                    {
                        readerIds.Add(readerConfig.Id);
                    }
                }
            }
            if (readerIds.Count > 0)
            {
                readers.ScheduleChangeNotification(this, day, intervalOffset, level, readerIds);
            }
        }

        #region IDisposable Members

        bool disposed = false;

        private void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                schedulesMap.Clear();
                schedulesMap = null;
                scheduledLevel = Reader8003ScheduleLevel.Blocked;
            }

            // Free any unmanaged objects here.            
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
