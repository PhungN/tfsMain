﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class OutputConfiguration : Output8003Configuration
    {
        public OutputConfiguration()
        {
        }

        public static void AutoConfigure(DeviceConfigurationBase parentDevice, int pointNumberOnParent, List<ConfigurationBase> configuration)
        {
            Output8003Configuration outputConfiguration = new Output8003Configuration();
            outputConfiguration.SetDefaults();
            outputConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            outputConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            outputConfiguration.Id = ConfigurationManager.Instance.NextOutputId;
            outputConfiguration.ParentDeviceId = parentDevice.Id;
            outputConfiguration.PointNumberOnParent = pointNumberOnParent;
            if (ConfigurationManager.Instance.DefaultingConfiguration || ConfigurationManager.Instance.GetAreaConfiguration(1) != null)
                outputConfiguration.AreaId = 1;
            else
                outputConfiguration.AreaId = 0;
            outputConfiguration.Name = string.Format("Output {0}:{1}", parentDevice.Name, pointNumberOnParent);
            configuration.Add(outputConfiguration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        public void AutoConfigure(DeviceConfigurationBase parentDevice, int pointNumberOnParent)
        {
            InitializeWithDefaults();
            Id = ConfigurationManager.Instance.NextOutputId;
            ParentDeviceId = parentDevice.Id;
            PointNumberOnParent = pointNumberOnParent;
            AreaId = 1;
            Area = ConfigurationManager.Instance.GetAreaConfiguration(AreaId);
            if (Area != null)
                Area.AddOutput(this);
            string parentDeviceName = ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, parentDevice.Id);
            ConfigurationStringRepository.AddName(ConfigurationType.Output, Id, string.Format("Output {0}:{1}", parentDeviceName, pointNumberOnParent));
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Output, Id, Name);
                Name = null;
            }
        }
        
        /// <summary>An area the input belongs to.</summary>
        public AreaConfiguration Area { get; set; }

        /// <summary>
        /// Get output name from repository
        /// </summary>
        /// <returns>Output Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Output, Id);
        }
    }
}
