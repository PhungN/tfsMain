﻿using Pacom.Configuration.ConfigurationCommon;
using System.Collections.Generic;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class GroupConfiguration : Group8003Configuration
    {
        public GroupConfiguration()
        {
        }

        public static void AutoConfigure(List<ConfigurationBase> configuration)
        {
            Group8003Configuration groupConfiguration = new Group8003Configuration();
            groupConfiguration.SetDefaults();
            groupConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            groupConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            groupConfiguration.Name = "All users";
            configuration.Add(groupConfiguration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        public void AutoConfigure()
        {
            InitializeWithDefaults();
            ConfigurationStringRepository.AddName(ConfigurationType.Group, Id, "All users");
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Group, Id, Name);
                Name = null;
            }
        }

        /// <summary>
        /// Get group name from repository
        /// </summary>
        /// <returns>The group Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Group, Id);
        }
    }
}
