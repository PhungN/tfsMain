﻿using Pacom.Configuration.ConfigurationCommon;
namespace Pacom.Peripheral.Common.Configuration
{
    public static class ConfigurationDefaults
    {
		/// <summary>
		/// The ADC reading below which the battery is considered to be disconnected or failed
        /// 6.0*10/(22+10)*1024/5 = 100 // 6V
        /// </summary>
        public const int NoBatteryMaxAdcLevelReading = 384;

		/// <summary>
		/// The ADC reading below which the AC Fail event is triggered 
        /// 3*10/(39+10)*1024/5 = 125 // Aproximately 3 volts
		/// </summary>
        public const int AcFailMaxAdcReading = 125;

        /// <summary>
        /// The default ADC reading for Charger Voltage read when charger is ON. 
        /// 12.6*10/(22+10)*1024/5 = 832 // 12.6 Volts
        /// </summary>
        public const int ChargerFailedCutOffAdcLevelReading = 807;

        // Maximum battery voltage value in Volt (V)
        public const double MaximumBatteryVoltage = 16.0;
        // Maximum supply input voltage in Volt (V)
        public const double MaximumInputVoltage = 24.0;
        // Maximum power supply temperature in °C
        public const double MaximumTemperature = 100.0;

        // Maximum 10bit ADC converter reading
        public const int MaximumAdcReading = 1024;

        /// <summary>
        /// Battery Voltage / AC Voltage reference resistor value
        /// </summary>
        public const int BatteryACVoltageResistorValue = 10000;
        
        /// <summary>
        /// Battery Voltage reference resistor value
        /// </summary>
        public const int BatteryVoltageResistorValue2 = 22000;

        /// <summary>
        /// AC Voltage reference resistor value
        /// </summary>
        public const int ACVoltageResistorValue = 39000;

        /// <summary>
        /// ADC converter reference voltage
        /// </summary>
        public const double PowerSupplyReferenceVoltage = 5.0;

        // Default value for alarm high state resistor in Ohms.
        public const int DefaultAlarmHighValue = 20000;

        // Default value for secure / normal state resistor in Ohms.
        public const int DefaultSecureValue = 10000;

        // Default value for masking state resistor in Ohms.
        public const int DefaultMaskingValue = 0;

        // Default value for range reduction state resistor in Ohms.
        public const int DefaultRangeReductionValue = 0;

        // Default value the end of line resistors tolerance value in percent between 0-100.
        public const InputTolerance DefaultTolerance = InputTolerance.TwentyFive;

        // Default number of consecutive readings required before an event is reported.
        public const int DefaultHitCount = 3;
    }
}
