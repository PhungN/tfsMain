﻿using System;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class ElevatorFloorUnlockScheduleList : ConfigurationListBase<ElevatorFloorUnlockSchedule>, IConfigurationList
    {
        internal ElevatorFloorUnlockScheduleList() : base() { }

        /// <summary>
        /// Get next schedule Id
        /// </summary>
        public int NextScheduleId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
