﻿using System;
using System.IO;
using System.Collections.Generic;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class MacroConfigurationList : ConfigurationListBase<MacroConfiguration>, IConfigurationList
    {
        internal MacroConfigurationList() : base() { }

        /// <summary>
        /// Get next macro Id
        /// </summary>
        public int NextMacroId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
