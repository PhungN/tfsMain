﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public static class ConfigurationFactory
    {
        public static void CreateDeviceConfigurationInstance(DeviceType deviceType, int physicalDeviceId)
        {
            List<ConfigurationBase> configuration = new List<ConfigurationBase>();

            switch (deviceType)
            {
                case DeviceType.Pacom8101:
                case DeviceType.Pacom8105:
                case DeviceType.Pacom1061:
                    Pacom8101KeypadConfiguration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom1064DC:
                    Pacom1064DCConfiguration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom1064IO:
                    Pacom1064IOConfiguration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom1076DC:
                    Pacom1076DCConfiguration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom1068:
                    Pacom1068Configuration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom1076IO:
                    Pacom1076IOConfiguration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom8303:
                    Pacom8303Configuration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom8308:
                    Pacom8308Configuration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom8501:
                    Pacom8501Configuration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom8501EC:
                    Pacom8501ECConfiguration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom8502:
                    Pacom8502Configuration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom8603:
                    Pacom8603Configuration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom1065IO:
                    Pacom1065IOConfiguration.AutoConfigure(physicalDeviceId, configuration);
                    break;
                case DeviceType.Pacom1076VC:
                    Pacom1076VCConfiguration.AutoConfigure(physicalDeviceId, configuration);
                    break;
            }
            if (configuration.Count > 0)
            {
                ConfigurationManager.Instance.DisableConfiguration(configuration);
                ConfigurationManager.Instance.UpdateConfiguration(configuration, false, ConfigurationManager.SystemUser, true);
            }
        }

        public static void CreateInovonicsDeviceConfigurationInstance(InovonicsDeviceType deviceType, int serialNumber)
        {
            List<ConfigurationBase> configuration = new List<ConfigurationBase>(); 
            
            switch (deviceType)
            {
                case InovonicsDeviceType.ES4000:
                    Inovonics8003ReceiverDeviceConfiguration.AutoConfigure(serialNumber, deviceType, configuration);
                    break;
                case InovonicsDeviceType.ES5000:
                    Inovonics8003RepeaterDeviceConfiguration.AutoConfigure(serialNumber, deviceType, configuration);
                    break;
                case InovonicsDeviceType.EN1210:
                case InovonicsDeviceType.EN1210EOL:
                case InovonicsDeviceType.EE1210SK:
                case InovonicsDeviceType.EE1215:
                case InovonicsDeviceType.EN1215EOL:
                case InovonicsDeviceType.EN1235DF:
                case InovonicsDeviceType.EN1235SF:
                case InovonicsDeviceType.ES1247:
                case InovonicsDeviceType.EN1249:
                case InovonicsDeviceType.EN1260:
                case InovonicsDeviceType.EE1261_EN1261HT:
                case InovonicsDeviceType.EN1262:
                case InovonicsDeviceType.ES1265:
                case InovonicsDeviceType.ES1242_ES1243:
                case InovonicsDeviceType.ES1223D:
                case InovonicsDeviceType.ES1223S:
                case InovonicsDeviceType.ES1223SK:
                case InovonicsDeviceType.ES1233D:
                case InovonicsDeviceType.ES1233S:
                case InovonicsDeviceType.ES1235D:
                case InovonicsDeviceType.ES1235S:
                case InovonicsDeviceType.EN1210W:
                case InovonicsDeviceType.EN1212:
                case InovonicsDeviceType.EE1215W:
                case InovonicsDeviceType.EN1215WEOL:
                case InovonicsDeviceType.ES1216:
                case InovonicsDeviceType.EN1252:
                case InovonicsDeviceType.EN1238D:
                case InovonicsDeviceType.ES1236D:
                case InovonicsDeviceType.EN1224:
                case InovonicsDeviceType.EN1224ON:
                case InovonicsDeviceType.EN1224OLD:
                case InovonicsDeviceType.EN1224ONOLD:
                    Inovonics8003SecurityDeviceConfiguration.AutoConfigure(serialNumber, deviceType, configuration);
                    break;
#if INOVONICSTEMPERATUREDEMO
                case InovonicsDeviceType.ES1721:
                case InovonicsDeviceType.ES1722:
                    Inovonics8003TemperatureDeviceConfiguration.AutoConfigure(serialNumber, deviceType, configuration);
                    break;
#endif
            }
            if (configuration.Count > 0)
                ConfigurationManager.Instance.UpdateConfiguration(configuration, false, ConfigurationManager.SystemUser, true);
        }
    }
}
