﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Peripheral.Common.Status;
using Pacom.Core.Contracts;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Serialization.Formatters.Asn1;
using System.Reflection;
using Pacom.Core.Access;
using Pacom.Configuration.ConfigurationCommon;
using System.Data.Common;
using System.Text;
using Pacom.Peripheral.Common.SQLCE;
using System.Threading;
using System.Data.SqlServerCe;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class UserConfigurationListSDCard : UserConfigurationList
    {
        private DbConnection connection = null;
        private DbCommand command = null;
        private StringBuilder sqlCommand = new StringBuilder();

        private Thread createUnisonIndexThread;

        private const string gmsUsersTableName = "GmsUsers";
        private const string gmsUserAccessTableName = "GmsUserAccess";
        private const string unisonUsersTableName = "UnisonUsers";
        private const string unisonUserAccessTableName = "UnisonUserAccess";

        private readonly object writeLock = new object();

        Dictionary<Type, PropertyInfo[]> reflectionDictionary = new Dictionary<Type, PropertyInfo[]>();

        internal UserConfigurationListSDCard()
        {
            connection = SqlCeDatabase.Instance.OpenDatabase();
            connection.Open();
            command = connection.CreateCommand();

            createTables();

            if (File.Exists(FileSystemPaths.UsersConfigFilePath))
            {
                StreamingContext context = new StreamingContext();
                ITypeLookup typesList = getListOfTypes();
                Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(typesList, true, context);
                List<ConfigurationBaseWithStreamOffsetAndLength> users = new List<ConfigurationBaseWithStreamOffsetAndLength>();

                // The user has added an SD card. Transfer the users to the DB and delete the file.
                lock (ConfigurationManager.ControllerConfigurationSync)
                {
                    using (FileStream fileStream = new FileStream(FileSystemPaths.UsersConfigFilePath, FileMode.Open))
                    {
                        while (fileStream.Position < fileStream.Length)
                        {
                            try
                            {
                                ConfigurationBase configurationItem = (ConfigurationBase)asn1Serializer.Deserialize(fileStream);
                                if (configurationItem == null || configurationItem.Id < 1)
                                    continue;

                                // ConfigurationManager.Instance.IsUnisonMode hasn't been initialised yet so don't check it here.
                                if (configurationItem is User || configurationItem is User8003Configuration)
                                {
                                    users.Add(new ConfigurationBaseWithStreamOffsetAndLength(){ Configuration = configurationItem });
                                }
                            }
                            catch (Exception ex)
                            {
                                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                                {
                                    return string.Format("Failed loading configuration item at position {0} from users.asn1 file. Handled exception : {1}",
                                        fileStream.Position, ex.ToString());
                                });
                            }
                        }
                    }
                }

                WriteOutConfigurationAndIndexFile(null, null, users.ToArray(), false);

                File.Delete(FileSystemPaths.UsersConfigFilePath);
                string indexFileName = FileSystemPaths.UsersConfigFilePath.Replace(".asn1", ".idx");
                if (File.Exists(indexFileName))
                    File.Delete(indexFileName);
            }
        }

        private void dropUnisonIndexes(SqlCeCommand writeCommand)
        {
            try
            {
                writeCommand.CommandText = "DROP INDEX UnisonUsers.ixUnisonLogicalId";
                writeCommand.ExecuteNonQuery();
            }
            catch
            {
            }
            try
            {
                writeCommand.CommandText = "DROP INDEX UnisonUsers.ixUnisonUsersId";
                writeCommand.ExecuteNonQuery();
            }
            catch
            {
            }
            try
            {
                writeCommand.CommandText = "DROP INDEX UnisonUsers.ixUnisonUsersPin";
                writeCommand.ExecuteNonQuery();
            }
            catch
            {
            }
            try
            {
                writeCommand.CommandText = "DROP INDEX UnisonUserAccess.ixUnisonUserAccess";
                writeCommand.ExecuteNonQuery();
            }
            catch
            {
            }
        }

        private static bool cancelIndexCreation;
        public static void CancelIndexCreation()
        {
            cancelIndexCreation = true;
        }

        private void createUnisonIndexes(SqlCeCommand writeCommand)
        {
            try
            {
                if (cancelIndexCreation)
                    return;
                writeCommand.CommandText = "CREATE NONCLUSTERED INDEX ixUnisonLogicalId ON UnisonUsers(LogicalId)";
                writeCommand.ExecuteNonQuery();
                if (cancelIndexCreation)
                    return;
                writeCommand.CommandText = "CREATE NONCLUSTERED INDEX ixUnisonUsersId ON UnisonUsers(UserId)";
                writeCommand.ExecuteNonQuery();
                if (cancelIndexCreation)
                    return;
                writeCommand.CommandText = "CREATE NONCLUSTERED INDEX ixUnisonUserAccess ON UnisonUserAccess(LogicalId)";
                writeCommand.ExecuteNonQuery();
                if (cancelIndexCreation)
                    return;
                writeCommand.CommandText = "CREATE NONCLUSTERED INDEX ixUnisonUsersPin ON UnisonUsers(UserPin)";
                writeCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Unable to create indexes: {0}", ex.ToString());
                });
            }
        }

        private void createUnisonIndexThreadMethod()
        {
            lock (writeLock)
            {
                using (SqlCeConnection writeConnection = new SqlCeConnection(SqlCeDatabase.Instance.DefaultConnectionString))
                {
                    writeConnection.Open();
                    using (SqlCeCommand writeCommand = writeConnection.CreateCommand())
                    {
                        createUnisonIndexes(writeCommand);
                    }
                    writeConnection.Close();
                }
                createUnisonIndexThread = null;
            }
        }

        private void startCreateUnisonIndexThread()
        {
            cancelIndexCreation = false;
            createUnisonIndexThread = new Thread(new ThreadStart(createUnisonIndexThreadMethod));
            createUnisonIndexThread.Name = "Create Unison Index Thread";
            createUnisonIndexThread.IsBackground = true;
            createUnisonIndexThread.Priority = ThreadPriority.Lowest;
            createUnisonIndexThread.Start();
        }

        /// <summary>
        /// Add columnName column if not exist
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="columnName"></param>
        private void addTableColumn(string tableName, string columnName, string dataType)
        {
            command.CommandText = string.Format(@"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='{0}' AND TABLE_NAME='{1}'", columnName, tableName);
            var columnExists = command.ExecuteScalar();
            if ((columnExists == null || columnExists.ToString() != columnName))
            {
                command.CommandText = string.Format("ALTER TABLE {0} ADD {1} {2}", tableName, columnName, dataType);
                command.ExecuteNonQuery();
            }
        }

        private void createTables()
        {
            if (connection.TableExists(gmsUsersTableName) == false)
            {
                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE TABLE GmsUsers(" +
                    "LogicalId INT PRIMARY KEY," +
                    "UserPin INT NOT NULL," +
                    "GroupId INT NOT NULL," +
                    "OutsideHoursAccess BIT NOT NULL DEFAULT 0," +
                    "UserManagementPrivilege BIT NOT NULL DEFAULT 0," +
                    "Name NVARCHAR(250)," +
                    "RevisionId INT NOT NULL," +
                    "ScheduleId INT NOT NULL DEFAULT 0," +
                    "AutoIsolateDeisolatePoints BIT NOT NULL DEFAULT 0)");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();

                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE NONCLUSTERED INDEX ixGmsUsers ON GmsUsers(UserPin)");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();
            }
            else
            {
                addTableColumn(gmsUsersTableName, "ScheduleId", "INT NOT NULL DEFAULT 0");
                addTableColumn(gmsUsersTableName, "AutoIsolateDeisolatePoints", "BIT NOT NULL DEFAULT 0");
            }

            if (connection.TableExists(gmsUserAccessTableName) == false)
            {
                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE TABLE GmsUserAccess(" +
                    "LogicalId INT NOT NULL," +
                    "AreaId INT NOT NULL," +
                    "CanIsolate BIT NOT NULL DEFAULT 0)");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();

                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE NONCLUSTERED INDEX ixGmsUserAccess ON GmsUserAccess(LogicalId)");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();
            }

            if (connection.TableExists(unisonUsersTableName) == false)
            {
                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE TABLE UnisonUsers(" +
                    "LogicalId INT NOT NULL," +
                    "UserId INT NOT NULL," +
                    "UserPin INT NOT NULL," +
                    "GroupId INT NOT NULL," +
                    "OutsideHoursAccess BIT NOT NULL DEFAULT 0," +
                    "UserManagementPrivilege BIT NOT NULL DEFAULT 0," +
                    "StoreInDegradedMemory BIT NOT NULL DEFAULT 0," +
                    "Name NVARCHAR(250)," +
                    "ValidFrom DATETIME NOT NULL," +
                    "ValidTo DATETIME NOT NULL," +
                    "RevisionId INT NOT NULL," +
                    "DelayAutomaticArming BIT NOT NULL DEFAULT 0," +
                    "ScheduleId INT NOT NULL DEFAULT 0," +
                    "AutoIsolateDeisolatePoints BIT NOT NULL DEFAULT 0)");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();

                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE NONCLUSTERED INDEX ixUnisonLogicalId ON UnisonUsers(LogicalId)");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();

                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE NONCLUSTERED INDEX ixUnisonUsersId ON UnisonUsers(UserId)");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();

                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE NONCLUSTERED INDEX ixUnisonUsersPin ON UnisonUsers(UserPin)");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();
            }
            else
            {
                // Add DelayAutomaticArming column if not exist
                addTableColumn(unisonUsersTableName, "DelayAutomaticArming", "BIT NOT NULL DEFAULT 0");

                // Add ScheduleId column if not exist
                addTableColumn(unisonUsersTableName, "ScheduleId", "INT NOT NULL DEFAULT 0");
                addTableColumn(unisonUsersTableName, "AutoIsolateDeisolatePoints", "BIT NOT NULL DEFAULT 0");
            }

            if (connection.TableExists(unisonUserAccessTableName) == false)
            {
                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE TABLE UnisonUserAccess(" +
                    "LogicalId INT NOT NULL," +
                    "AccessGroupId INT NOT NULL," +
                    "ValidFrom DATETIME," +
                    "ValidTo DATETIME)");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();

                sqlCommand.Length = 0;
                sqlCommand.Append(@"CREATE NONCLUSTERED INDEX ixUnisonUserAccess ON UnisonUserAccess(LogicalId)");
                command.Parameters.Clear();
                command.CommandText = sqlCommand.ToString();
                command.ExecuteNonQuery();
            }

            command.Parameters.Clear();
            command.CommandText = "SELECT COUNT(*) FROM Information_Schema.Indexes WHERE Table_Name = 'UnisonUsers' or Table_Name = 'UnisonUserAccess'";
            object count = command.ExecuteScalar();
            if (count == null || (int)count != 4)
            {
                SqlCeConnection writeConnection = new SqlCeConnection(SqlCeDatabase.Instance.DefaultConnectionString);
                writeConnection.Open();
                SqlCeCommand writeCommand = writeConnection.CreateCommand();
                cancelIndexCreation = false;
                dropUnisonIndexes(writeCommand);
                createUnisonIndexes(writeCommand);
                writeCommand.Dispose();
                writeConnection.Close();
                writeConnection.Dispose();
            }
        }

        public override void RemoveAll()
        {
            lock (connection)
            {
                command.Parameters.Clear();
                command.CommandText = string.Format(@"DROP TABLE {0}", gmsUsersTableName);
                command.ExecuteNonQuery();
                command.Parameters.Clear();
                command.CommandText = string.Format(@"DROP TABLE {0}", gmsUserAccessTableName);
                command.ExecuteNonQuery();
                command.Parameters.Clear();
                command.CommandText = string.Format(@"DROP TABLE {0}", unisonUsersTableName);
                command.ExecuteNonQuery();
                command.Parameters.Clear();
                command.CommandText = string.Format(@"DROP TABLE {0}", unisonUserAccessTableName);
                command.ExecuteNonQuery();

                createTables();
            }
        }

        /// <summary>
        /// Delete user configuration from user configuration list.
        /// </summary>
        /// <param name="userIds">Ids of the user configuration to remove.</param>
        /// <param name="userAuditInfo">User audit details: user type, user Id.</param>
        /// <returns>True if the user configuration was successfully removed.</returns>
        public override bool Delete(int[] logicalIds, UserAuditInfo userAuditInfo)
        {
            try
            {
                ConfigurationManager.Instance.CallConfigurationChangingEvent(ConfigurationElementsAffected.Users);

                bool isUnisonMode = ConfigurationManager.Instance.IsUnisonMode;

                if (isUnisonMode && (logicalIds.Length > 1))
                    CancelIndexCreation();
                
                lock (writeLock)
                {
                    SqlCeConnection writeConnection = new SqlCeConnection(SqlCeDatabase.Instance.DefaultConnectionString);
                    writeConnection.Open();

                    SqlCeCommand writeCommand = writeConnection.CreateCommand();

                    if (logicalIds.Length == 1)
                    {
                        writeCommand.CommandText = string.Format("DELETE FROM {0} WHERE LogicalId = {1}",
                            isUnisonMode ? unisonUsersTableName : gmsUsersTableName, logicalIds[0]);
                        if (writeCommand.ExecuteNonQuery() > 0)
                        {
                            writeCommand.CommandText = string.Format("DELETE FROM {0} WHERE LogicalId = {1}",
                                isUnisonMode ? unisonUserAccessTableName : gmsUserAccessTableName, logicalIds[0]);
                            writeCommand.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        if (isUnisonMode)
                            dropUnisonIndexes(writeCommand);

                        bool anyFound = false;
                        writeCommand.CommandText = string.Format("SELECT LogicalId FROM {0}", isUnisonMode ? unisonUsersTableName : gmsUsersTableName);
                        SqlCeResultSet resultSet = writeCommand.ExecuteResultSet(ResultSetOptions.Updatable);
                        while (resultSet.Read())
                        {
                            if (logicalIds.Contains(resultSet.GetInt32(0)))
                            {
                                resultSet.Delete();
                                anyFound = true;
                            }
                        }
                        resultSet.Dispose();
                        if (anyFound)
                        {
                            writeCommand.CommandText = string.Format("SELECT LogicalId FROM {0}", isUnisonMode ? unisonUserAccessTableName : gmsUserAccessTableName);
                            resultSet = writeCommand.ExecuteResultSet(ResultSetOptions.Updatable);
                            while (resultSet.Read())
                            {
                                if (logicalIds.Contains(resultSet.GetInt32(0)))
                                {
                                    resultSet.Delete();
                                }
                            }
                            resultSet.Dispose();
                        }

                        if (isUnisonMode)
                            startCreateUnisonIndexThread();

                        writeCommand.Dispose();
                        writeConnection.Close();
                        writeConnection.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Unable to delete user configuration: {0}", ex.ToString());
                });
                return false;
            }
            finally
            {
                ConfigurationManager.Instance.CallConfigurationChangedEvent(ConfigurationElementsAffected.Users, new List<ConfigurationChanges>(), new List<ConfigurationChanges>(), new List<ConfigurationChanges>());
            }
            return true;
        }

        // Check that there is at least 1 engineer and 1 non engineer with areas assigned
        public override bool EngineerIsPresent(List<int> keypadAreas)
        {
            if (ConfigurationManager.Instance.IsUnisonMode == false)
            {
                GroupConfiguration[] groups = ConfigurationManager.Instance.Groups.ToArray();
                StringBuilder engineerGroups = new StringBuilder();
                bool nonengineerGroupFound = false;
                foreach (GroupConfiguration group in groups)
                {
                    if (group.IsEngineer)
                    {
                        if (engineerGroups.Length == 0)
                            engineerGroups.Append("(");
                        else
                            engineerGroups.Append(",");
                        engineerGroups.Append(group.Id);
                    }
                    else
                    {
                        nonengineerGroupFound = true;
                    }
                }
                if (engineerGroups.Length == 0 || nonengineerGroupFound == false)
                    return false;

                lock (connection)
                {
                    sqlCommand.Length = 0;
                    sqlCommand.Append(@"SELECT DISTINCT ");
                    sqlCommand.Append(gmsUserAccessTableName);
                    sqlCommand.Append(".AreaId FROM ");
                    sqlCommand.Append(gmsUserAccessTableName);
                    sqlCommand.Append(" JOIN ");
                    sqlCommand.Append(gmsUsersTableName);
                    sqlCommand.Append(" ON ");
                    sqlCommand.Append(gmsUserAccessTableName);
                    sqlCommand.Append(".LogicalId = ");
                    sqlCommand.Append(gmsUsersTableName);
                    sqlCommand.Append(".LogicalId WHERE ");
                    sqlCommand.Append(gmsUsersTableName);
                    sqlCommand.Append(".GroupId IN ");
                    sqlCommand.Append(engineerGroups.ToString());
                    sqlCommand.Append(")");

                    command.Parameters.Clear();
                    command.CommandText = sqlCommand.ToString();
                    List<int> engineerAreas = new List<int>();
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read() == true)
                        {
                            engineerAreas.Add(reader.GetInt32(0));
                        }
                    }

                    for (int i = 0; i < engineerAreas.Count; i++)
                    {
                        if (keypadAreas.Contains(engineerAreas[i]) == false)
                        {
                            engineerAreas.RemoveAt(i);
                            i--;
                        }
                    }

                    if (engineerAreas.Count == 0)
                        return false;

                    StringBuilder engineerAreasAsString = new StringBuilder();
                    foreach (int areaId in engineerAreas)
                    {
                        if (engineerAreasAsString.Length == 0)
                            engineerAreasAsString.Append("(");
                        else
                            engineerAreasAsString.Append(",");
                        engineerAreasAsString.Append(areaId);
                    }

                    sqlCommand.Length = 0;
                    sqlCommand.Append(@"SELECT TOP(1) 1 FROM ");
                    sqlCommand.Append(gmsUsersTableName);
                    sqlCommand.Append(" WHERE GroupId NOT IN ");
                    sqlCommand.Append(engineerGroups.ToString());
                    sqlCommand.Append(") AND LogicalId IN (SELECT DISTINCT LogicalId FROM ");
                    sqlCommand.Append(gmsUserAccessTableName);
                    sqlCommand.Append(" WHERE AreaId IN ");
                    sqlCommand.Append(engineerAreasAsString.ToString());
                    sqlCommand.Append("))");
                    command.Parameters.Clear();
                    command.CommandText = sqlCommand.ToString();

                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read() == true)
                            return true;
                    }
                }
            }
            return false;
        }

        private IUserConfiguration getUser(int id, UserIdentifier userIdentifier)
        {
            lock (connection)
            {
                command.Parameters.Clear();
                command.AddParameterWithValue("Id", id);

                if (ConfigurationManager.Instance.IsUnisonMode == false)
                {
                    UserConfiguration user = null;
                    if (userIdentifier == UserIdentifier.UserPin)
                        command.CommandText = "SELECT TOP(1) * FROM GmsUsers WHERE UserPin = @Id";
                    else
                        command.CommandText = "SELECT * FROM GmsUsers WHERE LogicalId = @Id";
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read() == true)
                        {
                            user = new UserConfiguration();
                            user.Id = reader.GetInt32(0);
                            user.UserPin = reader.GetInt32(1);
                            user.GroupId = reader.GetInt32(2);
                            user.OutsideHoursAccess = reader.GetBoolean(3);
                            user.UserManagementPrivilege = reader.GetBoolean(4);
                            user.Name = reader.GetString(5);
                            user.RevisionId = reader.GetInt32(6);
                            user.ScheduleId = reader.GetInt32(7);
                            user.AutoIsolateDeisolatePoints = reader.GetBoolean(8);
                        }
                    }
                    if (user != null)
                    {
                        Dictionary<int, AreaAccessPrivilege> areaPrivileges = new Dictionary<int, AreaAccessPrivilege>();
                        command.Parameters.Clear();
                        command.AddParameterWithValue("LogicalId", user.Id);
                        command.CommandText = "SELECT * FROM GmsUserAccess WHERE LogicalId = @LogicalId ORDER BY AreaId";
                        using (DbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read() == true)
                            {
                                areaPrivileges[reader.GetInt32(1)] = new AreaAccessPrivilege() { CanIsolate = reader.GetBoolean(2) };
                            }
                        }

                        user.AreaIds = new int[areaPrivileges.Count];
                        int i = 0;
                        foreach (int key in areaPrivileges.Keys)
                        {
                            user.AreaIds[i] = key;
                            i++;
                        }

                        user.AreaAccessPrivilege = new AreaAccessPrivilege[areaPrivileges.Count];
                        i = 0;
                        foreach (AreaAccessPrivilege value in areaPrivileges.Values)
                        {
                            user.AreaAccessPrivilege[i] = value;
                            i++;
                        }
                        user.InitializeAfterCopy();
                        return user;
                    }
                }
                else
                {
                    User user = null;
                    if (userIdentifier == UserIdentifier.UserPin)
                        command.CommandText = "SELECT TOP(1) * FROM UnisonUsers WHERE UserPin = @Id";
                    else if (userIdentifier == UserIdentifier.LogicalId)
                        command.CommandText = "SELECT * FROM UnisonUsers WHERE LogicalId = @Id";
                    else
                        command.CommandText = "SELECT TOP(1) * FROM UnisonUsers WHERE UserId = @Id";
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read() == true)
                        {
                            user = new User();
                            user.Id = reader.GetInt32(0);
                            user.AlarmUserId = reader.GetInt32(1);
                            user.UserPin = reader.GetInt32(2);
                            user.GroupId = reader.GetInt32(3);
                            user.UserFlags = UserFlags.None;
                            if (reader.GetBoolean(4))
                                user.UserFlags |= UserFlags.AfterHoursAccess;
                            if (reader.GetBoolean(5))
                                user.UserFlags |= UserFlags.UserManagementPriviliges;
                            if (reader.GetBoolean(6))
                                user.UserFlags |= UserFlags.StoreInDegradedMemory;
                            user.Name = reader.GetString(7);
                            user.ValidFrom = reader.GetDateTime(8);
                            user.ValidTo = reader.GetDateTime(9);
                            user.RevisionId = reader.GetInt32(10);
                            if (reader.GetBoolean(11))
                                user.UserFlags |= UserFlags.DelayAutomaticArming;
                            user.ScheduleId = reader.GetInt32(12);
                            if (reader.GetBoolean(13))
                                user.UserFlags |= UserFlags.AutoIsolateDeisolatePoints;
                        }
                    }
                    if (user != null)
                    {
                        List<UserAccess> areaPrivileges = new List<UserAccess>();
                        command.Parameters.Clear();
                        command.AddParameterWithValue("LogicalId", user.Id);
                        command.CommandText = "SELECT * FROM UnisonUserAccess WHERE LogicalId = @LogicalId";
                        using (DbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read() == true)
                            {
                                areaPrivileges.Add(new UserAccess()
                                {
                                    AccessGroupId = reader.GetInt32(1),
                                    StartDateTime = reader.GetDateTime(2),
                                    EndDateTime = reader.GetDateTime(3)
                                });
                            }
                        }

                        user.AccessGroups = areaPrivileges.ToArray();

                        UserUnisonConfiguration userUnisonConfiguration = new UserUnisonConfiguration();
                        ConfigurationManager.CopyConfiguration(reflectionDictionary, user, userUnisonConfiguration);
                        return userUnisonConfiguration;
                    }
                }
                return null;
            }
        }

        /// <summary>
        /// Return configuration object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Logical node id, 1 based</param>
        /// <returns>Node configuration instance or null if not found</returns>
        public override IUserConfiguration this[int logicalId]
        {
            get
            {
                return getUser(logicalId, UserIdentifier.LogicalId);
            }
        }

        public override bool Exists(int logicalId)
        {
            lock (connection)
            {
                command.Parameters.Clear();
                command.AddParameterWithValue("LogicalId", logicalId);
                if (ConfigurationManager.Instance.IsUnisonMode == false)
                {
                    command.CommandText = "SELECT TOP(1) 1 FROM GmsUsers WHERE LogicalId = @LogicalId";
                    object cardExists = command.ExecuteScalar();
                    return cardExists != null && (int)cardExists == 1;
                }
                else
                {
                    command.CommandText = "SELECT TOP(1) 1 FROM UnisonUsers WHERE LogicalId = @LogicalId";
                    object cardExists = command.ExecuteScalar();
                    return cardExists != null && (int)cardExists == 1;
                }
            }
        }

        public override int Count
        {
            get
            {
                lock (connection)
                {
                    string userTableName;
                    if (ConfigurationManager.Instance.IsUnisonMode == false)
                        userTableName = gmsUsersTableName;
                    else
                        userTableName = unisonUsersTableName;

                    command.Parameters.Clear();
                    command.CommandText = string.Format(@"SELECT CARDINALITY FROM INFORMATION_SCHEMA.INDEXES WHERE TABLE_NAME = N'{0}'", userTableName);
                    object count = command.ExecuteScalar();
                    if (count == null)
                        return 0;
                    else
                        return (int)(Int64)count;
                }
            }
        }

        /// <summary>
        /// Check if the User Id / Pin provided match any of the stored users.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="userPin">User Pin</param>
        /// <param name="logicalUserId">The logical id of the user (Same for EMCS, different for Unison)</param>
        /// <param name="duress">True if this was duress pin and the User Id was valid</param>
        /// <returns>True if User found, False otherwise</returns>
        public override bool CanUserLogin(int userId, int userPin, UserAccessLevel currentAccessLevel, out int logicalUserId, out bool duress)
        {
            return canUserLogin(getUser(userId, UserIdentifier.UserId), userPin, currentAccessLevel, out logicalUserId, out duress);
        }

        /// <summary>
        /// Check if the Pin provided matches any of the stored users.
        /// </summary>
        /// <param name="userPin">User Pin</param>
        /// <param name="duress">True if this was duress pin and the User Id was valid</param>
        /// <returns>True if User found, False otherwise</returns>
        public override bool CanUserLogin(int userPin, UserAccessLevel currentAccessLevel, out int logicalUserId, out bool duress)
        {
            if (canUserLogin(getUser(userPin, UserIdentifier.UserPin), userPin, currentAccessLevel, out logicalUserId, out duress))
                return true;

            int[] possiblePins = userPin.GetValidPins(ConfigurationManager.Instance.ControllerConfiguration.DuressType);
            foreach (int possiblePin in possiblePins)
            {
                if (canUserLogin(getUser(possiblePin, UserIdentifier.UserPin), userPin, currentAccessLevel, out logicalUserId, out duress))
                {
                    duress = true;
                    return true;
                }
            }
            return false;
        }

        private bool canUserLogin(IUserConfiguration user, int userPin, UserAccessLevel currentAccessLevel, out int logicalUserId, out bool duress)
        {
            duress = false;
            logicalUserId = 0;
            if (user != null)
            {
                logicalUserId = user.Id;
                if (user.UserPin == userPin)
                {
                    bool accessLevelValid = isAccessLevelValid(currentAccessLevel, user.GroupId);
                    if (user.UserMode == ControllerMode.GmsEmcs || accessLevelValid == false)
                        return accessLevelValid;
                    // Extra checks required for Unison Mode of operation
                    return ((UserUnisonConfiguration)user).HasAccessPermission();
                }
                duress = user.UserPin.CheckDuressPin(userPin, ConfigurationManager.Instance.ControllerConfiguration.DuressType);
                if (duress == true)
                    return isAccessLevelValid(currentAccessLevel, user.GroupId);
            }
            return false;
        }

        /// <summary>
        /// Check if there are more than 1 users with the same PIN
        /// </summary>
        /// <param name="userPin"></param>
        /// <returns></returns>
        public override bool DoMultipleUsersHaveTheSamePin(int userPin)
        {
            string userTableName;
            if (ConfigurationManager.Instance.IsUnisonMode == false)
                userTableName = gmsUsersTableName;
            else
                userTableName = unisonUsersTableName;

            int totalCount = 0;

            lock (connection)
            {
                command.Parameters.Clear();
                command.AddParameterWithValue("UserPin", userPin);
                command.CommandText = string.Format(@"SELECT COUNT(*) FROM {0} WHERE UserPin = @UserPin", userTableName);
                object count = command.ExecuteScalar();
                if (count != null)
                    totalCount += (int)count;

                int[] possiblePins = userPin.GetValidPins(ConfigurationManager.Instance.ControllerConfiguration.DuressType);
                foreach (int possiblePin in possiblePins)
                {
                    command.Parameters.Clear();
                    command.AddParameterWithValue("UserPin", possiblePin);
                    count = command.ExecuteScalar();
                    if (count != null)
                        totalCount += (int)count;
                }
            }

            if (totalCount > 1)
                return true;
            return false;
        }

        public override void WriteOutConfigurationAndIndexFile(string outputFilePath, string inputFilePath, ConfigurationBaseWithStreamOffsetAndLength[] configuration, bool update)
        {
            if (update == false)
                RemoveAll();

            bool isUnisonMode = isUnisonConfiguration(configuration);
            bool recreateIndex = isUnisonMode && (configuration.Length > 1);

            if (recreateIndex)
                CancelIndexCreation();

            List<int> updatedUsers = new List<int>();
            lock (writeLock)
            {
                SqlCeConnection writeConnection = new SqlCeConnection(SqlCeDatabase.Instance.DefaultConnectionString);
                writeConnection.Open();
                SqlCeCommand writeCommand = writeConnection.CreateCommand();
                SqlCeResultSet resultSet;

                if (recreateIndex)
                    dropUnisonIndexes(writeCommand);

                if (update == true)
                {
                    int lowestLogicalId = int.MaxValue;
                    int highestLogicalId = int.MinValue;
                    for (int i = 0; i < configuration.Length; i++)
                    {
                        if (configuration[i].Configuration.Id < lowestLogicalId)
                            lowestLogicalId = configuration[i].Configuration.Id;
                        if (configuration[i].Configuration.Id > highestLogicalId)
                            highestLogicalId = configuration[i].Configuration.Id;
                    }

                    writeCommand.CommandText = string.Format("SELECT * FROM {0} WHERE LogicalId >= {1} AND LogicalId <= {2}", isUnisonMode ? unisonUsersTableName : gmsUsersTableName, lowestLogicalId, highestLogicalId);
                    resultSet = writeCommand.ExecuteResultSet(ResultSetOptions.Updatable);
                    while (resultSet.Read())
                    {
                        int resultSetId = resultSet.GetInt32(0);
                        for (int i = 0; i < configuration.Length; i++)
                        {
                            if (resultSetId == configuration[i].Configuration.Id)
                            {
                                updatedUsers.Add(resultSetId);

                                if (isUnisonMode)
                                {
                                    User user = (User)configuration[i].Configuration;
                                                                                          
                                    resultSet.SetInt32(1, user.AlarmUserId);
                                    resultSet.SetInt32(2, user.UserPin);
                                    resultSet.SetInt32(3, user.GroupId);
                                    resultSet.SetBoolean(4, user.UserFlags.Has(UserFlags.AfterHoursAccess));
                                    resultSet.SetBoolean(5, user.UserFlags.Has(UserFlags.UserManagementPriviliges));
                                    resultSet.SetBoolean(6, user.UserFlags.Has(UserFlags.StoreInDegradedMemory));
                                    if (user.Name.Length > 250)
                                        resultSet.SetString(7, user.Name.Substring(0, 250));
                                    else
                                        resultSet.SetString(7, user.Name);
                                    resultSet.SetDateTime(8, user.ValidFrom);
                                    resultSet.SetDateTime(9, user.ValidTo);
                                    resultSet.SetInt32(10, (int)user.RevisionId);
                                    resultSet.SetBoolean(11, user.UserFlags.Has(UserFlags.DelayAutomaticArming));
                                    resultSet.SetInt32(12, user.ScheduleId);
                                    resultSet.SetBoolean(13, user.UserFlags.Has(UserFlags.AutoIsolateDeisolatePoints));
                                }
                                else
                                {
                                    User8003Configuration user = (User8003Configuration)configuration[i].Configuration;

                                    resultSet.SetInt32(1, user.UserPin);
                                    resultSet.SetInt32(2, user.GroupId);
                                    resultSet.SetBoolean(3, user.OutsideHoursAccess);
                                    resultSet.SetBoolean(4, user.UserManagementPrivilege);
                                    if (user.Name.Length > 250)
                                        resultSet.SetString(5, user.Name.Substring(0, 250));
                                    else
                                        resultSet.SetString(5, user.Name);
                                    resultSet.SetInt32(6, (int)user.RevisionId);
                                    resultSet.SetInt32(7, user.ScheduleId);
                                    resultSet.SetBoolean(8, user.AutoIsolateDeisolatePoints);
                                }
                                resultSet.Update();
                                break;
                            }
                        }
                    }
                    resultSet.Dispose();

                    if (updatedUsers.Count > 0)
                    {
                        // Delete the access for the updated user as the number of entries may have changed
                        writeCommand.CommandText = string.Format("SELECT * FROM {0}", isUnisonMode ? unisonUserAccessTableName : gmsUserAccessTableName);
                        resultSet = writeCommand.ExecuteResultSet(ResultSetOptions.Updatable);
                        while (resultSet.Read())
                        {
                            int resultSetId = resultSet.GetInt32(0);
                            for (int i = 0; i < updatedUsers.Count; i++)
                            {
                                if (resultSetId == updatedUsers[i])
                                {
                                    resultSet.Delete();
                                    break;
                                }
                            }
                        }
                        resultSet.Dispose();
                    }
                }

                // Even if all transactions are updates, we still need to write the access table entries we proceed
                SqlCeCommand accessWriteCommand = writeConnection.CreateCommand();

                writeCommand.CommandText = string.Format("SELECT * FROM {0}", isUnisonMode ? unisonUsersTableName : gmsUsersTableName);
                resultSet = writeCommand.ExecuteResultSet(ResultSetOptions.Updatable);
                accessWriteCommand.CommandText = string.Format("SELECT * FROM {0}", isUnisonMode ? unisonUserAccessTableName : gmsUserAccessTableName);
                SqlCeResultSet accessResultSet = accessWriteCommand.ExecuteResultSet(ResultSetOptions.Updatable);

                SqlCeUpdatableRecord userRecord = resultSet.CreateRecord();
                SqlCeUpdatableRecord userAccessRecord = accessResultSet.CreateRecord();

                if (isUnisonMode == true)
                {
                    for (int i = 0; i < configuration.Length; i++)
                    {
                        User user = (User)configuration[i].Configuration;
                        if (updatedUsers.Contains(user.Id) == false)
                        {
                            userRecord.SetInt32(0, user.Id);
                            userRecord.SetInt32(1, user.AlarmUserId);
                            userRecord.SetInt32(2, user.UserPin);
                            userRecord.SetInt32(3, user.GroupId);
                            userRecord.SetBoolean(4, user.UserFlags.Has(UserFlags.AfterHoursAccess));
                            userRecord.SetBoolean(5, user.UserFlags.Has(UserFlags.UserManagementPriviliges));
                            userRecord.SetBoolean(6, user.UserFlags.Has(UserFlags.StoreInDegradedMemory));
                            if (user.Name.Length > 250)
                                userRecord.SetString(7, user.Name.Substring(0, 250));
                            else
                                userRecord.SetString(7, user.Name);
                            userRecord.SetDateTime(8, user.ValidFrom);
                            userRecord.SetDateTime(9, user.ValidTo);
                            userRecord.SetInt32(10, (int)user.RevisionId);
                            userRecord.SetBoolean(11, user.UserFlags.Has(UserFlags.DelayAutomaticArming));
                            userRecord.SetInt32(12, user.ScheduleId);
                            userRecord.SetBoolean(13, user.UserFlags.Has(UserFlags.AutoIsolateDeisolatePoints));
                            resultSet.Insert(userRecord);
                        }

                        foreach (UserAccess userAccess in user.AccessGroups)
                        {
                            userAccessRecord.SetInt32(0, user.Id);
                            userAccessRecord.SetInt32(1, userAccess.AccessGroupId);
                            if (userAccess.StartDateTime.HasValue)
                                userAccessRecord.SetDateTime(2, userAccess.StartDateTime.Value);
                            else
                                userAccessRecord.SetValue(2, null);
                            if (userAccess.EndDateTime.HasValue)
                                userAccessRecord.SetDateTime(3, userAccess.EndDateTime.Value);
                            else
                                userAccessRecord.SetValue(3, null);
                            accessResultSet.Insert(userAccessRecord);
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < configuration.Length; i++)
                    {
                        User8003Configuration user = (User8003Configuration)configuration[i].Configuration;
                        if (updatedUsers.Contains(user.Id) == false)
                        {
                            userRecord.SetInt32(0, user.Id);
                            userRecord.SetInt32(1, user.UserPin);
                            userRecord.SetInt32(2, user.GroupId);
                            userRecord.SetBoolean(3, user.OutsideHoursAccess);
                            userRecord.SetBoolean(4, user.UserManagementPrivilege);
                            if (user.Name.Length > 250)
                                userRecord.SetString(5, user.Name.Substring(0, 250));
                            else
                                userRecord.SetString(5, user.Name);
                            userRecord.SetInt32(6, (int)user.RevisionId);
                            userRecord.SetInt32(7, user.ScheduleId);
                            userRecord.SetBoolean(8, user.AutoIsolateDeisolatePoints);
                            resultSet.Insert(userRecord);
                        }

                        for (int areaIndex = 0; areaIndex < user.AreaIds.Length; areaIndex++)
                        {
                            userAccessRecord.SetInt32(0, user.Id);
                            userAccessRecord.SetInt32(1, user.AreaIds[areaIndex]);
                            userAccessRecord.SetBoolean(2, user.AreaAccessPrivilege[areaIndex].CanIsolate);
                            accessResultSet.Insert(userAccessRecord);
                        }
                    }
                }

                resultSet.Dispose();
                accessResultSet.Dispose();

                if (recreateIndex && cancelIndexCreation == false)
                    startCreateUnisonIndexThread();

                writeCommand.Dispose();
                accessWriteCommand.Dispose();

                writeConnection.Close();
                writeConnection.Dispose();
            }
        }

        public override int GetLowestId()
        {
            lock (connection)
            {
                command.Parameters.Clear();
                if (ConfigurationManager.Instance.IsUnisonMode == false)
                    command.CommandText = "SELECT MIN(LogicalId) FROM GmsUsers";
                else
                    command.CommandText = "SELECT MIN(LogicalId) FROM UnisonUsers";
                object logicalId = command.ExecuteScalar();
                if ((logicalId != null) && (logicalId is DBNull == false))
                    return (int)logicalId;
            }
            return 0;
        }

        private int getHighestId()
        {
            lock (connection)
            {
                command.Parameters.Clear();
                if (ConfigurationManager.Instance.IsUnisonMode == false)
                    command.CommandText = "SELECT MAX(LogicalId) FROM GmsUsers";
                else
                    command.CommandText = "SELECT MAX(LogicalId) FROM UnisonUsers";
                object logicalId = command.ExecuteScalar();
                if ((logicalId != null) && (logicalId is DBNull == false))
                    return (int)logicalId;
            }
            return 0;
        }

        public override int GetNextId(int currentId)
        {
            lock (connection)
            {
                command.Parameters.Clear();
                command.AddParameterWithValue("CurrentId", currentId);
                if (ConfigurationManager.Instance.IsUnisonMode == false)
                    command.CommandText = "SELECT MIN(LogicalId) FROM GmsUsers WHERE LogicalId > @CurrentId";
                else
                    command.CommandText = "SELECT MIN(LogicalId) FROM UnisonUsers WHERE LogicalId > @CurrentId";
                object logicalId = command.ExecuteScalar();
                if ((logicalId != null) && (logicalId is DBNull == false))
                    return (int)logicalId;
            }
            return GetLowestId();
        }

        public override int GetPreviousId(int currentId)
        {
            lock (connection)
            {
                command.Parameters.Clear();
                command.AddParameterWithValue("CurrentId", currentId);
                if (ConfigurationManager.Instance.IsUnisonMode == false)
                    command.CommandText = "SELECT MAX(LogicalId) FROM GmsUsers WHERE LogicalId < @CurrentId";
                else
                    command.CommandText = "SELECT MAX(LogicalId) FROM UnisonUsers WHERE LogicalId < @CurrentId";
                object logicalId = command.ExecuteScalar();
                if ((logicalId != null) && (logicalId is DBNull == false))
                    return (int)logicalId;
            }
            return getHighestId();
        }

        public void WriteOutAllUsersToStream(FileStream fileStream)
        {
#if !DEBUG
            if (ConfigurationManager.Instance.IsUnisonMode)
                return;
#else
            int count = 0;
#endif

            int currentId = GetLowestId();
            int nextId;

            if (currentId > 0)
            {
                StreamingContext context = new StreamingContext();
                ITypeLookup typesList = getListOfTypes();
                Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(typesList, true, context);
                asn1Serializer.SerializeDefaultValues = true;

                while (true)
                {
                    IUserConfiguration user = this[currentId];

                    UserConfiguration gmsUser = user as UserConfiguration;
                    if (gmsUser != null)
                    {
                        User8003Configuration user8003Configuration = new User8003Configuration();
                        ConfigurationManager.CopyConfiguration(reflectionDictionary, gmsUser, user8003Configuration);
                        asn1Serializer.Serialize(fileStream, user8003Configuration);
                    }
                    else
                    {
                        User unisonUser = new User();
                        ConfigurationManager.CopyConfiguration(reflectionDictionary, (UserUnisonConfiguration)user, unisonUser);
                        asn1Serializer.Serialize(fileStream, unisonUser);
                    }

                    nextId = GetNextId(currentId);
                    if (nextId > currentId)
                        currentId = nextId;
                    else
                        break;

#if DEBUG
                    if (count == 100)
                        break;
                    count++;
#endif
                    Thread.Sleep(0);        // Give other threads some time as this could be a long process.
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userIdentifier">LogicalId or UserId</param>
        /// <returns></returns>
        public override IUserConfiguration GetUserConfiguration(int id, UserIdentifier userIdentifier)
        {
            return getUser(id, userIdentifier);
        }
    }
}
