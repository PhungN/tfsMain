﻿namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class VaultControllerInterlockGroupConfigurationList : ConfigurationListBase<VaultControllerInterlockGroupConfiguration>, IConfigurationList
    {
        internal VaultControllerInterlockGroupConfigurationList() : base() { }

        /// <summary>
        /// Get next interlock group Id
        /// </summary>
        public int NextInterlockGroupId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
