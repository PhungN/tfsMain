﻿using System;
using Pacom.Core.Contracts;
using System.Collections.Generic;
using Pacom.Core.Access;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public partial class ConfigurationManager
    {
        private class ControllerConnectionTableList : IConfigurationList, IDisposable
        {
            SortedList<int, ControllerConnectionTable> tableList = new SortedList<int, ControllerConnectionTable>();

            public ControllerConnectionTableList()
            {
                CommitChanges = false;
            }

            public ConfigurationBase GetItem(int logicalId)
            {
                ControllerConnectionTable table = ConfigurationManager.Instance.controllerConnectionTables[logicalId - 1];
                if (table != null)
                    tableList[logicalId] = table;
                return table;
            }

            public void SetItem(int logicalId, IConfiguration item)
            {
                ControllerConnectionTable table = item as ControllerConnectionTable;
                if (table != null)
                    tableList[logicalId] = table;
            }

            public bool CommitChanges
            {
                get;
                set;
            }

            public void Dispose()
            {
                // While multiple connection tables may be stored, only 2 are actually used.
                // The entry with the lowest id uses System1 and System2 alarm queues.
                // The entry with the second lowest id uses System3 and System4 alarm queues.
                // Subsequent entries are ignored.
                if (CommitChanges)
                {
                    ControllerConnectionTable table1;
                    if (tableList.TryGetValue(1, out table1))
                    {
                        table1.PrimaryAlarmQueue = FrontEndSystem.System1;
                        table1.DisasterAlarmQueue = FrontEndSystem.System2;
                        ConfigurationManager.Instance.controllerConnectionTables[0] = table1;
                    }
                    else
                    {
                        ConfigurationManager.Instance.controllerConnectionTables[0] = null;
                    }

                    ControllerConnectionTable table2;
                    if (tableList.TryGetValue(2, out table2))
                    {
                        if (table1 == null)
                        {
                            table2.PrimaryAlarmQueue = FrontEndSystem.System1;
                            table2.DisasterAlarmQueue = FrontEndSystem.System2;
                        }
                        else
                        {
                            table2.PrimaryAlarmQueue = FrontEndSystem.System3;
                            table2.DisasterAlarmQueue = FrontEndSystem.System4;
                        }
                        ConfigurationManager.Instance.controllerConnectionTables[1] = table2;
                    }
                    else
                    {
                        ConfigurationManager.Instance.controllerConnectionTables[1] = null;
                    }
                }
            }

            public List<int> AsKeyList
            {
                get
                {
                    List<int> keys = new List<int>(2);
                    ControllerConnectionTable connectionTable1 = ConfigurationManager.Instance.controllerConnectionTables[0];
                    ControllerConnectionTable connectionTable2 = ConfigurationManager.Instance.controllerConnectionTables[1];
                    if (connectionTable1 != null)
                        keys.Add(connectionTable1.Id);
                    if (connectionTable2 != null)
                        keys.Add(connectionTable2.Id);
                    return keys;
                }
            }
        }

        private class ControllerConfigurationWrapper : IConfigurationList
        {
            public ControllerConfigurationWrapper()
            {
            }

            public ConfigurationBase GetItem(int logicalId)
            {
                return ConfigurationManager.Instance.ControllerConfiguration;
            }

            public void SetItem(int logicalId, IConfiguration item)
            {
                Pacom8003Configuration controllerConfiguration = item as Pacom8003Configuration;
                if (controllerConfiguration != null)
                    ConfigurationManager.Instance.controllerConfiguration = controllerConfiguration;
            }

            public List<int> AsKeyList
            {
                get
                {
                    List<int> keys = new List<int>(1);
                    Pacom8003Configuration controllerConfiguration = ConfigurationManager.Instance.ControllerConfiguration;
                    if (controllerConfiguration != null)
                        keys.Add(controllerConfiguration.Id);
                    return keys;
                }
            }
        }

        private class CalendarWrapper : IConfigurationList
        {
            public CalendarWrapper()
            {
            }

            public ConfigurationBase GetItem(int logicalId)
            {
                return ConfigurationManager.Instance.Calendar;
            }

            public void SetItem(int logicalId, IConfiguration item)
            {
                Calendar calendar = item as Calendar;
                if (calendar != null)
                    ConfigurationManager.Instance.calendar = calendar;
            }

            public List<int> AsKeyList
            {
                get
                {
                    List<int> keys = new List<int>(1);
                    Calendar calendar = ConfigurationManager.Instance.calendar;
                    if (calendar != null)
                        keys.Add(calendar.Id);
                    return keys;
                }
            }
        }

        /*
        private class VaultControllerWrapper : IConfigurationList
        {
            public VaultControllerWrapper()
            {
            }

            public ConfigurationBase GetItem(int logicalId)
            {
                return ConfigurationManager.Instance.VaultController;
            }

            public void SetItem(int logicalId, IConfiguration item)
            {
                var vcConfiguration = item as VaultController8003Configuration;
                if (vcConfiguration != null)
                    ConfigurationManager.Instance.VaultController = vcConfiguration;
            }

            public List<int> AsKeyList
            {
                get
                {
                    List<int> keys = new List<int>(1);
                    var vcConfiguration = ConfigurationManager.Instance.VaultController;
                    if (vcConfiguration != null)
                        keys.Add(vcConfiguration.Id);
                    return keys;
                }
            }
        }
        */
    }
}