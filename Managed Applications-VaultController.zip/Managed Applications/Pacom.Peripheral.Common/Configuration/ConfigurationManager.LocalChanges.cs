﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Status;
using Pacom.Serialization.Formatters.Asn1;

namespace Pacom.Peripheral.Common.Configuration
{
    public partial class ConfigurationManager
    {
        public void UpdateConfiguration(List<ConfigurationBase> configuration, bool fromWeb, UserAuditInfo userAuditInfo, bool sendEventToFrontEnd)
        {
            if (Directory.Exists(FileSystemPaths.DataTransferPath) == false)
                DirectoryExtensions.Recreate(FileSystemPaths.DataTransferPath);

            string fileName;
            string identifier;
            if (configuration.Count > 0)
            {
                lock (controllerConfigurationSync)
                {
                    if (fromWeb)
                    {
                        fileName = FileSystemPaths.WebConfigurationFilePath;
                        identifier = "/web";

                        int newConnectionTableEntries = 0;
                        foreach (ConfigurationBase configurationItem in configuration)
                        {
                            if (configurationItem is ControllerConnection8003Table)
                                newConnectionTableEntries++;
                        }
                        int currentConnectionTableEntries = 0;
                        for (int i = 0; i < controllerConnectionTables.Length; i++)
                        {
                            if (controllerConnectionTables[i] != null)
                                currentConnectionTableEntries++;
                        }

                        if (newConnectionTableEntries < currentConnectionTableEntries)
                        {
                            // As this is an update, if we don't delete the connections file, it won't be possible to
                            // remove connection tables.
                            MarkConfigurationFileAsModified(FileSystemPaths.ConnectionsConfigFilePath);
                            File.Delete(FileSystemPaths.ConnectionsConfigFilePath);
                        }
                    }
                    else
                    {
                        fileName = FileSystemPaths.LocalChangeFilePath;
                        identifier = "/localupdate";
                    }

                    // Write the new configuration out to a file.
                    using (FileStream fileStream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None))
                    {
                        // Create the Asn.1 Serializer instance
                        StreamingContext context = new StreamingContext();
                        Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(true, context);
                        asn1Serializer.SerializeDefaultValues = true;
                        foreach (ConfigurationBase configurationItem in configuration)
                        {
                            asn1Serializer.Serialize(fileStream, configurationItem);
                        }
                    }
                    LoadFromDtp(identifier, null, userAuditInfo, sendEventToFrontEnd);
                }
            }
        }

        /// <summary>
        /// Load / Save web configuration changes into the controller.
        /// </summary>
        /// <param name="controllerConfiguration">Updated controller configuration</param>
        /// <param name="ethernetConfiguration">Updated controller Ethernet connection properties.</param>
        /// <param name="connectionTables">Update connection tables</param>
        /// <param name="userAuditInfo">User audit details: user type, user Id.</param>
        public void SetConfigurationFromWeb(Device8003Configuration controllerConfiguration, Port8003IPPortConfiguration ethernetConfiguration,
                                            ControllerConnection8003Table[] connectionTables)
        {
            List<ConfigurationBase> configurationItems = new List<ConfigurationBase>(new ConfigurationBase[] { controllerConfiguration, ethernetConfiguration });
            if (connectionTables.Length > 0)
                configurationItems.AddRange(connectionTables);
            UpdateConfiguration(configurationItems, true, WebServerUser, true);
        }

        public void AddAccessSchedule(AccessSchedule accessSchedule)
        {
            List<ConfigurationBase> configurationItems = new List<ConfigurationBase>(new ConfigurationBase[] { accessSchedule });
            UpdateConfiguration(configurationItems, false, FrontEndUser, true);
        }

        /// <summary>
        /// Add user configuration to users configuration list and update the ASN.1 users file.
        /// </summary>
        /// <param name="user">New user configuration instance.</param>
        /// <param name="userAuditInfo">User audit details: user type, user Id.</param>
        /// <returns>True if the new user configuration was successfully added.</returns>
        public bool UpdateUser(UserConfigurationBase user, UserAuditInfo userAuditInfo)
        {
            if (user == null)
                return false;

            try
            {
                List<ConfigurationBase> configurationItems = new List<ConfigurationBase>(1);
                configurationItems.Add(user);
                UpdateConfiguration(configurationItems, false, userAuditInfo, true);
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Unable to add user configuration: {0}", ex.ToString());
                });
                return false;
            }
        }

        public void ConvertToUnison()
        {
            // Convert any readers or users from GMS to Unison type
            lock (controllerConfigurationSync)
            {
                List<ConfigurationBase> configurationItems = new List<ConfigurationBase>();
                
                List<IReaderConfiguration> readerList = readers.AsList;
                foreach (IReaderConfiguration reader in readerList)
                {
                    ReaderConfiguration readerConfiguration = reader as ReaderConfiguration;
                    if (readerConfiguration == null)
                        continue;

                    // Convert Legacy Reader Configuration to 8003 Base Reader Configuration
                    Reader8003LegacyWiegandConfiguration intermediateBaseConfig = new Reader8003LegacyWiegandConfiguration();
                    ConfigurationManager.CopyConfiguration(readerConfiguration, intermediateBaseConfig);
                    Reader8003Configuration baseConfig = new Reader8003Configuration();
                    ConfigurationManager.CopyConfiguration(intermediateBaseConfig, baseConfig);
                    baseConfig.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                    configurationItems.Add(baseConfig);
                }

                users.RemoveAll();
                UpdateConfiguration(configurationItems, false, SystemUser, true);
            }
        }

        public void UpdateLoggingSettings(LoggingLevel level, DebugLoggingSubCategory debugSubCategory)
        {
            // This could be done more efficiently to handle this specific case but as this happens very
            // infrequently, this has been done to look the same as saving all the configuration from the
            // web.

            // Get the existing configuration that the web normally sends
            Device8003Configuration controllerConfiguration = new Device8003Configuration();
            CopyConfiguration(this.controllerConfiguration, controllerConfiguration);

            Port8003IPPortConfiguration ethernetConfiguration = new Port8003IPPortConfiguration();
            CopyConfiguration(this.controllerConfiguration.EthernetPort, ethernetConfiguration);

            int currentConnectionTableEntries = 0;
            for (int i = 0; i < controllerConnectionTables.Length; i++)
            {
                if (controllerConnectionTables[i] != null)
                    currentConnectionTableEntries++;
            }
            ControllerConnection8003Table[] connectionTables = new ControllerConnection8003Table[currentConnectionTableEntries];
            int destinationIndex = 0;
            for (int i = 0; i < controllerConnectionTables.Length; i++)
            {
                if (controllerConnectionTables[i] != null)
                {
                    connectionTables[destinationIndex] = new ControllerConnection8003Table();
                    CopyConfiguration(controllerConnectionTables[i], connectionTables[destinationIndex]);
                    connectionTables[destinationIndex].RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                    destinationIndex++;
                }
            }

            // Apply the new logging settings
            controllerConfiguration.LoggingLevel = level;
            controllerConfiguration.DebugLoggingSubCategory = debugSubCategory;

            controllerConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            ethernetConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;

            // Save the configuration
            List<ConfigurationBase> configurationItems = new List<ConfigurationBase>(new ConfigurationBase[] { controllerConfiguration, ethernetConfiguration });
            if (connectionTables.Length > 0)
                configurationItems.AddRange(connectionTables);
            UpdateConfiguration(configurationItems, true, WebServerUser, true);
        }

        private void disableConfiguration(NodeConfiguration configuration)
        {
            configuration.Enabled = false;
            Logger.LogWarnMessage(LoggerClassPrefixes.ConfigurationManager, () =>
            {
                return string.Format("Licensing limit exceeded. The {0} will be disabled.", configuration);
            });
        }

        public void DisableConfiguration(List<ConfigurationBase> configurationList)
        {
            int enabledInputsCount = GetEnabledInputsCount();
            int enabledOutputsCount = GetEnabledOutputsCount();
            int enabledReadersCount = GetEnabledReadersCount();
            int enabledDoorsCount = GetEnabledDoorsCount();
            foreach (NodeConfiguration configuration in configurationList)
            {
                if (configuration is InputConfigurationBase)
                {
                    if (enabledInputsCount >= LicenseManager.Instance.MaximumInputCount)
                        disableConfiguration(configuration);
                }
                else if (configuration is OutputConfigurationBase)
                {
                    if (enabledOutputsCount >= LicenseManager.Instance.MaximumOutputCount)
                        disableConfiguration(configuration);
                }
                else if (configuration is ReaderConfigurationBase)
                {
                    if (enabledReadersCount >= LicenseManager.Instance.MaximumReaderCount)
                        disableConfiguration(configuration);
                }
                else if (configuration is DoorConfigurationBase)
                {
                    if (enabledDoorsCount >= LicenseManager.Instance.MaximumDoorCount)
                        disableConfiguration(configuration);
                }
            }
        }

        private bool setAutoConfigureDeviceConfiguration(DeviceLoopDeviceConfigurationBase deviceConfiguration, string deviceName, HardwareType hardwareType, int physicalDeviceId)
        {
            if (deviceConfiguration == null)
                return false;
            deviceConfiguration.SetDefaults();
            deviceConfiguration.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
            deviceConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            deviceConfiguration.Id = NextDeviceId(hardwareType);
            deviceConfiguration.DeviceLoopAddress = physicalDeviceId;
            deviceConfiguration.ParentDeviceId = ControllerConfiguration.Id;
            deviceConfiguration.Name = string.Format("{0}-{1}", deviceName, physicalDeviceId);
            return true;
        }

        public bool AddAutoConfigureDeviceConfiguration(DeviceLoopDeviceConfigurationBase deviceConfiguration, string deviceName, HardwareType hardwareType, int physicalDeviceId, List<ConfigurationBase> configurationList)
        {
            if (setAutoConfigureDeviceConfiguration(deviceConfiguration, deviceName, hardwareType, physicalDeviceId) == true)
            {
                configurationList.Add(deviceConfiguration);
                return true;
            }
            return false;
        }

        public bool AddAutoConfigureDeviceConfiguration(DeviceLoopDeviceConfigurationBase deviceConfiguration, string deviceName, HardwareType hardwareType, int physicalDeviceId, List<ConfigurationBase> configurationList, int inputsCount, int outputsCount)
        {
            if (AddAutoConfigureDeviceConfiguration(deviceConfiguration, deviceName, hardwareType, physicalDeviceId, configurationList) == true)
            {
                for (int i = 0; i < inputsCount; i++)
                {
                    InputConfiguration.AutoConfigure(deviceConfiguration, i + 1, configurationList);
                }
                for (int i = 0; i < outputsCount; i++)
                {
                    OutputConfiguration.AutoConfigure(deviceConfiguration, i + 1, configurationList);
                }
                return true;
            }
            return false;
        }
    }
}