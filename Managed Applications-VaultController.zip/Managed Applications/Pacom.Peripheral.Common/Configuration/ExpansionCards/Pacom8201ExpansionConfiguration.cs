﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom8201ExpansionConfiguration : Device8201ExpansionConfiguration, IExpansionCardConfigurationBase
    {
        public Pacom8201ExpansionConfiguration()
        {
        }

        public static int AutoConfigure(int slotId, int parentDeviceId, List<ConfigurationBase> configuration)
        {
            Device8201ExpansionConfiguration deviceConfiguration = new Device8201ExpansionConfiguration();
            deviceConfiguration.SetDefaults();
            deviceConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            deviceConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            deviceConfiguration.Id = ConfigurationManager.Instance.NextDeviceId(HardwareType.Pacom8201ExpansionCard);
            deviceConfiguration.ExpansionCardSlot = slotId;
            deviceConfiguration.ParentDeviceId = parentDeviceId;
            deviceConfiguration.Name = string.Format("Cellular-{0}", deviceConfiguration.Id);
            configuration.Add(deviceConfiguration);
            return deviceConfiguration.Id;
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
        }
        
        /// <summary>
        /// Get expansion card name from repository
        /// </summary>
        /// <returns>Expansion Card Name if found in repository, empty otherwise</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }
    }
}
