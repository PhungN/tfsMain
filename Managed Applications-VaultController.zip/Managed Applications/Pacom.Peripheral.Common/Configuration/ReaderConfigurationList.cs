﻿using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class ReaderConfigurationList : NodeConfigurationListBase<IReaderConfiguration>, IConfigurationList
    {
        internal ReaderConfigurationList() : base() { }

        /// <summary>
        /// Return reader configuration referenced by logical id
        /// </summary>
        /// <param name="logicalId">Reader logical id, 1 based.</param>
        /// <returns>Reader configuration instance or null if not found.</returns>
        public override IReaderConfiguration this[int logicalId]
        {
            set
            {
                if (value != null && value.Enabled == true && Exists(logicalId) == false && EnabledCount >= LicenseManager.Instance.MaximumReaderCount)
                {
                    value.Enabled = false;
                    string readerName = ConfigurationStringRepository.RetrieveName(ConfigurationType.Reader, value.Id);
                    Logger.LogWarnMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("Licensing limit exceeded. The added reader {0} will be disabled.", readerName);
                    });
                }
                base[logicalId] = value;
            }
        }

        /// <summary>
        /// Get next reader Id
        /// </summary>
        public int NextReaderId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
