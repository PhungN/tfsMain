﻿using Pacom.Core.Contracts;
using Pacom.Core.Access;
using Pacom.Configuration.ConfigurationCommon;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class PresenceZoneConfiguration : PresenceZone8003Configuration
    {
        public PresenceZoneConfiguration()
        {
            InReaders = new IReaderConfiguration[0];
            OutReaders = new IReaderConfiguration[0];
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.PresenceZone, Id, Name);
                base.Name = null;
            }
        }

        public IReaderConfiguration[] InReaders { get; set; }

        public IReaderConfiguration[] OutReaders { get; set; }

        internal void AddInReader(IReaderConfiguration reader)
        {
            // Check if the reader is already in the list
            foreach (var item in InReaders)
            {
                if (item == reader)
                    return;
            }

            IReaderConfiguration[] readers = new IReaderConfiguration[InReaders.Length + 1];
            for (int i = 0; i < InReaders.Length; i++)
            {
                readers[i] = InReaders[i];
            }
            readers[InReaders.Length] = reader;
            InReaders = readers;
        }

        internal void AddOutReader(IReaderConfiguration reader)
        {
            // Check if the reader is already in the list
            foreach (var item in OutReaders)
            {
                if (item == reader)
                    return;
            }

            IReaderConfiguration[] readers = new IReaderConfiguration[OutReaders.Length + 1];
            for (int i = 0; i < OutReaders.Length; i++)
            {
                readers[i] = OutReaders[i];
            }
            readers[OutReaders.Length] = reader;
            OutReaders = readers;
        }

        /// <summary>
        /// Get presence zone name from repository
        /// </summary>
        /// <returns>Presence Zone Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.PresenceZone, Id);
        }

        private void remove(ConfigurationChanges changedItem)
        {
            if (changedItem.ConfigurationType == ConfigurationElementType.Reader)
            {
                InReaders = ConfigurationUtils.Remove<IReaderConfiguration>(changedItem.Id, InReaders);
                OutReaders = ConfigurationUtils.Remove<IReaderConfiguration>(changedItem.Id, OutReaders);
            }
        }

        public void RemoveOldConfigurationItems(List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems)
        {
            foreach (ConfigurationChanges changedItem in changedItems)
            {
                remove(changedItem);
            }
            foreach (ConfigurationChanges removedItem in removedItems)
            {
                remove(removedItem);
            }
        }
    }
}
