﻿using System;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class OutputScheduleList : ConfigurationListBase<OutputSchedule>, IConfigurationList
    {
        internal OutputScheduleList() : base() { }

        /// <summary>
        /// Get next output schedule Id
        /// </summary>
        public int NextScheduleId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
