﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    /// <summary>
    /// This class will store configuration strings on FLASH memory so that they are not taking up space in RAM.
    /// </summary>
    public static class ConfigurationStringRepository
    {
        private static SortedList<long, string> names = new SortedList<long, string>();

        public static void AddName(ConfigurationType configurationType, int logicalId, string name)
        {
            long key = ((long)configurationType << 32) + logicalId;
            lock (names)
            {
                names[key] = name;
            }
        }

        public static string RetrieveName(ConfigurationType configurationType, int logicalId)
        {
            long key = ((long)configurationType << 32) + logicalId;
            lock (names)
            {
                string name = string.Empty;
                if (names.TryGetValue(key, out name) == true)
                    return name;
            }
            return string.Empty;
        }
    }
}
