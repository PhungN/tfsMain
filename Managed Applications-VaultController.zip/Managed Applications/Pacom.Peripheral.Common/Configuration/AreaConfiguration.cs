﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class AreaConfiguration : Area8003Configuration
    {
        public AreaConfiguration()
        {
        }

        public static void AutoConfigure(List<ConfigurationBase> configuration)
        {
            Area8003Configuration areaConfiguration = new Area8003Configuration();
            areaConfiguration.SetDefaults();
            areaConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            areaConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            areaConfiguration.Id = ConfigurationManager.Instance.NextAreaId;
            areaConfiguration.ParentDeviceId = ConfigurationManager.Instance.ControllerConfiguration.Id;
            areaConfiguration.Name = "Main Area";
            configuration.Add(areaConfiguration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            reset();
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Area, Id, Name);
                Name = null;
            }
            reset();
        }

        public Pacom8003AreaSchedule NormalSchedule { get; set; }

        public InputConfiguration[] Inputs { get; set; }

        public Pacom8101KeypadConfiguration[] Keypads { get; set; }

        public DoorConfiguration[] Doors { get; set; }

        public OutputConfiguration[] Outputs { get; set; }

        public IReaderConfiguration[] Readers { get; set; }

        /// <summary>
        /// Get total entry delay in milliseconds
        /// </summary>
        public int EntryDelay
        {
            get { return (int)(EntryDelay1 + EntryDelay2).TotalMilliseconds; }
        }

        /// <summary>
        /// Get entry delay 1 in milliseconds
        /// </summary>
        public int EntryDelay1Milliseconds
        {
            get { return (int)EntryDelay1.TotalMilliseconds; }
        }

        /// <summary>
        /// Get entry delay 2 in milliseconds
        /// </summary>
        public int EntryDelay2Milliseconds
        {
            get { return (int)EntryDelay2.TotalMilliseconds; }
        }

        /// <summary>
        /// Get total exit delay in seconds
        /// </summary>
        public int ExitDelaySeconds
        {
            get { return (int)(ExitDelay1 + ExitDelay2).TotalSeconds; }
        }

        /// <summary>
        /// Get entry delay extension in milliseconds
        /// </summary>
        public int EntryDelayExtendBy
        {
            get { return (int)DurationToExtendEntryDelayBy.TotalMilliseconds; }
        }

        /// <summary>
        /// Get area name from repository
        /// </summary>
        /// <returns>Area Name if found in repository, empty otherwise</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Area, Id);
        }

        public void AddDoor(DoorConfiguration door)
        {
            // Check if the door is already in the list
            foreach (var item in Doors)
            {
                if (item == door)
                    return;
            }

            DoorConfiguration[] doors = Doors;
            int oldLen = doors.Length;
            Array.Resize(ref doors, oldLen + 1);
            doors[oldLen] = door;
            Doors = doors;
        }

        public void AddInput(InputConfiguration input)
        {
            // Check if the input is already in the list
            foreach (var item in Inputs)
            {
                if (item == input)
                    return;
            }

            InputConfiguration[] inputs = Inputs;
            int oldLen = Inputs.Length;
            Array.Resize(ref inputs, oldLen + 1);
            inputs[oldLen] = input;
            Inputs = inputs;
        }

        public void AddKeypad(Pacom8101KeypadConfiguration keypad)
        {
            // Check if the keypad is already in the list
            foreach (var item in Keypads)
            {
                if (item == keypad)
                    return;
            }

            Pacom8101KeypadConfiguration[] keypads = Keypads;
            int oldLen = Keypads.Length;
            Array.Resize(ref keypads, oldLen + 1);
            keypads[oldLen] = keypad;
            Keypads = keypads;
        }

        public void AddOutput(OutputConfiguration output)
        {
            // Check if the output is already in the list
            foreach (var item in Outputs)
            {
                if (item == output)
                    return;
            }

            OutputConfiguration[] outputs = Outputs;
            int oldLen = Outputs.Length;
            Array.Resize(ref outputs, oldLen + 1);
            outputs[oldLen] = output;
            Outputs = outputs;
        }

        public void AddReader(IReaderConfiguration reader)
        {
            // Check if the reader is already in the list
            foreach (var item in Readers)
            {
                if (item == reader)
                    return;
            }

            IReaderConfiguration[] readers = Readers;
            int oldLen = Readers.Length;
            Array.Resize(ref readers, oldLen + 1);
            readers[oldLen] = reader;
            Readers = readers;
        }

        private void remove(ConfigurationChanges changedItem)
        {
            if (changedItem.ConfigurationType == ConfigurationElementType.Input)
                Inputs = ConfigurationUtils.Remove<InputConfiguration>(changedItem.Id, Inputs);
            else if (changedItem.ConfigurationType == ConfigurationElementType.Device)
                Keypads = ConfigurationUtils.Remove<Pacom8101KeypadConfiguration>(changedItem.Id, Keypads);
            else if (changedItem.ConfigurationType == ConfigurationElementType.Door)
                Doors = ConfigurationUtils.Remove<DoorConfiguration>(changedItem.Id, Doors);
            else if (changedItem.ConfigurationType == ConfigurationElementType.Output)
                Outputs = ConfigurationUtils.Remove<OutputConfiguration>(changedItem.Id, Outputs);
            else if (changedItem.ConfigurationType == ConfigurationElementType.Reader)
                Readers = ConfigurationUtils.Remove<IReaderConfiguration>(changedItem.Id, Readers);
        }

        public void RemoveOldConfigurationItems(List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems)
        {
            foreach (ConfigurationChanges changedItem in changedItems)
            {
                remove(changedItem);
            }
            foreach (ConfigurationChanges removedItem in removedItems)
            {
                remove(removedItem);
            }
        }

        private void reset()
        {
            if (Inputs == null)
                Inputs = new InputConfiguration[0];
            if (Keypads == null)
                Keypads = new Pacom8101KeypadConfiguration[0];
            if (Doors == null)
                Doors = new DoorConfiguration[0];
            if (Outputs == null)
                Outputs = new OutputConfiguration[0];
            if (Readers == null)
                Readers = new IReaderConfiguration[0];
        }

        public bool AreaModeFollowsConfigured
        {
            get { return AreaModeFollows != null && AreaModeFollows.Length > 0; }
        }
    }
}
