﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class DialupPortConfiguration : Port8003DialupPortConfiguration
    {
        public DialupPortConfiguration()
        {
        }

        public static void AutoConfigure(int parentDeviceId, Pacom8003PhysicalPort portNumberOnParent, List<ConfigurationBase> configuration)
        {
            Port8003DialupPortConfiguration portConfiguration = new Port8003DialupPortConfiguration();
            portConfiguration.SetDefaults();
            portConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            portConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            portConfiguration.Id = ConfigurationManager.Instance.NextPortId;
            portConfiguration.ParentDeviceId = parentDeviceId;
            portConfiguration.PortNumberOnParent = portNumberOnParent;
            if (portNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot1)
                portConfiguration.Name = "Expansion1 Dialup";
            else if (portNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot2)
                portConfiguration.Name = "Expansion1 Dialup";
            else
                portConfiguration.Name = "Dialup";
            portConfiguration.InitializationString = string.Empty;
            configuration.Add(portConfiguration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Port, Id, Name);
                Name = null;
            }
        }

        /// <summary>
        /// Get port name from repository
        /// </summary>
        /// <returns>Port Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Port, Id);
        }
    }
}
