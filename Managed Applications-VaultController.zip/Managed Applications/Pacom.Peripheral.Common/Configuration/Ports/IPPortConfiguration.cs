﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class IPPortConfiguration : Port8003IPPortConfiguration
    {
        public IPPortConfiguration()
        {
        }

        public static void AutoConfigure(int parentDeviceId, Pacom8003PhysicalPort portNumberOnParent, List<ConfigurationBase> configuration)
        {
            Port8003IPPortConfiguration portConfiguration = new Port8003IPPortConfiguration();
            portConfiguration.SetDefaults();
            portConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            portConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            portConfiguration.Id = ConfigurationManager.Instance.NextPortId;
            portConfiguration.ParentDeviceId = parentDeviceId;
            portConfiguration.PortNumberOnParent = portNumberOnParent;
            portConfiguration.Name = "On-board Ethernet";
            configuration.Add(portConfiguration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Port, Id, Name);
                Name = null;
            }
        }
        
        /// <summary>
        /// Get port name from repository
        /// </summary>
        /// <returns>Port Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Port, Id);
        }
    }
}
