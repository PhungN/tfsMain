﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class RS485AperioPortConfiguration : Port8003RS485AperioPortConfiguration
    {
        public RS485AperioPortConfiguration()
        {
        }

        public static void AutoConfigure(int parentDeviceId, Pacom8003PhysicalPort portNumberOnParent, List<ConfigurationBase> configuration)
        {
            Port8003RS485AperioPortConfiguration portConfiguration = new Port8003RS485AperioPortConfiguration();
            portConfiguration.SetDefaults();
            portConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            portConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            portConfiguration.Id = ConfigurationManager.Instance.NextPortId;
            portConfiguration.ParentDeviceId = parentDeviceId;
            portConfiguration.PortNumberOnParent = portNumberOnParent;

            if (portNumberOnParent == Pacom8003PhysicalPort.RS485)
                portConfiguration.Name = "On-board Aperio RS485";
            else if (portNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot1)
                portConfiguration.Name = "Expansion1 Aperio RS485";
            else if (portNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot2)
                portConfiguration.Name = "Expansion2 Aperio RS485";
            else
                portConfiguration.Name = "Aperio RS485";
            configuration.Add(portConfiguration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Port, Id, Name);
                Name = null;
            }
        }

        /// <summary>
        /// Get port name from repository
        /// </summary>
        /// <returns>Port Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Port, Id);
        }
    }
}
