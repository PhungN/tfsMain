﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class RS485AsisProprietaryReaderPortConfiguration : Port8003RS485AsisProprietaryReaderPortConfiguration
    {
        public RS485AsisProprietaryReaderPortConfiguration()
        {
        }

        public static void AutoConfigure(int parentDeviceId, Pacom8003PhysicalPort portNumberOnParent, List<ConfigurationBase> configuration)
        {
            Port8003RS485AsisProprietaryReaderPortConfiguration portConfiguration = new Port8003RS485AsisProprietaryReaderPortConfiguration();
            portConfiguration.SetDefaults();
            portConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            portConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            portConfiguration.Id = ConfigurationManager.Instance.NextPortId;
            portConfiguration.ParentDeviceId = parentDeviceId;
            portConfiguration.PortNumberOnParent = portNumberOnParent;
            if (portNumberOnParent == Pacom8003PhysicalPort.RS485)
                portConfiguration.Name = "On-board APRP";
            else if (portNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot1)
                portConfiguration.Name = "Expansion1 APRP";
            else if (portNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot2)
                portConfiguration.Name = "Expansion2 APRP";
            else
                portConfiguration.Name = "APRP";
            configuration.Add(portConfiguration);
        }
        
        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Port, Id, Name);
                Name = null;
            }
        }

        /// <summary>
        /// Get port name from repository
        /// </summary>
        /// <returns>Port Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Port, Id);
        }
    }
}
