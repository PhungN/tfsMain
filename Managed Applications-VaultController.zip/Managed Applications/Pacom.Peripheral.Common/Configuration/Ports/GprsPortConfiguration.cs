﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class GprsPortConfiguration : Port8003GprsPortConfiguration
    {
        public GprsPortConfiguration()
        {
        }

        public static void AutoConfigure(int parentDeviceId, Pacom8003PhysicalPort portNumberOnParent, List<ConfigurationBase> configuration)
        {
            Port8003GprsPortConfiguration portConfiguration = new Port8003GprsPortConfiguration();
            portConfiguration.SetDefaults();
            portConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            portConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            portConfiguration.Id = ConfigurationManager.Instance.NextPortId;
            portConfiguration.ParentDeviceId = parentDeviceId;
            portConfiguration.PortNumberOnParent = portNumberOnParent;
            if (portNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot1)
                portConfiguration.Name = "Expansion1 GPRS";
            else if (portNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot2)
                portConfiguration.Name = "Expansion2 GPRS";
            else
                portConfiguration.Name = "GPRS";
            portConfiguration.InitializationString = string.Empty;
            portConfiguration.DialModifier = string.Empty;
            configuration.Add(portConfiguration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Port, Id, Name);
                Name = null;
            }
        }

        /// <summary>
        /// Get port name from repository
        /// </summary>
        /// <returns>Port Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Port, Id);
        }
    }
}
