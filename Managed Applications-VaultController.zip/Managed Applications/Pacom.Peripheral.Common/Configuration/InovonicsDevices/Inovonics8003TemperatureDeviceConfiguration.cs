﻿#if INOVONICSTEMPERATUREDEMO
using System.Linq;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Status;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    /// <summary>
    /// This is the configuration required for the following Inovonics one alarm / one-way security devices: 
    ///     EN1721          - Integrated temperature and humidity transmitter    
    ///     EN1722          - Temperature/Humidity Transmitter
    /// </summary>
    public class Inovonics8003TemperatureDeviceConfiguration : InovonicsTemperatureDeviceConfiguration,
                                                               IInovonicsDeviceConfiguration
    {
        public const int AlarmsCount = 2;

        public Inovonics8003TemperatureDeviceConfiguration()
        {
        }

        /// <summary>
        /// Auto-configure this device type. The device 8 digit SerialNumber is used as the device address 
        /// </summary>
        /// <param name="serialNumber">Inovonics device Unique ID (8 digit Serial Number)</param>
        /// <param name="deviceType">Inovonics Device Type</param>
        public static void AutoConfigure(int serialNumber, InovonicsDeviceType deviceType, List<ConfigurationBase> configuration)
        {
            InovonicsTemperatureDeviceConfiguration deviceConfiguration = new InovonicsTemperatureDeviceConfiguration();
            deviceConfiguration.SetDefaults();
            deviceConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            deviceConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            deviceConfiguration.DeviceType = deviceType;
            deviceConfiguration.DeviceLoopAddress = serialNumber;
            deviceConfiguration.Id = ConfigurationManager.Instance.NextDeviceId;
            deviceConfiguration.ParentDeviceId = ConfigurationManager.Instance.InovonicsSerialReceiverId;
            deviceConfiguration.Name = string.Format("{0}-{1}", deviceType.AsShortString(), deviceConfiguration.Id);
            configuration.Add(deviceConfiguration);

            // Create inputs
            int alarmCount = InovonicsSecurityDeviceConfiguration.GetNumberOfAlarmInputs(deviceType);
            for (int i = 0; i < AlarmsCount; i++)
            {
                InputConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
            }
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            Inputs = new InputConfiguration[AlarmsCount];
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            if (Inputs == null)
                Inputs = new InputConfiguration[AlarmsCount];
        }

        /// <summary>
        /// Check if any of the inputs has a valid configuration
        /// </summary>
        public bool InputsValid
        {
            get { return Inputs.Any(input => input != null); }
        }

        #region IInovonicsDeviceConfiguration Members

        /// <summary>
        /// Get the device physical address. For Inovonics devices this will be the device Unique ID (8 digit Serial Number).
        /// </summary>
        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        /// <summary>
        /// Device inputs list - 1 input available
        /// </summary>
        public InputConfiguration[] Inputs { get; set; }

        /// <summary>
        /// Get IO device configured input count
        /// </summary>
        public int InputCount
        {
            get { return AlarmsCount; }
        }

        #endregion
    }
}
#endif
