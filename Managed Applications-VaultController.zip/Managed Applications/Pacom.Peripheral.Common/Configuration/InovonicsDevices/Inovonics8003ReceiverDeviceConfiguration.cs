﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Status;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    /// <summary>
    /// This is the configuration required for the following Inovonics devices: 
    ///     EN4000      - Serial Receiver
    /// </summary>
    public sealed class Inovonics8003ReceiverDeviceConfiguration : InovonicsReceiverDeviceConfiguration,
                                                                   IDeviceLoopDeviceConfigurationBase
    {
        public Inovonics8003ReceiverDeviceConfiguration()
            : base()
        {
            DeviceType = InovonicsDeviceType.ES4000;
        }

        /// <summary>
        /// Auto-configure this device type. For Serial Receiver the device 8 digit SerialNumber might be not known at this stage
        /// so the default DeviceAddress will be used instead.
        /// </summary>
        /// <param name="serialNumber">Inovonics device Unique ID (8 digit Serial Number)</param>
        /// <param name="deviceType">Inovonics Device Type</param>
        public static void AutoConfigure(int serialNumber, InovonicsDeviceType deviceType, List<ConfigurationBase> configuration)
        {
            InovonicsReceiverDeviceConfiguration deviceConfiguration = new InovonicsReceiverDeviceConfiguration();
            deviceConfiguration.SetDefaults();
            deviceConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            deviceConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            deviceConfiguration.DeviceType = deviceType;
            deviceConfiguration.DeviceLoopAddress = serialNumber;
            deviceConfiguration.Id = ConfigurationManager.Instance.NextDeviceId(HardwareType.InovonicsSerialReceiver);
            deviceConfiguration.ParentDeviceId = ConfigurationManager.Instance.ControllerConfiguration.Id;
            deviceConfiguration.Name = deviceType.AsString();
            configuration.Add(deviceConfiguration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
        }

        #region IDeviceLoopDeviceConfigurationBase Members

        /// <summary>
        /// Get the device physical address. For Inovonics devices this will be the device Unique ID (8 digit Serial Number).
        /// </summary>
        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        #endregion
    }
}
