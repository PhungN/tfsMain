﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utils;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    /// <summary>
    /// This is the configuration required for the following Inovonics one alarm / one-way security devices: 
    ///     EN1210          - Single Input Universal Transmitter    
    ///     EN1210EOL       - Single Input Universal Transmitter with EOL Protection
    ///     EE1210SK        - Universal Survey Transmitter – Europe    
    ///     EE1215          - Single Input Universal Transmitter with Wall Tamper – Europe
    ///     EN1215EOL       - Universal Transmitter with Wall Tamper
    ///     EN1235DF        - Double-Button Fixed Position Hold Up Transmitter
    ///     EN1235SF        - Single-Button Fixed Position Hold Up Transmitter
    ///     ES1242_1243     - Smoke / Heat Detector
    ///     ES1247          - Glassbreak Detector Transmitter - US/AUS/NZ/Europe
    ///     EN1249          - Billtrap Transmitter
    ///     EN1260          - Wall Mount Motion Detector
    ///     EE1261_EN1261HT - High Traffic Four Element Motion Detector - US/AUS/NZ/Europe
    ///     EN1262          - Motion Detector with Pet Immunity
    ///     ES1265          - 360° Ceiling Mount Motion Detector - US/AUS/NZ/Europe
    ///
    /// This is the configuration required for the following Inovonics two alarms / one-way security devices: 
    ///     EN1210W         - Door/Window Transmitter with Reed Switch
    ///     EN1212          - Dual Alarm Input Universal Transmitter
    ///     EE1215W         - Door/Window Transmitter with Wall Tamper and Reed Switch – Europe
    ///     EN1215WEOL      - Door/Window Transmitter with Wall Tamper, Reed Switch, and EOL Protection
    ///     ES1216          - Dual Alarm Input Universal Transmitter with Wall Tamper
    ///     EN1252          - Long Range Dual Alarm Input Universal Transmitter
    ///     EN1238D         - Double-Button Dual Condition Pendant Transmitter
    ///
    /// This is the configuration required for the following Inovonics three alarms / one-way security devices: 
    ///     ES1236D         - Double-Button Three Condition Pendant Transmitter
    ///
    /// This is the configuration required for the following Inovonics four alarms / one-way security devices: 
    ///     EN1224      - Multiple Condition Pendant Transmitter
    ///     EN1224OLD   - Multiple Condition Pendant Transmitter
    ///     EN1224ON    - Multiple Condition On/Off Pendant Transmitter
    ///     EN1224ONOLD - Multiple Condition On/Off Pendant Transmitter
    /// </summary>
    public class Inovonics8003SecurityDeviceConfiguration : InovonicsSecurityDeviceConfiguration,
                                                            IInovonicsDeviceConfiguration
    {
        public const int AlarmsCount = 4;

        public Inovonics8003SecurityDeviceConfiguration()
        {
        }

        /// <summary>
        /// Auto-configure this device type. The device 8 digit SerialNumber is used as the device address 
        /// </summary>
        /// <param name="serialNumber">Inovonics device Unique ID (8 digit Serial Number)</param>
        /// <param name="deviceType">Inovonics Device Type</param>
        public static void AutoConfigure(int serialNumber, InovonicsDeviceType deviceType, List<ConfigurationBase> configuration)
        {
            InovonicsSecurityDeviceConfiguration deviceConfiguration = new InovonicsSecurityDeviceConfiguration();
            deviceConfiguration.SetDefaults();
            deviceConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            deviceConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            deviceConfiguration.DeviceType = deviceType;
            deviceConfiguration.DeviceLoopAddress = serialNumber;
            deviceConfiguration.Id = ConfigurationManager.Instance.NextDeviceId(HardwareType.InovonicsTransceiver);
            deviceConfiguration.ParentDeviceId = ConfigurationManager.Instance.InovonicsSerialReceiverId;
            deviceConfiguration.Name = string.Format("{0}-{1}", deviceType.AsShortString(), deviceConfiguration.Id);
            configuration.Add(deviceConfiguration);

            // Create inputs
            int alarmCount = InovonicsSecurityDeviceConfiguration.GetNumberOfAlarmInputs(deviceType);
            for (int i = 0; i < alarmCount; i++)
            {
                InputConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
            }
            }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            Inputs = new InputConfiguration[AlarmsCount];
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            if (Inputs == null)
                Inputs = new InputConfiguration[AlarmsCount];
        }

        /// <summary>
        /// Check if any of the inputs has a valid configuration
        /// </summary>
        public bool InputsValid
        {
            get { return Inputs.Any(input => input != null); }
        }

        #region IInovonicsDeviceConfiguration Members

        /// <summary>
        /// Get the device physical address. For Inovonics devices this will be the device Unique ID (8 digit Serial Number).
        /// </summary>
        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        /// <summary>
        /// Device inputs list - 1 input available
        /// </summary>
        public InputConfiguration[] Inputs { get; set; }

        /// <summary>
        /// Get IO device configured input count
        /// </summary>
        public int InputCount
        {
            get { return AlarmsCount; }
        }

        #endregion
    }
}
