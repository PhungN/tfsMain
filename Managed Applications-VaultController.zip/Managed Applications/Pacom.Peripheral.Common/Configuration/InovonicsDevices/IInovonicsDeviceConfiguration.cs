﻿
namespace Pacom.Peripheral.Common.Configuration
{
    public interface IInovonicsDeviceConfiguration : IDeviceLoopDeviceConfigurationBase, IInputDeviceConfigurationBase
    {
    }
}
