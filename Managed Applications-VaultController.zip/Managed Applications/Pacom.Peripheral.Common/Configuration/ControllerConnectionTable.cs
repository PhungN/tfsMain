﻿using Pacom.Core.Contracts;
using Pacom.Core.Access;
using Pacom.Configuration.ConfigurationCommon;
using System.Collections.Generic;
using System;
using System.IO;

namespace Pacom.Peripheral.Common.Configuration
{
    public class ControllerConnectionTable : ControllerConnection8003Table
    {
        private ISram sram;

        private readonly object sync = new object();

        public ControllerConnectionTable(ISram sram)
        {
            this.sram = sram;
        }

        public static void AutoConfigure(List<ConfigurationBase> configuration)
        {
            ControllerConnection8003Table controllerConnectionTable = new ControllerConnection8003Table();
            controllerConnectionTable.SetDefaults();
            controllerConnectionTable.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            controllerConnectionTable.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;

            controllerConnectionTable.ConnectionEntry = new ControllerConnection8003Entry[1];
            controllerConnectionTable.ConnectionEntry[0] = new ControllerConnection8003Entry();
            // Set Defaults for connection entry
            controllerConnectionTable.ConnectionEntry[0].SetDefaults();
            configuration.Add(controllerConnectionTable);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;

            ConnectionEntry = new ControllerConnection8003Entry[1];
            ConnectionEntry[0] = new ControllerConnection8003Entry();
            // Set Defaults for connection entry
            ConnectionEntry[0].SetDefaults();
            FilteredConnectionEntries = new ControllerConnection8003Entry[1];
            FilteredConnectionEntries[0] = ConnectionEntry[0];
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            // Remove unused controller connection entries
            int len = 0;
            if (ConnectionEntry != null && ConnectionEntry.Length > 0)
                len = ConnectionEntry.Length;
            
            List<ControllerConnection8003Entry> filteredEntries = new List<ControllerConnection8003Entry>(len);
            if (ConnectionEntry != null)
            {
                foreach (ControllerConnection8003Entry entry in ConnectionEntry)
                {
                    if (entry.EnableEventReporting || entry.EnableDtpTransfers)
                    {
                        if (isIPAddressValid(entry.IPDestinationAddress))
                        {
                            if (entry.ControllerPhysicalPort == (int)ControllerPhysicalPort.Ethernet
                                || entry.ControllerPhysicalPort == (int)ControllerPhysicalPort.ExpansionSlot1
                                || entry.ControllerPhysicalPort == (int)ControllerPhysicalPort.ExpansionSlot2)
                            {
                                entry.IPDestinationAddress = entry.IPDestinationAddress.Trim();
                                filteredEntries.Add(entry);
                            }
                        }
                        else
                        {
                            if (entry.ControllerPhysicalPort == (int)ControllerPhysicalPort.ExpansionSlot1
                                || entry.ControllerPhysicalPort == (int)ControllerPhysicalPort.ExpansionSlot2)
                            {
                                if (entry.HighLevelAddress != null && entry.HighLevelAddress.Trim().Length > 0)
                                {
                                    entry.IPDestinationAddress = string.Empty;
                                    entry.HighLevelAddress = entry.HighLevelAddress.Trim();
                                    filteredEntries.Add(entry);
                                }
                            }
                        }
                    }
                }
            }
            if (ConnectionEntry == null)
                ConnectionEntry = new ControllerConnection8003Entry[0];

            if (filteredEntries.Count > 0)
            {
                if (FilteredConnectionEntries == null || FilteredConnectionEntries.Length != filteredEntries.Count)
                {
                    FilteredConnectionEntries = filteredEntries.ToArray();
                }
                else
                {
                    // Check that the FilteredConnectionEntries have changed and only overwrite them if they have.
                    // This is to maintain existing instances when the configuration hasn't changed.
                    bool changed = false;
                    for (int i = 0; i < filteredEntries.Count; i++)
                    {
                        if (filteredEntries[i].Equals(FilteredConnectionEntries[i]) == false)
                        {
                            changed = true;
                            break;
                        }
                    }
                    if (changed)
                        FilteredConnectionEntries = filteredEntries.ToArray();
                }
            }
            else
            {
                if (FilteredConnectionEntries == null || FilteredConnectionEntries.Length > 0)
                    FilteredConnectionEntries = new ControllerConnection8003Entry[0];
            }
        }

        public byte[] GetMasterKey()
        {
            byte[] masterKey = new byte[32];
            sram.ReadData(SramLocations.MasterKeysOffset + (33 * (Id - 1)), masterKey);
            return masterKey;
        }

        public void SetMasterKey(byte[] masterKey)
        {
            if (masterKey.Length == 32)
                sram.WriteData(SramLocations.MasterKeysOffset + (33 * (Id - 1)), masterKey);
        }

        private bool? commisioned = null;
        public bool GetCommisionedStatus()
        {
            lock (sync)
            {
                if (commisioned.HasValue)
                    return commisioned.Value;
                byte[] commisionedState = new byte[1];
                sram.ReadData(SramLocations.MasterKeysOffset + 32 + (33 * (Id - 1)), commisionedState);
                if (commisionedState[0] == 0xab)
                {
                    commisioned = true;
                    return true;
                }
                else
                {
                    commisioned = false;
                    return false;
                }
            }
        }
        
        public void SetCommisionedStatus(bool commisioned)
        {
            lock (sync)
            {
                byte[] commisionedState = new byte[1];
                if (commisioned)
                    commisionedState[0] = 0xab;
                else
                    commisionedState[0] = 0x00;
                sram.WriteData(SramLocations.MasterKeysOffset + 32 + (33 * (Id - 1)), commisionedState);
                this.commisioned = commisioned;
            }
        }

        public FrontEndSystem PrimaryAlarmQueue
        {
            get;
            set;
        }

        public FrontEndSystem DisasterAlarmQueue
        {
            get;
            set;
        }

        public ControllerConnection8003Entry[] FilteredConnectionEntries { get; set; }

        public bool ContainsValidEventConnections
        {
            get
            {
                bool hasEventConnections = false;
                foreach (ControllerConnection8003Entry entry in FilteredConnectionEntries)
                {
                    if (entry.AddressFieldValid == true && entry.EnableEventReporting == true)
                    {
                        hasEventConnections = true;
                        break;
                    }
                }
                return hasEventConnections;
            }
        }

        public static void DecommisionAll(ISram sram)
        {
            byte[] commisionedState = new byte[] { 0 };
            for (int i = 0; i < ConfigConsts.MaxControllerConnectionTables; i++)
            {
                sram.WriteData(SramLocations.MasterKeysOffset + 32 + (33 * i), commisionedState);
            }
            for (int i = 0; i < ConfigConsts.MaxControllerConnectionTables; i++)
            {
                ControllerConnectionTable connectionTable = ConfigurationManager.Instance.GetControllerConnectionTable(i);
                if (connectionTable != null)
                    connectionTable.commisioned = null;
            }
        }

        private static bool isIPAddressValid(string ipString)
        {
            if (ipString == null)
                return false;
            
            ipString = ipString.Trim();
            if (ipString.Length < 7)
                return false;

            if (ipString == "0.0.0.0")
                return false;

            string[] parts = ipString.Trim().Split('.');
            if (parts.Length != 4)
                return false;

            for (int i = 0; i < 4; i++)
            {
                try
                {
                    int temp = int.Parse(parts[i]);
                    if (temp < 0 || temp > 255)
                        return false;
                }
                catch
                {
                    return false;
                }
            }

            return true;
        }
    }
}
