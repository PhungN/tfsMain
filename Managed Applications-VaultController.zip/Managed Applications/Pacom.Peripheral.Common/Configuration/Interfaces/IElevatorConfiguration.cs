﻿using System;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public interface IElevatorConfiguration : INodeConfiguration
    {
        /// <summary>
        /// The card reader address for the elevator car reader.
        /// </summary>
        int ReaderId { get; set; }

        /// <summary>
        /// The card reader schedule id for the reader in the elevator. A value of 0 means “locked/unused”.
        /// </summary>
        int ScheduleId { get; set; }

        /// <summary>
        /// The alarm area that this point belongs to.
        /// </summary>        
        int AreaId { get; set; }

        /// <summary>
        /// The floors serviced by this elevator.
        /// </summary>
        int[] FloorIds { get; set; }

        /// <summary>
        /// The 1065EC (Elevator Controller) for floors 1-16 for this Elevator.
        /// </summary>
        int ElevatorController1To16Id { get; set; }

        /// <summary>
        /// The 1065EC (Elevator Controller) for floors 17-32 for this Elevator.
        /// </summary>
        int ElevatorController17To32Id { get; set; }

        /// <summary>
        /// The 1065EC (Elevator Controller) for floors 33-48 for this Elevator.
        /// </summary>
        int ElevatorController33To48Id { get; set; }

        /// <summary>
        /// The 1065EC (Elevator Controller) for floors 49-64 for this Elevator.
        /// </summary>
        int ElevatorController49To64Id { get; set; }

        /// <summary>
        /// The 1065EC (Elevator Controller) for floors 65-80 for this Elevator.
        /// </summary>
        int ElevatorController65To80Id { get; set; }

        /// <summary>
        /// The 1065EC (Elevator Controller) for floors 81-96 for this Elevator.
        /// </summary>
        int ElevatorController81To96Id { get; set; }

        /// <summary>
        /// The 1065EC (Elevator Controller) for floors 97-112 for this Elevator.
        /// </summary>
        int ElevatorController97To112Id { get; set; }

        /// <summary>
        /// The 1065EC (Elevator Controller) for floors 113-128 for this Elevator.
        /// </summary>
        int ElevatorController113To128Id { get; set; }

        /// <summary>
        /// The 1065EFM (Elevator Floor Monitor) for floors 1-48 for this Elevator.
        /// </summary>
        int ElevatorFloorMonitor1To48Id { get; set; }

        /// <summary>
        /// Determines the reporting option for selected floors. This option applies both to floor buttons connected through an
        /// Elevator Controller and to floor selection reporting back through the Elevator HLI.
        /// </summary>        
        ElevatorFloorSelectedReporting FloorSelectedReporting { get; set; }

        /// <summary>
        /// The schedule id for when to report floor selections. A value of 0 means 'always report'.
        /// </summary>
        int FloorSelectedReportingScheduleId { get; set; }

        /// <summary>
        /// If set, the floor the elevator car is currently on is monitored either through the Elevator HLI (if enabled) or by the 
        /// use of an Elevator Floor Monitor Controller. A status message will be reported back to Unison with the current floor
        /// whenever the current floor value changes.
        /// </summary>        
        bool EnableFloorMonitoring { get; set; }

        /// <summary>
        /// If set, apartment mode is enabled for this elevator. Apartment mode means that the Pacom 1065EC (Elevator Controller)  
        /// inputs are wired up to buttons on each floor (instead of the buttons in the elevator car). When a button is pressed, 
        /// the corresponding floor will be off security for a set time, allowing a guest to enter the elevator and press the 
        /// corresponding floor button without requiring a card. 
        /// NOTE: This option applies only to the 1065EC and not to the Elevator HLI.
        /// </summary>        
        bool EnableApartmentMode { get; set; }

        /// <summary>
        /// The time (in seconds) that a floor remains off security when triggered from an apartment input.
        /// During this time, a guest is allowed to enter the elevator and press the floor button without requiring a card.
        /// </summary>
        /// <remarks>
        /// NOTE: This setting only applies if apartment mode is enabled.
        /// </remarks>
        TimeSpan FloorAccessTime { get; set; }

        string GetName();
        int[] GetFloorControllerAddresses();
        int GetFloorAccessTime(int floorControllerAddress);
        bool IsValidReaderSchedule { get; }
        bool IsValidFloorSelectionReportingSchedule { get; }
    }

    public interface ILegacyElevatorConfiguration : IElevatorConfiguration
    {
        /// <summary>
        /// Floors Serviced
        /// </summary>
        bool[] FloorsServiced { get; set; }
    }

}
