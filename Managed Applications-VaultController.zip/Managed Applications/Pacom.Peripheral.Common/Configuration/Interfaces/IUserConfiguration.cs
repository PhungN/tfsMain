﻿using System.Collections.Generic;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    /// <summary>
    /// Compares any user in a list against a known user [compareToUser] and returns True
    /// if the binary predicate condition is satisfied
    /// </summary>
    /// <param name="compareToUser">User to compare list items against</param>
    /// <param name="otherUser">List User</param>
    /// <returns>True if the predicate condition is satisfied, False otherwise</returns>
    public delegate bool UserConfigurationBinaryPredicateFunc(IUserConfiguration compareToUser, IUserConfiguration otherUser);

    public interface IUserConfiguration : IConfiguration
    {
        /// <summary>
        /// Get / Set User Mode, either GMS/EMCS or Unison
        /// </summary>
        ControllerMode UserMode
        {
            get;
        }

        /// <summary>
        /// The user's ID as entered onto the keypad.
        /// </summary>
        int UserId
        {
            get; 
        }

        /// <summary>
        /// The user's PIN number.
        /// </summary>
        int UserPin 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// Get / Set User Name
        /// </summary>
        string Name
        {
            get;
            set;
        }

        /// <summary>
        /// The group the user belongs to.
        /// </summary>
        int GroupId 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// The user is allowed to Disarm areas despite being at an Armed level in the schedule.
        /// </summary>
        bool OutsideHoursAccess 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// The user is allowed to create, edit and delete other users from the keypad.
        /// </summary>
        bool UserManagementPrivilege 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// When Auto Isolate/Deisolate Points is on and the user has permission to isolate points on the area, 
        /// the points in alarm at arming time should be isolated without prompting the user, 
        /// and isolated points should be deisolated when disarming without prompting the user. 
        /// Applicable only for Default operating modes on the keypad.
        /// </summary>
        bool AutoIsolateDeisolatePoints 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// A sequence of areas that the user has permission to Arm / Disarm.
        /// </summary>
        int[] AreaIds 
        { 
            get; 
            set; 
        }

        AreaAccessPrivilege[] AreaAccessPrivilege 
        { 
            get; 
            set; 
        }


        /// <summary>
        /// Get the user accessible areas count
        /// </summary>
        int AreaCount
        {
            get;
        }

        /// <summary>
        /// Check if this is an engineer level user (Access Level 3 user)
        /// </summary>
        bool IsEngineer
        {
            get;
        }

        /// <summary>
        /// Initialize User Configuration Instance with default values.
        /// </summary>
        void InitializeWithDefaults();

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        void InitializeAfterCopy();

        /// <summary>
        /// Get user LastName / FirstName from stored name in format LastName,FirstName
        /// </summary>
        string[] GetLastFirstName();

        /// <summary>
        /// Get user FirstName / LastName from stored name in format FirstName, LastName
        /// </summary>
        string GetFirstLastName();

        /// <summary>
        /// Set user name in storage from an array of LastName,FirstName values.
        /// </summary>
        void SetLastFirstName(string[] lastFirstName);

        /// <summary>
        /// Reset user to defaults
        /// </summary>
        void ResetToDefaults();

        /// <summary>
        /// Copy the properties of current user to [other] user
        /// </summary>
        /// <param name="other">The user instance whose properties will be updated from current user.</param>
        void CopyTo(IUserConfiguration other);

        /// <summary>
        /// Add area identified by [logicalAreaId] id to this user accessible areas if not already added
        /// </summary>
        /// <param name="logicalAreaId">Logical area id, 1 based</param>
        /// <returns>True if the area was added successfuly, False otherwise</returns>
        bool AddAreaById(int logicalAreaId);

        /// <summary>
        /// Replace user areas with those in the areasToAdd list
        /// </summary>
        /// <param name="areasToAdd">List of areas to add.</param>
        void ReplaceAllAreas(List<AreaConfiguration> areasToAdd);

        /// <summary>
        /// Remove area specified by [logicalAreaId] from this user's accessible areas
        /// </summary>
        /// <param name="areaId">Logical area id, i based</param>
        /// <returns>True if the area was successfuly removed, False otherwise.</returns>
        bool RemoveAreaById(int logicalAreaId);

        /// <summary>
        /// Get all accessible areas for this user
        /// </summary>
        /// <param name="areas">The list to which user areas will be added</param>
        /// <returns>True if the user has any areas, False otherwise</returns>
        bool GetAllAreas(out List<AreaConfiguration> areas);

        /// <summary>
        /// Get all user area Ids
        /// </summary>
        /// <returns>List of all area Ids the user has access to.</returns>
        List<int> GetAllAreaIds();

        /// <summary>
        /// Check if this user can access area with [logicalAreaId] id
        /// </summary>
        /// <param name="logicalAreaId">Logical area id to check, 1 based</param>
        /// <returns>True if the user can access this area, False otherwise</returns>
        bool CanAccessArea(int logicalAreaId);

        /// <summary>
        /// Clear all accessible areas for this user
        /// </summary>
        void ClearAreas();

        /// <summary>
        /// Update user PIN
        /// </summary>
        /// <param name="newUserPin">New PIN value</param>
        void ChangePin(int newUserPin);

        /// <summary>
        /// Check if user has isolate privillege for this area
        /// </summary>
        /// <param name="areaId"></param>
        /// <returns></returns>
        bool CanIsolate(int areaId);
    }
}
