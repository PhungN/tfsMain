﻿using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public interface ILegacyReaderConfiguration : IReaderConfiguration
    {
        /// <summary>
        /// A list of up to 4 card format ids that the reader will support. Wiegand 26 bit is included for all readers and doesn't need to be specified.
        /// </summary>
        int[] CardFormatIds { get; set; }

        /// <summary>
        /// Card Formats instance array
        /// </summary>
        LegacyCardFormat[] CardFormats { get; set; }
    }
}
