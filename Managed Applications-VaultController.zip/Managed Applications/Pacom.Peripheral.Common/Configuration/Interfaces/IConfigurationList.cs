﻿using System.Collections.Generic;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    public interface IConfigurationList
    {
        ConfigurationBase GetItem(int logicalId);
        void SetItem(int logicalId, IConfiguration item);
        List<int> AsKeyList { get; }
    }
}