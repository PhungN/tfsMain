﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public interface IReaderConfiguration : INodeConfiguration
    {
        /// <summary>
        /// The 1 based reader number on the parent device.
        /// </summary>
        int PointNumberOnParent { get; set; }

        /// <summary>
        /// Set to true to clear the swiped card from the passback list of all other readers on the controller after a valid access. For example, an exit door.
        /// </summary>
        bool ClearPassbackMemoryOnOtherReaders { get; set; }

        /// <summary>
        /// An alarm area id this reader belongs to. 
        /// 0 if no area.
        /// </summary>
        int AreaId { get; set; }

        /// <summary>
        /// The card reader schedule id for the reader. A value of 0 means “locked/unused”.
        /// </summary>
        int ScheduleId { get; set; }

        /// <summary>
        /// The ids of presence zones this reader enters into.
        /// </summary>
        int[] EnterIntoPresenceZoneIds { get; set; }

        /// <summary>
        /// The ids of presence zones this reader exits out of.
        /// </summary>
        int[] ExitOutOfPresenceZoneIds { get; set; }

        /// <summary>
        /// The number of invalid logon attempts that cause the keypad to be temporarily locked.
        /// </summary>
        int InvalidLogOnAttemptsTillLockout { get; set; }

        /// <summary>
        /// The amount of time the keypad will remain locked after too many invalid logon attempts.
        /// </summary>
        TimeSpan LockoutTime { get; set; }

        /// <summary>
        /// The door instance this reader belongs to
        /// </summary>
        DoorConfiguration Door { get; set; }

        /// <summary>
        /// Reader egress schedule instance
        /// </summary>
        EgressSchedule EgressSchedule { get; set; }

        /// <summary>
        /// Reader schedule instance
        /// </summary>
        ReaderSchedule ReaderSchedule { get; set; }

        /// <summary>
        /// Reader Area instance
        /// </summary>
        AreaConfiguration Area { get; set; }

        /// <summary>
        /// The presence zones this reader enters into.
        /// </summary>
        PresenceZoneConfiguration[] EnterIntoPresenceZones { get; set; }

        /// <summary>
        /// The presence zones this reader exits out of.
        /// </summary>
        PresenceZoneConfiguration[] ExitOutOfPresenceZones { get; set; }

        ReaderCategory ReaderCategory { get; set; }

        /// <summary>
        /// Get reader name from repository
        /// </summary>
        /// <returns>Reader Name</returns>
        string GetName();

        /// <summary>
        /// Auto configure reader
        /// </summary>
        /// <param name="parentDevice"></param>
        /// <param name="pointNumberOnParent"></param>
        void AutoConfigure(DeviceConfigurationBase parentDevice, int pointNumberOnParent);

        /// <summary>
        /// Can be used to delay Automatic Arm"  (On/Off) default Off
        /// </summary>
        bool DelayAutomaticArming { get; set; }

    }
}
