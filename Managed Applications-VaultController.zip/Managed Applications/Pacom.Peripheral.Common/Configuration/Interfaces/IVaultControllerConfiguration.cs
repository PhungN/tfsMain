﻿using System;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public interface IVaultControllerConfiguration : INodeConfiguration
    {
        /// <summary>
        /// The area that this point belongs to.
        /// </summary>        
        int AreaId { get; set; }

        string GetName();

    }
}
