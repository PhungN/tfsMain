﻿
namespace Pacom.Peripheral.Common.Configuration
{
    public interface IInputDeviceConfigurationBase
    {
        /// <summary>
        /// Get / set IO device configured inputs
        /// </summary>
        InputConfiguration[] Inputs { get; set; }

        /// <summary>
        /// Get IO device configured input count
        /// </summary>
        int InputCount { get; }

        /// <summary>
        /// Check if any of the inputs has a valid configuration
        /// </summary>
        bool InputsValid { get; }
    }
}
