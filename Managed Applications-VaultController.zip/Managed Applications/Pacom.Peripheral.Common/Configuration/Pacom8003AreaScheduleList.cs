﻿using System;
using System.IO;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom8003AreaScheduleList : ConfigurationListBase<Pacom8003AreaSchedule>, IConfigurationList
    {
        internal Pacom8003AreaScheduleList() : base() { }

        /// <summary>
        /// Get next area schedule Id
        /// </summary>
        public int NextScheduleId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
