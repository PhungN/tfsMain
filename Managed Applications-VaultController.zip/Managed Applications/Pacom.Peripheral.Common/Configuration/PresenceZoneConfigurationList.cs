﻿using System;
using System.IO;
using System.Collections.Generic;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class PresenceZoneConfigurationList : ConfigurationListBase<PresenceZoneConfiguration>, IConfigurationList
    {
        internal PresenceZoneConfigurationList() : base() { }

        /// <summary>
        /// Get next presence zone Id
        /// </summary>
        public int NextPresenceZoneId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
