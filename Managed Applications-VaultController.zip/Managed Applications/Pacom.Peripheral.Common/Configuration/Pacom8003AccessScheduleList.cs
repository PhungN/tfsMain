﻿using System;
using System.IO;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom8003AccessScheduleList : ConfigurationListBase<Pacom8003AccessSchedule>, IConfigurationList
    {
        internal Pacom8003AccessScheduleList() : base() { }

        /// <summary>
        /// Get next access schedule Id
        /// </summary>
        public int NextScheduleId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
