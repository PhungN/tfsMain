﻿using System.Collections.Generic;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class OutputSchedule : Schedule
    {
        private Dictionary<DayType, ScheduleRecord> schedulesMap = new Dictionary<DayType, ScheduleRecord>();

        public OutputSchedule()
        {
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Schedules == null || Schedules.Length == 0)
                return;
            foreach (var scheduleRecord in Schedules)
            {
                schedulesMap[scheduleRecord.DayType] = scheduleRecord;
            }
        }
    }
}
