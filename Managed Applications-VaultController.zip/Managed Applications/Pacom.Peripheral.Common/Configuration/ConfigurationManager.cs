﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Common.SQLCE;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.Utils;
using Pacom.Serialization.Formatters.Asn1;
using SharpCompress.Archive;
using SharpCompress.Common;

namespace Pacom.Peripheral.Common.Configuration
{
    public partial class ConfigurationManager : IDisposable
    {
        #region Core
        /// <summary>
        /// Lock object needed for synchronizing access to shared configuration data
        /// </summary>
        private static object controllerConfigurationSync = new object();
        public static object ControllerConfigurationSync
        {
            get
            {
                return controllerConfigurationSync;
            }
        }

        /// <summary>
        /// Triggered when the configuration changes.
        /// </summary>
        public event EventHandler<ConfigurationChangeEventArgs> ConfigurationChanged;

        /// <summary>
        /// Triggered just before the configuration has to change.
        /// </summary>
        public event EventHandler<ConfigurationChangeEventArgs> ConfigurationChanging;

        /// <summary>
        /// Triggered after all the configuration changing event handlers have ran.
        /// </summary>
        public event EventHandler<ConfigurationChangeEventArgs> AfterConfigurationChanging;

        /// <summary>
        /// Triggered just before the configuration changed event handlers will ran.
        /// </summary>
        public event EventHandler<ConfigurationChangeEventArgs> BeforeConfigurationChanged;

        /// <summary>
        /// Triggered when configuration is updated to generate a ConfigurationChangeEvent to the front end.
        /// </summary>
        public event EventHandler<ChangedConfigurationEventArgs> InformFrontEndThatConfigurationChanged = null;

        /// <summary>
        /// Triggered when configuration is in progress to generate a ConfigurationChangeInProgressEvent to the front end.
        /// </summary>
        public event EventHandler<ConfigurationChangeInProgressEventArgs> InformFrontEndThatConfigurationChangeInProgress = null;

        /// <summary>
        /// Triggered when a keypad requests a configuration download from the front end.
        /// </summary>
        public event EventHandler ConfigurationDownloadRequest = null;

        /// <summary>
        /// Triggered when a new Raw Card (Credential) is read from the ASN.1 configuration
        /// </summary>
        public event EventHandler<CardDownloadEventArgs> CardDownloadRequest = null;

        /// <summary>
        /// Triggered when a new Raw Card (Credential) is to be deleted
        /// </summary>
        public event EventHandler<CardDeleteEventArgs> CardDeleteRequest = null;

        private Pacom8003Configuration controllerConfiguration;
        private Calendar calendar;
        private readonly ControllerConnectionTable[] controllerConnectionTables = new ControllerConnectionTable[ConfigConsts.MaxControllerConnectionTables];

        /// <summary>
        /// Device configuration list (Pacom devices / Inovonics EchoStream devices / etc.
        /// </summary>
        private DeviceConfigurationList devices = null;

        /// <summary>
        /// Area configuration list
        /// </summary>
        private AreaConfigurationList areas = null;

        /// <summary>
        /// Input configuration list
        /// </summary>
        private InputConfigurationList inputs = null;

        /// <summary>
        /// Output configuration list
        /// </summary>
        private OutputConfigurationList outputs = null;

        /// <summary>
        /// Elevator Controller Groups configuration list
        /// </summary>
        private ElevatorConfigurationList elevators = null;
        private ElevatorFloorConfigurationList elevatorFloors = null;

        /// <summary>
        /// Reader configuration list
        /// </summary>
        private ReaderConfigurationList readers = null;

        /// <summary>
        /// Door configuration list
        /// </summary>
        private DoorConfigurationList doors = null;

        /// <summary>
        /// Interlock Groups configuration list
        /// </summary>
        private InterlockGroupConfigurationList interlockGroups = null;

        /// <summary>
        /// Vault Controller configuration list
        /// </summary>
        private VautControllerConfigurationList vaultControllers = null;
        private VaultControllerInterlockGroupConfigurationList vaultControllerInterlockGroups = null;
        
        /// <summary>
        /// Group configuration list
        /// </summary>
        private GroupConfigurationList groups = null;

        /// <summary>
        /// Presence zone configuration list
        /// </summary>
        private PresenceZoneConfigurationList presenceZones = null;

        /// <summary>
        /// User configuration list
        /// </summary>
        private UserConfigurationList users = null;

        /// <summary>
        /// Macro configuration list
        /// </summary>
        private MacroConfigurationList macros = null;

        /// <summary>
        /// Legacy card format list
        /// </summary>
        private LegacyCardFormatList cardFormats = null;

        /// <summary>
        /// Access Groups List (Unison Access Groups)
        /// </summary>
        private AccessGroupList accessGroups = null;

        /// <summary>
        /// Expansion card configuration list
        /// </summary>
        private ExpansionCardConfigurationList expansionCards = null;

        /// <summary>
        /// Access Schedule list
        /// </summary>
        private Pacom8003AccessScheduleList accessSchedules = null;

        /// <summary>
        /// Area Schedule list
        /// </summary>
        private Pacom8003AreaScheduleList areaSchedules = null;

        /// <summary>
        /// Egress Schedule list
        /// </summary>
        private EgressScheduleList egressSchedules = null;

        /// <summary>
        /// Reader Schedule list
        /// </summary>
        private ReaderScheduleList readerSchedules = null;

        /// <summary>
        /// Output Schedule list
        /// </summary>
        private OutputScheduleList outputSchedules = null;

        /// <summary>
        /// Elevator Floor Unlock Schedule list
        /// </summary>
        private ElevatorFloorUnlockScheduleList elevatorFloorUnlockSchedules = null;
        /// <summary>
        /// Ports List
        /// </summary>
        private PortConfigurationList ports = null;

        /// <summary>
        /// Digital Receiver conversion templates
        /// </summary>
        private readonly Dictionary<int, OpenPacomToDigitalReceiverTemplate> openPacomToDigitalReceiverTemplates = new Dictionary<int, OpenPacomToDigitalReceiverTemplate>();

        private readonly Dictionary<InovonicsDeviceTypeAndSerialNumber, int> inovonicsDeviceIdBySerialNumber = new Dictionary<InovonicsDeviceTypeAndSerialNumber, int>();

        private ISram sram = null;

        private IDataFlash dataFlash = null;

        private IAdc adc = null;

        private INetworkAdapter networkAdapters = null;

        /// <summary>
        /// Checks if logging subcategory is enabled.
        /// </summary>
        /// <param name="subcategory"></param>
        /// <returns></returns>
        public bool IsDebugLoggingSubCategoryEnabled(DebugLoggingSubCategory subcategory)
        {
            if (controllerConfiguration != null)
            {
                if (controllerConfiguration.DebugLoggingSubCategory.Has(subcategory))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Allows to get or set the controller application time zone offset in Sram.
        /// </summary>
        public int TimeZoneOffsetMinutes
        {
            get
            {
                byte[] timeOffset = new byte[4];
                sram.ReadData(SramLocations.TimeZoneOffsetMinutesOffset, timeOffset);
                return BitConverter.ToInt32(timeOffset, 0);
            }
            set
            {
                byte[] timeOffset = BitConverter.GetBytes(value);
                sram.WriteData(SramLocations.TimeZoneOffsetMinutesOffset, timeOffset);
            }
        }

        /// <summary>
        /// Get / Set Unison Checkpoint Tag value, Set 0 = reset to GMS Card Access Mode of operation.
        /// </summary>
        public long UnisonCheckpointTag
        {
            get
            {
                byte[] checkpointTag = new byte[SramLocations.UnisonCheckpointTagLength];
                sram.ReadData(SramLocations.UnisonCheckpointTagOffset, checkpointTag);
                return BitConverter.ToInt64(checkpointTag, 0);
            }
            set
            {
                byte[] checkpointTag = BitConverter.GetBytes(value);
                sram.WriteData(SramLocations.UnisonCheckpointTagOffset, checkpointTag);
            }
        }

        /// <summary>
        /// Reset Unison Checkpoin Tag to default value 0. This will switch the controller to GMS mode of operation,
        /// including Legacy Card Access Control.
        /// </summary>
        public void ResetUnisonCheckpointTag()
        {
            UnisonCheckpointTag = 0;
        }

        /// <summary>
        /// Check if the 8003 controller is set to work in Unison Card Access Control Mode.
        /// </summary>
        public bool IsUnisonMode
        {
            get;
            set;
        }

        private IAccessCardManager accessCardManager;

        bool hasItemBeenRemoved(ConfigurationElementType itemType, int itemId, List<ConfigurationChanges> additions, List<ConfigurationChanges> removals)
        {
            bool foundInRemovedItems = false;
            foreach (var removedItem in removals)
            {
                if (removedItem.ConfigurationType == itemType && removedItem.Id == itemId)
                {
                    foundInRemovedItems = true;
                    break;
                }
            }
            if (foundInRemovedItems)
            {
                // If an item is in both lists it has changed parent but is still present.
                foreach (var newlyAddedItem in additions)
                {
                    if (newlyAddedItem.ConfigurationType == itemType && newlyAddedItem.Id == itemId)
                    {
                        foundInRemovedItems = false;
                        break;
                    }
                }
            }
            return foundInRemovedItems;
        }

        /// <summary>
        /// Make sure Unison Checkpoint Tag is valid. This is required because the SRAM might not be empty at the
        /// location where the Unison Checkpoint Tag is positioned and reading it will give incorrect results. Because
        /// of this we need to make sure there is no GMS configuration present before we commit to Unison.
        /// </summary>
        bool isConfigurationConsistent(List<ConfigurationChanges> additions, List<ConfigurationChanges> removals)
        {
            bool hasGMSConfig = false;
            bool hasUnisonConfig = false;

            // Restart the broadcastDeleteAllCardsTimer if it is running.
            if (broadcastDeleteAllCardsTimer != null)
                broadcastDeleteAllCardsTimer.Change(300000, 0);

            // Check Readers
            foreach (var reader in readers.AsList)
            {
                if (hasItemBeenRemoved(ConfigurationElementType.Reader, reader.Id, additions, removals))
                    continue;

                if (reader is ILegacyReaderConfiguration)
                    hasGMSConfig = true;
                else
                    hasUnisonConfig = true;
            }

            // Check a User
            // We won't check all users as in Unison mode ther may be many thousands but check at least one incase there are no access control elements configured.

            // Need to set IsUnisonMode so that the User checks behave as needed.
            IsUnisonMode = true;
            int lowestUserId = Users.GetLowestId();
            if (lowestUserId > 0)
            {
                IUserConfiguration user = Users[lowestUserId];
                if (user != null && user is UserUnisonConfiguration)
                {
                    hasUnisonConfig = true;
                }
            }

            IsUnisonMode = false;
            lowestUserId = Users.GetLowestId();
            if (lowestUserId > 0)
            {
                IUserConfiguration user = Users[lowestUserId];
                if (user != null && user is UserConfiguration)
                {
                    hasGMSConfig = true;
                }
            }

            if (hasGMSConfig == true && hasUnisonConfig == false)
            {
                if (accessCardManager.DatabaseMode == CardAccessDatabaseMode.Unison)
                {
                    accessCardManager.DeleteAllCardsLocally();
                    // We are not in a position here to broadcast the delete to the peripherals as the configuration is changing.
                    // We will start a 5 minute timer to give everything a chance to come online and then inform them of the delete.
                    if (broadcastDeleteAllCardsTimer == null)
                        broadcastDeleteAllCardsTimer = TimerManager.Instance.CreateTimer(broadcastDeleteAllCardsTimerCallback, null, 300000, Timeout.Infinite);
                }
                ResetUnisonCheckpointTag();

                // We are in GMS mode and all is well.
                IsUnisonMode = false;
                return true;
            }

            if (hasGMSConfig == false && hasUnisonConfig == true)
            {
                if (accessCardManager.DatabaseMode == CardAccessDatabaseMode.Gms)
                {
                    accessCardManager.DeleteAllCardsLocally();
                    // We are not in a position here to broadcast the delete to the peripherals as the configuration is changing.
                    // We will start a 5 minute timer to give everything a chance to come online and then inform them of the delete.
                    if (broadcastDeleteAllCardsTimer == null)
                        broadcastDeleteAllCardsTimer = TimerManager.Instance.CreateTimer(broadcastDeleteAllCardsTimerCallback, null, 300000, Timeout.Infinite);
                }

                // We are in Unison mode and all is well.
                IsUnisonMode = true;
                return true;
            }

            if (hasGMSConfig == false && hasUnisonConfig == false)
            {
                // There is no conflicting configuration.
                if (accessCardManager.DatabaseMode == CardAccessDatabaseMode.Gms)
                    IsUnisonMode = false;
                else
                    IsUnisonMode = true;
                return true;
            }

            // We have a bad mix of configuration / Unison Tag and database mode
            // We will delete all reader and user configuration, clear the access database and remote the Unison Tag to
            // restore the system to a good state.
            Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
            {
                return "The configuration is inconsistent. Partially defaulting the configuration.";
            });

            IsUnisonMode = true;
            accessCardManager.DeleteAllCardsLocally();
            // We are not in a position here to broadcast the delete to the peripherals as the configuration is changing.
            // We will start a 5 minute timer to give everything a chance to come online and then inform them of the delete.
            if (broadcastDeleteAllCardsTimer == null)
                broadcastDeleteAllCardsTimer = TimerManager.Instance.CreateTimer(broadcastDeleteAllCardsTimerCallback, null, 300000, Timeout.Infinite);
            return false;
        }

        IPacomTimer broadcastDeleteAllCardsTimer = null;
        private void broadcastDeleteAllCardsTimerCallback(object state)
        {
            try
            {
                TimerManager.Instance.RemoveTimer(broadcastDeleteAllCardsTimer);
                broadcastDeleteAllCardsTimer = null;

                if (CardDownloadRequest != null)
                {
                    // Notify AccessControlManager that a new card has been downloaded and needs to be
                    // added to SRAM / SD Card database
                    CardDownloadRequest(this, new CardDownloadEventArgs(null, true));
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Failed broadcasting delete all cards. {0}", ex.ToString());
                });
            }
        }

        private int gettimeZoneBias()
        {
            byte[] timeOffset = new byte[4];
            sram.ReadData(SramLocations.TimeZoneOffsetMinutesOffset, timeOffset);
            int timeZoneBias = BitConverter.ToInt32(timeOffset, 0);
            if (timeZoneBias > (60 * 24) || timeZoneBias < (-60 * 24))
            {
                timeZoneBias = 0;
                timeOffset = new byte[] { 0, 0, 0, 0 };
                sram.WriteData(SramLocations.TimeZoneOffsetMinutesOffset, timeOffset);
            }
            return timeZoneBias;
        }

        /// <summary>
        /// Gets the local time from controller UTC local time
        /// </summary>
        public DateTime ToLocalTime(DateTime controllerUtcTime)
        {
            int timeZoneBias = gettimeZoneBias();
            return controllerUtcTime.AddMinutes(timeZoneBias);
        }

        public DateTime ToUtcTime(DateTime localTime)
        {
            int timeZoneBias = gettimeZoneBias();
            return localTime.AddMinutes(-timeZoneBias);
        }

        private static ConfigurationManager instance = null;

        public ConfigurationChangeInProgressEventManager ConfigurationChangeEventManager
        {
            get;
            private set;
        }

        public event EventHandler<LogonDateTimeEventArgs> LogonDateTimeEvent;
        public void SetLogonDateTime(DateTime dateTime, int timeZoneOffsetMinutes, int connectionTableIndex)
        {
            if (LogonDateTimeEvent != null)
            {
                LogonDateTimeEvent(this, new LogonDateTimeEventArgs(dateTime, timeZoneOffsetMinutes, connectionTableIndex));
            }
        }

        private ConfigurationManager(ISram sram, IDataFlash dataFlash, INetworkAdapter networkAdapters, IAccessCardManager accessCardManager, IAdc adc)
        {
            this.sram = sram;
            this.networkAdapters = networkAdapters;
            this.dataFlash = dataFlash;
            this.adc = adc;
            this.accessCardManager = accessCardManager;

            devices = new DeviceConfigurationList();
            expansionCards = new ExpansionCardConfigurationList();
            areas = new AreaConfigurationList();
            inputs = new InputConfigurationList();
            outputs = new OutputConfigurationList();
            elevators = new ElevatorConfigurationList();
            elevatorFloors = new ElevatorFloorConfigurationList();
            readers = new ReaderConfigurationList();
            doors = new DoorConfigurationList();
            interlockGroups = new InterlockGroupConfigurationList();
            vaultControllerInterlockGroups = new VaultControllerInterlockGroupConfigurationList();
            groups = new GroupConfigurationList();
            presenceZones = new PresenceZoneConfigurationList();
            ports = new PortConfigurationList();
            macros = new MacroConfigurationList();
            accessGroups = new AccessGroupList();
            cardFormats = new LegacyCardFormatList();
            accessSchedules = new Pacom8003AccessScheduleList();
            areaSchedules = new Pacom8003AreaScheduleList();
            egressSchedules = new EgressScheduleList();
            readerSchedules = new ReaderScheduleList();
            outputSchedules = new OutputScheduleList();
            elevatorFloorUnlockSchedules = new ElevatorFloorUnlockScheduleList();
            ConfigurationChangeEventManager = ConfigurationChangeInProgressEventManager.Instance;
        }

        public static ConfigurationManager CreateInstance(ISram sram, IDataFlash dataFlash, INetworkAdapter networkAdapters, IAccessCardManager cardManager, IAdc adc)
        {
            if (instance == null)
            {
                instance = new ConfigurationManager(sram, dataFlash, networkAdapters, cardManager, adc);

                // The UserConfigurationListSDCard constructor needs to call IsUnisonMode so must be called after
                // ConfigurationManager has been constructed. This could be achieved with an additional call from
                // the Program class to ConfigurationManager but is cleaner to do it here.
                if (SqlCeDatabase.Instance.DefaultDatabaseIsValid == true)
                    instance.users = new UserConfigurationListSDCard();
                else
                    instance.users = new UserConfigurationListFile();
            }
            return instance;
        }

        public static ConfigurationManager Instance
        {
            get
            {
                return instance;
            }
        }

        public Pacom8003Configuration ControllerConfiguration
        {
            get { return controllerConfiguration; }
        }

        public Calendar Calendar
        {
            get { return calendar; }
        }

        public DeviceConfigurationBase[] Devices
        {
            get { return devices.AsArray; }
        }

        public void ExtractKeypadBitmap()
        {
            string keypadBitmapPath = FileSystemPaths.KeypadBitmapFile;
            try
            {
                DirectoryExtensions.Recreate(FileSystemPaths.KeypadBitmapDirectory);
                using (FileStream fileStream = File.OpenRead(keypadBitmapPath))
                {
                    using (IArchive archive = ArchiveFactory.Open(fileStream, Options.LookForHeader))
                    {
                        foreach (IArchiveEntry archiveEntry in archive.Entries)
                        {
                            if (archiveEntry.IsDirectory == false)
                                archiveEntry.WriteToDirectory(FileSystemPaths.KeypadBitmapDirectory, ExtractOptions.Overwrite);
                        }
                    }
                    fileStream.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public List<Device1076VCConfiguration> VaultControllerDevices
        {
            get
            {
                List<Device1076VCConfiguration> vaultControllerDevices = new List<Device1076VCConfiguration>();
                foreach (var device in devices.AsArray)
                {
                    Device1076VCConfiguration vaultController = device as Device1076VCConfiguration;
                    if (vaultController != null)
                        vaultControllerDevices.Add(vaultController);
                }
                return vaultControllerDevices;
            }
        }

        public string GetVaultName(int vaultNumber)
        {
            string vaultName = "";
            foreach (var device in VaultControllerDevices)
            {
                if (device.VaultControllerNumber == vaultNumber)
                {
                    vaultName = device.VaultName;
                    if (string.IsNullOrEmpty(vaultName) == true)
                        vaultName = string.Format("Vault {0}", vaultNumber.ToString("D2"));
                    break;
                }
            }
            return vaultName;
        }

        //public Device1076VCConfiguration this[int vaultControllerNumber]
        //{
        //    get
        //    {
        //        foreach (var device in VaultControllerDevices)
        //        {
        //            if (device.VaultControllerNumber == vaultControllerNumber)
        //                return device;
        //        }
        //        return null;
        //    }
        //}

        public int VaultControllerCount
        {
            get
            {
                return VaultControllerDevices.Count;
            }
        }

        /// <summary>
        /// Get Inovonics Serial Receiver configuration instance
        /// </summary>
        public DeviceConfigurationBase InovonicsSerialReceiver
        {
            get { return devices.AsArray.FirstOrDefault(device => device.HardwareType == HardwareType.InovonicsSerialReceiver); }
        }

        /// <summary>
        /// Get Inovonics Serial Receiver Id, fallback to controller Id if the Serial Receiver was not configured
        /// </summary>
        public int InovonicsSerialReceiverId
        {
            get
            {
                DeviceConfigurationBase serialReceiverConfig = InovonicsSerialReceiver;
                if (serialReceiverConfig != null)
                    return serialReceiverConfig.Id;
                return controllerConfiguration.Id;
            }
        }

        public AreaConfiguration[] AreasAsArray
        {
            get { return areas.AsArray; }
        }

        public AreaConfigurationList Areas
        {
            get { return areas; }
        }

        public List<AreaConfiguration> ModeFollowAreas
        {
            get
            {
                return areas.AsList.Select(area => area.Enabled && area.AreaModeFollowsConfigured);
            }
        }

        public int AreaCount
        {
            get { return areas.Count; }
        }

        public bool AnyAreasExist
        {
            get { return areas.IsEmpty == false; }
        }

        public bool ContainsArea(int areaId)
        {
            return areas.Exists(areaId);
        }

        public bool ContainsInput(int inputId)
        {
            return inputs.Exists(inputId);
        }

        /// <summary>
        /// True if any of the enabled configured areas can handle sequential alarm confirmation (alarm confirmation time flag is True)
        /// </summary>
        public bool AlarmConfirmationTimeEnabled
        {
            get
            {
                return areas.AsList.FirstOrDefault(area => area != null && area.Enabled == true && area.EnableAlarmConfirmationTime == true) != null;
            }
        }

        public DoorConfiguration[] Doors
        {
            get { return doors.AsArray; }
        }

        public InterlockGroupConfiguration[] InterlockGroups
        {
            get { return interlockGroups.AsArray; }
        }

        public VaultControllerInterlockGroupConfiguration[] VaultControllerInterlockGroups
        {
            get { return vaultControllerInterlockGroups.AsArray; }
        }

        public InputConfiguration[] Inputs
        {
            get { return inputs.AsArray; }
        }

        public OutputConfiguration[] Outputs
        {
            get { return outputs.AsArray; }
        }

        public IElevatorConfiguration[] Elevators
        {
            get { return elevators.AsArray; }
        }

        public ElevatorFloorConfiguration[] ElevatorFloors
        {
            get { return elevatorFloors.AsArray; }
        }

        public ExpansionCardDeviceConfigurationBase[] ExpansionCards
        {
            get { return expansionCards.AsArray; }
        }

        public IReaderConfiguration[] Readers
        {
            get { return readers.AsArray; }
        }

        public PresenceZoneConfiguration[] PresenceZones
        {
            get { return presenceZones.AsArray; }
        }

        public UserConfigurationList Users
        {
            get { return users; }
        }

        public AccessGroup[] AccessGroups
        {
            get { return accessGroups.AsArray; }
        }

        public PortConfigurationList Ports
        {
            get { return ports; }
        }

        public List<MacroConfiguration> Macros
        {
            get { return macros.AsList; }
        }

        public ReaderSchedule[] ReaderSchedules
        {
            get { return readerSchedules.AsArray; }
        }

        public Pacom8003AreaSchedule[] AreaSchedules
        {
            get { return areaSchedules.AsArray; }
        }

        public Pacom8003AccessSchedule[] AccessSchedules
        {
            get { return accessSchedules.AsArray; }
        }

        public EgressSchedule[] EgressSchedules
        {
            get { return egressSchedules.AsArray; }
        }

        public OutputScheduleList OutputSchedules
        {
            get { return outputSchedules; }
        }

        public ElevatorFloorUnlockScheduleList ElevatorFloorUnlockSchedules
        {
            get { return elevatorFloorUnlockSchedules; }
        }

        /// <summary>
        /// Get the device configuration including the controller
        /// </summary>
        /// <param name="logicalId">Device logical Id, includes the controller logical Id</param>
        /// <returns>Device configuration instance</returns>
        public DeviceConfigurationBase GetDeviceConfiguration(int logicalId)
        {
            if (controllerConfiguration.Id == logicalId)
                return controllerConfiguration;
            return devices[logicalId];
        }

        public ExpansionCardDeviceConfigurationBase GetExpansionCardDeviceConfiguration(int logicalId)
        {
            return expansionCards[logicalId];
        }

        public AreaConfiguration GetAreaConfiguration(int logicalId)
        {
            return areas[logicalId];
        }

        public InputConfiguration GetInputConfiguration(int logicalId)
        {
            return inputs[logicalId];
        }

        public string GetInputName(int logicalId)
        {
            InputConfiguration inputConfig = inputs[logicalId];
            if (inputConfig != null)
                return inputConfig.GetName();
            return string.Empty;
        }

        public OutputConfiguration GetOutputConfiguration(int logicalId)
        {
            return outputs[logicalId];
        }

        public IElevatorConfiguration GetElevatorConfiguration(int logicalId)
        {
            return elevators[logicalId];
        }

        public ElevatorFloorConfiguration GetElevatorFloorConfiguration(int logicalId)
        {
            return elevatorFloors[logicalId];
        }

        public DoorConfiguration GetDoorConfiguration(int logicalId)
        {
            return doors[logicalId];
        }

        public InterlockGroupConfiguration GetInterlockGroupConfiguration(int logicalId)
        {
            return interlockGroups[logicalId];
        }

        public VaultControllerInterlockGroupConfiguration GetVaultControllerInterlockGroupConfiguration(int logicalId)
        {
            return vaultControllerInterlockGroups[logicalId];
        }

        public IVaultControllerConfiguration GetVaultControllerConfiguration(int logicalId)
        {
            if(devices[logicalId] != null)
                return devices[logicalId] as IVaultControllerConfiguration;
            return null;
        }
        /// <summary>
        /// Get door logical id from reader logical id
        /// </summary>
        /// <param name="logicalReaderId">Reader logical id.</param>
        /// <returns>Door logical id, -1 if door not found.</returns>
        public int GetLogicalDoorId(int logicalReaderId)
        {
            if (logicalReaderId < 1)
                return 0;
            return doors.GetDoorLogicalId(logicalReaderId);
        }

        /// <summary>
        /// Get the logical reader id on which the door inputs and outputs are located
        /// </summary>
        /// <param name="logicalReaderId">Reader logical id.</param>
        /// <returns>Door logical id, 0 if door not found.</returns>
        public int GetMasterReaderId(int logicalDoorId)
        {
            if (logicalDoorId < 1)
                return 0;

            DoorConfiguration door = doors[logicalDoorId];
            if (door != null && door.Enabled == true)
            {
                if (door.InReader != null && door.InReader.Enabled == true)
                    return door.InReader.Id;
            }

            return 0;
        }

        /// <summary>
        /// Return an array of logical reader ids existing on logical device.
        /// </summary>
        /// <param name="logicalDeviceId">Logical device id</param>
        /// <returns></returns>
        public int[] GetReaderIdsForDevice(int logicalDeviceId)
        {
            List<int> deviceIds = new List<int>();
            foreach (var r in this.Readers)
            {
                if (r.ParentDeviceId == logicalDeviceId)
                    deviceIds.Add(r.Id);
            }
            return deviceIds.ToArray();
        }

        /// <summary>
        /// Return a logical reader id for a particular reader.
        /// </summary>
        /// <param name="logicalDeviceId">Logical device id</param>
        /// <param name="pointNumberOnParent">The point number on the device.</param>
        /// <returns></returns>
        public int GetReaderIdForDevice(int logicalDeviceId, int pointNumberOnParent)
        {
            foreach (IReaderConfiguration reader in this.Readers)
            {
                if (reader.ParentDeviceId == logicalDeviceId && reader.PointNumberOnParent == pointNumberOnParent)
                    return reader.Id;
            }
            return 0;
        }

        /// <summary>
        /// Return an array of logical door ids existing on logical device.
        /// </summary>
        /// <param name="logicalDeviceId">Logical device id</param>
        /// <returns></returns>
        public int[] GetDoorIdsForDevice(int logicalDeviceId)
        {
            List<int> deviceIds = new List<int>();
            foreach (var d in this.Doors)
            {
                if (d.ParentDeviceId == logicalDeviceId)
                    deviceIds.Add(d.Id);
            }
            return deviceIds.ToArray();
        }

        public GroupConfiguration GetGroupConfiguration(int logicalId)
        {
            return groups[logicalId];
        }

        public GroupConfigurationList UserGroups
        {
            get { return groups; }
        }

        public List<GroupConfiguration> Groups
        {
            get { return groups.AsList; }
        }

        public PresenceZoneConfiguration GetPresenceZoneConfiguration(int logicalId)
        {
            return presenceZones[logicalId];
        }

        public IReaderConfiguration GetReaderConfiguration(int logicalId)
        {
            return readers[logicalId];
        }

        public AccessGroup GetAccessGroupConfiguration(int logicalId)
        {
            return accessGroups[logicalId];
        }

        public LegacyCardFormat GetLegacyCardFormatConfiguration(int logicalId)
        {
            return cardFormats[logicalId];
        }

        public Pacom8003AccessSchedule GetAccessSchedule(int logicalId)
        {
            return accessSchedules[logicalId];
        }

        public Pacom8003AreaSchedule GetAreaSchedule(int logicalId)
        {
            return areaSchedules[logicalId];
        }

        public EgressSchedule GetEgressSchedule(int logicalId)
        {
            return egressSchedules[logicalId];
        }

        public ReaderSchedule GetReaderSchedule(int logicalId)
        {
            return readerSchedules[logicalId];
        }

        public OutputSchedule GetOutputSchedule(int logicalId)
        {
            return outputSchedules[logicalId];
        }

        public ElevatorFloorUnlockSchedule GetElevatorFloorUnlockSchedule(int logicalId)
        {
            return elevatorFloorUnlockSchedules[logicalId];
        }

        public ControllerConnectionTable GetControllerConnectionTable(int index)
        {
            if (index != 0 && index != 1)
                return null;

            return controllerConnectionTables[index];
        }

        /// <summary>
        /// Check if the controller has any connection to front-end configured.
        /// </summary>
        public bool FrontEndConnectionConfigured
        {
            get
            {
                ControllerConnectionTable firstConnectionTable = GetControllerConnectionTable(0);
                ControllerConnectionTable secondConnectionTable = GetControllerConnectionTable(1);
                if ((firstConnectionTable == null || firstConnectionTable.ConnectionEntry.Length == 0) &&
                    (secondConnectionTable == null || secondConnectionTable.ConnectionEntry.Length == 0))
                    return false;
                return true;
            }
        }

        public ControllerConnectionTable CreateConnectionTable(int id)
        {
            ControllerConnectionTable table = new ControllerConnectionTable(sram);
            table.InitializeWithDefaults();
            table.Id = id;
            return table;
        }

        public OpenPacomToDigitalReceiverTemplate GetOpenPacomToDigitalReceiverTemplate(int index)
        {
            OpenPacomToDigitalReceiverTemplate template = null;
            if (openPacomToDigitalReceiverTemplates.TryGetValue(index, out template) == true)
                return template;
            return null;
        }

        public bool ValidateUserSchedule(int userId)
        {
            var user = Users[userId] as UserConfigurationBase;
            if (user != null)
            {
                // We could create a new Basic schedule class that is identical to the existing Egress schedule
                // or rename the Egress schedule but for the time being, we will just use the Egress schedule as is.
                EgressSchedule schedule = ConfigurationManager.Instance.GetEgressSchedule(user.ScheduleId);
                if (schedule == null || schedule.Enabled)
                    return true;
            }
            return false;
        }

        public bool ValidateReaderSchedule(int scheduleId)
        {
            return ValidateSchedule(GetReaderSchedule(scheduleId));
        }

        public bool ValidateSchedule(Schedule schedule)
        {
            if (schedule == null)
                return false;

            EgressScheduleLevel level = EgressScheduleLevel.Disabled;
            DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
            DayType todayDayType = StatusManager.TodayDayType;
            foreach (var scheduleRecord in schedule.Schedules)
            {
                if (scheduleRecord.DayType == todayDayType)
                {
                    foreach (var interval in scheduleRecord.Intervals)
                    {
                        if (interval == null)
                            continue;
                        if (now.Hour > interval.StartTime.Hour ||
                            (now.Hour == interval.StartTime.Hour && now.Minute >= interval.StartTime.Minute))
                        {
                            if (Enum.IsDefined(typeof(EgressScheduleLevel), interval.Level))
                                level = (EgressScheduleLevel)interval.Level;
                            else
                                level = (EgressScheduleLevel)0;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }
            return level == EgressScheduleLevel.Enabled;
        }

        public ScheduleRecord GetTodaySchedule(Schedule schedule)
        {
            if (schedule != null)
            {
                DayType todayDayType = StatusManager.TodayDayType;
                foreach (var scheduleRecord in schedule.Schedules)
                {
                    if (scheduleRecord.DayType == todayDayType)
                        return scheduleRecord;
                }
            }
            return null;
        }       

        /// <summary>
        /// Read configuration for specific nodes and update next Id
        /// </summary>
        private void resetNextIds()
        {
            devices.ResetNextItemId();
            areas.ResetNextItemId();
            inputs.ResetNextItemId();
            outputs.ResetNextItemId();
            elevators.ResetNextItemId();
            elevatorFloors.ResetNextItemId();
            readers.ResetNextItemId();
            doors.ResetNextItemId();
            interlockGroups.ResetNextItemId();
            vaultControllerInterlockGroups.ResetNextItemId();
            groups.ResetNextItemId();
            presenceZones.ResetNextItemId();
            macros.ResetNextItemId();
            ports.ResetNextItemId();
        }

        /// <summary>
        /// Next available logical device Id, this must be unique for any devices including expansion cards
        /// </summary>
        public int NextDeviceId(HardwareType hardwareType)
        {
            return devices.NextDeviceId(hardwareType, expansionCards);
        }

        /// <summary>
        /// Next available logical port Id, this must be unique for any devices including expansion cards
        /// </summary>
        public int NextPortId
        {
            get { return ports.NextPortId; }
        }

        /// <summary>
        /// Next area Id
        /// </summary>
        public int NextAreaId
        {
            get { return areas.NextAreaId; }
        }

        /// <summary>
        /// Next Card Reader Id
        /// </summary>
        public int NextReaderId
        {
            get { return readers.NextReaderId; }
        }

        /// <summary>
        /// Next Door Id
        /// </summary>
        public int NextDoorId
        {
            get { return doors.NextDoorId; }
        }

        /// <summary>
        /// Next Interlock Group Id
        /// </summary>
        public int NextInterlockGroupId
        {
            get { return interlockGroups.NextInterlockGroupId; }
        }

        /// <summary>
        /// Next Vault Controller Interlock Group Id
        /// </summary>
        public int NextVaultControllerInterlockGroupId
        {
            get { return vaultControllerInterlockGroups.NextInterlockGroupId; }
        }

        /// <summary>
        /// Next Input Id
        /// </summary>
        public int NextInputId
        {
            get { return inputs.NextInputId; }
        }

        /// <summary>
        /// Next Output Id
        /// </summary>
        public int NextOutputId
        {
            get { return outputs.NextOutputId; }
        }

        public int NextOpenPacomToDigitalReceiverTemplateId
        {
            get
            {
                int maxId = 0;
                foreach (ControllerConnectionTable table in controllerConnectionTables)
                {
                    if (table != null && table.Id > maxId)
                        maxId = table.Id;
                }
                return maxId + 1;
            }
        }

        /// <summary>
        /// Check if the Inovonics device with the "serialNumber"  and "deviceType" was already configured and is available
        /// </summary>
        /// <param name="serialNumber">Inovonics device SerialNumber</param>
        /// <param name="deviceId">Return the logical device Id if found</param>
        /// <returns></returns>
        public bool GetInovonicsLogicalDeviceIdFromSerialNumber(InovonicsDeviceType deviceType, int serialNumber, ref int deviceId)
        {
            InovonicsDeviceTypeAndSerialNumber inovonicsDevice = new InovonicsDeviceTypeAndSerialNumber() 
                { DeviceType = deviceType, SerialNumber = serialNumber };
            return inovonicsDeviceIdBySerialNumber.TryGetValue(inovonicsDevice, out deviceId);
        }

        /// <summary>
        /// Updates the serial number of the Inovonics Serial Receiver.
        /// </summary>
        /// <param name="newSerialNumber"></param>
        public void UpdateInovonicsSerialReceiverSerialNumber(int newSerialNumber)
        {
            InovonicsDeviceConfigurationBase serialReceiverConfig = InovonicsSerialReceiver as InovonicsDeviceConfigurationBase;
            if (serialReceiverConfig != null)
            {
                InovonicsReceiverDeviceConfiguration updatedConfiguration = new InovonicsReceiverDeviceConfiguration();
                CopyConfiguration(serialReceiverConfig, updatedConfiguration);
                updatedConfiguration.DeviceLoopAddress = newSerialNumber;
                List<ConfigurationBase> configuration = new List<ConfigurationBase>();
                configuration.Add(updatedConfiguration);
                UpdateConfiguration(configuration, false, ConfigurationManager.SystemUser, true);
            }
        }

        /// <summary>
        /// Returns an array of LogicalIds belonging to Inovonics devices.
        /// </summary>
        /// <returns></returns>
        public int[] InovonicsDeviceLogicalIdsAsArray
        {
            get { return (new List<int>(inovonicsDeviceIdBySerialNumber.Values)).ToArray(); }
        }

        public int GetEnabledInputsCount()
        {
            int enabledInputsCount = 0;
            foreach (var input in ControllerConfiguration.Inputs)
            {
                if (input != null && input.Enabled == true)
                    enabledInputsCount += 1;
            }

            foreach (var device in Devices)
            {
                if (device is IDeviceLoopIODevice)
                {
                    foreach (var input in ((IDeviceLoopIODevice)device).Inputs)
                    {
                        if (input != null && input.Enabled == true)
                            enabledInputsCount += 1;
                    }
                }
            }

            return enabledInputsCount;
        }

        public int GetEnabledOutputsCount()
        {
            int enabledOutputsCount = 0;
            foreach (var output in ControllerConfiguration.Outputs)
            {
                if (output != null && output.Enabled == true)
                    enabledOutputsCount += 1;
            }

            foreach (var device in Devices)
            {
                if (device is IDeviceLoopIODevice)
                {
                    foreach (var output in ((IDeviceLoopIODevice)device).Outputs)
                    {
                        if (output != null && output.Enabled == true)
                            enabledOutputsCount += 1;
                    }
                }
            }

            return enabledOutputsCount;
        }

        public int GetEnabledReadersCount()
        {
            int enabledReadersCount = 0;
            foreach (var reader in ControllerConfiguration.Readers)
            {
                if (reader != null && reader.Enabled == true)
                    enabledReadersCount += 1;
            }

            foreach (var device in Devices)
            {
                if (device is IDeviceLoopDCDevice)
                {
                    foreach (var reader in ((IDeviceLoopDCDevice)device).Readers)
                    {
                        if (reader != null && reader.Enabled == true)
                            enabledReadersCount += 1;
                    }
                }
            }

            return enabledReadersCount;
        }

        public int GetEnabledDoorsCount()
        {
            int enabledDoorsCount = 0;
            foreach (var door in ControllerConfiguration.Doors)
            {
                if (door != null && door.Enabled == true)
                    enabledDoorsCount += 1;
            }

            foreach (var device in Devices)
            {
                if (device is IDeviceLoopDCDevice)
                {
                    foreach (var door in ((IDeviceLoopDCDevice)device).Doors)
                    {
                        if (door != null && door.Enabled == true)
                            enabledDoorsCount += 1;
                    }
                }
            }

            return enabledDoorsCount;
        }

        public bool BeepReaderWhenCardPresent
        {
            get
            {
                Port8003RS485OsdpDeviceLoopPortConfiguration portRs485OSPD = GetRS485OsdpPortConfiguration();
                if (portRs485OSPD != null)
                    return portRs485OSPD.BeepReaderWhenCardPresent;
                return false;
            }
        }

        public Port8003RS485OsdpDeviceLoopPortConfiguration GetRS485OsdpPortConfiguration()
        {
            foreach (var port in Ports.AsArray)
            {
                if (port != null)
                {
                    Port8003RS485OsdpDeviceLoopPortConfiguration portRs485Osdp = port as Port8003RS485OsdpDeviceLoopPortConfiguration;
                    if (portRs485Osdp != null)
                    {
                        return portRs485Osdp;
                    }
                }
            }
            return null;
        }
        #endregion

        #region Loading configuration from disk

        /// <summary>
        /// Get the list of types from assembly
        /// </summary>
        /// <returns>Hashed list of types</returns>
        private static HashTypeLookup getListOfTypes()
        {
            HashTypeLookup lookup = new HashTypeLookup(new List<Assembly>() { 
                                                             Assembly.Load("Pacom.Shared.Configuration"), 
                                                             Assembly.Load("Pacom.Shared.Access") 
                                                           });
            lookup.AddType(typeof(Pacom.Core.Contracts.Schedule));
            lookup.AddType(typeof(Pacom.Core.Contracts.AreaAccessPrivilege));
            return lookup;
        }

        public int MaxConfigInitRetryCount = 3;

        public bool DefaultingConfiguration
        {
            get;
            private set;
        }

        public void CreateInitialConfiguration(UserAuditInfo userAuditInfo)
        {
            // The reason has changed here
            Logger.LogCriticalMessage(LoggerClassPrefixes.ConfigurationManager, () =>
            {
                return string.Format("File {0} not found. Retry \"File.Exists\" {1} more times in case there was a temporary issue !",
                    FileSystemPaths.DevicesConfigFilePath, MaxConfigInitRetryCount);
            });
            int count = 0;
            while (count < MaxConfigInitRetryCount)
            {
                if (File.Exists(FileSystemPaths.DevicesConfigFilePath) == false)
                {
                    Logger.LogCriticalMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("File {0} not found. Controller will be re-initialized and all devices auto-configured !",
                            FileSystemPaths.DevicesConfigFilePath);
                    });
                }

                count++;
                if (count == MaxConfigInitRetryCount)
                {
                    try
                    {
                        Logger.LogCriticalMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return string.Format("File {0} not found after {1} retries. Controller will be re-initialized and all devices auto-configured !",
                                                 FileSystemPaths.DevicesConfigFilePath, MaxConfigInitRetryCount);
                        });
                        // Backup the Configuration directory
                        if (Directory.Exists(FileSystemPaths.BackupConfigurationDirectory) == true)
                        {
                            string[] filesToDelete = Directory.GetFiles(FileSystemPaths.BackupConfigurationDirectory);
                            foreach (string sourceDeleteFile in filesToDelete)
                            {
                                File.Delete(sourceDeleteFile);
                                while (File.Exists(sourceDeleteFile))
                                    Thread.Sleep(1);
                            }
                            Directory.Delete(FileSystemPaths.BackupConfigurationDirectory);
                        }
                        Directory.CreateDirectory(FileSystemPaths.BackupConfigurationDirectory);

                        if (Directory.Exists(FileSystemPaths.ConfigurationDirectory) == true)
                        {
                            string[] files = Directory.GetFiles(FileSystemPaths.ConfigurationDirectory);
                            foreach (string sourceFile in files)
                            {
                                string destinationFile = Path.Combine(FileSystemPaths.BackupConfigurationDirectory, Path.GetFileName(sourceFile));
                                File.Copy(sourceFile, destinationFile);
                                Thread.Sleep(1);
                            }
                            MarkAllConfigurationFilesAsModified();
                            foreach (string sourceFile in files)
                            {
                                File.Delete(sourceFile);
                                while (File.Exists(sourceFile))
                                    Thread.Sleep(1);
                            }
                        }
                    }
                    catch (IOException ex)
                    {
                        Logger.LogCriticalMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return string.Format("IO exception thrown while trying to backup configuration: {0}", ex.ToString());
                        });
                    }
                    catch (Exception ex)
                    {
                        Logger.LogCriticalMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return string.Format("Unknown exception thrown while trying to backup configuration: {0}", ex.ToString());
                        });
                    }
                    
                    // Unison checkpoint tag is no longer valid
                    ConfigurationManager.Instance.ResetUnisonCheckpointTag();

                    if (Directory.Exists(FileSystemPaths.ConfigurationDirectory) == false)
                    {
                        Directory.CreateDirectory(FileSystemPaths.ConfigurationDirectory);
                    }

                    // If we're resetting configuration but keeping the user database, then we need to make sure
                    // that IsUnisonMode is set if they're Unison users. Otherwise, the main 8003 configuration's
                    // AutoConfigure, and a later isConfigurationConsistent check won't work correctly.
                    IsUnisonMode = accessCardManager.DatabaseMode == CardAccessDatabaseMode.Unison;

                    // Create 8003 controller configuration
                    lock (controllerConfigurationSync)
                    {
                        // Read the max Ids
                        resetNextIds();
                        DefaultingConfiguration = true;

                        // Create the default 8003 configuration in ram as this is required
                        if (controllerConfiguration == null)
                        {
                            controllerConfiguration = new Pacom8003Configuration();
                            controllerConfiguration.InitializeWithDefaults();
                            controllerConfiguration.EthernetPort = new IPPortConfiguration();
                            controllerConfiguration.EthernetPort.InitializeWithDefaults();
                        }

                        // Start building the new configuration
                        List<ConfigurationBase> configuration = new List<ConfigurationBase>();
                        int controllerId = Pacom8003Configuration.AutoConfigure(configuration);

                        // Create controller Ethernet and RS485 ports
                        IPPortConfiguration.AutoConfigure(controllerId, Pacom8003PhysicalPort.Ethernet, configuration);

                        // Configure the device loop port
                        RS485DeviceLoopPortConfiguration.AutoConfigure(controllerId, Pacom8003PhysicalPort.RS485, configuration);

                        // Configure the RS232 port as Debug. Can be changed in Pacom .is to Inovonics if required.
                        RS232DebugPortConfiguration.AutoConfigure(controllerId, Pacom8003PhysicalPort.RS232, configuration);

                        // Create default controller connection table
                        ControllerConnectionTable.AutoConfigure(configuration);

                        // Create default group
                        GroupConfiguration.AutoConfigure(configuration);

                        // Create default area if not existent
                        AreaConfiguration.AutoConfigure(configuration);

                        if (accessCardManager.DatabaseMode == CardAccessDatabaseMode.NoCardsPresent)
                        {
                            // Create Default Admin User
                            UserConfiguration.AutoConfigure(configuration);
                        }

                        DefaultingConfiguration = false;

                        UpdateConfiguration(configuration, false, userAuditInfo, true);

                        // The FrontEnd may delete all configuration from the storage. Defaults are restored. Update data flash.
                        updateNetworkAdapterFromConfiguration(ConfigurationUpdateReason.NoConfiguration, userAuditInfo);
                    }
                    break;
                }
                Thread.Sleep(1000);
            }
        }

        ControllerConfigurationWrapper controllerConfigurationWrapper = null;
        CalendarWrapper calendarWrapper = null;
        ControllerConnectionTableList controllerConnectionTableList = null;
        
        /// <summary>
        /// Initialize the controller configuration from scratch or from configuration saved to disk. Track user that has initiated this action.
        /// </summary>
        /// <param name="reason"></param>
        /// <param name="changes"></param>
        /// <param name="customSettings"></param>
        /// <param name="userAuditInfo">User audit details: user type, user Id.</param>
        /// <returns>True if the initialization was successful</returns>
        public bool Initialize(ConfigurationUpdateReason reason, ConfigurationElementsAffected changes, UserAuditInfo userAuditInfo)
        {
            return initialize(reason, changes, userAuditInfo, null);
        }

        /// <summary>
        /// Initialize the controller configuration from scratch or from configuration saved to disk. Track user that has initiated this action.
        /// removedItems are passed in to save reading from configuration when only 1 item has been removed. This is particularly useful when
        /// there are many of one type of item such as Users in Unison and a number are deleted 1 at a time.
        /// </summary>
        /// <param name="reason"></param>
        /// <param name="changes"></param>
        /// <param name="userAuditInfo"></param>
        /// <param name="removedItems"></param>
        /// <returns></returns>
        private bool initialize(ConfigurationUpdateReason reason, ConfigurationElementsAffected changes, UserAuditInfo userAuditInfo, List<ConfigurationChanges> removedItems)
        {
            // Check if the config.ASN.1 file exists in the Restricted Region, if not create the full auto-configuration including the Pacom8003Configuration, 
            // ControllerConnectionTable, Admin User, Default Group, Ethernet Port and RS485 Port, otherwise read the configuration from the config.ASN.1 files
            if (File.Exists(FileSystemPaths.DevicesConfigFilePath) == false)
            {
                CreateInitialConfiguration(userAuditInfo);
                return true;
            }

            CallConfigurationChangingEvent(changes);

            List<ConfigurationChanges> newlyAddedItems = new List<ConfigurationChanges>();
            List<ConfigurationChanges> changedItems = new List<ConfigurationChanges>();

            invalidConfigurationElements.Clear();
            try
            {
                // Just in case the temp config file was not deleted after a dtp config download.
                File.Delete(FileSystemPaths.TempAsn1ConfigFilePath);

                if (removedItems == null)
                {
                    removedItems = new List<ConfigurationChanges>();
                    readConfigurationFromDisk(ref changes, newlyAddedItems, changedItems, removedItems);
                }

                if (newlyAddedItems.Count > 0 || changedItems.Count > 0 || removedItems.Count > 0)
                {
                    // Link Areas
                    if (areas.Count > 0)
                    {
                        foreach (var areaConfiguration in areas.AsArray)
                        {
                            areaConfiguration.RemoveOldConfigurationItems(changedItems, removedItems);
                            Pacom8003AreaSchedule areaSchedule = areaSchedules[areaConfiguration.NormalScheduleId];
                            if (areaSchedule != null)
                                areaConfiguration.NormalSchedule = areaSchedule;
                            else
                                areaConfiguration.NormalSchedule = null;
                        }
                    }

                    // Remove some existing device links
                    List<int> changedDeviceIds = new List<int>(changedItems.Count + removedItems.Count);
                    foreach (var changedItem in changedItems)
                    {
                        if (changedItem.ConfigurationType == ConfigurationElementType.Device ||
                            changedItem.ConfigurationType == ConfigurationElementType.ExpansionCard)
                            changedDeviceIds.Add(changedItem.Id);
                    }
                    foreach (var removedItem in removedItems)
                    {
                        // Don't remove if it is also being added at the same time such as is the case when the parent device changes.
                        bool skipRemoval = false;
                        foreach (var newlyAddedItem in newlyAddedItems)
                        {
                            if (newlyAddedItem.ConfigurationType == removedItem.ConfigurationType && newlyAddedItem.Id == removedItem.Id)
                            {
                                skipRemoval = true;
                                break;
                            }
                        }
                        if (skipRemoval)
                            continue;

                        switch (removedItem.ConfigurationType)
                        {
                            case ConfigurationElementType.Device:
                                changedDeviceIds.Add(removedItem.Id);
                                devices.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.ExpansionCard:
                                changedDeviceIds.Add(removedItem.Id);
                                expansionCards.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.Area:
                                areas.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.Input:
                                inputs.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.Output:
                                outputs.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.Elevator:
                                elevators.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.ElevatorFloor:
                                elevatorFloors.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.Door:
                                foreach (IReaderConfiguration reader in readers.AsArray)
                                {
                                    if (reader.Door != null && reader.Door.Id == removedItem.Id)
                                        reader.Door = null;
                                }
                                doors.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.InterlockGroup:
                                interlockGroups.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.VaultControllerInterlockGroup:
                                vaultControllerInterlockGroups.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.Group:
                                groups.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.PresenceZone:
                                presenceZones.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.Reader:
                                readers.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.Port:
                                ports.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.Macro:
                                macros.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.CardFormat:
                                cardFormats.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.AccessGroup:
                                accessGroups.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.AccessSchedule:
                                accessSchedules.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.Schedule:
                                egressSchedules.Remove(removedItem.Id);
                                readerSchedules.Remove(removedItem.Id);
                                areaSchedules.Remove(removedItem.Id);
                                outputSchedules.Remove(removedItem.Id);
                                elevatorFloorUnlockSchedules.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.OpenPacomToDigitalReceiverTemplate:
                                openPacomToDigitalReceiverTemplates.Remove(removedItem.Id);
                                break;
                            case ConfigurationElementType.ControllerConnectionTable:
                                break;
                            case ConfigurationElementType.Calendar:
                                calendar = null;
                                break;
                        }
                    }
                    if (changedDeviceIds.Count > 0)
                    {
                        for (int i = 0; i < controllerConfiguration.ExpansionCards.Length; i++)
                        {
                            if (controllerConfiguration.ExpansionCards[i] != null && changedDeviceIds.Contains(controllerConfiguration.ExpansionCards[i].Id))
                            {
                                controllerConfiguration.ExpansionCards[i] = null;
                                controllerConfiguration.ExpansionSlotPorts[i] = null;
                            }
                        }
                        foreach (var device in devices.AsArray)
                        {
                            IDeviceLoopExpansionCardHolderDevice deviceLoopDeviceExpansionCardHolder = device as IDeviceLoopExpansionCardHolderDevice;
                            if (deviceLoopDeviceExpansionCardHolder != null)
                            {
                                for (int i = 0; i < deviceLoopDeviceExpansionCardHolder.ExpansionCards.Length; i++)
                                {
                                    if (deviceLoopDeviceExpansionCardHolder.ExpansionCards[i] != null && changedDeviceIds.Contains(deviceLoopDeviceExpansionCardHolder.ExpansionCards[i].Id))
                                        deviceLoopDeviceExpansionCardHolder.ExpansionCards[i] = null;
                                }
                            }
                        }

                        if (inovonicsDeviceIdBySerialNumber.Count > 0)
                        {
                            List<InovonicsDeviceTypeAndSerialNumber> keysToRemove = new List<InovonicsDeviceTypeAndSerialNumber>();
                            foreach (KeyValuePair<InovonicsDeviceTypeAndSerialNumber, int> kvp in inovonicsDeviceIdBySerialNumber)
                            {
                                if (changedDeviceIds.Contains(kvp.Value))
                                    keysToRemove.Add(kvp.Key);
                            }
                            foreach (InovonicsDeviceTypeAndSerialNumber keyToRemove in keysToRemove)
                            {
                                inovonicsDeviceIdBySerialNumber.Remove(keyToRemove);
                            }
                        }

                        for (int i = 0; i < controllerConfiguration.DeviceLoopDevices.Length; i++)
                        {
                            if (controllerConfiguration.DeviceLoopDevices[i] != null && changedDeviceIds.Contains(controllerConfiguration.DeviceLoopDevices[i].Id))
                                controllerConfiguration.DeviceLoopDevices[i] = null;
                        }
                    }

                    // Link expansion cards
                    if (expansionCards.Count > 0)
                    {
                        foreach (var expansionCard in expansionCards.AsArray)
                        {
                            removeOldConfigurationItemsFromDevice(expansionCard, changedItems, removedItems);
                            if (expansionCard.ParentDeviceId == controllerConfiguration.Id)
                            {
                                // Expansion card lives on an 8003.
                                controllerConfiguration.ExpansionCards[expansionCard.ExpansionCardSlot - 1] = expansionCard;
                            }
                            else
                            {
                                // Expansion card lives on a device loop device.
                                DeviceConfigurationBase deviceLoopDevice = devices[expansionCard.ParentDeviceId];
                                IDeviceLoopExpansionCardHolderDevice deviceLoopDeviceExpansionCardHolder = deviceLoopDevice as IDeviceLoopExpansionCardHolderDevice;
                                if (deviceLoopDeviceExpansionCardHolder != null)
                                    deviceLoopDeviceExpansionCardHolder.ExpansionCards[expansionCard.ExpansionCardSlot - 1] = expansionCard;
                            }
                        }
                    }

                    // Link Pacom device loop devices
                    controllerConfiguration.RemoveOldConfigurationItems(changedItems, removedItems);
                    if (devices.Count > 0)
                    {
                        foreach (var deviceConfiguration in devices.AsArray)
                        {
                            removeOldConfigurationItemsFromDevice(deviceConfiguration, changedItems, removedItems);

                            if (deviceConfiguration is AperioDriver == true)
                            {
							    // The Aperio driver is not an addressable device itself, nothing more needs to be done.
                                continue;
                            }
                            IDeviceLoopDeviceConfigurationBase deviceConfig = (IDeviceLoopDeviceConfigurationBase)deviceConfiguration;
                            if (deviceConfig.DeviceAddress < 1)
                            {
                                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                                {
                                    return string.Format("Device address {0} invalid.", deviceConfig.DeviceAddress);
                                });
                            }
                            if (deviceConfiguration.Id < 1)
                            {
                                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                                {
                                    return string.Format("Device logical Id {0} is invalid.", deviceConfiguration.Id);
                                });
                            }

                            InovonicsDeviceConfigurationBase inovonicsDeviceConfig = deviceConfiguration as InovonicsDeviceConfigurationBase;
                            if (inovonicsDeviceConfig != null)
                            {
                                // This is an Inovonics EchoStream Device
                                InovonicsDeviceTypeAndSerialNumber inovonicsDevice = new InovonicsDeviceTypeAndSerialNumber() { DeviceType = inovonicsDeviceConfig.DeviceType, SerialNumber = inovonicsDeviceConfig.DeviceLoopAddress };
                                inovonicsDeviceIdBySerialNumber[inovonicsDevice] = inovonicsDeviceConfig.Id;
                                continue;
                            }

                            controllerConfiguration.DeviceLoopDevices[deviceConfig.DeviceAddress - 1] = deviceConfiguration as DeviceLoopDeviceConfigurationBase;
                            IDeviceLoopDeviceAreaList pacomLcdKeypadConfiguration = deviceConfiguration as IDeviceLoopDeviceAreaList;
                            if (pacomLcdKeypadConfiguration != null)
                                pacomLcdKeypadConfiguration.SetupAreas();
                        }
                    }

                    // Link doors
                    if (doors.Count > 0)
                    {
                        int enabledDoorsCount = 0;
                        foreach (var doorConfiguration in doors.AsArray)
                        {
                            if (doorConfiguration != null && doorConfiguration.Enabled == true)
                            {
                                if (enabledDoorsCount >= LicenseManager.Instance.MaximumDoorCount)
                                    disableConfiguration(doorConfiguration);
                            }
                            AreaConfiguration areaConfiguration = areas[doorConfiguration.AreaId];
                            doorConfiguration.Area = areaConfiguration;
                            if (areaConfiguration != null)
                                doorConfiguration.Area.AddDoor(doorConfiguration);
                            EgressSchedule egressSchedule = egressSchedules[doorConfiguration.EgressScheduleId];
                            doorConfiguration.EgressSchedule = egressSchedule;

                            IReaderConfiguration readerConfig = readers[doorConfiguration.ReaderInId];
                            doorConfiguration.InReader = readerConfig;
                            if (readerConfig != null)
                            {
                                doorConfiguration.InReader.EgressSchedule = doorConfiguration.EgressSchedule;
                                doorConfiguration.InReader.Door = doorConfiguration;

                                if (doorConfiguration.ParentDeviceId == controllerConfiguration.Id)
                                {
                                    // Door lives on an 8003.
                                    if (doorConfiguration.PointNumberOnParent <= controllerConfiguration.OnboardDoors.Length)
                                        controllerConfiguration.OnboardDoors[doorConfiguration.PointNumberOnParent - 1] = doorConfiguration;
                                }
                                else
                                {
                                    // Door lives on a device loop device.
                                    IDeviceLoopDCDevice deviceLoopDCDevice = devices[doorConfiguration.ParentDeviceId] as IDeviceLoopDCDevice;
                                    if (deviceLoopDCDevice != null)
                                    {
                                        deviceLoopDCDevice.Doors[doorConfiguration.PointNumberOnParent - 1] = doorConfiguration;
                                    }
                                }
                            }
                            readerConfig = readers[doorConfiguration.ReaderOutId];
                            doorConfiguration.OutReader = readerConfig;
                            if (readerConfig != null)
                            {
                                doorConfiguration.OutReader.EgressSchedule = doorConfiguration.EgressSchedule;
                                doorConfiguration.OutReader.Door = doorConfiguration;
                            }
                        }
                    }

                    // Link inputs
                    if (inputs.Count > 0)
                    {
                        int enabledInputsCount = 0;
                        foreach (var inputConfiguration in inputs.AsArray)
                        {
                            if (inputConfiguration != null && inputConfiguration.Enabled == true)
                            {
                                if (enabledInputsCount >= LicenseManager.Instance.MaximumInputCount)
                                    disableConfiguration(inputConfiguration);
                            }
                            AreaConfiguration areaConfiguration = areas[inputConfiguration.AreaId];
                            inputConfiguration.Area = areaConfiguration;
                            if (areaConfiguration != null)
                                inputConfiguration.Area.AddInput(inputConfiguration);

                            if (inputConfiguration.ParentDeviceId == controllerConfiguration.Id)
                            {
                                // Input lives on the 8003.
                                if (inputConfiguration.PointNumberOnParent <= controllerConfiguration.OnboardInputs.Length)
                                    controllerConfiguration.OnboardInputs[inputConfiguration.PointNumberOnParent - 1] = inputConfiguration;
                            }
                            else
                            {
                                // Check if the input lives on a device (Pacom Device Loop / Inovonics EchoStream)
                                DeviceConfigurationBase device = devices[inputConfiguration.ParentDeviceId];
                                if (device != null)
                                {
                                    ((IInputDeviceConfigurationBase)device).Inputs[inputConfiguration.PointNumberOnParent - 1] = inputConfiguration;
                                }
                                else
                                {
                                    // Check if the input lives on an expansion card
                                    ExpansionCardDeviceConfigurationBase expansionCard = expansionCards[inputConfiguration.ParentDeviceId];
                                    if (expansionCard != null)
                                    {
                                        if (expansionCard.ParentDeviceId == controllerConfiguration.Id)
                                        {
                                            // The input is on an input card on the 8003 controller.
                                            controllerConfiguration.SetExpansionInput(expansionCard.ExpansionCardSlot - 1, inputConfiguration);
                                        }
                                        else
                                        {
                                            // The input is on an input card on device loop device.
                                            device = devices[expansionCard.ParentDeviceId];
                                            IDeviceLoopExpansionCardHolderDevice deviceLoopDeviceExpansionCardHolder = device as IDeviceLoopExpansionCardHolderDevice;
                                            if (deviceLoopDeviceExpansionCardHolder != null)
                                                deviceLoopDeviceExpansionCardHolder.SetExpansionInput(expansionCard.ExpansionCardSlot - 1, inputConfiguration);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Link outputs
                    if (outputs.Count > 0)
                    {
                        int enabledOutputsCount = 0;
                        foreach (var outputConfiguration in outputs.AsArray)
                        {
                            if (outputConfiguration != null && outputConfiguration.Enabled == true)
                            {
                                if (enabledOutputsCount >= LicenseManager.Instance.MaximumOutputCount)
                                    disableConfiguration(outputConfiguration);
                            }
                            AreaConfiguration areaConfiguration = areas[outputConfiguration.AreaId];
                            outputConfiguration.Area = areaConfiguration;
                            if (areaConfiguration != null)
                                outputConfiguration.Area.AddOutput(outputConfiguration);

                            if (outputConfiguration.ParentDeviceId == controllerConfiguration.Id)
                            {
                                // Output lives on the 8003.
                                if (outputConfiguration.PointNumberOnParent <= controllerConfiguration.OnboardOutputs.Length)
                                    controllerConfiguration.OnboardOutputs[outputConfiguration.PointNumberOnParent - 1] = outputConfiguration;
                            }
                            else
                            {
                                // Check if the output lives on a device loop device
                                DeviceConfigurationBase device = devices[outputConfiguration.ParentDeviceId];
                                if (device != null)
                                {
                                    ((IDeviceLoopIODevice)device).Outputs[outputConfiguration.PointNumberOnParent - 1] = outputConfiguration;
                                }
                                else
                                {
                                    // Check if the output lives on an expansion card
                                    ExpansionCardDeviceConfigurationBase expansionCard = expansionCards[outputConfiguration.ParentDeviceId];
                                    if (expansionCard != null)
                                    {
                                        if (expansionCard.ParentDeviceId == controllerConfiguration.Id)
                                        {
                                            // The output is on an output card on the 8003 controller.
                                            controllerConfiguration.SetExpansionOutput(expansionCard.ExpansionCardSlot - 1, outputConfiguration);
                                        }
                                        else
                                        {
                                            // The output is on an output card on an device loop device.
                                            device = devices[expansionCard.ParentDeviceId];
                                            IDeviceLoopExpansionCardHolderDevice deviceLoopDeviceExpansionCardHolder = device as IDeviceLoopExpansionCardHolderDevice;
                                            if (deviceLoopDeviceExpansionCardHolder != null)
                                                deviceLoopDeviceExpansionCardHolder.SetExpansionOutput(expansionCard.ExpansionCardSlot - 1, outputConfiguration);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Remove some existing links
                    if (presenceZones.Count > 0)
                    {
                        foreach (var presenceZone in presenceZones.AsArray)
                        {
                            presenceZone.RemoveOldConfigurationItems(changedItems, removedItems);
                        }
                    }

                    // Link readers
                    if (readers.Count > 0)
                    {
                        int enabledReadersCount = 0;
                        foreach (var readerConfiguration in readers.AsArray)
                        {
                            if (readerConfiguration != null && readerConfiguration.Enabled == true)
                            {
                                if (enabledReadersCount >= LicenseManager.Instance.MaximumReaderCount)
                                    disableConfiguration(readerConfiguration as NodeConfiguration);
                            }
                            AreaConfiguration areaConfiguration = areas[readerConfiguration.AreaId];
                            readerConfiguration.Area = areaConfiguration;
                            if (areaConfiguration != null)
                                readerConfiguration.Area.AddReader(readerConfiguration);
                            ReaderSchedule readerSchedule = readerSchedules[readerConfiguration.ScheduleId];
                            readerConfiguration.ReaderSchedule = readerSchedule;

                            ILegacyReaderConfiguration legacyReaderConfig = readerConfiguration as ILegacyReaderConfiguration;
                            if (legacyReaderConfig != null)
                            {
                                List<LegacyCardFormat> cardFormatsList = new List<LegacyCardFormat>(legacyReaderConfig.CardFormatIds.Length);
                                for (int i = 0; i < legacyReaderConfig.CardFormatIds.Length; i++)
                                {
                                    if (cardFormats.Exists(legacyReaderConfig.CardFormatIds[i]) == true)
                                        cardFormatsList.Add(cardFormats[legacyReaderConfig.CardFormatIds[i]]);
                                }
                                LegacyCardFormat[] newArray = cardFormatsList.ToArray();
                                if (ConfigurationUtils.CompareArrays(legacyReaderConfig.CardFormats, newArray) == false)
                                    legacyReaderConfig.CardFormats = newArray;
                            }
                            List<PresenceZoneConfiguration> presenceZoneConfigurationList = new List<PresenceZoneConfiguration>(readerConfiguration.EnterIntoPresenceZoneIds.Length);
                            for (int i = 0; i < readerConfiguration.EnterIntoPresenceZoneIds.Length; i++)
                            {
                                PresenceZoneConfiguration presenceZone = presenceZones[readerConfiguration.EnterIntoPresenceZoneIds[i]];
                                if (presenceZone != null)
                                {
                                    presenceZone.AddInReader(readerConfiguration);
                                    presenceZoneConfigurationList.Add(presenceZone);
                                }
                            }
                            {
                                PresenceZoneConfiguration[] newArray = presenceZoneConfigurationList.ToArray();
                                if (ConfigurationUtils.CompareArrays(readerConfiguration.EnterIntoPresenceZones, newArray) == false)
                                    readerConfiguration.EnterIntoPresenceZones = newArray;
                            }
                            presenceZoneConfigurationList = new List<PresenceZoneConfiguration>(readerConfiguration.ExitOutOfPresenceZoneIds.Length);
                            for (int i = 0; i < readerConfiguration.ExitOutOfPresenceZoneIds.Length; i++)
                            {
                                PresenceZoneConfiguration presenceZone = presenceZones[readerConfiguration.ExitOutOfPresenceZoneIds[i]];
                                if (presenceZone != null)
                                {
                                    presenceZone.AddOutReader(readerConfiguration);
                                    presenceZoneConfigurationList.Add(presenceZone);
                                }
                            }
                            {
                                PresenceZoneConfiguration[] newArray = presenceZoneConfigurationList.ToArray();
                                if (ConfigurationUtils.CompareArrays(readerConfiguration.ExitOutOfPresenceZones, newArray) == false)
                                    readerConfiguration.ExitOutOfPresenceZones = newArray;
                            }

                            if (readerConfiguration.ParentDeviceId == controllerConfiguration.Id)
                            {
                                // Reader lives on the 8003.
                                if (readerConfiguration.PointNumberOnParent <= controllerConfiguration.OnboardReaders.Length)
                                    controllerConfiguration.OnboardReaders[readerConfiguration.PointNumberOnParent - 1] = readerConfiguration;
                            }
                            else
                            {
                                // Reader lives on a device loop device.
                                DeviceConfigurationBase deviceLoopDevice = devices[readerConfiguration.ParentDeviceId];
                                if (deviceLoopDevice != null)
                                {
                                    IDeviceLoopDCDevice device = deviceLoopDevice as IDeviceLoopDCDevice;
                                    if (device != null)
                                        device.Readers[readerConfiguration.PointNumberOnParent - 1] = readerConfiguration;
                                }
                            }
                        }
                    }

                    // Link ports
                    if (ports.Count > 0)
                    {
                        foreach (var portConfiguration in ports.AsArray)
                        {
                            IPPortConfiguration ethernetPort = portConfiguration as IPPortConfiguration;
                            if (ethernetPort != null)
                            {
                                controllerConfiguration.EthernetPort = ethernetPort;
                                continue;
                            }

                            RS485DeviceLoopPortConfiguration rs485DeviceLoopPort = portConfiguration as RS485DeviceLoopPortConfiguration;
                            if (rs485DeviceLoopPort != null)
                            {
                                switch (rs485DeviceLoopPort.PortNumberOnParent)
                                {
                                    case Pacom8003PhysicalPort.RS485:
                                        // Port lives on the 8003.
                                        controllerConfiguration.RS485Port = rs485DeviceLoopPort;
                                        break;
                                    case Pacom8003PhysicalPort.ExpansionSlot1:
                                    case Pacom8003PhysicalPort.ExpansionSlot2:
                                        // Port lives on an expansion card.
                                        controllerConfiguration.ExpansionSlotPorts[(int)rs485DeviceLoopPort.PortNumberOnParent - 3] = rs485DeviceLoopPort;
                                        break;
                                }
                                continue;
                            }

                            GprsPortConfiguration gprsPort = portConfiguration as GprsPortConfiguration;
                            if (gprsPort != null && gprsPort.ParentDeviceId == controllerConfiguration.Id)
                            {
                                if (gprsPort.PortNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot1)
                                    controllerConfiguration.ExpansionSlotPorts[0] = gprsPort;
                                else if (gprsPort.PortNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot2)
                                    controllerConfiguration.ExpansionSlotPorts[1] = gprsPort;
                                continue;
                            }

                            RS485OsdpDeviceLoopPortConfiguration rs485OsdpPort = portConfiguration as RS485OsdpDeviceLoopPortConfiguration;
                            if (rs485OsdpPort != null)
                            {
                                switch (rs485OsdpPort.PortNumberOnParent)
                                {
                                    case Pacom8003PhysicalPort.RS485:
                                        // Port lives on the 8003.
                                        controllerConfiguration.RS485Port = rs485OsdpPort;
                                        break;
                                    case Pacom8003PhysicalPort.ExpansionSlot1:
                                    case Pacom8003PhysicalPort.ExpansionSlot2:
                                        // Port lives on an expansion card.
                                        controllerConfiguration.ExpansionSlotPorts[(int)rs485OsdpPort.PortNumberOnParent - 3] = rs485OsdpPort;
                                        break;
                                }
                                continue;
                            }

                            RS485AsisProprietaryReaderPortConfiguration rs485AprpPort = portConfiguration as RS485AsisProprietaryReaderPortConfiguration;
                            if (rs485AprpPort != null)
                            {
                                switch (rs485AprpPort.PortNumberOnParent)
                                {
                                    case Pacom8003PhysicalPort.RS485:
                                        // Port lives on the 8003.
                                        controllerConfiguration.RS485Port = rs485AprpPort;
                                        break;
                                    case Pacom8003PhysicalPort.ExpansionSlot1:
                                    case Pacom8003PhysicalPort.ExpansionSlot2:
                                        // Port lives on an expansion card.
                                        controllerConfiguration.ExpansionSlotPorts[(int)rs485AprpPort.PortNumberOnParent - 3] = rs485AprpPort;
                                        break;
                                }
                                continue;
                            }

                            RS485AperioPortConfiguration rs485AperioPort = portConfiguration as RS485AperioPortConfiguration;
                            if (rs485AperioPort != null)
                            {
                                switch (rs485AperioPort.PortNumberOnParent)
                                {
                                    case Pacom8003PhysicalPort.RS485:
                                        // Port lives on the 8003.
                                        controllerConfiguration.RS485Port = rs485AperioPort;
                                        break;
                                    case Pacom8003PhysicalPort.ExpansionSlot1:
                                    case Pacom8003PhysicalPort.ExpansionSlot2:
                                        // Port lives on an expansion card.
                                        controllerConfiguration.ExpansionSlotPorts[(int)rs485AperioPort.PortNumberOnParent - 3] = rs485AperioPort;
                                        break;
                                }
                                continue;
                            }

                            DialupPortConfiguration dialupPort = portConfiguration as DialupPortConfiguration;
                            if (dialupPort != null && dialupPort.ParentDeviceId == controllerConfiguration.Id)
                            {
                                if (dialupPort.PortNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot1)
                                    controllerConfiguration.ExpansionSlotPorts[0] = dialupPort;
                                else if (dialupPort.PortNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot2)
                                    controllerConfiguration.ExpansionSlotPorts[1] = dialupPort;
                                continue;
                            }

                            RS232InovonicsPortConfiguration rs232Port = portConfiguration as RS232InovonicsPortConfiguration;
                            if (rs232Port != null && rs232Port.ParentDeviceId == controllerConfiguration.Id &&
                                rs232Port.PortNumberOnParent == Pacom8003PhysicalPort.RS232 && rs232Port.PortProtocol == PortProtocol.InovonicsEchoStream)
                            {
                                controllerConfiguration.RS232Port = rs232Port;
                                continue;
                            }

                            RS232DebugPortConfiguration rs232DebugPort = portConfiguration as RS232DebugPortConfiguration;
                            if (rs232DebugPort != null && rs232DebugPort.ParentDeviceId == controllerConfiguration.Id &&
                                rs232DebugPort.PortNumberOnParent == Pacom8003PhysicalPort.RS232 && rs232DebugPort.PortProtocol == PortProtocol.Rs232Debug)
                            {
                                controllerConfiguration.RS232Port = rs232DebugPort;
                                continue;
                            }
                        }
                    }

                    // Two cases here: 1) The configuration exists on startup -> update from data flash
                    //                 2) The configuration changed during operation -> update from configuration
                    if (reason == ConfigurationUpdateReason.Initial)
                    {
                        // It is not controller initialization but it is startup. Compare adapter configuration with data flash.
                        updateNetworkAdapterFromDataFlash(ConfigurationUpdateReason.Initial, userAuditInfo);
                    }
                    else
                    {
                        // Update the IP address and other settings here
                        updateNetworkAdapterFromConfiguration(reason, userAuditInfo);
                    }

                    if (controllerConfiguration != null)
                    {
                        // Set the logging level flag from controller configuration
                        Logger.SetLoggingLevel(controllerConfiguration.LoggingLevel);

                        // Check if the controller AllowCommandsAndDtpWithoutKeypadUser option is disabled and if so, check if it is valid
                        if (controllerConfiguration.AllowCommandsAndDtpWithoutKeypadUser == false && isAllowCommandsAndDtpWithoutKeypadUserValid() == false)
                        {
                            controllerConfiguration.AllowCommandsAndDtpWithoutKeypadUser = true;
                            invalidConfigurationElements.Add(new InvalidConfigurationIdentifierAndPropertyName(string.Format("/Nodes/Device/{0}", controllerConfiguration.Id), "AllowCommandsAndDtpWithoutKeypadUser"));
                            Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                            {
                                return string.Format("AllowCommandsAndDtpWithoutKeypadUser has been disabled without meeting prerequisites. Enabling to maintain functionality.");
                            });
                        }

                        // Update onboard input hit counts
                        int[] hitCounts = new int[8] { 3, 3, 3, 3, 3, 3, 3, 3 };
                        foreach (InputConfiguration input in ConfigurationManager.Instance.Inputs)
                        {
                            if (input.ParentDeviceId == controllerConfiguration.Id)
                            {
                                hitCounts[input.PointNumberOnParent - 1] = input.HitCount;
                            }
                        }
                        adc.SetAdcHitCounts(hitCounts);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Unhandled error loading configuration: {0}", ex.ToString());
                });
                return false;
            }
            finally
            {
                CallConfigurationChangedEvent(changes, newlyAddedItems, changedItems, removedItems);
            }
            return true;
        }

        private void readConfigurationFromDisk(ref ConfigurationElementsAffected changes, List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems)
        {
            StreamingContext context = new StreamingContext();
            ITypeLookup typesList = getListOfTypes();
            Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(typesList, true, context);
            asn1Serializer.SerializeDefaultValues = true;

            lock (controllerConfigurationSync)
            {
                controllerConfigurationWrapper = new ControllerConfigurationWrapper();
                calendarWrapper = new CalendarWrapper();
                controllerConnectionTableList = new ControllerConnectionTableList();

                if (isConfigurationFileModified(FileSystemPaths.DevicesConfigFilePath))
                {
                    if (controllerConfiguration != null)
                        removedItems.Add(new ConfigurationChanges() { ConfigurationType = ConfigurationElementType.Device, Id = controllerConfiguration.Id, ParentDeviceId = controllerConfiguration.ParentDeviceId });
                    getAllItems(devices, ConfigurationElementType.Device, removedItems);
                    getAllItems(expansionCards, ConfigurationElementType.ExpansionCard, removedItems);
                    loadAsn1File(FileSystemPaths.DevicesConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.SchedulesConfigFilePath))
                {
                    getAllItems(areaSchedules, ConfigurationElementType.Schedule, removedItems);
                    loadAsn1File(FileSystemPaths.SchedulesConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.LegacyAccessSchedulesConfigFilePath))
                {
                    getAllItems(accessSchedules, ConfigurationElementType.AccessSchedule, removedItems);
                    loadAsn1File(FileSystemPaths.LegacyAccessSchedulesConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.CalendarsConfigFilePath))
                {
                    if (calendar != null)
                        removedItems.Add(new ConfigurationChanges() { ConfigurationType = ConfigurationElementType.Calendar, Id = calendar.Id });
                    loadAsn1File(FileSystemPaths.CalendarsConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.CardProfilesConfigFilePath))
                {
                    getAllItems(cardFormats, ConfigurationElementType.CardFormat, removedItems);
                    loadAsn1File(FileSystemPaths.CardProfilesConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.AccessGroupsConfigFilePath))
                {
                    getAllItems(groups, ConfigurationElementType.Group, removedItems);
                    loadAsn1File(FileSystemPaths.AccessGroupsConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.ConnectionsConfigFilePath))
                {
                    foreach (ControllerConnectionTable controllerConnectionTable in controllerConnectionTables)
                    {
                        if (controllerConnectionTable != null)
                            removedItems.Add(new ConfigurationChanges() { ConfigurationType = ConfigurationElementType.ControllerConnectionTable, Id = controllerConnectionTable.Id });
                    }
                    loadAsn1File(FileSystemPaths.ConnectionsConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                    controllerConnectionTableList.CommitChanges = true;
                }
                if (isConfigurationFileModified(FileSystemPaths.AreasConfigFilePath))
                {
                    getAllItems(areas, ConfigurationElementType.Area, removedItems);
                    loadAsn1File(FileSystemPaths.AreasConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.PresenceZonesConfigFilePath))
                {
                    getAllItems(presenceZones, ConfigurationElementType.PresenceZone, removedItems);
                    loadAsn1File(FileSystemPaths.PresenceZonesConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.InputsConfigFilePath))
                {
                    getAllItems(inputs, ConfigurationElementType.Input, removedItems);
                    loadAsn1File(FileSystemPaths.InputsConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.OutputsConfigFilePath))
                {
                    getAllItems(outputs, ConfigurationElementType.Output, removedItems);
                    loadAsn1File(FileSystemPaths.OutputsConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.ElevatorsConfigFilePath))
                {
                    getAllItems(elevators, ConfigurationElementType.Elevator, removedItems);
                    loadAsn1File(FileSystemPaths.ElevatorsConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.ElevatorFloorsConfigFilePath))
                {
                    getAllItems(elevatorFloors, ConfigurationElementType.ElevatorFloor, removedItems);
                    loadAsn1File(FileSystemPaths.ElevatorFloorsConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.PortsConfigFilePath))
                {
                    getAllItems(ports, ConfigurationElementType.Port, removedItems);
                    loadAsn1File(FileSystemPaths.PortsConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.ReadersConfigFilePath))
                {
                    getAllItems(readers, ConfigurationElementType.Reader, removedItems);
                    loadAsn1File(FileSystemPaths.ReadersConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.DoorsConfigFilePath))
                {
                    getAllItems(doors, ConfigurationElementType.Door, removedItems);
                    loadAsn1File(FileSystemPaths.DoorsConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.InterlockGroupsConfigFilePath))
                {
                    getAllItems(interlockGroups, ConfigurationElementType.InterlockGroup, removedItems);
                    loadAsn1File(FileSystemPaths.InterlockGroupsConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.VaultControllerInterlockGroupsConfigFilePath))
                {
                    getAllItems(vaultControllerInterlockGroups, ConfigurationElementType.VaultControllerInterlockGroup, removedItems);
                    loadAsn1File(FileSystemPaths.VaultControllerInterlockGroupsConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.MacrosConfigFilePath))
                {
                    getAllItems(macros, ConfigurationElementType.Macro, removedItems);
                    loadAsn1File(FileSystemPaths.MacrosConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }
                if (isConfigurationFileModified(FileSystemPaths.OpenPacomToDigitalReceiverTemplateFilePath))
                {
                    if (openPacomToDigitalReceiverTemplates.ContainsKey(1))
                        removedItems.Add(new ConfigurationChanges() { ConfigurationType = ConfigurationElementType.OpenPacomToDigitalReceiverTemplate, Id = 1 });
                    loadAsn1File(FileSystemPaths.OpenPacomToDigitalReceiverTemplateFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }

                bool previousUnisonMode = IsUnisonMode;
                // Ensure the controller has only GMS or Unison configuration, not both.
                if (isConfigurationConsistent(newlyAddedItems, removedItems) == false)
                {
                    changes = ConfigurationElementsAffected.All;

                    getAllItems(readers, ConfigurationElementType.Reader, removedItems);
                    for (int i = 0; i < newlyAddedItems.Count; i++)
                    {
                        if (newlyAddedItems[i].ConfigurationType == ConfigurationElementType.Reader)
                        {
                            newlyAddedItems.RemoveAt(i);
                            i--;
                        }
                    }
                    for (int i = 0; i < changedItems.Count; i++)
                    {
                        if (changedItems[i].ConfigurationType == ConfigurationElementType.Reader)
                        {
                            changedItems.RemoveAt(i);
                            i--;
                        }
                    }

                    CommonUtilities.DeleteFile(FileSystemPaths.ReadersConfigFilePath);
                    CommonUtilities.DeleteFile(FileSystemPaths.ReadersConfigFilePath.Replace(".asn1", ".idx"));
                    Users.RemoveAll();

                    readers.Clear();
                }
                if (previousUnisonMode != IsUnisonMode)
                {
                    // We have switched access control models.
                    changes = ConfigurationElementsAffected.All;

                    int controllerId = controllerConfiguration.Id;
                    bool controllerChanged = false;
                    foreach (ConfigurationChanges newlyAddedItem in newlyAddedItems)
                    {
                        if (newlyAddedItem.ConfigurationType == ConfigurationElementType.Device && newlyAddedItem.Id == controllerId)
                        {
                            controllerChanged = true;
                            break;
                        }
                    }
                    if (controllerChanged == false)
                    {
                        foreach (ConfigurationChanges changedItem in changedItems)
                        {
                            if (changedItem.ConfigurationType == ConfigurationElementType.Device && changedItem.Id == controllerId)
                            {
                                controllerChanged = true;
                                break;
                            }
                        }
                    }
                    if (controllerChanged == false)
                    {
                        int indexToRemove = -1;
                        for (int i = 0; i < removedItems.Count; i++)
                        {
                            if (removedItems[i].ConfigurationType == ConfigurationElementType.Device && removedItems[i].Id == controllerId)
                            {
                                indexToRemove = i;
                                break;
                            }
                        }
                        if (indexToRemove >= 0)
                            removedItems.RemoveAt(indexToRemove);
                        changedItems.Add(new ConfigurationChanges() { ConfigurationType = ConfigurationElementType.Device, Id = controllerId, ParentDeviceId = controllerConfiguration.ParentDeviceId });
                    }
                }
                if (isConfigurationFileModified(FileSystemPaths.UserAccessGroupsConfigFilePath))
                {
                    getAllItems(accessGroups, ConfigurationElementType.AccessGroup, removedItems);
                    if (IsUnisonMode)
                        loadAsn1File(FileSystemPaths.UserAccessGroupsConfigFilePath, asn1Serializer, newlyAddedItems, changedItems, removedItems);
                }

                controllerConfigurationWrapper = null;
                calendarWrapper = null;
                controllerConnectionTableList.Dispose();
                controllerConnectionTableList = null;

                Logger.LogWarnMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendFormat("### New: {0}, Changed: {1}, Removed: {2}\r\n", newlyAddedItems.Count, changedItems.Count, removedItems.Count);
                    if (newlyAddedItems.Count > 0 && newlyAddedItems.Count < 30)
                    {
                        sb.Append("    New: \r\n");
                        for (int i = 0; i < newlyAddedItems.Count; i++)
                        {
                            sb.AppendFormat("       {0} {1}\r\n", newlyAddedItems[i].ConfigurationType.ToString(), newlyAddedItems[i].Id);
                        }
                    }
                    if (changedItems.Count > 0 && changedItems.Count < 30)
                    {
                        sb.Append("    Changed: \r\n");
                        for (int i = 0; i < changedItems.Count; i++)
                        {
                            sb.AppendFormat("       {0} {1}\r\n", changedItems[i].ConfigurationType.ToString(), changedItems[i].Id);
                        }
                    }
                    if (removedItems.Count > 0 && removedItems.Count < 30)
                    {
                        sb.Append("    Removed: \r\n");
                        for (int i = 0; i < removedItems.Count; i++)
                        {
                            sb.AppendFormat("       {0} {1}\r\n", removedItems[i].ConfigurationType.ToString(), removedItems[i].Id);
                        }
                    }
                    return sb.ToString();
                });
            }
        }

        private void getItemDetails(IConfigurationList configurationList, ConfigurationElementType configurationElementType, int id, List<ConfigurationChanges> removedItems)
        {
            if (configurationList.AsKeyList.Contains(id))
            {
                ConfigurationChanges configurationChanges = new ConfigurationChanges() { ConfigurationType = configurationElementType, Id = id };
                INodeConfiguration node = configurationList.GetItem(id) as INodeConfiguration;
                if (node != null)
                {
                    configurationChanges.ParentDeviceId = node.ParentDeviceId;
                    var expansionCardConfiguration = ConfigurationManager.Instance.GetExpansionCardDeviceConfiguration(node.ParentDeviceId);
                    if (expansionCardConfiguration != null)
                        configurationChanges.GrandParentDeviceId = expansionCardConfiguration.ParentDeviceId;
                }

                removedItems.Add(configurationChanges);
            }
        }

        private void getItemDetails(string filePath, ConfigurationBase configurationItem, List<ConfigurationChanges> removedItems)
        {
            controllerConfigurationWrapper = new ControllerConfigurationWrapper();
            calendarWrapper = new CalendarWrapper();
            controllerConnectionTableList = new ControllerConnectionTableList();

            if (filePath == FileSystemPaths.DevicesConfigFilePath)
            {
                if (controllerConfiguration == configurationItem)
                {
                    removedItems.Add(new ConfigurationChanges() { ConfigurationType = ConfigurationElementType.Device, Id = controllerConfiguration.Id, ParentDeviceId = controllerConfiguration.ParentDeviceId });
                }
                else
                {
                    getItemDetails(devices, ConfigurationElementType.Device, configurationItem.Id, removedItems);
                    getItemDetails(expansionCards, ConfigurationElementType.ExpansionCard, configurationItem.Id, removedItems);
                }
            }
            else if (filePath == FileSystemPaths.SchedulesConfigFilePath)
            {
                getItemDetails(areaSchedules, ConfigurationElementType.Schedule, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.LegacyAccessSchedulesConfigFilePath)
            {
                getItemDetails(accessSchedules, ConfigurationElementType.AccessSchedule, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.CalendarsConfigFilePath)
            {
                if (calendar != null)
                    removedItems.Add(new ConfigurationChanges() { ConfigurationType = ConfigurationElementType.Calendar, Id = configurationItem.Id });
            }
            else if (filePath == FileSystemPaths.CardProfilesConfigFilePath)
            {
                getItemDetails(cardFormats, ConfigurationElementType.CardFormat, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.AccessGroupsConfigFilePath)
            {
                getItemDetails(groups, ConfigurationElementType.Group, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.ConnectionsConfigFilePath)
            {
                removedItems.Add(new ConfigurationChanges() { ConfigurationType = ConfigurationElementType.ControllerConnectionTable, Id = configurationItem.Id });
            }
            else if (filePath == FileSystemPaths.AreasConfigFilePath)
            {
                getItemDetails(areas, ConfigurationElementType.Area, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.PresenceZonesConfigFilePath)
            {
                getItemDetails(presenceZones, ConfigurationElementType.PresenceZone, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.InputsConfigFilePath)
            {
                getItemDetails(inputs, ConfigurationElementType.Input, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.OutputsConfigFilePath)
            {
                getItemDetails(outputs, ConfigurationElementType.Output, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.ElevatorsConfigFilePath)
            {
                getItemDetails(elevators, ConfigurationElementType.Elevator, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.ElevatorFloorsConfigFilePath)
            {
                getItemDetails(elevatorFloors, ConfigurationElementType.ElevatorFloor, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.PortsConfigFilePath)
            {
                getItemDetails(ports, ConfigurationElementType.Port, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.ReadersConfigFilePath)
            {
                getItemDetails(readers, ConfigurationElementType.Reader, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.DoorsConfigFilePath)
            {
                getItemDetails(doors, ConfigurationElementType.Door, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.InterlockGroupsConfigFilePath)
            {
                getItemDetails(interlockGroups, ConfigurationElementType.InterlockGroup, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.VaultControllerInterlockGroupsConfigFilePath)
            {
                getItemDetails(vaultControllerInterlockGroups, ConfigurationElementType.VaultControllerInterlockGroup, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.MacrosConfigFilePath)
            {
                getItemDetails(macros, ConfigurationElementType.Macro, configurationItem.Id, removedItems);
            }
            else if (filePath == FileSystemPaths.OpenPacomToDigitalReceiverTemplateFilePath)
            {
                if (openPacomToDigitalReceiverTemplates.ContainsKey(1))
                    removedItems.Add(new ConfigurationChanges() { ConfigurationType = ConfigurationElementType.OpenPacomToDigitalReceiverTemplate, Id = 1 });
            }
            else if (IsUnisonMode == true && filePath == (FileSystemPaths.UserAccessGroupsConfigFilePath))
            {
                getItemDetails(accessGroups, ConfigurationElementType.AccessGroup, configurationItem.Id, removedItems);
            }

            controllerConfigurationWrapper = null;
            calendarWrapper = null;
            controllerConnectionTableList.Dispose();
            controllerConnectionTableList = null;
        }

        private void removeFromDevice(DeviceConfigurationBase device, ConfigurationChanges changedItem)
        {
            if (changedItem.ConfigurationType == ConfigurationElementType.Input || changedItem.ConfigurationType == ConfigurationElementType.Output)
            {
                IDeviceLoopIODevice ioDevice = device as IDeviceLoopIODevice;
                if (ioDevice != null)
                {
                    if (changedItem.ConfigurationType == ConfigurationElementType.Input && ioDevice.Inputs != null)
                        ConfigurationUtils.Null<InputConfiguration>(changedItem.Id, ioDevice.Inputs);
                    if (changedItem.ConfigurationType == ConfigurationElementType.Output && ioDevice.Outputs != null)
                        ConfigurationUtils.Null<OutputConfiguration>(changedItem.Id, ioDevice.Outputs);
                }
            }
            else if (changedItem.ConfigurationType == ConfigurationElementType.Reader || changedItem.ConfigurationType == ConfigurationElementType.Door)
            {
                IDeviceLoopDCDevice dcDevice = device as IDeviceLoopDCDevice;
                if (dcDevice != null)
                {
                    if (changedItem.ConfigurationType == ConfigurationElementType.Reader && dcDevice.Readers != null)
                        ConfigurationUtils.Null<IReaderConfiguration>(changedItem.Id, dcDevice.Readers);
                    if (changedItem.ConfigurationType == ConfigurationElementType.Door && dcDevice.Doors != null)
                        ConfigurationUtils.Null<DoorConfiguration>(changedItem.Id, dcDevice.Doors);
                }
            }
            else if (changedItem.ConfigurationType == ConfigurationElementType.Area)
            {
                IDeviceLoopDeviceAreaList areaDevice = device as IDeviceLoopDeviceAreaList;
                if (areaDevice != null && areaDevice.Areas != null)
                {
                    areaDevice.Areas = ConfigurationUtils.Remove<AreaConfiguration>(changedItem.Id, areaDevice.Areas);
                }
            }
        }

        private void removeOldConfigurationItemsFromDevice(DeviceConfigurationBase device, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems)
        {
            foreach (ConfigurationChanges changedItem in changedItems)
            {
                removeFromDevice(device, changedItem);
            }
            foreach (ConfigurationChanges removedItem in removedItems)
            {
                removeFromDevice(device, removedItem);
            }
        }

        private readonly List<InvalidConfigurationIdentifierAndPropertyName> invalidConfigurationElements = new List<InvalidConfigurationIdentifierAndPropertyName>();
        public InvalidConfigurationIdentifierAndPropertyName[] InvalidConfigurationElements
        {
            get
            {
                return invalidConfigurationElements.ToArray();
            }
        }

        public bool IsKeypadInENMode
        {
            get
            {
                return controllerConfiguration.KeypadOperationalMode == KeypadOperationalMode.EN50131Grade4;
            }
        }

        private bool isAllowCommandsAndDtpWithoutKeypadUserValid()
        {
            // Check that keypads are in EN mode of operation
            if (controllerConfiguration.KeypadOperationalMode != KeypadOperationalMode.EN50131Grade4)
                return false;

            List<int> keypadAreas = new List<int>();
            // Check that there is at least 1 keypad with areas assigned
            foreach (DeviceConfigurationBase device in devices.AsArray)
            {
                Device8003KeypadConfiguration keypad = device as Device8003KeypadConfiguration;
                if (keypad != null && keypad.Enabled == true)
                {
                    keypadAreas.AddRange(keypad.AreaIds);
                }
            }
            if (keypadAreas.Count == 0)
                return false;

            // Check that there is at least 1 engineer and 1 non engineer with areas assigned
            if (users.EngineerIsPresent(keypadAreas) == false)
                return false;

            return false;
        }

        /// <summary>
        /// Update network adapter state from information stored in data flash 
        /// </summary>
        /// <param name="reason"></param>
        /// <param name="userAuditInfo">User audit details: user type, user Id.</param>
        private void updateNetworkAdapterFromDataFlash(ConfigurationUpdateReason reason, UserAuditInfo userAuditInfo)
        {
            try
            {
                DataFlashConfig dataFlashConfig = new DataFlashConfig(dataFlash);
                bool dataFlashConfigUpdateRequired = false;

                // When configuration is present compare first with what is saved in configuration
                if (reason == ConfigurationUpdateReason.Initial || reason == ConfigurationUpdateReason.FrontEndOrWeb)
                {
                    IPAddress configIPAddress = IPAddress.Any;
                    IPAddress configSubnetMask = IPAddress.Any;
                    IPAddress configDefaultGateway = IPAddress.Any;
                    IPAddress configDnsServer = IPAddress.Any;
                    bool configUseDhcpServer = false;

                    bool configurationValid = true;
                    try
                    {
                        if (controllerConfiguration.EthernetPort != null)
                        {
                            configIPAddress = IPAddress.Parse(controllerConfiguration.EthernetPort.IPAddress);
                            configSubnetMask = IPAddress.Parse(controllerConfiguration.EthernetPort.SubnetMask);
                            configDefaultGateway = IPAddress.Parse(controllerConfiguration.EthernetPort.DefaultGateway);
                            configDnsServer = IPAddress.Parse(controllerConfiguration.EthernetPort.DnsServer);
                            configUseDhcpServer = controllerConfiguration.EthernetPort.UseDhcpServer;
                        }
                        else
                        {
                            configurationValid = false;
                            controllerConfiguration.EthernetPort = new IPPortConfiguration();
                            controllerConfiguration.EthernetPort.SetDefaults();
                        }
                    }
                    catch
                    {
                        configurationValid = false;
                    }
                    if (configurationValid == true)
                    {
                        // Configuration is parsed and ready to compare
                        if (dataFlashConfig.IPAddress.Equals(configIPAddress) &&
                            dataFlashConfig.SubnetMask.Equals(configSubnetMask) &&
                            dataFlashConfig.Gateway.Equals(configDefaultGateway) &&
                            dataFlashConfig.DnsServer.Equals(configDnsServer) &&
                            dataFlashConfig.DhcpEnabled == configUseDhcpServer)
                        {
                            // The configuration is the same - just exit
                            return;
                        }
                        else
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                            {
                                return "Data flash configuration change detected. Using data flash values for onboard ethernet port.";
                            });
                        }
                    }
                }
                else
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return "Using data flash values for onboard ethernet port.";
                    });
                }

                // Load data flash records to current controller configuration
                Port8003IPPortConfiguration newEthernetPortConfiguration = new Port8003IPPortConfiguration();
                ConfigurationManager.CopyConfiguration(controllerConfiguration.EthernetPort, newEthernetPortConfiguration);

                newEthernetPortConfiguration.IPAddress = dataFlashConfig.IPAddress.ToString();
                newEthernetPortConfiguration.SubnetMask = dataFlashConfig.SubnetMask.ToString();
                newEthernetPortConfiguration.DefaultGateway = dataFlashConfig.Gateway.ToString();
                newEthernetPortConfiguration.DnsServer = dataFlashConfig.DnsServer.ToString();
                newEthernetPortConfiguration.UseDhcpServer = dataFlashConfig.DhcpEnabled;
                newEthernetPortConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                List<ConfigurationBase> configurationItems = new List<ConfigurationBase>(new ConfigurationBase[] { newEthernetPortConfiguration });
                ConfigurationManager.Instance.UpdateConfiguration(configurationItems, false, userAuditInfo, true);

                // Confirm the configuration is valid now
                IPAddress adapterIPAddress = IPAddress.Any;
                IPAddress adapterSubnetMask = IPAddress.Any;
                IPAddress adapterDefaultGateway = IPAddress.Any;
                IPAddress adapterDnsServer = IPAddress.Any;
                bool adapterUseDhcpServer = false;
                bool valid = true;
                do
                {
                    try
                    {
                        adapterIPAddress = IPAddress.Parse(controllerConfiguration.EthernetPort.IPAddress);
                    }
                    catch
                    {
                        valid = false;
                        Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return "Unable to parse data flash IP address.";
                        });
                        break;
                    }
                    try
                    {
                        adapterSubnetMask = IPAddress.Parse(controllerConfiguration.EthernetPort.SubnetMask);
                    }
                    catch
                    {
                        valid = false;
                        Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return "Unable to parse data flash subnet mask.";
                        });
                        break;
                    }
                    try
                    {
                        adapterDefaultGateway = IPAddress.Parse(controllerConfiguration.EthernetPort.DefaultGateway);
                    }
                    catch
                    {
                        valid = false;
                        Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return "Unable to parse data flash default gateway.";
                        });
                        break;
                    }
                    try
                    {
                        adapterDnsServer = IPAddress.Parse(controllerConfiguration.EthernetPort.DnsServer);
                    }
                    catch
                    {
                        valid = false;
                        Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return "Unable to parse data flash DNS server.";
                        });
                        break;
                    }
                    adapterUseDhcpServer = controllerConfiguration.EthernetPort.UseDhcpServer;

                } while (false);
                if (valid == false)
                {
                    // If the configuration is invalid - use defaults
                    Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return "Using default onboard network adapter values.";
                    });
                    adapterIPAddress = IPAddress.Parse("10.1.1.1");
                    adapterSubnetMask = IPAddress.Parse("255.255.0.0");
                    adapterDefaultGateway = IPAddress.Parse("0.0.0.0");
                    adapterDnsServer = IPAddress.Parse("0.0.0.0");
                    adapterUseDhcpServer = false;
                    newEthernetPortConfiguration.IPAddress = adapterIPAddress.ToString();
                    newEthernetPortConfiguration.SubnetMask = adapterSubnetMask.ToString();
                    newEthernetPortConfiguration.DefaultGateway = adapterDefaultGateway.ToString();
                    newEthernetPortConfiguration.DnsServer = adapterDnsServer.ToString();
                    newEthernetPortConfiguration.UseDhcpServer = adapterUseDhcpServer;
                    newEthernetPortConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                    ConfigurationManager.Instance.UpdateConfiguration(configurationItems, false, userAuditInfo, true);
                    dataFlashConfigUpdateRequired = true;
                }
                if (dataFlashConfigUpdateRequired == true)
                {
                    // Save configuration to data flash. Update to data flash is always required at this point.
                    dataFlashConfig.IPAddress = adapterIPAddress;
                    dataFlashConfig.SubnetMask = adapterSubnetMask;
                    dataFlashConfig.Gateway = adapterDefaultGateway;
                    dataFlashConfig.DnsServer = adapterDnsServer;
                    dataFlashConfig.DhcpEnabled = adapterUseDhcpServer;
                    dataFlashConfig.Update();
                }
                // Update network adapter
                networkAdapters.UpdateOnboardAdapter(adapterIPAddress, adapterSubnetMask, adapterDefaultGateway, adapterDnsServer, adapterUseDhcpServer);
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Updating network adapter from data flash failed. {0}", ex.Message);
                });
            }
        }

        /// <summary>
        /// Update network adapter state from configuration
        /// </summary>
        /// <param name="reason"></param>
        /// <param name="userAuditInfo">User audit details: user type, user Id.</param>
        private void updateNetworkAdapterFromConfiguration(ConfigurationUpdateReason reason, UserAuditInfo userAuditInfo)
        {
            try
            {
                DataFlashConfig dataFlashConfig = new DataFlashConfig(dataFlash);
                // When configuration is present compare first with what is saved in configuration
                if (reason == ConfigurationUpdateReason.Initial || reason == ConfigurationUpdateReason.FrontEndOrWeb)
                {
                    IPAddress configIPAddress = IPAddress.Any;
                    IPAddress configSubnetMask = IPAddress.Any;
                    IPAddress configDefaultGateway = IPAddress.Any;
                    IPAddress configDnsServer = IPAddress.Any;
                    bool configUseDhcpServer = false;

                    bool configurationValid = true;
                    try
                    {
                        if (controllerConfiguration.EthernetPort != null)
                        {
                            configIPAddress = IPAddress.Parse(controllerConfiguration.EthernetPort.IPAddress);
                            configSubnetMask = IPAddress.Parse(controllerConfiguration.EthernetPort.SubnetMask);
                            configDefaultGateway = IPAddress.Parse(controllerConfiguration.EthernetPort.DefaultGateway);
                            configDnsServer = IPAddress.Parse(controllerConfiguration.EthernetPort.DnsServer);
                            configUseDhcpServer = controllerConfiguration.EthernetPort.UseDhcpServer;
                        }
                        else
                        {
                            configurationValid = false;
                            controllerConfiguration.EthernetPort = new IPPortConfiguration();
                            controllerConfiguration.EthernetPort.SetDefaults();
                        }
                    }
                    catch
                    {
                        configurationValid = false;
                    }
                    if (configurationValid == true)
                    {
                        // Configuration is parsed and ready to compare
                        if (dataFlashConfig.IPAddress.Equals(configIPAddress) &&
                            dataFlashConfig.SubnetMask.Equals(configSubnetMask) &&
                            dataFlashConfig.Gateway.Equals(configDefaultGateway) &&
                            dataFlashConfig.DnsServer.Equals(configDnsServer) &&
                            dataFlashConfig.DhcpEnabled == configUseDhcpServer)
                        {
                            // The configuration is the same - just exit
                            return;
                        }
                    }
                }

                IPAddress adapterIPAddress = IPAddress.Any;
                IPAddress adapterSubnetMask = IPAddress.Any;
                IPAddress adapterDefaultGateway = IPAddress.Any;
                IPAddress adapterDnsServer = IPAddress.Any;
                bool adapterUseDhcpServer = false;
                bool valid = true;
                do
                {

                    try
                    {
                        adapterIPAddress = IPAddress.Parse(controllerConfiguration.EthernetPort.IPAddress);
                    }
                    catch
                    {
                        valid = false;
                        Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return "Unable to parse configuration IP address.";
                        });
                        break;
                    }
                    try
                    {
                        adapterSubnetMask = IPAddress.Parse(controllerConfiguration.EthernetPort.SubnetMask);
                    }
                    catch
                    {
                        valid = false;
                        Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return "Unable to parse configuration subnet mask.";
                        });
                        break;
                    }
                    try
                    {
                        adapterDefaultGateway = IPAddress.Parse(controllerConfiguration.EthernetPort.DefaultGateway);
                    }
                    catch
                    {
                        valid = false;
                        Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return "Unable to parse configuration default gateway.";
                        });
                        break;
                    }
                    try
                    {
                        adapterDnsServer = IPAddress.Parse(controllerConfiguration.EthernetPort.DnsServer);
                    }
                    catch
                    {
                        valid = false;
                        Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return "Unable to parse configuration DNS server.";
                        });
                        break;
                    }
                    adapterUseDhcpServer = controllerConfiguration.EthernetPort.UseDhcpServer;

                } while (false);
                if (valid == true)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return "Using configuration values for onboard ethernet port.";
                    });
                    // Save configuration to data flash
                    dataFlashConfig.IPAddress = adapterIPAddress;
                    dataFlashConfig.SubnetMask = adapterSubnetMask;
                    dataFlashConfig.Gateway = adapterDefaultGateway;
                    dataFlashConfig.DnsServer = adapterDnsServer;
                    dataFlashConfig.DhcpEnabled = adapterUseDhcpServer;
                    dataFlashConfig.Update();
                    // Update network adapter
                    networkAdapters.UpdateOnboardAdapter(adapterIPAddress, adapterSubnetMask, adapterDefaultGateway, adapterDnsServer, adapterUseDhcpServer);
                }
                else
                {
                    // Something went wrong. Use the configuration from data flash.
                    updateNetworkAdapterFromDataFlash(ConfigurationUpdateReason.NoConfiguration, userAuditInfo);
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Updating network adapter from configuration failed. {0}", ex.Message);
                });
            }
        }

        private void getAllItems(IConfigurationList configurationList, ConfigurationElementType configurationElementType, List<ConfigurationChanges> removedItems)
        {
            foreach (int id in configurationList.AsKeyList)
            {
                ConfigurationChanges configurationChanges = new ConfigurationChanges() { ConfigurationType = configurationElementType, Id = id };
                INodeConfiguration node = configurationList.GetItem(id) as INodeConfiguration;
                if (node != null)
                {
                    configurationChanges.ParentDeviceId = node.ParentDeviceId;
                    var expansionCardConfiguration = ConfigurationManager.Instance.GetExpansionCardDeviceConfiguration(node.ParentDeviceId);
                    if (expansionCardConfiguration != null)
                        configurationChanges.GrandParentDeviceId = expansionCardConfiguration.ParentDeviceId;
                }

                removedItems.Add(configurationChanges);
            }
        }

        private bool loadConfigurationItem<T>(Type baseType, Type derivedType, ConfigurationBase configurationItem, IConfigurationList configurationList,
            ConfigurationElementType configurationElementType, List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems,
            List<ConfigurationChanges> removedItems, Dictionary<Type, System.Reflection.PropertyInfo[]> reflectionDictionary)
        {
            if (configurationItem.GetType() == baseType)
            {
                bool configurationAdded = false;
                bool configurationChanged = false;
                ConfigurationChanges configurationDescription = new ConfigurationChanges() { ConfigurationType = configurationElementType, Id = configurationItem.Id };

                INodeConfiguration node = configurationItem as INodeConfiguration;
                if (node != null)
                {
                    configurationDescription.ParentDeviceId = node.ParentDeviceId;
                    ExpansionCardDeviceConfigurationBase parentDevice = GetExpansionCardDeviceConfiguration(node.ParentDeviceId);
                    if (parentDevice != null)
                        configurationDescription.GrandParentDeviceId = parentDevice.ParentDeviceId;
                }

                ConfigurationBase output = configurationList.GetItem(configurationItem.Id) as ConfigurationBase;
                if (output == null)
                {
                    if (derivedType == typeof(ControllerConnectionTable))
                        output = new ControllerConnectionTable(sram);
                    else
                        output = (ConfigurationBase)Activator.CreateInstance(derivedType);
                    configurationList.SetItem(configurationItem.Id, output as IConfiguration);
                    if (newlyAddedItems != null)
                        newlyAddedItems.Add(configurationDescription);
                    configurationAdded = true;
                }
                else if (output.GetType() != derivedType)
                {
                    output = (ConfigurationBase)Activator.CreateInstance(derivedType);
                    configurationList.SetItem(configurationItem.Id, output as IConfiguration);
                    configurationChanged = true;
                }
                if (removedItems.Remove(configurationDescription) == false && configurationAdded == false)
                {
                    if (newlyAddedItems != null)
                        newlyAddedItems.Add(configurationDescription);
                    configurationAdded = true;
                }
                configurationChanged |= ConfigurationManager.CopyConfiguration(reflectionDictionary, configurationItem, output);
                if (configurationChanged && configurationAdded == false && changedItems != null)
                    changedItems.Add(configurationDescription);
                return true;
            }
            return false;
        }

        private void loadAsn1File(string filePath, Asn1DerFormatter asn1Serializer,
            List<ConfigurationChanges> additions, List<ConfigurationChanges> changes, List<ConfigurationChanges> removals)
        {
            if (File.Exists(filePath) == false)
                return;

            Dictionary<Type, System.Reflection.PropertyInfo[]> reflectionDictionary = new Dictionary<Type, System.Reflection.PropertyInfo[]>();

            using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
            {
                while (fileStream.Position < fileStream.Length)
                {
                    try
                    {
                        ConfigurationBase configurationItem = (ConfigurationBase)asn1Serializer.Deserialize(fileStream);
                        if (configurationItem == null || configurationItem.Id < 1)
                            continue;

                        Device8003Configuration deviceConfig = configurationItem as Device8003Configuration;
                        if (deviceConfig != null)
                        {
                            string password = deviceConfig.WebserverPassword;
                            if (string.IsNullOrEmpty(password) == false && password.StartsWith(ConfigConsts.EncryptedStringPrefix) == true)
                                deviceConfig.WebserverPassword = password.Substring(ConfigConsts.EncryptedStringPrefixLength).Decrypt();
                        }

                        if (loadConfigurationItem<ControllerConfigurationWrapper>(typeof(Device8003Configuration), typeof(Pacom8003Configuration), configurationItem, controllerConfigurationWrapper, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;

                        if (loadConfigurationItem<AreaConfigurationList>(typeof(Area8003Configuration), typeof(AreaConfiguration), configurationItem, areas, ConfigurationElementType.Area, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device1064DCConfiguration), typeof(Pacom1064DCConfiguration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device1064IOConfiguration), typeof(Pacom1064IOConfiguration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device1068Configuration), typeof(Pacom1068Configuration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device1076DCConfiguration), typeof(Pacom1076DCConfiguration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device1076IOConfiguration), typeof(Pacom1076IOConfiguration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8003KeypadConfiguration), typeof(Pacom8101KeypadConfiguration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8303PowerSupplyConfiguration), typeof(Pacom8303Configuration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8308PowerSupplyConfiguration), typeof(Pacom8308Configuration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8501DCConfiguration), typeof(Pacom8501Configuration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;                       
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8501ECConfiguration), typeof(Pacom8501ECConfiguration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue; 
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8603DCConfiguration), typeof(Pacom8603Configuration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8502Configuration), typeof(Pacom8502Configuration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device1065IOConfiguration), typeof(Pacom1065IOConfiguration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(AperioDriverConfiguration), typeof(AperioDriver), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(InovonicsReceiverDeviceConfiguration), typeof(Inovonics8003ReceiverDeviceConfiguration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(InovonicsRepeaterDeviceConfiguration), typeof(Inovonics8003RepeaterDeviceConfiguration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(InovonicsSecurityDeviceConfiguration), typeof(Inovonics8003SecurityDeviceConfiguration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device1076VCConfiguration), typeof(Pacom1076VCConfiguration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
#if INOVONICSTEMPERATUREDEMO
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(inovonicsTemperatureDeviceConfiguration), typeof(Inovonics8003TemperatureDeviceConfiguration), configurationItem, devices, ConfigurationElementType.Device, additions, changes, removals, reflectionDictionary)) continue;
#endif
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8201ExpansionConfiguration), typeof(Pacom8201ExpansionConfiguration), configurationItem, expansionCards, ConfigurationElementType.ExpansionCard, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8203ExpansionConfiguration), typeof(Pacom8203ExpansionConfiguration), configurationItem, expansionCards, ConfigurationElementType.ExpansionCard, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8204ExpansionConfiguration), typeof(Pacom8204ExpansionConfiguration), configurationItem, expansionCards, ConfigurationElementType.ExpansionCard, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8205ExpansionConfiguration), typeof(Pacom8205ExpansionConfiguration), configurationItem, expansionCards, ConfigurationElementType.ExpansionCard, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8207ExpansionConfiguration), typeof(Pacom8207ExpansionConfiguration), configurationItem, expansionCards, ConfigurationElementType.ExpansionCard, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8208ExpansionConfiguration), typeof(Pacom8208ExpansionConfiguration), configurationItem, expansionCards, ConfigurationElementType.ExpansionCard, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<DeviceConfigurationList>(typeof(Device8209ExpansionConfiguration), typeof(Pacom8209ExpansionConfiguration), configurationItem, expansionCards, ConfigurationElementType.ExpansionCard, additions, changes, removals, reflectionDictionary)) continue;

                        if (loadConfigurationItem<DoorConfigurationList>(typeof(Door8003Configuration), typeof(DoorConfiguration), configurationItem, doors, ConfigurationElementType.Door, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<InterlockGroupConfigurationList>(typeof(Interlock8003Configuration), typeof(InterlockGroupConfiguration), configurationItem, interlockGroups, ConfigurationElementType.InterlockGroup, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<VaultControllerInterlockGroupConfigurationList>(typeof(VaultControllerInterlock8003Configuration), typeof(VaultControllerInterlockGroupConfiguration), configurationItem, vaultControllerInterlockGroups, ConfigurationElementType.VaultControllerInterlockGroup, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<GroupConfigurationList>(typeof(Group8003Configuration), typeof(GroupConfiguration), configurationItem, groups, ConfigurationElementType.Group, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<InputConfigurationList>(typeof(AnalogueInput8003Configuration), typeof(InputConfiguration), configurationItem, inputs, ConfigurationElementType.Input, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<InputConfigurationList>(typeof(Input8003Configuration), typeof(InputConfiguration), configurationItem, inputs, ConfigurationElementType.Input, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<MacroConfigurationList>(typeof(Macro8003Configuration), typeof(MacroConfiguration), configurationItem, macros, ConfigurationElementType.Macro, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<OutputConfigurationList>(typeof(Output8003Configuration), typeof(OutputConfiguration), configurationItem, outputs, ConfigurationElementType.Output, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<ElevatorConfigurationList>(typeof(Elevator8003Configuration), typeof(ElevatorConfiguration), configurationItem, elevators, ConfigurationElementType.Elevator, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<ElevatorConfigurationList>(typeof(LegacyElevator8003Configuration), typeof(LegacyElevatorConfiguration), configurationItem, elevators, ConfigurationElementType.Elevator, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<ElevatorFloorConfigurationList>(typeof(ElevatorFloor8003Configuration), typeof(ElevatorFloorConfiguration), configurationItem, elevatorFloors, ConfigurationElementType.ElevatorFloor, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<PresenceZoneConfigurationList>(typeof(PresenceZone8003Configuration), typeof(PresenceZoneConfiguration), configurationItem, presenceZones, ConfigurationElementType.PresenceZone, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<ReaderConfigurationList>(typeof(Reader8003LegacyWiegandConfiguration), typeof(ReaderConfiguration), configurationItem, readers, ConfigurationElementType.Reader, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<ReaderConfigurationList>(typeof(Reader8003Configuration), typeof(ReaderUnisonConfiguration), configurationItem, readers, ConfigurationElementType.Reader, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<Pacom8003AccessScheduleList>(typeof(AccessSchedule), typeof(Pacom8003AccessSchedule), configurationItem, accessSchedules, ConfigurationElementType.AccessSchedule, additions, changes, removals, reflectionDictionary)) continue;

                        loadConfigurationItem<Pacom8003AreaScheduleList>(typeof(Schedule), typeof(Pacom8003AreaSchedule), configurationItem, areaSchedules, ConfigurationElementType.Schedule, additions, changes, removals, reflectionDictionary);
                        loadConfigurationItem<EgressScheduleList>(typeof(Schedule), typeof(EgressSchedule), configurationItem, egressSchedules, ConfigurationElementType.Schedule, null, null, removals, reflectionDictionary);
                        loadConfigurationItem<OutputScheduleList>(typeof(Schedule), typeof(OutputSchedule), configurationItem, outputSchedules, ConfigurationElementType.Schedule, null, null, removals, reflectionDictionary);
                        loadConfigurationItem<ElevatorFloorUnlockScheduleList>(typeof(Schedule), typeof(ElevatorFloorUnlockSchedule), configurationItem, elevatorFloorUnlockSchedules, ConfigurationElementType.Schedule, null, null, removals, reflectionDictionary);
                        if (loadConfigurationItem<ReaderScheduleList>(typeof(Schedule), typeof(ReaderSchedule), configurationItem, readerSchedules, ConfigurationElementType.Schedule, null, null, removals, reflectionDictionary)) continue;

                        if (loadConfigurationItem<AccessGroupList>(typeof(AccessGroup), typeof(AccessGroup), configurationItem, accessGroups, ConfigurationElementType.AccessGroup, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<LegacyCardFormatList>(typeof(LegacyCardFormat), typeof(LegacyCardFormat), configurationItem, cardFormats, ConfigurationElementType.CardFormat, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<PortConfigurationList>(typeof(Port8003GprsPortConfiguration), typeof(GprsPortConfiguration), configurationItem, ports, ConfigurationElementType.Port, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<PortConfigurationList>(typeof(Port8003IPPortConfiguration), typeof(IPPortConfiguration), configurationItem, ports, ConfigurationElementType.Port, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<PortConfigurationList>(typeof(Port8003RS485OsdpDeviceLoopPortConfiguration), typeof(RS485OsdpDeviceLoopPortConfiguration), configurationItem, ports, ConfigurationElementType.Port, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<PortConfigurationList>(typeof(Port8003RS485AsisProprietaryReaderPortConfiguration), typeof(RS485AsisProprietaryReaderPortConfiguration), configurationItem, ports, ConfigurationElementType.Port, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<PortConfigurationList>(typeof(Port8003RS485AperioPortConfiguration), typeof(RS485AperioPortConfiguration), configurationItem, ports, ConfigurationElementType.Port, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<PortConfigurationList>(typeof(Port8003RS485DeviceLoopPortConfiguration), typeof(RS485DeviceLoopPortConfiguration), configurationItem, ports, ConfigurationElementType.Port, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<PortConfigurationList>(typeof(Port8003DialupPortConfiguration), typeof(DialupPortConfiguration), configurationItem, ports, ConfigurationElementType.Port, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<PortConfigurationList>(typeof(Port8003RS232InovonicsPortConfiguration), typeof(RS232InovonicsPortConfiguration), configurationItem, ports, ConfigurationElementType.Port, additions, changes, removals, reflectionDictionary)) continue;
                        if (loadConfigurationItem<PortConfigurationList>(typeof(Port8003RS232DebugPortConfiguration), typeof(RS232DebugPortConfiguration), configurationItem, ports, ConfigurationElementType.Port, additions, changes, removals, reflectionDictionary)) continue;

                        OpenPacomToDigitalReceiver8003Template openPacomToDigitalReceiver8003Template = configurationItem as OpenPacomToDigitalReceiver8003Template;
                        if (openPacomToDigitalReceiver8003Template != null)
                        {
                            // Checking if the template has changed is hard so we just assume that it has changed.
                            // The consequence of this that any active digital receiver connections will be dropped when any configuration is changed.
                            ConfigurationChanges configurationDescription = new ConfigurationChanges() { ConfigurationType = ConfigurationElementType.OpenPacomToDigitalReceiverTemplate, Id = 1 };
                            if (openPacomToDigitalReceiverTemplates.ContainsKey(1))
                                changes.Add(configurationDescription);
                            else
                                additions.Add(configurationDescription);
                            removals.Remove(configurationDescription);

                            openPacomToDigitalReceiverTemplates[1] = new OpenPacomToDigitalReceiverTemplate(openPacomToDigitalReceiver8003Template);
                            continue;
                        }

                        if (loadConfigurationItem<CalendarWrapper>(typeof(Calendar), typeof(Calendar), configurationItem, calendarWrapper, ConfigurationElementType.Calendar, additions, changes, removals, reflectionDictionary)) continue;

                        ControllerConnection8003Table connectionTable = configurationItem as ControllerConnection8003Table;
                        if (connectionTable != null)
                        {
                            string password = connectionTable.Password;
                            if (string.IsNullOrEmpty(password) == false && password.StartsWith(ConfigConsts.EncryptedStringPrefix) == true)
                                connectionTable.Password = password.Substring(ConfigConsts.EncryptedStringPrefixLength).Decrypt();
                        }
                        if (loadConfigurationItem<ControllerConnectionTableList>(typeof(ControllerConnection8003Table), typeof(ControllerConnectionTable), configurationItem, controllerConnectionTableList, ConfigurationElementType.ControllerConnectionTable, additions, changes, removals, reflectionDictionary)) continue;
                    }
                    catch (Exception ex)
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return string.Format("Failed loading configuration item at position {0} from config.asn1 file. Handled exception : {1}",
                                fileStream.Position, ex.ToString());
                        });
                        continue;
                    }
                }
            }
            MarkConfigurationFileAsProcessed(filePath);
        }

        #endregion

        #region Configuration changing

        /// <summary>
        /// Trigger configuration changing event handler
        /// </summary>
        internal void CallConfigurationChangingEvent(ConfigurationElementsAffected changes)
        {
            if (ConfigurationChanging == null)
                return;

            try
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return "Configuration CHANGING!";
                });
                ConfigurationChangeEventArgs eventArgs = new ConfigurationChangeEventArgs(changes);
                ConfigurationChanging(this, eventArgs);
                if (AfterConfigurationChanging != null)
                    AfterConfigurationChanging(this, eventArgs);
            }
            catch (Exception ex)
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Error while preparing for configuration change : {0}", ex.ToString());
                });
            }
        }

        /// <summary>
        /// Trigger configuration changed event handler
        /// </summary>
        internal void CallConfigurationChangedEvent(ConfigurationElementsAffected changes, List<ConfigurationChanges> newlyAddedItems, List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems)
        {
            if (ConfigurationChanged == null)
                return;

            try
            {
                ConfigurationChangeEventArgs eventArgs = new ConfigurationChangeEventArgs(changes, newlyAddedItems, changedItems, removedItems);
                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, eventArgs.ToString); // TODO: remove this before release
                if (BeforeConfigurationChanged != null)
                    BeforeConfigurationChanged(this, eventArgs);

                ConfigurationChanged(this, eventArgs);
                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return "Configuration successfully CHANGED!";
                });
            }
            catch (Exception ex)
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Error while applying configuration : {0}", ex.ToString());
                });
            }
        }

        /// <summary>
        /// Create atomic configuration changer handler instance. The instance must be disposed before other part of the code can create it.
        /// This is the only way to call ConfigurationChanging and ConfigurationChanged events.
        /// </summary>
        /// <param name="changes">Flag with change elements affecting this operation</param>
        /// <returns></returns>
        public ConfigurationChanger CreateConfigurationChanger(ConfigurationElementsAffected changes)
        {
            ConfigurationChanger result = new ConfigurationChanger(this, changes);
            return result;
        }

        /// <summary>
        /// Create atomic configuration changer handler instance. The instance must be disposed before other part of the code can create it.
        /// This is the only way to call ConfigurationChanging and ConfigurationChanged events.
        /// </summary>
        /// <param name="changes">Flag with change elements affecting this operation</param>
        /// <returns></returns>
        public ConfigurationChanger TryCreateConfigurationReader()
        {
            ConfigurationChanger result = new ConfigurationChanger(this);
            return result;
        }

        public void RequestConfigurationFromFrontEnd()
        {
            if (ConfigurationDownloadRequest != null)
                ConfigurationDownloadRequest(this, new EventArgs());
        }
        #endregion

        #region Save configuration to disk

        /// <summary>
        /// Inform Front-End that configuration has changed
        /// </summary>
        /// <param name="identifier">String Identifier of the configuration item that has changed</param>
        /// <param name="userAuditInfo">User that initiaited the configuration change(s).</param>
        public void NotifyFrontEndConfigurationChanged(string identifier, UserAuditInfo userAuditInfo)
        {
            if (InformFrontEndThatConfigurationChanged != null)
            {
                InformFrontEndThatConfigurationChanged(this, new ChangedConfigurationEventArgs(controllerConfiguration.Id, identifier, userAuditInfo));
            }
        }

        public void NotifyFrontEndConfigurationChangeInProgress(string identifier, UserAuditInfo userAuditInfo)
        {
            if (InformFrontEndThatConfigurationChangeInProgress != null)
            {
                InformFrontEndThatConfigurationChangeInProgress(this, new ConfigurationChangeInProgressEventArgs(controllerConfiguration.Id, identifier, userAuditInfo));
            }
        }

        public void TriggerUserConfigurationChanged(int id, UserAuditInfo userAuditInfo)
        {
            NotifyFrontEndConfigurationChanged(string.Format("/Users/{0}", id), userAuditInfo);
        }

        /// <summary>
        /// Check if directory exists and if not found create the directory.
        /// </summary>
        /// <returns>Return True if the directory already exists or was created successfully, False otherwise.</returns>
        private bool tryDirectoryExists()
        {
            bool directoryExists = Directory.Exists(FileSystemPaths.ConfigurationDirectory);
            if (directoryExists == false)
            {
                DirectoryInfo di = Directory.CreateDirectory(FileSystemPaths.ConfigurationDirectory);
                directoryExists = di != null && di.Exists;
            }
            if (directoryExists == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Unable to create configuration directory: {0}. The default configuration can't be saved to config.asn1 file.",
                        FileSystemPaths.ConfigurationDirectory);
                });
                return false;
            }
            return true;
        }

        #endregion

        #region User Logger

        /// <summary>
        /// Front End User logging information
        /// </summary>
        private static UserAuditInfo frontEndUser = new UserAuditInfo(OriginatingUserType.FrontEndUser, StatusConsts.FrontEndUser);
        public static UserAuditInfo FrontEndUser
        {
            get { return frontEndUser; }
        }

        /// <summary>
        /// Web Server User logging information
        /// </summary>
        private static UserAuditInfo webServerUser = new UserAuditInfo(OriginatingUserType.WebServerUser, StatusConsts.WebServerUser);
        public static UserAuditInfo WebServerUser
        {
            get { return webServerUser; }
        }

        /// <summary>
        /// System User logging information
        /// </summary>
        private static UserAuditInfo systemUser = new UserAuditInfo(OriginatingUserType.SystemUser, StatusConsts.SystemUser);
        public static UserAuditInfo SystemUser
        {
            get { return systemUser; }
        }

        /// <summary>
        /// Schedule User logging information
        /// </summary>
        private static UserAuditInfo scheduleUser = new UserAuditInfo(OriginatingUserType.SystemUser, StatusConsts.ScheduleUser);
        public static UserAuditInfo ScheduleUser
        {
            get { return scheduleUser; }
        }

        /// <summary>
        /// Macro User logging information
        /// </summary>
        private static UserAuditInfo macroUser = new UserAuditInfo(OriginatingUserType.ExpressionEngineUser, StatusConsts.MacroUser);
        public static UserAuditInfo MacroUser
        {
            get { return macroUser; }
        }

        /// <summary>
        /// Alarm User logging information
        /// </summary>
        private static UserAuditInfo alarmUser = new UserAuditInfo(OriginatingUserType.AlarmKeypadUser, StatusConsts.UndefinedUser);
        public static UserAuditInfo AlarmUser(int userId)
        {
            alarmUser.OriginatingUserId = userId;
            return alarmUser;
        }

        #endregion

        #region IDisposable Members

        bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.
                instance = null;
            }

            // Free any unmanaged objects here.            
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
