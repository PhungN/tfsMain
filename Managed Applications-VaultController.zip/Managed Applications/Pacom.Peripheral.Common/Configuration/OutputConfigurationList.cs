﻿using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class OutputConfigurationList : NodeConfigurationListBase<OutputConfiguration>, IConfigurationList
    {
        internal OutputConfigurationList() : base() { }

        /// <summary>
        /// Return output configuration referenced by logical id
        /// </summary>
        /// <param name="logicalId">Output logical id, 1 based</param>
        /// <returns>Output configuration instance or null if not found</returns>
        public override OutputConfiguration this[int logicalId]
        {
            set
            {
                if (value != null && value.Enabled == true && Exists(logicalId) == false && EnabledCount >= LicenseManager.Instance.MaximumOutputCount)
                {
                    value.Enabled = false;
                    string outputName = ConfigurationStringRepository.RetrieveName(ConfigurationType.Output, value.Id);
                    Logger.LogWarnMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("Licensing limit exceeded. The added output {0} will be disabled.", outputName);
                    });
                }
                base[logicalId] = value;
            }
        }

        /// <summary>
        /// Get next output Id
        /// </summary>
        public int NextOutputId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
