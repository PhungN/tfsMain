﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class ElevatorConfiguration : Elevator8003Configuration, IElevatorConfiguration
    {
        public ElevatorConfiguration()
        {
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Elevator, Id, Name);
                Name = null;
            }
        }

        /// <summary>
        /// Get elevator name from repository
        /// </summary>
        /// <returns>Elevator Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Elevator, Id);
        }

        public int[] GetFloorControllerAddresses()
        {
            return new int[]
            {
                ElevatorController1To16Id,
                ElevatorController17To32Id,
                ElevatorController33To48Id,
                ElevatorController49To64Id,
                ElevatorController65To80Id,
                ElevatorController81To96Id,
                ElevatorController97To112Id,
                ElevatorController113To128Id,
            };
        }

        public int GetFloorAccessTime(int floorControllerAddress)
        {
            if (GetFloorControllerAddresses().Contains(floorControllerAddress) == true)
            {
                return (EnableApartmentMode == true) ? (int)FloorAccessTime.TotalSeconds : 0;
            }
            return -1;
        }

        public bool IsValidReaderSchedule
        {
            get
            {
                ReaderSchedule schedule = ConfigurationManager.Instance.GetReaderSchedule(ScheduleId);
                return ConfigurationManager.Instance.ValidateSchedule(schedule);
            }
        }

        public bool IsValidFloorSelectionReportingSchedule
        {
            get
            {
                ReaderSchedule schedule = ConfigurationManager.Instance.GetReaderSchedule(FloorSelectedReportingScheduleId);
                return ConfigurationManager.Instance.ValidateSchedule(schedule);
            }
        }
    }


    public sealed class LegacyElevatorConfiguration : LegacyElevator8003Configuration, ILegacyElevatorConfiguration
    {
        public LegacyElevatorConfiguration()
        {
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Elevator, Id, Name);
                Name = null;
            }
        }

        /// <summary>
        /// Get elevator name from repository
        /// </summary>
        /// <returns>Elevator Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Elevator, Id);
        }

        public int[] GetFloorControllerAddresses()
        {
            return new int[]
            {
                ElevatorController1To16Id,
                ElevatorController17To32Id,
                ElevatorController33To48Id,
                ElevatorController49To64Id,
                ElevatorController65To80Id,
                ElevatorController81To96Id,
                ElevatorController97To112Id,
                ElevatorController113To128Id,
            };
        }

        public int GetFloorAccessTime(int floorControllerAddress)
        {
            if (GetFloorControllerAddresses().Contains(floorControllerAddress) == true)
            {
                return (EnableApartmentMode == true) ? (int)FloorAccessTime.TotalSeconds : 0;
            }
            return -1;
        }

        public bool IsValidReaderSchedule
        {
            get
            {
                ReaderSchedule schedule = ConfigurationManager.Instance.GetReaderSchedule(ScheduleId);
                return ConfigurationManager.Instance.ValidateSchedule(schedule);
            }
        }

        public bool IsValidFloorSelectionReportingSchedule
        {
            get
            {
                ReaderSchedule schedule = ConfigurationManager.Instance.GetReaderSchedule(FloorSelectedReportingScheduleId);
                return ConfigurationManager.Instance.ValidateSchedule(schedule);
            }
        }
    }

}
