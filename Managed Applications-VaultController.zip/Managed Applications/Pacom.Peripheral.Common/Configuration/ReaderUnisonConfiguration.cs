﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class ReaderUnisonConfiguration : Reader8003Configuration, IReaderConfiguration
    {
        public ReaderUnisonConfiguration()
        {
            EnterIntoPresenceZoneIds = new int[0];
            ExitOutOfPresenceZoneIds = new int[0];
        }

        public static int AutoConfigure(DeviceConfigurationBase parentDevice, int pointNumberOnParent, List<ConfigurationBase> configuration)
        {
            Reader8003Configuration readerConfiguration = new Reader8003Configuration();
            readerConfiguration.SetDefaults();
            readerConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            readerConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            readerConfiguration.Id = ConfigurationManager.Instance.NextReaderId;
            readerConfiguration.ParentDeviceId = parentDevice.Id;
            readerConfiguration.PointNumberOnParent = pointNumberOnParent;
            if (ConfigurationManager.Instance.DefaultingConfiguration || ConfigurationManager.Instance.GetAreaConfiguration(1) != null)
                readerConfiguration.AreaId = 1;
            else
                readerConfiguration.AreaId = 0;
            readerConfiguration.Name = string.Format("Reader {0}:{1}", parentDevice.Name, pointNumberOnParent);
            configuration.Add(readerConfiguration);
            return readerConfiguration.Id;
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        public void AutoConfigure(DeviceConfigurationBase parentDevice, int pointNumberOnParent)
        {
            InitializeWithDefaults();
            Id = ConfigurationManager.Instance.NextReaderId;
            ParentDeviceId = parentDevice.Id;
            PointNumberOnParent = pointNumberOnParent;
            AreaId = 1;
            Area = ConfigurationManager.Instance.GetAreaConfiguration(AreaId);
            if (Area != null)
                Area.AddReader(this);
            string parentDeviceName = ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, parentDevice.Id);
            ConfigurationStringRepository.AddName(ConfigurationType.Reader, Id, string.Format("Reader {0}:{1}", parentDeviceName, pointNumberOnParent));
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Reader, Id, Name);
                Name = null;
            }

            if (EnterIntoPresenceZoneIds == null)
                EnterIntoPresenceZoneIds = new int[0];
            if (ExitOutOfPresenceZoneIds == null)
                ExitOutOfPresenceZoneIds = new int[0];
        }

        public DoorConfiguration Door { get; set; }

        public ReaderSchedule ReaderSchedule { get; set; }

        public EgressSchedule EgressSchedule { get; set; }

        public AreaConfiguration Area { get; set; }

        public PresenceZoneConfiguration[] EnterIntoPresenceZones { get; set; }

        public PresenceZoneConfiguration[] ExitOutOfPresenceZones { get; set; }

        /// <summary>
        /// Get reader name from repository
        /// </summary>
        /// <returns>Reader Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Reader, Id);
        }
    }
}
