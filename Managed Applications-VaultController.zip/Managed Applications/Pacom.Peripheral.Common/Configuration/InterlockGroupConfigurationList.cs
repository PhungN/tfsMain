﻿namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class InterlockGroupConfigurationList : ConfigurationListBase<InterlockGroupConfiguration>, IConfigurationList
    {
        internal InterlockGroupConfigurationList() : base() { }

        /// <summary>
        /// Get next interlock group Id
        /// </summary>
        public int NextInterlockGroupId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
