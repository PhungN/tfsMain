﻿using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class VautControllerConfigurationList : NodeConfigurationListBase<VaultControllerConfiguration>, IConfigurationList
    {
        internal VautControllerConfigurationList() : base() { }

        /// <summary>
        /// Return vault controller configuration referenced by logical id
        /// </summary>
        /// <param name="logicalId">logical id, 1 based</param>
        /// <returns>vault controller configuration instance or null if not found</returns>
        public override VaultControllerConfiguration this[int logicalId]
        {
            set
            {
                base[logicalId] = value;
            }
        }

        /// <summary>
        /// Get next output Id
        /// </summary>
        public int NextId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
