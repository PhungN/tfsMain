﻿using System;
using System.Collections.Generic;
using Pacom.Core.Access;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class UserUnisonConfiguration : User, IUserConfiguration
    {
        public UserUnisonConfiguration()
        {
            UserMode = ControllerMode.Unison;
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        public void AutoConfigure()
        {
            InitializeWithDefaults();
            Name = "Admin";
            Name = null;
            UserPin = 2461;
            OutsideHoursAccess = true;
            UserManagementPrivilege = true;
            AutoIsolateDeisolatePoints = false;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
        }

        /// <summary>
        /// Get / Set User Mode, either GMS/EMCS or Unison
        /// </summary>
        public ControllerMode UserMode
        {
            get;
            private set;
        }

        /// <summary>
        /// A sequence of areas that the user has permission to Arm / Disarm.
        /// </summary>
        public int[] AreaIds
        {
            get
            {
                List<int> ids = new List<int>();
                DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
                if (now < ValidFrom || now > ValidTo)
                    return ids.ToArray();

                if (AccessGroups == null)
                    return ids.ToArray();
                foreach (var userAccess in AccessGroups)
                {
                    if (now < userAccess.StartDateTime || now > userAccess.EndDateTime)
                        continue;

                    AccessGroup accessGroup = ConfigurationManager.Instance.GetAccessGroupConfiguration(userAccess.AccessGroupId);
                    if (accessGroup == null)
                        continue;

                    if (accessGroup.AccessGroupMembers == null || accessGroup.AccessGroupMembers.Length == 0)
                        continue;

                    foreach (var accessGroupMember in accessGroup.AccessGroupMembers)
                    {
                        if (accessGroupMember.NodeCategory == NodeCategory.Area && accessGroupMember.NodeId > 0 && now >= accessGroupMember.ValidFrom && now <= accessGroupMember.ValidTo)
                        {
                            // We could create a new UnisonAccess class that is identical to the existing Egress schedule
                            // or rename the Egress schedule but for the time being, we will just use the Egress schedule as is.
                            EgressSchedule schedule = ConfigurationManager.Instance.GetEgressSchedule(accessGroupMember.ScheduleId);
                            if (schedule == null)
                                continue;
                            if (schedule.Enabled)
                                ids.Add(accessGroupMember.NodeId);
                        }
                    }
                }
                return ids.ToArray();

            }
            set { }
        }

        public AreaAccessPrivilege[] AreaAccessPrivilege
        {
            get;
            set;
        }

        /// <summary>
        /// Get the user accessible areas count
        /// </summary>
        public int AreaCount
        {
            get { return AreaIds.Length; }
        }

        /// <summary>
        /// Check if this is an engineer level user (Access Level 3 user)
        /// </summary>
        public bool IsEngineer
        {
            get
            {
                GroupConfiguration groupConfig = ConfigurationManager.Instance.GetGroupConfiguration(GroupId);
                return groupConfig != null ? groupConfig.IsEngineer : false;
            }
        }

        /// <summary>
        /// Get the user's name from repository
        /// </summary>
        /// <returns>The user's Name</returns>
        public string GetName()
        {
            return Name;
        }

        /// <summary>
        /// Get user LastName / FirstName from stored name in format LastName,FirstName
        /// </summary>
        public string[] GetLastFirstName()
        {
            string name = Name;
            if (string.IsNullOrEmpty(name))
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return "Empty user name.";
                });
                return new string[0];
            }

            // Return a string array with LastName = name[0] and FirstName = name[1]
            string[] names = name.Split(new char[] { ',' });
            if (names.Length < 1)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Invalid user name: {0}", name);
                });
            }
            return names;
        }

        /// <summary>
        /// Get user FirstName / LastName from stored name in format FirstName, LastName
        /// </summary>
        public string GetFirstLastName()
        {
            string[] names = GetLastFirstName();
            if (names.Length >= 1)
                return names.Length > 1 ? string.Format("{0} {1}", names[1], names[0]) : names[0];
            return "";
        }

        /// <summary>
        /// Set user name in storage from an array of LastName,FirstName values.
        /// </summary>
        public void SetLastFirstName(string[] lastFirstName)
        {
            if (lastFirstName.Length < 1)
                return;
            if (lastFirstName.Length == 2)
                Name = string.Format("{0},{1}", lastFirstName[0], lastFirstName[1]);
            else
                Name = string.Format("{0},", lastFirstName[0]);
        }

        /// <summary>
        /// Reset user to defaults
        /// </summary>
        public void ResetToDefaults()
        {
            SetDefaults();
        }

        /// <summary>
        /// Copy the properties of current user to [other] user
        /// </summary>
        /// <param name="other">The user instance whose properties will be updated from current user.</param>
        public void CopyTo(IUserConfiguration other)
        {
            if (other == null)
                return;

            other.Id = Id;
            other.UserPin = UserPin;
            other.GroupId = GroupId;
            other.SetLastFirstName(GetLastFirstName());
            other.OutsideHoursAccess = OutsideHoursAccess;
            other.UserManagementPrivilege = UserManagementPrivilege;
            other.AutoIsolateDeisolatePoints = AutoIsolateDeisolatePoints;
        }

        /// <summary>
        /// Add area identified by [logicalAreaId] id to this user accessible areas if not already added
        /// </summary>
        /// <param name="logicalAreaId">Logical area id, 1 based</param>
        /// <returns>True if the area was added successfuly, False otherwise</returns>
        public bool AddAreaById(int logicalAreaId)
        {
            // CP - Not available for Unison Users
            return false;
        }

        /// <summary>
        /// Replace user areas with those in the areasToAdd list
        /// </summary>
        /// <param name="areasToAdd">List of areas to add.</param>
        public void ReplaceAllAreas(List<AreaConfiguration> areasToAdd)
        {
            // CP - Not available for Unison Users
        }

        /// <summary>
        /// Remove area specified by [logicalAreaId] from this user's accessible areas
        /// </summary>
        /// <param name="areaId">Logical area id, i based</param>
        /// <returns>True if the area was successfuly removed, False otherwise.</returns>
        public bool RemoveAreaById(int logicalAreaId)
        {
            // CP - Not available for Unison Users
            return false;
        }

        /// <summary>
        /// Get all accessible areas for this user
        /// </summary>
        /// <param name="areas">The list to which user areas will be added</param>
        /// <returns>True if the user has any areas, False otherwise</returns>
        public bool GetAllAreas(out List<AreaConfiguration> areas)
        {
            areas = new List<AreaConfiguration>();
            foreach (int areaId in AreaIds)
            {
                AreaConfiguration area = ConfigurationManager.Instance.Areas[areaId];
                if (area != null)
                    areas.Add(area);
            }
            return true;
        }

        /// <summary>
        /// Get all user area Ids
        /// </summary>
        /// <returns>List of all area Ids the user has access to.</returns>
        public List<int> GetAllAreaIds()
        {
            return AreaIds.ToList();
        }

        /// <summary>
        /// The user is allowed to Disarm areas despite being at an Armed level in the schedule.
        /// </summary>
        public bool OutsideHoursAccess 
        {
            get { return true; }
            set
            {
                UserFlags = UserFlags.SetOrResetFlag(UserFlags.AfterHoursAccess, value);
            }
        }

        /// <summary>
        /// The user is allowed to create, edit and delete other users from the keypad.
        /// </summary>
        public bool UserManagementPrivilege 
        {
            get { return UserFlags.Has(UserFlags.UserManagementPriviliges); }
            set
            {
                UserFlags = UserFlags.SetOrResetFlag(UserFlags.UserManagementPriviliges, value);
            }
        }

        public bool AutoIsolateDeisolatePoints
        {
            get { return UserFlags.Has(UserFlags.AutoIsolateDeisolatePoints); }
            set
            {
                UserFlags = UserFlags.SetOrResetFlag(UserFlags.AutoIsolateDeisolatePoints, value);
            }
        }

        /// <summary>
        /// Delay Automatic Arming.
        /// </summary>
        public bool DelayAutomaticArming
        {
            get { return UserFlags.Has(UserFlags.DelayAutomaticArming); }
            set
            {
                UserFlags = UserFlags.SetOrResetFlag(UserFlags.DelayAutomaticArming, value);
            }
        }

        /// <summary>
        /// Check if this user can access area with [logicalAreaId] id
        /// </summary>
        /// <param name="logicalAreaId">Logical area id to check, 1 based</param>
        /// <returns>True if the user can access this area, False otherwise</returns>
        public bool CanAccessArea(int logicalAreaId)
        {
            return AreaIds.Contains(logicalAreaId);
        }

        /// <summary>
        /// Clear all accessible areas for this user
        /// </summary>
        public void ClearAreas()
        {
            // CP - Not implemented for Unison Users
        }

        /// <summary>
        /// Update user PIN
        /// </summary>
        /// <param name="newUserPin">New PIN value</param>
        public void ChangePin(int newUserPin)
        {
            UserPin = newUserPin;
        }

        /// <summary>
        /// Update user state after configuration change. This is not required for Unison because the
        /// accessible areas depend on access group permissions and need to be calculated whenever is
        /// required.
        /// </summary>
        public void UpdateAreas(List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems)
        {
        }

        /// <summary>
        /// Check if date is inside the valid from / until date range
        /// </summary>
        /// <param name="localTime">DateTime to check</param>
        /// <returns>True if date in range</returns>
        public bool IsValidDate(DateTime utcTime)
        {
            DateTime now = ConfigurationManager.Instance.ToLocalTime(utcTime);
            return now >= ValidFrom && now <= ValidTo;
        }

        /// <summary>
        /// Check if user has access permission to access readerId
        /// </summary>
        /// <param name="readerId">Logical Reader Id</param>
        /// <param name="isDuressPin">True if a duress pin was entered</param>
        /// <returns>True if the user has permission to access the reader at this time</returns>
        public AccessPermissionResult HasAccessPermission(int readerId, bool isDuressPin)
        {
            DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);

            if (now < ValidFrom || now > ValidTo)
                return AccessPermissionResult.Expired;

            bool invalidReader = true;
            foreach (UserAccess userAccess in AccessGroups)
            {
                if (userAccess.StartDateTime.HasValue && now < userAccess.StartDateTime)
                    continue;

                if (userAccess.EndDateTime.HasValue && now > userAccess.EndDateTime)
                    continue;

                AccessGroup accessGroup = ConfigurationManager.Instance.GetAccessGroupConfiguration(userAccess.AccessGroupId);
                if (accessGroup == null)
                    continue;

                foreach (var accessGroupMember in accessGroup.AccessGroupMembers)
                {
                    if (accessGroupMember.NodeCategory != NodeCategory.Reader)
                        continue;
                    if (accessGroupMember.NodeId != readerId)
                        continue;

                    invalidReader = false;
                    if (isDuressPin)
                        return AccessPermissionResult.Valid;

                    if (now < accessGroupMember.ValidFrom || now > accessGroupMember.ValidTo)
                        return AccessPermissionResult.InvalidSchedule;

                    // We could create a new UnisonAccess class that is identical to the existing Egress schedule
                    // or rename the Egress schedule but for the time being, we will just use the Egress schedule as is.
                    EgressSchedule schedule = ConfigurationManager.Instance.GetEgressSchedule(accessGroupMember.ScheduleId);
                    if (schedule == null)
                        continue;
                    if (schedule.Enabled)
                        return AccessPermissionResult.Valid;
                }
            }
            if (invalidReader)
                return AccessPermissionResult.InvalidReader;
            return AccessPermissionResult.InvalidSchedule;
        }

        /// <summary>
        /// The user's ID as entered onto the keypad.
        /// </summary>
        public int UserId
        {
            get
            {
                return AlarmUserId;
            }
        }

        /// <summary>
        /// Check if user has access permission to access area(s) by logging on a Pacom8101 keypad
        /// </summary>
        /// <returns>True if the user has permission to access the reader for this schedule</returns>
        public bool HasAccessPermission()
        {
            DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
            if (now < ValidFrom || now > ValidTo)
                return false;

            foreach (var userAccess in AccessGroups)
            {
                if (now < userAccess.StartDateTime || now > userAccess.EndDateTime)
                    continue;

                AccessGroup accessGroup = ConfigurationManager.Instance.GetAccessGroupConfiguration(userAccess.AccessGroupId);
                if (accessGroup == null)
                    continue;

                if (accessGroup.AccessGroupMembers.Length == 0)
                    continue;

                foreach (var accessGroupMember in accessGroup.AccessGroupMembers)
                {
                    if (accessGroupMember.NodeCategory == NodeCategory.Area && now >= accessGroupMember.ValidFrom && now <= accessGroupMember.ValidTo)
                        return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Check if user has isolate privilege for this area.
        /// Returns true for area 0 if the user has privilege for any area.
        /// </summary>
        /// <param name="areaId"></param>
        /// <returns></returns>
        public bool CanIsolate(int areaId)
        {
            if (areaId > 0)
            {
                for (int i = 0; i < AreaIds.Length; i++)
                {
                    if (AreaIds[i] == areaId)
                    {
                        if (AreaAccessPrivilege != null && i < AreaAccessPrivilege.Length && AreaAccessPrivilege[i] != null)
                            return AreaAccessPrivilege[i].CanIsolate;
                        return true;
                    }
                }
            }
            return true;
        }
    }
}
