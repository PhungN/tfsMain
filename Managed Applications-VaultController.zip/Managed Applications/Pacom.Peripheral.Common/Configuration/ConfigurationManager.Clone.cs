﻿using System;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using System.Reflection;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Core.Access;

namespace Pacom.Peripheral.Common.Configuration
{
    public partial class ConfigurationManager
    {
        public static void CopyConfiguration(ConfigurationBase source, ConfigurationBase destination)
        {
            Dictionary<Type, PropertyInfo[]> reflectionDictionary = new Dictionary<Type, PropertyInfo[]>();
            CopyConfiguration(reflectionDictionary, source, destination);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns>False if the configuration is the same, True if different.</returns>
        public static bool CopyConfiguration(Dictionary<Type, PropertyInfo[]> reflectionDictionary, ConfigurationBase source, ConfigurationBase destination)
        {
            MethodInfo methodInfo;
            if (source == null && destination == null)
                return false;
            if (source == null || destination == null)
                return true;

            Type sourceType = source.GetType();
            Type destinationType = destination.GetType();

            Type baseType;
            if (sourceType == destinationType)
            {
                baseType = sourceType;
                if (baseType.Namespace == "Pacom.Peripheral.Common.Configuration")
                    baseType = baseType.BaseType;
            }
            else if (sourceType.BaseType == destinationType)
            {
                baseType = destinationType;
            }
            else if (destinationType.BaseType == sourceType)
            {
                baseType = sourceType;
            }
            else
            {
                throw new ArgumentException("Source and destination types don't match!");
            }

            PropertyInfo[] members;
            if (reflectionDictionary.ContainsKey(baseType))
            {
                members = reflectionDictionary[baseType];
            }
            else
            {
                members = baseType.GetProperties(BindingFlags.Instance | BindingFlags.Public);
                reflectionDictionary.Add(baseType, members);
            }

            bool configurationChanged = false;
            foreach (PropertyInfo property in members)
            {
                try
                {
                    if (property.CanWrite)
                    {
                        if (property.PropertyType.IsValueType || property.PropertyType.IsEnum || property.PropertyType.Equals(typeof(System.String)))
                        {
                            if (property.Name == "Name")
                            {
                                string sourceValue = (string)property.GetValue(source, null);
                                string destinationValue = (string)property.GetValue(destination, null);
                                if (sourceValue == null)
                                {
                                    methodInfo = sourceType.GetMethod("GetName");
                                    if (methodInfo != null)
                                        sourceValue = (string)methodInfo.Invoke(source, new object[] { });
                                }
                                else if (destinationValue == null)
                                {
                                    methodInfo = destinationType.GetMethod("GetName");
                                    if (methodInfo != null)
                                        destinationValue = (string)methodInfo.Invoke(destination, new object[] { });
                                }
                                if (sourceValue != destinationValue)
                                {
                                    configurationChanged = true;
                                    property.SetValue(destination, sourceValue, null);
                                }
                                else if (sourceValue == null && destinationValue == null)
                                {
                                    // Don't set configuration changed for this condition
                                    property.SetValue(destination, string.Empty, null);
                                }
                            }
                            else
                            {
                                // Value type or string
                                if (property.GetValue(source, null) == null)
                                {
                                    string desinationValue = (string)property.GetValue(destination, null);
                                    if (desinationValue == null)
                                    {
                                        // Don't set configuration changed for this condition
                                        property.SetValue(destination, string.Empty, null);
                                    }
                                    else if (desinationValue != string.Empty)
                                    {
                                        configurationChanged = true;
                                        property.SetValue(destination, string.Empty, null);
                                    }
                                }
                                else if (property.GetValue(source, null).Equals(property.GetValue(destination, null)) == false)
                                {
                                    configurationChanged = true;
                                    property.SetValue(destination, property.GetValue(source, null), null);
                                }
                            }
                        }
                        else
                        {
                            // A class or array
                            bool setRequired = false;
                            object complexObject = cloneComplex(reflectionDictionary, property.PropertyType, property.GetValue(source, null), property.GetValue(destination, null), ref setRequired);
                            if (setRequired)
                            {
                                configurationChanged = true;
                                property.SetValue(destination, complexObject, null);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("CloneConfiguration failed: {0}", ex.ToString());
                    });
                }
            }

            methodInfo = destinationType.GetMethod("InitializeAfterCopy");
            if (methodInfo != null)
                methodInfo.Invoke(destination, new object[] { });
            return configurationChanged;
        }

        private static int depth = 0;
        private static object cloneComplex(Dictionary<Type, PropertyInfo[]> reflectionDictionary, Type sourceType, object sourceValue, object destinationValue, ref bool configurationChanged)
        {
            depth++;
            if (depth > 10)
                throw new Exception("Infinite recursive call detected in cloneComplex!");
            object destination;

            if (sourceType.IsArray)
            {
                if (sourceValue == null)
                {
                    depth--;
                    if (destinationValue == null)
                    {
                        // Don't set configuration changed for this condition
                        destination = Array.CreateInstance(sourceType.GetElementType(), 0);
                        return destination;
                    }
                    else if (destinationValue.GetType() != sourceType || ((Array)destinationValue).GetLength(0) != 0)
                    {
                        destination = Array.CreateInstance(sourceType.GetElementType(), 0);
                        configurationChanged = true;
                        return destination;
                    }
                    return destinationValue;
                }

                // Only supports single dimensional arrays
                Array array = sourceValue as Array;
#if DEBUG
                if (array.Rank != 1)
                    throw new ArgumentException("Array rank is greater than 1!");
#endif

                int elements = array.GetLength(0);
                Array destinationArray = destinationValue as Array;
                if (destinationArray == null || destinationArray.GetLength(0) != elements)
                {
                    configurationChanged = true;
                    destinationArray = Array.CreateInstance(sourceType.GetElementType(), elements);
                }
                for (int i = 0; i < elements; i++)
                {
                    object arrayElement = array.GetValue(i);
                    object destinationElement = destinationArray.GetValue(i);
                    Type arrayElementType = arrayElement.GetType();
                    if (arrayElementType.IsValueType || arrayElementType.IsEnum || arrayElementType.Equals(typeof(System.String)))
                    {
                        if (arrayElement == null)
                        {
                            if (destinationElement == null)
                            {
                                // Don't set configuration changed for this condition
                                destinationArray.SetValue(string.Empty, i);
                            }
                            else if ((string)destinationElement != string.Empty)
                            {
                                configurationChanged = true;
                                destinationArray.SetValue(string.Empty, i);
                            }
                        }
                        else if (destinationElement == null || destinationElement.Equals(arrayElement) == false)
                        {
                            configurationChanged = true;
                            destinationArray.SetValue(arrayElement, i);
                        }
                    }
                    else
                    {
                        // A class or array
                        bool setRequired = false;
                        object complexObject = cloneComplex(reflectionDictionary, arrayElementType, arrayElement, destinationElement, ref setRequired);
                        if (setRequired)
                        {
                            configurationChanged = true;
                            destinationArray.SetValue(complexObject, i);
                        }
                    }
                }
                depth--;
                return destinationArray;
            }
            else
            {
                if (sourceValue == null && destinationValue == null)
                {
                    // Don't set configuration changed for this condition
                    destination = Activator.CreateInstance(sourceType);
                }
                else if (destinationValue == null || destinationValue.GetType() != sourceType || sourceValue == null)
                {
                    configurationChanged = true;
                    destination = Activator.CreateInstance(sourceType);
                }
                else
                {
                    destination = destinationValue;
                }
            }

            PropertyInfo[] members;
            if (reflectionDictionary.ContainsKey(sourceType))
            {
                members = reflectionDictionary[sourceType];
            }
            else
            {
                members = sourceType.GetProperties(BindingFlags.Instance | BindingFlags.Public);
                reflectionDictionary.Add(sourceType, members);
            }

            foreach (PropertyInfo property in members)
            {
                try
                {
                    if (property.CanWrite)
                    {
                        if (property.PropertyType.IsValueType || property.PropertyType.IsEnum || property.PropertyType.Equals(typeof(System.String)))
                        {
                            // Simple value type or string
                            if (property.GetValue(sourceValue, null) == null)
                            {
                                string destinationString = (string)property.GetValue(destination, null);
                                if (destinationString == null)
                                {
                                    // Don't set configuration changed for this condition
                                    property.SetValue(destination, string.Empty, null);
                                }
                                else if (destinationString != string.Empty)
                                {
                                    configurationChanged = true;
                                    property.SetValue(destination, string.Empty, null);
                                }
                            }
                            else if (property.GetValue(sourceValue, null).Equals(property.GetValue(destination, null)) == false)
                            {
                                configurationChanged = true;
                                property.SetValue(destination, property.GetValue(sourceValue, null), null);
                            }
                        }
                        else
                        {
                            // A class or array
                            bool setRequired = false;
                            object complexObject = cloneComplex(reflectionDictionary, property.PropertyType, property.GetValue(sourceValue, null), property.GetValue(destination, null), ref setRequired);
                            if (setRequired)
                            {
                                configurationChanged = true;
                                property.SetValue(destination, complexObject, null);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("cloneComplex failed:", ex.ToString());
                    });
                }
            }
            depth--;
            return destination;
        }
    }
}
