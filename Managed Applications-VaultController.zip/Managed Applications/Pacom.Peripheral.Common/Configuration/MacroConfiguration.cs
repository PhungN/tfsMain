﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class MacroConfiguration : Macro8003Configuration
    {
        public MacroConfiguration()
        {
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Macro, Id, Name);
                Name = null;
            }
        }

        /// <summary>
        /// Get macro name from repository
        /// </summary>
        /// <returns>The macro Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Macro, Id);
        }
    }
}
