﻿using System.Collections.Generic;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class DoorConfigurationList : NodeConfigurationListBase<DoorConfiguration>, IConfigurationList
    {
        internal DoorConfigurationList() : base() { }

        /// <summary>
        /// Return door configuration referenced by logical id
        /// </summary>
        /// <param name="logicalId">Door logical id, 1 based</param>
        /// <returns>Door configuration instance or null if not found</returns>
        public override DoorConfiguration this[int logicalId]
        {
            set
            {
                if (value != null && value.Enabled == true && Exists(logicalId) == false && EnabledCount >= LicenseManager.Instance.MaximumDoorCount)
                {
                    value.Enabled = false;
                    string doorName = ConfigurationStringRepository.RetrieveName(ConfigurationType.Door, value.Id);
                    Logger.LogWarnMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("Licensing limit exceeded. The added door {0} will be disabled.", doorName);
                    });
                }
                base[logicalId] = value;
            }
        }

        /// <summary>
        /// Get next door Id
        /// </summary>
        public int NextDoorId
        {
            get { return nextConfigurationItemId; }
        }

        /// <summary>
        /// Get door logical id from reader logical id
        /// </summary>
        /// <param name="logicalReaderId">Reader logical id.</param>
        /// <returns>Door logical id, -1 if door not found.</returns>
        public int GetDoorLogicalId(int logicalReaderId)
        {
            List<DoorConfiguration> doors = AsList;
            foreach (var door in doors)
            {
                if (door != null && (door.ReaderInId == logicalReaderId || door.ReaderOutId == logicalReaderId))
                    return door.Id;
            }
            return -1;
        }
    }
}
