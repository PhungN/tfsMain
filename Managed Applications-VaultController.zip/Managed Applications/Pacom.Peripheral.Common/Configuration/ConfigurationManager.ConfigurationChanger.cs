﻿using System;
using System.Threading;

namespace Pacom.Peripheral.Common.Configuration
{
    public partial class ConfigurationManager
    {
        private enum ConfigurationChangerType
        {
            ConfigurationWriter,
            ConfigurationReader
        }

        public class ConfigurationChanger : IDisposable
        {
            /// <summary>
            /// Count the WRITE changers created. 
            /// </summary>
            private ConfigurationElementsAffected changes = ConfigurationElementsAffected.All;
            private ConfigurationManager owner = null;

            /// <summary>
            /// Constructor used to create instance allowing for configuration change
            /// </summary>
            /// <param name="owner"></param>
            /// <param name="changes"></param>
            internal ConfigurationChanger(ConfigurationManager owner, ConfigurationElementsAffected changes)
            {
                Monitor.Enter(ConfigurationManager.ControllerConfigurationSync);
                this.LockAcquired = true;
                if (changes == ConfigurationElementsAffected.None)
                {
                    this.changerType = ConfigurationChangerType.ConfigurationReader;
                    this.changes = ConfigurationElementsAffected.All;
                }
                else
                {
                    this.changerType = ConfigurationChangerType.ConfigurationWriter;
                    this.changes = changes;
                }
                this.owner = owner;
                if (changerType == ConfigurationChangerType.ConfigurationWriter)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("Configuration lock: WRITE created.");
                    });
                }
                else
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("Configuration lock: READ created.");
                    });
                }
            }

            /// <summary>
            /// Constructor used to create instance allowing for configuration read
            /// </summary>
            /// <param name="owner"></param>
            internal ConfigurationChanger(ConfigurationManager owner)
            {
                if (Monitor.TryEnter(ConfigurationManager.ControllerConfigurationSync) == true)
                    this.LockAcquired = true;
                else
                    this.LockAcquired = false;
                this.changerType = ConfigurationChangerType.ConfigurationReader;
                this.changes = ConfigurationElementsAffected.All;
                this.owner = owner;
                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return "Configuration lock: READ created.";
                });
            }

            /// <summary>
            /// Returns true if lock has been acquired.
            /// </summary>
            public bool LockAcquired { private set; get; }

            private ConfigurationChangerType changerType = ConfigurationChangerType.ConfigurationReader;

            #region IDisposable Members

            public void Dispose()
            {
                // Signal event when writer got the changer created, reader does not get this events
                if (this.changerType == ConfigurationChangerType.ConfigurationWriter)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return "Configuration lock: WRITE disposed.";
                    });
                }
                else
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return "Configuration lock: READ disposed.";
                    });
                }
                // Release lock if it was acquired
                if (this.LockAcquired == true)
                {
                    Monitor.Exit(ConfigurationManager.ControllerConfigurationSync);
                    this.LockAcquired = false;
                }
            }

            #endregion
        }
    }
}
