﻿using System;
using System.IO;
using System.Collections.Generic;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class GroupConfigurationList : ConfigurationListBase<GroupConfiguration>, IConfigurationList
    {
        internal GroupConfigurationList() : base() { }

        /// <summary>
        /// Get next group Id
        /// </summary>
        public int NextGroupId
        {
            get { return nextConfigurationItemId; }
        }

        /// <summary>
        /// Add new group using the default group configuration constructor
        /// </summary>
        public void AddDefaultGroup()
        {
            GroupConfiguration group = new GroupConfiguration();
            group.AutoConfigure();
            this[group.Id] = group;
        }
    }
}
