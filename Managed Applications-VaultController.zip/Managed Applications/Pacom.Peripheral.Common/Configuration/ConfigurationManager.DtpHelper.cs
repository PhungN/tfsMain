﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Core.Contracts;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Serialization.Formatters.Asn1;
using System.Threading;
using System.Net;
using System.Text;
using System.Runtime.Serialization;

namespace Pacom.Peripheral.Common.Configuration
{
    public partial class ConfigurationManager
    {
        private const uint userAsn1Hash = 0xe0a63e12;

        public void PrepareDtpUpload(string identifier)
        {
            lock (controllerConfigurationSync)
            {
                string uploadFilePath = FileSystemPaths.DataTransferUploadFilePath;
                if (identifier == "/WebTemplateUpload")
                    uploadFilePath = FileSystemPaths.WebTemplateUploadFilePath;

                for (int i = 0; i < 3; i++)
                {
                    try
                    {
                        if (File.Exists(uploadFilePath))
                            File.Delete(uploadFilePath);
                        break;
                    }
                    catch
                    {
                        Thread.Sleep(1000);
                    }
                }
                // Create a 0 length file, just in case we have nothing to upload.
                using (FileStream dataTransferUploadFileStream = new FileStream(uploadFilePath, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                {
                }

                int hashIndex = identifier.IndexOf('#');
                if (hashIndex != -1)
                    identifier = identifier.Substring(0, hashIndex);
                if (identifier.Length == 0)
                    return;

                if (identifier == "/" || identifier == "/WebTemplateUpload")
                {
                    using (FileStream fileStream = new FileStream(uploadFilePath, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                    {
                        appendFile(FileSystemPaths.AreasConfigFilePath, fileStream);
                        if (identifier == "/WebTemplateUpload")
                            appendFileEncryptingPasswords(FileSystemPaths.DevicesConfigFilePath, fileStream);
                        else
                            appendFile(FileSystemPaths.DevicesConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.DoorsConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.InterlockGroupsConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.InputsConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.MacrosConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.OutputsConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.ElevatorsConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.ElevatorFloorsConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.PortsConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.ReadersConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.PresenceZonesConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.SchedulesConfigFilePath, fileStream);

                        UserConfigurationListSDCard userConfigurationList = users as UserConfigurationListSDCard;
                        if (userConfigurationList != null)
                            userConfigurationList.WriteOutAllUsersToStream(fileStream);
                        else
                            appendFile(FileSystemPaths.UsersConfigFilePath, fileStream);

                        appendFile(FileSystemPaths.CalendarsConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.CardProfilesConfigFilePath, fileStream);
                        if (identifier == "/WebTemplateUpload")
                            appendFileEncryptingPasswords(FileSystemPaths.ConnectionsConfigFilePath, fileStream);
                        else
                            appendFile(FileSystemPaths.ConnectionsConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.AccessGroupsConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.OpenPacomToDigitalReceiverTemplateFilePath, fileStream);
                        appendFile(FileSystemPaths.UserAccessGroupsConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.VaultControllerConfigFilePath, fileStream);
                        appendFile(FileSystemPaths.VaultControllerInterlockGroupsConfigFilePath, fileStream);
                        return;
                    }
                }

                string[] identifierPortions = identifier.Substring(1).Split('/');

                for (int i = 0; i < identifierPortions.Length; i++)
                {
                    identifierPortions[i] = identifierPortions[i].ToLower();
                }

                string configurationFileName = identifierPortions[0];
                switch (identifierPortions[0])
                {
                    case "nodes":
                        if (identifierPortions.Length > 1 && identifierPortions[1].Length > 0)
                            configurationFileName = identifierPortions[1];
                        else
                            break;
                        switch (identifierPortions[1])
                        {
                            case "area":
                                break;
                            case "device":
                                break;
                            case "door":
                                break;
                            case "interlockgroup":
                                break;
                            case "input":
                                break;
                            case "macro":
                                break;
                            case "output":
                                break;
                            case "port":
                                break;
                            case "reader":
                                break;
                            case "presencezone":
                                break;
                            default:
                                return;
                        }
                        break;
                    case "schedules":
                        break;
                    case "users":
                        break;
                    case "calendars":
                        break;
                    case "cardprofiles":
                        break;
                    case "connection":
                        break;
                    case "accessgroups":
                        break;
                    case "openpacomtodigitalreceivertemplate":
                        break;
                    case "useraccessgroups":
                        break;
                    case "vaultcontrollers":
                        break;
                    default:
                        return;
                }

                if (configurationFileName[configurationFileName.Length - 1] != 's')
                    configurationFileName += 's';

                int id = -1;
                bool identifierContainsId = false;
                if (identifierPortions[identifierPortions.Length - 1].Length > 0)
                {
                    try
                    {
                        id = Int32.Parse(identifierPortions[identifierPortions.Length - 1]);
                        identifierContainsId = true;
                    }
                    catch
                    {
                    }
                }

                string asn1FileName = FileSystemPaths.ConfigurationDirectory + configurationFileName + ".asn1";
                string indexFileName = FileSystemPaths.ConfigurationDirectory + configurationFileName + ".idx";
                if (identifierContainsId && id != -1)
                {
                    if (File.Exists(asn1FileName) && File.Exists(indexFileName))
                    {
                        ConfigurationIndexFileEntry indexFileEntry = new ConfigurationIndexFileEntry();

                        using (FileStream fileStream = new FileStream(indexFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                        {
                            byte[] buffer = new byte[4];
                            while (fileStream.Position < fileStream.Length)
                            {
                                try
                                {
                                    fileStream.Read(buffer, 0, 4);
                                    indexFileEntry.Id = BitConverter.ToInt32(buffer, 0);
                                    if (indexFileEntry.Id == id)
                                    {
                                        fileStream.Read(buffer, 0, 4);
                                        indexFileEntry.Offset = BitConverter.ToInt32(buffer, 0);
                                        fileStream.Read(buffer, 0, 4);
                                        indexFileEntry.Length = BitConverter.ToInt32(buffer, 0);
                                        break;
                                    }
                                    else
                                    {
                                        fileStream.Position += 8;
                                    }
                                }
                                catch
                                {
                                }
                            }
                        }

                        if (indexFileEntry.Id == id)
                        {
                            using (FileStream dataTransferUploadFileStream = new FileStream(uploadFilePath, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                            {
                                using (FileStream configurationFileStream = new FileStream(asn1FileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                                {
                                    byte[] data = new byte[indexFileEntry.Length];
                                    configurationFileStream.Position = indexFileEntry.Offset;
                                    configurationFileStream.Read(data, 0, indexFileEntry.Length);
                                    dataTransferUploadFileStream.Write(data, 0, indexFileEntry.Length);
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (configurationFileName == "nodes")
                    {
                        using (FileStream fileStream = new FileStream(uploadFilePath, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                        {
                            appendFile(FileSystemPaths.AreasConfigFilePath, fileStream);
                            appendFile(FileSystemPaths.DevicesConfigFilePath, fileStream);
                            appendFile(FileSystemPaths.DoorsConfigFilePath, fileStream);
                            appendFile(FileSystemPaths.InterlockGroupsConfigFilePath, fileStream);
                            appendFile(FileSystemPaths.VaultControllerInterlockGroupsConfigFilePath, fileStream);
                            appendFile(FileSystemPaths.InputsConfigFilePath, fileStream);
                            appendFile(FileSystemPaths.MacrosConfigFilePath, fileStream);
                            appendFile(FileSystemPaths.OutputsConfigFilePath, fileStream);
                            appendFile(FileSystemPaths.ElevatorsConfigFilePath, fileStream);
                            appendFile(FileSystemPaths.ElevatorFloorsConfigFilePath, fileStream);
                            appendFile(FileSystemPaths.PortsConfigFilePath, fileStream);
                            appendFile(FileSystemPaths.ReadersConfigFilePath, fileStream);
                            appendFile(FileSystemPaths.PresenceZonesConfigFilePath, fileStream);
                        }
                    }
                    else
                    {
                        if (File.Exists(asn1FileName))
                            File.Copy(asn1FileName, uploadFilePath, true);
                    }
                }
            }
        }

        private static void appendFile(string filePath, FileStream destinationStream)
        {
            if (File.Exists(filePath))
            {
                using (FileStream sourceStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    while ((bytesRead = sourceStream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        destinationStream.Write(buffer, 0, bytesRead);
                    }
                }
            }
        }

        private static void appendFileEncryptingPasswords(string filePath, FileStream destinationStream)
        {
            // Create a serializer that only knows about the types with passwords
            HashTypeLookup lookup = new HashTypeLookup(new List<Assembly>() { });
            lookup.AddType(typeof(Device8003Configuration));
            lookup.AddType(typeof(ControllerConnection8003Table));
            lookup.AddType(typeof(ControllerConnection8003Entry));

            Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(lookup, true, new StreamingContext());
            asn1Serializer.SerializeDefaultValues = true;
            try
            {
                using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    while (fileStream.Position < fileStream.Length)
                    {
                        long position = fileStream.Position;
                        ConfigurationBase configurationItem = (ConfigurationBase)asn1Serializer.TryDeserialize(fileStream);
                        long length = (fileStream.Position - position);

                        if (configurationItem != null)
                        {
                            ControllerConnection8003Table connectionTable = configurationItem as ControllerConnection8003Table;
                            if (connectionTable != null)
                            {
                                if (string.IsNullOrEmpty(connectionTable.Password) || connectionTable.Password.StartsWith(ConfigConsts.EncryptedStringPrefix))
                                {
                                    configurationItem = null;
                                }
                                else
                                {
                                    connectionTable.Password = string.Format("{0}{1}", ConfigConsts.EncryptedStringPrefix, connectionTable.Password.Encrypt());
                                    connectionTable.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                                }
                            }
                            else
                            {
                                Device8003Configuration controllerConfiguration = configurationItem as Device8003Configuration;
                                if (controllerConfiguration != null)
                                {
                                    if (string.IsNullOrEmpty(controllerConfiguration.WebserverPassword) || controllerConfiguration.WebserverPassword.StartsWith(ConfigConsts.EncryptedStringPrefix))
                                    {
                                        configurationItem = null;
                                    }
                                    else
                                    {
                                        controllerConfiguration.WebserverPassword = string.Format("{0}{1}", ConfigConsts.EncryptedStringPrefix, controllerConfiguration.WebserverPassword.Encrypt());
                                        controllerConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                                    }
                                }
                            }
                        }
                        if (configurationItem == null)
                        {
                            // This is not a configuration item that has a password or the password is already encrypted. Write it out as is.
                            fileStream.Seek(position, SeekOrigin.Begin);
                            byte[] data = new byte[length];
                            fileStream.Read(data, 0, (int)length);
                            destinationStream.Write(data, 0, (int)length);
                        }
                        else
                        {
                            // Serialize the modified configuration item.
                            asn1Serializer.Serialize(destinationStream, configurationItem);
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private int controllerLogicalId
        {
            get
            {
                int logicalId = 1;
                try
                {
                    logicalId = controllerConfiguration.Id;
                }
                catch
                {
                }
                return logicalId;
            }
        }

        private readonly static List<string> unmodifiedConfigurationFiles = new List<string>();

        public static void MarkConfigurationFileAsModified(string asn1File)
        {
            lock (unmodifiedConfigurationFiles)
            {
                for (int i = 0; i < unmodifiedConfigurationFiles.Count; i++)
                {
                    if (String.Compare(unmodifiedConfigurationFiles[i], asn1File, true) == 0)
                    {
                        unmodifiedConfigurationFiles.RemoveAt(i);
                        return;
                    }
                }
            }
        }

        public static void MarkAllConfigurationFilesAsModified()
        {
            lock (unmodifiedConfigurationFiles)
            {
                unmodifiedConfigurationFiles.Clear();
            }
        }

        public static void MarkConfigurationFileAsProcessed(string asn1File)
        {
            lock (unmodifiedConfigurationFiles)
            {
                if (isConfigurationFileModified(asn1File) == true)
                    unmodifiedConfigurationFiles.Add(asn1File);
            }
        }

        private static bool isConfigurationFileModified(string asn1File)
        {
            lock (unmodifiedConfigurationFiles)
            {
                for (int i = 0; i < unmodifiedConfigurationFiles.Count; i++)
                {
                    if (String.Compare(unmodifiedConfigurationFiles[i], asn1File, true) == 0)
                        return false;
                }
                return true;
            }
        }

        /// <summary>
        /// Delete configuration item(s) identified by "identifier" from controller. The controller will be re-Initialized if required.
        /// </summary>
        /// <param name="identifier">Configuration item(s) to delete.</param>
        /// <param name="userAuditInfo">User audit details: user type, user Id.</param>
        public void Delete(string identifier, int[] ids, UserAuditInfo userAuditInfo)
        {
            try
            {
                lock (controllerConfigurationSync)
                {
                    string configurationFileName = "";
                    string[] identifierPortions = null;

                    bool individualId = false;
                    int individualIdToDelete = -1;
                    ConfigurationElementsAffected elementsAffected = 0;

                    int hashIndex = identifier.IndexOf('#');
                    if (hashIndex != -1)
                        identifier = identifier.Substring(0, hashIndex);
                    if (identifier.Length == 0)
                        return;

                    if (identifier != "/" && identifier.ToLower() != "/nodes/")
                    {
                        identifierPortions = identifier.Substring(1).Split('/');

                        for (int i = 0; i < identifierPortions.Length; i++)
                        {
                            identifierPortions[i] = identifierPortions[i].ToLower();
                        }

                        if (identifierPortions[identifierPortions.Length - 1].Length > 0)
                        {
                            try
                            {
                                individualIdToDelete = Int32.Parse(identifierPortions[identifierPortions.Length - 1]);
                                individualId = true;
                            }
                            catch
                            {
                            }
                        }

                        configurationFileName = identifierPortions[0];
                        switch (identifierPortions[0])
                        {
                            case "nodes":
                                configurationFileName = identifierPortions[1];
                                switch (identifierPortions[1])
                                {
                                    case "area":
                                        break;
                                    case "device":
                                        break;
                                    case "door":
                                        break;
                                    case "interlockgroup":
                                        break;
                                    case "input":
                                        break;
                                    case "macro":
                                        break;
                                    case "output":
                                        break;
                                    case "port":
                                        break;
                                    case "reader":
                                        break;
                                    case "presencezone":
                                        break;
                                    default:
                                        return;
                                }
                                break;
                            case "schedules":
                                break;
                            case "users":
                                if (ids != null && ids.Length > 0)
                                    users.Delete(ids, userAuditInfo);
                                else if (individualId)
                                    users.Delete(new int[] { individualIdToDelete }, userAuditInfo);
                                else
                                    users.RemoveAll();
                                return;
                            case "calendars":
                                break;
                            case "cardprofiles":
                                break;
                            case "connection":
                                break;
                            case "accessgroups":
                                break;
                            case "accessschedules":
                                break;
                            case "useraccessgroups":
                                break;
                            case "openpacomtodigitalreceivertemplate":
                                break;
                            case "cards":
                                break;
                            case "vaultcontrollers":
                                break;
                            default:
                                return;
                        }

                        if (configurationFileName[configurationFileName.Length - 1] != 's')
                            configurationFileName += 's';
                    }

                    if (identifierPortions[0] == "cards")
                    {
                        if (individualId)
                        {
                            if (CardDeleteRequest != null)
                                CardDeleteRequest(this, new CardDeleteEventArgs(individualIdToDelete));
                        }
                        else
                        {
                            if (ids == null)
                                CardDownloadRequest(this, new CardDownloadEventArgs(null, true));
                            else if (CardDeleteRequest != null)
                                CardDeleteRequest(this, new CardDeleteEventArgs(ids));
                        }
                        return;
                    }

                    if (identifier == "/")
                    {
                        elementsAffected = ConfigurationElementsAffected.All;
                        using (var configChanger = CreateConfigurationChanger(elementsAffected))
                        {
                            FileSystemPaths.DeleteFrontEndConfiguration(true);
                            ControllerConnectionTable.DecommisionAll(sram);
                            ConfigurationManager.Instance.TimeZoneOffsetMinutes = 0;
                            Users.RemoveAll();
                            accessCardManager.DeleteAllCardsLocally();
                            // We are not in a position here to broadcast the delete to the peripherals as the configuration is changing.
                            // We will start a 5 minute timer to give everything a chance to come online and then inform them of the delete.
                            if (broadcastDeleteAllCardsTimer == null)
                                broadcastDeleteAllCardsTimer = TimerManager.Instance.CreateTimer(broadcastDeleteAllCardsTimerCallback, null, 300000, Timeout.Infinite);
                            ConfigurationManager.Instance.IsUnisonMode = false;		// Set here so that Initialize will create GMS configuration
                            Initialize(ConfigurationUpdateReason.FrontEndOrWeb, elementsAffected, userAuditInfo);
                        }
                    }
                    else
                    {
                        string asn1FileName = FileSystemPaths.ConfigurationDirectory + configurationFileName + ".asn1";
                        string indexFileName = FileSystemPaths.ConfigurationDirectory + configurationFileName + ".idx";
                        if (File.Exists(asn1FileName) && File.Exists(indexFileName))
                        {
                            if (individualId == true && ids == null)
                            {
                                ids = new int[1];
                                ids[0] = individualIdToDelete;
                            }

                            if (ids != null)
                            {
                                // An individual item or a set of items are to be deleted

                                // We need to remove the nodes with the same ids as those that we have just received so that we may append the new configuration items to the
                                // end of the file without causing any duplicated ids.
                                List<ConfigurationIndexFileEntry> existingIndexFileEntries;
                                using (FileStream fileStream = new FileStream(indexFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                                {
                                    byte[] buffer = new byte[4];
                                    existingIndexFileEntries = new List<ConfigurationIndexFileEntry>((int)(fileStream.Length / 12));
                                    while (fileStream.Position < fileStream.Length)
                                    {
                                        try
                                        {
                                            ConfigurationIndexFileEntry indexFileEntry = new ConfigurationIndexFileEntry();
                                            fileStream.Read(buffer, 0, 4);
                                            indexFileEntry.Id = BitConverter.ToInt32(buffer, 0);
                                            fileStream.Read(buffer, 0, 4);
                                            indexFileEntry.Offset = BitConverter.ToInt32(buffer, 0);
                                            fileStream.Read(buffer, 0, 4);
                                            indexFileEntry.Length = BitConverter.ToInt32(buffer, 0);
                                            if (ids.Contains(indexFileEntry.Id))
                                                indexFileEntry.MarkedForDeletion = true;
                                            else
                                                indexFileEntry.MarkedForDeletion = false;
                                            existingIndexFileEntries.Add(indexFileEntry);
                                        }
                                        catch
                                        {
                                        }
                                    }
                                }

                                StreamingContext context = new StreamingContext();
                                ITypeLookup typesList = getListOfTypes();
                                Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(typesList, true, context);
                                asn1Serializer.SerializeDefaultValues = true;
                                ConfigurationBase configurationItem;

                                bool nothingToDelete = true;
                                List<ConfigurationChanges> removedItems = new List<ConfigurationChanges>();
                                using (FileStream fileStream = new FileStream(asn1FileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                                {
                                    foreach (ConfigurationIndexFileEntry indexFileEntry in existingIndexFileEntries)
                                    {
                                        if (indexFileEntry.MarkedForDeletion)
                                        {
                                            nothingToDelete = false;
                                            fileStream.Position = indexFileEntry.Offset;
                                            configurationItem = (ConfigurationBase)asn1Serializer.Deserialize(fileStream);
                                            elementsAffected |= getAffectedConfigurationElements(configurationItem, controllerLogicalId);
                                            getItemDetails(asn1FileName, configurationItem, removedItems);
                                        }
                                    }
                                }

                                if (nothingToDelete)
                                    return;

                                Logger.LogWarnMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                                {
                                    StringBuilder sb = new StringBuilder();
                                    sb.AppendFormat("### New: 0, Changed: 0, Removed: {0}\r\n", removedItems.Count);
                                    if (removedItems.Count > 0 && removedItems.Count < 30)
                                    {
                                        sb.Append("    Removed: \r\n");
                                        for (int i = 0; i < removedItems.Count; i++)
                                        {
                                            sb.AppendFormat("       {0} {1}\r\n", removedItems[i].ConfigurationType.ToString(), removedItems[i].Id);
                                        }
                                    }
                                    return sb.ToString();
                                });


                                using (var configChanger = CreateConfigurationChanger(elementsAffected))
                                {
                                    MarkConfigurationFileAsModified(asn1FileName);
                                    if (File.Exists(FileSystemPaths.TempAsn1ConfigFilePath))
                                        File.Delete(FileSystemPaths.TempAsn1ConfigFilePath);
                                    File.Move(asn1FileName, FileSystemPaths.TempAsn1ConfigFilePath);
                                    File.Delete(indexFileName);

                                    using (FileStream newFileStream = new FileStream(asn1FileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                                    {
                                        using (FileStream oldFileStream = new FileStream(FileSystemPaths.TempAsn1ConfigFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                                        {
                                            for (int i = 0; i < existingIndexFileEntries.Count; i++)
                                            {
                                                if (existingIndexFileEntries[i].MarkedForDeletion)
                                                {
                                                    // Don't copy the entry across to our new file & remove the index entry
                                                    existingIndexFileEntries.RemoveAt(i);
                                                    i--;
                                                }
                                                else
                                                {
                                                    // Copy the entry across to our new file and update the offset in the index
                                                    oldFileStream.Position = existingIndexFileEntries[i].Offset;
                                                    byte[] data = new byte[existingIndexFileEntries[i].Length];
                                                    oldFileStream.Read(data, 0, existingIndexFileEntries[i].Length);
                                                    existingIndexFileEntries[i].Offset = (int)newFileStream.Position;
                                                    newFileStream.Write(data, 0, existingIndexFileEntries[i].Length);
                                                }
                                            }
                                        }
                                    }
                                    File.Delete(FileSystemPaths.TempAsn1ConfigFilePath);

                                    // Recreate the index entries
                                    using (FileStream fileStream = new FileStream(indexFileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                                    {
                                        foreach (ConfigurationIndexFileEntry existingIndexFileEntry in existingIndexFileEntries)
                                        {
                                            fileStream.Write(BitConverter.GetBytes(existingIndexFileEntry.Id), 0, 4);
                                            fileStream.Write(BitConverter.GetBytes(existingIndexFileEntry.Offset), 0, 4);
                                            fileStream.Write(BitConverter.GetBytes(existingIndexFileEntry.Length), 0, 4);
                                        }
                                    }
                                    initialize(ConfigurationUpdateReason.FrontEndOrWeb, elementsAffected, userAuditInfo, removedItems);
                                }
                            }
                            else
                            {
                                // A whole category is being removed

                                StreamingContext context = new StreamingContext();
                                ITypeLookup typesList = getListOfTypes();
                                Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(typesList, true, context);
                                asn1Serializer.SerializeDefaultValues = true;

                                using (FileStream fileStream = new FileStream(asn1FileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                                {
                                    while (fileStream.Position < fileStream.Length)
                                    {
                                        try
                                        {
                                            ConfigurationBase configurationItem = (ConfigurationBase)asn1Serializer.Deserialize(fileStream);
                                            elementsAffected |= getAffectedConfigurationElements(configurationItem, controllerLogicalId);
                                        }
                                        catch
                                        {
                                        }
                                    }
                                }

                                using (var configChanger = CreateConfigurationChanger(elementsAffected))
                                {
                                    MarkConfigurationFileAsModified(asn1FileName);
                                    File.Delete(asn1FileName);
                                    File.Delete(indexFileName);

                                    Initialize(ConfigurationUpdateReason.FrontEndOrWeb, elementsAffected, userAuditInfo);
                                }
                            }
                        }
                    }
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Load configuration from DTP
        /// </summary>
        /// <param name="identifier">Identifier(s) for configuration item(s) that needs to be loaded.</param>
        /// <param name="customSettings">Settings that need to be applied: IP Address, Sub Net Mask, DHCP flag.</param>
        /// <param name="userAuditInfo">User audit details: user type, user Id.</param>
        public void LoadFromDtp(string identifier, DtpCustomSettings customSettings, UserAuditInfo userAuditInfo, bool sendEventToFrontEnd)
        {
            LoadFromDtp(identifier, customSettings, userAuditInfo, sendEventToFrontEnd, null);
        }

        /// <summary>
        /// Load configuration from DTP
        /// </summary>
        /// <param name="identifier">Identifier(s) for configuration item(s) that needs to be loaded.</param>
        /// <param name="customSettings">Settings that need to be applied: IP Address, Sub Net Mask, DHCP flag.</param>
        /// <param name="userAuditInfo">User audit details: user type, user Id.</param>
        /// <param name="requiredType">If not null, a type that must be present in the ASN1 file</param>
        public void LoadFromDtp(string identifier, DtpCustomSettings customSettings, UserAuditInfo userAuditInfo, bool sendEventToFrontEnd, Type requiredType)
        {
            string originalIdentifier = identifier;
            string[] updatedIdentifiers = new string[0];
            try
            {
                lock (controllerConfigurationSync)
                {
                    string inputFilePath = FileSystemPaths.DataTransferDownloadFilePath;
                    string[] identifierPortions = null;

                    bool update = false;
                    ConfigurationElementsAffected elementsAffected = 0;

                    if (ValidateDownloadRequest(identifier) == false)
                        return;

                    // Remove the #{id} used by Unison.
                    int hashIndex = identifier.IndexOf('#');
                    if (hashIndex != -1)
                        identifier = identifier.Substring(0, hashIndex);
                    if (identifier.Length == 0)
                        return;

                    identifier = identifier.ToLower();
                    if (identifier != "/" && identifier != "/nodes/")
                    {
                        identifierPortions = identifier.Substring(1).Split('/');

                        if (identifierPortions[0] == "localupdate")
                        {
                            update = true;
                            inputFilePath = FileSystemPaths.LocalChangeFilePath;
                        }
                        else if (identifierPortions[0] == "update")
                        {
                            update = true;
                        }
                        else if (identifierPortions[0] == "web")
                        {
                            update = true;
                            inputFilePath = FileSystemPaths.WebConfigurationFilePath;
                        }
                        else if (identifierPortions[0] == "usb")
                        {
                            originalIdentifier = "/";
                            identifier = "/";
                            inputFilePath = FileSystemPaths.UsbFlashDriveDownloadFilePath;
                        }
                        else if (identifierPortions[0] == "webtemplatedownload")
                        {
                            originalIdentifier = "/";
                            identifier = "/";
                            inputFilePath = FileSystemPaths.WebTemplateDownloadFilePath;
                        }

                        int id = -1;
                        if (identifier != "/" && identifierPortions[identifierPortions.Length - 1].Length > 0)
                        {
                            try
                            {
                                id = Int32.Parse(identifierPortions[identifierPortions.Length - 1]);
                                update = true;
                            }
                            catch
                            {
                            }
                        }
                    }

                    StreamingContext context = new StreamingContext();
                    ITypeLookup typesList = getListOfTypes();
                    Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(typesList, true, context);
                    asn1Serializer.SerializeDefaultValues = true;

                    List<ConfigurationBaseWithStreamOffsetAndLength> configuration = new List<ConfigurationBaseWithStreamOffsetAndLength>();
                    using (FileStream fileStream = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return string.Format("Processing DTP file {0} of size {1}.", inputFilePath, fileStream.Length);
                        });

                        try
                        {
                            if (identifierPortions != null && (identifierPortions[0] == "update" || identifierPortions[0] == "users"))
                            {
                                Asn1TypeField asn1Type = Asn1DerStreamReadWriter.ReadAsn1TypeByteFromStream(fileStream);
                                if (asn1Type.Asn1Type == userAsn1Hash)
                                    fastDeserializeUsers(fileStream, configuration, asn1Serializer, elementsAffected, controllerLogicalId);
                                else
                                    fileStream.Position = 0;
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                            {
                                return string.Format("Failed on fastDeserializeUsers. {0}", ex.ToString());
                            });
                            fileStream.Position = 0;
                            configuration.Clear();
                        }

                        while (fileStream.Position < fileStream.Length)
                        {
                            try
                            {
                                ConfigurationBaseWithStreamOffsetAndLength configurationBaseWithStreamOffsetAndLength = new ConfigurationBaseWithStreamOffsetAndLength();
                                configurationBaseWithStreamOffsetAndLength.Offset = (int)fileStream.Position;

                                ConfigurationBase configurationItem = (ConfigurationBase)asn1Serializer.Deserialize(fileStream);
                                if (configurationItem == null)
                                {
                                    // Deserialisation of the item failed, move onto next
                                    continue;
                                }
                                elementsAffected |= getAffectedConfigurationElements(configurationItem, controllerLogicalId);

                                configurationBaseWithStreamOffsetAndLength.Configuration = configurationItem;
                                configurationBaseWithStreamOffsetAndLength.Length = (int)fileStream.Position - configurationBaseWithStreamOffsetAndLength.Offset;
                                configuration.Add(configurationBaseWithStreamOffsetAndLength);
                            }
#pragma warning disable 0168
#if DEBUG
                            catch (Exception ex)
#else
                            catch
#endif
#pragma warning restore 0168
                            {
                            }
                        }
                    }

                    // Optionally check for a specific type being present, as a method of checking the ASN1 file is valid
                    if (requiredType != null && configuration.Exists(item => item.Configuration.GetType().Equals(requiredType)) == false)
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager,
                                               () => "Loading configuration failed: Invalid file");
                        return;
                    }

                    ConfigurationBaseWithStreamOffsetAndLength[] areas;
                    ConfigurationBaseWithStreamOffsetAndLength[] devices;
                    ConfigurationBaseWithStreamOffsetAndLength[] doors;
                    ConfigurationBaseWithStreamOffsetAndLength[] interlockGroups;
                    ConfigurationBaseWithStreamOffsetAndLength[] inputs;
                    ConfigurationBaseWithStreamOffsetAndLength[] macros;
                    ConfigurationBaseWithStreamOffsetAndLength[] outputs;
                    ConfigurationBaseWithStreamOffsetAndLength[] elevators;
                    ConfigurationBaseWithStreamOffsetAndLength[] elevatorFloors;
                    ConfigurationBaseWithStreamOffsetAndLength[] ports;
                    ConfigurationBaseWithStreamOffsetAndLength[] readers;
                    ConfigurationBaseWithStreamOffsetAndLength[] presenceZones;
                    ConfigurationBaseWithStreamOffsetAndLength[] schedules;
                    ConfigurationBaseWithStreamOffsetAndLength[] accessSchedules;
                    ConfigurationBaseWithStreamOffsetAndLength[] users;
                    ConfigurationBaseWithStreamOffsetAndLength[] calendars;
                    ConfigurationBaseWithStreamOffsetAndLength[] cardProfiles;
                    ConfigurationBaseWithStreamOffsetAndLength[] controllerConnectionTables;
                    ConfigurationBaseWithStreamOffsetAndLength[] groups;
                    ConfigurationBaseWithStreamOffsetAndLength[] openPacomToDigitalReceiverTemplates;
                    ConfigurationBaseWithStreamOffsetAndLength[] vaultControllers;
                    ConfigurationBaseWithStreamOffsetAndLength[] vaultControllerInterlockGroups;
                    List<Credential> cards;
                    ConfigurationBaseWithStreamOffsetAndLength[] userAccessGroups;
                    categoriseConfiguration(configuration, out areas, out devices, out doors, out interlockGroups, out vaultControllerInterlockGroups, out inputs, out macros, out outputs, out elevators, out elevatorFloors, out ports, out readers, out presenceZones,
                                            out schedules, out accessSchedules, out users, out calendars, out cardProfiles, out controllerConnectionTables, out groups,
                                            out cards, out userAccessGroups, out openPacomToDigitalReceiverTemplates, out updatedIdentifiers, out vaultControllers);

                    if (update == false || identifierPortions[0] == "update")
                    {
                        updatedIdentifiers = new string[1];
                        updatedIdentifiers[0] = identifier;
                    }

                    using (var configChanger = CreateConfigurationChanger(elementsAffected))
                    {
                        if (identifier == "/")
                        {
                            FileSystemPaths.DeleteFrontEndConfiguration(true);
                            Users.RemoveAll();
                        }

                        if (areas.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.AreasConfigFilePath, inputFilePath, areas, update);
                        if (devices.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.DevicesConfigFilePath, inputFilePath, devices, update);
                        if (doors.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.DoorsConfigFilePath, inputFilePath, doors, update);
                        if (interlockGroups.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.InterlockGroupsConfigFilePath, inputFilePath, interlockGroups, update);
                        if (inputs.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.InputsConfigFilePath, inputFilePath, inputs, update);
                        if (macros.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.MacrosConfigFilePath, inputFilePath, macros, update);
                        if (outputs.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.OutputsConfigFilePath, inputFilePath, outputs, update);
                        if (elevators.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.ElevatorsConfigFilePath, inputFilePath, elevators, update);
                        if (elevatorFloors.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.ElevatorFloorsConfigFilePath, inputFilePath, elevatorFloors, update);
                        if (ports.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.PortsConfigFilePath, inputFilePath, ports, update);
                        if (readers.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.ReadersConfigFilePath, inputFilePath, readers, update);
                        if (presenceZones.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.PresenceZonesConfigFilePath, inputFilePath, presenceZones, update);
                        if (schedules.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.SchedulesConfigFilePath, inputFilePath, schedules, update);
                        if (accessSchedules.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.LegacyAccessSchedulesConfigFilePath, inputFilePath, accessSchedules, update);
                        if (users.Length > 0)
                            Users.WriteOutConfigurationAndIndexFile(FileSystemPaths.UsersConfigFilePath, inputFilePath, users, update);
                        if (calendars.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.CalendarsConfigFilePath, inputFilePath, calendars, update);
                        if (cardProfiles.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.CardProfilesConfigFilePath, inputFilePath, cardProfiles, update);
                        if (controllerConnectionTables.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.ConnectionsConfigFilePath, inputFilePath, controllerConnectionTables, update);
                        if (groups.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.AccessGroupsConfigFilePath, inputFilePath, groups, update);
                        if (userAccessGroups.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.UserAccessGroupsConfigFilePath, inputFilePath, userAccessGroups, update);
                        if (openPacomToDigitalReceiverTemplates.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.OpenPacomToDigitalReceiverTemplateFilePath, inputFilePath, openPacomToDigitalReceiverTemplates, update);
                        if (vaultControllers.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.VaultControllerConfigFilePath, inputFilePath, vaultControllers, update);
                        if (vaultControllerInterlockGroups.Length > 0)
                            WriteOutConfigurationAndIndexFile(FileSystemPaths.VaultControllerInterlockGroupsConfigFilePath, inputFilePath, vaultControllerInterlockGroups, update);
                        if (cards.Count > 0 && CardDownloadRequest != null)
                        {
                            // Notify AccessControlManager that a new card has been downloaded and needs to be
                            // added to SRAM / SD Card database
                            CardDownloadRequest(this, new CardDownloadEventArgs(cards, !update));
                        }

                        List<ConfigurationBase> customConfigurationChanges = null;
                        if (customSettings != null)
                        {
                            int controllerId = -1;
                            customConfigurationChanges = new List<ConfigurationBase>();
                            foreach (var device in devices)
                            {
                                Device8003Configuration controller = device.Configuration as Device8003Configuration;
                                if (controller != null)
                                {
                                    controllerId = controller.Id;
                                    if (controller.SiteId != customSettings.SiteId)
                                    {
                                        controller.SiteId = customSettings.SiteId;
                                        customConfigurationChanges.Add(controller);
                                    }
                                    break;
                                }
                            }
                            foreach (var port in ports)
                            {
                                Port8003IPPortConfiguration ethernetPort = port.Configuration as Port8003IPPortConfiguration;
                                if (ethernetPort != null && ethernetPort.ParentDeviceId == controllerId && 
                                    ethernetPort.PortNumberOnParent == Pacom8003PhysicalPort.Ethernet)
                                {
                                    if (ethernetPort.IPAddress != customSettings.EthernetPort.IPAddress ||
                                        ethernetPort.SubnetMask != customSettings.EthernetPort.SubnetMask ||
                                        ethernetPort.UseDhcpServer != customSettings.EthernetPort.UseDhcpServer)
                                    {
                                        ethernetPort.IPAddress = customSettings.EthernetPort.IPAddress;
                                        ethernetPort.SubnetMask = customSettings.EthernetPort.SubnetMask;
                                        ethernetPort.UseDhcpServer = customSettings.EthernetPort.UseDhcpServer;
                                        customConfigurationChanges.Add(ethernetPort);
                                    }
                                    break;
                                }
                            }
                            // Add the connection table as these are deleted otherwise.
                            foreach (var controllerConnectionTable in controllerConnectionTables)
                            {
                                customConfigurationChanges.Add(controllerConnectionTable.Configuration);
                            }
                        }

                        if (customConfigurationChanges == null)
                            Initialize(ConfigurationUpdateReason.FrontEndOrWeb, elementsAffected, userAuditInfo);
                        else
                            UpdateConfiguration(customConfigurationChanges, true, userAuditInfo, false);
                    }
                }

                if (InformFrontEndThatConfigurationChanged != null && sendEventToFrontEnd)
                {
                    foreach (string updatedIdentifier in updatedIdentifiers)
                    {
                        if (originalIdentifier.ToLower().Contains(updatedIdentifier.ToLower()))
                            InformFrontEndThatConfigurationChanged(this, new ChangedConfigurationEventArgs(controllerConfiguration.Id, originalIdentifier, userAuditInfo));
                        else
                            InformFrontEndThatConfigurationChanged(this, new ChangedConfigurationEventArgs(controllerConfiguration.Id, updatedIdentifier, userAuditInfo));
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Loading configuration failed: {0}", ex.ToString());
                });
            }
        }

        private static void fastDeserializeUsers(Stream fileStream, List<ConfigurationBaseWithStreamOffsetAndLength> configuration, Asn1DerFormatter asn1Serializer, ConfigurationElementsAffected elementsAffected, int controllerLogicalId)
        {
            fileStream.Position = 0;
            User defaultUser = new User();
            defaultUser.SetDefaults();
            User currentUser = null;
            List<UserAccess> userAccessList = new List<UserAccess>();
            long nextObjectPosition = 0;
            ConfigurationBaseWithStreamOffsetAndLength configurationBaseWithStreamOffsetAndLength;
            elementsAffected = getAffectedConfigurationElements(defaultUser, controllerLogicalId);

            while (fileStream.Position < fileStream.Length)
            {
                try
                {
                    configurationBaseWithStreamOffsetAndLength = new ConfigurationBaseWithStreamOffsetAndLength();
                    configurationBaseWithStreamOffsetAndLength.Offset = (int)fileStream.Position;
                    Asn1TypeField asn1Type = Asn1DerStreamReadWriter.ReadAsn1TypeByteFromStream(fileStream);
                    if (asn1Type.Asn1Type == userAsn1Hash)
                    {
                        nextObjectPosition = Asn1DerStreamReadWriter.ReadAsn1LengthBytesFromStream(fileStream) + fileStream.Position;
                        configurationBaseWithStreamOffsetAndLength.Length = (int)nextObjectPosition - configurationBaseWithStreamOffsetAndLength.Offset;
                        currentUser = new User();
                        currentUser.AccessGroups = new Pacom.Core.Access.UserAccess[0];
                        currentUser.AlarmUserId = defaultUser.AlarmUserId;
                        currentUser.GroupId = defaultUser.GroupId;
                        currentUser.Id = defaultUser.Id;
                        currentUser.Name = defaultUser.Name;
                        currentUser.RevisionId = defaultUser.RevisionId;
                        currentUser.UserFlags = defaultUser.UserFlags;
                        currentUser.UserPin = defaultUser.UserPin;
                        currentUser.ValidFrom = defaultUser.ValidFrom;
                        currentUser.ValidTo = defaultUser.ValidTo;
                        userAccessList.Clear();
                        UserAccess currentUserAccess = null;

                        while (true)
                        {
                            asn1Type = Asn1DerStreamReadWriter.ReadAsn1TypeByteFromStream(fileStream);
                            int length = Asn1DerStreamReadWriter.ReadAsn1LengthBytesFromStream(fileStream);
                            switch (asn1Type.Asn1Type)
                            {
                                case 0x82267243:
                                    {
                                        continue;
                                    }
                                case 0x10bce7b4:
                                    {
                                        if (currentUserAccess != null)
                                            userAccessList.Add(currentUserAccess);
                                        currentUserAccess = new Pacom.Core.Access.UserAccess();
                                        break;
                                    }
                                case 0x25c686cf:
                                    {
                                        currentUserAccess.AccessGroupId = (int)Asn1DerStreamReadWriter.ReadAsn1IntegerFromStream(fileStream, length);
                                        break;
                                    }
                                case 0xb62c46e7:
                                case 0x0546aed2:
                                case 0xe2997c49:
                                case 0x9f280dd0:
                                    {
                                        byte[] stringData = new byte[length];
                                        if (fileStream.Read(stringData, 0, length) == -1)
                                            throw new SerializationException("Not enough ASN.1 data to deserialize string value.");
                                        switch (asn1Type.Asn1Type)
                                        {
                                            case 0xb62c46e7:
                                                {
                                                    currentUserAccess.EndDateTime = Asn1Der.ReadDateTime(stringData, length, UniversalType.GeneralizedTime);
                                                    break;
                                                }
                                            case 0x0546aed2:
                                                {
                                                    currentUserAccess.StartDateTime = Asn1Der.ReadDateTime(stringData, length, UniversalType.GeneralizedTime);
                                                    break;
                                                }
                                            case 0xe2997c49:
                                                {
                                                    currentUser.ValidFrom = Asn1Der.ReadDateTime(stringData, length, UniversalType.GeneralizedTime).Value;
                                                    break;

                                                }
                                            case 0x9f280dd0:
                                                {
                                                    currentUser.ValidTo = Asn1Der.ReadDateTime(stringData, length, UniversalType.GeneralizedTime).Value;
                                                    break;
                                                }
                                        }
                                        break;
                                    }
                                case 0x0113efc8:
                                    {
                                        currentUser.AlarmUserId = (int)Asn1DerStreamReadWriter.ReadAsn1IntegerFromStream(fileStream, length);
                                        break;
                                    }
                                case 0x8468be01:
                                    {
                                        currentUser.GroupId = (int)Asn1DerStreamReadWriter.ReadAsn1IntegerFromStream(fileStream, length);
                                        break;
                                    }
                                case 0x1:
                                    {
                                        currentUser.Id = (int)Asn1DerStreamReadWriter.ReadAsn1IntegerFromStream(fileStream, length);
                                        break;
                                    }
                                case 0x0fe07306:
                                    {
                                        currentUser.Name = Asn1DerStreamReadWriter.ReadAsn1StringFromStream(fileStream, length, UniversalType.Utf8String);
                                        break;
                                    }
                                case 0x1E:
                                    {
                                        currentUser.RevisionId = Asn1DerStreamReadWriter.ReadAsn1IntegerFromStream(fileStream, length);
                                        break;
                                    }
                                case 0x5f42a80d:
                                    {
                                        currentUser.UserFlags = (UserFlags)Asn1DerStreamReadWriter.ReadAsn1IntegerFromStream(fileStream, length);
                                        break;
                                    }
                                case 0x64b15109:
                                    {
                                        currentUser.UserPin = (int)Asn1DerStreamReadWriter.ReadAsn1IntegerFromStream(fileStream, length);
                                        break;
                                    }
                                default:
                                    {
                                        fileStream.Position += length;
                                        break;
                                    }
                            }

                            if (fileStream.Position >= nextObjectPosition)
                            {
                                if (currentUserAccess != null)
                                    userAccessList.Add(currentUserAccess);
                                currentUser.AccessGroups = userAccessList.ToArray();
                                configurationBaseWithStreamOffsetAndLength.Configuration = currentUser;
                                configuration.Add(configurationBaseWithStreamOffsetAndLength);
                                break;
                            }
                        }
                    }
                    else
                    {
                        fileStream.Position = configurationBaseWithStreamOffsetAndLength.Offset;

                        ConfigurationBase configurationItem = (ConfigurationBase)asn1Serializer.Deserialize(fileStream);
                        if (configurationItem == null)
                        {
                            // Deserialisation of the item failed, move onto next
                            continue;
                        }
                        elementsAffected |= getAffectedConfigurationElements(configurationItem, controllerLogicalId);

                        configurationBaseWithStreamOffsetAndLength.Configuration = configurationItem;
                        configurationBaseWithStreamOffsetAndLength.Length = (int)fileStream.Position - configurationBaseWithStreamOffsetAndLength.Offset;
                        configuration.Add(configurationBaseWithStreamOffsetAndLength);
                        if (configuration.Count == 2)
                            UserConfigurationListSDCard.CancelIndexCreation();
                    }
                }
                catch
                {
                    fileStream.Position = nextObjectPosition;
                }
            }
        }

        internal static void WriteOutConfigurationAndIndexFile(string outputFilePath, string inputFilePath, ConfigurationBaseWithStreamOffsetAndLength[] configuration, bool update)
        {
            string indexFileName = outputFilePath.Replace(".asn1", ".idx");
            List<ConfigurationIndexFileEntry> indexFileEntries;

            MarkConfigurationFileAsModified(outputFilePath);
            if (update == true && File.Exists(outputFilePath) && File.Exists(indexFileName))
            {
                // The existing files should be updated
                // We need to remove the nodes with the same ids as those that we have just received so that we may append the new configuration items to the
                // end of the file without causing any duplicated ids.

                using (FileStream fileStream = new FileStream(indexFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    byte[] buffer = new byte[4];
                    indexFileEntries = new List<ConfigurationIndexFileEntry>((int)(fileStream.Length / 12) + configuration.Length);
                    while (fileStream.Position < fileStream.Length)
                    {
                        try
                        {
                            ConfigurationIndexFileEntry indexFileEntry = new ConfigurationIndexFileEntry();
                            fileStream.Read(buffer, 0, 4);
                            indexFileEntry.Id = BitConverter.ToInt32(buffer, 0);
                            fileStream.Read(buffer, 0, 4);
                            indexFileEntry.Offset = BitConverter.ToInt32(buffer, 0);
                            fileStream.Read(buffer, 0, 4);
                            indexFileEntry.Length = BitConverter.ToInt32(buffer, 0);
                            indexFileEntries.Add(indexFileEntry);
                        }
                        catch
                        {
                        }
                    }
                }

                bool duplicateEntriesFound = false;
                foreach (ConfigurationBaseWithStreamOffsetAndLength configurationEntry in configuration)
                {
                    foreach (ConfigurationIndexFileEntry existingIndexFileEntry in indexFileEntries)
                    {
                        if (configurationEntry.Configuration.Id == existingIndexFileEntry.Id)
                        {
                            duplicateEntriesFound = true;
                            break;
                        }
                    }
                    if (duplicateEntriesFound)
                        break;
                }

                if (duplicateEntriesFound)
                {
                    // There was at least one duplicate entry found, we must first remove them before continuing to append the new configuration items.

                    if (File.Exists(FileSystemPaths.TempAsn1ConfigFilePath))
                        File.Delete(FileSystemPaths.TempAsn1ConfigFilePath);
                    File.Move(outputFilePath, FileSystemPaths.TempAsn1ConfigFilePath);
                    File.Delete(indexFileName);

                    using (FileStream newFileStream = new FileStream(outputFilePath, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                    {
                        using (FileStream oldFileStream = new FileStream(FileSystemPaths.TempAsn1ConfigFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                        {
                            for (int i = 0; i < indexFileEntries.Count; i++)
                            {
                                bool duplicateEntry = false;
                                foreach (ConfigurationBaseWithStreamOffsetAndLength configurationEntry in configuration)
                                {
                                    if (configurationEntry.Configuration.Id == indexFileEntries[i].Id)
                                    {
                                        duplicateEntry = true;
                                        break;
                                    }
                                }

                                if (duplicateEntry)
                                {
                                    // Don't copy the entry across to our new file & remove the index entry
                                    indexFileEntries.RemoveAt(i);
                                    i--;
                                }
                                else
                                {
                                    // Copy the entry across to our new file and update the offset in the index
                                    oldFileStream.Position = indexFileEntries[i].Offset;
                                    byte[] data = new byte[indexFileEntries[i].Length];
                                    oldFileStream.Read(data, 0, indexFileEntries[i].Length);
                                    indexFileEntries[i].Offset = (int)newFileStream.Position;
                                    newFileStream.Write(data, 0, indexFileEntries[i].Length);
                                }
                            }
                        }

                        // Append the new configuration to the end of the asn1 file
                        using (FileStream inputFileStream = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                        {
                            foreach (ConfigurationBaseWithStreamOffsetAndLength configurationBaseWithStreamOffsetAndLength in configuration)
                            {
                                inputFileStream.Position = configurationBaseWithStreamOffsetAndLength.Offset;
                                byte[] data = new byte[configurationBaseWithStreamOffsetAndLength.Length];
                                inputFileStream.Read(data, 0, data.Length);

                                ConfigurationIndexFileEntry indexFileEntry = new ConfigurationIndexFileEntry();
                                indexFileEntry.Offset = (int)newFileStream.Position;
                                indexFileEntry.Id = configurationBaseWithStreamOffsetAndLength.Configuration.Id;
                                indexFileEntry.Length = data.Length;

                                newFileStream.Write(data, 0, data.Length);

                                indexFileEntries.Add(indexFileEntry);
                            }
                        }
                    }
                    File.Delete(FileSystemPaths.TempAsn1ConfigFilePath);

                    // Write out all of the index entries
                    using (FileStream fileStream = new FileStream(indexFileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                    {
                        foreach (ConfigurationIndexFileEntry existingIndexFileEntry in indexFileEntries)
                        {
                            fileStream.Write(BitConverter.GetBytes(existingIndexFileEntry.Id), 0, 4);
                            fileStream.Write(BitConverter.GetBytes(existingIndexFileEntry.Offset), 0, 4);
                            fileStream.Write(BitConverter.GetBytes(existingIndexFileEntry.Length), 0, 4);
                        }
                    }
                }
                else
                {
                    // There were no duplicate entries found, simply append the new configuration items.
                    indexFileEntries = new List<ConfigurationIndexFileEntry>(configuration.Length);

                    using (FileStream outputFileStream = new FileStream(outputFilePath, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                    {
                        outputFileStream.Position = outputFileStream.Length;

                        using (FileStream inputFileStream = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                        {
                            foreach (ConfigurationBaseWithStreamOffsetAndLength configurationBaseWithStreamOffsetAndLength in configuration)
                            {
                                inputFileStream.Position = configurationBaseWithStreamOffsetAndLength.Offset;
                                byte[] data = new byte[configurationBaseWithStreamOffsetAndLength.Length];
                                inputFileStream.Read(data, 0, data.Length);

                                ConfigurationIndexFileEntry indexFileEntry = new ConfigurationIndexFileEntry();
                                indexFileEntry.Offset = (int)outputFileStream.Position;
                                indexFileEntry.Id = configurationBaseWithStreamOffsetAndLength.Configuration.Id;
                                indexFileEntry.Length = data.Length;

                                outputFileStream.Write(data, 0, data.Length);

                                indexFileEntries.Add(indexFileEntry);
                            }
                        }
                    }

                    // Append the new index entries to the end of the index file
                    using (FileStream fileStream = new FileStream(indexFileName, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                    {
                        fileStream.Position = fileStream.Length;

                        foreach (ConfigurationIndexFileEntry indexFileEntry in indexFileEntries)
                        {
                            fileStream.Write(BitConverter.GetBytes(indexFileEntry.Id), 0, 4);
                            fileStream.Write(BitConverter.GetBytes(indexFileEntry.Offset), 0, 4);
                            fileStream.Write(BitConverter.GetBytes(indexFileEntry.Length), 0, 4);
                        }
                    }
                }
            }
            else
            {
                // The existing files should be deleted
                indexFileEntries = new List<ConfigurationIndexFileEntry>();

                using (FileStream inputFileStream = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    using (FileStream outputFileStream = new FileStream(outputFilePath, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                    {
                        foreach (ConfigurationBaseWithStreamOffsetAndLength configurationBaseWithStreamOffsetAndLength in configuration)
                        {
                            inputFileStream.Position = configurationBaseWithStreamOffsetAndLength.Offset;
                            byte[] data = new byte[configurationBaseWithStreamOffsetAndLength.Length];
                            inputFileStream.Read(data, 0, data.Length);

                            ConfigurationIndexFileEntry indexFileEntry = new ConfigurationIndexFileEntry();
                            indexFileEntry.Offset = (int)outputFileStream.Position;
                            indexFileEntry.Id = configurationBaseWithStreamOffsetAndLength.Configuration.Id;
                            indexFileEntry.Length = data.Length;

                            outputFileStream.Write(data, 0, data.Length);

                            indexFileEntries.Add(indexFileEntry);
                        }
                    }
                }

                using (FileStream fileStream = new FileStream(indexFileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                {
                    foreach (ConfigurationIndexFileEntry indexFileEntry in indexFileEntries)
                    {
                        fileStream.Write(BitConverter.GetBytes(indexFileEntry.Id), 0, 4);
                        fileStream.Write(BitConverter.GetBytes(indexFileEntry.Offset), 0, 4);
                        fileStream.Write(BitConverter.GetBytes(indexFileEntry.Length), 0, 4);
                    }
                }
            }
        }

        private static void categoriseConfiguration(List<ConfigurationBaseWithStreamOffsetAndLength> configuration,
            out ConfigurationBaseWithStreamOffsetAndLength[] areas,
            out ConfigurationBaseWithStreamOffsetAndLength[] devices,
            out ConfigurationBaseWithStreamOffsetAndLength[] doors,
            out ConfigurationBaseWithStreamOffsetAndLength[] interlockGroups,
            out ConfigurationBaseWithStreamOffsetAndLength[] vaultControllerInterlockGroups,
            out ConfigurationBaseWithStreamOffsetAndLength[] inputs,
            out ConfigurationBaseWithStreamOffsetAndLength[] macros,
            out ConfigurationBaseWithStreamOffsetAndLength[] outputs,
            out ConfigurationBaseWithStreamOffsetAndLength[] elevators,
            out ConfigurationBaseWithStreamOffsetAndLength[] elevatorFloors,
            out ConfigurationBaseWithStreamOffsetAndLength[] ports,
            out ConfigurationBaseWithStreamOffsetAndLength[] readers,
            out ConfigurationBaseWithStreamOffsetAndLength[] presenceZones,
            out ConfigurationBaseWithStreamOffsetAndLength[] schedules,
            out ConfigurationBaseWithStreamOffsetAndLength[] accessSchedules,
            out ConfigurationBaseWithStreamOffsetAndLength[] users,
            out ConfigurationBaseWithStreamOffsetAndLength[] calendars,
            out ConfigurationBaseWithStreamOffsetAndLength[] cardProfiles,
            out ConfigurationBaseWithStreamOffsetAndLength[] controllerConnectionTables,
            out ConfigurationBaseWithStreamOffsetAndLength[] groups,
            out List<Credential> cards,
            out ConfigurationBaseWithStreamOffsetAndLength[] userAccessGroups,
            out ConfigurationBaseWithStreamOffsetAndLength[] openPacomToDigitalReceiverTemplates,
            out string[] updatedIdentifiers,
            out ConfigurationBaseWithStreamOffsetAndLength[] vaultControllers
            )
        {

            if (configuration == null || configuration.Count == 0)
            {
                areas = new ConfigurationBaseWithStreamOffsetAndLength[0];
                devices = new ConfigurationBaseWithStreamOffsetAndLength[0];
                doors = new ConfigurationBaseWithStreamOffsetAndLength[0];
                interlockGroups = new ConfigurationBaseWithStreamOffsetAndLength[0];
                inputs = new ConfigurationBaseWithStreamOffsetAndLength[0];
                macros = new ConfigurationBaseWithStreamOffsetAndLength[0];
                outputs = new ConfigurationBaseWithStreamOffsetAndLength[0];
                elevators = new ConfigurationBaseWithStreamOffsetAndLength[0];
                elevatorFloors = new ConfigurationBaseWithStreamOffsetAndLength[0];
                ports = new ConfigurationBaseWithStreamOffsetAndLength[0];
                readers = new ConfigurationBaseWithStreamOffsetAndLength[0];
                presenceZones = new ConfigurationBaseWithStreamOffsetAndLength[0];
                schedules = new ConfigurationBaseWithStreamOffsetAndLength[0];
                accessSchedules = new ConfigurationBaseWithStreamOffsetAndLength[0];
                users = new ConfigurationBaseWithStreamOffsetAndLength[0];
                calendars = new ConfigurationBaseWithStreamOffsetAndLength[0];
                cardProfiles = new ConfigurationBaseWithStreamOffsetAndLength[0];
                controllerConnectionTables = new ConfigurationBaseWithStreamOffsetAndLength[0];
                groups = new ConfigurationBaseWithStreamOffsetAndLength[0];
                cards = new List<Credential>();
                userAccessGroups = new ConfigurationBaseWithStreamOffsetAndLength[0];
                openPacomToDigitalReceiverTemplates = new ConfigurationBaseWithStreamOffsetAndLength[0];
                updatedIdentifiers = new string[0];
                vaultControllers = new ConfigurationBaseWithStreamOffsetAndLength[0];
                vaultControllerInterlockGroups = new ConfigurationBaseWithStreamOffsetAndLength[0];
                return;
            }

            List<ConfigurationBaseWithStreamOffsetAndLength> localAreaList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localDeviceList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localDoorList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localInterlockGroupList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localInputList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localMacroList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localOutputList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localPortList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localReaderList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localPresenceZoneList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localScheduleList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localAccessScheduleList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localUserList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localCalendarList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localCardProfileList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localControllerConnectionTableList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localGroupList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<Credential> localCardsList = new List<Credential>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localUserAccessGroupsList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localOpenPacomToDigitalReceiverTemplateList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<string> localUpdatedIdentifiersList = new List<string>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localElevatorList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localElevatorFloorList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localVaultControllerList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localVaultControllerInterlockGroupList = new List<ConfigurationBaseWithStreamOffsetAndLength>();

            foreach (ConfigurationBaseWithStreamOffsetAndLength configurationItem in configuration)
            {
                Area8003Configuration area8003Configuration = configurationItem.Configuration as Area8003Configuration;
                if (area8003Configuration != null)
                {
                    localAreaList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Area/{0}", area8003Configuration.Id));
                    continue;
                }

                ControllerConnection8003Table controllerConnection8003Table = configurationItem.Configuration as ControllerConnection8003Table;
                if (controllerConnection8003Table != null)
                {
                    localControllerConnectionTableList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Connection/{0}", controllerConnection8003Table.Id));
                    continue;
                }

                DeviceConfigurationBase device = configurationItem.Configuration as DeviceConfigurationBase;
                if (device != null)
                {
                    localDeviceList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Device/{0}", device.Id));
                    continue;
                }

                Door8003Configuration door8003Configuration = configurationItem.Configuration as Door8003Configuration;
                if (door8003Configuration != null)
                {
                    localDoorList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Door/{0}", door8003Configuration.Id));
                    continue;
                }

                Interlock8003Configuration interlock8003Configuration = configurationItem.Configuration as Interlock8003Configuration;
                if (interlock8003Configuration != null)
                {
                    localInterlockGroupList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/InterlockGroup/{0}", interlock8003Configuration.Id));
                    continue;
                }

                VaultControllerInterlock8003Configuration vaultControllerInterlock8003Configuration = configurationItem.Configuration as VaultControllerInterlock8003Configuration;
                if (vaultControllerInterlock8003Configuration != null)
                {
                    localVaultControllerInterlockGroupList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/VaultControllerInterlockGroup/{0}", vaultControllerInterlock8003Configuration.Id));
                    continue;
                }

                Group8003Configuration group8003Configuration = configurationItem.Configuration as Group8003Configuration;
                if (group8003Configuration != null)
                {
                    localGroupList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/AccessGroups/{0}", group8003Configuration.Id));
                    continue;
                }

                AnalogueInput8003Configuration analogueInput8003Configuration = configurationItem.Configuration as AnalogueInput8003Configuration;
                if (analogueInput8003Configuration != null)
                {
                    localInputList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Input/{0}", analogueInput8003Configuration.Id));
                    continue;
                }

                Input8003Configuration input8003Configuration = configurationItem.Configuration as Input8003Configuration;
                if (input8003Configuration != null)
                {
                    localInputList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Input/{0}", input8003Configuration.Id));
                    continue;
                }

                Macro8003Configuration macro8003Configuration = configurationItem.Configuration as Macro8003Configuration;
                if (macro8003Configuration != null)
                {
                    localMacroList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Macro/{0}", macro8003Configuration.Id));
                    continue;
                }

                Output8003Configuration output8003Configuration = configurationItem.Configuration as Output8003Configuration;
                if (output8003Configuration != null)
                {
                    localOutputList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Output/{0}", output8003Configuration.Id));
                    continue;
                }

                PresenceZone8003Configuration presenceZone8003Configuration = configurationItem.Configuration as PresenceZone8003Configuration;
                if (presenceZone8003Configuration != null)
                {
                    localPresenceZoneList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/PresenceZone/{0}", presenceZone8003Configuration.Id));
                    continue;
                }

                Reader8003LegacyWiegandConfiguration reader8003LegacyWiegandConfiguration = configurationItem.Configuration as Reader8003LegacyWiegandConfiguration;
                if (reader8003LegacyWiegandConfiguration != null)
                {
                    localReaderList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Reader/{0}", reader8003LegacyWiegandConfiguration.Id));
                    continue;
                }

                Reader8003Configuration reader8003Configuration = configurationItem.Configuration as Reader8003Configuration;
                if (reader8003Configuration != null)
                {
                    localReaderList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Reader/{0}", reader8003Configuration.Id));
                    continue;
                }

                Credential card = configurationItem.Configuration as Credential;
                if (card != null)
                {
                    localCardsList.Add(card);
                    localUpdatedIdentifiersList.Add(String.Format("/Cards/{0}", card.Id));
                    continue;
                }

                AccessSchedule accessSchedule = configurationItem.Configuration as AccessSchedule;
                if (accessSchedule != null)
                {
                    localAccessScheduleList.Add(configurationItem);
                    continue;
                }

                Schedule schedule = configurationItem.Configuration as Schedule;
                if (schedule != null)
                {
                    localScheduleList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Schedules/{0}", schedule.Id));
                    continue;
                }

                Port8003GprsPortConfiguration port8003GprsPortConfiguration = configurationItem.Configuration as Port8003GprsPortConfiguration;
                if (port8003GprsPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003GprsPortConfiguration.Id));
                    continue;
                }

                Port8003IPPortConfiguration port8003IPPortConfiguration = configurationItem.Configuration as Port8003IPPortConfiguration;
                if (port8003IPPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003IPPortConfiguration.Id));
                    continue;
                }

                Port8003RS485OsdpDeviceLoopPortConfiguration port8003RS485OsdpDeviceLoopPortConfiguration = configurationItem.Configuration as Port8003RS485OsdpDeviceLoopPortConfiguration;
                if (port8003RS485OsdpDeviceLoopPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003RS485OsdpDeviceLoopPortConfiguration.Id));
                    continue;
                }

                Port8003RS485AsisProprietaryReaderPortConfiguration port8003RS485AsisProprietaryReaderPortConfiguration = configurationItem.Configuration as Port8003RS485AsisProprietaryReaderPortConfiguration;
                if (port8003RS485AsisProprietaryReaderPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003RS485AsisProprietaryReaderPortConfiguration.Id));
                    continue;
                }

                Port8003RS485AperioPortConfiguration port8003RS485AperioPortConfiguration = configurationItem.Configuration as Port8003RS485AperioPortConfiguration;
                if (port8003RS485AperioPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003RS485AperioPortConfiguration.Id));
                    continue;
                }

                Port8003RS485DeviceLoopPortConfiguration port8003RS485DeviceLoopPortConfiguration = configurationItem.Configuration as Port8003RS485DeviceLoopPortConfiguration;
                if (port8003RS485DeviceLoopPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003RS485DeviceLoopPortConfiguration.Id));
                    continue;
                }

                Port8003DialupPortConfiguration port8003DialupPortConfiguration = configurationItem.Configuration as Port8003DialupPortConfiguration;
                if (port8003DialupPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003DialupPortConfiguration.Id));
                    continue;
                }

                Port8003RS232InovonicsPortConfiguration port8003RS232InovonicsPortConfiguration = configurationItem.Configuration as Port8003RS232InovonicsPortConfiguration;
                if (port8003RS232InovonicsPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003RS232InovonicsPortConfiguration.Id));
                    continue;
                }

                Port8003RS232DebugPortConfiguration port8003RS232DebugPortConfiguration = configurationItem.Configuration as Port8003RS232DebugPortConfiguration;
                if (port8003RS232DebugPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003RS232DebugPortConfiguration.Id));
                    continue;
                }

                User8003Configuration user8003Configuration = configurationItem.Configuration as User8003Configuration;
                if (user8003Configuration != null)
                {
                    localUserList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Users/{0}", user8003Configuration.Id));
                    continue;
                }

                User userConfiguration = configurationItem.Configuration as User;
                if (userConfiguration != null)
                {
                    localUserList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Users/{0}", userConfiguration.Id));
                    continue;
                }

                Pacom.Core.Access.Calendar calendarItem = configurationItem.Configuration as Pacom.Core.Access.Calendar;
                if (calendarItem != null)
                {
                    localCalendarList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Calendars/{0}", calendarItem.Id));
                    continue;
                }

                LegacyCardFormat legacyCardFormat = configurationItem.Configuration as LegacyCardFormat;
                if (legacyCardFormat != null)
                {
                    localCardProfileList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/CardProfiles/{0}", legacyCardFormat.Id));
                    continue;
                }

                AccessGroup accessGroupConfiguration = configurationItem.Configuration as AccessGroup;
                if (accessGroupConfiguration != null)
                {
                    localUserAccessGroupsList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/UserAccessGroups/{0}", accessGroupConfiguration.Id));
                    continue;
                }

                OpenPacomToDigitalReceiver8003Template openPacomToDigitalReceiver8003Template = configurationItem.Configuration as OpenPacomToDigitalReceiver8003Template;
                if (openPacomToDigitalReceiver8003Template != null)
                {
                    localOpenPacomToDigitalReceiverTemplateList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/OpenPacomToDigitalReceiverTemplate/{0}", openPacomToDigitalReceiver8003Template.Id));
                    continue;
                }

                Elevator8003Configuration elevatorConfiguration = configurationItem.Configuration as Elevator8003Configuration;
                if (elevatorConfiguration != null)
                {
                    localElevatorList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/ElevatorGroup/{0}", elevatorConfiguration.Id));
                    continue;
                }
                LegacyElevator8003Configuration legacyElevatorConfiguration = configurationItem.Configuration as LegacyElevator8003Configuration;
                if (legacyElevatorConfiguration != null)
                {
                    localElevatorList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/ElevatorGroup/{0}", legacyElevatorConfiguration.Id));
                    continue;
                }

                ElevatorFloor8003Configuration elevatorFloorConfiguration = configurationItem.Configuration as ElevatorFloor8003Configuration;
                if (elevatorFloorConfiguration != null)
                {
                    localElevatorFloorList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/ElevatorFloorGroup/{0}", elevatorFloorConfiguration.Id));
                    continue;
                }
            }

            areas = localAreaList.ToArray();
            devices = localDeviceList.ToArray();
            doors = localDoorList.ToArray();
            interlockGroups = localInterlockGroupList.ToArray();
            inputs = localInputList.ToArray();
            macros = localMacroList.ToArray();
            outputs = localOutputList.ToArray();
            elevators = localElevatorList.ToArray();
            elevatorFloors = localElevatorFloorList.ToArray();
            ports = localPortList.ToArray();
            readers = localReaderList.ToArray();
            presenceZones = localPresenceZoneList.ToArray();
            schedules = localScheduleList.ToArray();
            accessSchedules = localAccessScheduleList.ToArray();
            users = localUserList.ToArray();
            calendars = localCalendarList.ToArray();
            cardProfiles = localCardProfileList.ToArray();
            controllerConnectionTables = localControllerConnectionTableList.ToArray();
            groups = localGroupList.ToArray();
            cards = localCardsList;
            userAccessGroups = localUserAccessGroupsList.ToArray();
            openPacomToDigitalReceiverTemplates = localOpenPacomToDigitalReceiverTemplateList.ToArray();
            updatedIdentifiers = localUpdatedIdentifiersList.ToArray();
            vaultControllers = localVaultControllerList.ToArray();
            vaultControllerInterlockGroups = localVaultControllerInterlockGroupList.ToArray();
        }

        private static ConfigurationElementsAffected getAffectedConfigurationElements(ConfigurationBase configurationItem, int controllerLogicalId)
        {
            Area8003Configuration area8003Configuration = configurationItem as Area8003Configuration;
            if (area8003Configuration != null)
                return (ConfigurationElementsAffected.DeviceLoopDevices | ConfigurationElementsAffected.LocalDevice);

            ControllerConnection8003Table controllerConnection8003Table = configurationItem as ControllerConnection8003Table;
            if (controllerConnection8003Table != null)
                return ConfigurationElementsAffected.ControllerConnectionTable;

            DeviceConfigurationBase device = configurationItem as DeviceConfigurationBase;
            if (device != null)
            {
                if (device is Device8003Configuration)
                {
                    return ConfigurationElementsAffected.All;
                }
                else if (device is Device8201ExpansionConfiguration ||
                         device is Device8205ExpansionConfiguration ||
                         device is Device8207ExpansionConfiguration ||
                         device is Device8209ExpansionConfiguration)
                {
                    return ConfigurationElementsAffected.LocalDevice | ConfigurationElementsAffected.Ports;
                }
                else if (device is Device8203ExpansionConfiguration ||
                         device is Device8204ExpansionConfiguration)
                {
                    if (device.ParentDeviceId == controllerLogicalId)
                        return ConfigurationElementsAffected.LocalDevice;
                    else
                        return ConfigurationElementsAffected.DeviceLoopDevices;
                }
                else if (device is DeviceLoopDeviceConfigurationBase)
                {
                    return ConfigurationElementsAffected.DeviceLoopDevices;
                }
                else if (device is InovonicsDeviceConfigurationBase)
                {
                    return ConfigurationElementsAffected.InovonicsDevices;
                }
            }

            Door8003Configuration door8003Configuration = configurationItem as Door8003Configuration;
            if (door8003Configuration != null)
            {
                return ConfigurationElementsAffected.LocalDevice | ConfigurationElementsAffected.DeviceLoopDevices | ConfigurationElementsAffected.AccessControl;
            }

            Interlock8003Configuration interlock8003Configuration = configurationItem as Interlock8003Configuration;
            if (interlock8003Configuration != null)
            {
                return ConfigurationElementsAffected.AccessControl;
            }

            Group8003Configuration group8003Configuration = configurationItem as Group8003Configuration;
            if (group8003Configuration != null)
                return ConfigurationElementsAffected.Groups;

            AnalogueInput8003Configuration analogueInput8003Configuration = configurationItem as AnalogueInput8003Configuration;
            if (analogueInput8003Configuration != null)
            {
                if (analogueInput8003Configuration.ParentDeviceId == controllerLogicalId)
                    return ConfigurationElementsAffected.LocalDevice;
                else
                    return ConfigurationElementsAffected.DeviceLoopDevices;
            }

            Input8003Configuration input8003Configuration = configurationItem as Input8003Configuration;
            if (input8003Configuration != null)
            {
                if (input8003Configuration.ParentDeviceId == controllerLogicalId)
                    return ConfigurationElementsAffected.LocalDevice;
                else
                {
                    DeviceConfigurationBase deviceConfig = ConfigurationManager.Instance.GetDeviceConfiguration(input8003Configuration.ParentDeviceId);
                    if (deviceConfig != null && deviceConfig.HardwareType == HardwareType.InovonicsTransceiver)
                        return ConfigurationElementsAffected.InovonicsDevices;
                    return ConfigurationElementsAffected.DeviceLoopDevices;
                }
            }

            Macro8003Configuration macro8003Configuration = configurationItem as Macro8003Configuration;
            if (macro8003Configuration != null)
                return ConfigurationElementsAffected.Macros;

            Output8003Configuration output8003Configuration = configurationItem as Output8003Configuration;
            if (output8003Configuration != null)
            {
                if (output8003Configuration.ParentDeviceId == controllerLogicalId)
                    return ConfigurationElementsAffected.LocalDevice;
                else
                    return ConfigurationElementsAffected.DeviceLoopDevices;
            }

            PresenceZone8003Configuration presenceZone8003Configuration = configurationItem as PresenceZone8003Configuration;
            if (presenceZone8003Configuration != null)
                return (ConfigurationElementsAffected.DeviceLoopDevices | ConfigurationElementsAffected.LocalDevice);

            Reader8003Configuration reader8003Configuration = configurationItem as Reader8003Configuration;
            if (reader8003Configuration != null)
            {
                if (reader8003Configuration.ParentDeviceId == controllerLogicalId)
                    return ConfigurationElementsAffected.LocalDevice | ConfigurationElementsAffected.AccessControl;
                else
                    return ConfigurationElementsAffected.DeviceLoopDevices | ConfigurationElementsAffected.AccessControl;
            }

            AccessSchedule access8003Schedule = configurationItem as AccessSchedule;
            if (access8003Schedule != null)
                return ConfigurationElementsAffected.Schedules;

            Schedule schedule = configurationItem as Schedule;
            if (schedule != null)
                return ConfigurationElementsAffected.Schedules;

            Port8003GprsPortConfiguration port8003GprsPortConfiguration = configurationItem as Port8003GprsPortConfiguration;
            if (port8003GprsPortConfiguration != null)
                return ConfigurationElementsAffected.Ports;

            Port8003IPPortConfiguration port8003IPPortConfiguration = configurationItem as Port8003IPPortConfiguration;
            if (port8003IPPortConfiguration != null)
                return ConfigurationElementsAffected.Ports;

            Port8003RS485DeviceLoopPortConfiguration port8003RS485DeviceLoopPortConfiguration = configurationItem as Port8003RS485DeviceLoopPortConfiguration;
            if (port8003RS485DeviceLoopPortConfiguration != null)
                return ConfigurationElementsAffected.Ports;

            Port8003RS485OsdpDeviceLoopPortConfiguration port8003RS485OsdpDeviceLoopPortConfiguration = configurationItem as Port8003RS485OsdpDeviceLoopPortConfiguration;
            if (port8003RS485OsdpDeviceLoopPortConfiguration != null)
                return ConfigurationElementsAffected.Ports;

            Port8003RS485AsisProprietaryReaderPortConfiguration port8003RS485AsisProprietaryReaderPortConfiguration = configurationItem as Port8003RS485AsisProprietaryReaderPortConfiguration;
            if (port8003RS485AsisProprietaryReaderPortConfiguration != null)
                return ConfigurationElementsAffected.Ports;

            Port8003RS485AperioPortConfiguration port8003RS485AperioPortConfiguration = configurationItem as Port8003RS485AperioPortConfiguration;
            if (port8003RS485AperioPortConfiguration != null)
                return ConfigurationElementsAffected.Ports;

            Port8003DialupPortConfiguration port8003DialupPortConfiguration = configurationItem as Port8003DialupPortConfiguration;
            if (port8003DialupPortConfiguration != null)
                return ConfigurationElementsAffected.Ports;

            Port8003RS232InovonicsPortConfiguration port8003InovonicsPortConfiguration = configurationItem as Port8003RS232InovonicsPortConfiguration;
            if (port8003InovonicsPortConfiguration != null)
                return ConfigurationElementsAffected.RS232Port;

            UserConfigurationBase userConfiguration = configurationItem as UserConfigurationBase;
            if (userConfiguration != null)
                return ConfigurationElementsAffected.Users;

            Credential card = configurationItem as Credential;
            if (card != null)
                return ConfigurationElementsAffected.Users;

            AccessGroup accessGroup = configurationItem as AccessGroup;
            if (accessGroup != null)
                return ConfigurationElementsAffected.Users;

            Pacom.Core.Access.Calendar calendarItem = configurationItem as Pacom.Core.Access.Calendar;
            if (calendarItem != null)
                return ConfigurationElementsAffected.Schedules;

            LegacyCardFormat legacyCardFormat = configurationItem as LegacyCardFormat;
            if (legacyCardFormat != null)
                return (ConfigurationElementsAffected.DeviceLoopDevices | ConfigurationElementsAffected.LocalDevice);

            LegacyElevator8003Configuration legacyElevatorConfiguration = configurationItem as LegacyElevator8003Configuration;
            if (legacyElevatorConfiguration != null)
            {
                return ConfigurationElementsAffected.LocalDevice;
            }

            Elevator8003Configuration elevatorConfiguration = configurationItem as Elevator8003Configuration;
            if (elevatorConfiguration != null)
            {
                return ConfigurationElementsAffected.LocalDevice;
            }

            ElevatorFloor8003Configuration elevatorFloorConfiguration = configurationItem as ElevatorFloor8003Configuration;
            if (elevatorFloorConfiguration != null)
            {
                return ConfigurationElementsAffected.LocalDevice;
            }

            return ConfigurationElementsAffected.All;
        }

        public bool ValidateUploadRequest(string identifier)
        {
            int hashIndex = identifier.IndexOf('#');
            if (hashIndex != -1)
                identifier = identifier.Substring(0, hashIndex);
            if (identifier.Length == 0)
                return false;

            if (identifier == "/" || identifier.ToLower() == "/nodes/")
                return true;

            string[] identifierPortions = identifier.Substring(1).Split('/');
            for (int i = 0; i < identifierPortions.Length; i++)
            {
                identifierPortions[i] = identifierPortions[i].ToLower();
            }

            string configurationFileName = identifierPortions[0];
            switch (identifierPortions[0])
            {
                case "nodes":
                    configurationFileName = identifierPortions[1];
                    switch (identifierPortions[1])
                    {
                        case "area":
                            break;
                        case "device":
                            break;
                        case "door":
                            break;
                        case "interlockgroup":
                            break;
                        case "input":
                            break;
                        case "macro":
                            break;
                        case "output":
                            break;
                        case "port":
                            break;
                        case "reader":
                            break;
                        case "presencezone":
                            break;
                        default:
                            return false;
                    }
                    break;
                case "schedules":
                    break;
                case "users":
                    break;
                case "calendars":
                    break;
                case "cardprofiles":
                    break;
                case "connection":
                    break;
                case "accessgroups":
                    break;
                case "accessschedules":
                    break;
                case "useraccessgroups":
                    break;
                case "openpacomtodigitalreceivertemplate":
                    break;
                case "vaultcontrollers":
                    break;
                default:
                    return false;
            }

            if (configurationFileName[configurationFileName.Length - 1] != 's')
                configurationFileName += 's';

            int id = -1;
            if (identifierPortions[identifierPortions.Length - 1].Length > 0)
            {
                try
                {
                    id = Int32.Parse(identifierPortions[identifierPortions.Length - 1]);
                }
                catch
                {
                }
            }

            string indexFileName = FileSystemPaths.ConfigurationDirectory + configurationFileName + ".idx";

            if (id == -1)
            {
                if (File.Exists(indexFileName))
                {
                    using (FileStream fileStream = new FileStream(indexFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        if (fileStream.Length > 0)
                            return true;
                    }
                }
            }
            else
            {
                if (File.Exists(indexFileName))
                {
                    using (FileStream fileStream = new FileStream(indexFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        byte[] buffer = new byte[4];
                        while (fileStream.Position < fileStream.Length)
                        {
                            try
                            {
                                fileStream.Read(buffer, 0, 4);
                                int readId = BitConverter.ToInt32(buffer, 0);
                                if (readId == id)
                                    return true;
                                else
                                    fileStream.Position += 8;
                            }
                            catch
                            {
                            }
                        }
                    }
                }
            }

            return false;
        }

        public bool ValidateDownloadRequest(string identifier)
        {
            int hashIndex = identifier.IndexOf('#');
            if (hashIndex != -1)
                identifier = identifier.Substring(0, hashIndex);
            if (identifier.Length == 0)
                return false;

            if (identifier == "/" || identifier.ToLower() == "/nodes/" || identifier == "/WebTemplateDownload")
                return true;

            string[] identifierPortions = identifier.Substring(1).Split('/');
            for (int i = 0; i < identifierPortions.Length; i++)
            {
                identifierPortions[i] = identifierPortions[i].ToLower();
            }

            switch (identifierPortions[0])
            {
                case "nodes":
                    switch (identifierPortions[1])
                    {
                        case "area":
                            break;
                        case "device":
                            break;
                        case "door":
                            break;
                        case "interlockgroup":
                            break;
                        case "input":
                            break;
                        case "macro":
                            break;
                        case "output":
                            break;
                        case "port":
                            break;
                        case "reader":
                            break;
                        case "presencezone":
                            break;
                        default:
                            return false;
                    }
                    break;
                case "schedules":
                    break;
                case "users":
                    break;
                case "calendars":
                    break;
                case "cardprofiles":
                    break;
                case "connection":
                    break;
                case "accessgroups":
                    break;
                case "accessschedules":
                    break;
                case "cards":
                    break;
                case "useraccessgroups":
                    break;
                case "update":
                    break;
                case "web":
                    break;
                case "usb":
                    break;
                case "openpacomtodigitalreceivertemplate":
                    break;
                case "localupdate":
                    break;
                case "vaultcontrollers":
                    break;
                default:
                    return false;
            }

            return true;
        }
    }
}
