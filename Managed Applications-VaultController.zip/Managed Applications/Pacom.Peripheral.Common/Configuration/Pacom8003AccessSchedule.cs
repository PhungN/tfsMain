﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Core.Access;
using Pacom.Peripheral.Common.Utilities;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common.Configuration
{
    public class Pacom8003AccessSchedule : AccessSchedule
    {
        private Dictionary<DayType, ScheduleRecord> schedulesMap = new Dictionary<DayType, ScheduleRecord>();

        public Pacom8003AccessSchedule()
        {
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Schedules == null || Schedules.Length == 0)
                return;

            foreach (var scheduleRecord in Schedules)
            {
                schedulesMap[scheduleRecord.DayType] = scheduleRecord;
            }
        }

        public bool Enabled
        {
            get
            {
                DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
                DayType todayDay = StatusManager.TodayDayType;

                AccessLevel level = AccessLevel.Deny;
                ScheduleRecord scheduleRecord = null;
                if (schedulesMap.TryGetValue(todayDay, out scheduleRecord) == true)
                {
                    if ((scheduleRecord.Intervals != null && scheduleRecord.Intervals.Length > 0) == false)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return string.Format("Access Schedule for {0}, doesn't contain any intervals.", todayDay.ToString());
                        });
                    }
                    // An access schedule record was found for this day, look for the schedule interval the current time of day falls in and get the
                    // schedule level.
                    foreach (var scheduleInterval in scheduleRecord.Intervals)
                    {
                        if (scheduleInterval == null)
                            continue;
                        if (now.Hour > scheduleInterval.StartTime.Hour ||
                            (now.Hour == scheduleInterval.StartTime.Hour && now.Minute >= scheduleInterval.StartTime.Minute))
                        {
                            level = (AccessLevel)scheduleInterval.Level;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                return level == AccessLevel.Allow;
            }
        }
    }
}
