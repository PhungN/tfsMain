﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Core.Access;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class AccessGroupList : ConfigurationListBase<AccessGroup>, IConfigurationList
    {
        internal AccessGroupList() : base() { }

        /// <summary>
        /// Get next access group logical Id
        /// </summary>
        public int NextAccessGroupId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
