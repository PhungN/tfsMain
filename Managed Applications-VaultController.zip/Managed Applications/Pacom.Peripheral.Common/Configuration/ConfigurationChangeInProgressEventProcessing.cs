﻿using System;

namespace Pacom.Peripheral.Common.Configuration
{
    internal class ConfigurationChangeInProgressEventProcessing
    {
        private UserAuditInfo userAuditInfo;
        private IPacomTimer timer = null;
        private int totalTimeElapsed;
        private const int timeout = 60*1000;
        private const int eventExpiredTime = 24*60*60*1000;
        private Action<string> onEventExpired;

        public ConfigurationChangeInProgressEventProcessing(string identifier, UserAuditInfo userAuditInfo, Action<string> onChangeEventExpired)
        {
            this.Identifier = identifier;
            this.userAuditInfo = userAuditInfo;
            totalTimeElapsed = 0;
            timer = TimerManager.Instance.CreateTimer(onTimer, null, timeout, timeout);
            this.onEventExpired = onChangeEventExpired;
        }

        public string Identifier
        {
            get;
            private set;
        }

        public void Update()
        {
            totalTimeElapsed = 0;
            if (timer != null)
                timer.Change(timeout, timeout);
        }

        public void Dispose()
        {
            if (timer != null)
            {
                timer.Stop();
                TimerManager.Instance.RemoveTimer(timer);
                timer = null;
            }
        }

        private void onTimer(object state)
        {
            if (timer != null)
            {
                totalTimeElapsed += timeout;
                if (totalTimeElapsed >= eventExpiredTime)
                {
                    onEventExpired(Identifier);
                }
                else
                {
                    ConfigurationManager.Instance.NotifyFrontEndConfigurationChangeInProgress(Identifier, userAuditInfo);
                }
            }
        }
    }
}
