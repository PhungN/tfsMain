﻿using System;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    public abstract class ConfigurationListBase<T> where T : IConfiguration
    {
        protected SortedList<int, T> configurationItemList = null;

        protected ConfigurationListBase()
        {
            configurationItemList = new SortedList<int, T>();
        }

        /// <summary>
        /// Clear configuration items list
        /// </summary>
        public virtual void Clear()
        {
            if (configurationItemList != null)
                configurationItemList.Clear();
        }

        /// <summary>
        /// Returns number of configuration items managed by this list.
        /// </summary>
        public bool IsEmpty
        {
            get 
            {
                    return configurationItemList.Count == 0;
                }
            }

        /// <summary>
        /// Get configuration items count
        /// </summary>
        public int Count
        {
            get
            {
                    return configurationItemList.Count;
                }
            }

        /// <summary>
        /// Checks if a configuration item with the specified logicalId exists
        /// </summary>
        /// <param name="logicalId">Configuration item logical Id.</param>
        /// <returns>True if the configuration was found, False otherwise</returns>
        public bool Exists(int logicalId)
        {
                return (configurationItemList.ContainsKey(logicalId) == true);
            }

        /// <summary>
        /// Return the configuration list elements as an array that can be iterated independently
        /// </summary>
        public T[] AsArray
        {
            get
            {
                return configurationItemList.GetValues().ToArray();
                }
            }

        /// <summary>
        /// Return the configuration list elements as a generic list that can be iterated independently
        /// </summary>
        public List<T> AsList
        {
            get
            {
                return configurationItemList.GetValues();
            }
        }

        /// <summary>
        /// Return the configuration list elements ids as a generic list that can be iterated independently
        /// </summary>
        public List<int> AsKeyList
        {
            get
            {
                return configurationItemList.GetKeys();
            }
        }

        /// <summary>
        /// Return configuration object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Logical node id, 1 based</param>
        /// <returns>Node configuration instance or null if not found</returns>
        public virtual T this[int logicalId]
        {
            get
            {
                    if (logicalId < 1 || configurationItemList == null || configurationItemList.Count < 1)
                        return default(T);
                    T configurationItem = default(T);
                    configurationItemList.TryGetValue(logicalId, out configurationItem);
                    return configurationItem;
                }
            set
            {
                    if (logicalId >= 1 && value != null)
                        configurationItemList[logicalId] = value;
                }
            }

        /// <summary>
        /// Remove configuration item from list.
        /// </summary>
        /// <param name="logicalId">Configuration item to remove logical id.</param>
        /// <returns>True if the item was successfully removed.</returns>
        public bool Remove(int logicalId)
        {
                if (logicalId < 1)
                    return false;
                return configurationItemList.Remove(logicalId);
            }

        protected int lastDispensedItemId = -1;

        /// <summary>
        /// Get next available configuration item id.
        /// </summary>
        protected int nextConfigurationItemId
        {
            get
            {
                lock (ConfigurationManager.ControllerConfigurationSync)
                {
                    int nextId = 1;
                    if (ConfigurationManager.Instance.DefaultingConfiguration == false && configurationItemList.Count > 0)
                        nextId = (configurationItemList.Keys[configurationItemList.Count - 1] + 1);

                    nextId = Math.Max(nextId, lastDispensedItemId + 1);
                    lastDispensedItemId = nextId;
                    return lastDispensedItemId;
                }
            }
        }

        public virtual void ResetNextItemId()
        {
            lastDispensedItemId = 0;
        }

        public ConfigurationBase GetItem(int logicalId)
        {
            return this[logicalId] as ConfigurationBase;
        }

        public void SetItem(int logicalId, IConfiguration item)
        {
            this[logicalId] = (T)item;
        }
    }
}
