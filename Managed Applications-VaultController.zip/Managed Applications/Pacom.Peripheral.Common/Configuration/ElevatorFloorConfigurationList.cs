﻿
namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class ElevatorFloorConfigurationList : ConfigurationListBase<ElevatorFloorConfiguration>, IConfigurationList
    {
        internal ElevatorFloorConfigurationList() : base() { }

        /// <summary>
        /// Get next elevator controller Id
        /// </summary>
        public int NextElevatorFloorId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
