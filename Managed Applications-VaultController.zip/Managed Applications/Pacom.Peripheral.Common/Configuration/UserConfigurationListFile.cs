﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Peripheral.Common.Status;
using Pacom.Core.Contracts;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Serialization.Formatters.Asn1;
using System.Reflection;
using Pacom.Core.Access;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class UserConfigurationListFile : UserConfigurationList
    {
        SortedList<int, int> logicalIdToOffset;
        SortedList<int, int> userIdTologicalId;
        Dictionary<int, int> logicalIdToPin;

        StreamingContext context = new StreamingContext();
        ITypeLookup typesList = getListOfTypes();
        Asn1DerFormatter asn1Serializer;
        Dictionary<Type, PropertyInfo[]> reflectionDictionary = new Dictionary<Type, PropertyInfo[]>();

        internal UserConfigurationListFile()
        {
            asn1Serializer = new Asn1DerFormatter(typesList, true, context);

            byte[] fileData = null;
            ushort crcVal;
            if (File.Exists(FileSystemPaths.UsersConfigFilePath))
            {
                using (FileStream fileStream = new FileStream(FileSystemPaths.UsersConfigFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    fileData = new byte[fileStream.Length];
                    fileStream.Read(fileData, 0, fileData.Length);
                }
                crcVal = Crc16Ccitt.ComputeChecksum(fileData, 0, fileData.Length);

                if (readIndexFile())
                {
                    readSecondIndexFile(crcVal, fileData);
                }
                else
                {
                    string indexFileName = FileSystemPaths.UsersConfigFilePath.Replace(".asn1", ".idxb");
                    if (File.Exists(indexFileName))
                        File.Delete(indexFileName);
                }
            }
            else
            {
                logicalIdToOffset = new SortedList<int, int>();
                userIdTologicalId = new SortedList<int, int>();
                logicalIdToPin = new Dictionary<int, int>();

                string indexFileName = FileSystemPaths.UsersConfigFilePath.Replace(".asn1", ".idx");
                if (File.Exists(indexFileName))
                    File.Delete(indexFileName);
                indexFileName = FileSystemPaths.UsersConfigFilePath.Replace(".asn1", ".idxb");
                if (File.Exists(indexFileName))
                    File.Delete(indexFileName);
            }
        }

        private bool readIndexFile()
        {
            string indexFileName = FileSystemPaths.UsersConfigFilePath.Replace(".asn1", ".idx");
            if (File.Exists(indexFileName))
            {
                using (FileStream fileStream = new FileStream(indexFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    byte[] buffer = new byte[4];
                    logicalIdToOffset = new SortedList<int, int>((int)(fileStream.Length / 12));
                    while (fileStream.Position < fileStream.Length)
                    {
                        try
                        {
                            fileStream.Read(buffer, 0, 4);
                            int id = BitConverter.ToInt32(buffer, 0);
                            fileStream.Read(buffer, 0, 4);
                            int offset = BitConverter.ToInt32(buffer, 0);
                            fileStream.Seek(4, SeekOrigin.Current); // Length

                            logicalIdToOffset[id] = offset;
                        }
                        catch
                        {
                        }
                    }
                }
                return true;
            }
            else
            {
                logicalIdToOffset = new SortedList<int, int>();
                try
                {
                    if (File.Exists(FileSystemPaths.UsersConfigFilePath))
                        File.Delete(FileSystemPaths.UsersConfigFilePath);
                }
                catch
                {
                }
            }
            return false;
        }

        // A second index file has been added to improve Unison AlarmUserId -> logicalId and Pin -> logicalId searches.
        private void readSecondIndexFile(ushort crc, byte[] userFile)
        {
            bool indexFileValid = false;
            string indexFileName = FileSystemPaths.UsersConfigFilePath.Replace(".asn1", ".idxb");
            if (File.Exists(indexFileName))
            {
                using (FileStream fileStream = new FileStream(indexFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    if (fileStream.Length > 2 && (((fileStream.Length - 2) % 12) == 0))
                    {
                        byte[] buffer = new byte[4];
                        fileStream.Read(buffer, 0, 2);
                        ushort readCrc = BitConverter.ToUInt16(buffer, 0);
                        if (readCrc == crc)
                        {
                            indexFileValid = true;

                            userIdTologicalId = new SortedList<int, int>((int)((fileStream.Length - 2) / 12));
                            logicalIdToPin = new Dictionary<int, int>((int)((fileStream.Length - 2) / 12));
                            while (fileStream.Position < fileStream.Length)
                            {
                                try
                                {
                                    fileStream.Read(buffer, 0, 4);
                                    int logicalId = BitConverter.ToInt32(buffer, 0);
                                    fileStream.Read(buffer, 0, 4);
                                    int userId = BitConverter.ToInt32(buffer, 0);
                                    fileStream.Read(buffer, 0, 4);
                                    int pin = BitConverter.ToInt32(buffer, 0);

                                    if (userId > 0)
                                        userIdTologicalId[userId] = logicalId;
                                    logicalIdToPin[logicalId] = pin;
                                }
                                catch
                                {
                                    indexFileValid = false;
                                }
                            }
                        }
                    }
                }
            }

            if (indexFileValid == false)
            {
                // Something is wrong with the index file. Recreate it.
                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return "Users.idxb is corrupt or missing, recreating...";
                });

                if (File.Exists(indexFileName))
                    File.Delete(indexFileName);

                userIdTologicalId = new SortedList<int, int>(logicalIdToOffset.Count);
                logicalIdToPin = new Dictionary<int, int>(logicalIdToOffset.Count);

                bool isUnisonMode = ConfigurationManager.Instance.IsUnisonMode;
                bool corruptionDetected = false;
                using (FileStream indexFileStream = new FileStream(indexFileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                {
                    using (MemoryStream usersStream = new MemoryStream(userFile))
                    {
                        int logicalId = 0;
                        int userId = 0;
                        int pin = 0;

                        indexFileStream.Write(BitConverter.GetBytes(crc), 0, 2);
                        while (usersStream.Position < usersStream.Length)
                        {
                            try
                            {
                                int offset = (int)usersStream.Position;

                                ConfigurationBase configurationItem = (ConfigurationBase)asn1Serializer.Deserialize(usersStream);
                                if (configurationItem == null || configurationItem.Id < 1)
                                    continue;

                                if (isUnisonMode)
                                {
                                    User unisonUser = configurationItem as User;
                                    logicalId = unisonUser.Id;
                                    userId = unisonUser.AlarmUserId;
                                    pin = unisonUser.UserPin;
                                }
                                else
                                {
                                    User8003Configuration emcsUser = configurationItem as User8003Configuration;
                                    logicalId = emcsUser.Id;
                                    userId = emcsUser.Id;
                                    pin = emcsUser.UserPin;
                                }

                                if (logicalIdToOffset[logicalId] != offset)
                                {
                                    corruptionDetected = true;
                                    break;
                                }

                                if (userId > 0)
                                    userIdTologicalId[userId] = logicalId;
                                logicalIdToPin[logicalId] = pin;

                                indexFileStream.Write(BitConverter.GetBytes(logicalId), 0, 4);
                                indexFileStream.Write(BitConverter.GetBytes(userId), 0, 4);
                                indexFileStream.Write(BitConverter.GetBytes(pin), 0, 4);
                            }
                            catch
                            {
                            }
                        }
                    }
                }

                if (corruptionDetected)
                    RemoveAll();
            }
        }

        private void writeSecondIndexFile()
        {
            string indexFileName = FileSystemPaths.UsersConfigFilePath.Replace(".asn1", ".idxb");

            if (File.Exists(indexFileName))
                File.Delete(indexFileName);

            ushort crc = Crc16Ccitt.ComputeChecksum(FileSystemPaths.UsersConfigFilePath);

            using (FileStream indexFileStream = new FileStream(indexFileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
            {
                indexFileStream.Write(BitConverter.GetBytes(crc), 0, 2);

                foreach (int logicalId in logicalIdToPin.Keys)
                {
                    int index = userIdTologicalId.IndexOfValue(logicalId);
                    int userId = 0;
                    if (index >= 0)
                        userId = userIdTologicalId.Keys[index];
                    int pin = logicalIdToPin[logicalId];

                    indexFileStream.Write(BitConverter.GetBytes(logicalId), 0, 4);
                    indexFileStream.Write(BitConverter.GetBytes(userId), 0, 4);
                    indexFileStream.Write(BitConverter.GetBytes(pin), 0, 4);
                }
            }
        }

        public override void RemoveAll()
        {
            lock (ConfigurationManager.ControllerConfigurationSync)
            {
                logicalIdToOffset.Clear();
                userIdTologicalId.Clear();
                logicalIdToPin.Clear();

                if (File.Exists(FileSystemPaths.UsersConfigFilePath))
                    File.Delete(FileSystemPaths.UsersConfigFilePath);
                string indexFileName = FileSystemPaths.UsersConfigFilePath.Replace(".asn1", ".idx");
                if (File.Exists(indexFileName))
                    File.Delete(indexFileName);
                indexFileName = FileSystemPaths.UsersConfigFilePath.Replace(".asn1", ".idxb");
                if (File.Exists(indexFileName))
                    File.Delete(indexFileName);
            }
        }

        /// <summary>
        /// Delete user configuration from user configuration list.
        /// </summary>
        /// <param name="logicalIds">Ids of the user configuration to remove.</param>
        /// <param name="userAuditInfo">User audit details: user type, user Id.</param>
        /// <returns>True if the user configuration was successfully removed.</returns>
        public override bool Delete(int[] logicalIds, UserAuditInfo userAuditInfo)
        {
            try
            {
                bool anyToRemove = false;

                lock (ConfigurationManager.ControllerConfigurationSync)
                {
                    foreach (int logicalId in logicalIds)
                    {
                        if (logicalIdToOffset.ContainsKey(logicalId))
                        {
                            anyToRemove = true;
                            break;
                        }
                    }
                    if (anyToRemove == false)
                        return true;
                    try
                    {
                        ConfigurationManager.Instance.CallConfigurationChangingEvent(ConfigurationElementsAffected.Users);

                        string tempIndexFileName = FileSystemPaths.TempAsn1ConfigFilePath.Replace(".asn1", ".idx");
                        if (File.Exists(FileSystemPaths.TempAsn1ConfigFilePath))
                            File.Delete(FileSystemPaths.TempAsn1ConfigFilePath);
                        if (File.Exists(tempIndexFileName))
                            File.Delete(tempIndexFileName);
                        File.Move(FileSystemPaths.UsersConfigFilePath, FileSystemPaths.TempAsn1ConfigFilePath);
                        File.Move(FileSystemPaths.UsersConfigFilePath.Replace(".asn1", ".idx"), tempIndexFileName);
                        byte[] buffer = new byte[12];
                        byte[] data = new byte[0];

                        int newOffset = 0;
                        using (FileStream newIndexFileStream = new FileStream(FileSystemPaths.UsersConfigFilePath.Replace(".asn1", ".idx"), FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                        {
                            using (FileStream oldIndexFileStream = new FileStream(tempIndexFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                            {
                                using (FileStream newFileStream = new FileStream(FileSystemPaths.UsersConfigFilePath, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                                {
                                    using (FileStream oldFileStream = new FileStream(FileSystemPaths.TempAsn1ConfigFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                                    {
                                        while (oldIndexFileStream.Position < oldIndexFileStream.Length)
                                        {
                                            oldIndexFileStream.Read(buffer, 0, 12);
                                            int id = BitConverter.ToInt32(buffer, 0);
                                            int offset = BitConverter.ToInt32(buffer, 4);
                                            int length = BitConverter.ToInt32(buffer, 8);

                                            if (logicalIds.Contains(id))
                                            {
                                                try
                                                {
                                                    logicalIdToOffset.Remove(id);
                                                }
                                                catch
                                                {
                                                }
                                            }
                                            else
                                            {
                                                oldFileStream.Position = offset;
                                                if (length > data.Length)
                                                    data = new byte[length];
                                                oldFileStream.Read(data, 0, length);
                                                newOffset = (int)newFileStream.Position;
                                                newFileStream.Write(data, 0, length);
                                                logicalIdToOffset[id] = newOffset;
                                                newIndexFileStream.Write(BitConverter.GetBytes(id), 0, 4);
                                                newIndexFileStream.Write(BitConverter.GetBytes(newOffset), 0, 4);
                                                newIndexFileStream.Write(BitConverter.GetBytes(length), 0, 4);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        foreach (int logicalId in logicalIds)
                        {
                            int index = userIdTologicalId.IndexOfValue(logicalId);
                            if (index >= 0)
                                userIdTologicalId.RemoveAt(index);
                            logicalIdToPin.Remove(logicalId);
                        }
                        writeSecondIndexFile();
                    }
                    finally
                    {
                        ConfigurationManager.Instance.CallConfigurationChangedEvent(ConfigurationElementsAffected.Users, new List<ConfigurationChanges>(), new List<ConfigurationChanges>(), new List<ConfigurationChanges>());
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Unable to delete user configuration: {0}", ex.ToString());
                });
                return false;
            }
        }

        // Check that there is at least 1 engineer and 1 non engineer with areas assigned
        public override bool EngineerIsPresent(List<int> keypadAreas)
        {
            List<int> engineerAreas = new List<int>();
            List<int> nonengineerAreas = new List<int>();
            lock (ConfigurationManager.ControllerConfigurationSync)
            {
                using (FileStream fileStream = new FileStream(FileSystemPaths.UsersConfigFilePath, FileMode.Open))
                {
                    bool isUnisonMode = ConfigurationManager.Instance.IsUnisonMode;
                    while (fileStream.Position < fileStream.Length)
                    {
                        try
                        {
                            ConfigurationBase configurationItem = (ConfigurationBase)asn1Serializer.Deserialize(fileStream);
                            if (configurationItem == null || configurationItem.Id < 1)
                                continue;

                            User8003Configuration emcsUser = configurationItem as User8003Configuration;
                            if (isUnisonMode == true && configurationItem is User)
                            {
                                UserUnisonConfiguration userUnisonConfiguration = new UserUnisonConfiguration();
                                ConfigurationManager.CopyConfiguration(reflectionDictionary, configurationItem, userUnisonConfiguration);

                                bool isEngineer = userUnisonConfiguration.IsEngineer;
                                if (isEngineer)
                                    engineerAreas.AddRange(userUnisonConfiguration.AreaIds);
                                else
                                    nonengineerAreas.AddRange(userUnisonConfiguration.AreaIds);
                            }
                            else if (isUnisonMode == false && emcsUser != null)
                            {
                                bool isEngineer = ConfigurationManager.Instance.GetGroupConfiguration(emcsUser.GroupId).IsEngineer;
                                if (isEngineer)
                                    engineerAreas.AddRange(emcsUser.AreaIds);
                                else
                                    nonengineerAreas.AddRange(emcsUser.AreaIds);
                            }

                            // Check that there is at least 1 area in common to the keypad, the engineer and the non engineer
                            foreach (int area in keypadAreas)
                            {
                                if (engineerAreas.Contains(area) && nonengineerAreas.Contains(area))
                                    return true;
                            }
                        }
                        catch
                        {
                        }
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Return configuration object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Logical node id, 1 based</param>
        /// <returns>Node configuration instance or null if not found</returns>
        public override IUserConfiguration this[int logicalId]
        {
            get
            {
                lock (ConfigurationManager.ControllerConfigurationSync)
                {
                    if (logicalIdToOffset.ContainsKey(logicalId) == false)
                        return null;
                    try
                    {
                        using (FileStream fileStream = new FileStream(FileSystemPaths.UsersConfigFilePath, FileMode.Open))
                        {
                            try
                            {
                                fileStream.Position = logicalIdToOffset[logicalId];
                                ConfigurationBase configurationItem = (ConfigurationBase)asn1Serializer.Deserialize(fileStream);
                                if (configurationItem == null || configurationItem.Id < 1)
                                    return null;

                                if (ConfigurationManager.Instance.IsUnisonMode == true && configurationItem is User)
                                {
                                    UserUnisonConfiguration userUnisonConfiguration = new UserUnisonConfiguration();
                                    ConfigurationManager.CopyConfiguration(reflectionDictionary, configurationItem, userUnisonConfiguration);
                                    return userUnisonConfiguration;
                                }
                                else if (ConfigurationManager.Instance.IsUnisonMode == false && configurationItem is User8003Configuration)
                                {
                                    UserConfiguration userConfiguration = new UserConfiguration();
                                    ConfigurationManager.CopyConfiguration(reflectionDictionary, configurationItem, userConfiguration);
                                    return userConfiguration;
                                }
                            }
                            catch (Exception ex)
                            {
                                Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                                {
                                    return string.Format("Failed loading configuration item at position {0} from users.asn1 file. Handled exception : {1}",
                                        fileStream.Position, ex.ToString());
                                });
                            }
                        }
                    }
                    catch (FileNotFoundException)
                    {
                        // If there are no users, then the file won't exist
                    }
                }

                return null;
            }
        }

        public override bool Exists(int logicalId)
        {
            lock (ConfigurationManager.ControllerConfigurationSync)
            {
                return logicalIdToOffset.ContainsKey(logicalId);
            }
        }

        public override int Count
        {
            get
            {
                lock (ConfigurationManager.ControllerConfigurationSync)
                {
                    return logicalIdToOffset.Count;
                }
            }
        }

        /// <summary>
        /// Check if the User Id / Pin provided match any of the stored users.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="userPin">User Pin</param>
        /// <param name="logicalUserId">The logical id of the user (Same for EMCS, different for Unison)</param>
        /// <param name="duress">True if this was duress pin and the User Id was valid</param>
        /// <returns>True if User found, False otherwise</returns>
        public override bool CanUserLogin(int userId, int userPin, UserAccessLevel currentAccessLevel, out int logicalUserId, out bool duress)
        {
            duress = false;
            logicalUserId = 0;
            IUserConfiguration user = null;
            if (ConfigurationManager.Instance.IsUnisonMode)
            {
                if (userIdTologicalId.TryGetValue(userId, out logicalUserId))
                    user = this[logicalUserId];
            }
            else
            {
                logicalUserId = userId;
                user = this[logicalUserId];
            }

            if (user != null)
            {
                if (user.UserPin == userPin)
                {
                    bool accessLevelValid = isAccessLevelValid(currentAccessLevel, user.GroupId);
                    if (user.UserMode == ControllerMode.GmsEmcs || accessLevelValid == false)
                        return accessLevelValid;
                    // Extra checks required for Unison Mode of operation
                    return ((UserUnisonConfiguration)user).HasAccessPermission();
                }
                duress = user.UserPin.CheckDuressPin(userPin, ConfigurationManager.Instance.ControllerConfiguration.DuressType);
                if (duress == true)
                    return isAccessLevelValid(currentAccessLevel, user.GroupId);
            }
            return false;
        }

        /// <summary>
        /// Check if the Pin provided matches any of the stored users.
        /// </summary>
        /// <param name="userPin">User Pin</param>
        /// <param name="duress">True if this was duress pin and the User Id was valid</param>
        /// <returns>True if User found, False otherwise</returns>
        public override bool CanUserLogin(int userPin, UserAccessLevel currentAccessLevel, out int logicalUserId, out bool duress)
        {
            duress = false;
            logicalUserId = 0;

            if (userPin == 0)
                return false;

            lock (ConfigurationManager.ControllerConfigurationSync)
            {
                foreach (KeyValuePair<int, int> pair in logicalIdToPin)
                {
                    if (pair.Value == userPin)
                    {
                        logicalUserId = pair.Key;
                        duress = false;
                        break;
                    }
                    else if (pair.Value.CheckDuressPin(userPin, ConfigurationManager.Instance.ControllerConfiguration.DuressType))
                    {
                        logicalUserId = pair.Key;
                        duress = true;
                    }
                }
            }

            IUserConfiguration user = null;
            user = this[logicalUserId];

            if (user != null)
            {
                if (user.UserPin == userPin)
                {
                    bool accessLevelValid = isAccessLevelValid(currentAccessLevel, user.GroupId);
                    if (user.UserMode == ControllerMode.GmsEmcs || accessLevelValid == false)
                        return accessLevelValid;
                    // Extra checks required for Unison Mode of operation
                    return ((UserUnisonConfiguration)user).HasAccessPermission();
                }
                duress = user.UserPin.CheckDuressPin(userPin, ConfigurationManager.Instance.ControllerConfiguration.DuressType);
                if (duress == true)
                    return isAccessLevelValid(currentAccessLevel, user.GroupId);
            }
            return false;
        }

        /// <summary>
        /// Check if there are more than 1 users with the same PIN
        /// </summary>
        /// <param name="userPin"></param>
        /// <returns></returns>
        public override bool DoMultipleUsersHaveTheSamePin(int userPin)
        {
            bool foundPin = false;
            lock (ConfigurationManager.ControllerConfigurationSync)
            {
                foreach (KeyValuePair<int, int> pair in logicalIdToPin)
                {
                    if (pair.Value == userPin || pair.Value.CheckDuressPin(userPin, ConfigurationManager.Instance.ControllerConfiguration.DuressType))
                    {
                        if (foundPin)
                            return true;
                        foundPin = true;
                    }
                }
            }

            return false;
        }

        public override void WriteOutConfigurationAndIndexFile(string outputFilePath, string inputFilePath, ConfigurationBaseWithStreamOffsetAndLength[] configuration, bool update)
        {
            bool isUnisonMode = isUnisonConfiguration(configuration);

            lock (ConfigurationManager.ControllerConfigurationSync)
            {
                ConfigurationManager.WriteOutConfigurationAndIndexFile(outputFilePath, inputFilePath, configuration, update);
                readIndexFile();
                
                foreach (ConfigurationBaseWithStreamOffsetAndLength configurationBaseWithStreamOffsetAndLength in configuration)
                {
                    UserConfigurationBase baseUser = configurationBaseWithStreamOffsetAndLength.Configuration as UserConfigurationBase;

                    int logicalId = baseUser.Id;
                    int userId = baseUser.Id;
                    int pin = baseUser.UserPin;
                    if (isUnisonMode)
                    {
                        User unisonUser = configurationBaseWithStreamOffsetAndLength.Configuration as User;
                        userId = unisonUser.AlarmUserId;

                    }
                    int index = userIdTologicalId.IndexOfValue(logicalId);
                    if (index >= 0)
                        userIdTologicalId.RemoveAt(index);
                    if (userId > 0)
                        userIdTologicalId[userId] = logicalId;

                    logicalIdToPin[logicalId] = pin;
                }
                writeSecondIndexFile();
            }
        }

        public override int GetLowestId()
        {
            lock (ConfigurationManager.ControllerConfigurationSync)
            {
                if (logicalIdToOffset.Count == 0)
                    return 0;
                return logicalIdToOffset.Keys[0];
            }
        }

        public override int GetNextId(int currentId)
        {
            lock (ConfigurationManager.ControllerConfigurationSync)
            {
                int count = logicalIdToOffset.Count;
                if (count == 0)
                    return 0;
                int index = logicalIdToOffset.Keys.IndexOf(currentId) + 1;
                if (index >= count)
                    return logicalIdToOffset.Keys[0];
                return logicalIdToOffset.Keys[index];
            }
        }

        public override int GetPreviousId(int currentId)
        {
            lock (ConfigurationManager.ControllerConfigurationSync)
            {
                int count = logicalIdToOffset.Count;
                if (count == 0)
                    return 0;
                int index = logicalIdToOffset.Keys.IndexOf(currentId) - 1;
                if (index < 0)
                    return logicalIdToOffset.Keys[count - 1];
                return logicalIdToOffset.Keys[index];
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userIdentifier">LogicalId (for EMCS) or UserId (for Unison)</param>
        /// <returns></returns>
        public override IUserConfiguration GetUserConfiguration(int id, UserIdentifier userIdentifier)
        {
            if (userIdentifier == UserIdentifier.UserId)
            {
                int logicalUserId;
                if (userIdTologicalId.TryGetValue(id, out logicalUserId))
                    return this[logicalUserId];
                return null;
            }
            else
            {
                return this[id];
            }
        }
    }
}
