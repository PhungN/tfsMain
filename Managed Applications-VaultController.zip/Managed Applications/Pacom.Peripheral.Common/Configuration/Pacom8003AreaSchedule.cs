﻿using System;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom8003AreaSchedule : Schedule, IDisposable
    {
        private Dictionary<DayType, ScheduleRecord> schedulesMap = new Dictionary<DayType, ScheduleRecord>();

        private AreaScheduleLevel scheduledLevel = AreaScheduleLevel.Armed;

        /// <summary>
        /// Current schedule level - set every time the area schedule timer fires.
        /// </summary>
        public AreaScheduleLevel ScheduledLevel
        {
            get { return scheduledLevel; }
        }

        private int scheduleIntervalOffset = 0;

        /// <summary>
        /// Current schedule interval - set to the interval index plus one. 0 means no interval has been reached.
        /// </summary>
        public int ScheduleIntervalOffset
        {
            get { return scheduleIntervalOffset; }
        }

        private DayType scheduleDay = DayType.None;

        /// <summary>
        /// Current schedule day
        /// </summary>
        public DayType ScheduleDay
        {
            get { return scheduleDay; }
        }

        public Pacom8003AreaSchedule()
        {
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Schedules == null || Schedules.Length == 0)
                return;

            foreach (var scheduleRecord in Schedules)
            {
                schedulesMap[scheduleRecord.DayType] = scheduleRecord;
            }

            DateTime now = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
            RecalculateSchedule(now, null, false);
        }

        /// <summary>
        /// Get the current area schedule level and return the next time the timer should fire for this area schedule
        /// </summary>
        /// <param name="now">The current time</param>
        /// <returns>The next time when the timer should fire</returns>
        internal DateTime RecalculateSchedule(DateTime now, AreaStatusList areas, bool triggerLateToCloseEvent)
        {
            DayType todayDay = StatusManager.TodayDayType;
            DateTime nextStartTime = DateTime.MaxValue;
            AreaScheduleLevel level = AreaScheduleLevel.Armed;
            ScheduleRecord scheduleRecord = null;

            int newIntervalId = -1;
            DayType newDayType = DayType.None;
            if (schedulesMap.TryGetValue(todayDay, out scheduleRecord) == true)
            {
                if ((scheduleRecord.Intervals != null && scheduleRecord.Intervals.Length > 0) == false)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("Area Schedule for {0}, does not contain any intervals.", todayDay.ToString());
                    });
                }
                newDayType = todayDay;
                // A schedule record was found for this day, look for the schedule interval the current time of day falls in and get the
                // schedule level.
                if (scheduleRecord.Intervals.Length > 0)
                {
                    int maxIntervalId = scheduleRecord.Intervals.Length - 1;
                    for (int i = 0; i <= maxIntervalId; i++)
                    {
                        ScheduleInterval scheduleInterval = scheduleRecord.Intervals[i];
                        if (scheduleInterval == null)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                            {
                                return string.Format("Area Schedule interval for day {0} is invalid.", todayDay.ToString());
                            });
                        }
                        if (now.Hour > scheduleInterval.StartTime.Hour ||
                            (now.Hour == scheduleInterval.StartTime.Hour && now.Minute >= scheduleInterval.StartTime.Minute))
                        {
                            newIntervalId = i;
                            if (Enum.IsDefined(typeof(AreaScheduleLevel), scheduleInterval.Level))
                                level = (AreaScheduleLevel)scheduleInterval.Level;
                            else
                                level = AreaScheduleLevel.Armed;
                            if (newIntervalId < maxIntervalId)
                            {
                                TimeSpan timeOfDay = scheduleRecord.Intervals[i + 1].StartTime.TimeOfDay;
                                nextStartTime = new DateTime(now.Year, now.Month, now.Day, timeOfDay.Hours, timeOfDay.Minutes, timeOfDay.Seconds, DateTimeKind.Local);
                            }
                            else
                            {
                                nextStartTime = new DateTime(now.Year, now.Month, now.Day, 23, 59, 59, DateTimeKind.Local);
                            }
                        }
                        else
                        {
                            if (newIntervalId == -1)
                            {
                                // This time schedule record has one schedule interval only and the current time is smaller then the interval StartTime.
                                TimeSpan timeOfDay = scheduleInterval.StartTime.TimeOfDay;
                                nextStartTime = new DateTime(now.Year, now.Month, now.Day, timeOfDay.Hours, timeOfDay.Minutes, timeOfDay.Seconds, DateTimeKind.Local);
                            }
                            break;
                        }
                    }
                }
            }

            if (nextStartTime == DateTime.MaxValue)
            {
                // Get next timer due time
                nextStartTime = new DateTime(now.Year, now.Month, now.Day, 23, 59, 59, DateTimeKind.Local);
            }

            // Offset the interval Id by one. Zero means there was no interval schedule found.
            newIntervalId++;

            scheduledLevel = level;
            scheduleIntervalOffset = newIntervalId;
            scheduleDay = newDayType;

            if (areas != null && triggerLateToCloseEvent == true)
            {
                // Aggregate areas that obey this area schedule
                aggregateAreas(newDayType, newIntervalId, level, areas);
            }

            return nextStartTime;
        }

        /// <summary>
        /// Notify area list that a schedule change has occurred.
        /// </summary>
        /// <param name="day">None - no day has been found or it is the day of the week the interval applies.</param>
        /// <param name="intervalOffset">0 - no intervals are applied yet. Value 1 and more is a offset within the day intervals minus one. </param>
        /// <param name="level">Area schedule level</param>
        /// <param name="areas"></param>
        private void aggregateAreas(DayType day, int intervalOffset, AreaScheduleLevel level, AreaStatusList areas)
        {
            List<int> areaIds = new List<int>();
            foreach (var areaConfig in ConfigurationManager.Instance.AreasAsArray)
            {
                if (areaConfig.Enabled == true && areaConfig.NormalScheduleId == Id)
                {
                    if (areaIds.Contains(areaConfig.Id) == false)
                    {
                        if (level == AreaScheduleLevel.Armed)
                        {
                            if (areaConfig.AutoArmArea == true)
                            {
                                areaIds.Add(areaConfig.Id);
                            }
                            else
                            {
                                AreaStatus areaStatus = areas[areaConfig.Id];
                                if (areaStatus != null && areaStatus.Mode == AreaScheduleLevel.Disarmed)
                                {
                                    Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
                                    {
                                        return string.Format("Area [{0}] -> [SEND] Late to Close Event.", areaStatus.DisplayName);
                                    });
                                    areas.TriggerAreaLateToClose(areaStatus);
                                    // Start Area Late to Close timer
                                    areaStatus.StartLateToCloseTimer();
                                }
                            }
                        }
                        else if (level == AreaScheduleLevel.Disarmed)
                        {
                            areaIds.Add(areaConfig.Id);
                            AreaStatus areaStatus = areas[areaConfig.Id];
                            if (areaStatus != null && areaStatus.Mode == AreaScheduleLevel.Disarmed)
                            {
                                // Stop Area Late to Close timer
                                areaStatus.StopLateToCloseTimer();
                            }
                        }
                    }
                }
            }
            if (areaIds.Count > 0)
            {
                areas.ScheduleChangeNotification(this, day, intervalOffset, level, areaIds);
            }
        }

        #region IDisposable Members

        bool disposed = false;

        private void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                schedulesMap.Clear();
                schedulesMap = null;
                scheduledLevel = AreaScheduleLevel.Armed;
            }

            // Free any unmanaged objects here.            
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
