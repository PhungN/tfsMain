﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class DoorConfiguration : Door8003Configuration
    {
        public DoorConfiguration()
        {
        }

        public static int AutoConfigure(DeviceConfigurationBase parentDevice, int pointNumberOnParent, int readerInId, int readerOutId, List<ConfigurationBase> configuration)
        {
            Door8003Configuration doorConfiguration = new Door8003Configuration();
            doorConfiguration.SetDefaults();
            doorConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            doorConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            doorConfiguration.Id = ConfigurationManager.Instance.NextDoorId;
            doorConfiguration.ParentDeviceId = parentDevice.Id;
            doorConfiguration.PointNumberOnParent = pointNumberOnParent;
            if (ConfigurationManager.Instance.DefaultingConfiguration || ConfigurationManager.Instance.GetAreaConfiguration(1) != null)
                doorConfiguration.AreaId = 1;
            else
                doorConfiguration.AreaId = 0;
            doorConfiguration.ReaderInId = readerInId;
            doorConfiguration.ReaderOutId = readerOutId;
            doorConfiguration.Name = string.Format("Door {0}:{1}", parentDevice.Name, pointNumberOnParent);
            configuration.Add(doorConfiguration);
            return doorConfiguration.Id;
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        public void AutoConfigure(DeviceConfigurationBase parentDevice, int pointNumberOnParent, IReaderConfiguration inReader, IReaderConfiguration outReader)
        {
            InitializeWithDefaults();
            Id = ConfigurationManager.Instance.NextDoorId;
            ParentDeviceId = parentDevice.Id;
            PointNumberOnParent = pointNumberOnParent;
            AreaId = 1;
            Area = ConfigurationManager.Instance.GetAreaConfiguration(AreaId);
            if (Area != null)
                Area.AddDoor(this);
            string parentDeviceName = ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, parentDevice.Id);
            ConfigurationStringRepository.AddName(ConfigurationType.Door, Id, string.Format("Door {0}:{1}", parentDeviceName, pointNumberOnParent));

            if (inReader != null)
            {
                ReaderInId = inReader.Id;
                InReader = inReader;
                InReader.Door = this;
            }
            else
            {
                ReaderInId = 0;
            }
            if (outReader != null)
            {
                ReaderOutId = outReader.Id;
                OutReader = outReader;
                OutReader.Door = this;
            }
            else
            {
                ReaderOutId = 0;
            }
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Door, Id, Name);
                Name = null;
            }
        }
        
        public IReaderConfiguration InReader { get; set; }

        public IReaderConfiguration OutReader { get; set; }

        public EgressSchedule EgressSchedule { get; set; }

        public AreaConfiguration Area { get; set; }

        /// <summary>
        /// Get door name from repository
        /// </summary>
        /// <returns>Door Name if found in repository, empty otherwise</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Door, Id);
        }

        /// <summary>
        /// Convert StrikeTime TimeSpan to seconds as required by the Pacom comunication protocol
        /// </summary>
        public int StrikeTimeInSeconds
        {
            get 
            {
                if (StrikeTime.TotalSeconds > int.MaxValue)
                    return int.MaxValue;
                else
                    return (int)StrikeTime.TotalSeconds; 
            }
        }

        /// <summary>
        /// Convert StrikeTime TimeSpan to milliseconds as required by the Pacom comunication protocol
        /// </summary>
        public int StrikeTimeInMilliseconds
        {
            get 
            {
                if (StrikeTime.TotalMilliseconds > int.MaxValue)
                    return int.MaxValue;
                else
                    return (int)StrikeTime.TotalMilliseconds;
            }
        }

        /// <summary>
        /// Convert EmbarrassmentTime TimeSpan to seconds as required by the Pacom comunication protocol
        /// </summary>
        public int EmbarrassmentTimeInSeconds
        {
            get { return (int)EmbarrassmentTime.TotalSeconds; }
        }

        /// <summary>
        /// Check the EgressSchedule in order to see if the door egress operation should be allowed or not.
        /// </summary>
        public bool EgressEnabled
        {
            get 
            {
                if (EgressSchedule == null)
                    return false;
                return EgressSchedule.Enabled;
            }
        }
    }
}
