﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class UserConfiguration : User8003Configuration, IUserConfiguration
    {
        public UserConfiguration()
        {
            AreaIds = new int[0];
            AreaAccessPrivilege = new AreaAccessPrivilege[0];
            UserMode = ControllerMode.GmsEmcs;
        }

        public static void AutoConfigure(List<ConfigurationBase> configuration)
        {
            User8003Configuration userConfiguration = new User8003Configuration();
            userConfiguration.SetDefaults();
            userConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            userConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            userConfiguration.Name = "Admin";
            userConfiguration.UserPin = 2461;
            userConfiguration.OutsideHoursAccess = true;
            userConfiguration.UserManagementPrivilege = true;
            userConfiguration.AutoIsolateDeisolatePoints = false;
            userConfiguration.AreaIds = new int[1] { 1 };
            userConfiguration.AreaAccessPrivilege = new AreaAccessPrivilege[1] { new AreaAccessPrivilege() { CanIsolate = true } };
            configuration.Add(userConfiguration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            InitializeAfterCopyStatic(this);
        }

        public static void InitializeAfterCopyStatic(User8003Configuration user)
        {
            if (user.AreaIds == null)
                user.AreaIds = new int[0];
            if (user.AreaAccessPrivilege == null || user.AreaIds.Length != user.AreaAccessPrivilege.Length)
                user.AreaAccessPrivilege = new AreaAccessPrivilege[user.AreaIds.Length];
        }

        /// <summary>
        /// Get / Set User Mode, either GMS/EMCS or Unison
        /// </summary>
        public ControllerMode UserMode
        {
            get;
            private set;
        }

        /// <summary>
        /// Get the user accessible areas count
        /// </summary>
        public int AreaCount
        {
            get { return AreaIds.Length; }
        }

        /// <summary>
        /// Check if this is an engineer level user (Access Level 3 user)
        /// </summary>
        public bool IsEngineer
        {
            get
            {
                GroupConfiguration groupConfig = ConfigurationManager.Instance.GetGroupConfiguration(GroupId);
                return groupConfig != null ? groupConfig.IsEngineer : false;
            }
        }

        /// <summary>
        /// Get the user's name from repository
        /// </summary>
        /// <returns>The user's Name</returns>
        public string GetName()
        {
            return Name;
        }

        /// <summary>
        /// Get user LastName / FirstName from stored name in format LastName,FirstName
        /// </summary>
        public string[] GetLastFirstName()
        {
            string name = Name;
            if (string.IsNullOrEmpty(name))
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return "Empty user name.";
                });
                return new string[0];
            }

            // Return a string array with LastName = name[0] and FirstName = name[1]
            string[] names = name.Split(new char[] { ',' });
            if (names.Length < 1)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Invalid user name: {0}", name);
                });
            }
            return names;
        }

        /// <summary>
        /// Get user FirstName / LastName from stored name in format FirstName, LastName
        /// </summary>
        public string GetFirstLastName()
        {
            string[] names = GetLastFirstName();
            if (names.Length >= 1)
                return names.Length > 1 ? string.Format("{0} {1}", names[1], names[0]) : names[0];
            return "";
        }

        /// <summary>
        /// Set user name in storage from an array of LastName,FirstName values.
        /// </summary>
        public void SetLastFirstName(string[] lastFirstName)
        {
            if (lastFirstName.Length < 1)
                return;
            if (lastFirstName.Length == 2)
                Name = string.Format("{0},{1}", lastFirstName[0], lastFirstName[1]);
            else
                Name = string.Format("{0},", lastFirstName[0]);
        }

        /// <summary>
        /// Reset user to defaults
        /// </summary>
        public void ResetToDefaults()
        {
            SetDefaults();
        }

        /// <summary>
        /// Copy the properties of current user to [other] user
        /// </summary>
        /// <param name="other">The user instance whose properties will be updated from current user.</param>
        public void CopyTo(IUserConfiguration other)
        {
            if (other == null)
                return;

            other.Id = Id;
            other.UserPin = UserPin;
            other.GroupId = GroupId;
            other.SetLastFirstName(GetLastFirstName());
            other.OutsideHoursAccess = OutsideHoursAccess;
            other.UserManagementPrivilege = UserManagementPrivilege;
            other.AutoIsolateDeisolatePoints = AutoIsolateDeisolatePoints;
            // Copy the areas from user into [other] user
            if (AreaIds.Length == 0)
            {
                other.AreaIds = new int[0];
                other.AreaAccessPrivilege = new AreaAccessPrivilege[0];
                return;
            }
            other.AreaIds = new int[AreaIds.Length];
            other.AreaAccessPrivilege = new AreaAccessPrivilege[AreaIds.Length];
            Array.Copy(AreaIds, other.AreaIds, AreaIds.Length);
            Array.Copy(AreaAccessPrivilege, other.AreaAccessPrivilege, AreaIds.Length);
        }

        /// <summary>
        /// Add area identified by [logicalAreaId] id to this user accessible areas if not already added
        /// </summary>
        /// <param name="logicalAreaId">Logical area id, 1 based</param>
        /// <returns>True if the area was added successfuly, False otherwise</returns>
        public bool AddAreaById(int logicalAreaId)
        {
            // Check if logicalAreaId already present in AreaIds
            if (AreaIds.Contains(logicalAreaId) == true)
                return false;

            var area = ConfigurationManager.Instance.GetAreaConfiguration(logicalAreaId);
            if (area == null)
                return false;

            List<int> areaIds = new List<int>(AreaIds);
            areaIds.Add(area.Id);
            AreaIds = areaIds.ToArray();

            List<AreaAccessPrivilege> areaAccessPrivilege = new List<AreaAccessPrivilege>(AreaAccessPrivilege);
            areaAccessPrivilege.Add(new AreaAccessPrivilege() { CanIsolate = true });
            AreaAccessPrivilege = areaAccessPrivilege.ToArray();

            return true;
        }

        /// <summary>
        /// Replace user areas with those in the areasToAdd list
        /// </summary>
        /// <param name="areasToAdd">List of areas to add.</param>
        public void ReplaceAllAreas(List<AreaConfiguration> areasToAdd)
        {
            if (AreaIds.Length > 0)
                ClearAreas();

            AreaIds = new int[areasToAdd.Count];
            int index = 0;
            foreach (var area in areasToAdd)
            {
                AreaIds[index] = area.Id;
            }
        }

        /// <summary>
        /// Remove area specified by [logicalAreaId] from this user's accessible areas
        /// </summary>
        /// <param name="areaId">Logical area id, i based</param>
        /// <returns>True if the area was successfuly removed, False otherwise.</returns>
        public bool RemoveAreaById(int logicalAreaId)
        {
            // Check that the area with logicalAreaId exists in AreaIds
            if (AreaIds.Contains(logicalAreaId) == false)
                return false;

            List<int> areaIds = AreaIds.ToList();
            areaIds.Remove(logicalAreaId);
            AreaIds = areaIds.ToArray();

            return true;
        }

        /// <summary>
        /// Get all accessible areas for this user
        /// </summary>
        /// <param name="areas">The list to which user areas will be added</param>
        /// <returns>True if the user has any areas, False otherwise</returns>
        public bool GetAllAreas(out List<AreaConfiguration> areas)
        {
            areas = new List<AreaConfiguration>();
            if (AreaIds.Length == 0)
                return false;

            foreach (int areaId in AreaIds)
            {
                AreaConfiguration area = ConfigurationManager.Instance.Areas[areaId];
                if (area != null)
                    areas.Add(area);
            }
            return true;
        }

        /// <summary>
        /// Get all user area Ids
        /// </summary>
        /// <returns>List of all area Ids the user has access to.</returns>
        public List<int> GetAllAreaIds()
        {
            return AreaIds.ToList();
        }

        /// <summary>
        /// Check if this user can access area with [logicalAreaId] id
        /// </summary>
        /// <param name="logicalAreaId">Logical area id to check, 1 based</param>
        /// <returns>True if the user can access this area, False otherwise</returns>
        public bool CanAccessArea(int logicalAreaId)
        {
            return AreaIds.Contains(logicalAreaId);
        }

        /// <summary>
        /// Clear all accessible areas for this user
        /// </summary>
        public void ClearAreas()
        {
            AreaIds = new int[0];
            AreaAccessPrivilege = new AreaAccessPrivilege[0];
        }

        /// <summary>
        /// The user's ID as entered onto the keypad.
        /// </summary>
        public int UserId
        {
            get
            {
                return Id;
            }
        }

        /// <summary>
        /// Update user PIN
        /// </summary>
        /// <param name="newUserPin">New PIN value</param>
        public void ChangePin(int newUserPin)
        {
            UserPin = newUserPin;
        }

        /// <summary>
        /// Check if user has isolate privilege for this area.
        /// Returns true for area 0 if the user has privilege for any area.
        /// </summary>
        /// <param name="areaId"></param>
        /// <returns></returns>
        public bool CanIsolate(int areaId)
        {
            if (areaId > 0)
            {
                for (int i = 0; i < AreaIds.Length; i++)
                {
                    if (AreaIds[i] == areaId)
                    {
                        if (AreaAccessPrivilege != null && i < AreaAccessPrivilege.Length && AreaAccessPrivilege[i] != null)
                            return AreaAccessPrivilege[i].CanIsolate;
                        return true;
                    }
                }
            }
            return true;
        }
    }
}
