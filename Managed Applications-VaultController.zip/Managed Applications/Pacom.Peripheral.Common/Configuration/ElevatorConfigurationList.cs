﻿namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class ElevatorConfigurationList : NodeConfigurationListBase<IElevatorConfiguration>, IConfigurationList
    {
        internal ElevatorConfigurationList() : base() { }

        /// <summary>
        /// Get next elevator controller Id
        /// </summary>
        public int NextElevatorId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
