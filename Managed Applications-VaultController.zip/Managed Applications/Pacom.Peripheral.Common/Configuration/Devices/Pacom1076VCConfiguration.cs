﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utils;
using Pacom.Core.Contracts;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom1076VCConfiguration : Device1076VCConfiguration, IDeviceLoopIODevice
    {
        public const int OnboardInputsCount = 8;
        public const int OnboardOutputsCount = 4;

        public Pacom1076VCConfiguration()
        {
        }

        private static int getNextAvailableId(List<int> usedIds)
        {
            for (int i = 1; i < 16; i++)
            {
                if (usedIds.Contains(i) == false)
                    return i;
            }
            return -1;
        }

        public static void AutoConfigure(int physicalDeviceId, List<ConfigurationBase> configuration)
        {
            List<int> usedIds = new List<int>();
            foreach (var device in ConfigurationManager.Instance.VaultControllerDevices)
            {
                usedIds.Add(device.VaultControllerNumber);
            }
            int vaultNumber = getNextAvailableId(usedIds);

            var vcConfiguration = new Device1076VCConfiguration();
            ConfigurationManager.Instance.AddAutoConfigureDeviceConfiguration(vcConfiguration, "1076VC", HardwareType.Pacom1076VaultController, physicalDeviceId, configuration, 0, 0);
            vcConfiguration.VaultControllerNumber = vaultNumber;
            vcConfiguration.VaultName = string.Format("Vault {0}", vaultNumber.ToString("D2"));
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Device inputs list - 8 inputs available
        /// </summary>
        public InputConfiguration[] Inputs { get; set; }

        /// <summary>
        /// Device Outputs list - 4 output 
        /// </summary>
        public OutputConfiguration[] Outputs { get; set; }

        /// <summary>
        /// Check if any of the inputs has a valid configuration
        /// </summary>
        public bool InputsValid
        {
            get { return Inputs.Any(input => input != null); }
        }

        /// <summary>
        /// Check if the one output has a valid configuration
        /// </summary>
        public bool OutputsValid
        {
            get { return Outputs.Any(output => output != null); }
        }

        public int InputCount
        {
            get { return OnboardInputsCount; }
        }

        public int OutputCount
        {
            get { return OnboardOutputsCount; }
        }

        /// <summary>
        /// Get the door controller physical address including the controller address which is set to 0.
        /// </summary>
        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        /// <summary>
        /// Create device features list: 8 inputs and 4 outputs
        /// </summary>
        private void createDeviceFeaturesList()
        {
            if (Inputs == null)
                Inputs = new InputConfiguration[OnboardInputsCount];
            if (Outputs == null)
                Outputs = new OutputConfiguration[OnboardOutputsCount];
        }
    }
}
