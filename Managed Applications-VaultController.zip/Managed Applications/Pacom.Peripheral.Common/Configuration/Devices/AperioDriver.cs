﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    /// <summary>
    /// One for each bus. Holds the doors and readers on that  bus, one of each for each 
    /// possible Aperio address 1-127. Automatically created and destroyed as needed in CCM, 
    /// and hidden from the user.
    ///
    /// Device that door and reader points are on, with this linking to the specific RS485 
    /// port that is using the Aperio protocol
    /// </summary>
    public sealed class AperioDriver : AperioDriverConfiguration, IDeviceLoopDCDevice
    {
        public const int OnboardReadersCount = 127;
        public const int OnboardDoorsCount = 127;

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.AperioDriver, Id, Name);
                Name = null;
            }
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Create device features list: 127 readers and 127 doors
        /// </summary>
        private void createDeviceFeaturesList()
        {
            if (Readers == null)
                Readers = new IReaderConfiguration[OnboardReadersCount];
            if (Doors == null)
                Doors = new DoorConfiguration[OnboardDoorsCount];
        }

        /// <summary>
        /// DeviceAddress is not valid for AperioDriver
        /// </summary>
        public int DeviceAddress { get { return -1; } }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.AperioDriver, Id);
        }

        public IReaderConfiguration[] Readers { get; set; }
        public DoorConfiguration[] Doors { get; set; }

        public int ReaderCount{get { return OnboardReadersCount; }}
        public int DoorCount{get { return OnboardDoorsCount; }}

        /// <summary>
        /// Are any doors configured
        /// </summary>
        public bool DoorsValid
        {
            get
            {
                if (Doors == null)
                    return false;
                return Doors.Any(door => door != null);
            }
        }

        /// <summary>
        /// Are any readers configured
        /// </summary>
        public bool ReadersValid
        {
            get
            {
                if (Readers == null)
                    return false;
                return Readers.Any(reader => reader != null);
            }
        }

        /// <summary>
        /// Get Enable strike input for door
        /// </summary>
        /// <param name="doorIdOnDCDevice">Door id on door device</param>
        public bool IsStrikeEnabledForDoor(int doorIdOnDCDevice)
        {
            // Initially we don't know know if the door model can report strike state,
            // and we can't request it on demand.  If the door starts reporting
            // strike state, we'll update this on the DoorStatus later.
            return false;
        }

        /// <summary>
        /// Check if this reader can update the door peripherals
        /// </summary>
        /// <param name="reader">Reader Configuration instance</param>
        /// <returns>True if the reader can update the door peripherals, False otherwise</returns>
        public bool CanReaderUpdateDoorPeripherals(IReaderConfiguration reader)
        {
            return false; // the reader can't update our status LED, etc.
        }
    }
}
