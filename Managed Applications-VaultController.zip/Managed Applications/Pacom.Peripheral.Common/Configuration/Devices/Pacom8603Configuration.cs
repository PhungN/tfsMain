﻿using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom8603Configuration : Device8603DCConfiguration, IDeviceLoopIODevice, 
                                                                            IDeviceLoopDCDevice, 
                                                                            IDeviceLoopExpansionCardHolderDevice
    {
        /// <summary>
        /// Inputs count is OnBoard=(8) + Expansions1-4 + S-ART card =(8, 8, 8, 8, 124) -> 164 (one S-ART card allowed)
        /// </summary>
        public const int InputsCount = 164;

        public const int OnboardInputsCount = 8;

        public const int LegacyInputsCount = 32;

        /// <summary>
        /// Default outputs count is OnBoard=(8) + Expansions1-4 + S-ART card =(4, 4, 4, 4, 248) -> 272 (one S-ART card allowed)
        /// </summary>
        public const int OutputsCount = 272;

        public const int OnboardOutputsCount = 8;

        private const int expansionCardCount = 4;

        /// <summary>
        /// Returns number of allocated expansion slots on a device. Required by expansion holder device interface.
        /// </summary>
        public int ExpansionCardCount
        {
            get { return expansionCardCount; }
        }

        public const int OnboardReadersCount = 4;

        public const int OnboardDoorsCount = 2;

        #region  Door 1 input ids

        /// <summary>
        /// Pacom8603 door controller contact input id.
        /// </summary>
        public const int CardReaderAContactInputId = 5;

        /// <summary>
        /// Pacom8603 door controller egress input id.
        /// </summary>
        public const int CardReaderAEgressInputId = 7;

        /// <summary>
        /// Pacom8603 door controller strike input id.
        /// </summary>
        public const int CardReaderAStrikeInputId = 6;

        #endregion

        #region Door 2 input ids

        /// <summary>
        /// Pacom8603 door controller contact input id.
        /// </summary>
        public const int CardReaderBContactInputId = 2;

        /// <summary>
        /// Pacom8603 door controller egress input id.
        /// </summary>
        public const int CardReaderBEgressInputId = 4;

        /// <summary>
        /// Pacom8603 door controller strike input id.
        /// </summary>
        public const int CardReaderBStrikeInputId = 3;

        #endregion

        public Pacom8603Configuration()
        {
        }

        public static void AutoConfigure(int physicalDeviceId, List<ConfigurationBase> configuration)
        {
            Device8603DCConfiguration deviceConfiguration = new Device8603DCConfiguration();
            ConfigurationManager.Instance.AddAutoConfigureDeviceConfiguration(deviceConfiguration, "8603", HardwareType.Pacom8603, physicalDeviceId, configuration);

            // Create onboard inputs: IN1 and IN2 only
            for (int i = 0; i < 2; i++)
            {
                InputConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
            }

            // Create readers
            int[] readerIds = new int[OnboardReadersCount];
            bool isUnisonMode = ConfigurationManager.Instance.IsUnisonMode;
            for (int i = 0; i < OnboardReadersCount; i++)
            {
                if (isUnisonMode)
                    readerIds[i] = ReaderUnisonConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
                else
                    readerIds[i] = ReaderConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
            }

            // Create doors
            DoorConfiguration.AutoConfigure(deviceConfiguration, 1, readerIds[0], readerIds[2], configuration);
            DoorConfiguration.AutoConfigure(deviceConfiguration, 2, readerIds[1], readerIds[3], configuration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Get Enable strike input for child door
        /// </summary>
        /// <param name="doorIdOnDCDevice">Door id on door device: 0</param>
        /// <returns>Returns the value of EnableStrikeInputDoor2 flags.</returns>
        public bool IsStrikeEnabledForDoor(int doorIdOnDCDevice)
        {
            if (doorIdOnDCDevice < 0 || doorIdOnDCDevice > 1)
                return false;
            if (doorIdOnDCDevice == 0)
                return EnableStrikeInput1;
            return EnableStrikeInput2;
        }

        /// <summary>
        /// Check if this reader can update the shared door peripherals
        /// </summary>
        /// <param name="reader">Reader Configuration instance</param>
        /// <returns>True if the reader can update the door peripherals, False otherwise</returns>
        public bool CanReaderUpdateDoorPeripherals(IReaderConfiguration reader)
        {
            if (reader == null)
                return false;

            if (DoorsValid == false)
                return true;

            DoorConfiguration door = reader.Door;
            if (door != null)
                return true;

            IReaderConfiguration otherReader = getOtherReaderConfiguration(reader.PointNumberOnParent);
            if (otherReader == null)
                return true;

            if (otherReader.Door != null)
                return false;

            if (reader.PointNumberOnParent == 1 || reader.PointNumberOnParent == 2)
                return true;
            return false;
        }

        private IReaderConfiguration getOtherReaderConfiguration(int readerPhysicalId)
        {
            int otherReaderId = 0;
            switch (readerPhysicalId)
            {
                case 1:
                    otherReaderId = 3;
                    break;
                case 2:
                    otherReaderId = 4;
                    break;
                case 3:
                    otherReaderId = 1;
                    break;
                case 4:
                    otherReaderId = 2;
                    break;
            }
            if (otherReaderId == 0)
                return null;

            return Readers[otherReaderId - 1];
        }

        /// <summary>
        /// Assign input into the right location in 8603 device Inputs array 
        /// </summary>
        /// <param name="expansionCardSlot">Expansion card slot id: 0 - 3</param>
        /// <param name="outputConfiguration">Input configuration to insert</param>
        public void SetExpansionInput(int expSlot, InputConfiguration inputConfiguration)
        {
            if (expSlot < 0 && expSlot > ExpansionCardCount - 1)
                return;
            int inputStartId = getInputStartId(expSlot); 
            Inputs[inputStartId + inputConfiguration.PointNumberOnParent - 1] = inputConfiguration;
        }

        /// <summary>
        /// Get the 1st input id for expansion card slot
        /// </summary>
        /// <param name="expSlot">Expansion card slot: 0-3</param>
        /// <returns>The 1st input id for expansion slot, takes into account the presence of a S-ART card in one of the slots before the [expSlot]</returns>
        private int getInputStartId(int expSlot)
        {
            int offset = isSartCardInSlot(expSlot) == true ? 4 : expSlot;
            return OnboardInputsCount + offset * Pacom8204ExpansionConfiguration.OnboardInputsCount;
        }

        /// <summary>
        /// Assign output into the right location in 8603 device Outputs array 
        /// </summary>
        /// <param name="expansionCardSlot">Expansion card slot id: 0 - 3</param>
        /// <param name="outputConfiguration">Output configuration to insert</param>
        public void SetExpansionOutput(int expSlot, OutputConfiguration outputConfiguration)
        {
            if (expSlot < 0 && expSlot > ExpansionCardCount - 1)
                return;
            int outputStartId = OutputStartId(expSlot);
            Outputs[outputStartId + outputConfiguration.PointNumberOnParent - 1] = outputConfiguration;
        }

        /// <summary>
        /// S-ART outputs starting point in the Outputs array
        /// </summary>
        public const int SartOutputsStartingPoint = Pacom8603Configuration.OnboardOutputsCount + 4 * Pacom8203ExpansionConfiguration.OnboardOutputsCount;

        /// <summary>
        /// Get the 1st output id for expansion card slot
        /// </summary>
        /// <param name="expSlot">Expansion card slot: 0-3</param>
        /// <returns>The 1st output id for expansion slot, takes into account the presence of a S-ART card in one of the slots before the [expSlot]</returns>
        public int OutputStartId(int expSlot)
        {
            if (isSartCardInSlot(expSlot) == true)
                return SartOutputsStartingPoint;
            if (expSlot == 1)
                return OnboardOutputsCount;
            return expSlot == 0 ? OnboardOutputsCount + Pacom8203ExpansionConfiguration.OnboardOutputsCount :
                                  OnboardOutputsCount + expSlot * Pacom8203ExpansionConfiguration.OnboardOutputsCount;
        }

        /// <summary>
        /// Check if there is any S-ART card configured in any of the expansion slots before this one
        /// </summary>
        /// <param name="currentSlot">Current expansion card to check</param>
        /// <returns>True if any expansion card slot before this one ha s a S-ART card configured for it</returns>
        private bool isSartCardInSlot(int currentSlot)
        {
            return (ExpansionCards[currentSlot] != null && ExpansionCards[currentSlot].HardwareType == HardwareType.Pacom8208ExpansionCard);
        }

        /// <summary>
        /// Return S-ART expanion card slot number, 0 based or -1 if S-ART card is not found.
        /// </summary>
        public int SartCardSlotNumber
        {
            get
            {
                for (int i = 0; i < ExpansionCardCount; i++)
                {
                    if (isSartCardInSlot(i) == true)
                        return ExpansionCards[i].ExpansionCardSlot - 1;
                }
                return -1;
            }
        }

        /// <summary>
        /// Get logical input Id from owner and point number on owner
        /// </summary>
        /// <param name="owner">Input point owner: Onboard, Exp1, ..., Exp4, Sart1, etc.</param>
        /// <param name="pointNumberOnParent">Input point number on parent: 0 - max points on owner</param>
        /// <returns>Input logical Id or 0 if not found</returns>
        public int GetLogicalInputId(OwnerType owner, int pointNumberOnParent)
        {
            if (owner == OwnerType.None || owner == OwnerType.Tamper)
                return 0;

            int offset = 0;
            if (owner != OwnerType.Onboard)
            {
                offset = OnboardInputsCount + (int)(owner - OwnerType.Expansion1) * Pacom8204ExpansionConfiguration.OnboardInputsCount; 
            }
            InputConfiguration inputConfig = Inputs[offset + pointNumberOnParent];
            if (inputConfig != null)
                return inputConfig.Id;
            return 0;
        }

        /// <summary>
        /// Auto configure all 8603 valid expansion cards
        /// </summary>
        /// <param name="installedExpansionCards">expansion cards list: 4 in total</param>
        public void CreateExpansionCards(ExpansionCardType[] installedExpansionCards)
        {
            if (installedExpansionCards == null)
                return;

            List<ConfigurationBase> configuration = new List<ConfigurationBase>();

            for (int slot = 0; slot < ExpansionCardCount; slot++)
            {
                if (installedExpansionCards[slot] == ExpansionCardType.None)
                    continue;
                if (ExpansionCards[slot] != null) // Do not configure over existing entry
                    continue;

                switch (installedExpansionCards[slot])
                {
                    case ExpansionCardType.Pacom8204InputCard:
                        {
                            var parent = Pacom8204ExpansionConfiguration.AutoConfigure(slot + 1, Id, configuration);
                        // Create expansion card inputs
                        for (int i = 0; i < Pacom8204ExpansionConfiguration.OnboardInputsCount; i++)
                        {
                                InputConfiguration.AutoConfigure(parent, i + 1, configuration);
                            }
                        }
                        break;
                    case ExpansionCardType.Pacom8203OutputCard:
                        {
                            var parent = Pacom8203ExpansionConfiguration.AutoConfigure(slot + 1, Id, configuration);
                        // Create expansion card outputs
                        for (int i = 0; i < Pacom8203ExpansionConfiguration.OnboardOutputsCount; i++)
                        {
                                OutputConfiguration.AutoConfigure(parent, i + 1, configuration);
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
            if (configuration.Count > 0)
            {
                ConfigurationManager.Instance.DisableConfiguration(configuration);
                ConfigurationManager.Instance.UpdateConfiguration(configuration, false, ConfigurationManager.SystemUser, true);
            }
        }

        /// <summary>
        /// Expansion Cards array - 4 expansion cards available
        /// </summary>
        public ExpansionCardDeviceConfigurationBase[] ExpansionCards { get; set; }

        /// <summary>
        /// Onboard Inputs array - the number of available inputs, currently 164 = 8 + 8 + 8 + 8 + 8 + 124
        /// </summary>
        public InputConfiguration[] Inputs { get; set; }

        /// <summary>
        /// Onboard Outputs array - the number of available outputs, currently 272 = 8 + 4 + 4 + 4 + 4 + 248
        /// </summary>
        public OutputConfiguration[] Outputs { get; set; }

        /// <summary>
        /// Onboard readers - 4 readers available
        /// </summary>
        public IReaderConfiguration[] Readers { get; set; }

        /// <summary>
        /// Doors array - 2 door supported
        /// </summary>
        public DoorConfiguration[] Doors { get; set; }

        /// <summary>
        /// Check if any of the inputs has a valid configuration
        /// </summary>
        public bool InputsValid
        {
            get { return Inputs.Any(input => input != null); }
        }

        /// <summary>
        /// Check if the one output has a valid configuration
        /// </summary>
        public bool OutputsValid
        {
            get { return Outputs.Any(output => output != null); }
        }

        /// <summary>
        /// Check if 8603 readers were configured
        /// </summary>
        public bool DoorsValid
        {
            get 
            { 
                if (Doors == null)
                    return false;
                return Doors.Any(door => door != null);
            }
        }

        /// <summary>
        /// Check if any 8603 readers are configured
        /// </summary>
        public bool ReadersValid
        {
            get 
            {
                if (Readers == null)
                    return false;
                return Readers.Any(reader => reader != null); 
            }
        }

        /// <summary>
        /// Check if 8603 expansion cards were configured
        /// </summary>
        public bool ExpansionCardsValid
        {
            get { return ExpansionCards.Any(card => card != null && card.CardType != ExpansionCardType.None); }
        }

        private List<ExpansionCardDeviceConfigurationBase> getExpansionCard(ExpansionCardType cardType)
        {
            List<ExpansionCardDeviceConfigurationBase> expansionCards = new List<ExpansionCardDeviceConfigurationBase>();
            foreach (var card in ExpansionCards)
            {
                if (card != null && card.CardType == cardType)
                    expansionCards.Add(card);
            }
            return expansionCards;
        }

        public ExpansionCardDeviceConfigurationBase[] InputExpansionCards
        {
            get 
            {
                if (ExpansionCards.Length == 0)
                    return null;
                return getExpansionCard(ExpansionCardType.Pacom8204InputCard).ToArray();
            }
        }

        public ExpansionCardDeviceConfigurationBase[] OutputExpansionCards
        {
            get
            {
                if (ExpansionCards.Length == 0)
                    return null;
                return getExpansionCard(ExpansionCardType.Pacom8203OutputCard).ToArray();
            }
        }

        public int InputCount
        {
            get { return InputsCount; }
        }

        public int OutputCount
        {
            get { return OutputsCount; }
        }

        public int ReaderCount
        {
            get { return OnboardReadersCount; }
        }

        public int DoorCount
        {
            get { return OnboardDoorsCount; }
        }

        /// <summary>
        /// Get the door controller physical address including the controller address which is set to 0.
        /// </summary>
        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        /// <summary>
        /// Create device features list: 32 inputs, 13 outputs, 4 readers, 2 door and 4 expansion cards
        /// </summary>
        private void createDeviceFeaturesList()
        {
            if (Inputs == null)
                Inputs = new InputConfiguration[InputsCount];
            if (Outputs == null)
                Outputs = new OutputConfiguration[OutputsCount];
            if (Readers == null)
                Readers = new IReaderConfiguration[OnboardReadersCount];
            if (Doors == null)
                Doors = new DoorConfiguration[OnboardDoorsCount];
            if (ExpansionCards == null)
                ExpansionCards = new ExpansionCardDeviceConfigurationBase[ExpansionCardCount];
        }
    }
}
