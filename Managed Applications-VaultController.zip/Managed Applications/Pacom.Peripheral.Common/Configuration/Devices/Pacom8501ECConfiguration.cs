﻿using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom8501ECConfiguration : Device8501ECConfiguration, IDeviceLoopIODevice, IDeviceLoopExpansionCardHolderDevice
    {
        /// <summary>
        /// Inputs count is OnBoard=(16)
        /// </summary>
        public const int InputsCount = 16;
        public const int OnboardInputsCount = 16;
        public const int LegacyInputsCount = 16;

        /// <summary>
        /// Default outputs count is OnBoard=(4) + Expansions1-4
        /// </summary>
        public const int OutputsCount = 20;
        public const int OnboardOutputsCount = 4;
        private const int expansionCardCount = 4;

        /// <summary>
        /// Returns number of allocated expansion slots on a device. Required by expansion holder device interface.
        /// </summary>
        public int ExpansionCardCount
        {
            get
            {
                return expansionCardCount;
            }
        }

        public Pacom8501ECConfiguration()
        {
        }

        public static void AutoConfigure(int physicalDeviceId, List<ConfigurationBase> configuration)
        {
            ConfigurationManager.Instance.AddAutoConfigureDeviceConfiguration(new Device8501ECConfiguration(), "EC", HardwareType.Pacom1065ElevatorController, physicalDeviceId, configuration, 0, 0);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Assign input into the right location in 8501 device Inputs array 
        /// </summary>
        /// <param name="expansionCardSlot">Expansion card slot id: 0 - 3</param>
        /// <param name="outputConfiguration">Input configuration to insert</param>
        public void SetExpansionInput(int expSlot, InputConfiguration inputConfiguration)
        {
        }

        /// <summary>
        /// Assign output into the right location in 8501 device Outputs array 
        /// </summary>
        /// <param name="expansionCardSlot">Expansion card slot id: 0 - 3</param>
        /// <param name="outputConfiguration">Output configuration to insert</param>
        public void SetExpansionOutput(int expSlot, OutputConfiguration outputConfiguration)
        {
            if (expSlot < 0 && expSlot > ExpansionCardCount - 1)
                return;
            int outputStartId = OutputStartId(expSlot);
            Outputs[outputStartId + outputConfiguration.PointNumberOnParent - 1] = outputConfiguration;
        }

        /// <summary>
        /// Get the 1st output id for expansion card slot
        /// </summary>
        /// <param name="expSlot">Expansion card slot: 0-3</param>
        /// <returns>The 1st output id for expansion slot, takes into account the presence of a S-ART card in one of the slots before the [expSlot]</returns>
        public int OutputStartId(int expSlot)
        {
            if (expSlot == 1)
                return OnboardOutputsCount;
            return expSlot == 0 ? OnboardOutputsCount + Pacom8203ExpansionConfiguration.OnboardOutputsCount :
                                  OnboardOutputsCount + expSlot * Pacom8203ExpansionConfiguration.OnboardOutputsCount;
        }

        /// <summary>
        /// Get logical input Id from owner and point number on owner
        /// </summary>
        /// <param name="owner">Input point owner: Onboard, Exp1, ..., Exp4, Sart1, etc.</param>
        /// <param name="pointNumberOnParent">Input point number on parent: 0 - max points on owner</param>
        /// <returns>Input logical Id or 0 if not found</returns>
        public int GetLogicalInputId(OwnerType owner, int pointNumberOnParent)
        {
            if (owner == OwnerType.None || owner == OwnerType.Tamper)
                return 0;

            int offset = 0;
            if (owner != OwnerType.Onboard)
            {
                offset = OnboardInputsCount + (int)(owner - OwnerType.Expansion1) * Pacom8204ExpansionConfiguration.OnboardInputsCount;
            }
            InputConfiguration inputConfig = Inputs[offset + pointNumberOnParent];
            if (inputConfig != null)
                return inputConfig.Id;
            return 0;
        }

        /// <summary>
        /// Auto configure all 8501 valid expansion cards
        /// </summary>
        /// <param name="installedExpansionCards">expansion cards list: 4 in total</param>
        public void CreateExpansionCards(ExpansionCardType[] installedExpansionCards)
        {
            if (installedExpansionCards == null)
                return;

            List<ConfigurationBase> configuration = new List<ConfigurationBase>();

            // Create onboard expansion cards if present
            for (int slot = 0; slot < ExpansionCardCount; slot++)
            {
                if (installedExpansionCards[slot] == ExpansionCardType.None)
                    continue;
                if (ExpansionCards[slot] != null) // Do not configure over existing entry
                    continue;

                switch (installedExpansionCards[slot])
                {
                    case ExpansionCardType.Pacom8203OutputCard:
                        {
                            var parent = Pacom8203ExpansionConfiguration.AutoConfigure(slot + 1, Id, configuration);
                            // Create expansion card outputs
                            for (int i = 0; i < Pacom8203ExpansionConfiguration.OnboardOutputsCount; i++)
                            {
                                OutputConfiguration.AutoConfigure(parent, i + 1, configuration);
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
            if (configuration.Count > 0)
            {
                ConfigurationManager.Instance.DisableConfiguration(configuration);
                ConfigurationManager.Instance.UpdateConfiguration(configuration, false, ConfigurationManager.SystemUser, true);
            }
        }

        /// <summary>
        /// Expansion Cards array - 4 expansion cards available
        /// </summary>
        public ExpansionCardDeviceConfigurationBase[] ExpansionCards { get; set; }

        /// <summary>
        /// Onboard Inputs array - the number of available inputs, currently 16
        /// </summary>
        public InputConfiguration[] Inputs { get; set; }

        /// <summary>
        /// Onboard Outputs array - the number of available outputs, currently 20
        /// </summary>
        public OutputConfiguration[] Outputs { get; set; }

        /// <summary>
        /// Check if any of the inputs has a valid configuration
        /// </summary>
        public bool InputsValid
        {
            get { return Inputs.Any(input => input != null); }
        }

        /// <summary>
        /// Check if the one output has a valid configuration
        /// </summary>
        public bool OutputsValid
        {
            get { return Outputs.Any(output => output != null); }
        }

        /// <summary>
        /// Check if 8501 expansion cards were configured
        /// </summary>
        public bool ExpansionCardsValid
        {
            get { return ExpansionCards.Any(card => card != null && card.CardType != ExpansionCardType.None); }
        }

        public ExpansionCardDeviceConfigurationBase[] OutputExpansionCards
        {
            get
            {
                if (ExpansionCards.Length == 0)
                    return null;
                return getExpansionCards(ExpansionCardType.Pacom8203OutputCard).ToArray();
            }
        }

        public int InputCount
        {
            get { return InputsCount; }
        }

        public int OutputCount
        {
            get { return OutputsCount; }
        }

        /// <summary>
        /// Get the door controller physical address including the controller address which is set to 0.
        /// </summary>
        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        /// <summary>
        /// Create device features list: 32 inputs, 13 outputs, 2 readers, 1 door and 4 expansion cards
        /// </summary>
        private void createDeviceFeaturesList()
        {
            if (Inputs == null)
                Inputs = new InputConfiguration[InputsCount];
            if (Outputs == null)
                Outputs = new OutputConfiguration[OutputsCount];
            if (ExpansionCards == null)
                ExpansionCards = new ExpansionCardDeviceConfigurationBase[ExpansionCardCount];
        }

        private List<ExpansionCardDeviceConfigurationBase> getExpansionCards(ExpansionCardType cardType)
        {
            List<ExpansionCardDeviceConfigurationBase> expansionCards = new List<ExpansionCardDeviceConfigurationBase>();
            foreach (var card in ExpansionCards)
            {
                if (card != null && card.CardType == cardType)
                    expansionCards.Add(card);
            }
            return expansionCards;
        }
    }
}