﻿
namespace Pacom.Peripheral.Common.Configuration
{
    public interface IExpansionCardConfigurationBase
    {
        /// <summary>
        /// Get expansion card device name from repository
        /// </summary>
        /// <returns>Expansion Card Name</returns>
        string GetName();

    }
}
