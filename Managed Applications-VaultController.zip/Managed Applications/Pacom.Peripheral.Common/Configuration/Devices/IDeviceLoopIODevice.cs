﻿
namespace Pacom.Peripheral.Common.Configuration
{
    public interface IDeviceLoopIODevice : IDeviceLoopDeviceConfigurationBase, IInputDeviceConfigurationBase
    {
        /// <summary>
        /// Get / set IO device configured outputs
        /// </summary>
        OutputConfiguration[] Outputs { get; set; }

        /// <summary>
        /// Get IO device configured output count
        /// </summary>
        int OutputCount { get; }

        /// <summary>
        /// Check if the one output has a valid configuration
        /// </summary>
        bool OutputsValid { get; }
    }
}