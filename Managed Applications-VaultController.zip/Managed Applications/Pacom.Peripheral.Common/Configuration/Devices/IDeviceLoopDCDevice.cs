﻿
namespace Pacom.Peripheral.Common.Configuration
{
    public interface IDeviceLoopDCDevice : IDeviceLoopDeviceConfigurationBase
    {
        /// <summary>
        /// Get / set door controller device configured readers
        /// </summary>
        IReaderConfiguration[] Readers { get; set; }

        /// <summary>
        /// Get / set door controller device configured doors
        /// </summary>
        DoorConfiguration[] Doors { get; set; }

        /// <summary>
        /// Get door controller device readers count
        /// </summary>
        int ReaderCount { get; }

        /// <summary>
        /// Get door controller device doors count
        /// </summary>
        int DoorCount { get; }

        /// <summary>
        /// Check if any of the door controller device doors was configured.
        /// </summary>
        bool DoorsValid { get; }

        /// <summary>
        /// Check if any of the door controller device readers are configured.
        /// </summary>
        bool ReadersValid { get; }

        /// <summary>
        /// Returns the EnableStrike flag for one of the door controller device doors. 
        /// </summary>
        /// <param name="doorIdOnDCDevice">Physical door id on device: 0..1</param>
        /// <returns>True / False</returns>
        bool IsStrikeEnabledForDoor(int doorIdOnDCDevice);

        /// <summary>
        /// Check if this reader can update the shared door peripherals (this is valid for 8501 and on board DC interfaces)
        /// </summary>
        /// <param name="reader">Reader Configuration instance</param>
        /// <returns>True if the reader can update the door peripherals, False otherwise</returns>
        bool CanReaderUpdateDoorPeripherals(IReaderConfiguration reader);
    }
}