﻿using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public interface IDeviceLoopDeviceAreaList : IDeviceLoopDeviceConfigurationBase
    {
        /// <summary>
        /// List of areas that the keypad can arm / disarm
        /// </summary>
        AreaConfiguration[] Areas { get; set; }

        /// <summary>
        /// Keypad contains any of the areas in areaIds list
        /// </summary>
        /// <param name="areaIds">List of area Ids to check against.</param>
        /// <returns>True if at least one of the areaIds id is contained in keypad's AreaIds list.</returns>
        bool ContainsAnyArea(List<int> areaIds);

        /// <summary>
        /// Setup device areas list (create new area instances for all areas this device can handle, e.g.: 8101/1061 keypad areas)
        /// </summary>
        void SetupAreas();
    }
}