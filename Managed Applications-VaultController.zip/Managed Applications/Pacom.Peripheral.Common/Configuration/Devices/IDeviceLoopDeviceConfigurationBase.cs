﻿
namespace Pacom.Peripheral.Common.Configuration
{
    public interface IDeviceLoopDeviceConfigurationBase
    {
        /// <summary>
        /// Get the device physical address. For Inovonics devices this will be the device Unique ID (8 digit Serial Number).
        /// </summary>
        int DeviceAddress { get; }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        string GetName();
    }
}
