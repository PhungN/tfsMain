﻿using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public interface IDeviceLoopExpansionCardHolderDevice
    {
        /// <summary>
        /// Returns number of allocated expansion slots on a device
        /// </summary>
        int ExpansionCardCount { get; }

        /// <summary>
        /// Expansion Cards array
        /// </summary>
        ExpansionCardDeviceConfigurationBase[] ExpansionCards { get; set; }

        /// <summary>
        /// Assign input to expansion card
        /// </summary>
        /// <param name="expansionCardSlot">Expansion card slot id</param>
        /// <param name="outputConfiguration">Input configuration to insert</param>
        void SetExpansionInput(int expSlot, InputConfiguration inputConfiguration);

        /// <summary>
        /// Assign output to expansion card
        /// </summary>
        /// <param name="expansionCardSlot">Expansion card slot id</param>
        /// <param name="outputConfiguration">Output configuration to insert</param>
        void SetExpansionOutput(int expSlot, OutputConfiguration outputConfiguration);

        /// <summary>
        /// Check if expansion cards were configured
        /// </summary>
        bool ExpansionCardsValid { get; }
    }
}
