﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utils;
using Pacom.Core.Contracts;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom1076IOConfiguration : Device1076IOConfiguration, IDeviceLoopIODevice
    {
        public const int OnboardInputsCount = 8;
        public const int OnboardOutputsCount = 4;

        public Pacom1076IOConfiguration()
        {
        }

        public static void AutoConfigure(int physicalDeviceId, List<ConfigurationBase> configuration)
        {
            ConfigurationManager.Instance.AddAutoConfigureDeviceConfiguration(new Device1076IOConfiguration(), "1076IO", HardwareType.Pacom1076InputOutput, physicalDeviceId, configuration, OnboardInputsCount, OnboardOutputsCount);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Device inputs list - 8 inputs available
        /// </summary>
        public InputConfiguration[] Inputs { get; set; }

        /// <summary>
        /// Device Outputs list - 4 output 
        /// </summary>
        public OutputConfiguration[] Outputs { get; set; }

        /// <summary>
        /// Check if any of the inputs has a valid configuration
        /// </summary>
        public bool InputsValid
        {
            get { return Inputs.Any(input => input != null); }
        }

        /// <summary>
        /// Check if the one output has a valid configuration
        /// </summary>
        public bool OutputsValid
        {
            get { return Outputs.Any(output => output != null); }
        }

        public int InputCount
        {
            get { return OnboardInputsCount; }
        }

        public int OutputCount
        {
            get { return OnboardOutputsCount; }
        }

        /// <summary>
        /// Get the door controller physical address including the controller address which is set to 0.
        /// </summary>
        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        /// <summary>
        /// Create device features list: 8 inputs and 4 outputs
        /// </summary>
        private void createDeviceFeaturesList()
        {
            if (Inputs == null)
                Inputs = new InputConfiguration[OnboardInputsCount];
            if (Outputs == null)
                Outputs = new OutputConfiguration[OnboardOutputsCount];
        }
    }
}
