﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utils;
using Pacom.Core.Contracts;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom1065IOConfiguration : Device1065IOConfiguration, IDeviceLoopIODevice
    {
        public const int OnboardInputsCount = 16;
        public const int OnboardOutputsCount = 4;

        public Pacom1065IOConfiguration()
        {
        }

        public static void AutoConfigure(int physicalDeviceId, List<ConfigurationBase> configuration)
        {
            ConfigurationManager.Instance.AddAutoConfigureDeviceConfiguration(new Device1065IOConfiguration(), "1065IO", HardwareType.Pacom1065InputOutput, physicalDeviceId, configuration, OnboardInputsCount, OnboardOutputsCount); 
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Device inputs list - 16 inputs available
        /// </summary>
        public InputConfiguration[] Inputs { get; set; }

        /// <summary>
        /// Device Outputs list - 4 output 
        /// </summary>
        public OutputConfiguration[] Outputs { get; set; }

        /// <summary>
        /// Check if any of the inputs has a valid configuration
        /// </summary>
        public bool InputsValid
        {
            get { return Inputs.Any(input => input != null); }
        }

        /// <summary>
        /// Check if the one output has a valid configuration
        /// </summary>
        public bool OutputsValid
        {
            get { return Outputs.Any(output => output != null); }
        }

        public int InputCount
        {
            get 
            {
                return Inputs == null ? 0 : Inputs.Count(input => input != null);
            }
        }

        public int OutputCount
        {
            get 
            {
                return Outputs == null ? 0 : Outputs.Count(output => output != null);
            }
        }

        /// <summary>
        /// Get the door controller physical address including the controller address which is set to 0.
        /// </summary>
        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        /// <summary>
        /// Create device features list: max 48 inputs and max 20 outputs
        /// </summary>
        private void createDeviceFeaturesList()
        {
            Inputs = new InputConfiguration[48];
            Outputs = new OutputConfiguration[20];
        }

    }
}
