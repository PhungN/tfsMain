﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using System.Collections.Generic;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom8308Configuration : Device8308PowerSupplyConfiguration, IDeviceLoopDeviceConfigurationBase
    {
        public Pacom8308Configuration()
        {
        }

        public static void AutoConfigure(int physicalDeviceId, List<ConfigurationBase> configuration)
        {
            ConfigurationManager.Instance.AddAutoConfigureDeviceConfiguration(new Device8308PowerSupplyConfiguration(),
                                                                              "8308",
                                                                              HardwareType.Pacom8308,
                                                                              physicalDeviceId,
                                                                              configuration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            Initialize();
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            Initialize();
        }

        private void Initialize()
        {
            // Nothing to do for now
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        #region IDeviceLoopDeviceConfigurationBase Members

        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        #endregion
    }
}
