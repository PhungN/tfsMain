﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using System.Collections.Generic;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom8303Configuration : Device8303PowerSupplyConfiguration, IDeviceLoopDeviceConfigurationBase
    {
        public Pacom8303Configuration()
        {
        }

        public static void AutoConfigure(int physicalDeviceId, List<ConfigurationBase> configuration)
        {
            ConfigurationManager.Instance.AddAutoConfigureDeviceConfiguration(new Device8303PowerSupplyConfiguration(), "8303", HardwareType.Pacom8303, physicalDeviceId, configuration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            initialize();
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            initialize();
        }

        /// <summary>
        /// Convert the voltage value to milli volts if needed
        /// </summary>
        /// <param name="value">Configured Voltage value (it can be in either Voltas or MilliVolts). The values in Volt must be converted to MilliVolt.</param>
        /// <returns></returns>
        private int convertToThousands(int value)
        {
            const int voltDegreeMultiplier = 1000;
            if (value > 0 && value < 100)
                return value * voltDegreeMultiplier;
            return value;
        }

        private void initialize()
        {
            bool enableBatteryMonitoring = ExpectedBatteryVoltageRangeLowerBound < ExpectedBatteryVoltageRangeUpperBound;

            // Make sure the expected battery voltage lower / upper bound value is >= 8V
            ExpectedBatteryVoltageRangeLowerBound = Math.Max(8000, ExpectedBatteryVoltageRangeLowerBound);
            ExpectedBatteryVoltageRangeUpperBound = Math.Max(8000, ExpectedBatteryVoltageRangeUpperBound);
            batteryVoltageLowerBoundAdcReading = (int)Math.Floor(ExpectedBatteryVoltageRangeLowerBound * batteryVoltageMultiplier);
            batteryVoltageUpperBoundAdcReading = (int)Math.Floor(ExpectedBatteryVoltageRangeUpperBound * batteryVoltageMultiplier);
            if (enableBatteryMonitoring == false)
            {
                batteryVoltageLowerBoundAdcReading = int.MinValue;
                batteryVoltageUpperBoundAdcReading = int.MaxValue;
            }

            supplyVoltageLowerBoundAdcReading = (int)Math.Floor(ExpectedInputVoltageRangeLowerBound * supplyVoltageMultiplier);
            supplyVoltageUpperBoundAdcReading = (int)Math.Floor(ExpectedInputVoltageRangeUpperBound * supplyVoltageMultiplier);
            if (supplyVoltageLowerBoundAdcReading >= supplyVoltageUpperBoundAdcReading)
            {
                supplyVoltageLowerBoundAdcReading = int.MinValue;
                supplyVoltageUpperBoundAdcReading = int.MaxValue;
            }

            temperatureLowerBoundAdcReading = (int)Math.Floor(ExpectedTemperatureRangeLowerBound * temperatureMultiplier);
            temperatureUpperBoundAdcReading = (int)Math.Floor(ExpectedTemperatureRangeUpperBound * temperatureMultiplier);
            if (temperatureLowerBoundAdcReading >= temperatureUpperBoundAdcReading)
            {
                temperatureLowerBoundAdcReading = int.MinValue;
                temperatureUpperBoundAdcReading = int.MaxValue;
            }

            minBatteryVoltageInVolt = Math.Round(ExpectedBatteryVoltageRangeLowerBound / voltageAndTemperatureDivisor, 2);
            maxBatteryVoltageInVolt = Math.Round(ExpectedBatteryVoltageRangeUpperBound / voltageAndTemperatureDivisor, 2);
            minSupplyVoltageInVolt = Math.Round(ExpectedInputVoltageRangeLowerBound / voltageAndTemperatureDivisor, 2);
            maxSupplyVoltageInVolt = Math.Round(ExpectedInputVoltageRangeUpperBound / voltageAndTemperatureDivisor, 2);
            minTemperatureInDegreeC = Math.Round(ExpectedTemperatureRangeLowerBound / voltageAndTemperatureDivisor, 2);
            maxTemperatureInDegreeC = Math.Round(ExpectedTemperatureRangeUpperBound / voltageAndTemperatureDivisor, 2);
        }

        /// <summary>
        /// Check if any of the battery test parameters has changed.
        /// </summary>
        /// <param name="config">Pacom8303 Configuration to check against</param>
        /// <returns>True if any of the battery test parameters has changed, False otherwise.</returns>
        public bool BatteryTestParametersChanged(Pacom8303Configuration config)
        {
            if (config == null)
                return false;

            if (config.BatteryTestTime.Equals(BatteryTestTime) == false)
                return true;
            if (config.BatteryTestDuration.Equals(BatteryTestDuration) == false)
                return true;
            return false;
        }

        public override bool Equals(object obj)
        {
            Device8303PowerSupplyConfiguration config = obj as Device8303PowerSupplyConfiguration;
            if (config == null)
                return false;

            if (config.BatteryCapacity != BatteryCapacity)
                return false;

            if (config.BatteryTestDuration != BatteryTestDuration)
                return false;

            if (config.BatteryTestTime != BatteryTestTime)
                return false;

            if (config.ControllersPowerSupply != ControllersPowerSupply)
                return false;

            if (config.ExpectedBatteryVoltageRangeLowerBound != ExpectedBatteryVoltageRangeLowerBound)
                return false;

            if (config.ExpectedBatteryVoltageRangeUpperBound != ExpectedBatteryVoltageRangeUpperBound)
                return false;

            if (config.ExpectedInputVoltageRangeLowerBound != ExpectedInputVoltageRangeLowerBound)
                return false;

            if (config.ExpectedInputVoltageRangeUpperBound != ExpectedInputVoltageRangeUpperBound)
                return false;

            if (config.ExpectedTemperatureRangeLowerBound != ExpectedTemperatureRangeLowerBound)
                return false;

            if (config.ExpectedTemperatureRangeUpperBound != ExpectedTemperatureRangeUpperBound)
                return false;

            if (config.NominalCurrentDrain != NominalCurrentDrain)
                return false;

            if (config.PreWarningTime != PreWarningTime)
                return false;

            if (config.ParentDeviceId != ParentDeviceId)
                return false;

            return true;
        }

        private const double voltageAndTemperatureDivisor = 1000.0;
        private const double batteryVoltageDenominatorValue = (ConfigurationDefaults.BatteryACVoltageResistorValue + ConfigurationDefaults.BatteryVoltageResistorValue2) * ConfigurationDefaults.PowerSupplyReferenceVoltage;
        private const double batteryVoltageNumeratorValue = ConfigurationDefaults.BatteryACVoltageResistorValue * ConfigurationDefaults.MaximumAdcReading;
        private const double batteryVoltageMultiplier = batteryVoltageNumeratorValue / batteryVoltageDenominatorValue / voltageAndTemperatureDivisor;

        private int batteryVoltageLowerBoundAdcReading = 0;
        public int BatteryVoltageLowerBoundAdcReading
        {
            get { return batteryVoltageLowerBoundAdcReading; }
        }

        private int batteryVoltageUpperBoundAdcReading = 0;
        public int BatteryVoltageUpperBoundAdcReading
        {
            get { return batteryVoltageUpperBoundAdcReading; }
        }

        private const double supplyVoltageDenominatorValue = (ConfigurationDefaults.BatteryACVoltageResistorValue + ConfigurationDefaults.ACVoltageResistorValue) * ConfigurationDefaults.PowerSupplyReferenceVoltage;
        private const double supplyVoltageNumeratorValue = ConfigurationDefaults.BatteryACVoltageResistorValue * ConfigurationDefaults.MaximumAdcReading;
        private const double supplyVoltageMultiplier = supplyVoltageNumeratorValue / supplyVoltageDenominatorValue / voltageAndTemperatureDivisor;

        private int supplyVoltageLowerBoundAdcReading = 0;
        public int SupplyVoltageLowerBoundAdcReading
        {
            get { return supplyVoltageLowerBoundAdcReading; }
        }

        private int supplyVoltageUpperBoundAdcReading = 0;
        public int SupplyVoltageUpperBoundAdcReading
        {
            get { return supplyVoltageUpperBoundAdcReading; }
        }

        private const double temperatureDenominatorValue = ConfigurationDefaults.MaximumTemperature;
        private const double temperatureNumeratorValue = ConfigurationDefaults.MaximumAdcReading;
        private const double temperatureMultiplier = temperatureNumeratorValue / temperatureDenominatorValue / voltageAndTemperatureDivisor;

        private int temperatureLowerBoundAdcReading = 10;
        public int TemperatureLowerBoundAdcReading
        {
            get { return temperatureLowerBoundAdcReading; }
        }

        private int temperatureUpperBoundAdcReading = 717;
        public int TemperatureUpperBoundAdcReading
        {
            get { return temperatureUpperBoundAdcReading; }
        }

        private double minBatteryVoltageInVolt = 0.0;
        public double MinBatteryVoltageInVolt
        {
            get { return minBatteryVoltageInVolt; }
        }

        private double maxBatteryVoltageInVolt = 14.0;
        public double MaxBatteryVoltageInVolt
        {
            get { return maxBatteryVoltageInVolt; }
        }

        private double minSupplyVoltageInVolt = 0.0;
        public double MinSupplyVoltageInVolt
        {
            get { return minSupplyVoltageInVolt; }
        }

        private double maxSupplyVoltageInVolt = 20.0;
        public double MaxSupplyVoltageInVolt
        {
            get { return maxSupplyVoltageInVolt; }
        }

        private double minTemperatureInDegreeC = 1.0;
        public double MinTemperatureInDegreeC
        {
            get { return minTemperatureInDegreeC; }
        }

        private double maxTemperatureInDegreeC = 100.0;
        public double MaxTemperatureInDegreeC
        {
            get { return maxTemperatureInDegreeC; }
        }

        public override int GetHashCode()
        {
            return BatteryCapacity.GetHashCode() ^
                   BatteryTestDuration.GetHashCode() ^
                   BatteryTestTime.GetHashCode() ^
                   ControllersPowerSupply.GetHashCode() ^
                   ExpectedBatteryVoltageRangeLowerBound.GetHashCode() ^
                   ExpectedBatteryVoltageRangeUpperBound.GetHashCode() ^
                   ExpectedInputVoltageRangeLowerBound.GetHashCode() ^
                   ExpectedInputVoltageRangeUpperBound.GetHashCode() ^
                   ExpectedTemperatureRangeLowerBound.GetHashCode() ^
                   ExpectedTemperatureRangeUpperBound.GetHashCode() ^
                   NominalCurrentDrain.GetHashCode() ^
                   PreWarningTime.GetHashCode() ^
                   ParentDeviceId.GetHashCode();
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        #region IDeviceLoopDeviceConfigurationBase Members

        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        #endregion
    }
}
