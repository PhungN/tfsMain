﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utils;
using Pacom.Core.Contracts;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom1064DCConfiguration : Device1064DCConfiguration, IDeviceLoopIODevice, 
                                                                              IDeviceLoopDCDevice
    {
        /// <summary>
        /// Pacom1064 door controller contact input id.
        /// </summary>
        public const int ContactInputId = 0;

        /// <summary>
        /// Pacom1064 door controller egress input id.
        /// </summary>
        public const int EgressInputId = 1;

        /// <summary>
        /// Pacom1064 door controller strike input id.
        /// </summary>
        public const int StrikeInputId = 2;

        /// <summary>
        /// Pacom1064 door controller spare input id.
        /// </summary>
        public const int SpareInputId = 3;

        public const int OnboardInputsCount = 4;
        public const int OnboardOutputsCount = 0;

        public const int OnboardReadersCount = 1;
        public const int OnboardDoorsCount = 1;

        public Pacom1064DCConfiguration()
        {
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            createDeviceFeaturesList();
        }

        public static void AutoConfigure(int physicalDeviceId, List<ConfigurationBase> configuration)
        {
            Device1064DCConfiguration deviceConfiguration = new Device1064DCConfiguration();
            ConfigurationManager.Instance.AddAutoConfigureDeviceConfiguration(deviceConfiguration, "1064DC", HardwareType.Pacom1064DoorController, physicalDeviceId, configuration);

            // Create inputs
            for (int i = 0; i < OnboardInputsCount; i++)
            {
                if ((i == StrikeInputId && deviceConfiguration.EnableStrikeInput == false) || i == SpareInputId)
                    InputConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
            }

            // Create outputs
            for (int i = 0; i < OnboardOutputsCount; i++)
            {
                OutputConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
            }

            int readerInId;
            // Create readers
            if (ConfigurationManager.Instance.IsUnisonMode)
                readerInId = ReaderUnisonConfiguration.AutoConfigure(deviceConfiguration, 1, configuration);
            else
                readerInId = ReaderConfiguration.AutoConfigure(deviceConfiguration, 1, configuration);

            // Create doors
            for (int i = 0; i < OnboardReadersCount; i++)
            {
                DoorConfiguration.AutoConfigure(deviceConfiguration, i + 1, readerInId, 0, configuration);
            }
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Get Enable strike input for this door on this DC device
        /// </summary>
        /// <param name="doorIdOnDCDevice">Door id on device</param>
        /// <returns>Returns the value of EnableStrikeInput flag.</returns>
        public bool IsStrikeEnabledForDoor(int doorIdOnDCDevice)
        {
            if (doorIdOnDCDevice != 0)
                return false;
            return EnableStrikeInput;
        }

        /// <summary>
        /// Check if this reader can update the shared door peripherals (this is valid for 8501 and on board DC interfaces)
        /// </summary>
        /// <param name="reader">Reader Configuration instance</param>
        /// <returns>True if the reader can update the door peripherals, False otherwise</returns>
        public bool CanReaderUpdateDoorPeripherals(IReaderConfiguration reader)
        {
            return true;
        }

        /// <summary>
        /// Check if any of the inputs has a valid configuration
        /// </summary>
        public bool InputsValid
        {
            get { return Inputs.Any(input => input != null); }
        }

        /// <summary>
        /// Check if the one output has a valid configuration
        /// </summary>
        public bool OutputsValid
        {
            get { return Outputs.Any(output => output != null); }
        }

        /// <summary>
        /// Check if 1064DC door is configured
        /// </summary>
        public bool DoorsValid
        {
            get { return Doors != null && Doors.Length == 1 && Doors[0] != null; }
        }

        /// <summary>
        /// Check if the 1064DC reader is configured
        /// </summary>
        public bool ReadersValid
        {
            get { return Readers != null && Readers.Length == 1 && Readers[0] != null; }
        }

        /// <summary>
        /// Device inputs list - 4 inputs available
        /// </summary>
        public InputConfiguration[] Inputs { get; set; }

        /// <summary>
        /// Device Outputs list - 4 outputs available 
        /// </summary>
        public OutputConfiguration[] Outputs { get; set; }

        /// <summary>
        /// DC device readers - 1 available
        /// </summary>
        public IReaderConfiguration[] Readers { get; set; }

        /// <summary>
        /// DC device doors - 1 available
        /// </summary>
        public DoorConfiguration[] Doors { get; set; }

        public int InputCount 
        { 
            get { return OnboardInputsCount; } 
        }

        public int OutputCount
        {
            get { return OnboardOutputsCount; } 
        }

        public int ReaderCount 
        {
            get { return OnboardReadersCount; } 
        }

        public int DoorCount 
        {
            get { return OnboardDoorsCount; } 
        }

        /// <summary>
        /// Get the door controller physical address including the controller address which is set to 0.
        /// </summary>
        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        /// <summary>
        /// Create device features list: 4 inputs, 4 outputs, 1 reader and 1 door
        /// </summary>
        private void createDeviceFeaturesList()
        {
            if (Inputs == null)
                Inputs = new InputConfiguration[OnboardInputsCount];
            if (Outputs == null)
                Outputs = new OutputConfiguration[OnboardOutputsCount];
            if (Readers == null)
                Readers = new IReaderConfiguration[OnboardReadersCount];
            if (Doors == null)
                Doors = new DoorConfiguration[OnboardDoorsCount];
        }
    }
}
