﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using System.Collections.Generic;
using Pacom.Peripheral.Common.Utils;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom8101KeypadConfiguration : Device8003KeypadConfiguration, IDeviceLoopIODevice
                                                                                    , IDeviceLoopDCDevice
                                                                                    , IDeviceLoopDeviceAreaList
    {
        public const int OnboardInputsCount = 2;
        public const int OnboardOutputsCount = 4;

        public const int OnboardReadersCount = 1;
        public const int OnboardDoorsCount = 1;

        public Pacom8101KeypadConfiguration()
        {
        }

        public static void AutoConfigure(int physicalDeviceId, List<ConfigurationBase> configuration)
        {
            Device8003KeypadConfiguration deviceConfiguration = new Device8003KeypadConfiguration();
            deviceConfiguration.SetDefaults();
            deviceConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            deviceConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            deviceConfiguration.AreaIds = new int[0];

            ConfigurationManager.Instance.AddAutoConfigureDeviceConfiguration(deviceConfiguration, "8101Keypad", HardwareType.Pacom8101, physicalDeviceId, configuration);
            if (ConfigurationManager.Instance.DefaultingConfiguration || ConfigurationManager.Instance.GetAreaConfiguration(1) != null)
            {
                deviceConfiguration.AreaIds = new int[1] { 1 };
            }
            else if (ConfigurationManager.Instance.Areas.Count > 0)
            {
                foreach (AreaConfiguration area in ConfigurationManager.Instance.Areas.AsArray)
                {
                    if (area != null && area.Enabled)
                    {
                        deviceConfiguration.AreaIds = new int[1] { area.Id };
                        break;
                    }
                }
            }

            if (ConfigurationManager.Instance.GetAreaConfiguration(deviceConfiguration.AreaId) == null)
            {
                if (deviceConfiguration.AreaIds.Length > 0)
                {
                    deviceConfiguration.AreaId = deviceConfiguration.AreaIds[0];
                }
                else
                {
                    deviceConfiguration.AreaId = 0;
                }
            }
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            createDeviceFeaturesList();
            AreaIds = new int[0];
            Areas = new AreaConfiguration[0];
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            createDeviceFeaturesList();
            if (AreaIds == null)
                AreaIds = new int[0];
        }

        /// <summary>
        /// List of areas that the keypad can arm / disarm
        /// </summary>
        public AreaConfiguration[] Areas { get; set; }

        /// <summary>
        /// Device inputs list - 2 inputs available: Door contact & egress
        /// </summary>
        public InputConfiguration[] Inputs { get; set; }

        /// <summary>
        /// Device Outputs list - 4 outputs available: Green, Red LED, Strike Output(Relay 2) and External Buzzer
        /// </summary>
        public OutputConfiguration[] Outputs { get; set; }

        /// <summary>
        /// Device readers list - 1 available if the device is configured as a card reader
        /// </summary>
        public IReaderConfiguration[] Readers { get; set; }

        /// <summary>
        /// Device doors list - 1 available if the device is configured as a card reader
        /// </summary>
        public DoorConfiguration[] Doors { get; set; }

        /// <summary>
        /// Check if the keypad is configured as a card reader
        /// </summary>
#if TEST8101CARDREADER        
        public bool IsConfiguredAsCardReader
        {
            get { return true; }
        }
#else
        public bool IsConfiguredAsCardReader
        {
            get { return Readers.Length > 0 && Readers[0] != null; }
        }
#endif

        /// <summary>
        /// Keypad contains any of the areas in areaIds list
        /// </summary>
        /// <param name="areaIds">List of area Ids to check against.</param>
        /// <returns>True if at least one of the areaIds id is contained in keypad's AreaIds list.</returns>
        public bool ContainsAnyArea(List<int> areaIds)
        {
            return AreaIds.Intersect(areaIds).Count > 0;
        }

        /// <summary>
        /// Setup device areas list (create new area instances for all areas this device can handle, e.g.: 8101/1061 keypad areas)
        /// </summary>
        public void SetupAreas()
        {
            if (Areas == null || Areas.Length != AreaIds.Length)
                Areas = new AreaConfiguration[AreaIds.Length];
            for (int i = 0; i < AreaIds.Length; i++)
            {
                Areas[i] = ConfigurationManager.Instance.GetAreaConfiguration(AreaIds[i]);
                if (Areas[i] != null)
                {
                    Areas[i].AddKeypad(this);
                }
            }
        }

        /// <summary>
        /// Get Enable strike input for this door on this DC device
        /// </summary>
        /// <param name="doorIdOnDCDevice">Door id on device</param>
        /// <returns>Returns True if strike should be enabled.</returns>
        public bool IsStrikeEnabledForDoor(int doorIdOnDCDevice)
        {
            if (IsConfiguredAsCardReader == false)
                return false;

            return doorIdOnDCDevice != 0 ? false : true;
        }

        /// <summary>
        /// Check if this reader can update the door peripherals - always True
        /// </summary>
        /// <param name="reader">Reader Configuration instance</param>
        /// <returns>True if the reader can update the door peripherals, False otherwise</returns>
        public bool CanReaderUpdateDoorPeripherals(IReaderConfiguration reader)
        {
            return true;
        }

        /// <summary>
        /// Exit count down count in multiples of 1 second. E.g. for ExitDelay1 + ExitDelay2 = 20000 ms -> ExitCountdownCount = 20
        /// </summary>
        public int ExitCountdownCount
        {
            get
            {
                if (Areas == null)
                    return 0;
                int delayMilliseconds = (int)Areas.Max(area => 
                    {
                        return area != null ? area.ExitDelay1 + area.ExitDelay2 : TimeSpan.MinValue;
                    }).TotalMilliseconds;
                if (delayMilliseconds == 0)
                    return 0;
                return delayMilliseconds / 1000;
            }
        }

        /// <summary>
        /// Exit count down count 2 in multiples of 1 second. E.g. for ExitDelay2 = 0 ms -> ExitCountdownCount2 = 0
        /// </summary>
        public int ExitCountdownCount2
        {
            get
            {
                if (Areas == null)
                    return 0;
                int delayMilliseconds = (int)Areas.Max(area => 
                    {
                        return area != null ? area.ExitDelay2 : TimeSpan.MinValue;
                    }).TotalMilliseconds;
                if (delayMilliseconds == 0)
                    return 0;
                return delayMilliseconds / 1000;
            }
        }

        public int InputCount
        {
            get { return OnboardInputsCount; }
        }

        public int OutputCount
        {
            get { return OnboardOutputsCount; }
        }

        public int ReaderCount
        {
            get { return OnboardReadersCount; }
        }

        public int DoorCount
        {
            get { return OnboardDoorsCount; }
        }

        /// <summary>
        /// Check if any of the inputs has a valid configuration
        /// </summary>
        public bool InputsValid
        {
            get { return Inputs.Any(input => input != null); }
        }

        /// <summary>
        /// Check if the one output has a valid configuration
        /// </summary>
        public bool OutputsValid
        {
            get { return Outputs.Any(output => output != null); }
        }

        /// <summary>
        /// Check if 8101 card reader door is configured
        /// </summary>
        public bool DoorsValid
        {
            get { return Doors.Length == 1 && Doors[0] != null; }
        }

        /// <summary>
        /// Check if the 8101 card reader is configured
        /// </summary>
        public bool ReadersValid
        {
            get { return Readers.Length == 1 && Readers[0] != null; }
        }

        /// <summary>
        /// Get the door controller physical address including the controller address which is set to 0.
        /// </summary>
        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        /// <summary>
        /// Create device features list: 2 inputs and 4 outputs
        /// </summary>
        private void createDeviceFeaturesList()
        {
            if (Inputs == null)
                Inputs = new InputConfiguration[OnboardInputsCount];
            if (Outputs == null)
                Outputs = new OutputConfiguration[OnboardOutputsCount];
            if (Readers == null)
                Readers = new IReaderConfiguration[OnboardReadersCount];
            if (Doors == null)
                Doors = new DoorConfiguration[OnboardDoorsCount];
        }
    }
}
