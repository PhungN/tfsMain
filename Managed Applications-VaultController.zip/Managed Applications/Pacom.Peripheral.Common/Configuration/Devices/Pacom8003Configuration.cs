﻿using System;
using System.IO;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom8003Configuration : Device8003Configuration, IDeviceLoopIODevice, 
                                                                          IDeviceLoopDCDevice, 
                                                                          IDeviceLoopExpansionCardHolderDevice
    {
        /// <summary>
        /// List of onboard door input ids: contact, strike and egress. These input ids are 0 based.
        /// </summary>
        public readonly Dictionary<int, List<int>> OnboardDoorInputIds = new Dictionary<int, List<int>>(2)
        {
            // Door 1
            { 0, new List<int>(3)
                          {
                              5, // Contact Input
                              6, // Strike Input
                              7  // Egress Input
                          }
            },
            // Door 2
            { 1, new List<int>(3)
                          {
                              2, // Contact Input
                              3, // Strike Input
                              4  // Egress Input
                          }
            }
        };

        /// <summary>
        /// The physical Id of the local device, it is 0 because the device loop device addresses are between 1 and 128
        /// </summary>
        public const int LocalDeviceAddress = 0;

        public const int OnboardInputsCount = 8;
        public const int OnboardOutputsCount = 8;
        private const int expansionCardCount = 4;
        public const int ExpansionCardInputsCount = 8;
        public const int ExpansionCardOutputsCount = 4;
        public const int OnboardReadersCount = 4;
        public const int OnboardDoorsCount = 2;
        public const int DeviceLoopDevicesCount = 128;

        public Pacom8003Configuration()
        {
            AlarmUserIdMaxLength = 6;
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            validateContactIdHeartbeatInterval();
            GprsDataUsageReportingStartDate = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            createControllerFeaturesList();
        }

        public static int AutoConfigure(List<ConfigurationBase> configuration)
        {
            Device8003Configuration deviceConfiguration = new Device8003Configuration();
            deviceConfiguration.SetDefaults();
            deviceConfiguration.GprsDataUsageReportingStartDate = ConfigurationManager.Instance.ToLocalTime(DateTime.UtcNow);
            deviceConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            deviceConfiguration.AutoConfigureDeviceLoop = true;
            deviceConfiguration.ParentDeviceId = ConfigurationManager.Instance.ControllerConfiguration.Id;
            deviceConfiguration.Name = "8003";
            configuration.Add(deviceConfiguration);

            // Create onboard inputs: IN1 and IN2 only
            for (int i = 0; i < 2; i++)
            {
                InputConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
            }

            // Create readers
            int[] readerIds = new int[OnboardReadersCount];
            bool isUnisonMode = ConfigurationManager.Instance.IsUnisonMode;
            for (int i = 0; i < OnboardReadersCount; i++)
            {
                if (isUnisonMode)
                    readerIds[i] = ReaderUnisonConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
                else
                    readerIds[i] = ReaderConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
            }

            // Create doors
            DoorConfiguration.AutoConfigure(deviceConfiguration, 1, readerIds[0], readerIds[2], configuration);
            DoorConfiguration.AutoConfigure(deviceConfiguration, 2, readerIds[1], readerIds[3], configuration);
            return deviceConfiguration.Id;
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            validateContactIdHeartbeatInterval();
            createControllerFeaturesList();
        }

        /// <summary>
        /// Validate & set Contact Id / SIA heartbeat interval. Only multiples of 1 minute are allowed. 
        /// All values > 0 and smaller than 1 minute will be rounded up to 1 minute. All values > 1 minute
        /// that are not multiples of 1 minute will be truncated to multiples of 1 minute.
        /// </summary>
        private void validateContactIdHeartbeatInterval()
        {
            int heartbeatInterval = (int)ContactIdHeartbeatInterval.TotalSeconds;
            if (heartbeatInterval > 0)
            {
                if (heartbeatInterval < 60)
                    ContactIdHeartbeatInterval = TimeSpan.FromMinutes(1);
                else
                    ContactIdHeartbeatInterval = TimeSpan.FromMinutes((int)ContactIdHeartbeatInterval.TotalMinutes);
            }
        }

        /// <summary>
        /// Create all controller features list, e.g. inputs, outputs, expansion ports, 
        /// readers, doors and devices.
        /// </summary>
        private void createControllerFeaturesList()
        {
            if (ExpansionCards == null)
                ExpansionCards = new ExpansionCardDeviceConfigurationBase[ExpansionCardCount];
            if (OnboardInputs == null)
                OnboardInputs = new InputConfiguration[OnboardInputsCount];
            if (OnboardOutputs == null)
                OnboardOutputs = new OutputConfiguration[OnboardOutputsCount];
            if (OnboardReaders == null)
                OnboardReaders = new IReaderConfiguration[OnboardReadersCount];
            if (OnboardDoors == null)
                OnboardDoors = new DoorConfiguration[OnboardDoorsCount];
            if (ExpansionSlot1Inputs == null)
                ExpansionSlot1Inputs = new InputConfiguration[ExpansionCardInputsCount];
            if (ExpansionSlot1Outputs == null)
                ExpansionSlot1Outputs = new OutputConfiguration[ExpansionCardOutputsCount];
            if (ExpansionSlot2Inputs == null)
                ExpansionSlot2Inputs = new InputConfiguration[ExpansionCardInputsCount];
            if (ExpansionSlot2Outputs == null)
                ExpansionSlot2Outputs = new OutputConfiguration[ExpansionCardOutputsCount];
            if (ExpansionSlot3Inputs == null)
                ExpansionSlot3Inputs = new InputConfiguration[ExpansionCardInputsCount];
            if (ExpansionSlot3Outputs == null)
                ExpansionSlot3Outputs = new OutputConfiguration[ExpansionCardOutputsCount];
            if (ExpansionSlot4Inputs == null)
                ExpansionSlot4Inputs = new InputConfiguration[ExpansionCardInputsCount];
            if (ExpansionSlot4Outputs == null)
                ExpansionSlot4Outputs = new OutputConfiguration[ExpansionCardOutputsCount];
            if (ExpansionSlotPorts == null)
                ExpansionSlotPorts = new Port8003ConfigurationBase[ExpansionCardCount];
            if (DeviceLoopDevices == null)
                DeviceLoopDevices = new DeviceLoopDeviceConfigurationBase[DeviceLoopDevicesCount];
        }

        private void remove(ConfigurationChanges changedItem)
        {
            // ExpansionCards, ExpansionSlotPorts and DeviceLoopDevices are removed in ConfigurationManager
            if (changedItem.ConfigurationType == ConfigurationElementType.Input)
            {
                ConfigurationUtils.Null<InputConfiguration>(changedItem.Id, OnboardInputs);
                ConfigurationUtils.Null<InputConfiguration>(changedItem.Id, ExpansionSlot1Inputs);
                ConfigurationUtils.Null<InputConfiguration>(changedItem.Id, ExpansionSlot2Inputs);
                ConfigurationUtils.Null<InputConfiguration>(changedItem.Id, ExpansionSlot3Inputs);
                ConfigurationUtils.Null<InputConfiguration>(changedItem.Id, ExpansionSlot4Inputs);
            }
            else if (changedItem.ConfigurationType == ConfigurationElementType.Output)
            {
                ConfigurationUtils.Null<OutputConfiguration>(changedItem.Id, OnboardOutputs);
                ConfigurationUtils.Null<OutputConfiguration>(changedItem.Id, ExpansionSlot1Outputs);
                ConfigurationUtils.Null<OutputConfiguration>(changedItem.Id, ExpansionSlot2Outputs);
                ConfigurationUtils.Null<OutputConfiguration>(changedItem.Id, ExpansionSlot3Outputs);
                ConfigurationUtils.Null<OutputConfiguration>(changedItem.Id, ExpansionSlot4Outputs);
            }
            else if (changedItem.ConfigurationType == ConfigurationElementType.Reader)
            {
                ConfigurationUtils.Null<IReaderConfiguration>(changedItem.Id, OnboardReaders);
            }
            else if (changedItem.ConfigurationType == ConfigurationElementType.Door)
            {
                ConfigurationUtils.Null<DoorConfiguration>(changedItem.Id, OnboardDoors);
            }
            else if (changedItem.ConfigurationType == ConfigurationElementType.Port)
            {
                ConfigurationUtils.Null<Port8003ConfigurationBase>(changedItem.Id, ExpansionSlotPorts);
            }
        }

        public void RemoveOldConfigurationItems(List<ConfigurationChanges> changedItems, List<ConfigurationChanges> removedItems)
        {
            foreach (ConfigurationChanges changedItem in changedItems)
            {
                remove(changedItem);
            }
            foreach (ConfigurationChanges removedItem in removedItems)
            {
                remove(removedItem);
            }
        }

        /// <summary>
        /// Get / Set the alarm users maximum ID length
        /// This is currently not set anywhere but is here so that it may
        /// transition into a controller configuration property if required.
        /// </summary>
        public int AlarmUserIdMaxLength { get; set; }

        /// <summary>
        /// Returns number of allocated expansion slots on a device
        /// </summary>
        public int ExpansionCardCount
        {
            get
            {
                return expansionCardCount;
            }
        }

        /// <summary>
        /// Onboard expansion cards - 4 cards supported
        /// </summary>
        public ExpansionCardDeviceConfigurationBase[] ExpansionCards { get; set; }

        /// <summary>
        /// Onboard Inputs array - 8 inputs available
        /// </summary>
        public InputConfiguration[] OnboardInputs { get; set; }

        /// <summary>
        /// Onboard Outputs array - 8 outputs available
        /// </summary>
        public OutputConfiguration[] OnboardOutputs { get; set; }

        /// <summary>
        /// Onboard readers - 4 readers available
        /// </summary>
        public IReaderConfiguration[] OnboardReaders { get; set; }

        /// <summary>
        /// Doors array - 2 doors supported
        /// </summary>
        public DoorConfiguration[] OnboardDoors { get; set; }

        public InputConfiguration[] ExpansionSlot1Inputs { get; set; }

        public OutputConfiguration[] ExpansionSlot1Outputs { get; set; }

        public InputConfiguration[] ExpansionSlot2Inputs { get; set; }

        public OutputConfiguration[] ExpansionSlot2Outputs { get; set; }

        public InputConfiguration[] ExpansionSlot3Inputs { get; set; }

        public OutputConfiguration[] ExpansionSlot3Outputs { get; set; }

        public InputConfiguration[] ExpansionSlot4Inputs { get; set; }

        public OutputConfiguration[] ExpansionSlot4Outputs { get; set; }

        public IPPortConfiguration EthernetPort { get; set; }

        public Port8003RS485PortConfiguration RS485Port { get; set; }

        public Port8003RS232PortConfiguration RS232Port { get; set; }

        public Port8003ConfigurationBase[] ExpansionSlotPorts { get; set; }

        public DeviceLoopDeviceConfigurationBase[] DeviceLoopDevices { get; set; }

        /// <summary>
        /// Check if any of the inputs has a valid configuration
        /// </summary>
        public bool InputsValid
        {
            get { return OnboardInputs.Any(input => input != null); }
        }

        /// <summary>
        /// Check if the one output has a valid configuration
        /// </summary>
        public bool OutputsValid
        {
            get { return OnboardOutputs.Any(output => output != null); }
        }

        /// <summary>
        /// Check if any 8003 readers are configured
        /// </summary>
        public bool ReadersValid
        {
            get { return OnboardReaders.Any(reader => reader != null); }
        }

        /// <summary>
        /// Check if 8003 doors were configured
        /// </summary>
        public bool DoorsValid
        {
            get { return OnboardDoors.Any(door => door != null); }
        }

        /// <summary>
        /// Check if 8003 expansion ports were configured
        /// </summary>
        public int ExpansionPortsValidCount
        {
            get { return ExpansionSlotPorts.Count(port => port != null); }
        }

        /// <summary>
        /// Check if 8003 expansion cards were configured
        /// </summary>
        public bool ExpansionCardsValid
        {
            get { return ExpansionCards.Any(card => card != null && card.CardType != ExpansionCardType.None); }
        }

        /// <summary>
        /// Check if the event queue is enabled
        /// </summary>
        public bool EventQueueEnabled
        {
            get { return EventQueueCapacity > 0; }
        }

        /// <summary>
        /// Get contact physical input id
        /// </summary>
        /// <param name="door">Door Id: Either 0 or 1</param>
        /// <returns>Contact input id</returns>
        public int ContactInputId(int door)
        {
            return OnboardDoorInputIds[door][0];
        }

        /// <summary>
        /// Get contact logical input id
        /// </summary>
        /// <param name="inputId">Physical input id</param>
        /// <returns>Contact logical input id</returns>
        public int LogicalContactInputId(int door)
        {
            int inputId = ContactInputId(door);
            InputConfiguration inputConfig = OnboardInputs[inputId];
            if (inputConfig != null)
                return inputConfig.Id;
            return -1;
        }

        /// <summary>
        /// Get strike physical input id
        /// </summary>
        /// <param name="door">Door Id: Either 0 or 1</param>
        /// <returns>Strike input id</returns>
        public int StrikeInputId(int door)
        {
            return OnboardDoorInputIds[door][1];
        }

        /// <summary>
        /// Get strike logical input id
        /// </summary>
        /// <param name="inputId">Physical input id</param>
        /// <returns>Strike logical input id</returns>
        public int LogicalStrikeInputId(int door)
        {
            int inputId = StrikeInputId(door);
            InputConfiguration inputConfig = OnboardInputs[inputId];
            if (inputConfig != null)
                return inputConfig.Id;
            return -1;
        }

        /// <summary>
        /// Get egress physical input id
        /// </summary>
        /// <param name="door">Door Id: Either 0 or 1</param>
        /// <returns>Egress input id</returns>
        public int EgressInputId(int door)
        {
            return OnboardDoorInputIds[door][2];
        }

        /// <summary>
        /// Get egress logical input id
        /// </summary>
        /// <param name="door">Door Id: Either 0 or 1</param>
        /// <returns>Egress input id</returns>
        public int LogicalEgressInputId(int door)
        {
            int inputId = EgressInputId(door);
            InputConfiguration inputConfig = OnboardInputs[inputId];
            if (inputConfig != null)
                return inputConfig.Id;
            return -1;
        }

        /// <summary>
        /// Checks if this physical input id is one of the door inputs
        /// </summary>
        /// <param name="inputId">Physical input id</param>
        /// <returns>True if this is one of the door inputs, False otherwise</returns>
        public bool IsDoorInputId(int inputId)
        {
            for (int i = 0; i < OnboardDoors.Length; i++)
            {
                if ((OnboardDoors[i] != null) && OnboardDoorInputIds[i].Contains(inputId))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Get the Logical DeviceId from device loop address
        /// </summary>
        /// <param name="deviceLoopAddress">Device Address 0-127</param>
        /// <returns>If successful returns the 1 based device logical id, otherwise -1.</returns>
        public int LogicalDeviceId(int deviceLoopAddress)
        {
            // Check if the controller logical id is required
            if (deviceLoopAddress == -1)
                return Id;
            if ((deviceLoopAddress >= 0 && deviceLoopAddress < DeviceLoopDevicesCount) == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return "DeviceId must be >= 0.";
                });
            }
            if (DeviceLoopDevices[deviceLoopAddress] == null)
                return -1;
            return DeviceLoopDevices[deviceLoopAddress].Id;
        }

        /// <summary>
        /// Get the input logical id from device loop address and input id on door device.
        /// </summary>
        /// <param name="deviceLoopAddress">Device physical address 0-127.</param>
        /// <param name="inputId">Input Id on door device, 0 based.</param>
        /// <returns>If successful returns input logical id, otherwise -1.</returns>
        public int LogicalInputId(int deviceLoopAddress, int inputId)
        {
            if (deviceLoopAddress < 0)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return "DeviceId must be >= 0.";
                });
            }
            if (DeviceLoopDevices[deviceLoopAddress] == null)
                return -1;
            IDeviceLoopIODevice ioDevice = DeviceLoopDevices[deviceLoopAddress] as IDeviceLoopIODevice;
            if (ioDevice == null || inputId < 0 || inputId >= ioDevice.InputCount)
                return -1;
            InputConfiguration inputConfig = ioDevice.Inputs[inputId];
            return (inputConfig != null ? inputConfig.Id : -1);
        }

        /// <summary>
        /// Get any of the on board inputs logical id from physical input id.
        /// </summary>
        /// <param name="inputId">Input Id on controller, 0 based.</param>
        /// <returns>If successful returns input logical id, otherwise -1.</returns>
        public int LogicalInputId(int inputId)
        {
            if (inputId < 0 || inputId >= OnboardInputsCount)
                return -1;
            InputConfiguration inputConfig = OnboardInputs[inputId];
            if (inputConfig == null)
                return -1;
            return inputConfig.Id;
        }

        /// <summary>
        /// Get any of the specified expansion card's inputs logical id from physical input id.
        /// </summary>
        /// <param name="slotNumber">Expansion Card slot number.</param>
        /// <param name="inputId">Input Id on expansion card, 0 based.</param>
        /// <returns>If successful returns input logical id, otherwise -1.</returns>
        public int ExpansionCardLogicalInputId(int slotNumber, int inputId)
        {
            if (ExpansionCards[slotNumber] == null || ExpansionCards[slotNumber].CardType != ExpansionCardType.Pacom8204InputCard)
                return -1;

            if (inputId >= ExpansionCardInputsCount)
                return -1;

            InputConfiguration inputConfig = null;
            if (slotNumber == 0)
                inputConfig = ExpansionSlot1Inputs[inputId];
            else if (slotNumber == 1)
                inputConfig = ExpansionSlot2Inputs[inputId];
            else if (slotNumber == 2)
                inputConfig = ExpansionSlot3Inputs[inputId];
            else if (slotNumber == 3)
                inputConfig = ExpansionSlot4Inputs[inputId];

            if (inputConfig == null)
                return -1;
            return inputConfig.Id;
        }

        /// <summary>
        /// Get card reader logical id from physical card reader id if the reader is
        /// on the 8003 local device DC.
        /// </summary>
        /// <param name="cardReaderId">Card reader physical id on controller, 0..3</param>
        /// <returns>Card reader logical id</returns>
        public int LogicalReaderId(int cardReaderId)
        {
            return OnboardReaders[cardReaderId] != null ? OnboardReaders[cardReaderId].Id : 0;
        }

        /// <summary>
        /// Get card reader logical id from physical device id and card reader id
        /// </summary>
        /// <param name="deviceId">Physical device id, 0..127</param>
        /// <param name="cardReaderId">Card reader id on physical device 0..1</param>
        /// <returns>Card reader logical id</returns>
        public int LogicalReaderId(int deviceId, int cardReaderId)
        {
            if (DeviceLoopDevices[deviceId] == null)
                return 0;
            IDeviceLoopDCDevice dcDevice = DeviceLoopDevices[deviceId] as IDeviceLoopDCDevice;
            if (dcDevice == null || cardReaderId < 0 || cardReaderId >= dcDevice.ReaderCount)
                return 0;
            IReaderConfiguration readerConfig = dcDevice.Readers[cardReaderId];
            return readerConfig != null ? readerConfig.Id : 0;
        }

        /// <summary>
        /// Assign input into the right location in 8501 device Inputs array 
        /// </summary>
        /// <param name="expansionCardSlot">Expansion card slot id: 0 - 3</param>
        /// <param name="outputConfiguration">Input configuration to insert</param>
        public void SetExpansionInput(int expSlot, InputConfiguration inputConfiguration)
        {
            if (expSlot < 0 && expSlot > ExpansionCardCount - 1)
                return;
            InputConfiguration[] expansionSlotInputs = ExpansionSlot1Inputs;
            if (expSlot > 0)
            {
                if (expSlot == 1)
                    expansionSlotInputs = ExpansionSlot2Inputs;
                else if (expSlot == 2)
                    expansionSlotInputs = ExpansionSlot3Inputs;
                else if (expSlot == 3)
                    expansionSlotInputs = ExpansionSlot4Inputs;
            }
            expansionSlotInputs[inputConfiguration.PointNumberOnParent - 1] = inputConfiguration;
        }

        /// <summary>
        /// Assign output into the right location in 8501 device Outputs array 
        /// </summary>
        /// <param name="expansionCardSlot">Expansion card slot id: 0 - 3</param>
        /// <param name="outputConfiguration">Output configuration to insert</param>
        public void SetExpansionOutput(int expSlot, OutputConfiguration outputConfiguration)
        {
            if (expSlot < 0 && expSlot > ExpansionCardCount - 1)
                return;
            OutputConfiguration[] expansionSlotOutputs = ExpansionSlot1Outputs;
            if (expSlot > 0)
            {
                if (expSlot == 1)
                    expansionSlotOutputs = ExpansionSlot2Outputs;
                else if (expSlot == 2)
                    expansionSlotOutputs = ExpansionSlot3Outputs;
                else if (expSlot == 3)
                    expansionSlotOutputs = ExpansionSlot4Outputs;
            }
            expansionSlotOutputs[outputConfiguration.PointNumberOnParent - 1] = outputConfiguration;
        }

        /// <summary>
        /// Check if Expansion Slot port is configured as an RS485 serial connection
        /// </summary>
        /// <param name="slotNumber">Expansion slot port number: 0 or 1</param>
        /// <param name="protocol">Check if the requested protocol is handled by the port configuration</param>
        /// <returns>True if the expansion slot port is configured as RS485, False otherwise.</returns>
        public bool ExpansionSlotPortHasSerialConfiguration(int slotNumber, PortProtocol protocol)
        {
            Port8003RS485PortConfiguration config = ExpansionSlotPorts[slotNumber] as Port8003RS485PortConfiguration;
            return config != null &&  config.PortProtocol == protocol;
        }

        private void createExpansionCard(ExpansionCardType installedExpansionCard, int slot)
        {
            // Create onboard expansion cards if present
            if (ExpansionCards[slot] != null)
                return;

            List<ConfigurationBase> configuration = new List<ConfigurationBase>();

            Pacom8003PhysicalPort port = (slot == 0) ? Pacom8003PhysicalPort.ExpansionSlot1 : Pacom8003PhysicalPort.ExpansionSlot2;
            switch (installedExpansionCard)
            {
                case ExpansionCardType.Pacom8201GprsCard:
                    Pacom8201ExpansionConfiguration.AutoConfigure(slot + 1, Id, configuration);
                    GprsPortConfiguration.AutoConfigure(Id, port, configuration);
                    break;
                case ExpansionCardType.Pacom8209PstnCard:
                    Pacom8209ExpansionConfiguration.AutoConfigure(slot + 1, Id, configuration);
                    DialupPortConfiguration.AutoConfigure(Id, port, configuration);
                    break;
                case ExpansionCardType.Pacom8205SerialCard:
                    Pacom8205ExpansionConfiguration.AutoConfigure(slot + 1, Id, configuration);
                    RS485DeviceLoopPortConfiguration.AutoConfigure(Id, port, configuration);
                    break;
                case ExpansionCardType.Pacom8207StarCouplerCard:
                    Pacom8207ExpansionConfiguration.AutoConfigure(slot + 1, Id, configuration);
                    RS485DeviceLoopPortConfiguration.AutoConfigure(Id, port, configuration);
                    break;
                case ExpansionCardType.Pacom8204InputCard:
                    {
                        var parent = Pacom8204ExpansionConfiguration.AutoConfigure(slot + 1, Id, configuration);
                        // Create expansion card inputs
                        for (int i = 0; i < Pacom8204ExpansionConfiguration.OnboardInputsCount; i++)
                        {
                            InputConfiguration.AutoConfigure(parent, i + 1, configuration);
                        }
                    }
                    break;
                case ExpansionCardType.Pacom8203OutputCard:
                    {
                        var parent = Pacom8203ExpansionConfiguration.AutoConfigure(slot + 1, Id, configuration);
                        // Create expansion card outputs
                        for (int i = 0; i < Pacom8203ExpansionConfiguration.OnboardOutputsCount; i++)
                        {
                            OutputConfiguration.AutoConfigure(parent, i + 1, configuration);
                        }
                    }
                    break;
            }
            ConfigurationManager.Instance.DisableConfiguration(configuration);
            ConfigurationManager.Instance.UpdateConfiguration(configuration, false, ConfigurationManager.SystemUser, true);
        }

        /// <summary>
        /// Get Enable strike input for door 1 or door 2
        /// </summary>
        /// <param name="doorIdOnDCDevice">Door id on door device: 0 or 1</param>
        /// <returns>Returns the value of either the EnableStrikeInputDoor1 or EnableStrikeInputDoor2 flags.</returns>
        public bool IsStrikeEnabledForDoor(int doorIdOnDCDevice)
        {
            if (doorIdOnDCDevice < 0 || doorIdOnDCDevice > 1)
                return false;
            if (doorIdOnDCDevice == 0)
                return EnableStrikeInputDoor1;
            return EnableStrikeInputDoor2;
        }

        /// <summary>
        /// Check if this reader can update the shared door peripherals
        /// </summary>
        /// <param name="logicalReaderId">Logical Reader Id</param>
        /// <returns>True if the reader can update the door peripherals, False otherwise</returns>
        public bool CanReaderUpdateDoorPeripherals(IReaderConfiguration reader)
        {
            if (reader == null)
                return false;

            if (DoorsValid == false)
                return true;

            DoorConfiguration door = reader.Door;
            if (door != null)
                return true;

            IReaderConfiguration otherReader = getOtherReaderConfiguration(reader.PointNumberOnParent);
            if (otherReader == null)
                return true;

            if (otherReader.Door != null)
                return false;

            if (reader.PointNumberOnParent == 1 || reader.PointNumberOnParent == 2)
                return true;
            return false;
        }

        private IReaderConfiguration getOtherReaderConfiguration(int readerPhysicalId)
        {
            int otherReaderId = 0;
            switch (readerPhysicalId)
            {
                case 1: 
                    otherReaderId = 3;
                    break;
                case 2: 
                    otherReaderId = 4;
                    break;
                case 3: 
                    otherReaderId = 1;
                    break;
                case 4: 
                    otherReaderId = 2;
                    break;
            }
            if (otherReaderId == 0)
                return null;

            return Readers[otherReaderId - 1];
        }

        /// <summary>
        /// Get the localized description for one alarm only, e.g.: EventSourceLatchOrIsolateType.Offline
        /// </summary>
        /// <param name="alarmType"></param>
        /// <returns></returns>
        public string GetDeviceAlarmDescription(EventSourceLatchOrIsolateType alarmType)
        {
            switch (alarmType)
            {
                case EventSourceLatchOrIsolateType.Offline: return OfflineEventText;
                case EventSourceLatchOrIsolateType.Tamper: return TamperEventText;
                case EventSourceLatchOrIsolateType.PowerFail: return ACFailEventText;
                case EventSourceLatchOrIsolateType.BatteryFail: return BatteryFailEventText;
                case EventSourceLatchOrIsolateType.BatteryChargerFail: return BatteryChargerFailEventText;
                case EventSourceLatchOrIsolateType.FuseFail: return FuseFailEventText;
                case EventSourceLatchOrIsolateType.InternalBatteryFail: return InternalBatteryFailEventText;
                case EventSourceLatchOrIsolateType.ReportingFail: return OfflineToFrontEndEventText;
                case EventSourceLatchOrIsolateType.TemperatureFail: return TemperatureFailEventText;
                case EventSourceLatchOrIsolateType.SignalFail: return SignalFailEventText;
                case EventSourceLatchOrIsolateType.AreaConfirmedAlarm: return AreaConfirmedAlarmEventText;
                case EventSourceLatchOrIsolateType.DeviceSubstitution: return DeviceSubstitutionEventText;
                case EventSourceLatchOrIsolateType.TooManyInvalidLogonAttempts: return TooManyInvalidLogonAttemptsEventText;
                case EventSourceLatchOrIsolateType.SensorCleanRequired: return SensorCleanRequiredEventText;
                default: return string.Empty;
            }
        }

        /// <summary>
        /// Get the localized description for an input's status, e.g.: ALARM/OPEN/SHORT etc.
        /// </summary>
        /// <param name="alarmType"></param>
        /// <returns></returns>
        public string GetInputStatusDescription(Common.InputStatus status)
        {
            switch (status)
            {
                case Common.InputStatus.Short: return ShortCircuitEventText;
                case Common.InputStatus.Open: return OpenCircuitEventText;
                case Common.InputStatus.Trouble: return TroubleEventText;
                case Common.InputStatus.SelfTestFail: return SelfTestFailEventText;    
                default:
                    string statusText = string.Empty;
                    if (status.ContainsAlarm() == true)
                        statusText += AlarmText + " ";
                    if (status.ContainsMasking() == true)
                        statusText += MaskEventText + " ";
                    if (status.ContainsRangeReduction() == true)
                        statusText += RangeReductionEventText;
                    if (string.IsNullOrEmpty(statusText) == true)
                        return SecureText;
                    return statusText.Trim();
            }
        }

        /// <summary>
        /// Auto-configure controller expansion cards
        /// </summary>
        /// <param name="installedExpansionCards">List of installed expansion cards</param>
        /// <returns>True if a change was made and needs to be written out.</returns>
        public void AutoConfigureExpansionCards(ExpansionCardType[] installedExpansionCards)
        {
            if (AutoConfigureDeviceLoop == false)
                return;

            for (int i = 0; i < ExpansionCardCount;  i++)
            {
                if (ExpansionCards[i] == null && installedExpansionCards[i] != ExpansionCardType.None)
                    createExpansionCard(installedExpansionCards[i], i);
            }
        }

        #region IDeviceLoopDCDevice Members

        public IReaderConfiguration[] Readers
        {
            get { return OnboardReaders; }
            set { OnboardReaders = value; }
        }

        public DoorConfiguration[] Doors
        {
            get { return OnboardDoors; }
            set { OnboardDoors = value; }
        }

        public int ReaderCount
        {
            get { return OnboardReadersCount; }
        }

        public int DoorCount
        {
            get { return OnboardDoorsCount; }
        }

        #endregion

        #region IDeviceLoopIODevice Members

        public InputConfiguration[] Inputs
        {
            get 
            {
                List<InputConfiguration> inputs = new List<InputConfiguration>(
                    OnboardInputs.Length + ExpansionSlot1Inputs.Length + ExpansionSlot2Inputs.Length + ExpansionSlot3Inputs.Length + ExpansionSlot4Inputs.Length);
                inputs.AddRange(OnboardInputs);
                inputs.AddRange(ExpansionSlot1Inputs);
                inputs.AddRange(ExpansionSlot2Inputs);
                inputs.AddRange(ExpansionSlot3Inputs);
                inputs.AddRange(ExpansionSlot4Inputs);
                return inputs.ToArray();
            }
            set { OnboardInputs = value; }
        }

        public OutputConfiguration[] Outputs
        {
            get 
            {
                List<OutputConfiguration> outputs = new List<OutputConfiguration>(
                    OnboardOutputs.Length + ExpansionSlot1Outputs.Length + ExpansionSlot2Outputs.Length + ExpansionSlot3Outputs.Length + ExpansionSlot4Outputs.Length);
                outputs.AddRange(OnboardOutputs);
                outputs.AddRange(ExpansionSlot1Outputs);
                outputs.AddRange(ExpansionSlot2Outputs);
                outputs.AddRange(ExpansionSlot3Outputs);
                outputs.AddRange(ExpansionSlot4Outputs);
                return outputs.ToArray();
            }
            set { OnboardOutputs = value; }
        }

        public int InputCount
        {
            get { return OnboardInputsCount; }
        }

        public int OutputCount
        {
            get { return OnboardOutputsCount; }
        }

        /// <summary>
        /// Get the door controller physical address including the controller address which is set to 0.
        /// </summary>
        public int DeviceAddress 
        {
            get { return LocalDeviceAddress; } 
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        #endregion
    }
}
