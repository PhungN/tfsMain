﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utils;
using Pacom.Core.Contracts;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class Pacom1076DCConfiguration : Device1076DCConfiguration, IDeviceLoopIODevice
                                                                            , IDeviceLoopDCDevice
    {
        public const int OnboardInputsCount = 8;
        public const int OnboardOutputsCount = 4;
        public const int OnboardReadersCount = 2;
        public const int OnboardDoorsCount = 2;

        /// Card Reader A input ids:
        /// <summary>
        /// Pacom1076 door controller contact input id.
        /// </summary>
        public const int CardReaderAContactInputId = 0;

        /// <summary>
        /// Pacom1076 door controller egress input id.
        /// </summary>
        public const int CardReaderAEgressInputId = 1;

        /// <summary>
        /// Pacom1076 door controller strike input id.
        /// </summary>
        public const int CardReaderAStrikeInputId = 2;

        /// <summary>
        /// Pacom1076 door controller spare input id.
        /// </summary>
        public const int CardReaderASpareInputId = 3;

        /// Card Reader B input ids:
        /// <summary>
        /// Pacom1076 door controller contact input id.
        /// </summary>
        public const int CardReaderBContactInputId = 4;

        /// <summary>
        /// Pacom1076 door controller egress input id.
        /// </summary>
        public const int CardReaderBEgressInputId = 5;

        /// <summary>
        /// Pacom1076 door controller strike input id.
        /// </summary>
        public const int CardReaderBStrikeInputId = 6;

        /// <summary>
        /// Pacom1076 door controller spare input id.
        /// </summary>
        public const int CardReaderBSpareInputId = 7;

        public Pacom1076DCConfiguration()
        {
        }

        public static void AutoConfigure(int physicalDeviceId, List<ConfigurationBase> configuration)
        {
            Device1076DCConfiguration deviceConfiguration = new Device1076DCConfiguration();
            ConfigurationManager.Instance.AddAutoConfigureDeviceConfiguration(deviceConfiguration, "1076DC", HardwareType.Pacom1076DoorController, physicalDeviceId, configuration);

            // Create inputs
            for (int i = 0; i < OnboardInputsCount; i++)
            {
                if ((i == CardReaderAStrikeInputId && deviceConfiguration.EnableStrikeInputA == false) || i == CardReaderASpareInputId ||
                    (i == CardReaderBStrikeInputId && deviceConfiguration.EnableStrikeInputB == false) || i == CardReaderBSpareInputId)
                {
                    InputConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
                }
            }

            // Create outputs
            for (int i = 0; i < OnboardOutputsCount; i++)
            {
                OutputConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
            }

            // Create readers
            int[] readerIds = new int[OnboardReadersCount];
            bool isUnisonMode = ConfigurationManager.Instance.IsUnisonMode;
            for (int i = 0; i < OnboardReadersCount; i++)
            {
                if (isUnisonMode)
                    readerIds[i] = ReaderUnisonConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
                else
                    readerIds[i] = ReaderConfiguration.AutoConfigure(deviceConfiguration, i + 1, configuration);
            }

            // Create doors
            DoorConfiguration.AutoConfigure(deviceConfiguration, 1, readerIds[0], readerIds[1], configuration);        
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Device, Id, Name);
                Name = null;
            }
            createDeviceFeaturesList();
        }

        /// <summary>
        /// Get Enable strike input for door A or door B
        /// </summary>
        /// <param name="doorIdOnDCDevice">Door id on door device: 0 or 1</param>
        /// <returns>Returns the value of either the EnableStrikeInputA or EnableStrikeInputB flags.</returns>
        public bool IsStrikeEnabledForDoor(int doorIdOnDCDevice)
        {
            if (doorIdOnDCDevice < 0 || doorIdOnDCDevice > 1)
                return false;
            if (doorIdOnDCDevice == 0)
                return EnableStrikeInputA;
            return EnableStrikeInputB;
        }

        /// <summary>
        /// Check if this reader can update the door peripherals - always returns True
        /// </summary>
        /// <param name="reader">Reader Configuration instance</param>
        /// <returns>True if the reader can update the door peripherals, False otherwise</returns>
        public bool CanReaderUpdateDoorPeripherals(IReaderConfiguration reader)
        {
            return true;
        }

        /// <summary>
        /// Check if 1076 doors were configured
        /// </summary>
        public bool DoorsValid
        {
            get
            {
                if (Doors == null)
                    return false;
                return Doors.Any(door => door != null);
            }
        }

        /// <summary>
        /// Check if any 1076 readers are configured
        /// </summary>
        public bool ReadersValid
        {
            get
            {
                if (Readers == null)
                    return false;
                return Readers.Any(reader => reader != null);
            }
        }

        /// <summary>
        /// Check if any of the inputs has a valid configuration
        /// </summary>
        public bool InputsValid
        {
            get { return Inputs.Any(input => input != null); }
        }

        /// <summary>
        /// Check if the one output has a valid configuration
        /// </summary>
        public bool OutputsValid
        {
            get { return Outputs.Any(output => output != null); }
        }

        /// <summary>
        /// Device inputs list - 4 inputs available
        /// </summary>
        public InputConfiguration[] Inputs { get; set; }

        /// <summary>
        /// Device Outputs list - 4 outputs available 
        /// </summary>
        public OutputConfiguration[] Outputs { get; set; }

        /// <summary>
        /// Onboard readers - 2 readers available
        /// </summary>
        public IReaderConfiguration[] Readers { get; set; }

        /// <summary>
        /// Doors array - 2 doors supported
        /// </summary>
        public DoorConfiguration[] Doors { get; set; }

        public int InputCount
        {
            get { return OnboardInputsCount; }
        }

        public int OutputCount
        {
            get { return OnboardOutputsCount; }
        }

        public int ReaderCount
        {
            get { return OnboardReadersCount; }
        }

        public int DoorCount
        {
            get { return OnboardDoorsCount; }
        }

        /// <summary>
        /// Get the door controller physical address including the controller address which is set to 0.
        /// </summary>
        public int DeviceAddress
        {
            get { return DeviceLoopAddress; }
        }

        /// <summary>
        /// Get device name from repository
        /// </summary>
        /// <returns>Device Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, Id);
        }

        /// <summary>
        /// Create device features list: 2 readers and 2 doors
        /// </summary>
        private void createDeviceFeaturesList()
        {
            if (Inputs == null)
                Inputs = new InputConfiguration[OnboardInputsCount];
            if (Outputs == null)
                Outputs = new OutputConfiguration[OnboardOutputsCount];
            if (Readers == null)
                Readers = new IReaderConfiguration[OnboardReadersCount];
            if (Doors == null)
                Doors = new DoorConfiguration[OnboardDoorsCount];
        }
    }
}
