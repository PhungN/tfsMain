﻿using System;
using System.IO;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class EgressScheduleList : ConfigurationListBase<EgressSchedule>, IConfigurationList
    {
        internal EgressScheduleList() : base() { }

        /// <summary>
        /// Get next egress schedule Id
        /// </summary>
        public int NextScheduleId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
