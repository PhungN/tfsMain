﻿using System;
using System.IO;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class PortConfigurationList : NodeConfigurationListBase<Port8003ConfigurationBase>, IConfigurationList
    {
        internal PortConfigurationList() : base() { }

        /// <summary>
        /// Get next port Id
        /// </summary>
        public int NextPortId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
