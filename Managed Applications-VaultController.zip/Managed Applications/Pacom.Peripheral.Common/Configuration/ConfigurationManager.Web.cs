﻿using System.IO;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Serialization.Formatters.Asn1;
using System;

namespace Pacom.Peripheral.Common.Configuration
{
    public partial class ConfigurationManager
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pathToXmlFile">Save digital receiver template file to controller.</param>
        /// <param name="userAuditInfo">User audit details: user type, user Id.</param>
        /// <returns></returns>
        public bool SaveXmlDigitalReceiverConversionTemplateAsAsn1(string pathToXmlFile, UserAuditInfo userAuditInfo)
        {
            OpenPacomToDigitalReceiverTemplate template = new OpenPacomToDigitalReceiverTemplate();
            OpenPacomToDigitalReceiver8003Template templateBase = null;
            if (template.ImportFromXML(pathToXmlFile, out templateBase) == true)
            {
                try
                {
                    StreamingContext context = new StreamingContext();
                    ITypeLookup typesList = getListOfTypes();
                    Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(typesList, true, context);
                    asn1Serializer.SerializeDefaultValues = true;

                    lock (controllerConfigurationSync)
                    {
                        using (var configChanger = CreateConfigurationChanger(ConfigurationElementsAffected.ConversionTemplates))
                        {
                            int length = 0;
                            ConfigurationManager.MarkConfigurationFileAsModified(FileSystemPaths.OpenPacomToDigitalReceiverTemplateFilePath);
                            using (FileStream fileStream = new FileStream(FileSystemPaths.OpenPacomToDigitalReceiverTemplateFilePath, FileMode.Create, FileAccess.Write, FileShare.None))
                            {
                                asn1Serializer.Serialize(fileStream, templateBase);
                                length = (int)fileStream.Position;
                            }

                            using (FileStream fileStream = new FileStream(FileSystemPaths.OpenPacomToDigitalReceiverTemplateFilePath.Replace(".asn1", ".idx"), FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None))
                            {
                                fileStream.Write(BitConverter.GetBytes(templateBase.Id), 0, 4);
                                fileStream.Write(BitConverter.GetBytes(0), 0, 4);
                                fileStream.Write(BitConverter.GetBytes(length), 0, 4);
                            }
                            Initialize(ConfigurationUpdateReason.FrontEndOrWeb, ConfigurationElementsAffected.ConversionTemplates, userAuditInfo);
                        }
                    }
                    if (InformFrontEndThatConfigurationChanged != null)
                        InformFrontEndThatConfigurationChanged(this, new ChangedConfigurationEventArgs(controllerConfiguration.Id, 
                                                                                                       string.Format("/OpenPacomToDigitalReceiverTemplate/{0}", templateBase.Id), 
                                                                                                       userAuditInfo));

                    return true;
                }
                catch (IOException ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("Digital Receiver Template file saving failed: {0}", ex.ToString());
                    });
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("Digital Receiver Template file saving failed: {0}", ex.ToString());
                    });
                }
            }
            return false;
        }

        public bool SaveDigitalReceiverConversionTemplateAsXml(string pathToXmlFile)
        {
            OpenPacomToDigitalReceiverTemplate template = null;
            if (openPacomToDigitalReceiverTemplates.TryGetValue(OpenPacomToDigitalReceiverTemplate.DigitalReceiverTemplateId, out template) == false)
                return false;

            return template.ExportToXML(FileSystemPaths.DigitalReceiverXmlTemplateUploadFilePath);
        }
    }
}
