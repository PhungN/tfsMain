﻿using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class InputConfigurationList : NodeConfigurationListBase<InputConfiguration>, IConfigurationList
    {
        internal InputConfigurationList() : base() { }

        /// <summary>
        /// Return input configuration referenced by logical id
        /// </summary>
        /// <param name="logicalId">Input logical id, 1 based.</param>
        /// <returns>Input configuration instance or null if not found</returns>
        public override InputConfiguration this[int logicalId]
        {
            set
            {
                if (value != null && value.Enabled == true && Exists(logicalId) == false && EnabledCount >= LicenseManager.Instance.MaximumInputCount)
                {
                    value.Enabled = false;
                    string inputName = ConfigurationStringRepository.RetrieveName(ConfigurationType.Input, value.Id);
                    Logger.LogWarnMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return string.Format("Licensing limit exceeded. The added input {0} will be disabled.", inputName);
                    });
                }
                base[logicalId] = value;
            }
        }

        /// <summary>
        /// Get next input Id
        /// </summary>
        public int NextInputId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
