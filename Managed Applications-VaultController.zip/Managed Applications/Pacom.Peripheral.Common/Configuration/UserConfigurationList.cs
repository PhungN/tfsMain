﻿using System;
using System.Collections.Generic;
using System.IO;
using Pacom.Peripheral.Common.Status;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Core.Contracts;
using Pacom.Core.Access;
using System.Reflection;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public abstract class UserConfigurationList
    {
        /// <summary>
        /// Check if this user has permissions to execute a task. Currently this only checks if the user
        /// is part of the Engineers group or the user is the Front-End User.
        /// </summary>
        /// <param name="userId">User Id to check</param>
        /// <returns>True if this user has permissions</returns>
        public bool HasEngineeringPermissions(int userId)
        {
            if (ConfigurationManager.Instance.ControllerConfiguration.KeypadOperationalMode.IsEN() == false || userId == StatusConsts.FrontEndUser)
                return true;

            IUserConfiguration user = this[userId];
            if (user == null)
                return false;
            return user.IsEngineer;
        }

        /// <summary>
        /// Return configuration object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Logical node id, 1 based</param>
        /// <returns>Node configuration instance or null if not found</returns>
        public abstract IUserConfiguration this[int logicalId]
        {
            get;
        }

        public bool CanIsolate(int userId, int areaId)
        {
            IUserConfiguration user = this[userId];
            if (user != null)
                return user.CanIsolate(areaId);
            return false;
        }

        /// <summary>
        /// Check if access level is valid for user that tries to log in. This is checked only for EN-GRADE4 compiance level
        /// </summary>
        /// <param name="currentAccessLevel"></param>
        /// <param name="groupId"></param>
        /// <returns></returns>
        protected bool isAccessLevelValid(UserAccessLevel currentAccessLevel, int groupId)
        {
            if (ConfigurationManager.Instance.ControllerConfiguration.KeypadOperationalMode.IsEN() == false)
                return true;

            bool engineer = false;
            GroupConfiguration groupConfig = ConfigurationManager.Instance.GetGroupConfiguration(groupId);
            if (groupConfig != null)
                engineer = groupConfig.IsEngineer;
            bool validAccessLevel = ((engineer == true && currentAccessLevel == UserAccessLevel.AccessLevel2) ||
                                     (engineer == false && currentAccessLevel == UserAccessLevel.AccessLevel1));
            return validAccessLevel;
        }

        protected static HashTypeLookup getListOfTypes()
        {
            HashTypeLookup lookup = new HashTypeLookup(new Assembly[0]);
            lookup.AddType(typeof(Pacom.Configuration.ConfigurationCommon.User8003Configuration));
            lookup.AddType(typeof(Pacom.Core.Access.User));
            lookup.AddType(typeof(AreaAccessPrivilege));
            lookup.AddType(typeof(UserAccess));
            return lookup;
        }

        protected static bool isUnisonConfiguration(ConfigurationBaseWithStreamOffsetAndLength[] configuration)
        {
            bool isUnisonMode = true;
            if (configuration.Length > 0 && configuration[0].Configuration is User8003Configuration)
                isUnisonMode = false;
            return isUnisonMode;
        }

        public abstract void RemoveAll();
        public abstract bool Delete(int[] logicalIds, UserAuditInfo userAuditInfo);
        public abstract bool EngineerIsPresent(List<int> keypadAreas);
        public abstract bool Exists(int logicalId);
        public abstract int Count
        {
            get;
        }
        public abstract bool CanUserLogin(int userId, int userPin, UserAccessLevel currentAccessLevel, out int logicalUserId, out bool duress);
        public abstract bool CanUserLogin(int userPin, UserAccessLevel currentAccessLevel, out int logicalUserId, out bool duress);
        public abstract bool DoMultipleUsersHaveTheSamePin(int userPin);
        public abstract void WriteOutConfigurationAndIndexFile(string outputFilePath, string inputFilePath, ConfigurationBaseWithStreamOffsetAndLength[] configuration, bool update);
        public abstract int GetLowestId();
        public abstract int GetNextId(int currentId);
        public abstract int GetPreviousId(int currentId);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userIdentifier">LogicalId or UserId</param>
        /// <returns></returns>
        public abstract IUserConfiguration GetUserConfiguration(int id, UserIdentifier userIdentifier);

    }
}