﻿using System;

namespace Pacom.Peripheral.Common.Configuration
{
    public class ScheduleIntervalDetails
    {
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int Level { get; set; }
        public int Id { get; set; }
        
        public ScheduleIntervalDetails(int id, DateTime startTime, DateTime endTime, int level)
        {
            Id = id;
            StartTime = startTime;
            EndTime = endTime;
            Level = level;
        }

        public override string ToString()
        {
            return string.Format("Id: {0}, StartTime: {1}, EndTime: {2}, Level: {3}",
                Id, StartTime.ToString("HH:mm"), EndTime.ToString("HH:mm"), Level);
        }
    }
}
