﻿using System;

namespace Pacom.Peripheral.Common.Configuration
{
    public class ConfigConsts
    {
        private ConfigConsts() { }

        /// <summary>
        /// The maximum number of supported controller connection tables.
        /// </summary>
        public const int MaxControllerConnectionTables = 2;

        /// <summary>
        /// All available controller connection tables.
        /// </summary>
        public const int AllControllerConnectionTables = -1;

        /// <summary>
        /// The prefix included with encrypted passwords.
        /// </summary>
        public const string EncryptedStringPrefix = "enc:";

        /// <summary>
        /// The length of the prefix included with encrypted passwords.
        /// </summary>
        public const int EncryptedStringPrefixLength = 4;
    }
}
