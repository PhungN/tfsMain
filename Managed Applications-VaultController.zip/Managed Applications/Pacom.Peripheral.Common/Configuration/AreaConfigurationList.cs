﻿using System;
using System.IO;
using System.Collections.Generic;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class AreaConfigurationList : NodeConfigurationListBase<AreaConfiguration>, IConfigurationList
    {
        internal AreaConfigurationList() : base() { }

        /// <summary>
        /// Get next area Id
        /// </summary>
        public int NextAreaId
        {
            get { return nextConfigurationItemId; }
        }
    }
}
