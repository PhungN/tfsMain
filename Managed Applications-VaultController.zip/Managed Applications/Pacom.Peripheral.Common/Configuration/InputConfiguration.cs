﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Utilities;
using System.Collections.Generic;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common.Configuration
{
    /// <summary>
    /// This configuration setting is used to configure the behaviour of the logical inputs on a Controller.
    /// This class will handle both digital and analog inputs
    /// </summary>
    public sealed class InputConfiguration : Input8003Configuration
    {
        public InputConfiguration()
        {
            SecureValue = -1;
        }

        public static void AutoConfigure(DeviceConfigurationBase parentDevice, int pointNumberOnParent, List<ConfigurationBase> configuration)
        {
            Input8003Configuration inputConfiguration = new Input8003Configuration();
            inputConfiguration.SetDefaults();
            inputConfiguration.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            inputConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            inputConfiguration.Id = ConfigurationManager.Instance.NextInputId;
            inputConfiguration.ParentDeviceId = parentDevice.Id;
            inputConfiguration.PointNumberOnParent = pointNumberOnParent;
            if (ConfigurationManager.Instance.DefaultingConfiguration || ConfigurationManager.Instance.GetAreaConfiguration(1) != null)
                inputConfiguration.AreaId = 1;
            else
                inputConfiguration.AreaId = 0;
            inputConfiguration.Name = string.Format("Input {0}:{1}", parentDevice.Name, pointNumberOnParent);
            configuration.Add(inputConfiguration);
        }

        public void InitializeWithDefaults()
        {
            base.SetDefaults();
            base.SetComplianceLevelDefaults(ConfigurationManager.Instance.ControllerConfiguration.ComplianceLevel);
            RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        public void AutoConfigure(DeviceConfigurationBase parentDevice, int pointNumberOnParent)
        {
            InitializeWithDefaults();
            Id = ConfigurationManager.Instance.NextInputId;
            ParentDeviceId = parentDevice.Id;
            PointNumberOnParent = pointNumberOnParent;
            AreaId = 1;
            Area = ConfigurationManager.Instance.GetAreaConfiguration(AreaId);
            if (Area != null)
                Area.AddInput(this);
            string parentDeviceName = ConfigurationStringRepository.RetrieveName(ConfigurationType.Device, parentDevice.Id);
            ConfigurationStringRepository.AddName(ConfigurationType.Input, Id, string.Format("Input {0}:{1}", parentDeviceName, pointNumberOnParent));
        }

        /// <summary>
        /// Do not remove. Called using reflection from ConfigurationManager.
        /// </summary>
        public void InitializeAfterCopy()
        {
            if (Name != null)
            {
                ConfigurationStringRepository.AddName(ConfigurationType.Input, Id, Name);
                Name = null;
            }

            if (SecureValue != -1)
            {
                IsAnalogueInput = false;
            }
            else
            {
                IsAnalogueInput = true;
                AlarmHighValue = 25500;
                SecureValue = 25500;
                ResistorTolerance = (int)InputTolerance.TwentyFive;
                NoTamper = false;
            }
            updateAfterLoad();
        }

        #region Public Properties

        /// <summary>An array of areas the input belongs to.</summary>
        public AreaConfiguration Area { get; set; }

        /// <summary>
        /// The voltage range that the input should stay within in Volts (0 - 10). An event is generated if the input falls out of this range. This value is in millivolts.
        /// </summary>
        public int ExpectedVoltageLowerBound { get; set; }

        /// <summary>
        /// The voltage range that the input should stay within in Volts (0 - 10). An event is generated if the input falls out of this range. This value is in millivolts.
        /// </summary>
        public int ExpectedVoltageUpperBound { get; set; }

        /// <summary>
        /// Check if this input is analogue
        /// </summary>
        public bool IsAnalogueInput
        {
            get;
            set;
        }

        /// <summary>
        /// Get input name from repository
        /// </summary>
        /// <returns>Input Name</returns>
        public string GetName()
        {
            return ConfigurationStringRepository.RetrieveName(ConfigurationType.Input, Id);
        }

        /// <summary>
        /// True if this input point reports at the conclusion of the entry delay or extended entry delay.
        /// For sequentially confirmed alarms (BS 8243:2010) this function returns True only if the entry 
        /// delay timer is active and the area has a valid entry delay.
        /// </summary>
        public static bool IsUnqualifiedAlarmDuringEntryDelay(EntryDelayRunningActionType entryDelayRunningAction, EntryTimerState entryTimerState, bool confirmationTimerRunning, 
                                                              bool areaHasEntryDelay, out bool extendEntryDelay)
        {
            extendEntryDelay = false;
            if (entryDelayRunningAction == EntryDelayRunningActionType.ReportImmediately)
                return false;
            if (entryDelayRunningAction == EntryDelayRunningActionType.StartsEntryDelay)
            {
                return areaHasEntryDelay;
            }
			// If we are here the point is an off-route detector that can extend the entry delay, report at the end of the entry delay or report if a second
            // off-route detector is triggered. This input is BS 8243:2010 compliant.
            if (entryTimerState == EntryTimerState.NotRunning)
                return false;
            extendEntryDelay = entryDelayRunningAction == EntryDelayRunningActionType.ExtendEntryDelayAndReportAtConclusionOfExtendedEntryDelay &&
                               confirmationTimerRunning == false;
            return areaHasEntryDelay;
        }

        /// <summary>
        /// Update any properties that need to be kept in synch because of backwards compatibility caused by new and expanded
        /// properties replacing old ones, e.g.: StartsEntryDelay
        /// </summary>
        private void updateAfterLoad()
        {
            if (TriggersEntryDelay == true && EntryDelayRunningActionType == EntryDelayRunningActionType.ReportImmediately)
            {
                EntryDelayRunningActionType = EntryDelayRunningActionType.StartsEntryDelay;
            }
        }
        #endregion
    }
}
