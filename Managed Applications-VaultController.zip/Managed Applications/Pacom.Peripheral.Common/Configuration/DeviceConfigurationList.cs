﻿using System;
using System.IO;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    public sealed class DeviceConfigurationList : ConfigurationListBase<DeviceConfigurationBase>, IConfigurationList
    {
        internal DeviceConfigurationList() : base() { }

        /// <summary>
        /// 8101 Keypad device Id lower limit
        /// </summary>
        private const int lowKeypadId = 2;

        /// <summary>
        /// 8101 Keypad device Id higher limit
        /// </summary>
        private const int highKeypadId = 8;

        /// <summary>
        /// 8303 Power Supply device Id lower limit
        /// </summary>
        private const int lowPowerSupplyId = 9;

        /// <summary>
        /// 8303 Power Supply device Id higher limit
        /// </summary>
        private const int highPowerSupplyId = 12;

        internal int EnabledKeypadCount
        {
            get { return AsList.Count(device => device.HardwareType == HardwareType.Pacom8101 && device.Enabled == true); }
        }

        private int lastDispensedKeypadId = -1;
        private int lastDispensedPowerSupplyId = -1;

        public override void ResetNextItemId()
        {
            base.ResetNextItemId();
            lastDispensedKeypadId = 0;
            lastDispensedPowerSupplyId = 0;
        }

        /// <summary>
        /// Next available logical device Id, this must be unique for any devices including expansion cards
        /// </summary>
        public int NextDeviceId(HardwareType hardwareType, ExpansionCardConfigurationList expansionCardList)
        {
            lock (ConfigurationManager.ControllerConfigurationSync)
            {
                bool defaultingConfiguration = ConfigurationManager.Instance.DefaultingConfiguration;

                if (hardwareType == HardwareType.Pacom8101 || hardwareType == HardwareType.Pacom8101A)
                {
                    for (int i = lowKeypadId; i <= highKeypadId; i++)
                    {
                        if (lastDispensedKeypadId < i &&
                            (defaultingConfiguration || (configurationItemList.ContainsKey(i) == false && expansionCardList.ExpansionCardList.ContainsKey(i) == false)))
                        {
                            lastDispensedKeypadId = i;
                            return lastDispensedKeypadId;
                        }
                    }
                }
                else if (hardwareType == HardwareType.Pacom8303 || hardwareType == HardwareType.Pacom8308)
                {
                    for (int i = lowPowerSupplyId; i <= highPowerSupplyId; i++)
                    {
                        if (lastDispensedPowerSupplyId < i &&
                            (defaultingConfiguration || (configurationItemList.ContainsKey(i) == false && expansionCardList.ExpansionCardList.ContainsKey(i) == false)))
                        {
                            lastDispensedPowerSupplyId = i;
                            return lastDispensedPowerSupplyId;
                        }
                    }
                }

                int nextId = 13;
                if (defaultingConfiguration == false && configurationItemList.Count > 0)
                    nextId = (configurationItemList.Keys[configurationItemList.Count - 1] + 1);
                if (defaultingConfiguration == false && expansionCardList.Count > 0)
                {
                    int nextExpansionCardId = (expansionCardList.ExpansionCardList.Keys[expansionCardList.Count - 1] + 1);
                    if (nextExpansionCardId > nextId)
                        nextId = nextExpansionCardId;
                }
                nextId = Math.Max(nextId, lastDispensedItemId + 1);
                lastDispensedItemId = nextId;
                return lastDispensedItemId;
            }
        }
    }
}
