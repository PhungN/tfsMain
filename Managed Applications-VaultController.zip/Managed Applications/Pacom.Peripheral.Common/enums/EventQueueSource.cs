﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.EventQueue
{
    public enum EventQueueSource
    {
        None,
        Sram,
        SdCard
    }
}
