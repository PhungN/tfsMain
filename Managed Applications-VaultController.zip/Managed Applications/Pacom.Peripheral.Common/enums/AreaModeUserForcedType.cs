﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum AreaModeUserForcedType
    {
        Normal, 
        UserForced, 
    }
}
