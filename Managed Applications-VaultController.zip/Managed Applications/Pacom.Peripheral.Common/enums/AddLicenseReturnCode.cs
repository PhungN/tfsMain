﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum AddLicenseReturnCode
    {
        Success = 0,
        FailedCodeInvalid = 1,
        FailedCodeIncorrect = 2,
        FailedApplying = 3,
    }
}
