﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum SystemStatusType
    {
        /// <summary>
        /// The device loop is operating as normal. Can accept devices.
        /// </summary>
        NormalOperation,

        /// <summary>
        /// The device loop has been shutdown for the configuration change process.
        /// </summary>
        ConfigurationChanging,

        /// <summary>
        /// The device loop is shutdown just before controller restart.
        /// </summary>
        ControllerRestarting
    }
}
