﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum KeypadKey : byte
    {
        Zero = 0,
        One = 1,
        Two = 2,
        Three = 3,
        Four = 4,
        Five = 5,
        Six = 6,
        Seven = 7,
        Eight = 8,
        Nine = 9,
        Day = 10,           // Disarm
        Night = 11,         // Arm
        Test = 12,          // View / Test
        Enter = 13,         // Carriage Return
        Delete = 14,        // Delete
        Cancel = 15,        // ////
        Function1 = 16,     // F1
        Function2 = 17,     // F2
        Function3 = 18,     // F3
        Function4 = 19,     // F4      
        Escape = 20,        // [x]
        KeyPressed = 0,
        KeyReleased = 0x80,

        // Virtual keys - don't exist in the keypad but used for state transitions
        AutoArmIsolatePointsInAlarm         = 0x81,
        ArmCommitArm                        = 0x82,
        ArmIsolatePointsInAlarm             = 0x83,
        ArmAckAlarms                        = 0x84,
        AutoArmAckAlarms                    = 0x85,
        PermissionError                     = 0x86,
        Retry                               = 0x87,
        RetryAreaNotFound                   = 0x88,
        RetryAreaIdNotFound                 = 0x89,
        RetryAreaAlreadyProcessed           = 0x8A,
        DisarmAckAlarms                     = 0x8B,
        AutoDisarmAckAlarms                 = 0x8C,
        LoggedOnAckAlarms                   = 0x8D,
        AutoDisarmDeisolatePointsInAlarm    = 0x8E,
        DisarmDeisolatePointsInAlarm        = 0x8F,
        PointsInAlarmDeisolated             = 0x90,
        PointsInAlarmIsolated               = 0x91,
        TestModeFailedToEnterTestMode       = 0x92,
        TestModeEnterTestDuration           = 0x93,
        TestModeSelectAreaComplete          = 0x94,
        IsolatePointsInAlarm                = 0x95,
        DateTimeChangeSuccess               = 0x96,
        DateTimeChangeFail                  = 0x97,
        AutoArmAckIsolatedAlarms            = 0x98,
        ArmAckIsolatedAlarms                = 0x99,
        DisplayDeisolatedPoints             = 0x9A,
        PopupMessage                        = 0x9B,
        LogoutPointsInAlarm                 = 0x9C,
        LogoutCancelAlarms                  = 0x9D,
        ArmCommitArmDone                    = 0x9E,
        InvalidSchedule                     = 0x9F,
        InternalStateChange1                = 0xFC,
        InternalStateChange2                = 0xFD,
        InternalStateChange3                = 0xFE,
        AnyKey                              = 0xff,
    }
}
