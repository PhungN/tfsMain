﻿using System;

namespace Pacom.Peripheral.Common.GraphicsKeypad
{
    [Flags]
    public enum DisplayFlags : byte
    {
        Default = 0,

        /// <summary>
        /// The font size can be small = 0, medium = 1, large = 2 or extra large =3. 
        /// Note with the 8105 extra large is not supported.
        /// </summary>
        FontSize0 = 0x01,
        FontSize1 = 0x02,

        /// <summary>
        /// The menu item text is to be place at the left hand side.
        /// </summary>
        LeftJustified = 0x04,

        /// <summary>
        /// The menu item text is to be place at the right hand side.
        /// </summary>
        RightJustified = 0x08,

        /// <summary>
        /// The text field is in UTF-8 format. If it is not set then it is using the Pacom language set.
        /// </summary>
        Unicode = 0x10,

        /// <summary>
        /// More than one menu item can be prechosen (highlighted) and a confirm button 
        /// should be pressed before the list of menu items is returned. 
        /// This uses return code 61 but more than one menu item number is supplied
        /// </summary>
        MultiSelect = 0x20,

        /// <summary>
        /// The user must select the menu item first and then press the confirm button 
        /// before the return code 61 is sent.
        /// </summary>
        Confirm = 0x40,

        /// <summary>
        /// The next byte is for additional flag bits.
        /// </summary>
        AdditionalFlag = 0x80,
    }
}
