﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum FirewallRuleSourceType
    {
        WebServer = 1,
        DeviceLoop = 2,        
        FrontEnd = 3,
        GprsConnectionSlot1 = 4,
        GprsConnectionSlot2 = 5
    }
}
