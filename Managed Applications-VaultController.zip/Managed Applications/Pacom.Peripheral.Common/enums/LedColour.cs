﻿using System;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum LedColour
    {
        NotSet = 0,
        Red = 1,
        Green = 2,
        Amber = 4,
        None = 8,
    }
}
