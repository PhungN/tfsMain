﻿namespace Pacom.Peripheral.Common
{
    public enum ControllerPhysicalPort : int
    {
        Ethernet = 1,
        RS485 = 2,
        ExpansionSlot1 = 3,
        ExpansionSlot2 = 4,
        UsbDevice = 5,
        UsbHost = 6,
        RS232 = 7,
    }
}
