﻿namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// 8003 protocol type and event reporting format
    /// </summary>
    public enum Pacom8003MessageFormat
    {
        /// <summary>Unknown message format</summary>
        None = 0,

        /// <summary>binary ASN.1 message format</summary>
        PacomIs = 1,

        /// <summary>Ademco Contact Id SIA DC-05 message format over PSTN</summary>
        ContactId = 2,

        /// <summary>SIA DC-03 message format over PSTN</summary>
        Sia = 3,

        /// <summary>Sia DC-09 IP Event Reporting, Format = ADM-CID (Ademco Contact Id)</summary>
        ContactIdOverIP = 4,

        /// <summary>Sia DC-09 IP Event Reporting, Format = SIA-DCS (SIA DC-03 format)</summary>
        SiaOverIP = 5,
    }
}
