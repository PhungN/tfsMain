﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum SpiDevice
    {
        DataFlash = 1,
        AdcU29 = 2,
        AdcU20 = 3
    }
}
