﻿namespace Pacom.Peripheral.Common.LcdKeypadStateMachine
{
    public enum ReasonForBeeping
    {
        DelayedEntryPointInAlarm = 1500,
        ExitWarning = 2000,
        TestMode = 2100,
        KeypadUserMessage = 1600,
        OffRoutePointInAlarm = 2500,
        AreaLateToClose = 1200,
        AreaFailToArm = 1000,
        Macro = 1800,
    }
}
