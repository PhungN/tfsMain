﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{
    public enum KeypadBuzzerPriority
    {
        NoBeeping = 0,
        ExitDelay1 = 1,
        ExitDelay2 = 2,
        EntryDelay1 = 3,
        EntryDelay2 = 4,
        OffRoutePointDelay1 = 5,
        OffRoutePointDelay2 = 6,
        Undefined = 255,
    }
}
