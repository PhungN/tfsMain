﻿namespace Pacom.Peripheral.Common
{
    public enum ChangedDoorControllerInput : byte
    {
        DoorContact = 0x01,
        Egress = 0x02,
        Strike = 0x04
    }
}
