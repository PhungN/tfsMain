﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum ConfigurationUpdateReason
    {
        Initial,
        NoConfiguration,
        FrontEndOrWeb,
    }
}
