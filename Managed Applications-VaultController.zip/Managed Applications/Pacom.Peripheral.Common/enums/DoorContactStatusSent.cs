﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum DoorContactStatusSent
    {
        ForcedSecure,
        ForcedAlarm,
        AjarSecure,
        AjarAlarm,
        Unknown
    }
}
