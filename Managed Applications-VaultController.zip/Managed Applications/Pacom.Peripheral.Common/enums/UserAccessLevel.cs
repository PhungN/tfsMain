﻿namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// EN-50131 user access levels. Defines the different levels of access any EN grade I&HAS system can obey.
    /// The 4 levels are defined as:
    ///     - Access Level 1 - User access by any person. Any functions at this level are required to be accessible without any access restrictions.
    ///     - Access Level 2 - User access by any normal operator. Access to functions required at this level will be restricted by using a unique
    ///                        UserID / Pin combination for each user. Level 2 access must not provide access to levels 3 or 4 functions.
    ///     - Access Level 3 - User access by any engineer (e.g. alarm company personnel). Users at this level can change the I&HAS system configuration.
    ///                        Access to functions required at this level will be restricted by using a unique UserID / Pin combination for each user. 
    ///                        Level 3 access must not provide access to level 4 functions.
    ///     - Access Level 4 - User access by the manufacturer of the equipment. Access to functions required at this level will be restricted by using 
    ///                        a unique UserID / Pin combination for each user. Functions available at this level are remote configuration and firmware 
    ///                        download.
    /// </summary>
    public enum UserAccessLevel
    {
        AccessLevel1 = 0,
        AccessLevel2 = 1,
        AccessLevel3 = 2, // Access at this level requires a prior login with a valid AccessLevel2 user
        AccessLevel4 = 3, // Access at this level requires a prior login with a valid AccessLevel2 user followed by a login with a valid AccessLevel3 user.
    }
}
