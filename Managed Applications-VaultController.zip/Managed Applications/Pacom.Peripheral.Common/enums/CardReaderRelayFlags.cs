﻿using System;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum RelaysFlags : byte
    {
        AllRelaysOff = 0x00,
        Gpoa = 0x01,
        Gpob = 0x02,
        Output4A = 0x04,
        Output4B = 0x08,
    }
}
