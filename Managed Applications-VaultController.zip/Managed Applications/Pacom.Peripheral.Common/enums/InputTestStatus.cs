﻿namespace Pacom.Peripheral.Common
{
    public enum InputTestStatus : byte
    {
        Completed,
        Failed,
        Success,
    }
}
