﻿
namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Cellular signal strength
    /// </summary>
    public enum GprsNetworkSignalStrength
    {
        Good,
        OK,
        Poor,
        NoNetwork,
        AutoConfigurationIncomplete
    }
}
