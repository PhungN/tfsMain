﻿
namespace Pacom.Peripheral.Common
{
    public enum GprsNetworkRegistration
    {
        NotRegistered,
        Registered,
        Searching,
        RegistrationDenied,
        Unknown,
        RegisteredRoaming
    }
}
