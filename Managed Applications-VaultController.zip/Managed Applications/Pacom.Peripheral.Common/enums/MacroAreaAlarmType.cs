﻿
namespace Pacom.Peripheral.Macros
{
    /// <summary>
    /// Enumeration used to trigger macro events for areas.
    /// </summary>
    public enum MacroAreaAlarmType
    {
        None,
        AreaAlarmed,
        AreaRestored,
        AreaEntryDelay,
        HasDelayedAutomaticArm,
        DelayedAutomaticArmFailed
    }
}
