﻿using System;

namespace Pacom.Core.Contracts
{
    /// <summary>
    /// The category of the node.
    /// </summary>
    public enum ConfigurationCategory
    {
        /// <summary>No category type set.</summary>
        None = 0,

        /// <summary>Input Object Type</summary>
        Input = 1,

        /// <summary>Output Object Type</summary>
        Output = 2,

        /// <summary>Reader Object Type</summary>
        Reader = 3,

        /// <summary>Input/Output Device Object Type</summary>
        [Obsolete("Please use NodeCategory.Device")]
        IODevice = 4,

        /// <summary>Trigger Object Type</summary>
        Trigger = 5,

        /// <summary>Timer Object Type</summary>
        Timer = 6,

        /// <summary>Door Object Type</summary>
        Door = 7,

        /// <summary>Floor Object Type</summary>
        Floor = 8,

        /// <summary>Egress Object Type</summary>
        Egress = 9,

        /// <summary>Keypad Object Type</summary>
        Keypad = 10,

        /// <summary>Site Object Type</summary>
        Site = 11,

        /// <summary>Controller Object Type</summary>
        [Obsolete("Please use NodeCategory.Device")]
        Controller = 12,

        /// <summary>Macro Object Type</summary>
        Macro = 13,

        /// <summary>Port Object Type</summary>
        Port = 14,

        /// <summary>Area Object Type</summary>
        Area = 15,

        /// <summary>Group Object Type</summary>
        Group = 16,

        /// <summary>User Object Type</summary>
        User = 17,

        /// <summary>CCTV Object Type</summary>
        /// <Remarks>Unused. Please check with Desmond before using this object type.</Remarks>
        Cctv = 18,

        /// <summary>DVR Object Type</summary>
        Dvr = 19,

        /// <summary>Microphone Object Type</summary>
        Microphone = 20,

        /// <summary>Speaker Object Type</summary>
        Speaker = 21,

        /// <summary>Pulse Counter Object Type</summary>
        PulseCounter = 22,

        /// <summary>BMS Device Object Type</summary>
        [Obsolete("Please use NodeCategory.Device")]
        BmsDevice = 23,

        /// <summary>Time Schedule Object Type</summary>
        TimeSchedule = 24,

        /// <summary>Time Zone Object Type</summary>
        TimeZone = 25,

        /// <summary>Elevator Object Type</summary>
        Elevator = 26,

        /// <summary>Door Controller Object Type</summary>
        [Obsolete("Please use NodeCategory.Device")]
        DoorController = 27,

        /// <summary>Vault Object Type</summary>
        Vault = 28,

        /// <summary>Camera Object Type</summary>
        Camera = 29,

        /// <summary>Access Card Object Type</summary>
        Card = 30,

        /// <summary>BaseStation Object Type</summary>
        BaseStation = 31,

        /// <summary>TransIT Object Type</summary>
        [Obsolete("Please use NodeCategory.Device")]
        TransIT = 32,

        /// <summary>Gms Object Type</summary>
        Gms = 33,

        /// <summary>Third Party Device Object Type</summary>
        [Obsolete("Please use NodeCategory.Device")]
        ThirdPartyDevice = 34,

        /// <summary>Power Supply Object Type</summary>
        PowerSupply = 35,

        /// <summary>Elevator Controller Object Type</summary>
        ElevatorController = 36,

        /// <summary>An alarm receiver device.</summary>
        DigitalReceiver = 37,

        /// <summary>External Third Party Applications (e.g. MAS) that communicate via the Protocol Service.</summary>
        ThirdPartyApplication = 38,

        /// <summary>An interface to an application directly through the Protocol Service Application Interface.</summary>
        ApplicationInterface = 39,

        /// <summary>Vault Controller object type.</summary>
        [Obsolete("Please use NodeCategory.Device")]
        VaultController = 40,

        /// <summary>Counter object type.</summary>
        Counter = 41,

        /// <summary>Linecard object type.</summary>
        [Obsolete("Please use NodeCategory.Device")]
        Linecard = 42,

        /// <summary>AreaProfile object type.</summary>
        AreaProfile = 43,

        /// <summary>CardFormat object type.</summary>
        CardFormat = 44,

        /// <summary>CardType object type.</summary>
        CardType = 45,

        /// <summary>AnalogueInput object type.</summary>
        AnalogueInput = 46,

        /// <summary>A local controller alarm user.</summary>
        AlarmUser = 47,

        /// <summary>Calendar object type.</summary>
        Calendar = 48,

        /// <summary>Activation object type.</summary>
        OutputActivation = 49,

        /// <summary>Pacom General Purpose IP (GPIP)</summary>
        [Obsolete("Please use NodeCategory.Device")]
        Gpip = 50,

        /// <summary>Remote Maintenance type.</summary>
        [Obsolete("Please use NodeCategory.Device")]
        RemoteMaintenance = 51,

        /// <summary>BMS Input object type.</summary>
        [Obsolete("Please use NodeCategory.Input")]
        BmsInput = 52,

        /// <summary>BMS Action object type.</summary>
        [Obsolete("Please use NodeCategory.Macro")]
        BmsAction = 53,

        /// <summary>BMS Output object type.</summary>
        [Obsolete("Please use NodeCategory.Output")]
        BmsOutput = 54,

        /// <summary>BMS Macro object type.</summary>
        [Obsolete("Please use NodeCategory.Macro")]
        BmsMacro = 55,

        /// <summary>Presence zone is used for people counting and anti-passback.</summary>
        PresenceZone = 56,

        /// <summary>A door interlock group.</summary>
        Interlock = 57,

        /// <summary>An alarm reporting record.</summary>
        AlarmReport = 58,

        /// <summary>A set of data transmission rule.</summary>
        /// <remarks>Usually applied to a port, but can be applied to the whole controller.</remarks>
        Protocol = 59,

        /// <summary>An alarm reporting settings record.</summary>
        AlarmReportSettings = 63,

        /// <summary>General device object.</summary>
        /// <remarks>Devices can be connected to each other in a tree structure and have other nodes as children.</remarks>
        Device = 100,
    }
}
