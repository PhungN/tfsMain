﻿
namespace Pacom.Peripheral.ExpansionCards
{
    /// <summary>
    /// Pacom Cellular card status LED values 
    /// </summary>
    public enum PacomCellularCardStatusLed
    {
        /// <summary>
        /// Green
        /// </summary>
        Good,
        /// <summary>
        /// Amber
        /// </summary>
        OK,
        /// <summary>
        /// Red
        /// </summary>
        Poor,
        /// <summary>
        /// Flashy Red
        /// </summary>
        NoNetwork,
        /// <summary>
        /// All leds blank
        /// </summary>
        PortNotConfigured
    }
}
