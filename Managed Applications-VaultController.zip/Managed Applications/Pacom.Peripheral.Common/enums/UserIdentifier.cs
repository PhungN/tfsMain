﻿
namespace Pacom.Peripheral.Common.Configuration
{
    public enum UserIdentifier
    {
        LogicalId,
        UserId,
        UserPin
    }
}
