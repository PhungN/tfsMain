﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum LockOrUnlockOperation
    {
        Unlock,
        Lock,
        DeniedStart,
        DeniedFinished,
    }
}
