﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum ConfigurationElementsAffected
    {
        None = 0,
        DeviceLoopDevices = 0x01,
        LocalDevice = 0x02,
        Macros = 0x04,
        Ports = 0x08,
        Schedules = 0x10,
        Users = 0x20,
        ControllerConnectionTable = 0x40,
        Groups = 0x80,
        ConversionTemplates = 0x100,
        /// <summary>RS232 port used either as Debug Port or for communicating wirh Inovonics EchoStream Serial Receiver</summary>
        RS232Port = 0x200,
        /// <summary>Inovonics EchoStream devices configuration has changed, e.g.: Serial Receiver, High-Power Repeaters or One-Way Devices</summary>
        InovonicsDevices = 0x400,
        AccessControl = 0x800, // Doors and/or readers
        All = 0x0FFFFFFF
    }
}
