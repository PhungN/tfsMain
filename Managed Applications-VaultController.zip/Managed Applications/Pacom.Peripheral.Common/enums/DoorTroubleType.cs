﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum DoorTroubleType
    {
        None = 0,
        Contact,
        Strike,
        Spare,
        Egress
    }
}
