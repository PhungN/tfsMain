﻿using System;

namespace Pacom.Peripheral.Common.GraphicsKeypad
{
    [Flags]
    public enum MenuFlags : byte
    {
        /// <summary>
        /// Delete any previous menu items that have already been sent.
        /// This flag would normally only be set on the first menu item message sent
        /// </summary>
        Clear = 0x01,
        /// <summary>
        /// To display the menu now, otherwise it is hidden. 
        /// Menu items are sent with multiple messages. 
        /// Once a message is sent with the “Show” bit then the menu list as a whole must be displayed. 
        /// This flag would normally only be set on the last menu item message sent.
        /// </summary>
        Show = 0x02,
        /// <summary>
        /// To show a cross at the top right corner, which can be pressed. 
        /// This will generate a DEL key press message to be sent to the Controller. 
        /// Note that it is recommended to show the cross at the top right hand side, 
        /// as this is normal to indicate a close button, but its placement is strict.
        /// </summary>
        Exit = 0x04,
        Title = 0x08,
        Selected = 0x10,
        Horizontal = 0x20,
        Drop = 0x40,
        SubMenu = 0x80,

        Default = Show | Exit,
    }
}
