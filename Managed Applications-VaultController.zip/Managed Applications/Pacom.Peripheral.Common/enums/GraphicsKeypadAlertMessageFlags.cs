﻿using System;

namespace Pacom.Peripheral.Common.GraphicsKeypad
{
    [Flags]
    public enum AlertMessageFlags : byte
    {
        /// <summary>
        /// The font size can be 
        /// small = 0, 
        /// medium = 1, 
        /// large = 2 or 
        /// extra large =3. 
        /// Note with the 8105 extra large is not supported.
        /// </summary>
        FontSize0 = 0x01,
        FontSize1 = 0x02,

        /// <summary>
        /// Set to 0 for normal size. 
        /// Set to 1 for double size. 
        /// Set to 2 for triple size (not supported on 8105). 
        /// Set to 4 for quadruple size.
        /// </summary>
        IconSizeLow = 0x04,
        IconSizeHigh = 0x80,

        /// <summary>
        /// Flashes the image.
        /// </summary>
        Flash = 0x10,

        /// <summary>
        /// Sound buzzer
        /// </summary>
        Beep = 0x20,

        Defaut = Flash | FontSize0 | IconSizeLow,
    }
}
