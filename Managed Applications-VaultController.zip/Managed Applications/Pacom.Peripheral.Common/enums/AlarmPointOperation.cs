﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum AlarmPointOperation
    {
        None = 0,
        Add,
        AddToUnqualified,
        Remove,
    }
}
