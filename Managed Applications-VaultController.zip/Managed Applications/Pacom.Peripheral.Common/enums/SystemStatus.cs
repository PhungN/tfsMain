﻿using System;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum SystemStatus
    {
        OnlineToFrontEnd = 0,               // Solid green on the status LED
        FirmwareUpdateInProgress = 0x1,     // Blinking green on the status LED
        Booting = 0x2,                      // Solid orange on the status LED
        OfflineToFrontEnd = 0x04,           // Blinking orange on the status LED
        HardwareError = 0x08,               // Solid red on the status LED
        Terminating = 0x10,                 // All LEDs off.
        PartiallyOfflineToFrontEnd = 0x20,  // Dual reporting with one connection table online while the other is offline. Blinking between green and orange
        LoadingUsbFlashDriveTemplate = 0x40,       // Loading a template file from a USB flash drive
        LoadingUsbFlashDriveTemplateOk = 0x80,     // Template loading done, all OK
        LoadingUsbFlashDriveTemplateError = 0x100  // Template loading done, an error occurred
    }
}
