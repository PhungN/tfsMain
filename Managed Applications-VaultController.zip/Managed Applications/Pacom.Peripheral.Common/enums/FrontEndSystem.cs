﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Supported front-end systems enumeration.
    /// </summary>
    public enum FrontEndSystem
    {
        System1 = 0,
        System2 = 1,
        System3 = 2,
        System4 = 3,
        System5 = 4,
        System6 = 5,
        System7 = 6,
        System8 = 7
    }
}
