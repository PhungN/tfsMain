﻿namespace Pacom.Peripheral.Common
{
    public enum PowerSupplyMonitoredInputType
    {
        UnknownInput = -1,
        BatteryVoltage = 0,
        InputVoltage = 1,
        Temperature = 2
    }
}
