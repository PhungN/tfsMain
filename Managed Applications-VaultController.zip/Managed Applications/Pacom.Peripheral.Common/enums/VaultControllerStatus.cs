﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum VaultControllerInputType
    {
        SeismicDetector=0,
        SolenoidSensor=1,
        DoorContact=2,
        LockSensor=3,
        EmergencyStop=4,
        Interlock=5,
        DisplayTamper=6,
        Unknown,
    }

    [Flags]
    public enum VaultOpenStatus
    {
        Close           = 0,
        WaitState       = 1 << 0,
        PreOpenState    = 1 << 1,
        Opened            = 1 << 2,
        Alarm           = 1 << 3,
        Hasten          = 1 << 4,

        //WaitState,
        //AccessState,
        //PreOpenState,
        //PreAlarmHastenState,
    }

    [System.Flags]
    public enum VaultStatusFlags
    {
        WO = 0x01,
        WT = 0x02,
        IL = 0x04,
        WD = 0x08,
        VA = 0x10,
        PA = 0x20,
        AL = 0x40,
    }

    [Flags]
    public enum VaultStatus
    {
        Secure      = 0,
        Alarm       = 1 << 0,
        Online      = 1 << 1,
        Offline     = 1 << 2,
        Aborted     = 1 << 3,
        Unlocked    = 1 << 4,
        TestPass    = 1 << 5,
        TestFail    = 1 << 6,
        OpenRequest = 1 << 7,
        Open        = 1 << 8,
        Unlock      = 1 << 9,
        Locked      = 1 << 10,
        Close       = 1 << 11,
        Interlock   = 1 << 12,
        NotExist    = 1 << 13,
        Openning    = 1 << 14,
        Hasten      = 1 << 15,
    }

    [Flags]
    public enum VaultInputFlags
    {
        Secure = 0,
        SeismicDetectorAlarm = 0x01,
        SolenoidSensorAlarm = 0x02,
        DoorContactAlarm = 0x04,
        LockSensorAlarm = 0x08,
        EmergencyStopAlarm = 0x10,
        InterlockAlarm = 0x20,
        DisplayTamperAlarm = 0x40,
    }

    [Flags]
    public enum VaultOutput
    {
        SeismicTest = 0x01,    // Seismic Test Output
        DoorLock = 0x02,       // Vault Door Lock Output
        Interlock = 0x04,      // Interlock Output
        Sounder = 0x08,        // Sounder Output
    }
    public enum VaultDisplayType
    {
        SC4DlintDisplay = 0,
        SLED_C4Display = 1
    }

}
