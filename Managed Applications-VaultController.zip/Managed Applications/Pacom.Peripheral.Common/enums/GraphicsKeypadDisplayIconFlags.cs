﻿using System;

namespace Pacom.Peripheral.Common.GraphicsKeypad
{
    [Flags]
    public enum DisplayIconFlags : byte
    {
        /// <summary>
        /// Delete any previous menu items that have already been sent. 
        /// This flag would normally only be set on the first menu item message sent.
        /// </summary>
        Clear = 0x01,

        /// <summary>
        /// To display the icon page now, otherwise it is hidden. 
        /// Icon items are sent with multiple messages. 
        /// Once a message is sent with the “Show” bit then the icon page list as a whole must be displayed. 
        /// This flag would normally only be set on the last icon item message sent.
        /// </summary>
        Show = 0x02,

        /// <summary>
        /// The text is shown above the graphical instead of below.
        /// </summary>
        Top = 0x04,
    }
}
