﻿using System;

namespace Pacom.Peripheral.Common
{

    /// <summary>
    /// PSTN 8209 modem status LED.
    /// </summary>
    public enum PstnModemConnectionStatus
    {
        ConnectionEstablished,    // Green
        DialupFailed,             // Flashing red
        Dialing,                  // Red
        NoDialupActivity,         // All leds off
    }
}
