﻿
namespace Pacom.Peripheral.Common
{
    public enum ConfigurationType : int
    {
        Area = 0,
        Device = 1,
        Door = 2,
        Group = 3,
        Macro = 4,
        Input = 5,
        Output = 6,
        PresenceZone = 7,
        Reader = 8,
        User = 9,
        Port = 11,
        InterlockGroup = 12,
        Elevator = 13,
        ElevatorFloor = 14,
        AperioDriver = 15,
        VaultController = 16,
        VaultControllerInterlockGroup = 17,
    }
}
