﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum IOExpanderDevice
    {
        IOExpanderU30 = 0x27,
        IOExpanderU34 = 0x25
    }
}
