﻿namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Inovonics Serial Receiver message types enum
    /// </summary>
    public enum InovonicsMessageType : int
    {
        /// <summary>Invalid message</summary>
        UnknownMessage = 0x00,
        /// <summary>Data acknowledgement - sent by the controller to the Serial Receiver, not required</summary>
        DataAcknowledgementMessage = 0x10,
        /// <summary>Supervisory Message - sent by the Serial Receiver</summary>
        SupervisoryMessage = 0x11,
        /// <summary>No Hop Message - sent by any One-Way Transmitters (the device that received the message first is not reported)</summary>
        NoHopMessage = 0x12,
        /// <summary>Extended Message - sent by any One-Way Transmitters / High-Power Repeaters (the device that received the message first is also reported)</summary>
        ExtendedMessage = 0x13,
        /// <summary>Extended Supervisory Message - sent by the Serial Receiver</summary>
        ExtendedSupervisoryMessage = 0x1C,
#if INOVONICSTEMPERATUREDEMO
        /// <summary>Sent by temperature Transmitters
        TemperatureAndHumidityAnalogDataMessage = 0x72,
#endif
    }
}
