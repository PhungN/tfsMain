﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum ReaderModeForcedType
    {
        Normal, 
        UserForced, 
    }
}
