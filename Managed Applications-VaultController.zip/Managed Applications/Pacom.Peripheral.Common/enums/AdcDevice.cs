﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum AdcDevice
    {
        AdcU29 = 2,
        AdcU20 = 3
    }
}
