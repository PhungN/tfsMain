﻿using System;

namespace Pacom.Peripheral.Common.GraphicsKeypad
{
    public enum BitmapId
    {
        NoBitmap = 0,
        Alarm = 1,
        Alert = 2,
        ClockImg = 3,
        ChainImg = 4,
        LockImg = 5,
        UnlockImg = 6,
        OpenImg = 7,
        Safe = 8,
        SafeOpen = 9,
        MonoAlert = 10,
        MonoClock = 11,
        MonoChain = 12,
        MonoLock = 13,
        MonoUnlock = 14,
        MonoOpen = 15
    }
}
