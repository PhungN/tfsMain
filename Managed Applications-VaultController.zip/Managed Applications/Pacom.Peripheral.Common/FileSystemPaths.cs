﻿using System;
using System.IO;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.SQLCE;

namespace Pacom.Peripheral.Common
{
    public class FileSystemPaths
    {
        public const string ConfigurationDirectory = "\\RestrictedRegion\\Configuration\\";
        public const string BackupConfigurationDirectory = "\\PublicRegion\\BackupConfiguration\\";

        public const string LogsDirectory = "\\PublicRegion\\Logs";
        public const string KeypadBitmapDirectory = "\\PublicRegion\\Bitmaps";
        public const string KeypadBitmapFile = "\\PublicRegion\\keypadBitmaps.7z";

        public const string ShutDownLogPath = "\\RestrictedRegion\\Logs";
        public const string ShutDownLogFilePath = ShutDownLogPath + "\\shutdown.log";

        public const string AreasConfigFilePath = FileSystemPaths.ConfigurationDirectory + "areas.asn1";
        public const string DevicesConfigFilePath = FileSystemPaths.ConfigurationDirectory + "devices.asn1";
        public const string DoorsConfigFilePath = FileSystemPaths.ConfigurationDirectory + "doors.asn1";
        public const string InterlockGroupsConfigFilePath = FileSystemPaths.ConfigurationDirectory + "interlockgroups.asn1";
        public const string VaultControllerInterlockGroupsConfigFilePath = FileSystemPaths.ConfigurationDirectory + "vaultControllerInterlockgroups.asn1";
        public const string InputsConfigFilePath = FileSystemPaths.ConfigurationDirectory + "inputs.asn1";
        public const string MacrosConfigFilePath = FileSystemPaths.ConfigurationDirectory + "macros.asn1";
        public const string OutputsConfigFilePath = FileSystemPaths.ConfigurationDirectory + "outputs.asn1";
        public const string ElevatorsConfigFilePath = FileSystemPaths.ConfigurationDirectory + "elevators.asn1";
        public const string ElevatorFloorsConfigFilePath = FileSystemPaths.ConfigurationDirectory + "elevatorFloors.asn1";
        public const string PortsConfigFilePath = FileSystemPaths.ConfigurationDirectory + "ports.asn1";
        public const string ReadersConfigFilePath = FileSystemPaths.ConfigurationDirectory + "readers.asn1";
        public const string PresenceZonesConfigFilePath = FileSystemPaths.ConfigurationDirectory + "presencezones.asn1";
        public const string SchedulesConfigFilePath = FileSystemPaths.ConfigurationDirectory + "schedules.asn1";
        public const string LegacyAccessSchedulesConfigFilePath = FileSystemPaths.ConfigurationDirectory + "accessschedules.asn1";
        public const string UsersConfigFilePath = FileSystemPaths.ConfigurationDirectory + "users.asn1";
        public const string CalendarsConfigFilePath = FileSystemPaths.ConfigurationDirectory + "calendars.asn1";
        public const string VaultControllerConfigFilePath = FileSystemPaths.ConfigurationDirectory + "vaultController.asn1";
        public const string CardProfilesConfigFilePath = FileSystemPaths.ConfigurationDirectory + "cardprofiles.asn1";
        public const string UserAccessGroupsConfigFilePath = FileSystemPaths.ConfigurationDirectory + "useraccessgroups.asn1";
        public const string ConnectionsConfigFilePath = FileSystemPaths.ConfigurationDirectory + "connections.asn1";
        public const string AccessGroupsConfigFilePath = FileSystemPaths.ConfigurationDirectory + "accessgroups.asn1";
        public const string OpenPacomToDigitalReceiverTemplateFilePath = FileSystemPaths.ConfigurationDirectory + "openpacomtodigitalreceivertemplate.asn1";

        public const string OnboardRS485DeviceLoopEncryptionKeysFilePath = FileSystemPaths.ConfigurationDirectory + "Onboard485Keys.bin";
        public const string ExpansionCard1RS485DeviceLoopEncryptionKeysFilePath = FileSystemPaths.ConfigurationDirectory + "Exp1485Keys.bin";
        public const string ExpansionCard2RS485DeviceLoopEncryptionKeysFilePath = FileSystemPaths.ConfigurationDirectory + "Exp2485Keys.bin";
        public const string DeviceLoopMasterKeysFilePath = FileSystemPaths.ConfigurationDirectory + "masterKeys.bin";
        public const string PeerToPeerMasterKeysFilePath = FileSystemPaths.ConfigurationDirectory + "p2pKeys.bin";
        public const string PeerToPeerMasterKeyFilePath = FileSystemPaths.ConfigurationDirectory + "p2pSlaveKey.bin";
        public const string PresenceZoneStatusFilePath = FileSystemPaths.ConfigurationDirectory + "userArea{0}.bin";

        public const string UnacknowledgedAlarmsQueuePath = "\\RestrictedRegion\\UnacknowledgedAlarmsQueue";
        public const string SDCardScanInProgressPath = "\\RestrictedRegion\\SDCardScanInProgress";

        public const string DataTransferPath = "\\RestrictedRegion\\Dtp\\";
        public const string SDCardDataTransferPath = "\\SDRegion\\Dtp\\";

        private const string usbFlashDriveDownloadFileName = "usbFlashDownload.asn1";
        private const string webTemplateDownloadFileName = "webTemplateDownload.asn1";
        private const string webTemplateUploadFileName = "webTemplateUpload.asn1";
        public const string tempAsn1ConfigFileName = "temp.asn1";
        public const string dataTransferDownloadFileName = "download.dtp";
        public const string dataTransferUploadFileName = "upload.dtp";
        public const string webConfigurationFileName = "web.asn1";
        public const string localChangeFileName = "localChange.asn1";
        public const string digitalReceiverXmlTemplateDownloadFileName = "digitalReceiverTemplateDownload.xml";
        public const string digitalReceiverXmlTemplateUploadFileName = "digitalReceiverTemplateUpload.xml";

        private const string firmwareDownloadPath = "\\RestrictedRegion\\Download";
        private const string firmwareExtractPath = "\\RestrictedRegion\\Download\\Extract";
        private const string sdCardFirmwareDownloadPath = "\\SDRegion\\Download";
        private const string sdCardFirmwareExtractPath = "\\SDRegion\\Download\\Extract";

        private static bool isFct = false;
        public static bool IsFct
        {
            set
            {
                isFct = value;
            }
        }

        private static string getNandOrSDFilePath(string fileName)
        {
            if (isFct)
                return string.Format("{0}{1}", DataTransferPath, fileName);
            if (SqlCeDatabase.Instance.DefaultDatabaseIsValid == true)
                return string.Format("{0}{1}", SDCardDataTransferPath, fileName);
            return string.Format("{0}{1}", DataTransferPath, fileName);
        }

        public const string DatabaseFilename = "\\SDRegion\\controller.sdf";
        public static string UsbFlashDriveDownloadFilePath { get { return getNandOrSDFilePath(usbFlashDriveDownloadFileName); } }
        public static string WebTemplateDownloadFilePath { get { return getNandOrSDFilePath(webTemplateDownloadFileName); } }
        public static string WebTemplateUploadFilePath { get { return getNandOrSDFilePath(webTemplateUploadFileName); } }
        public static string TempAsn1ConfigFilePath { get { return getNandOrSDFilePath(tempAsn1ConfigFileName); } }
        public static string DataTransferDownloadFilePath { get { return getNandOrSDFilePath(dataTransferDownloadFileName); } }
        public static string DataTransferUploadFilePath { get { return getNandOrSDFilePath(dataTransferUploadFileName); } }
        public static string WebConfigurationFilePath { get { return getNandOrSDFilePath(webConfigurationFileName); } }
        public static string LocalChangeFilePath { get { return getNandOrSDFilePath(localChangeFileName); } }
        public static string DigitalReceiverXmlTemplateDownloadFilePath { get { return getNandOrSDFilePath(digitalReceiverXmlTemplateDownloadFileName); } }
        public static string DigitalReceiverXmlTemplateUploadFilePath { get { return getNandOrSDFilePath(digitalReceiverXmlTemplateUploadFileName); } }

        public static string FirmwareDownloadPath
        {
            get
            {
                if (SqlCeDatabase.Instance.DefaultDatabaseIsValid == true)
                    return sdCardFirmwareDownloadPath;
                return firmwareDownloadPath;
            }
        }

        public static string FirmwareExtractPath
        {
            get
            {
                if (SqlCeDatabase.Instance.DefaultDatabaseIsValid == true)
                    return sdCardFirmwareExtractPath;
                return firmwareExtractPath;
            }
        }

        public static void DeleteFrontEndConfiguration(bool includeGroupConfiguration)
        {
            try
            {
                ConfigurationManager.MarkAllConfigurationFilesAsModified();
                File.Delete(FileSystemPaths.AreasConfigFilePath);
                File.Delete(FileSystemPaths.DevicesConfigFilePath);
                File.Delete(FileSystemPaths.DoorsConfigFilePath);
                File.Delete(FileSystemPaths.InterlockGroupsConfigFilePath);
                File.Delete(FileSystemPaths.VaultControllerInterlockGroupsConfigFilePath);
                File.Delete(FileSystemPaths.InputsConfigFilePath);
                File.Delete(FileSystemPaths.MacrosConfigFilePath);
                File.Delete(FileSystemPaths.OutputsConfigFilePath);
                File.Delete(FileSystemPaths.ElevatorsConfigFilePath);
                File.Delete(FileSystemPaths.ElevatorFloorsConfigFilePath);
                File.Delete(FileSystemPaths.PortsConfigFilePath);
                File.Delete(FileSystemPaths.ReadersConfigFilePath);
                File.Delete(FileSystemPaths.PresenceZonesConfigFilePath);
                File.Delete(FileSystemPaths.SchedulesConfigFilePath);
                File.Delete(FileSystemPaths.UsersConfigFilePath);
                File.Delete(FileSystemPaths.CalendarsConfigFilePath);
                File.Delete(FileSystemPaths.CardProfilesConfigFilePath);
                File.Delete(FileSystemPaths.ConnectionsConfigFilePath);
                File.Delete(FileSystemPaths.OpenPacomToDigitalReceiverTemplateFilePath);
                File.Delete(FileSystemPaths.UserAccessGroupsConfigFilePath);

                File.Delete(FileSystemPaths.AreasConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.DevicesConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.DoorsConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.InterlockGroupsConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.VaultControllerInterlockGroupsConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.InputsConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.MacrosConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.OutputsConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.ElevatorsConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.ElevatorFloorsConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.PortsConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.ReadersConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.PresenceZonesConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.SchedulesConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.UsersConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.CalendarsConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.CardProfilesConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.ConnectionsConfigFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.OpenPacomToDigitalReceiverTemplateFilePath.Replace(".asn1", ".idx"));
                File.Delete(FileSystemPaths.UserAccessGroupsConfigFilePath.Replace(".asn1", ".idx"));

                if (includeGroupConfiguration)
                {
                    File.Delete(FileSystemPaths.AccessGroupsConfigFilePath);
                    File.Delete(FileSystemPaths.AccessGroupsConfigFilePath.Replace(".asn1", ".idx"));
                }
            }
            catch
            {
            }
        }
    }
}