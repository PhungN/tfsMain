﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Common.Configuration;

// Example Wiegand 26bit card..
// Wiegand Generator: Bits 1-26 = 10001010000101101101000011 (Parity, Facility * 8, Code * 16, Parity)
//                         Card = 2316751040 (8a16d0c0)
// byte[] array of this when scanned is { 0x8a, 0x16, 0xd0, 0xc0 }
// CardScanProcessor.toString(BitArray card) => "26:10 0010 1000 0101 1011 0100 0011" (with card[0] being the leftmost (MSB) bit, what the user would call "bit 1"

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Process a card scan, passing it onto AccessControlManager if it matches a card profile for the reader
    /// </summary>
    public class CardScanProcessor : IDisposable
    {
        /// <summary>
        /// Definition of the Wiegand 26-bit card format that we use as a default fallback
        /// </summary>
        private static readonly LegacyCardFormat wiegand26 = new LegacyCardFormat
                                                             {
                                                                 NumberOfBits = 26,
                                                                 ReverseCardBits = false,
                                                                 InvertCardBits = false,
                                                                 FacilityOffset = 2,
                                                                 FacilityLength = 8,
                                                                 IssueOffset = 0,
                                                                 IssueLength = 0,
                                                                 CodeOffset = 10,
                                                                 CodeLength = 16,
                                                                 ParityConfiguration = new[]
                                                                                       {
                                                                                           new LegacyCardParity { Offset = 1, Mask = 0x00001ffe, ParityType = CardParity.Even },
                                                                                           new LegacyCardParity { Offset = 26, Mask = 0x1ffe000, ParityType = CardParity.Odd }
                                                                                       }
                                                             };

        /// <summary>
        /// A keypads to manage PIN key presses, indexed by reader ID
        /// </summary>
        private readonly Dictionary<int, CardScanProcessorPinEntryKeypad> keypads = new Dictionary<int, CardScanProcessorPinEntryKeypad>();

        #region Instance, IDisposable, and Access Control Manager

        /// <summary>
        /// The access control manager to tell about card swipes and PIN entries
        /// </summary>
        public IAccessControlManager accessControlManager { get; private set; }

        public void SetAccessControlManager(IAccessControlManager manager)
        {
            accessControlManager = manager;
        }

        public void Dispose()
        {
            removeKeypads();
            ConfigurationManager.Instance.ConfigurationChanged -= configurationChanged;
            instance = null;
        }

        private static CardScanProcessor instance = null;

        public static CardScanProcessor CreateInstance()
        {
            if (instance == null)
            {
                instance = new CardScanProcessor();
            }
            return instance;
        }

        public static CardScanProcessor Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.CardScanProcessor, () => "CardScanProcessor instance must be created before usage. Call CreateInstance() method before using this property.");
                }
#endif
                return instance;
            }
        }

        public CardScanProcessor()
        {
            ConfigurationManager.Instance.ConfigurationChanged += configurationChanged;
            configurationChanged(null, null);
        }

        #endregion

        /// <summary>
        /// Configuration has changed
        /// </summary>
        private void configurationChanged(object sender, ConfigurationChangeEventArgs e)
        {
            int keypadInactivityTimer = (int)ConfigurationManager.Instance.ControllerConfiguration.ReaderInactivityTimeout.TotalSeconds;
            if (keypadInactivityTimer < 1 || keypadInactivityTimer > 15)
            {
                keypadInactivityTimer = 15;
            }

            int pinLength = ConfigurationManager.Instance.ControllerConfiguration.ReaderNumberOfPinDigits;
            if (pinLength < 1 || pinLength > 8)
            {
                pinLength = 8;
            }

            // Create a keypad for each reader
            removeKeypads();
            foreach (IReaderConfiguration reader in ConfigurationManager.Instance.Readers)
            {
                if (reader.Enabled == false)
                {
                    continue;
                }
                keypads[reader.Id] = new CardScanProcessorPinEntryKeypad(reader.Id, pinLength, keypadInactivityTimer, ProcessPinData);
            }
        }

        /// <summary>
        /// Callback, e.g. from CardScanProcessorKeypad, when a PIN has been entered
        /// </summary>
        public void ProcessPinData(int logicalReaderId, byte[] keys)
        {
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.CardScanProcessor, DebugLoggingSubCategory.AccessControl,
                                   () => string.Format("Reader Id {0} keypad keys: {1}:{2}",
                                                       logicalReaderId,
                                                       keys.Length,
                                                       BitConverter.ToString(keys)));
#else
            Logger.LogDebugMessage(LoggerClassPrefixes.CardScanProcessor, DebugLoggingSubCategory.AccessControl,
                                   () => string.Format("Reader Id {0} keypad keys: {1}", logicalReaderId, keys.Length));
#endif
            accessControlManager.ProcessPinData(logicalReaderId, keys);
        }

        /// <summary>
        /// Remove all keypads
        /// </summary>
        private void removeKeypads()
        {
            keypads.Clear();
        }

        #region Pretty Printers

        /// <summary>
        /// Nicely format a LegacyCardFormat for printing
        /// </summary>
        private static string toString(LegacyCardFormat cardFormat)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Bits: {0}, Reverse: {1}, Invert: {2}, F: @{3}+{4}, I: @{5}+{6}, C: @{7}+{8}",
                            cardFormat.NumberOfBits,
                            cardFormat.ReverseCardBits ? "yes" : "no", cardFormat.InvertCardBits ? "yes" : "no",
                            cardFormat.FacilityOffset, cardFormat.FacilityLength,
                            cardFormat.IssueOffset, cardFormat.IssueLength,
                            cardFormat.CodeOffset, cardFormat.CodeLength);
            if (cardFormat.ParityConfiguration != null)
            {
                foreach (LegacyCardParity parity in cardFormat.ParityConfiguration)
                {
                    if (parity.ParityType != CardParity.None)
                    {
                        sb.AppendFormat(" + Parity: {0}, Offset {1}, Mask {2:x}",
                                        parity.ParityType, parity.Offset, parity.Mask);
                    }
                }
            }
            return sb.ToString();
        }

        /// <summary>
        /// Nicely format a card in a BitArray for printing
        /// </summary>
        private static string toString(BitArray card)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(card.Length);
            sb.Append(":");
            for (int i = 0; i < card.Length; i++)
            {
                if (i != 0 && (i % 4 == 0))
                {
                    sb.Append(" ");
                }
                sb.Append(card[i] ? "1" : "0");
            }
            return sb.ToString();
        }

        /// <summary>
        /// Print out the used bytes of cardData
        /// </summary>
        private static string toString(byte[] cardData, int bitLength)
        {
            int usedBytes = (bitLength + 7) / 8;
            return BitConverter.ToString(cardData, 0, usedBytes) + ":" + bitLength;
        }

        #endregion

        /// <summary>
        /// Process raw data received from a reader
        /// </summary>
        /// <param name="logicalReaderId">Reader's logical ID</param>
        /// <param name="cardData">Data as bytes.</param>
        /// <param name="bitLength">Number of bits of the bytes that are used.</param>
        /// <param name="valid">true if the data is valid, e.g. no collision</param>
        public void ProcessScan(int logicalReaderId, byte[] cardData, int bitLength, bool valid)
        {
            // Example card scan, Wiegand 26. Facility = 0x98 (152), Code = 0xf803 (63491)
            // Raw bitstream: 1100 1100 0111 1100 0000 0001 10 (26 bits)
            // Hex equivalent:  C    C    7    C    0    1   8 (last nibble assuming padding of 00)
            //
            // Arrives as: cardData[0..3] = 0xcc 0x7c 0x01 0x80 (last byte padded at the LSB end with 000000, to make up full final byte for total of 32 bits)
            //                  bitLength = 26
            //
            // Note in the CCM UI that "bit 1" is the most significant bit, and that's the most significant (7th) bit of the first byte.
            // For legacy decoding, we'll later turn this byte array into a BitArray, so that the BitArray[0] element is the first (MSB) of the raw bitstream
            // received.

#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.CardScanProcessor, DebugLoggingSubCategory.AccessControl,
                                   () => string.Format("CardScanProcessor : {0} scan on reader {1} : {2}",
                                                       valid ? "Valid" : "Invalid", logicalReaderId, toString(cardData, bitLength)));
#else
            Logger.LogDebugMessage(LoggerClassPrefixes.CardScanProcessor, DebugLoggingSubCategory.AccessControl,
                                   () => string.Format("CardScanProcessor : {0} scan on reader {1} : {2} bits",
                                                       valid ? "Valid" : "Invalid", logicalReaderId, bitLength));
#endif

            IReaderConfiguration readerConfiguration = ConfigurationManager.Instance.GetReaderConfiguration(logicalReaderId);
            if (readerConfiguration == null)
            {
                Logger.LogWarnMessage(LoggerClassPrefixes.CardScanProcessor, () => string.Format("Reader {0} is not configured", logicalReaderId));
                return;
            }

            if (readerConfiguration.Enabled == false)
            {
                Logger.LogWarnMessage(LoggerClassPrefixes.CardScanProcessor, () => string.Format("Reader {0} is disabled", logicalReaderId));
                return;
            }

            if (bitLength < 4)
            {
                Logger.LogWarnMessage(LoggerClassPrefixes.CardScanProcessor, () => string.Format("Reader {0} not enough data received", logicalReaderId));
                return;
            }

            if (bitLength >= 256)
            {
                Logger.LogWarnMessage(LoggerClassPrefixes.CardScanProcessor, () => string.Format("Reader {0} too much data received", logicalReaderId));
                return;
            }

            if (valid == false)
            {
                Logger.LogWarnMessage(LoggerClassPrefixes.CardScanProcessor, () => string.Format("Reader {0} collision occurred while reading card data", logicalReaderId));
                accessControlManager.ProcessAccessDenied(logicalReaderId);
                return;
            }

            if (tryProcessKeypress(logicalReaderId, cardData, bitLength) == true)
            {
                return; // Successfully decoded as a key, we're done.
            }

            if (ConfigurationManager.Instance.IsUnisonMode == true)
            {
                unisonMode(logicalReaderId, cardData, bitLength);
            }
            else
            {
                legacyMode(readerConfiguration, cardData, bitLength);
            }
        }

        /// <summary>
        /// Process card data in Unison mode
        /// </summary>
        private void unisonMode(int logicalReaderId, byte[] cardData, int bitLength)
        {
            // Send straight off to AccessControlManager
            accessControlManager.ProcessRawCardData(logicalReaderId, cardData, bitLength);
        }

        /// <summary>
        /// Process card data in legacy mode
        /// </summary>
        private void legacyMode(IReaderConfiguration readerConfiguration, byte[] cardData, int bitLength)
        {
            // Check against any card profiles defined for this reader, otherwise fall back to Wiegand 26
            Reader8003LegacyWiegandConfiguration legacyReader = readerConfiguration as Reader8003LegacyWiegandConfiguration;
            if (legacyReader == null)
            {
                Logger.LogWarnMessage(LoggerClassPrefixes.CardScanProcessor, () => string.Format("No appropriate reader configuration for reader {0}", readerConfiguration.Id));
                return;
            }

            // We work with the card data as a BitArray
            BitArray card = toBitArray(cardData, bitLength);
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.CardScanProcessor, DebugLoggingSubCategory.AccessControl, () => "Card: " + toString(card));
#endif

            // Try each card format on this reader
            foreach (int formatId in legacyReader.CardFormatIds)
            {
                LegacyCardFormat cardFormat = ConfigurationManager.Instance.GetLegacyCardFormatConfiguration(formatId);
                if (cardFormat == null)
                {
                    Logger.LogWarnMessage(LoggerClassPrefixes.CardScanProcessor, () => string.Format("Reader {0} references non-existent card profile {1}", readerConfiguration.Id, formatId));
                    continue;
                }

                Logger.LogDebugMessage(LoggerClassPrefixes.CardScanProcessor, DebugLoggingSubCategory.AccessControl, () => "Trying format ID " + formatId + " = " + toString(cardFormat));

                CardNumberHolder legacyCardFormat = tryToDecodeCard(card, cardFormat);
                if (legacyCardFormat != null)
                {
                    // Successfully decoded
                    accessControlManager.ProcessLegacyCardData(legacyReader.Id, legacyCardFormat);
                    return;
                }
            }

            // Didn't match any of the user-defined profiles, fall back to checking against Wiegand 26-bit
            Logger.LogDebugMessage(LoggerClassPrefixes.CardScanProcessor, DebugLoggingSubCategory.AccessControl, () => "Trying wiegand26 = " + toString(wiegand26));

            CardNumberHolder wiegandCard = tryToDecodeCard(card, wiegand26);
            if (wiegandCard != null)
            {
                // Wiegand-26 matches
                accessControlManager.ProcessLegacyCardData(legacyReader.Id, wiegandCard);
                return;
            }

            Logger.LogWarnMessage(LoggerClassPrefixes.CardScanProcessor,
                                  () => string.Format("CardScanProcessor : Reader {0}, no card profiles matched {1}", readerConfiguration.Id, toString(cardData, bitLength)));
        }

        /// <summary>
        /// See if the cardData and bitLength are a keypress
        /// </summary>
        /// <returns>true if it was processed as a keypress</returns>
        private bool tryProcessKeypress(int logicalReaderId, byte[] cardData, int bitLength)
        {
            // A keypress is either 4 or 8 bits of data

            if (bitLength == 4)
            {
                // 4-bit scan will be in the upper nibble of the data byte
                processKey(logicalReaderId, (byte)((cardData[0] >> 4) & 0x0F));
                return true;
            }

            if (bitLength == 8)
            {
                // 8-bit scan will have the data in the lower nibble
                processKey(logicalReaderId, (byte)(cardData[0] & 0x0F));
                return true;
            }

            return false;
        }

        /// <summary>
        /// A key was pressed on a reader, process it
        /// </summary>
        private void processKey(int logicalReaderId, byte key)
        {
            CardScanProcessorPinEntryKeypad keypad = keypads[logicalReaderId];
            if (keypad != null)
            {
                keypad.ProcessKey(key);
            }
        }

        /// <summary>
        /// Try the card data against a legacy card format.
        /// </summary>
        /// <param name="cardIn">The card data</param>
        /// <param name="cardFormat">Card format to check against</param>
        /// <returns>null if no match or parity error, otherwise a CardNumberHolder with extracted F/I/C values</returns>
        private static CardNumberHolder tryToDecodeCard(BitArray cardIn, LegacyCardFormat cardFormat)
        {
            if (cardIn.Length != cardFormat.NumberOfBits)
            {
                // Wrong number of bits
                return null;
            }

            // The card data we're working with for the rest of this function. Either a copy or the original 
            // data provided, depending on whether or not we want to change it
            BitArray card;

            if (cardFormat.InvertCardBits || cardFormat.ReverseCardBits)
            {
                // We're going to be altering the card, so make a copy to work with
                card = new BitArray(cardIn);

                if (cardFormat.InvertCardBits)
                {
                    card.Not();
                }

                if (cardFormat.ReverseCardBits)
                {
                    reverse(card);
                }
            }
            else
            {
                // Use the original data
                card = cardIn;
            }

            // Parity checks
            if (cardFormat.ParityConfiguration != null)
            {
                foreach (LegacyCardParity parity in cardFormat.ParityConfiguration)
                {
                    if (parity != null && parity.ParityType != CardParity.None && checkParity(card, parity) == false)
                    {
                        // Parity error
                        return null;
                    }
                }
            }

            // Success! Return the F/I/C from the card
            return extractDetails(card, cardFormat);
        }

        /// <summary>
        /// Convert raw cardData to the BitArray that we will use
        /// </summary>
        /// <param name="cardData">Raw data from the reader</param>
        /// <param name="bitLength">Number of valid bits</param>
        /// <returns>BitArray with element [0] being the first/MSB of the scan</returns>
        private static BitArray toBitArray(byte[] cardData, int bitLength)
        {
            // Raw bitstream: 1100 1100 0111 1100 0000 0001 10 (26 bits)
            // hex equivalent:  C    C    7    C    0    1   8
            // Arrives as: cardData[0..3] = 0xcc 0x7c 0x01 0x80

            // Some readers will provide the cardData array with many more bytes than needed, so rely on bitLength instead.
            BitArray card = new BitArray(bitLength);
            int byteNum = 0;
            int bitNum = 0;
            int mask = 0x80;
            while (bitLength-- > 0 && byteNum < cardData.Length) // while we haven't run out of bits, or bytes to process
            {
                card[bitNum++] = (cardData[byteNum] & mask) != 0x00;
                mask >>= 1; // work through the bits in the byte
                if (mask == 0x00)
                {
                    // all bits done, set up for the next cardData byte
                    byteNum++;
                    mask = 0x80;
                }
            }

            return card;
        }

        /// <summary>
        /// Using the card format, extract F/I/C from the card data
        /// </summary>
        private static CardNumberHolder extractDetails(BitArray card, LegacyCardFormat cardFormat)
        {
            int facility = (int)extract(card, cardFormat.FacilityOffset, cardFormat.FacilityLength);
            int issue = (int)extract(card, cardFormat.IssueOffset, cardFormat.IssueLength);
            long code = extract(card, cardFormat.CodeOffset, cardFormat.CodeLength);

            return new CardNumberHolder(facility, issue, code);
        }

        /// <summary>
        /// Turn a sub-range of bits into a value
        /// </summary>
        /// <param name="card">Card data</param>
        /// <param name="msb1Offset">Location of the MSB of the value, with "1" being the MSB of the card data</param>
        /// <param name="codeLength">Number of bits for the value</param>
        private static long extract(BitArray card, int msb1Offset, int codeLength)
        {
            if (codeLength == 0)
            {
                return 0;
            }

            if (msb1Offset < 1)
            {
                msb1Offset = 1; // Fix up invalid offset, to match behaviour of <= v1.12 and 8603.
            }

            // The offset is 1-based, with 1 being the MSB
            long result = 0;
            int cardPos = msb1Offset - 1;
            for (int i = 0; i < codeLength; i++)
            {
                result <<= 1;
                if (card[cardPos++] == true)
                {
                    result |= 0x01;
                }
            }

            return result;
        }

        /// <summary>
        /// Check the parity of the card data, using the supplied LegacyCardParity definition
        /// </summary>
        /// <returns>true if the parity is correct</returns>
        private static bool checkParity(BitArray card, LegacyCardParity parityDefinition)
        {
            int parityBitPosition = parityDefinition.Offset - 1; // Offset 1 is MSB

            bool odd = card[parityBitPosition]; // Accumulated parity, start with the value of the parity bit itself
            IEnumerable<int> bitPositions = whichBitsAreSet(parityDefinition.Mask, card.Length);
            foreach (int position in bitPositions)
            {
                if (card[position] == true)
                {
                    odd ^= true;
                }
            }
            return odd == (parityDefinition.ParityType == CardParity.Odd);
        }

        /// <summary>
        /// Gets the indices of the "1" bits in the mask supplied, also doing a bit reversal to
        /// translate from how LegacyCardParity specifies masks, to how we need to apply it to
        /// our BitArray card data.
        /// </summary>
        /// <param name="mask">LegacyCardParity mask to analyse</param>
        /// <param name="cardLength">The length of the card that this mask is being applied to</param>
        /// <returns>A list of zero or more integers, one for each set "1" bit</returns>
        private static IEnumerable<int> whichBitsAreSet(long mask, int cardLength)
        {
            // A LegacyCardParity mask of 0x01 applied against a 8-bit card means it looks at BitArray card[7].
            // A LegacyCardParity mask of 0x40 applied against a 8-bit card means it looks at BitArray card[1].
            List<int> result = new List<int>();
            for (int i = 0; i < cardLength && mask != 0; i++)
            {
                if ((mask & 0x01) == 0x01)
                {
                    result.Add(i);
                }
                mask >>= 1;
            }
            return result;
        }

        /// <summary>
        /// Reverse the bits in a BitArray
        /// </summary>
        private static void reverse(BitArray card)
        {
            // Reverse the order of the bits in the BitArray
            for (int i = 0, j = card.Length - 1; i < card.Length / 2; i++, j--)
            {
                bool t = card[i];
                card[i] = card[j];
                card[j] = t;
            }
        }

        #region Unit Test Access
        /// <summary>
        /// Used by the unit tests to bypass all the reader-related things, and try to decode a legacy card swipe against the given cardFormat
        /// </summary>
        /// <returns>Card if successfully decoded, null otherwise</returns>
        public static CardNumberHolder UnitTestDecodeLegacyCard(byte[] cardData, int bitLength, LegacyCardFormat cardFormat)
        {
            BitArray card = toBitArray(cardData, bitLength);
            return tryToDecodeCard(card, cardFormat);
        }

        /// <summary>
        /// Used by the unit tests to bypass all the reader-related things, and try to decode a legacy card swipe against the fallback Wiegand 26 format
        /// </summary>
        /// <returns>Card if successfully decoded, null otherwise</returns>
        public static CardNumberHolder UnitTestDecodeWiegand26Card(byte[] cardData, int bitLength)
        {
            return UnitTestDecodeLegacyCard(cardData, bitLength, wiegand26);
        }

        /// <summary>
        /// Used by the unit tests test reversing of a BitArray
        /// </summary>
        /// <returns>BitArray with the bits in reverse order</returns>
        public static BitArray UnitTestReverse(BitArray data)
        {
            BitArray result = new BitArray(data);
            reverse(result);
            return result;
        }
        #endregion
    }
}
