﻿using System;
using Pacom.Peripheral.CellularManagement;
using System.Net;

namespace Pacom.Peripheral.Common
{
    public interface IGprsExpansionCardStatus
    {
        /// <summary>
        /// Get / Set GPRS modem current network registration state
        /// </summary>
        GprsNetworkRegistration NetworkRegistration
        {
            get;
            set;
        }

        /// <summary>
        /// Get / Set GPRS modem current signal strength 
        /// </summary>
        GprsNetworkSignalStrength SignalStrength
        {
            get;
            set;
        }

        /// <summary>
        /// Get the current reported mobile service carrier
        /// </summary>
        string CellularCarrier
        {
            get;
        }

        /// <summary>
        /// Get current carrier access technology
        /// </summary>
        CellularAccessTechnology CellularAccessTechnology
        {
            get;
        }

        /// <summary>
        /// Get modem module serial number
        /// </summary>
        string CellularModuleSerialNumber
        {
            get;
        }

        /// <summary>
        /// Get modem module revision
        /// </summary>
        string CellularModuleRevision
        {
            get;
        }

        /// <summary>
        /// Get modem module model
        /// </summary>
        string CellularModuleModel
        {
            get;
        }

        /// <summary>
        /// Get modem module manufacturer
        /// </summary>
        string CellularModuleManufacturer
        {
            get;
        }

        /// <summary>
        /// Get current connection duration
        /// </summary>
        TimeSpan ConnectionDuration
        {
            get;
        }

        /// <summary>
        /// Get current connection transmitted bytes
        /// </summary>
        int ConnectionTransmittedBytes
        {
            get;
        }

        /// <summary>
        /// Get current connection received bytes
        /// </summary>
        int ConnectionReceivedBytes
        {
            get;
        }

        /// <summary>
        /// Get IP address assigned to the connection by remote site
        /// </summary>
        IPAddress ConnectionIPAddress
        {
            get;
        }

        /// <summary>
        /// GPRS data usage details
        /// </summary>
        IGprsDataUsageDetails IGprsDataUsage
        {
            get;
        }

        /// <summary>
        /// Clear cellular module statistics
        /// </summary>
        void ClearCellularModuleStatistics();

        /// <summary>
        /// Clear current connection statistics
        /// </summary>
        void ClearConnectionStatistics();

        /// <summary>
        /// Update current connection statistics
        /// </summary>        
        void UpdateConnectionStatistics(int txBytes, int rxBytes, TimeSpan duration);

        /// <summary>
        /// Update cellular module statistics
        /// </summary>
        void UpdateCellularModuleStatistics(string serialNumber, string revision, string model, string manufacturer);

        /// <summary>
        /// Update cellular carrier
        /// </summary>
        void UpdateCellularCarrier(string carrier, CellularAccessTechnology act);

        /// <summary>
        /// Update current connection IP address
        /// </summary>        
        void UpdateConnectionIPAddress(IPAddress address);
    }
}
