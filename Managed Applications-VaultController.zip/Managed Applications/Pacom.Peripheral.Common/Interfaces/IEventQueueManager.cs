﻿using System;
using Pacom.Peripheral.Common;
using System.Collections.Generic;

namespace Pacom.Peripheral.EventQueue
{
    /// <summary>
    /// Interface for accessing event queue manager.
    /// </summary>
    public interface IEventQueueManager
    {
        /// <summary>
        /// Triggered when new event event is entered into the queue
        /// </summary>
        event EventHandler<NewEventAddedEventArgs> NewEventAdded;

        /// <summary>
        /// Enable or disable queue for specific system. System1 cannot be disabled.
        /// </summary>
        /// <param name="system">Array with enabled systems</param>
        void SetSystems(FrontEndSystem[] inputSystemSet);

        /// <summary>
        /// Begin event queue for system.
        /// </summary>
        /// <param name="inputSystem">System id to be enabled</param>
        void EnableSystem(FrontEndSystem inputSystem);

        /// <summary>
        /// Stop event queue for system.
        /// </summary>
        /// <param name="inputSystem">System id to be disable</param>
        void DisableSystem(FrontEndSystem inputSystem);

        /// <summary>
        /// Check if system is enabled
        /// </summary>
        /// <param name="inputSystem">System id to be checked</param>
        /// <returns></returns>
        bool IsSystemEnabled(FrontEndSystem inputSystem);

        /// <summary>
        /// Begin event queue for system with starting point based on existing system. 
        /// If the source system is not enabled the queue will start from next event enqueued.
        /// If the destination system is already enabled there will be no change in configuration.
        /// </summary>
        /// <param name="sourceSystem">Source system to base item offsets on</param>
        /// <param name="destinationSystem">System to enable</param>
        void CloneSystem(FrontEndSystem sourceSystem, FrontEndSystem destinationSystem);

        /// <summary>
        /// Issues a ticket with event position and data from the queue
        /// </summary>
        /// <param name="systemId"></param>
        /// <returns></returns>
        EventQueueTicket PeekEventFromQueue(FrontEndSystem system);

        /// <summary>
        /// Removes ticket from queue
        /// </summary>
        /// <param name="ticket"></param>
        void RemoveEventByTicket(EventQueueTicket ticket);

        /// <summary>
        /// Checks if event queue for particular system has high priority events
        /// </summary>
        /// <param name="systemId">Frontend system 1..8</param>
        /// <returns>Returns True when high priority events present for the system</returns>
        bool HighPriorityEventsPresent(FrontEndSystem system);
        
        /// <summary>
        /// Returns event count for specified system
        /// </summary>
        /// <param name="systemId">Frontend system 1..8</param>
        /// <returns>Return number of events still queued for the system</returns>
        int EventCount(FrontEndSystem system);

        /// <summary>
        /// Remove all events from all queue. Restart the queues and statistics. Preserve the system configuration.
        /// </summary>
        void Flush();

        /// <summary>
        /// Iterate event queue for available items.
        /// </summary>
        /// <param name="system"></param>
        /// <returns></returns>
        IEnumerable<byte[]> IterateQueue(FrontEndSystem system);
    }
}
