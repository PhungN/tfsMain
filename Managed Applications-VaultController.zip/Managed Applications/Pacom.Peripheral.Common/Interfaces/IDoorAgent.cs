﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    public interface IDoorAgent : IDoorReaderAgentBase
    {
        /// <summary>
        /// Get door agent current door lock operation
        /// </summary>
        DoorLockOperation DoorLockOperation
        {
            get;
        }

        /// <summary>
        /// Shunt time for masking any alarms while the door is open
        /// </summary>
        int ShuntTime
        {
            get;
            set;
        }

        /// <summary>
        /// Embarrassment time, extra time allowed for closing the door during which the buzzer will beep in milliseconds.
        /// </summary>
        int EmbarrassmentTime
        {
            get;
            set;
        }

        /// <summary>
        /// Deactivate Strike Timeout - Bolt Door Only
        /// </summary>
        int DeactivateStrikeTimeout
        {
            get;
        }

        /// <summary>
        /// Get the current door alarm
        /// </summary>
        DoorAlarms DoorAlarm
        {
            get;
        }

        /// <summary>
        /// Returns the last door alarm sent
        /// </summary>
        DoorAlarms LastDoorAlarmSent
        {
            get;
        }

        /// <summary>
        /// Get the door alarm timers currently running
        /// </summary>
        DoorAlarmTimers DoorAlarmTimers
        {
            get;
        }

        /// <summary>
        /// Get In Reader Transaction information 
        /// </summary>
        ReaderTransaction InReaderTransaction
        {
            get;
        }

        /// <summary>
        /// Get Out Reader Transaction information 
        /// </summary>
        ReaderTransaction OutReaderTransaction
        {
            get;
        }

        /// <summary>
        /// Check If In Reader Is Assigned
        /// </summary>
        bool IsInReaderAssigned
        {
            get;
        }

        /// <summary>
        /// Check If Out Reader Is Assigned
        /// </summary>
        bool IsOutReaderAssigned
        {
            get;
        }

        /// <summary>
        /// In Reader Status Instance
        /// </summary>
        ReaderStatus InReaderStatus
        {
            get;
        }

        /// <summary>
        /// Out Reader Status Instance
        /// </summary>
        ReaderStatus OutReaderStatus
        {
            get;
        }

        /// <summary>
        /// Keypad Inactivity Timer On In Reader In Progress
        /// </summary>
        bool IsKeypadInactivityTimerOnInReaderInProgress
        {
            get;
        }

        /// <summary>
        /// Keypad Inactivity Timer On Out Reader In Progress
        /// </summary>
        bool IsKeypadInactivityTimerOnOutReaderInProgress
        {
            get;
        }

        /// <summary>
        /// When door is open by command this is the duration type.
        /// </summary>
        DurationType TransactionDurationType
        {
            get;
        }

        /// <summary>
        /// When door is open by command this is the duration in seconds.
        /// </summary>
        int TransactionAccessDuration
        {
            get;
        }
    }
}
