﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common.LcdKeypadStateMachine;
using Pacom.Peripheral.AlarmManagement;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.EventQueue;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Pacom8101 keypad statemachine interface. Implemented in the Pacom.Peripheral.KeypadStateMachine assembly.
    /// </summary>
    public interface IKeypadStateMachine : IDisposable
    {
        /// <summary>
        /// Event triggered when turn off keypad buzzer message needs to be sent to the keypad device. The owner Pacom8101 device will subscribe to this event.
        /// </summary>
        event EventHandler BuzzerOffEvent;

        /// <summary>
        /// Event triggered when turn on keypad buzzer message needs to be sent to the keypad device. The owner Pacom8101 device will subscribe to this event.
        /// </summary>
        event EventHandler<BuzzerOnEventArgs> BuzzerOnEvent;

        /// <summary>
        /// Event triggered when clear keypad LCD display message needs to be sent to the keypad device. The owner Pacom8101 device will subscribe to this event.
        /// </summary>
        event EventHandler ClearLcdDisplayEvent;

        /// <summary>
        /// Event triggered when display countdown count on keypad's Lcd message needs to be sent to the keypad device. The owner Pacom8101 device will subscribe to this event.
        /// </summary>
        event EventHandler<CountdownEventArgs> DisplayCountdownEvent;

        /// <summary>
        /// Event triggered when the escape [x] character needs to be displayed on keypad's LCD display . The owner Pacom8101 device will subscribe to this event.
        /// </summary>
        event EventHandler<DisplayEscapeCharOnLcdDisplayEventArgs> DisplayEscapeCharOnLcdDisplayEvent;

        /// <summary>
        /// Event triggered when we need to echo the last entered digit on the keypad's LCD display. The owner Pacom8101 device will subscribe to this event.
        /// </summary>
        event EventHandler<EchoLastDigitOnLcdDisplayEventArgs> EchoLastDigitOnLcdDisplayEvent;

        /// <summary>
        /// Event triggered when we need to echo the last entered character on the keypad's LCD display. The owner Pacom8101 device will subscribe to this event.
        /// </summary>
        event EventHandler<EchoLastCharOnLcdDisplayEventArgs> EchoLastCharOnLcdDisplayEvent;

        /// <summary>
        /// Event triggered when we need to display text on one of the keypad's LCD display lines. The owner Pacom8101 device will subscribe to this event.
        /// </summary>
        event EventHandler<DisplayMessageOnLcdDisplayEventArgs> DisplayMessageOnLcdDisplayEvent;

        /// <summary>
        /// Event triggered when we need to send message to keypad's LCD display. The owner Pacom8101 device will subscribe to this event.
        /// </summary>
        event EventHandler<LcdMessagesEventArgs> LcdMessagesEvent;

        /// <summary>
        /// Event triggered when we need to update all LEDs independently if the keypad is in legacy mode of operation (8 areas). The owner Pacom8101 device will subscribe to this event.
        /// </summary>
        event EventHandler<UpdateAllLedsEventArgs> UpdateAllLedsEvent;

        /// <summary>
        /// Event triggered when we need to update the keypad's stored user defined characters. The owner Pacom8101 device will subscribe to this event.
        /// </summary>
        event EventHandler<UpdateCustomCharacterEventArgs> UpdateCustomCharacterEvent;

        /// <summary>
        /// Event triggered when we need to turn OMN the Lcd display backlighting. The owner Pacom8101 device will subscribe to this event.
        /// </summary>
        event EventHandler TurnOnLcdDisplayBacklightEvent;

        /// <summary>
        /// A number of icon buttons can be set. 
        /// When shown they must be displayed out across the screen in a way that is easy to see and allow them to be selected. 
        /// This is analogous to smart phones that show a number of applications that can be run on the home page.
        /// Multi messages will be sent to build the list of icons.
        /// If the number of items is more than can be shown on the screen then some sort of scroll bar will show and allow the list to be scrolled. 
        /// Note that the 8105 only supports a maximum of 12 icons). The icon page once shown will persist until a clear screen text message is sent.
        /// </summary>
        event EventHandler<GraphicsKeypadIconButtonEventArgs> DisplayIconButttonEvent;

        event EventHandler<GraphicsKeypadMenuEventArgs> DisplayVaultMenuEvent;

        event EventHandler<GraphicsKeypadAlertMessageEventArgs> DisplayAlertMessageEvent;

        /// <summary>
        /// Get / Set AlarmManager instance
        /// </summary>
        IAlarmManager AlarmManager
        {
            get;
            set;
        }

        /// <summary>
        /// Get / Set EventQueueManager instance
        /// </summary>
        IEventQueueManager EventQueueManager
        {
            get;
            set;
        }

        /// <summary>
        /// Handles KeyPressed message sent to Pacom8101 controller from the physical keypad device
        /// </summary>
        /// <param name="keyCode">Keypad KeyCode</param>
        /// <param name="logicalDeviceId">Keypad Logical Device Id</param>
        void KeyPressed(KeypadKey keyCode);

        /// <summary>
        /// Update the keypad's state and display after the macro has ran if needed
        /// </summary>
        void DoAfterMacroRun();

        /// <summary>
        /// Initialize Keypad State Machine
        /// </summary>
        void Initialize();

        /// <summary>
        /// Set keypad state machine macro state to DisarmingStarted
        /// </summary>
        void DisarmingStarted();

        /// <summary>
        /// Set keypad state machine macro state to ArmingStarted
        /// </summary>
        /// <param name="withoutDelay">True if the arming is without delay, False otherwise.</param>
        void ArmingStarted(bool withoutDelay);

        /// <summary>
        /// Set user messages that will be displayed on keypad LCD display until a user presses any of the keypad keys.
        /// </summary>
        /// <param name="userMessages">The list of messages to be displayed on keypad LCD lines in order from top to bottom.</param>
        void SetUserMessages(string[] userMessages);

        /// <summary>
        /// Check if the keypad's configuration contains any of the areas in [areaIds] list
        /// </summary>
        /// <param name="areaIds">Area list to check against</param>
        /// <returns>True if the keypad's configuration contains at least one of the areas in [areaIds] list.</returns>
        bool ContainsAnyArea(List<int> areaIds);

        /// <summary>
        /// Check if keypad in is area
        /// </summary>
        /// <param name="areaId"></param>
        /// <returns></returns>
        bool IsInArea(int areaId);

        /// <summary>
        /// Change keypad display width
        /// </summary>
        /// <param name="newLineWidth">New display width</param>
        void SetDisplayWidth(int newLineWidth);

        /// <summary>
        /// Turn on the buzzer with the specified number of seconds
        /// </summary>
        /// <param name="seconds"></param>
        void ActivateBuzzer(int seconds);

        /// <summary>
        /// Turn on the buzzer with the specified number of milliseconds
        /// </summary>
        /// <param name="milliseconds"></param>
        void ActivateBuzzerMillisecond(int milliSeconds);

        /// <summary>
        /// Turn off the buzzer
        /// </summary>
        void DeactivateBuzzer();

        void GraphicsKeypadMenuSelection(byte itemNumber);
        bool IsGraphicsKeypad { get; set; }
    }
}
