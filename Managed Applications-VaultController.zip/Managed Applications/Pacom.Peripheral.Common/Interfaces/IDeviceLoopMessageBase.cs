﻿using System;

namespace Pacom.Peripheral.Common
{
    public delegate void SendOnDeviceLoopFunc(IDeviceLoopMessageBase message);

    public interface IDeviceLoopMessageBase
    {
        byte[] Data { get; }
        byte FunctionCode { get; }
        int Length { get; }
        int Offset { get; }
        string ToString();
    }
}
