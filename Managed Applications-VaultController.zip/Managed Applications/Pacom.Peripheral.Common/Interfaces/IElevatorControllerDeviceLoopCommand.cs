﻿using System;

namespace Pacom.Peripheral.Common
{
    public interface IElevatorControllerDeviceLoopCommand
    {
        void UnlockFloors(int floorsAccess, int activeTimeInSeconds);
        void SetFloorAccessTime(int floorAccessTime);
    }
}
