﻿using Pacom.Peripheral.Common;
using Pacom.Core.Contracts;
using System;

namespace Pacom.Peripheral.AlarmManagement
{
    public delegate bool EnqueueEventDelegate(EventMessageBase eventMessage);

    public interface IAlarmManager : IDisposable
    {
        /// <summary>
        /// Get the list of unacknowledged alarms
        /// </summary>
        IAlarmsQueue<EventMessageBase> UnacknowledgedAlarms
        {
            get;
        }

        /// <summary>
        /// Get the list of all persisted alarms that will be available for display on any keypad
        /// </summary>
        IAlarmsQueue<EventMessageBase> Alarms
        {
            get;
        }
    }
}
