﻿using Pacom.Peripheral.Common.Status;
using System;

namespace Pacom.Peripheral.Common
{
    public interface IReaderAgent : IDoorReaderAgentBase
    {
        /// <summary>
        /// Get Reader Transaction information 
        /// </summary>
        ReaderTransaction ReaderTransaction
        {
            get;
        }

        /// <summary>
        /// Keypad Inactivity Timer On Reader In Progress
        /// </summary>
        bool IsKeypadInactivityTimerInProgress
        {
            get;
        }

        /// <summary>
        /// Reset card reader agent state
        /// </summary>
        void ResetAgent();

        /// <summary>
        /// Clear valid card transaction information
        /// </summary>
        void ClearValidCardTransaction();

        DoorAgentContexts Context { get; set; }
    }
}
