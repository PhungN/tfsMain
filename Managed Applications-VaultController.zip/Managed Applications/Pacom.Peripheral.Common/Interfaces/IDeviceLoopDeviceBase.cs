﻿using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common
{
    public interface IDeviceLoopDeviceBase
    {
        /// <summary>
        /// Returns device physical Id
        /// </summary>
        int DeviceId
        {
            get;
        }

        /// <summary>
        /// Returns device logical Id
        /// </summary>
        int LogicalDeviceId
        {
            get;
        }

        /// <summary>
        /// Returns 1 based device physical Id
        /// </summary>
        int DeviceIdOneBased
        {
            get;
        }

        /// <summary>
        /// Returns device type
        /// </summary>
        DeviceType DeviceType
        {
            get;
        }

        /// <summary>
        /// Returns Device Type as string
        /// </summary>
        string DeviceTypeName
        {
            get;
        }

        /// <summary>
        /// Firmware / main application version number
        /// </summary>
        FirmwareVersion FirmwareVersion
        {
            get;
            set;
        }

        /// <summary>
        /// Bootloader version number
        /// </summary>
        FirmwareVersion BootloaderVersion
        {
            get;
            set;
        }

        /// <summary>
        /// Get device connects on 485 Serial connection
        /// </summary>
        bool ConnectedOnSerial 
        { 
            get; 
        }

        /// <summary>
        /// Get device connects on UDP/IP connection
        /// </summary>
        bool ConnectedOnIP 
        { 
            get; 
        }

        /// <summary>
        /// Returns True if device is disconnected, False otherwise
        /// </summary>
        bool Disconnected
        {
            get;
        }

        /// <summary>
        /// Get device configuration
        /// </summary>
        DeviceLoopDeviceConfigurationBase ConfigurationBase
        { 
            get; 
        }

        /// <summary>
        /// Array of expansion card types, valid for 8501 devices only, maximum 2 entries.
        /// </summary>
        ExpansionCardType[] ExpansionCardTypes
        {
            get;
            set;
        }

        /// <summary>
        /// Device initialization
        /// </summary>
        void Initialize();

        /// <summary>
        /// Handle message received from physical device on device loop
        /// </summary>
        /// <param name="message">Message Received</param>
        void ReceiveMessage(IDeviceLoopMessageBase message);

        /// <summary>
        /// Send message to physical device on device loop
        /// </summary>
        /// <param name="message">Message to send</param>
        void SendOnDeviceLoop(IDeviceLoopMessageBase message);

        /// <summary>
        /// Send messages to physical device on device loop
        /// </summary>
        /// <param name="messages">List of messages to send.</param>
        void SendOnDeviceLoop(List<IDeviceLoopMessageBase> messages);
        
        /// <summary>
        /// Sets output on device loop device
        /// </summary>
        /// <param name="ouputsStates">Array with output statuses.</param>
        /// <param name="changedIndex">If set to value other than -1, a single output has changed, the zero based index in the array points to the changed value.</param>
        void SetOutputStatus(bool[] ouputsStates, int changedIndex);

        /// <summary>
        /// Send access control command to device
        /// </summary>
        /// <param name="logicalReaderId">Logical card reader Id.</param>
        /// <param name="readerConfig">Card Reader Access Control Command.</param>
        void SendAccessControlCommand(int logicalReaderId, CardReaderCommandDataConfig readerConfig);

    }

    public interface ISecurityLevelDisplay
    {
        void SendDisplaySecurityLevelCommand(int logicalReaderId, CardReaderDisplaySecurityLevelConfig config);
    }
}
