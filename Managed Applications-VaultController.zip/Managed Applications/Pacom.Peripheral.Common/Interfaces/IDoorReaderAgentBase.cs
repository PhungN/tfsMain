﻿using System;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Door / Reader Agent Common Public Services.
    /// </summary>
    public interface IDoorReaderAgentBase
    {
        /// <summary>
        /// Get current door / reader operation state.
        /// </summary>
        DoorOperationState OperationState
        {
            get;
            set;
        }

        /// <summary>
        /// Strike Time in milliseconds
        /// </summary>
        int StrikeTime
        {
            get;
            set;
        }

        /// <summary>
        /// Keypad inactivity time, time allowed for the pin entry.
        /// </summary>
        int KeypadInactivityTimeout
        {
            get;
        }

        /// <summary>
        /// Get duration to activate card reader LED for denied card [ms]
        /// </summary>
        int AccessDeniedDuration
        {
            get;
        }

        /// <summary>
        /// Returns the state of the Strike after the peripherals have been updated
        /// </summary>
        bool StrikeActivated
        {
            get;
        }

        /// <summary>
        /// Broadcast the last access control transaction (door / reader peripheral).
        /// The Door / Reader Agent unit tests subscribe to this event in order to get 
        /// the last door / reader peripheral transaction and compare it with the 
        /// expected value.
        /// </summary>
        event EventHandler<AccessControlTransactionEventArgs> LastAccessControlTransactionEvent;

        /// <summary>
        /// Send access control transaction event so any subscribers can receive the value of the last access control transaction
        /// for this door / reader.
        /// </summary>
        /// <param name="transactionType">Access Control Transaction Value</param>
        void SendAccessControlTransactionEvent(TransactionType transactionType);

        /// <summary>
        /// Check if Access Denied is in progress
        /// </summary>
        bool IsDeniedAccessTimerInProgress
        {
            get;
        }

        /// <summary>
        /// Get the door / reader peripheral timers currently running
        /// </summary>
        DoorPeripheralTimers PeripheralTimers
        {
            get;
            set;
        }

        /// <summary>
        /// Update Door / Reader Agent State
        /// </summary>
        /// <param name="context">Door / Reader Agent Context</param>
        /// <returns>True if Strike Activated / False Otherwise</returns>
        bool UpdateAgentState(DoorAgentContexts context);
    }
}
