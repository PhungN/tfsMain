﻿using System;

namespace Pacom.Peripheral.Common
{
    public interface ISram
    {
        bool WriteData(int offset, byte[] data);
        bool ReadData(int offset, byte[] data);
    }
}
