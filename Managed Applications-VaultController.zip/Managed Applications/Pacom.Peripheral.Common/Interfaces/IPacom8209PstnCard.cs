﻿using System.IO.Ports;

namespace Pacom.Peripheral.Common
{
    public interface IPacom8209PstnCard
    {
        PhysicalSerialPort PortId { get; }
        int PortBaudRate { get; }
        Parity PortParity { get; }
        int PortDataBits { get; }
        StopBits PortStopBits { get; }
        PstnModemConnectionStatus ConnectionStatus { get; set; }
        void PulseReset();

        /// <summary>Get/Set RTS modem PIO port</summary>
        bool RtsEnabled { get; }

        /// <summary>Get/Set DTR modem PIO port</summary>
        bool DtrEnabled { get; }

        /// <summary>Allows control of line seize relay on the PSTN modem</summary>
        bool LineSeized { get; set; }

        /// <summary>
        /// Set / Reset modem RTS / DTR pins in one command
        /// </summary>
        void EnableRtsAndDtr();

        /// <summary>
        /// Toggle DTR modem pin - required for SIA switching in / out of AT command mode
        /// </summary>
        /// <param name="dtr">True/False</param>
        void SetDtr(bool dtr);
    }
}
