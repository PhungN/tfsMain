﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common
{
    public interface IDeviceLoopManager
    {
        /// <summary>
        /// Triggered when an invalid configuration has been detected.
        /// </summary>
        event EventHandler<InvalidConfigurationEventBase> InvalidConfigurationEvent;

        /// <summary>
        /// Triggered when a device loop requires new instance of keypad state machine.
        /// </summary>
        event EventHandler<RequestKeypadStateMachineEventArgs> RequestKeypadStateMachineInstance;

        /// <summary>
        /// Get Indexer property that returns the DeviceLoopDevice instance for a given physical deviceId.
        /// The physical device id is 0 based, with values in the range 0 - 127.
        /// </summary>
        /// <param name="deviceId">Physical DeviceId, 0 based</param>
        /// <returns>The IDeviceLoopDeviceBase interface for the given physical device id or null if the deviceId is invalid.</returns>
        IDeviceLoopDeviceBase this[int deviceId]
        {
            get;
        }

        /// <summary>
        /// Get keypad by device Id
        /// </summary>
        /// <param name="deviceId">Physical DeviceId, 0 based</param>
        /// <returns>IKeypadStateMachine or null if this is not a keypad.</returns>
        IKeypadStateMachine GetKeypad(int deviceId);

        /// <summary>
        /// Get power supply IPowerSupplyDevice interface if the device with [deviceId] supports it
        /// </summary>
        /// <param name="deviceId">Physical DeviceId, 0 based</param>
        /// <returns>IPowerSupplyDevice or null if this is not a power supply device.</returns>
        IPowerSupplyDevice GetPowerSupply(int deviceId);

        /// <summary>
        /// Returns true if at least one keypad is connected to the device loop
        /// </summary>
        bool OneOrMoreKeypadsOnline
        {
            get;
        }

        /// <summary>
        /// Queue firmware update for device type.
        /// </summary>
        /// <param name="deviceType">Device type for which to start firmware update.</param>
        /// <param name="firmwarePath">Firmware file path.</param>
        /// <param name="firmwareVersion">New firmware file version.</param>
        void UpdateFirmware(DeviceType deviceType, string firmwarePath, string firmwareFilePath, FirmwareVersion firmwareVersion);

        /// <summary>
        /// Notify keypads that have access to any area in areasToDisarmIds that disarming has started
        /// </summary>
        /// <param name="areasToDisarmIds">List of areas that will be disarmed.</param>
        void NotifyKeypadsDisarmingStarted(List<int> areasToDisarmIds);

        /// <summary>
        /// Notify keypads that have access to any area in areasToArmIds that arming has started
        /// </summary>
        /// <param name="areasToArmIds">List of areas that will be armed.</param>
        /// <param name="withoutDelay">True if the arming is without delay, False otherwise.</param>
        void NotifyKeypadsArmingStarted(List<int> areasToArmIds, bool withoutDelay);

        /// <summary>
        /// Turn on all the buzzers in an area with the specified number of seconds
        /// If seconds is zero, buzzers will be on permanantly
        /// </summary>
        /// <param name="areaId"></param>
        /// <param name="seconds"></param>
        void ActivateKeypadBuzzers(int areaId, int seconds);

        /// <summary>
        /// Turn off all the buzzers in an area
        /// </summary>
        /// <param name="areaId"></param>
        void DeactivateKeypadBuzzers(int areaId);

        /// <summary>
        /// Turn on buzzer with the specified number of seconds
        /// If seconds is zero, buzzer will be on permanantly
        /// </summary>
        /// <param name="deviceId"></param>
        /// <param name="seconds"></param>
        void ActivateKeypadBuzzer(int deviceId, int seconds);

        /// <summary>
        /// Turn off all the buzzer
        /// </summary>
        /// <param name="deviceId"></param>
        void DeactivateKeypadBuzzer(int deviceId);
    }
}
