﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.CellularManagement
{
    /// <summary>
    /// Interface used to access the cellular API.
    /// </summary>
    public interface ICellularManager
    {
        /// <summary>
        /// Triggered when the connection is started. Just after connection to the provider IP network.
        /// </summary>
        event EventHandler<EventArgs> CellularConnectionEstablished;

        /// <summary>
        /// Triggered when the connection is ended.
        /// </summary>
        event EventHandler<EventArgs> CellularConnectionHangup;

        /// <summary>
        /// Check if cellular connection is established on specified physical port.
        /// </summary>
        /// <param name="port">Physical port on which we should query the status</param>
        /// <returns>Returns </returns>
        bool AvailableForUse(PhysicalSerialPort port);
        
        /// <summary>
        /// Request to send SMS via the cellular mobile provider.
        /// </summary>
        /// <param name="phoneNumber">Recipient phone number</param>
        /// <param name="message">Message body</param>
        /// <returns>Returns True if the message was successfully enqueued.</returns>
        /// <remarks>The message will be discarded is the system does not have means to send it.</remarks>
        bool SendSms(string phoneNumber, string message);

        /// <summary>
        /// Request the manager to reload.
        /// </summary>
        /// <returns>Returns true if the configuration was avaliable and reload will happen soon.</returns>
        bool Reload();
    }
}
