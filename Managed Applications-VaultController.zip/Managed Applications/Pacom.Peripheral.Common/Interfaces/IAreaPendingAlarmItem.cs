﻿using Pacom.Core.Contracts;

namespace Pacom.Peripheral.AlarmManagement
{
    public interface IAreaPendingAlarmItem
    {
        /// <summary>
        /// Add new event to area pending alarm queue
        /// </summary>
        /// <param name="anEvent">New event instance.</param>
        void AddEvent(EventMessageBase anEvent);

        /// <summary>
        /// Flush area pending alarms queue.
        /// </summary>
        void Flush();

        /// <summary>
        /// Enable area pending alarms queue.
        /// </summary>
        void Enable();

        /// <summary>
        /// Check if area pending alarm queue sis enbaled.
        /// </summary>
        bool IsEnabled { get; }

        /// <summary>
        /// Disable area pending alarms queue.
        /// </summary>
        void Disable();

        /// <summary>
        /// Flush area pending alarms queue and then disable it.
        /// </summary>
        void FlushAndDisable();

        /// <summary>
        /// Flush area pending alarms queue and then enable it.
        /// </summary>
        void FlushAndEnable();

        /// <summary>
        /// Dequeue all events from the area pending alarms queue and push them into the
        /// main alarm manager queue so they will be stored and then sent to the front-end.
        /// </summary>
        void StopAndDequeue();
    }
}
