﻿
namespace Pacom.Peripheral.Common
{
    public interface IPowerSupplyDevice
    {
        /// <summary>
        /// Check if battery load test is in progress
        /// </summary>
        bool BatteryLoadTestInProgress { get; }

        /// <summary>
        /// Start battery load test immediately if possible. If the battery load test is currently running return False.
        /// </summary>
        /// <returns>True if the battery load test can start, False otherwise</returns>
        bool StartBatteryLoadTest();

        /// <summary>
        /// Stop battery load test if running. If the battery load test is not currently running return False.
        /// </summary>
        /// <returns>True if the battery load test can be stopped, False otherwise</returns>
        bool StopBatteryLoadTest();
    }
}
