﻿using System;
using System.Security.Cryptography;

namespace Pacom.Peripheral.Common
{
    public interface IMacGenerator : IDisposable
    {
        ICryptoTransform CreateEncryptor(PaddingMode paddingMode);
        ICryptoTransform CreateDecryptor(PaddingMode paddingMode);
        byte[] GenerateEncryptedSessionKey();
        void DecryptNewSessionKey(byte[] encryptedSessionKey);
        byte[] EncryptNextSessionId(long nextSessionId);
        long DecryptNextSessionId(byte[] nextSessionIdBytes);
        bool IsMacValid(byte[] data, int startIndex, byte[] mac);
        byte[] ComputeHash(byte[] input, int offset, int length);

        byte[] Key
        {
            get;
        }
    }
}
