﻿using Pacom.Peripheral.Common.Status;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Common
    /// </summary>
    public interface IStatusItem
    {
        StatusItemType ItemType
        {
            get;
        }

        int LogicalId
        {
            get;
        }

        /// <summary>
        /// Get all current alarms. The default is None. Only devices are implementing this.
        /// </summary>
        EventSourceLatchOrIsolateType CurrentAlarms
        {
            get;
        }

        /// <summary>
        /// Check if this status item has any alarms
        /// </summary>
        bool HasAnyAlarm
        {
            get;
        }

        EventSourceLatchOrIsolateType IsolatedAlarms
        {
            get;
        }

        /// <summary>
        /// Set isolated flag for a single status item (device, expansion card, input, door, output, reader, etc.) for a specified duration.
        /// </summary>
        /// <param name="value">True for isolate, false for normal operation when the [bitFieldValue] is not used.</param>
        /// <param name="bitField">BitField options to isolate/deisolate when the [boolValue] is not used</param>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="durationInSeconds">The duration for which the point will be isolated, 0 means that the point will be isolated idefinitely</param>
        /// <returns>True if the point's isolated state was successfully changed, False otherwise.</returns>
        bool SetIsolated(bool value, EventSourceLatchOrIsolateType bitField, UserAuditInfo userAuditInfo, int durationInSeconds);

        /// <summary>
        /// Isolate status item state.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        void Isolate(UserAuditInfo userAuditInfo);

        /// <summary>
        /// Deisolate status item state.
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        void Deisolate(UserAuditInfo userAuditInfo);

        /// <summary>
        /// Isolate device / controller / input / output / etc. specific alarm or
        /// all alarms (E.g.: for a device we can isolate Tamper or Offline or both of them).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="options">Alarm types to isolate: Offline / Tamper / etc.</param>
        void Isolate(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options);

        /// <summary>
        /// Deisolate device / controller / input / output / etc. specific alarm or
        /// all alarms (E.g.: for a device we can deisolate Tamper or Offline or both of them).
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the isolate / deisolate command.</param>
        /// <param name="options">Alarm types to deisolate: Offline / Tamper / etc.</param>
        void Deisolate(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options);

        /// <summary>
        /// Get all latched alarm flags (e.g.: Offline, Tamper, etc.)
        /// </summary>
        EventSourceLatchOrIsolateType LatchedAlarms
        {
            get;
        }

        /// <summary>
        /// Unlatch point alarms if latched
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        /// <returns>True if the point has been unlatched</returns>
        bool Unlatch(UserAuditInfo userAuditInfo);

        /// <summary>
        /// Unlatch point specified alarms if latched
        /// </summary>
        /// <param name="userAuditInfo">User that initiaited the restore (unlatch) command.</param>
        /// <param name="options">Latched alarms to unlatch (restore)</param>
        /// <returns>True if the point has been unlatched</returns>
        bool Unlatch(UserAuditInfo userAuditInfo, EventSourceLatchOrIsolateType options);

        /// <summary>
        /// Increment latched suspect count for specified [suspectStatusType]. 
        /// </summary>
        /// <param name="suspectStatusType">Suspect status type for which the count will be incremented</param>
        void IncrementSuspectCount(EventSourceLatchOrIsolateType suspectStatusType);

        /// <summary>
        /// Reset suspect count. 
        /// </summary>
        void ResetSuspectCount();

        /// <summary>
        /// Indicates that the status item instance is in latched state when this value is true.
        /// The status item has changed to alarm and will stay in this state, until unlatched.
        /// </summary>
        bool IsCurrentlyLatched
        {
            get;
        }

        /// <summary>
        /// Get display name for this status item instance
        /// </summary>
        /// <returns>Display Name string.</returns>
        string DisplayName
        {
            get;
        }

        /// <summary>
        /// Get status item display when alarms are present
        /// </summary>
        /// <returns>Status item display name including any alarms</returns>
        string DisplayAlarmedName
        {
            get;
        }

        /// <summary>
        /// Get status item display when isolated alarms are present
        /// </summary>
        /// <returns>Status item display name including any isolated alarms</returns>
        string DisplayIsolatedName
        {
            get;
        }

        /// <summary>
        /// Get alarm description for [alarmType], implemented for devices only, not needed for other status items.
        /// </summary>
        /// <param name="alarmType">Alarm Type: Offline, Tamper, etc.</param>
        /// <returns></returns>
        string AlarmDescription(EventSourceLatchOrIsolateType alarmType);

        /// <summary>
        /// Check if this status item has multiple alarms
        /// </summary>
        bool HasMultipleAlarms
        {
            get;
        }

        /// <summary>
        /// Check if this status item has multiple isolated alarms
        /// </summary>
        bool HasMultipleIsolatedAlarms
        {
            get;
        }

        /// <summary>
        /// Get the ConfirmedType for current alarm based on area mode and the previous unconfirmed alarm if required.
        /// </summary>
        /// <param name="unconfirmedAlarmSource">The source of an existing unconfirmed alarm, received before the current alarm.</param>
        /// <param name="areaSource">Area from which the alarm has originated</param>
        /// <returns>None, Unconfirmed or Confirmed.</returns>
        ConfirmedType GetConfirmedAlarmType(IStatusItem unconfirmedAlarmSource, IStatusItem areaSource);

        /// <summary>
        /// True if this status item can be isolated at the specifed access level
        /// </summary>
        bool CanIsolate(UserAccessLevel level);

        /// <summary>
        /// True if this status item can be de-isolated at the specifed access level
        /// </summary>
        bool CanDeisolate(UserAccessLevel level);
    }
}
