﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{
    public interface IDeviceLoopManagerFinalization
    {
        /// <summary>
        /// Shutdown device loop managed and make it stop accepting new connections.
        /// </summary>
        void Shutdown();
    }
}
