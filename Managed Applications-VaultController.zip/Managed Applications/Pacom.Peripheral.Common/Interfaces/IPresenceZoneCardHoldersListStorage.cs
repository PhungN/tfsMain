﻿using System;

namespace Pacom.Peripheral.Common
{
    public interface IPresenceZoneAntipassbackIdsList
    {
        /// <summary>
        /// Check if this presence zone contains this card / user
        /// </summary>
        /// <param name="antipassbackId">card / user id to search for</param>
        /// <returns>True if the card / user already exists, False otherwise</returns>
        bool Contains(long antipassbackId);

        /// <summary>
        /// Add card / user to this presence zone
        /// </summary>
        /// <param name="antipassbackId">card / user to add to presence zone</param>
        void Add(long antipassbackId);

        /// <summary>
        /// Remove card / user from this presence zone.
        /// </summary>
        /// <param name="antipassbackId">card / user id to remove.</param>
        void Remove(long antipassbackId);

        /// <summary>
        /// Count of cards / users in this presence zone
        /// </summary>
        int Count { get; }

        /// <summary>
        /// Perform any tidy up.
        /// </summary>
        void Cleanup();
    }
}
