﻿using System;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common
{
    public interface IDeviceStatusBase : IStatusItem
    {
        /// <summary>
        /// Get the device hardware type.
        /// </summary>
        HardwareType HardwareType
        {
            get;
        }

        /// <summary>
        /// Check if this is an Inovonics device.
        /// </summary>
        bool IsInovonicsDevice
        {
            get;
        }

        /// <summary>
        /// Get / Set device Online status
        /// </summary>
        bool Online
        {
            get;
            set;
        }

        /// <summary>
        /// Get device masked Online status
        /// </summary>
        bool MaskedOnline
        {
            get;
        }

        /// <summary>
        /// Get device Tamper status
        /// </summary>
        bool TamperActive
        {
            get;
            set;
        }

        /// <summary>
        /// Get device masked Tamper status
        /// </summary>
        bool MaskedTamperActive
        {
            get;
        }

        /// <summary>
        /// Get / Set the device serial number
        /// </summary>
        string SerialNumber
        {
            get;
            set;
        }

        /// <summary>
        /// It is time to notify the alarm manager about the device being in offline state for too long
        /// </summary>
        void NotifyDeviceOffline();
    }
}
