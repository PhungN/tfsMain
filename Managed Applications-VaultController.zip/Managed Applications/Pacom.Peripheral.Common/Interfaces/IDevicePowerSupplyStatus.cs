﻿using System;
using Pacom.Events.EventsCommon;

namespace Pacom.Peripheral.Common
{
    public interface IDevicePowerSupplyStatus
    {
        int LogicalId
        {
            get;
        }

        PowerFailState PowerState
        {
            get;
        }

        PowerFailState MaskedPowerState
        {
            get;
        }

        BatteryFailState MaskedBatteryState
        {
            get;
        }

        bool MaskedBatteryChargerFailed
        {
            get;
        }

        /// <summary>
        /// Set masked power supply status property to new value
        /// </summary>
        /// <param name="value">New status</param>
        /// <param name="acFailDelayExpired">True if AC Fail delay has expired, False otherwise</param>
        void SetMaskedPowerState(PowerFailState value, bool acFailDelayExpired);
    }
}
