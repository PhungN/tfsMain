﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{
    public interface IOsdpDeviceLoopManager
    {

    }
}
