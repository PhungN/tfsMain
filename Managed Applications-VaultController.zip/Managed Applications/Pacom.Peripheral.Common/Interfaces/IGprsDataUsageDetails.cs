﻿using System;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common
{
    public interface IGprsDataUsageDetails : IDisposable
    {
        /// <summary>
        /// Check if any data usage details are available
        /// </summary>
        bool IsValid { get; }

        /// <summary>
        /// Data Usage period start date
        /// </summary>
        DateTime StartDate { get; }

        /// <summary>
        /// Data Usage period end date
        /// </summary>
        DateTime EndDate { get; }

        /// <summary>
        /// Get next rollover date
        /// </summary>
        DateTime RolloverDate { get; }

        /// <summary>
        /// GPRS data usage frequency
        /// </summary>
        GprsDataUsageReportingFrequency Frequency { get; }

        /// <summary>
        /// Get the bytes transmitted for current period as string in format: Data Transmitted [KB]: nnn.nn
        /// </summary>
        string FormattedTransmittedData { get; }

        /// <summary>
        /// Get the bytes received for current period as string in format: Data Received [KB]: nnn.nn
        /// </summary>
        string FormattedReceivedData { get; }
    }
}
