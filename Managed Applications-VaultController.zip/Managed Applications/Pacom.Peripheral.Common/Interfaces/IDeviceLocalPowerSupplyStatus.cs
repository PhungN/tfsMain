﻿using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common
{
    public interface IDeviceLocalPowerSupplyStatus
    {
        bool BatteryTestInProgress { get; set; }

        /// <summary>
        /// Start battery load test immediately if possible. If the battery load test is currently running return False.
        /// </summary>
        /// <returns>True if the battery load test can start, False otherwise</returns>
        bool StartBatteryLoadTest();

        /// <summary>
        /// Create PowerSupplyInformation for this device
        /// </summary>
        void UpdatePowerSupplyInformation(PowerSupplyInformation powerSupplyInfo);
    }
}
