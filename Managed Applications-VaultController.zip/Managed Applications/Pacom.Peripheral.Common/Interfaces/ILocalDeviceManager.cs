﻿using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common
{
    public interface ILocalDeviceManager
    {
        /// <summary>
        /// Get local device configuration instance
        /// </summary>
        Pacom8003Configuration Configuration
        {
            get;
        }

        /// <summary>
        /// Unlock / lock local device doors after the local device is initialized.
        /// </summary>
        void LockUnlockDoors();

        /// <summary>
        /// Set / Reset local output.
        /// </summary>
        /// <param name="outputId">Physical id of the output to be set / reset.</param>
        /// <param name="newState">New output state.</param>
        void SetOutputStatus(int outputId, bool newState);
        
        /// <summary>
        /// Set / Reset local output.
        /// </summary>
        /// <param name="slot">Expansion number 1, or 2.</param>
        /// <param name="outputId">Physical id of the output to be set / reset.</param>
        /// <param name="newState">New output state.</param>
        void SetExpansionOutputStatus(int slot, int outputId, bool newState);

        /// <summary>
        /// Trigger restore of expansion card inputs
        /// </summary>
        /// <param name="logicalExpansionCardId">Logical expansion card id</param>
        void RestoreExpansionCardInputs(int logicalExpansionCardId);

        /// <summary>
        /// Function processing card read from external device
        /// </summary>
        /// <param name="cardReaderNumber">Card reader number</param>
        /// <param name="cardLength">Read card length</param>
        /// <param name="cardData">Read card bytes</param>
        void ProcessCardRead(int cardReaderNumber, int cardLength, byte[] cardData);
    }
}
