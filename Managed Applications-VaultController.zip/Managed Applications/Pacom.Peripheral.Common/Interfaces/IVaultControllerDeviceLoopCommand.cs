﻿using System;

namespace Pacom.Peripheral.Common
{
    public interface IVaultControllerDeviceLoopCommand
    {
        void GetStatus();
        void SetOutput(byte outputs);
        void SetConfiguration(VaultDisplayType displayType);
        void OpenVault(byte waitTime, byte accessTime, byte preOpenTime, byte preAlarmType);
        void CloseVault();
        void SetInterlock(bool enable);

    }

    public interface IDeviceLoopCommand
    {
        void SendCommand(byte functionCode, byte[] data);
        void SendCommand(byte functionCode, byte[] data, int offset, int count);
    }
}
