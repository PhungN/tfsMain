﻿using System;

namespace Pacom.Peripheral.Common
{
    public interface IDeviceStatus : IDeviceStatusBase
    {
        /// <summary>
        /// Get device Battery Low status
        /// </summary>
        bool InternalBatteryLow
        {
            get;
            set;
        }

        /// <summary>
        /// Get device masked Battery Low status
        /// </summary>
        bool MaskedInternalBatteryLow
        {
            get;
        }
    }
}
