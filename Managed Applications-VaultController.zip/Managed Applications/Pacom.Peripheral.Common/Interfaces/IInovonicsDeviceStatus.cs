﻿using System;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common
{
    public interface IInovonicsDeviceStatus
    {
        bool Enabled { get; }
        bool IsCurrentlyLatched { get; }
        bool Isolated { get; }
        bool MaskedOnline { get; }
        bool MaskedTamperActive { get; }
        bool Online { get; set; }
        bool TamperActive { get; }
        int LogicalId { get; }
        int ParentDeviceId { get; }
        string AlarmsAsString { get; }
        string IsolatedAlarmsAsString { get; }
        string LatchedAlarmsAsString { get; }
        string SerialNumber { get; }
        EventSourceLatchOrIsolateType CurrentAlarms { get; }
        EventSourceLatchOrIsolateType LatchedAlarms { get; }
        EventSourceLatchOrIsolateType IsolatedAlarms { get; }
        HardwareType HardwareType { get; }
        InovonicsDeviceType DeviceType { get; }
    }
}
