﻿using System;
using Pacom.Peripheral.Macros;
using Pacom.Peripheral.Common.Status;
namespace Pacom.Peripheral.Common
{
    public interface IMacroManager
    {
        void EnqueueKeyPadEvent(int deviceId, int userId, int keyId);
        void EnqueueKeyPadEvent(int deviceId, int userId);
        void EnqueueSingleBadgeEvent(int logicalReaderId, long cardId, int groupId);
        void EnqueueDoubleBadgeEvent(int logicalReaderId, long cardId, int groupId);
        void EnqueueFrontEndConnectionRestoredEvent();
        void EnqueueAreaAlarm(int logicalAreaId, MacroAreaAlarmType areaEvent, bool confirmationTimeExpired);
        void EnqueueAreaModeChanged(int logicalAreaId, int userId);
        void EnqueueAreaFailedToArmEvent(int logicalAreaId, int userId);
        void EnqueueUserAreaChanged(int logicalUserAreaId);
        void EnqueueAnyInputAlarm(int logicalInputId);
        void EnqueueAnyInputTrouble(int logicalInputId);
        void EnqueueDeviceTamperActive(int logicalDeviceId);
        void EnqueueReaderTamperActive(int logicalReaderId);
        void EnqueueDeviceSubstitution(int logicalDeviceId);
        void EnqueueUnacknowledgedAlarmsQueueEmptyEvent();
        void EnqueueShortTextMessage(string phoneNumber, string messageBody);
        void EnqueueInputTestStatus(int logicalInputId, InputTestStatus testStatus);
        void EnqueueDoorEvent(int logicalDoorId, DoorContextStatus context);
        void EnqueueInterlockEvent(int logicalInterlockId, InterlockContextStatus context, int userId, int groupId);
        event EventHandler<ExpressionInvalidEventArgs> InvalidExpression;
    }
}
