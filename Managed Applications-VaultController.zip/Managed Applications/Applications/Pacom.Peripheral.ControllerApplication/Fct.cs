﻿using System;
using System.Threading;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Protocol;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Diagnostics;
using Pacom.Configuration.ConfigurationCommon;
using System.Reflection;
using Pacom.Peripheral.AccessControl;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Applications
{
    internal class PendingMessageDisplayQueue
    {
        private readonly List<string> pendingMessageDisplayQueue = new List<string>(20);

        internal void Add(string message)
        {
            try
            {
                lock (pendingMessageDisplayQueue)
                {
                    pendingMessageDisplayQueue.Add(message);
                }
            }
            catch
            {
            }
        }

        internal void Flush()
        {
            try
            {
                lock (pendingMessageDisplayQueue)
                {
                    foreach (string message in pendingMessageDisplayQueue)
                    {
                        Console.WriteLine(message);
                    }
                    pendingMessageDisplayQueue.Clear();
                }
            }
            catch
            {
            }
        }
    }

    public static class Fct
    {
        public static UdpIPConnection connection;
        public static List<string> receivedMessages = new List<string>();
        public static AutoResetEvent receivedMessageEvent = new AutoResetEvent(false);

        private static bool unexpectedMessageReceived = false;
        private static bool unexpectedButtonPressed = false;

        private static bool resetButtonPressed = false;
        private static bool oneTouchButtonPressed = false;
        private static bool rs485MessageReceived = false;

        private static Thread fctThread;
        private static Thread fctFailedTestRetryThread;
        private static bool fctThreadSuccess = true;

        private static readonly PendingMessageDisplayQueue pendingMessageDisplayQueue = new PendingMessageDisplayQueue();

        private static bool rtcTestPart1Failed = false;
        private static bool linkTestsFailed = false;
        private static bool sramTestsFailed = false;
        private static bool dataFlashTestsFailed = false;
        private static bool expansionCardTestsFailed = false;
        private static bool alarmInputTestsFailed = false;
        private static bool boardRevisionTestFailed = false;
        private static bool rs232TestFailed = false;
        private static bool batteryTestsFailed = false;
        private static bool rtcTestPart2Failed = false;

        private static bool resetTestFailed = false;
        private static bool lanTestFailed = false;

        private static bool statusLedTestFailed = false;
        private static bool sdCardTestsFailed = false;
        private static bool rs485TestsFailed = false;
        private static bool powerAdcTestsFailed = false;
        private static bool criTestsFailed = false;
        private static bool outputTestsFailed = false;
        private static bool powerOutTestFailed = false;
        private static bool tamperTestsFailed = false;
        private static bool usbHostTestsFailed = false;

        private static void fctThreadMethod()
        {
            try
            {
                for (int i = 0; i < 8; i++)
                {
                    OnboardOutputs.ClearOutput(i);
                }
                if (performRtcTestPart1() == false)
                {
                    rtcTestPart1Failed = true;
                    fctThreadSuccess = false;
                }
                if (performButtonAndSwitchTests() == false)
                    fctThreadSuccess = false;

                Pcb.OneTouchButtonPressed += new EventHandler(Pcb_OneTouchButtonPressed);
                Pcb.ResetButtonPressed += new EventHandler(Pcb_ResetButtonPressed);

                if (performLinkTests() == false)
                {
                    linkTestsFailed = true;
                    fctThreadSuccess = false;
                }
                if (performSramTests() == false)
                {
                    sramTestsFailed = true;
                    fctThreadSuccess = false;
                }
                if (performBoardRevisionTest() == false)
                {
                    boardRevisionTestFailed = true;
                    fctThreadSuccess = false;
                }
                if (performRS232Test() == false)
                {
                    rs232TestFailed = true;
                    fctThreadSuccess = false;
                }
                if (performBatteryTests() == false)
                {
                    batteryTestsFailed = true;
                    fctThreadSuccess = false;
                }
                if (performRtcTestPart2() == false)
                {
                    rtcTestPart2Failed = true;
                    fctThreadSuccess = false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("<<-- Exception: " + ex.ToString() + " -->> ");
                fctThreadSuccess = false;
            }

            pendingMessageDisplayQueue.Flush();
        }

        private static void fctFailedTestRetryThreadMethod()
        {
            try
            {
                while (true)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        OnboardOutputs.ClearOutput(i);
                    }

                    if (resetTestFailed)
                    {
                        if (connection != null)
                        {
                            connection.Dispose();
                            connection = null;
                        }

                        performResetTest();

                        performLanTest(pendingMessageDisplayQueue);
                        pendingMessageDisplayQueue.Flush();

                        IOExpander.ConfigureInputs(IOExpanderDevice.IOExpanderU30, IOExpanderPin.Pin5 | IOExpanderPin.Pin6 | IOExpanderPin.Pin7);
                        IOExpander.ConfigureInputs(IOExpanderDevice.IOExpanderU34, IOExpanderPin.Pin3 | IOExpanderPin.Pin4 | IOExpanderPin.Pin5 | IOExpanderPin.Pin6 | IOExpanderPin.Pin7);
                    }
                    else if (lanTestFailed)
                    {
                        if (connection != null)
                        {
                            connection.Dispose();
                            connection = null;
                        }

                        performLanTest(pendingMessageDisplayQueue);
                        pendingMessageDisplayQueue.Flush();
                    }

                    if (connection == null)
                    {
                        connection = UdpIPManager.Instance.CreateConnection(3435, true);
                        connection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(connection_ConnectionStateChanged);
                        connection.DataReceived += new EventHandler<ReceivedDataEventArgs>(connection_DataReceived);
                        connection.Connect();
                    }

                    if (rtcTestPart1Failed)
                        performRtcTestPart1();
                    if (linkTestsFailed)
                        performLinkTests();
                    if (sramTestsFailed)
                        performSramTests();
                    if (dataFlashTestsFailed)
                        performDataFlashTests();
                    if (expansionCardTestsFailed)
                        performExpansionCardTests();
                    if (alarmInputTestsFailed)
                        performAlarmInputTests();
                    if (boardRevisionTestFailed)
                        performBoardRevisionTest();
                    if (rs232TestFailed)
                        performRS232Test();
                    if (batteryTestsFailed)
                        performBatteryTests();
                    if (rtcTestPart2Failed)
                        performRtcTestPart2();

                    if (statusLedTestFailed)
                        performStatusLedTest();
                    if (sdCardTestsFailed)
                        performSDCardTests();
                    if (rs485TestsFailed)
                        performRS485Tests();
                    if (powerAdcTestsFailed)
                        performPowerAdcTests();
                    if (criTestsFailed)
                        performCriTests();
                    if (outputTestsFailed)
                        performOutputTests();
                    if (powerOutTestFailed)
                        performPowerOutTest();
                    if (tamperTestsFailed)
                        performTamperTests();
                    if (usbHostTestsFailed)
                        performUsbHostTests();

                    Console.WriteLine("<<-- Pacom 8003 Test Failed -->> ");
                    Console.WriteLine("<<-- ------------------------- -->> ");
                    Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("<<-- Exception: " + ex.ToString() + " -->> ");
                fctThreadSuccess = false;
            }
        }

        public static void PerformFct()
        {
            FileSystemPaths.IsFct = true;

            // Disable firewall for FCT
            NativeFirewallApi.AddFirewallRule("FCT UDP Inbound", 3435, 3435, NativeProtocolType.UDP, RuleDirectionType.FWF_INBOUND);

            Console.WriteLine("<<-- Pacom 8003 Functional Test " + Assembly.GetExecutingAssembly().GetName().Version + " -->> ");

            bool success = true;
            bool runTests = true;
            try
            {
                if (DataFlashSerialPage.FctPassedOk && hasValidSerialNumber() == false)
                {
                    // We've previously passed the FCT on this board, but it doesn't have a 
                    // serial number yet, so first offer to just set the serial number
                    if (askYesNoQuestion("Press \"Yes\" to set serial number, \"No\" to run FCT"))
                    {
                        runTests = false;
                        createConnectionToMasterUnit();
                    }
                }

                if (runTests)
                {
                    // Prepare watchdog polling thread.
                    WatchdogTimer.CreateInstance(WatchdogType.Managed);
                    WatchdogTimer.Instance.ToggleAction(WatchdogTimer_InputToggleRequired);
                    WatchdogTimer.Instance.EnableWatchdogTimer();

                    if (performResetTest() == false)
                    {
                        resetTestFailed = true;
                        success = false;
                    }

                    fctThread = new Thread(new ThreadStart(fctThreadMethod));
                    fctThread.Name = "FCT Thread";
                    fctThread.IsBackground = true;
                    fctThread.Priority = ThreadPriority.Normal;
                    fctThread.Start();

                    // Initialise storage
                    try
                    {
                        pendingMessageDisplayQueue.Add("<<-- Formatting the NAND Flash -->> ");
                        StoreManager.CreateInstance();
                        if (StoreManager.Instance.RestoreDisks() == true)
                        {
                            // Recreate logs directory
                            if (Directory.Exists("\\PublicRegion\\Logs") == false)
                                Directory.CreateDirectory("\\PublicRegion\\Logs");
                        }
                        else
                        {
                            Application.Closing = true;
                            Thread.Sleep(100);
                            // Make status Led red
                            Gpio.ClearOutput(GpioPort.PortC, 7);
                            Gpio.SetOutput(GpioPort.PortC, 6);
                            Hal.WatchdogTimer.Instance.Dispose();
                            while (true) ;
                        }
                    }
                    catch
                    {
                        pendingMessageDisplayQueue.Add("<<-- BOOT: Fatal error while restoring storage devices. -->> ");
                        Application.Closing = true;
                        Thread.Sleep(100);
                        // Make status Led red
                        Gpio.ClearOutput(GpioPort.PortC, 7);
                        Gpio.SetOutput(GpioPort.PortC, 6);
                        Hal.WatchdogTimer.Instance.Dispose();
                        while (true) ;
                    }

                    Common.SQLCE.SqlCeDatabase.CreateInstance();
                    TimerManager.CreateInstance();

                    NetworkAdapter.CreateInstance();
                    AccessCardManager.CreateInstance();
                    ConfigurationManager.CreateInstance(Sram.Instance, DataFlash.Instance, NetworkAdapter.Instance, AccessCardManager.Instance, Adc.CreateInstance());
                    ConfigurationManager.Instance.Initialize(ConfigurationUpdateReason.Initial, ConfigurationElementsAffected.All, ConfigurationManager.SystemUser);
                    StatusManager.CreateInstance(Sram.Instance, DataFlash.Instance, AccessCardManager.Instance);

                    if (performLanTest(pendingMessageDisplayQueue) == false)
                    {
                        lanTestFailed = true;
                        success = false;
                    }

                    createConnectionToMasterUnit();

                    fctThread.Join();
                    if (fctThreadSuccess == false)
                        success = false;
                    pendingMessageDisplayQueue.Flush();

                    if (performExpansionCardTests() == false)
                    {
                        expansionCardTestsFailed = true;
                        success = false;
                    }
                    if (performAlarmInputTests() == false)
                    {
                        alarmInputTestsFailed = true;
                        success = false;
                    }
                    if (performDataFlashTests() == false)
                    {
                        dataFlashTestsFailed = true;
                        success = false;
                    }
                    if (performStatusLedTest() == false)
                    {
                        statusLedTestFailed = true;
                        success = false;
                    }
                    if (performSDCardTests() == false)
                    {
                        sdCardTestsFailed = true;
                        success = false;
                    }
                    if (performRS485Tests() == false)
                    {
                        rs485TestsFailed = true;
                        success = false;
                    }
                    if (performPowerAdcTests() == false)
                    {
                        powerAdcTestsFailed = true;
                        success = false;
                    }
                    if (performCriTests() == false)
                    {
                        criTestsFailed = true;
                        success = false;
                    }
                    if (performOutputTests() == false)
                    {
                        outputTestsFailed = true;
                        success = false;
                    }
                    if (performPowerOutTest() == false)
                    {
                        powerOutTestFailed = true;
                        success = false;
                    }
                    if (performTamperTests() == false)
                    {
                        tamperTestsFailed = true;
                        success = false;
                    }
                    if (performUsbHostTests() == false)
                    {
                        usbHostTestsFailed = true;
                        success = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("<<-- Exception: " + ex.ToString() + " -->> ");
                success = false;
            }

            setMasterUnitOutput(2, true);
            if (success == false || unexpectedMessageReceived == true || unexpectedButtonPressed == true)
            {
                DataFlashSerialPage.SetFctPassedOk(false);
                Console.WriteLine("<<-- Pacom 8003 Test Failed -->> ");
                Console.WriteLine("<<-- ------------------------- -->> ");

                fctFailedTestRetryThread = new Thread(new ThreadStart(fctFailedTestRetryThreadMethod));
                fctFailedTestRetryThread.Name = "FCT Failed Test Retry Thread";
                fctFailedTestRetryThread.IsBackground = true;
                fctFailedTestRetryThread.Priority = ThreadPriority.Normal;
                fctFailedTestRetryThread.Start();
            }
            else
            {
                DataFlashSerialPage.SetFctPassedOk(true);
                updateSerialNumber();
                setMasterUnitOutput(2, true);
                Console.WriteLine("<<-- Pacom 8003 Tested Okay -->> ");
                Console.WriteLine("<<-- ------------------------- -->> ");
            }

            // Loop forever so that the watchdog timer won't cause a reboot.
            while (true)
            {
                if (success)
                    setMasterUnitOutput(3, true);
                else
                    setMasterUnitOutput(4, true);
                Thread.Sleep(200);
            }
        }

        private static void createConnectionToMasterUnit()
        {
            UdpIPManager.CreateInstance();
            connection = new UdpIPManager().CreateConnection(3435, true);
            connection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(connection_ConnectionStateChanged);
            connection.DataReceived += new EventHandler<ReceivedDataEventArgs>(connection_DataReceived);
            connection.Connect();
        }

        private static bool performRtcTestPart1()
        {
            Console.WriteLine("<<-- Performing Real Time Clock Test Part 1. -->> ");

            if (I2c.WriteToDevice(0x68, 0, 1, new byte[] { 0, 0, 1, 2, 3, 4, 5, 0 }) == false)
            {
                Console.WriteLine("<<-- Failed Writing to Real Time Clock Data. Real Time Clock Test Part 1 Failed. (check U33, Y4, R257, R255) -->> ");
                return false;
            }

            if (I2c.WriteToDevice(0x68, 9, 1, new byte[] { 0 }) == false)
            {
                Console.WriteLine("<<-- Failed Writing to Real Time Clock Data. Real Time Clock Test Part 1 Failed. (check U33, Y4, R257, R255) -->> ");
                return false;
            }

            byte[] rtcData = new byte[10];
            if (I2c.ReadFromDevice(0x68, 0, 1, rtcData) == false)
            {
                Console.WriteLine("<<-- Failed Reading Real Time Clock Data. Real Time Clock Test Part 1 Failed. (check U33, Y4, R257, R255) -->> ");
                return false;
            }

            if (rtcData[2] != 1 || rtcData[3] != 2 || rtcData[4] != 3 || rtcData[5] != 4 || rtcData[6] != 5 || rtcData[9] != 0)
            {
                Console.WriteLine("<<-- Failed Verifying Real Time Clock Data. (" + BitConverter.ToString(rtcData) + ") Real Time Clock Test Part 1 Failed. (check U33, Y4, R257, R255) -->> ");
                return false;
            }

            Console.WriteLine("<<-- Real Time Clock Test Part 1 Passed. -->> ");
            return true;
        }

        private static bool performRtcTestPart2()
        {
            Console.WriteLine("<<-- Performing Real Time Clock Test Part 2. -->> ");

            byte[] rtcData = new byte[10];
            if (I2c.ReadFromDevice(0x68, 0, 1, rtcData) == false)
            {
                Console.WriteLine("<<-- Failed Reading Real Time Clock Data. Real Time Clock Test Part 1 Failed. (check U33, Y4, R257, R255) -->> ");
                return false;
            }

            if (rtcData[0] == 0 && rtcData[1] == 0)
            {
                Console.WriteLine("<<-- Real Time Clock is Not Running. Real Time Clock Test Part 2 Failed. (check U33, Y4, R257, R255) -->> ");
                return false;
            }

            Console.WriteLine("<<-- Real Time Clock Test Part 2 Passed. -->> ");
            return true;
        }

        private static bool performLanTest(PendingMessageDisplayQueue pendingMessageDisplayQueue)
        {
            pendingMessageDisplayQueue.Add("<<-- Performing LAN Test. -->> ");

            uint startTime = (uint)Environment.TickCount;
            for (int i = 0; i < 20000; i++)
            {
                if (Ping.PingAddress(IPAddress.Parse("10.1.1.2")) == true)
                {
                    pendingMessageDisplayQueue.Add("<<-- LAN Test Passed. -->> ");
                    return true;
                }
                if (((uint)Environment.TickCount - startTime) > 200000)
                    break;
                Thread.Sleep(10);
            }

            pendingMessageDisplayQueue.Add("<<-- No Ping Reply. LAN Test Failed. (check U13, Y1, ETH1, C46, C48, R62, R60, R58, R59, R49, R61, R57, R51, R54, R56, R48) -->> ");
            return false;
        }

        private static bool performPowerOutTest()
        {
            Console.WriteLine("<<-- Performing Power Feed Out Test. -->> ");

            int reading = readMasterUnitInput(0, true, 3);
            if (reading < 700)
            {
                Console.WriteLine("<<-- Power Feed Out Test Failed. (" + reading + ") (check F1, F7, D21, R43, R42) -->> ");
                return false;
            }

            Console.WriteLine("<<-- Power Feed Out Passed. -->> ");
            return true;
        }
        
        private static bool performBoardRevisionTest()
        {
            Console.WriteLine("<<-- Performing Board Revision Test. -->> ");

            if (Pcb.Version != 1)
            {
                Console.WriteLine("<<-- Board Revision Read Failed. Board Revision Test Failed. (check U34, R261, R270, R267, R273, R258, R262, R268, R269) -->> ");
                return false;
            }

            Console.WriteLine("<<-- Board Revision Test Passed. -->> ");
            return true;
        }

        private static bool performTamperTests()
        {
            Console.WriteLine("<<-- Performing Tamper Detection Tests. -->> ");

            bool instantaneousTamperStatus;
            Gpio.GetInput(GpioPort.PortB, 30, out instantaneousTamperStatus);
            if (instantaneousTamperStatus == false)
            {
                Console.WriteLine("<<-- Tamper Detection Falsely. Tamper Detection Test Failed. (check R8, R13) -->> ");
                return false;
            }
            setMasterUnitOutput(1, true);
            Gpio.GetInput(GpioPort.PortB, 30, out instantaneousTamperStatus);
            if (instantaneousTamperStatus)
            {
                Console.WriteLine("<<-- Tamper Detection Failed. Tamper Detection Test Failed. (check R8, R13) -->> ");
                return false;
            }
            setMasterUnitOutput(1, false);

            Console.WriteLine("<<-- Tamper Detection Tests Passed. -->> ");
            return true;
        }

        private static bool performStatusLedTest()
        {
            int offValue;
            int greenValue;
            int redValue;

            Console.WriteLine("<<-- Performing Status LED Test. -->> ");

            // Turn status LED off
            Gpio.ClearPortOutputs(GpioPort.PortC, 0xC0);
            offValue = readMasterUnitInput(1, true, 3);
            if (offValue == -1)
                return false;

            // Turn status LED green
            Gpio.ClearOutput(GpioPort.PortC, 6);
            Gpio.SetOutput(GpioPort.PortC, 7);
            greenValue = readMasterUnitInput(1, true, 3);
            if (greenValue == -1)
                return false;

            if (greenValue - offValue < 20)
            {
                Console.WriteLine("<<-- Status LED Test Failed. Green LED didn't light up. (check ambient light, U22, R215, R219, BI-LED1) -->> ");
                return false;
            }

            // Turn status LED red
            Gpio.ClearOutput(GpioPort.PortC, 7);
            Gpio.SetOutput(GpioPort.PortC, 6);
            redValue = readMasterUnitInput(1, true, 3);
            if (redValue == -1)
                return false;

            if (redValue - offValue < 20)
            {
                Console.WriteLine("<<-- Status LED Test Failed. Red LED didn't light up. (check ambient light, U22, R214, R220, BI-LED1) -->> ");
                return false;
            }

            // Turn status LED off
            Gpio.ClearPortOutputs(GpioPort.PortC, 0xC0);

            Console.WriteLine("<<-- Status LED Test Passed. -->> ");
            return true;
        }

        private static bool performLinkTests()
        {
            bool fctInput;
            bool eraseBootloaderInput;

            Console.WriteLine("<<-- Performing Link Tests. -->> ");

            OnboardOutputs.SetOutput(0);
            for (int i = 0; i < 3000; i++)
            {
                Hal.Gpio.GetInput(GpioPort.PortB, 18, out eraseBootloaderInput);
                if (eraseBootloaderInput == false)
                    break;
                Thread.Sleep(1);
            }
            Hal.Gpio.GetInput(GpioPort.PortB, 18, out eraseBootloaderInput);
            if (eraseBootloaderInput)
            {
                Console.WriteLine("<<-- Link Test Failed. LNK9 didn't read correctly. (check jumper on LNK9 is not present, U30, Q13, D22, REL1, LED6, R187, R188,  R249, R232, R234) -->> ");
                return false;
            }
            OnboardOutputs.ClearOutput(0);
            for (int i = 0; i < 3000; i++)
            {
                Hal.Gpio.GetInput(GpioPort.PortB, 18, out eraseBootloaderInput);
                if (eraseBootloaderInput)
                    break;
                Thread.Sleep(1);
            }
            Hal.Gpio.GetInput(GpioPort.PortB, 18, out eraseBootloaderInput);
            if (eraseBootloaderInput == false)
            {
                Console.WriteLine("<<-- Link Test Failed. LNK9 didn't read correctly. (check jumper on LNK9 is not present, U30, Q13, D22, REL1, LED6, R187, R188,  R249, R232, R234) -->> ");
                return false;
            }

            OnboardOutputs.SetOutput(1);
            for (int i = 0; i < 3000; i++)
            {
                Hal.Gpio.GetInput(GpioPort.PortC, 1, out fctInput);
                if (fctInput)
                    break;
                Thread.Sleep(1);
            }
            Hal.Gpio.GetInput(GpioPort.PortC, 1, out fctInput);
            if (fctInput == false)
            {
                Console.WriteLine("<<-- Link Test Failed. LNK7 didn't read correctly. (check jumper on LNK7 is not present, U30, Q14, D23, REL2, LED7, R198, R202,  R245, R232, R234) -->> ");
                return false;
            }
            OnboardOutputs.ClearOutput(1);
            for (int i = 0; i < 3000; i++)
            {
                Hal.Gpio.GetInput(GpioPort.PortC, 1, out fctInput);
                if (fctInput == false)
                    break;
                Thread.Sleep(1);
            }
            Hal.Gpio.GetInput(GpioPort.PortC, 1, out fctInput);
            if (fctInput)
            {
                Console.WriteLine("<<-- Link Test Failed. LNK7 didn't read correctly. (check jumper on LNK7 is not present, U30, Q14, D23, REL2, LED7, R198, R202,  R245, R232, R234) -->> ");
                return false;
            }

            Console.WriteLine("<<-- Link Tests Passed. -->> ");
            return true;
        }
        
        private static bool performRS232Test()
        {
            bool success = false;
            Console.WriteLine("<<-- Performing RS232 Tests. -->> ");

            SerialManager serialManager = new SerialManager();
            Serial232Connection serialConnection = (Serial232Connection)serialManager.CreateConnection(PhysicalSerialType.RS232, PhysicalSerialPort.OnboardRS232Port, 115200, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);
            serialConnection.Connect();

            serialConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(serialConnection_DataReceived);
            serialConnection.Send(ASCIIEncoding.ASCII.GetBytes("%%echo fct message%%"), new Dictionary<string, object>());

            for (int i = 0; i < 5000; i++)
            {
                if (rs232ReceivedData.Length == rs232ExpectedResponse.Length && ASCIIEncoding.ASCII.GetString(rs232ReceivedData, 0, rs232ReceivedData.Length) == rs232ExpectedResponse)
                {
                    success = true;
                    break;
                }
                Thread.Sleep(1);
            }
            serialConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(serialConnection_DataReceived);
            serialConnection.Dispose();
            serialConnection = null;

            if (success)
                Console.WriteLine("<<-- RS232 Tests Passed. -->> ");
            else
                Console.WriteLine("<<-- RS232 Test Failed. (check U17, C61, C59, C148, U16, U16, R166, LED3, R195, R167, LED4, C131) -->> ");
            return success;
        }

        const string rs232ExpectedResponse = "%%reply fct message%%";
        static byte[] rs232ReceivedData = new byte[0];
        static void serialConnection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            byte[] data = new byte[rs232ReceivedData.Length + e.Data.Length];
            Buffer.BlockCopy(rs232ReceivedData, 0, data, 0, rs232ReceivedData.Length);
            Buffer.BlockCopy(e.Data, 0, data, rs232ReceivedData.Length, e.Data.Length);
            rs232ReceivedData = data;
        }

        static byte[] rs232SerialNumberReceivedData = new byte[0];
        static void serialConnection_SerialNumberDataReceived(object sender, ReceivedDataEventArgs e)
        {
            byte[] data = new byte[rs232SerialNumberReceivedData.Length + e.Data.Length];
            Buffer.BlockCopy(rs232SerialNumberReceivedData, 0, data, 0, rs232SerialNumberReceivedData.Length);
            Buffer.BlockCopy(e.Data, 0, data, rs232SerialNumberReceivedData.Length, e.Data.Length);
            rs232SerialNumberReceivedData = data;
        }

        static byte[] yesNoReceivedData = new byte[0];
        static void serialConnection_YesNoDataReceived(object sender, ReceivedDataEventArgs e)
        {
            byte[] data = new byte[yesNoReceivedData.Length + e.Data.Length];
            Buffer.BlockCopy(yesNoReceivedData, 0, data, 0, yesNoReceivedData.Length);
            Buffer.BlockCopy(e.Data, 0, data, yesNoReceivedData.Length, e.Data.Length);
            yesNoReceivedData = data;
        }

        private static bool performButtonAndSwitchTests()
        {
            Console.WriteLine("<<-- Performing Button and Switch Tests. -->> ");

            Pcb.OneTouchButtonPressed += new EventHandler(Pcb_OneTouchButtonPressedUnderTest);
            Pcb.ResetButtonPressed += new EventHandler(Pcb_ResetButtonPressedUnderTest);

            Console.WriteLine("<<-- Please Press RST (SW3) Button -->> ");
            resetButtonPressed = false;
            while (true)
            {
                if (resetButtonPressed)
                    break;
                Thread.Sleep(1);
            }

            Console.WriteLine("<<-- Please Press General Purpose (SW2) Button -->> ");
            oneTouchButtonPressed = false;
            while (true)
            {
                if (oneTouchButtonPressed)
                    break;
                Thread.Sleep(1);
            }

            if (Pcb.DipSwitch1Pin1)
            {
                Console.WriteLine("<<-- Please Turn OFF SW1-1 -->> ");
                while (Pcb.DipSwitch1Pin1)
                {
                    Thread.Sleep(1);
                }
            }
            else
            {
                Console.WriteLine("<<-- Please Turn ON SW1-1 -->> ");
                while (Pcb.DipSwitch1Pin1 == false)
                {
                    Thread.Sleep(1);
                }
                Console.WriteLine("<<-- Please Turn OFF SW1-1 -->> ");
                while (Pcb.DipSwitch1Pin1)
                {
                    Thread.Sleep(1);
                }
            }

            if (Pcb.DipSwitch1Pin2)
            {
                Console.WriteLine("<<-- Please Turn OFF SW1-2 -->> ");
                while (Pcb.DipSwitch1Pin2)
                {
                    Thread.Sleep(1);
                }
            }
            else
            {
                Console.WriteLine("<<-- Please Turn ON SW1-2 -->> ");
                while (Pcb.DipSwitch1Pin2 == false)
                {
                    Thread.Sleep(1);
                }
                Console.WriteLine("<<-- Please Turn OFF SW1-2 -->> ");
                while (Pcb.DipSwitch1Pin2)
                {
                    Thread.Sleep(1);
                }
            }

            Console.WriteLine("<<-- Button and Switch Tests Passed. -->> ");

            return true;
        }

        private static bool performSramTests()
        {
            Console.WriteLine("<<-- Performing SRAM Tests. -->> ");

            byte[] data = new byte[1024 * 1024];
            byte[] dataVerify = new byte[1024 * 1024];
            for (int i = 0; i < data.Length; i++)
            {
                data[i] = 0;
            }
            Sram.Instance.WriteData(0, data);
            Sram.Instance.ReadData(0, dataVerify);
            for (int i = 0; i < data.Length; i++)
            {
                if (dataVerify[i] != 0)
                {
                    Console.WriteLine("<<-- Failed RW 0 Test. SRAM Tests Failed. (check U8, U21, C159, C160, R137, R150, R160, R162, R151, R157) -->> ");
                    return false;
                }
                data[i] = 0xFF;
            }

            Sram.Instance.WriteData(0, data);
            Sram.Instance.ReadData(0, dataVerify);
            for (int i = 0; i < data.Length; i++)
            {
                if (dataVerify[i] != 0xFF)
                {
                    Console.WriteLine("<<-- Failed RW FF Test. SRAM Tests Failed. (check U8, U21, C159, C160, R137, R150, R160, R162, R151, R157) -->> ");
                    return false;
                }
                data[i] = (byte)i;
            }

            Sram.Instance.WriteData(0, data);
            Sram.Instance.ReadData(0, dataVerify);

            if (data.SequenceEqual(dataVerify) == false)
            {
                Console.WriteLine("<<-- Failed RW Random Test. SRAM Tests Failed. (check U8, U21, C159, C160, R137, R150, R160, R162, R151, R157) -->> ");
                return false;
            }

            Console.WriteLine("<<-- SRAM Tests Passed. -->> ");

            return true;
        }

        private static bool performDataFlashTests()
        {
            Console.WriteLine("<<-- Performing DataFlash Tests. -->> ");

            IDataFlash dataFlash = DataFlash.Instance;
            byte[] serialNum = DataFlashSerialPage.SerialNumber;
            if (serialNum == null)
            {
                Console.WriteLine("<<-- DataFlash Read Failed. DataFlash Tests Failed. (check U18, U14, U25, U23, C136, C164, C165, C174, C168, R192, R191, R205, R226) -->> ");
                return false;
            }

            string serialNumber = ASCIIEncoding.ASCII.GetString(serialNum, 0, serialNum.Length);
            if (
                serialNum[0] < '0' || serialNum[0] > '9' ||
                serialNum[1] < '0' || serialNum[1] > '9' ||
                serialNum[2] < '0' || serialNum[2] > '9' ||
                serialNum[4] != '-' ||
                serialNum[5] < '0' || serialNum[5] > '9' ||
                serialNum[6] < '0' || serialNum[6] > '9' ||
                serialNum[7] < '0' || serialNum[7] > '9' ||
                serialNum[8] < '0' || serialNum[8] > '9' ||
                serialNum[9] != '-' ||
                serialNum[10] < '0' || serialNum[10] > '9' ||
                serialNum[11] < '0' || serialNum[11] > '9' ||
                serialNum[12] < '0' || serialNum[12] > '9' ||
                serialNum[13] < '0' || serialNum[13] > '9' ||
                serialNum[14] < '0' || serialNum[14] > '9' ||
                serialNum[15] < '0' || serialNum[15] > '9'
                )
            {
                Console.WriteLine("<<-- Serial Number Read Failed. DataFlash Tests Failed. (" + serialNumber + ") -->> ");
                return false;
            }

            byte[] data = new byte[DataFlash.PageSize];
            new Random().NextBytes(data);
            if (dataFlash.WriteData((1024 * 1024) - DataFlash.PageSize, data) == false)
            {
                Console.WriteLine("<<-- DataFlash Write Failed. DataFlash Tests Failed. (check U18, U14, U25, U23, C136, C164, C165, C174, C168, R192, R191, R205, R226) -->> ");
                return false;
            }
            
            byte[] dataVerify = new byte[DataFlash.PageSize];
            if (dataFlash.ReadData((1024 * 1024) - DataFlash.PageSize, dataVerify) == false)
            {
                Console.WriteLine("<<-- DataFlash Read Failed. DataFlash Tests Failed. (check U18, U14, U25, U23, C136, C164, C165, C174, C168, R192, R191, R205, R226) -->> ");
                return false;
            }

            if (data.SequenceEqual(dataVerify) == false)
            {
                Console.WriteLine("<<-- DataFlash Read Verify Failed. DataFlash Tests Failed. (check U18, U14, U25, U23, C136, C164, C165, C174, C168, R192, R191, R205, R226) -->> ");
                return false;
            }

            Console.WriteLine("<<-- DataFlash Tests Passed. (" + serialNumber + ") -->> ");
            return true;
        }

        private static bool performSDCardTests()
        {
            Console.WriteLine("<<-- Performing SD Card Tests. -->> ");

            bool sdPresentInput;

            Hal.Gpio.GetInput(GpioPort.PortA, Constants.SdCardPresent, out sdPresentInput);

            if (sdPresentInput == false)
            {
                Console.WriteLine("<<-- SD Card Not Present. SD Card Tests Failed. (check CN15) -->> ");
                return false;
            }

            if (File.Exists("\\SDRegion\\Test.txt") == false)
            {
                Console.WriteLine("<<-- Failed reading from SD Card. SD Card Tests Failed. (check CN15, U18, C153, RN1, R201) -->> ");
                return false;
            }

            using (FileStream fs = new FileStream("\\SDRegion\\Test.txt", FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.Read))
            {
                using (StreamReader sr = new StreamReader(fs))
                {
                    string line = sr.ReadLine();

                    if (line != "Pacom FCT")
                    {
                        Console.WriteLine("<<-- Failed reading contents of file from SD Card. SD Card Tests Failed. (check CN15, U18, C153, RN1, R201) -->> ");
                        return false;
                    }
                }
            }

            Console.WriteLine("<<-- SD Card Tests Passed. -->> ");
            return true;
        }

        private static bool performUsbHostTests()
        {
            Console.WriteLine("<<-- Performing USB Host Tests. -->> ");

            for (int i = 0; i < 10000; i++)
            {
                if (File.Exists("\\Hard Disk\\USBHost.txt"))
                    break;
            }

            if (File.Exists("\\Hard Disk\\USBHost.txt") == false)
            {
                Console.WriteLine("<<-- Failed reading from USB Host. USB Host Tests Failed. (check USB Flash Drive, CN13, U36, D24, R266, R265) -->> ");
                return false;
            }

            using (FileStream fs = new FileStream("\\Hard Disk\\USBHost.txt", FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.Read))
            {
                using (StreamReader sr = new StreamReader(fs))
                {
                    string line = sr.ReadLine();

                    if (line != "Pacom FCT")
                    {
                        Console.WriteLine("<<-- Failed reading contents of file from USB Host. USB Host Tests Failed. (check USB Flash Drive, CN13, U36, D24, R266, R265) -->> ");
                        return false;
                    }
                }
            }

            Console.WriteLine("<<-- USB Host Tests Passed. -->> ");
            return true;
        }

        private static bool performRS485Tests()
        {
            Console.WriteLine("<<-- Performing RS485 Test. -->> ");

            Serial485Connection connection = (Serial485Connection)(new SerialManager().CreateConnection(PhysicalSerialType.RS485, PhysicalSerialPort.OnboardRS485Port, 38400, System.IO.Ports.Parity.Even, 8, System.IO.Ports.StopBits.One));
            connection.DataReceived += new EventHandler<ReceivedDataEventArgs>(rs485connection_DataReceived);
            connection.Connect();

            verifyNoReceivedMessages();
            if (connection.Send(ASCIIEncoding.ASCII.GetBytes("Pacom FCT"), new Dictionary<string, object>()) == false)
            {
                Console.WriteLine("<<-- RS485 Fail Sending. RS485 Test Failed. (check U7, U9, F8, F9, C101, C40, R161, R155, R149, R164, R146, R148, R142) -->> ");
                connection.Dispose();
                return false;
            }

            bool success = false;
            while (true)
            {
                if (receivedMessageEvent.WaitOne(500, false))
                {
                    lock (receivedMessages)
                    {
                        while (receivedMessages.Count > 0)
                        {
                            if (receivedMessages[0] == "<485 5061636F6D20464354>")
                            {
                                success = true;
                                receivedMessages.RemoveAt(0);
                                break;
                            }
                        }
                    }
                    if (success)
                        break;
                }
                else
                {
                    break;
                }
            }
            if (success == false)
            {
                Console.WriteLine("<<-- RS485 Failed Verifying Sent Data. RS485 Test Failed. (check U7, U9, F8, F9, C101, C40, R161, R155, R149, R164, R146, R148, R142) -->> ");
                connection.Dispose();
                return false;
            }

            verifyNoReceivedMessages();

            rs485MessageReceived = false;
            string message = "<485 544346206D6F636150>";
            sendMessage(message);

            bool ackReceived = false;
            while (true)
            {
                if (receivedMessageEvent.WaitOne(500, false))
                {
                    lock (receivedMessages)
                    {
                        while (receivedMessages.Count > 0)
                        {
                            if (receivedMessages[0] == "<Ack>")
                            {
                                ackReceived = true;
                            }
                            receivedMessages.RemoveAt(0);
                        }
                    }
                    if (ackReceived)
                        break;
                }
                else
                {
                    break;
                }
            }

            for (int i = 0; i < 2000; i++)
            {
                if (rs485MessageReceived)
                    break;
            }
            if (rs485MessageReceived == false)
            {
                Console.WriteLine("<<-- RS485 Failed Receiving Data. RS485 Test Failed. (check U7, U9, F8, F9, C101, C40, R161, R155, R149, R164, R146, R148, R142) -->> ");
                ThreadPool.QueueUserWorkItem(new WaitCallback(disposeConnectionMethod), connection);
                return false;
            }

            ThreadPool.QueueUserWorkItem(new WaitCallback(disposeConnectionMethod), connection);

            Console.WriteLine("<<-- RS485 Test Passed. -->> ");
            return true;
        }

        private static bool performExpansionCardTests()
        {
            Console.WriteLine("<<-- Performing Expansion Card Tests. -->> ");

            ExpansionCardManager expansionCardManager = ExpansionCardManager.CreateInstance();

            if (expansionCardManager.GetExpansionCardType(0) != ExpansionCardType.Pacom8203OutputCard)
            {
                Console.WriteLine("<<-- Can't Detect Output Card in Expansion Slot 1. Expansion Card Test Failed. (check EXP1, VAR2, R136, R131, R130) -->> ");
                return false;
            }
            if (expansionCardManager.GetExpansionCardType(1) != ExpansionCardType.Pacom8203OutputCard)
            {
                Console.WriteLine("<<-- Can't Detect Output Card in Expansion Slot 2. Expansion Card Test Failed. (check EXP2, VAR4, R89, R88, R92) -->> ");
                return false;
            }

            // Expansion Slot Uarts
            Serial232Connection connection1 = (Serial232Connection)(new SerialManager().CreateConnection(PhysicalSerialType.RS232, PhysicalSerialPort.ExpansionCard1, 115200, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One));
            Serial232Connection connection2 = (Serial232Connection)(new SerialManager().CreateConnection(PhysicalSerialType.RS232, PhysicalSerialPort.ExpansionCard2, 115200, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One));

            connection1.DataReceived += new EventHandler<ReceivedDataEventArgs>(connection1_DataReceived);
            connection2.DataReceived += new EventHandler<ReceivedDataEventArgs>(connection2_DataReceived);

            connection1.Connect();
            connection2.Connect();

            connection1.Send(new byte[] { 0xAA, 0x55, 0x11, 0x22 }, new Dictionary<string, object>());
            connection2.Send(new byte[] { 0xAA, 0x55, 0x11, 0x33, 0x44 }, new Dictionary<string, object>());

            for (int i = 0; i < 5000; i++)
            {
                if (expansion1ValidDataReceived && expansion2ValidDataReceived)
                    break;
                Thread.Sleep(1);
            }

            if (expansion1ValidDataReceived == false || expansion2ValidDataReceived == false)
            {
                Console.WriteLine("<<-- Expansion Port Uarts Failed to Receive Valid Data. Expansion Card Test Failed. (check EXP1, EXP2, RN15, RN12) -->> ");
                ThreadPool.QueueUserWorkItem(new WaitCallback(disposeConnectionMethod), connection1);
                ThreadPool.QueueUserWorkItem(new WaitCallback(disposeConnectionMethod), connection2);
                return false;
            }

            ThreadPool.QueueUserWorkItem(new WaitCallback(disposeConnectionMethod), connection1);
            ThreadPool.QueueUserWorkItem(new WaitCallback(disposeConnectionMethod), connection2);

            // Expansion Slot IO
            bool input1;
            bool input2;
            bool input3;
            bool input4;
            bool input5;

            Gpio.ConfigurePin(GpioPort.PortC, 2, false, false, false);
            Gpio.ConfigurePin(GpioPort.PortC, 10, false, false, false);
            Gpio.ConfigurePin(GpioPort.PortC, 15, false, false, false);
            Gpio.ConfigurePin(GpioPort.PortC, 4, false, false, false);
            Gpio.ConfigurePin(GpioPort.PortC, 0, false, false, false);

            Gpio.ConfigurePin(GpioPort.PortB, 26, true, false, false);
            Gpio.ConfigurePin(GpioPort.PortB, 27, true, false, false);
            Gpio.ConfigurePin(GpioPort.PortB, 23, true, false, false);
            Gpio.ConfigurePin(GpioPort.PortB, 24, true, false, false);
            Gpio.ConfigurePin(GpioPort.PortB, 25, true, false, false);

            for (int i = 0; i < 6; i++)
            {
                bool expectedInput1 = false;
                bool expectedInput2 = false;
                bool expectedInput3 = false;
                bool expectedInput4 = false;
                bool expectedInput5 = false;

                if (i == 1)
                {
                    Gpio.SetOutput(GpioPort.PortB, 26);
                    expectedInput1 = true;
                }
                else
                {
                    Gpio.ClearOutput(GpioPort.PortB, 26);
                }
                if (i == 2)
                {
                    Gpio.SetOutput(GpioPort.PortB, 27);
                    expectedInput2 = true;
                }
                else
                {
                    Gpio.ClearOutput(GpioPort.PortB, 27);
                }
                if (i == 3)
                {
                    Gpio.SetOutput(GpioPort.PortB, 23);
                    expectedInput3 = true;
                }
                else
                {
                    Gpio.ClearOutput(GpioPort.PortB, 23);
                }
                if (i == 4)
                {
                    Gpio.SetOutput(GpioPort.PortB, 24);
                    expectedInput4 = true;
                }
                else
                {
                    Gpio.ClearOutput(GpioPort.PortB, 24);
                }
                if (i == 5)
                {
                    Gpio.SetOutput(GpioPort.PortB, 25);
                    expectedInput5 = true;
                }
                else
                {
                    Gpio.ClearOutput(GpioPort.PortB, 25);
                }

                Gpio.GetInput(GpioPort.PortC, 2, out input1);
                Gpio.GetInput(GpioPort.PortC, 10, out input2);
                Gpio.GetInput(GpioPort.PortC, 15, out input3);
                Gpio.GetInput(GpioPort.PortC, 4, out input4);
                Gpio.GetInput(GpioPort.PortC, 0, out input5);

                if (input1 != expectedInput1 || input2 != expectedInput2 || input3 != expectedInput3 || input4 != expectedInput4 || input5 != expectedInput5)
                {
                    Console.WriteLine("<<-- Expansion 2 Port IO Failed to Read Correct Values. Expansion Card Test Failed. (check EXP1, EXP2, RN15, RN12, RN16, RN11) -->> ");
                    return false;
                }
            }

            Gpio.ConfigurePin(GpioPort.PortB, 26, false, false, false);
            Gpio.ConfigurePin(GpioPort.PortB, 27, false, false, false);
            Gpio.ConfigurePin(GpioPort.PortB, 23, false, false, false);
            Gpio.ConfigurePin(GpioPort.PortB, 24, false, false, false);
            Gpio.ConfigurePin(GpioPort.PortB, 25, false, false, false);

            Gpio.ConfigurePin(GpioPort.PortC, 2, true, false, false);
            Gpio.ConfigurePin(GpioPort.PortC, 10, true, false, false);
            Gpio.ConfigurePin(GpioPort.PortC, 15, true, false, false);
            Gpio.ConfigurePin(GpioPort.PortC, 4, true, false, false);
            Gpio.ConfigurePin(GpioPort.PortC, 0, true, false, false);

            for (int i = 0; i < 6; i++)
            {
                bool expectedInput1 = false;
                bool expectedInput2 = false;
                bool expectedInput3 = false;
                bool expectedInput4 = false;
                bool expectedInput5 = false;

                if (i == 1)
                {
                    Gpio.SetOutput(GpioPort.PortC, 2);
                    expectedInput1 = true;
                }
                else
                {
                    Gpio.ClearOutput(GpioPort.PortC, 2);
                }
                if (i == 2)
                {
                    Gpio.SetOutput(GpioPort.PortC, 10);
                    expectedInput2 = true;
                }
                else
                {
                    Gpio.ClearOutput(GpioPort.PortC, 10);
                }
                if (i == 3)
                {
                    Gpio.SetOutput(GpioPort.PortC, 15);
                    expectedInput3 = true;
                }
                else
                {
                    Gpio.ClearOutput(GpioPort.PortC, 15);
                }
                if (i == 4)
                {
                    Gpio.SetOutput(GpioPort.PortC, 4);
                    expectedInput4 = true;
                }
                else
                {
                    Gpio.ClearOutput(GpioPort.PortC, 4);
                }
                if (i == 5)
                {
                    Gpio.SetOutput(GpioPort.PortC, 0);
                    expectedInput5 = true;
                }
                else
                {
                    Gpio.ClearOutput(GpioPort.PortC, 0);
                }

                Gpio.GetInput(GpioPort.PortB, 26, out input1);
                Gpio.GetInput(GpioPort.PortB, 27, out input2);
                Gpio.GetInput(GpioPort.PortB, 23, out input3);
                Gpio.GetInput(GpioPort.PortB, 24, out input4);
                Gpio.GetInput(GpioPort.PortB, 25, out input5);

                if (input1 != expectedInput1 || input2 != expectedInput2 || input3 != expectedInput3 || input4 != expectedInput4 || input5 != expectedInput5)
                {
                    Console.WriteLine("<<-- Expansion 1 Port IO Failed to Read Correct Values. Expansion Card Test Failed. (check EXP1, EXP2, RN15, RN12, RN16, RN11) -->> ");
                    return false;
                }
            }

            Console.WriteLine("<<-- Expansion Card Tests Passed. -->> ");
            return true;
        }

        private static bool expansion1ValidDataReceived = false;
        private static bool expansion2ValidDataReceived = false;
        static void connection1_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            byte[] data = new byte[] { 0xAA, 0x55, 0x11, 0x33, 0x44 };
            if (data.SequenceEqual(e.Data))
                expansion1ValidDataReceived = true;
        }

        static void connection2_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            byte[] data = new byte[] { 0xAA, 0x55, 0x11, 0x22 };
            if (data.SequenceEqual(e.Data))
                expansion2ValidDataReceived = true;
        }

        private static bool performAlarmInputTests()
        {
            Console.WriteLine("<<-- Performing Alarm Input Tests. -->> ");
            int inactiveLowerLimit = 880;
            int inactiveUpperLimit = 970;
            int activeLowerLimit = 80;
            int activeUpperLimit = 120;

            Pacom.Peripheral.ExpansionCards.Pacom8203OutputCard expansionCard1 = ((Pacom.Peripheral.ExpansionCards.Pacom8203OutputCard)ExpansionCardManager.Instance.GetExpansionCard(0));
            Pacom.Peripheral.ExpansionCards.Pacom8203OutputCard expansionCard2 = ((Pacom.Peripheral.ExpansionCards.Pacom8203OutputCard)ExpansionCardManager.Instance.GetExpansionCard(1));
            for (int k = 0; k < 9; k++)
            {
                int activePin = 0;

                expansionCard1.ClearOutput(0);
                expansionCard1.ClearOutput(1);
                expansionCard1.ClearOutput(2);
                expansionCard1.ClearOutput(3);
                expansionCard2.ClearOutput(0);
                expansionCard2.ClearOutput(1);
                expansionCard2.ClearOutput(2);
                expansionCard2.ClearOutput(3);

                switch (k)
                {
                    case 0:
                        activePin = -1;
                        break;
                    case 1:
                        activePin = 0;
                        expansionCard2.SetOutput(3);
                        break;
                    case 2:
                        activePin = 1;
                        expansionCard2.SetOutput(2);
                        break;
                    case 3:
                        activePin = 2;
                        expansionCard2.SetOutput(1);
                        break;
                    case 4:
                        activePin = 3;
                        expansionCard2.SetOutput(0);
                        break;
                    case 5:
                        activePin = 4;
                        expansionCard1.SetOutput(3);
                        break;
                    case 6:
                        activePin = 5;
                        expansionCard1.SetOutput(2);
                        break;
                    case 7:
                        activePin = 6;
                        expansionCard1.SetOutput(1);
                        break;
                    case 8:
                        activePin = 7;
                        expansionCard1.SetOutput(0);
                        break;
                }

                for (int j = 0; j < 3; j++)
                {
                    // Select High reference voltage
                    Gpio.ClearOutput(GpioPort.PortA, 30);
                    Thread.Sleep(50);

                    for (int i = 0; i < 8; i++)
                    {
                        int reading = Adc.PerformAdcRead(AdcDevice.AdcU29, i);

                        if (activePin == i)
                        {
                            if (reading < activeLowerLimit || reading > activeUpperLimit)
                            {
                                Console.WriteLine("<<-- Active High ADC Reading Out of Range. (" + i + ", " + reading + ") Alarm Input Tests Failed. (check U29, U24, U32, CN8, RP1) -->> ");
                                return false;
                            }
                        }
                        else
                        {
                            if (reading < inactiveLowerLimit || reading > inactiveUpperLimit)
                            {
                                Console.WriteLine("<<-- High ADC Reading Out of Range. (" + i + ", " + reading + ") Alarm Input Tests Failed. (check U29, U24, U32, CN8, RP1) -->> ");
                                return false;
                            }
                        }
                        Console.WriteLine("High ADC Reading " + i + " " + reading);
                    }

                    // Select Low reference voltage
                    Gpio.SetOutput(GpioPort.PortA, 30);
                    Thread.Sleep(50);

                    for (int i = 0; i < 8; i++)
                    {
                        int reading = Adc.PerformAdcRead(AdcDevice.AdcU29, i);

                        if (activePin == i)
                        {
                            if (reading < activeLowerLimit || reading > activeUpperLimit)
                            {
                                Console.WriteLine("<<-- Active Low ADC Reading Out of Range. (" + i + ", " + reading + ") Alarm Input Tests Failed. (check U29, U24, U32, CN8, RP1) -->> ");
                                return false;
                            }
                        }
                        else
                        {
                            if (reading < inactiveLowerLimit || reading > inactiveUpperLimit)
                            {
                                Console.WriteLine("<<-- Low ADC Reading Out of Range. (" + i + ", " + reading + ") Alarm Input Tests Failed. (check U29, U24, U32, CN8, RP1) -->> ");
                                return false;
                            }
                        }
                        Console.WriteLine("Low ADC Reading " + i + " " + reading);
                    }
                }
            }

            expansionCard1.ClearOutput(0);

            Console.WriteLine("<<-- Alarm Input Tests Passed. -->> ");
            return true;
        }

        private static bool performPowerAdcTests()
        {
            Console.WriteLine("<<-- Performing Power ADC Tests. -->> ");

            int reading = Adc.PerformAdcRead(AdcDevice.AdcU20, 0);
            if (reading < 360 || reading > 420)
            {
                Console.WriteLine("<<-- Vin ADC Reading Out of Range. (" + reading + ") Power ADC Tests Failed. (check U20, U31, U19, R96, R97, R203, R199) -->> ");
                return false;
            }

            reading = Adc.PerformAdcRead(AdcDevice.AdcU20, 1);
            if (reading < 1020)
            {
                Console.WriteLine("<<-- Status Pin Reading Out of Range. (" + reading + ") Power ADC Tests Failed. (check U20, U31, U19, R96, R97, R126, R128, R127) -->> ");
                return false;
            }

            bool success = false;
            for (int i = 0; i < 100; i++)
            {
                setMasterUnitOutput(0, true);
                Thread.Sleep(20);
                reading = Adc.PerformAdcRead(AdcDevice.AdcU20, 1);
                if (reading >= 560 && reading <= 620)
                {
                    success = true;
                    break;
                }
            }
            if (success == false)
            {
                Console.WriteLine("<<-- Status Pin Reading Out of Range. (" + reading + ") Power ADC Tests Failed. (check U20, U31, U19, R96, R97, R126, R128, R127) -->> ");
                return false;
            }
            setMasterUnitOutput(0, false);

            reading = Adc.PerformAdcRead(AdcDevice.AdcU20, 2);
            if (reading < 300 || reading > 380)
            {
                Console.WriteLine("<<-- 5V ADC Out of Range. (" + reading + ") Power ADC Tests Failed. (check U20, U31, U19, R96, R97, R207, R213) -->> ");
                return false;
            }

            reading = Adc.PerformAdcRead(AdcDevice.AdcU20, 3);
            if (reading < 170 || reading > 270)
            {
                Console.WriteLine("<<-- 3.3V ADC Out of Range. (" + reading + ") Power ADC Tests Failed. (check U20, U31, U19, R96, R97, R206, R212) -->> ");
                return false;
            }

            Console.WriteLine("<<-- Power ADC Tests Passed. -->> ");
            return true;
        }

        private static bool performCriTests()
        {
            Cri.CardRead += new EventHandler<CardReadEventArgs>(Cri_CardRead);

            Console.WriteLine("<<-- Performing Card Reader Tests. -->> ");

            byte[] data = new byte[] {0xAA, 0x55, 0x1F, 0x28};

            lastCardReadInterface = -1;
            lastCardReadData = null;
            performMasterUnitCardSwipe(0, 32, data);
            for (int i = 0; i < 5000; i++)
            {
                if (lastCardReadInterface != -1)
                    break;
                Thread.Sleep(1);
            }
            if (lastCardReadData == null || lastCardReadData.Length < 4 || lastCardReadData[0] != data[0] || lastCardReadData[1] != data[1] || lastCardReadData[2] != data[2] || lastCardReadData[3] != data[3])
            {
                Console.WriteLine("<<-- Reading Card on Reader Interface 1 Failed. Card Reader Tests Failed. (check U26, U27, R32, R31, R34, R33) -->> ");
                return false;
            }

            lastCardReadInterface = -1;
            lastCardReadData = null;
            performMasterUnitCardSwipe(1, 32, data);
            for (int i = 0; i < 5000; i++)
            {
                if (lastCardReadInterface != -1)
                    break;
                Thread.Sleep(1);
            }
            if (lastCardReadData == null || lastCardReadData.Length < 4 || lastCardReadData[0] != data[0] || lastCardReadData[1] != data[1] || lastCardReadData[2] != data[2] || lastCardReadData[3] != data[3])
            {
                Console.WriteLine("<<-- Reading Card on Reader Interface 2 Failed. Card Reader Tests Failed. (check U26, U27, R46, R45, R34, R33) -->> ");
                return false;
            }

            lastCardReadInterface = -1;
            lastCardReadData = null;
            performMasterUnitCardSwipe(2, 32, data);
            for (int i = 0; i < 5000; i++)
            {
                if (lastCardReadInterface != -1)
                    break;
                Thread.Sleep(1);
            }
            if (lastCardReadData == null || lastCardReadData.Length < 4 || lastCardReadData[0] != data[0] || lastCardReadData[1] != data[1] || lastCardReadData[2] != data[2] || lastCardReadData[3] != data[3])
            {
                Console.WriteLine("<<-- Reading Card on Reader Interface 3 Failed. Card Reader Tests Failed. (check U26, U28, R86, R87, R94, R93) -->> ");
                return false;
            }

            lastCardReadInterface = -1;
            lastCardReadData = null;
            performMasterUnitCardSwipe(3, 32, data);
            for (int i = 0; i < 5000; i++)
            {
                if (lastCardReadInterface != -1)
                    break;
                Thread.Sleep(1);
            }
            if (lastCardReadData == null || lastCardReadData.Length < 4 || lastCardReadData[0] != data[0] || lastCardReadData[1] != data[1] || lastCardReadData[2] != data[2] || lastCardReadData[3] != data[3])
            {
                Console.WriteLine("<<-- Reading Card on Reader Interface 4 Failed. Card Reader Tests Failed. (check U26, U28, R111, R110, R94, R93) -->> ");
                return false;
            }

            Console.WriteLine("<<-- Card Reader Tests Passed. -->> ");
            return true;
        }

        private static bool performOutputTests()
        {
            Console.WriteLine("<<-- Performing Output Tests. -->> ");

            for (int i = 0; i < 6; i++)
            {
                OnboardOutputs.ClearAllOutputs();
                OnboardOutputs.SetOutput(i + 2);

                int failCount = 0;
                for (int j = 0; j < 6; j++)
                {
                    int reading = readMasterUnitInput(7 - j, true, 3);

                    if (j == i)
                    {
                        if (reading > 100)
                        {
                            Console.WriteLine("<<-- Output " + (j + 2) + " Failed to Activate. Output Tests Failed. (check U30, U34, Q4, Q5, Q6, Q7, Q8, Q9, R37, R39, R41, R98, R100, R105, R36, R38, R40, R95, R101, R103) -->> ");
                            if (failCount < 3)
                            {
                                failCount++;
                                j--;
                                Thread.Sleep(500);
                                continue;
                            }
                            return false;
                        }
                    }
                    else
                    {
                        if (reading < 900)
                        {
                            Console.WriteLine("<<-- Output " + (j + 2) + " Activated Out of Turn. Output Tests Failed. (check U30, U34, Q4, Q5, Q6, Q7, Q8, Q9, R37, R39, R41, R98, R100, R105, R36, R38, R40, R95, R101, R103) -->> ");
                            if (failCount < 3)
                            {
                                failCount++;
                                j--;
                                Thread.Sleep(500);
                                continue;
                            }
                            return false;
                        }
                    }
                    failCount = 0;
                }
            }
            OnboardOutputs.SetOutput(2);
            OnboardOutputs.SetOutput(3);
            OnboardOutputs.SetOutput(4);
            OnboardOutputs.SetOutput(5);
            OnboardOutputs.SetOutput(6);
            OnboardOutputs.SetOutput(7);
            for (int j = 0; j < 6; j++)
            {
                int reading = readMasterUnitInput(7 - j, true, 3);
                if (reading > 100)
                {
                    Console.WriteLine("<<-- Output " + (j + 2) + " Failed to Activate On All. Output Tests Failed. (check U30, U34, Q4, Q5, Q6, Q7, Q8, Q9, R37, R39, R41, R98, R100, R105, R36, R38, R40, R95, R101, R103) -->> ");
                    return false;
                }
            }

            OnboardOutputs.ClearAllOutputs();
            for (int j = 0; j < 6; j++)
            {
                int reading = readMasterUnitInput(7 - j, true, 3);
                if (reading < 900)
                {
                    Console.WriteLine("<<-- Output " + (j + 2) + " Failed to Deactivate. Output Tests Failed. (check U30, U34, Q4, Q5, Q6, Q7, Q8, Q9, R37, R39, R41, R98, R100, R105, R36, R38, R40, R95, R101, R103) -->> ");
                    return false;
                }
            }

            Console.WriteLine("<<-- Output Tests Passed. -->> ");
            return true;
        }

        private static int lastCardReadInterface = -1;
        private static byte[] lastCardReadData = null;
        static void Cri_CardRead(object sender, CardReadEventArgs e)
        {
            lastCardReadData = e.ReadCardNumber;
            lastCardReadInterface = e.CardReaderNumber;
        }

        private static void disposeConnectionMethod(Object stateInfo)
        {
            ProtocolConnectionBase connection = (ProtocolConnectionBase)stateInfo;
            connection.Dispose();
        }

        private static bool performBatteryTests()
        {
            Console.WriteLine("<<-- Performing Battery Test. -->> ");

            bool batteryGood;
            Hal.Gpio.GetInput(GpioPort.PortB, 14, out batteryGood);

            if (batteryGood == false)
            {
                Console.WriteLine("<<-- Battery reporting low or missing. Battery Test Failed. (check BT1, CN12, U21, R99, C159, C160) -->> ");
                return false;
            }

            Console.WriteLine("<<-- Battery Test Passed. -->> ");
            return true;
        }

        private static bool performResetTest()
        {
            try
            {
                NetworkAdapter.UnloadDriver();
                                
                // Make NRST a GPIO
                WatchdogTimer.Instance.DisableUserReset();
                // Stop WDT toggling
                WatchdogTimer.Instance.ToggleAction(null);

                Console.WriteLine("<<-- Testing Watchdog Timer. Please wait... -->> ");

                // Ensure the WD is running (useful when the WD is disabled during debugging)
                Hal.Gpio.ClearOutput(GpioPort.PortA, 9);
                Hal.Gpio.ConfigurePin(GpioPort.PortA, 9, true, false, false);

                // Wait for WD reset to be generated
                int WaitForInitialWDReset = 50;
                while (true)
                {
                    Thread.Sleep(50);
                    WaitForInitialWDReset--;

                    bool value = true;
                    WatchdogTimer.Instance.ReadResetLevel(out value);
                    // Success when WD pulse is detected
                    if (value == false)
                        break;
                    if (WaitForInitialWDReset <= 0)
                    {
                        Console.WriteLine("<<-- Failed Watchdog Timer Test. Initial On-pulse not detected. (check U23, U25) -->> ");
                        return false;
                    }
                }

                int ResetCyclesToTest = 3;
                while (ResetCyclesToTest > 0)
                {
                    // Wait for NRST True
                    int WaitForRestoredReset = 20;
                    while (true)
                    {
                        bool value = false;
                        WatchdogTimer.Instance.ReadResetLevel(out value);
                        if (WaitForRestoredReset == 0 && value == true)
                            break;

                        Thread.Sleep(50);

                        if (WaitForRestoredReset <= 0)
                        {
                            Console.WriteLine("<<-- Failed Watchdog Timer Test. Off-pulse 1.6s not detected. (check U23, U25) -->> ");
                            return false;
                        }
                        WaitForRestoredReset--;
                    }

                    int ResetCyclesToTestPause = 30;
                    while (true)
                    {
                        bool value = true;
                        WatchdogTimer.Instance.ReadResetLevel(out value);
                        // Success when WD pulse is detected
                        if (value == false)
                            break;

                        Thread.Sleep(50);

                        if (ResetCyclesToTestPause <= 0)
                        {
                            Console.WriteLine("<<-- Failed Watchdog Timer Test. Off-pulse 1.6s detected too long. (check U23, U25) -->> ");
                            return false;
                        }
                        ResetCyclesToTestPause--;
                    }


                    // Wait for NRST False
                    int WaitForResetToLast = 6;
                    while (true)
                    {
                        bool value = true;
                        WatchdogTimer.Instance.ReadResetLevel(out value);
                        if (WaitForResetToLast == 0 && value == false)
                            break;

                        Thread.Sleep(15);

                        if (WaitForResetToLast <= 0)
                        {
                            Console.WriteLine("<<-- Failed Watchdog Timer Test. On-pulse 200ms not detected. (check U23, U25) -->> ");
                            return false;
                        }
                        WaitForResetToLast--;
                    }

                    int WaitForResetToLastPause = 40;
                    while (true)
                    {
                        bool value = false;
                        WatchdogTimer.Instance.ReadResetLevel(out value);
                        if (value == true)
                            break;

                        Thread.Sleep(15);

                        if (WaitForResetToLastPause <= 0)
                        {
                            Console.WriteLine("<<-- Failed Watchdog Timer Test. On-pulse 200ms detected too long. (check U23, U25) -->> ");
                            return false;
                        }
                        WaitForResetToLastPause--;
                    }


                    ResetCyclesToTest--;
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                // Restore WD and Reset functionality
                Hal.WatchdogTimer.Instance.ToggleAction(WatchdogTimer_InputToggleRequired);
                Hal.Gpio.ConfigurePin(GpioPort.PortC, 11, true, false, false);
                Hal.Gpio.ConfigurePin(GpioPort.PortA, 9, true, false, false);
                Hal.WatchdogTimer.Instance.ToggleInput();
                WatchdogTimer.Instance.EnableUserReset();

                NetworkAdapter.LoadDriver();
            }

            Console.WriteLine("<<-- Tested Watchdog Timer Okay -->> ");
            return true;
        }

        private static void rs485connection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            try
            {
                if (ASCIIEncoding.ASCII.GetString(e.Data, 0, e.Data.Length) == "TCF mocaP")
                    rs485MessageReceived = true;
            }
            catch
            {
            }
        }

        private static void connection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            try
            {
                if (e.Data.Length > 4 && e.Data[0] == '<')
                {
                    lock (receivedMessages)
                    {
                        string message = ASCIIEncoding.ASCII.GetString(e.Data, 0, e.Data.Length);
                        Console.WriteLine("Rcv: " + message);
                        receivedMessages.Add(message);
                        receivedMessageEvent.Set();
                    }
                }
            }
            catch
            {
            }
        }

        private static void sendMessage(string message)
        {
            Console.WriteLine("Snd: " + message);

            Dictionary<string, object> dictionary = new Dictionary<string, object>();
            dictionary.Add("RemoteEndPoint", new IPEndPoint(IPAddress.Parse("10.1.1.2"), 3435));
            connection.Send(ASCIIEncoding.ASCII.GetBytes(message), dictionary);
        }

        private static void connection_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
        }

        private static void verifyNoReceivedMessages()
        {
            lock (receivedMessages)
            {
                if (receivedMessages.Count > 0)
                {
                    Console.WriteLine("<<-- Received unexpected message. Test Failed. -->> ");
                    unexpectedMessageReceived = true;
                    foreach (string message in receivedMessages)
                    {
                        Console.WriteLine("<<--     Rcv: " + message + " -->> ");
                    }
                    receivedMessages.Clear();
                }
            }
        }

        static void Pcb_ResetButtonPressed(object sender, EventArgs e)
        {
            Console.WriteLine("<<-- Reset Button Pressed Unexpectedly. Test Failed. -->> ");
            unexpectedButtonPressed = true;
        }

        static void Pcb_OneTouchButtonPressed(object sender, EventArgs e)
        {
            Console.WriteLine("<<-- General Purpose Button Pressed Unexpectedly. Test Failed. -->> ");
            unexpectedButtonPressed = true;
        }

        static void Pcb_ResetButtonPressedUnderTest(object sender, EventArgs e)
        {
            resetButtonPressed = true;
        }

        static void Pcb_OneTouchButtonPressedUnderTest(object sender, EventArgs e)
        {
            oneTouchButtonPressed = true;
        }

        private static int readMasterUnitInput(int inputNumber, bool high, int readings)
        {
            int average = 0;

            for (int i = 0; i < readings; i++)
            {
                bool ackReceived = false;
                bool inReceived = false;
                int inputReading = -1;

                verifyNoReceivedMessages();

                string message = "<In " + inputNumber + " ";
                if (high)
                    message += "Hi>";
                else
                    message += "Lo>";

                sendMessage(message);

                while (true)
                {
                    if (receivedMessageEvent.WaitOne(500, false))
                    {
                        lock (receivedMessages)
                        {
                            while (receivedMessages.Count > 0)
                            {
                                if (receivedMessages[0] == "<Ack>")
                                {
                                    ackReceived = true;
                                }
                                else if (receivedMessages[0].Substring(0, 4) == "<In ")
                                {
                                    inReceived = true;

                                    string[] receivedMessagePortions = receivedMessages[0].Split(new char[] { ' ' });

                                    if (Int32.Parse(receivedMessagePortions[1]) == inputNumber)
                                    {
                                        inputReading = Int32.Parse(receivedMessagePortions[2].Replace(">", ""));
                                    }
                                }
                                receivedMessages.RemoveAt(0);
                            }
                        }
                        if (ackReceived && inReceived)
                            break;
                    }
                    else
                    {
                        break;
                    }
                }
                if (inputReading == -1)
                    return -1;
                average += inputReading;
            }

            average = average / readings;

            return average;
        }

        private static void setMasterUnitOutput(int outputNumber, bool on)
        {
            verifyNoReceivedMessages();

            string message = "<Out " + outputNumber + " ";
            if (on)
                message += "On>";
            else
                message += "Off>";

            sendMessage(message);

            bool ackReceived = false;
            while (true)
            {
                if (receivedMessageEvent.WaitOne(500, false))
                {
                    lock (receivedMessages)
                    {
                        while (receivedMessages.Count > 0)
                        {
                            if (receivedMessages[0] == "<Ack>")
                            {
                                ackReceived = true;
                            }
                            receivedMessages.RemoveAt(0);
                        }
                    }
                    if (ackReceived)
                        break;
                }
                else
                {
                    break;
                }
            }
        }

        private static void performMasterUnitCardSwipe(int interfaceNumber, int bits, byte[] data)
        {
            verifyNoReceivedMessages();

            string message = "<Wie " + interfaceNumber + " " + bits + " " + BitConverter.ToString(data).Replace("-","") + ">";

            sendMessage(message);

            bool ackReceived = false;
            while (true)
            {
                if (receivedMessageEvent.WaitOne(1500, false))
                {
                    lock (receivedMessages)
                    {
                        while (receivedMessages.Count > 0)
                        {
                            if (receivedMessages[0] == "<Ack>")
                            {
                                ackReceived = true;
                            }
                            receivedMessages.RemoveAt(0);
                        }
                    }
                    if (ackReceived)
                        break;
                }
                else
                {
                    break;
                }
            }
        }


        private static bool hasValidSerialNumber()
        {
            byte[] serialNum = null;
            while (true)
            {
                try
                {
                    serialNum = DataFlashSerialPage.SerialNumber;
                    if (serialNum != null)
                    {
                        break;
                    }
                }
                catch
                {
                }
                Thread.Sleep(1000);
            }

            try
            {
                string serialNumber = ASCIIEncoding.ASCII.GetString(serialNum, 0, serialNum.Length);
                if (
                    serialNum[0] != '0' ||
                    serialNum[1] != '4' ||
                    serialNum[2] != '3' ||
                    serialNum[3] != 'G' ||
                    serialNum[4] != '-' ||
                    serialNum[5] < '0' || serialNum[5] > '9' ||
                    serialNum[6] < '0' || serialNum[6] > '9' ||
                    serialNum[7] < '0' || serialNum[7] > '9' ||
                    serialNum[8] < '0' || serialNum[8] > '9' ||
                    serialNum[9] != '-' ||
                    serialNum[10] < '0' || serialNum[10] > '9' ||
                    serialNum[11] < '0' || serialNum[11] > '9' ||
                    serialNum[12] < '0' || serialNum[12] > '9' ||
                    serialNum[13] < '0' || serialNum[13] > '9' ||
                    serialNum[14] < '0' || serialNum[14] > '9' ||
                    serialNum[15] < '0' || serialNum[15] > '9'
                    )
                {
                    return false;
                }
                if (int.Parse(serialNumber.Substring(10)) == 0)
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        private static void updateSerialNumber()
        {
            Console.WriteLine("<<-- Checking Serial Number. -->> ");
            
            if (hasValidSerialNumber())
            {
                Console.WriteLine("<<-- Valid Serial Number Already Programmed. -->> ");
                return;
            }

            SerialManager serialManager = new SerialManager();
            bool validSerialReceived = false;

            while (true)
            {
                Serial232Connection serialConnection = null;
                try
                {
                    serialConnection = (Serial232Connection)serialManager.CreateConnection(PhysicalSerialType.RS232, PhysicalSerialPort.OnboardRS232Port, 115200, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);
                    serialConnection.Connect();

                    serialConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(serialConnection_SerialNumberDataReceived);
                    serialConnection.Send(ASCIIEncoding.ASCII.GetBytes("%%8003 SN Request%%"), new Dictionary<string, object>());

                    while (true)
                    {
                        //Expected response: %%SN Response%%043G-0000-000000%%00000000000000000000000000000000000000000000000000%%
                        if (rs232SerialNumberReceivedData.Length >= 85)
                        {
                            if (rs232SerialNumberReceivedData[0] == '%' &&
                                rs232SerialNumberReceivedData[1] == '%' &&
                                rs232SerialNumberReceivedData[2] == 'S' &&
                                rs232SerialNumberReceivedData[3] == 'N' &&
                                rs232SerialNumberReceivedData[4] == ' ' &&
                                rs232SerialNumberReceivedData[5] == 'R' &&
                                rs232SerialNumberReceivedData[6] == 'e' &&
                                rs232SerialNumberReceivedData[7] == 's' &&
                                rs232SerialNumberReceivedData[8] == 'p' &&
                                rs232SerialNumberReceivedData[9] == 'o' &&
                                rs232SerialNumberReceivedData[10] == 'n' &&
                                rs232SerialNumberReceivedData[11] == 's' &&
                                rs232SerialNumberReceivedData[12] == 'e' &&
                                rs232SerialNumberReceivedData[13] == '%' &&
                                rs232SerialNumberReceivedData[14] == '%' &&
                                rs232SerialNumberReceivedData[15] == '0' &&
                                rs232SerialNumberReceivedData[16] == '4' &&
                                rs232SerialNumberReceivedData[17] == '3' &&
                                rs232SerialNumberReceivedData[18] == 'G' &&
                                rs232SerialNumberReceivedData[19] == '-' &&
                                rs232SerialNumberReceivedData[20] >= '0' && rs232SerialNumberReceivedData[20] <= '9' &&
                                rs232SerialNumberReceivedData[21] >= '0' && rs232SerialNumberReceivedData[21] <= '9' &&
                                rs232SerialNumberReceivedData[22] >= '0' && rs232SerialNumberReceivedData[22] <= '9' &&
                                rs232SerialNumberReceivedData[23] >= '0' && rs232SerialNumberReceivedData[23] <= '9' &&
                                rs232SerialNumberReceivedData[24] == '-' &&
                                rs232SerialNumberReceivedData[25] >= '0' && rs232SerialNumberReceivedData[25] <= '9' &&
                                rs232SerialNumberReceivedData[26] >= '0' && rs232SerialNumberReceivedData[26] <= '9' &&
                                rs232SerialNumberReceivedData[27] >= '0' && rs232SerialNumberReceivedData[27] <= '9' &&
                                rs232SerialNumberReceivedData[28] >= '0' && rs232SerialNumberReceivedData[28] <= '9' &&
                                rs232SerialNumberReceivedData[29] >= '0' && rs232SerialNumberReceivedData[29] <= '9' &&
                                rs232SerialNumberReceivedData[30] >= '0' && rs232SerialNumberReceivedData[30] <= '9' &&
                                rs232SerialNumberReceivedData[31] == '%' &&
                                rs232SerialNumberReceivedData[32] == '%' &&
                                rs232SerialNumberReceivedData[83] == '%' &&
                                rs232SerialNumberReceivedData[84] == '%')
                            {
                                validSerialReceived = true;
                            }

                            break;
                        }
                        Thread.Sleep(10);
                    }
                }
                catch
                {
                }
                finally
                {
                    serialConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(serialConnection_SerialNumberDataReceived);
                    serialConnection.Dispose();
                    serialConnection = null;
                }
                if (validSerialReceived)
                    break;

                Thread.Sleep(2000);
            }

            while (true)
            {
                try
                {
                    byte[] pacomSerialNumber = new byte[16];
                    byte[] manufacturerSerialNumber = new byte[50];

                    Buffer.BlockCopy(rs232SerialNumberReceivedData, 15, pacomSerialNumber, 0, 16);
                    Buffer.BlockCopy(rs232SerialNumberReceivedData, 33, manufacturerSerialNumber, 0, 50);

                    if (Pacom.Peripheral.Hal.DataFlashSerialPage.SetSerialNumber(pacomSerialNumber) &&
                        DataFlashSerialPage.SetManufacturersSerialNumber(manufacturerSerialNumber))
                    {
                        DataFlashConfig dataFlashConfig = new DataFlashConfig(DataFlash.Instance);

                        // Update the default MAC address to reflect the new serial number
                        byte[] macAddress = new byte[] { 0x00, 0xE0, 0x42, 0x94, 0x00, 0x00 };
                        string[] serialNumberParts = ASCIIEncoding.ASCII.GetString(pacomSerialNumber, 0, 16).Split('-');
                        if (serialNumberParts.Length == 3)
                        {
                            int unitNumber = int.Parse(serialNumberParts[2]);
                            macAddress[4] = (byte)(unitNumber >> 8);
                            macAddress[5] = (byte)unitNumber;
                        }
                        dataFlashConfig.MacAddress = macAddress;
                        if (dataFlashConfig.Update())
                        {
                            return;
                        }
                    }
                }
                catch
                {
                }
                Thread.Sleep(1000);
            }
        }

        static void WatchdogTimer_InputToggleRequired()
        {
            Hal.WatchdogTimer.Instance.ToggleInput();
        }

        private static bool askYesNoQuestion(string message)
        {
            SerialManager serialManager = new SerialManager();

            Serial232Connection serialConnection = null;
            try
            {
                serialConnection = (Serial232Connection)serialManager.CreateConnection(PhysicalSerialType.RS232, PhysicalSerialPort.OnboardRS232Port, 115200, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);
                serialConnection.Connect();

                serialConnection.DataReceived += serialConnection_YesNoDataReceived;
                serialConnection.Send(ASCIIEncoding.ASCII.GetBytes("%%YesNoQuestion%%" + message + "%%"), new Dictionary<string, object>());

                while (true)
                {
                    if (yesNoReceivedData.Length < 1)
                    {
                        Thread.Sleep(10);
                        continue;
                    }
                    return yesNoReceivedData[0] == 'Y';
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                serialConnection.DataReceived -= serialConnection_YesNoDataReceived;
                serialConnection.Dispose();
                serialConnection = null;
            }
        }
    }
}