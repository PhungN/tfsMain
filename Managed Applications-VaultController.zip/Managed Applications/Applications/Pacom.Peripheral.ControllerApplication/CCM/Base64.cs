﻿#if DEBUG
using System;
using System.Text;

namespace Pacom.Peripheral.Common
{
    public static class Base64
    {
        private static byte[] base64EncodingTable = new byte[]
        {
            (byte)'A', (byte)'B', (byte)'C', (byte)'D', (byte)'E', (byte)'F', (byte)'G', (byte)'H',
            (byte)'I', (byte)'J', (byte)'K', (byte)'L', (byte)'M', (byte)'N', (byte)'O', (byte)'P', 
            (byte)'Q', (byte)'R', (byte)'S', (byte)'T', (byte)'U', (byte)'V', (byte)'W', (byte)'X',
            (byte)'Y', (byte)'Z', (byte)'a', (byte)'b', (byte)'c', (byte)'d', (byte)'e', (byte)'f',
            (byte)'g', (byte)'h', (byte)'i', (byte)'j', (byte)'k', (byte)'l', (byte)'m', (byte)'n',
            (byte)'o', (byte)'p', (byte)'q', (byte)'r', (byte)'s', (byte)'t', (byte)'u', (byte)'v',
            (byte)'w', (byte)'x', (byte)'y', (byte)'z', (byte)'0', (byte)'1', (byte)'2', (byte)'3',
            (byte)'4', (byte)'5', (byte)'6', (byte)'7', (byte)'8', (byte)'9', (byte)'+', (byte)'/'
        };

        private static byte[] base64DecodingTable = new byte[]
        {
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, //gap: ctrl chars
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, //gap: ctrl chars
            0,0,0,0,0,0,0,0,0,0,0,           //gap: spc,!"#$%'()*
            62,                   // +
            0, 0, 0,             // gap ,-.
            63,                   // /
            52, 53, 54, 55, 56, 57, 58, 59, 60, 61, // 0-9
            0, 0, 0,             // gap: :;<
            99,                   //  = (end padding)
            0, 0, 0,             // gap: >?@
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,
            17,18,19,20,21,22,23,24,25, // A-Z
            0, 0, 0, 0, 0, 0,    // gap: [\]^_`
            26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,
            43,44,45,46,47,48,49,50,51, // a-z    
            0, 0, 0, 0,          // gap: {|}~ (and the rest...)
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
        };

        /// <summary>
        /// Base64 encode function.
        /// </summary>
        public static byte[] Encode(byte[] data, int offset, int size)
        {
            int requiredSize = (4 * ((size + 2) / 3));
            byte[] buffer = new byte[requiredSize];
            int mBufferPos = 0;

            UInt32 octet_a;
            UInt32 octet_b;
            UInt32 octet_c;
            UInt32 triple;
            int sizeMod = size - (size % 3);
            // adding all data triplets
            for (; offset < sizeMod; )
            {
                octet_a = data[offset++];
                octet_b = data[offset++];
                octet_c = data[offset++];

                triple = (octet_a << 0x10) + (octet_b << 0x08) + octet_c;

                buffer[mBufferPos++] = base64EncodingTable[(triple >> 3 * 6) & 0x3F];
                buffer[mBufferPos++] = base64EncodingTable[(triple >> 2 * 6) & 0x3F];
                buffer[mBufferPos++] = base64EncodingTable[(triple >> 1 * 6) & 0x3F];
                buffer[mBufferPos++] = base64EncodingTable[(triple >> 0 * 6) & 0x3F];
            }

            // last bytes
            if (sizeMod < size)
            {
                octet_a = offset < size ? data[offset++] : (UInt32)0;
                octet_b = offset < size ? data[offset++] : (UInt32)0;
                octet_c = (UInt32)0; // last character is definitely padded

                triple = (octet_a << 0x10) + (octet_b << 0x08) + octet_c;

                buffer[mBufferPos++] = base64EncodingTable[(triple >> 3 * 6) & 0x3F];
                buffer[mBufferPos++] = base64EncodingTable[(triple >> 2 * 6) & 0x3F];
                buffer[mBufferPos++] = base64EncodingTable[(triple >> 1 * 6) & 0x3F];
                buffer[mBufferPos++] = base64EncodingTable[(triple >> 0 * 6) & 0x3F];

                // add padding '='
                sizeMod = size % 3;
                // last character is definitely padded
                buffer[mBufferPos - 1] = (byte)'=';
                if (sizeMod == 1) buffer[mBufferPos - 2] = (byte)'=';
            }
            return buffer;
        }

        /// <summary>
        /// Base64 decoder function.
        /// </summary>
        public static byte[] Decode(byte[] data)
        {
            if (data.Length == 0)
                return new byte[0];

            int padCount = 0;
            if (data.Length >= 2 && data[data.Length - 1] == (byte)'=') padCount++;
            if (data.Length >= 3 && data[data.Length - 2] == (byte)'=') padCount++;
            if (data.Length >= 4 && data[data.Length - 3] == (byte)'=') padCount++;
            int requiredSize = (((data.Length / 4) - 1) * 3) + (3 - padCount);
            byte[] buffer = new byte[requiredSize];

            int sourceIdx = 0;
            int bufferIdx = 0;
            for (int j = 0; j < data.Length; j += 4)
            {
                byte s1 = base64DecodingTable[data[sourceIdx++]];
                byte s2 = base64DecodingTable[data[sourceIdx++]];
                byte s3 = base64DecodingTable[data[sourceIdx++]];
                byte s4 = base64DecodingTable[data[sourceIdx++]];

                byte d1 = (byte)((byte)((byte)(s1 & 0x3f) << 2) | (byte)((byte)(s2 & 0x30) >> 4));
                byte d2 = (byte)((byte)((byte)(s2 & 0x0f) << 4) | (byte)((byte)(s3 & 0x3c) >> 2));
                byte d3 = (byte)((byte)((byte)(s3 & 0x03) << 6) | (byte)((byte)(s4 & 0x3f) >> 0));

                buffer[bufferIdx++] = d1;
                if (s3 == 99)
                    break;      // end padding found
                buffer[bufferIdx++] = d2;
                if (s4 == 99)
                    break;      // end padding found
                buffer[bufferIdx++] = d3;
            }
            return buffer;
        }

        public static string Encode(string value)
        {
            byte[] valueBin = Encoding.ASCII.GetBytes(value);
            byte[] valueBinEncoded = Base64.Encode(valueBin, 0, valueBin.Length);
            return Encoding.ASCII.GetString(valueBinEncoded, 0, valueBinEncoded.Length);
        }

        public static string Decode(string value)
        {
            byte[] valueBin = Encoding.ASCII.GetBytes(value);
            byte[] valueBinDecoded = Base64.Decode(valueBin);
            return Encoding.ASCII.GetString(valueBinDecoded, 0, valueBinDecoded.Length);
        }
    }
}
#endif
