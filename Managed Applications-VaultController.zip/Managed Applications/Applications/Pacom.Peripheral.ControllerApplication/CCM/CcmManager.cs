﻿#if DEBUG
using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.EventQueue;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Applications
{
    public class CcmManager : IDisposable
    {
        /// <summary>
        /// Singleton instatnce of ExpansionCardManager class
        /// </summary>
        private static CcmManager instance = null;
        public static CcmManager CreateInstance()
        {
            if (instance == null)
            {
                instance = new CcmManager();
            }
            return instance;
        }
        
        /// <summary>
        /// Instance of ExpansionCardManager
        /// </summary>
        /// <returns></returns>
        public static CcmManager Instance
        {
            get
            {
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return "TestsRunner instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
                return instance;
            }
        }

        ControllerConfigurationConnection controllerConfigurationConnection = null;
        CardholderConnection cardholderConnection = null;
        CommandConnection commandConnection = null;

        private CcmManager()
        {
            NativeFirewallApi.AddFirewallRule("CCM", 8281, 8284, NativeProtocolType.TCP, RuleDirectionType.FWF_INBOUND);    

            controllerConfigurationConnection = new ControllerConfigurationConnection();
            cardholderConnection = new CardholderConnection();
            commandConnection = new CommandConnection();
            EventQueueManager.Instance.NewEventAdded += new EventHandler<NewEventAddedEventArgs>(Instance_NewEventAdded);
        }

        private void Instance_NewEventAdded(object sender, NewEventAddedEventArgs e)
        {
            if (ConfigurationManager.Instance.IsDebugLoggingSubCategoryEnabled(DebugLoggingSubCategory.FrontEndConnections) == true)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.EventQueue, () =>
                {
                    string messsage = "New Event: ";
                    for (int i = 0; i < 8; i++)
                    {
                        if (e.HighPriorityPresent[i] == true)
                            messsage += string.Format("S{0}C{1}HI", i + 1, e.CountOfEvents[i]);
                        else
                            messsage += string.Format("S{0}C{1}", i + 1, e.CountOfEvents[i]);
                        if (i != 7)
                            messsage += "|";
                    }                
                    return messsage;
                });
            }
        }

        #region IDisposable Members

        bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                if (controllerConfigurationConnection != null)
                {
                    controllerConfigurationConnection.Dispose();
                    controllerConfigurationConnection = null;
                }
                if (cardholderConnection != null)
                {
                    cardholderConnection.Dispose();
                    cardholderConnection = null;
                }
                if (commandConnection != null)
                {
                    commandConnection.Dispose();
                    commandConnection = null;
                }
                instance = null;
            }

            // Free any unmanaged objects here.            
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}
#endif
