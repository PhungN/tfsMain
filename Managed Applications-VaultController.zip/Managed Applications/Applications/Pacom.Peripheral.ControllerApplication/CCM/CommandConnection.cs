﻿#if DEBUG
using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Protocol;

namespace Pacom.Peripheral.Applications
{
    public class CommandConnection : IDisposable
    {
        /// <summary>
        /// The TCP/IP port where commands can be queried on.
        /// </summary>
        public const int ConnectionPort = 8284;
        
        private TcpIPManager connectionManager;
        private Dictionary<TcpIPConnection, CommandConnectionData> activeConnections = new Dictionary<TcpIPConnection, CommandConnectionData>();

        public CommandConnection()
        {
            connectionManager = TcpIPManager.Instance;
            connectionManager.StartListening(ConnectionPort, true, connectionManager_OnIncomingConnection, null);
            Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
            {
                return string.Format("COMMAND QY: Expecting frontend connection on TCP/IP port {0}.", ConnectionPort);
            });
        }

        private void connectionManager_OnIncomingConnection(object sender, IncomingConnectionEventArgs e)
        {
            TcpIPConnection connection = (TcpIPConnection)e.Connection;
            connection.DataReceived += new EventHandler<ReceivedDataEventArgs>(connection_DataReceived);
            connection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(connection_ConnectionStateChanged);
            activeConnections.Add(connection, new CommandConnectionData(connection));                        
            connection.Connect();
            Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
            {
                return string.Format("COMMAND QY: Frontend connected. (Active connections: {0})", activeConnections.Count);
            });
        }

        void connection_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            TcpIPConnection connection = (TcpIPConnection)sender;
            if (activeConnections.ContainsKey(connection) == true)
            {
                if (e.NewConnectionState == ConnectionState.Disconnected)
                {
                    activeConnections.Remove(connection);
                    Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return string.Format("COMMAND QY: Frontend disconnected. (Active connections: {0})", activeConnections.Count);
                    });
                }
            }            
        }

        void connection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            TcpIPConnection connection = (TcpIPConnection)sender;
            if (activeConnections.ContainsKey(connection) == true)
            {
                activeConnections[connection].ProcessCommand(e.Data);
            }                        
        }

        #region IDisposable Members

        bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                foreach (var connection in activeConnections)
                {
                    try
                    {
                        if (connection.Value != null)
                        {
                            // Todo: Unsubscribe events
                            connection.Value.Dispose();
                        }
                    }
                    catch
                    {
                    }
                }

                // Free any other managed objects here.              
                connectionManager.StopListening(connectionManager_OnIncomingConnection);
            }

            // Free any unmanaged objects here.            
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
#endif
