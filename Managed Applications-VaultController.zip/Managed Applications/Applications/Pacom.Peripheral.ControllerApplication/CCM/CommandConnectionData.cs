﻿#if DEBUG
using System.Collections.Generic;
using System.Reflection;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.FrontEndConnection;
using Pacom.Peripheral.Messaging.OpenPacomMessages;
using Pacom.Serialization.Formatters.Asn1;
using System;
using System.IO;
using System.Text;
using System.Xml.Linq;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.DeviceLoop;
using Pacom.Peripheral.Protocol;

namespace Pacom.Peripheral.Applications
{
    public class CommandConnectionData : IDisposable
    {
        private TcpIPConnection connection;
        private byte[] dataReceived = new byte[0];

        public class StringChunkFromXml
        {
            public string Text;
            public int Count;
        }

        public CommandConnectionData(TcpIPConnection connection)
        {
            this.connection = connection;
        }

        public void ProcessCommand(byte[] rawCommand)
        {
            byte[] dataReceivedNew = new byte[dataReceived.Length + rawCommand.Length];
            Array.Copy(dataReceived, 0, dataReceivedNew, 0, dataReceived.Length);
            Array.Copy(rawCommand, 0, dataReceivedNew, dataReceived.Length, rawCommand.Length);
            dataReceived = dataReceivedNew;
            // Discard data if too much
            if (dataReceived.Length > 10000000)
            {
                dataReceived = new byte[0];
            }
            // Check if closing tag has been found
            if (closingResponseFound(dataReceived) == true)
            {
                try
                {
                    XDocument xdoc = processRawCommand(dataReceived);
                    switch (getRequestType(xdoc))
                    {
                        case RequestType.SetDateTime:
                        {
                            connection.Send(parseSetDateTimeRequest(xdoc), null);
                            break;
                        }
                        case RequestType.ProgramSerialNumber:
                        {
                            connection.Send(parseProgramSerialNumberRequest(xdoc), null);
                            break;
                        }
                        case RequestType.FirmwareUpdateImage:
                        {
                            connection.Send(parseFirmwareUpdateImage(xdoc), null);
                            break;
                        }
                        case RequestType.Asn1Command:
                        {
                            connection.Send(parseAsn1Command(xdoc), null);
                            break;
                        }
                    }
                }
                finally
                {
                    dataReceived = new byte[0];
                }
            }
        }

        private bool closingResponseFound(byte[] data)
        {
            byte[] responseEnd = Encoding.ASCII.GetBytes(@"</request>");
            if (data.Length < responseEnd.Length)
                return false;

            for (int i = 1; i <= responseEnd.Length; i++)
            {
                if (data[data.Length - i] != responseEnd[responseEnd.Length - i])
                {
                    return false;
                }
            }
            return true;
        }

        private enum RequestType
        {
            Unknown,
            ProgramSerialNumber,
            FirmwareUpdateImage,
            Asn1Command,
            SetDateTime
        }

        private XDocument processRawCommand(byte[] rawCommand)
        {
            try
            {
                string commandAsString = Encoding.Default.GetString(rawCommand, 0, rawCommand.Length);
                return XDocument.Parse(commandAsString);
            }
            catch
            {
                return null;
            }
        }

        private RequestType getRequestType(XDocument xdoc)
        {
            /*
            * <request type='???'>
            *    ....
            * </request>
            */

            if (xdoc == null)
            {
                return RequestType.Unknown;
            }

            try
            {
                var request = xdoc.Element("request");
                XAttribute xRequestType = request.Attribute("type");

                if (xRequestType == null || xRequestType.Value == null)
                {
                    return RequestType.Unknown;
                }

                switch (xRequestType.Value.ToLower())
                {
                    default:
                        return RequestType.Unknown;
                    case "programserialnumber":
                        return RequestType.ProgramSerialNumber;
                    case "setdatetime":
                        return RequestType.SetDateTime;
                    case "firmwareupdateimage":
                        return RequestType.FirmwareUpdateImage;
                    case "asn1command":
                        return RequestType.Asn1Command;
                }
            }
            catch
            {
                return RequestType.Unknown;
            }
        }

        private Asn1DerFormatter asnEventSerializer;

        private byte[] parseAsn1Command(XDocument xdoc)
        {
            try
            {
                var xRequest = xdoc.Element("request");
                var xAsn1Command = xRequest.Element("asn1command");
                byte[] bytes = Encoding.ASCII.GetBytes(xAsn1Command.Value);
                byte[] asn1 = Base64.Decode(bytes);
                string hex = BitConverter.ToString(asn1).Replace("-", "");
                Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication,
                                       () => string.Format("CCM: ASN1Command: {0}", hex));

                if (asnEventSerializer == null)
                {
                    Assembly assembly = Assembly.Load("Pacom.Shared.Commands");
                    ITypeLookup typesList = new HashTypeLookup(new List<Assembly>() { assembly });
                    asnEventSerializer = new Asn1DerFormatter(typesList, true, new StreamingContext());
                }


                CommandMessageBase message = null;
                using (MemoryStream ms = new MemoryStream(asn1))
                {
                    message = (CommandMessageBase)asnEventSerializer.Deserialize(ms);
                }
                message.SourceAddress = new LogicalAddress(0, NodeType.Site, (uint)ConfigurationManager.Instance.ControllerConfiguration.SiteId, OpenPacomObjectType.Controller, 1).ToString();
                message.UtcTimestamp = DateTime.UtcNow;

                OpenPacomMessage<OpenPacomCommandMessage<OpenPacomCommandData>> openpm = new OpenPacomMessage<OpenPacomCommandMessage<OpenPacomCommandData>>();
                openpm.Message = new OpenPacomCommandMessage<OpenPacomCommandData>();
                openpm.Message.SpecificCommandMessage = new OpenPacomCommandData();
                openpm.Message.SpecificCommandMessage.DataFormat = DataEncodingFormat.Asn1Der;
                Dictionary<string, object> dict = new Dictionary<string, object>
                                                  {
                                                      { "OpenPacomCommandMessage", openpm },
                                                      { "CommandMessage", message }
                                                  };

                ReceivedDataEventArgs rde = new ReceivedDataEventArgs(asn1, dict);
                string reason;
                if (FrontEndConnectionManager.Instance.CcmInjectCommand(0, rde, out reason))
                {
                    return responseOk();
                }

                if (string.IsNullOrEmpty(reason))
                {
                    reason = "Unable to send command";
                }

                return responseError(reason);
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication,
                                       () => string.Format("CCM: ASN1Command error: {0}", ex.ToString()));
                return responseError("ASN1Command exception");
            }
        }

        private byte[] parseFirmwareUpdateImage(XDocument xdoc)
        {
            try
            {
                var xRequest = xdoc.Element("request");
                var xFirmwareUpdateImage = xRequest.Element("firmwareupdateimage");
                var xVersion = xFirmwareUpdateImage.Element("version");
                var xDeviceType = xFirmwareUpdateImage.Element("devicetype");

                string version = Base64.Decode(xVersion.Value);
                string deviceType = Base64.Decode(xDeviceType.Value);

                DeviceType dt = (DeviceType)Enum.Parse(typeof(DeviceType), deviceType, false);
                FirmwareVersion fv = new FirmwareVersion(version);

                string firmwareProcessingFile = FirmwareManager.GetFirmwareFileName(dt);
                if (string.IsNullOrEmpty(firmwareProcessingFile))
                {
                    return responseError("Unable to determine firmwareProcessingFile");
                }

                string newFileName = FileSystemPaths.FirmwareDownloadPath + "\\" + firmwareProcessingFile;

                if (File.Exists(newFileName))
                {
                    File.Delete(newFileName);
                }

                using (var f = File.OpenWrite(newFileName))
                {
                    byte[] imageBytes = Convert.FromBase64String(xFirmwareUpdateImage.Element("image").Value);
                    f.Write(imageBytes, 0, imageBytes.Length);
                    f.Close();
                }

                DeviceLoopManager.Instance.UpdateFirmware(dt, FileSystemPaths.FirmwareDownloadPath + "\\", newFileName, fv);

                return responseOk();
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.FimrwareManager,
                                       () => string.Format("CCM: Firmware upgrade request error: {0}", ex.ToString()));
                return responseError("CCM: Firmware upgrade request exception");
            }
        }

        private byte[] parseSetDateTimeRequest(XDocument xdoc)
        {
            try
            {
                var xRequest = xdoc.Element("request");
                var xDateTime = xRequest.Element("datetime");

                // datetime validation
                DateTime dt = DateTime.ParseExact(xDateTime.Value, "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);

                Hal.Calendar.SetUtcTime(dt, true);

                Logger.LogDebugMessage(LoggerClassPrefixes.FimrwareManager, () => "CCM: Controller time updated");

                return responseOk();
            }
            catch
            {
                return responseError("SerialNumberRequest exception");
            }
        }

        private byte[] parseProgramSerialNumberRequest(XDocument xdoc)
        {
            try
            {
                var xRequest = xdoc.Element("request");
                var xSerial = xRequest.Element("serial");
                var xDeviceAddress = xRequest.Element("deviceaddress");

                // Serial validation
                string serial = xSerial.Value.Trim();
                if (serial.Length != "0000-0000-000000".Length)
                    return responseError("Serial length invalid");

                if (serial[4] != '-' || serial[9] != '-')
                    return responseError("Serial format error");

                // Address validation
                int deviceAddress = int.Parse(xDeviceAddress.Value) - 1;

                if (deviceAddress < 0 || deviceAddress > 128)
                    return responseError("Invalid device loop address");

                var setSerialMessage = new Pacom.Peripheral.Messaging.DeviceLoopMessages.SetSerialNumberCommand(serial);
                Pacom.Peripheral.DeviceLoop.DeviceLoopManager.Instance.SendMessage(setSerialMessage, deviceAddress);

                var getSerialMessage = new Pacom.Peripheral.Messaging.DeviceLoopMessages.RequestSerialNumberCommand();
                Pacom.Peripheral.DeviceLoop.DeviceLoopManager.Instance.SendMessage(getSerialMessage, deviceAddress);

                return responseOk();
            }
            catch
            {
                return responseError("SerialNumberRequest exception");
            }
        }

        private byte[] responseNoData()
        {
            return Encoding.ASCII.GetBytes("<response type='nodata'></response>");
        }

        private byte[] responseOk()
        {
            return Encoding.ASCII.GetBytes("<response type='Ok'></response>");
        }

        private byte[] responseError(string message)
        {
            StringBuilder send = new StringBuilder(40 + message.Length);
            send.Append("<response type='error'>");
            if (string.IsNullOrEmpty(message) == false)
            {
                send.Append(message);
            }
            send.Append("</response>");
            return Encoding.ASCII.GetBytes(send.ToString());
        }

        #region IDisposable Members

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.              
                connection.Dispose();
                connection = null;
            }

            // Free any unmanaged objects here.            
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}

#endif
