﻿#if DEBUG
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml.Linq;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Protocol;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Peripheral.Common.Utilities;

namespace Pacom.Peripheral.Applications
{
    public class ControllerConfigurationConnectionData : IDisposable
    {
        private TcpIPConnection connection;
        private byte[] dataReceived = new byte[0];

        public ControllerConfigurationConnectionData(TcpIPConnection connection)
        {
            this.connection = connection;
        }

        public void ProcessCommand(byte[] rawCommand)
        {
            byte[] dataReceivedNew = new byte[dataReceived.Length + rawCommand.Length];
            Array.Copy(dataReceived, 0, dataReceivedNew, 0, dataReceived.Length);
            Array.Copy(rawCommand, 0, dataReceivedNew, dataReceived.Length, rawCommand.Length);
            dataReceived = dataReceivedNew;
            // Discard data if too much
            if (dataReceived.Length > 500000)
            {
                dataReceived = new byte[0];
            }
            // Check if closing tag has been found
            if (closingResponseFound(dataReceived) == true)
            {
                try
                {
                    XDocument xdoc = processRawCommand(dataReceived);
                    switch (getRequestType(xdoc))
                    {
                        case RequestType.GetConfiguration:
                            {
                                connection.Send(parseGetConfiguration(), null);
                            }
                            break;
                        case RequestType.SetConfiguration:
                            {
                                if (parseSetConfiguration(xdoc) == true)
                                {
                                    connection.Send(responseOk(), null);
                                }
                                else
                                {
                                    connection.Send(responseError(), null);
                                }
                            }
                            break;
                        case RequestType.Unknown:
                            connection.Send(responseError(), null);
                            break;
                    }
                }
                finally
                {
                    dataReceived = new byte[0];
                }
            }
        }

        private bool closingResponseFound(byte[] data)
        {
            byte[] responseEnd = Encoding.ASCII.GetBytes(@"</request>");
            if (data.Length < responseEnd.Length)
                return false;

            for (int i = 1; i <= responseEnd.Length; i++)
            {
                if (data[data.Length - i] != responseEnd[responseEnd.Length - i])
                {
                    return false;
                }
            }
            return true;
        }

        private enum RequestType
        {
            Unknown,
            GetConfiguration,
            SetConfiguration,
            GetAccessControlMode,
        }

        private XDocument processRawCommand(byte[] rawCommand)
        {
            try
            {
                string commandAsString = Encoding.ASCII.GetString(rawCommand, 0, rawCommand.Length);
                return XDocument.Parse(commandAsString);
            }
            catch
            {
                return null;
            }
        }

        private RequestType getRequestType(XDocument xdoc)
        {

            /*
            * <request type='???'>
            *    ....
            * </request>
            */

            if (xdoc == null)
                return RequestType.Unknown;

            RequestType result = RequestType.Unknown;
            try
            {
                var request = xdoc.Element("request");
                XAttribute xRequestType = request.Attribute("type");

                if (xRequestType != null && xRequestType.Value != null)
                {
                    if (string.Compare(xRequestType.Value, "getconfiguration", true) == 0)
                        result = RequestType.GetConfiguration;
                    else if (string.Compare(xRequestType.Value, "setconfiguration", true) == 0)
                        result = RequestType.SetConfiguration;
                    else if (string.Compare(xRequestType.Value, "getaccesscontrolmode", true) == 0)
                        result = RequestType.GetAccessControlMode;
                }
            }
            catch
            {
                result = RequestType.Unknown;
            }
            return result;
        }

        private static HashTypeLookup getListOfTypes()
        {
            HashTypeLookup lookup = new HashTypeLookup(new List<Assembly>() { 
                                                             Assembly.Load("Pacom.Shared.Configuration"), 
                                                             Assembly.Load("Pacom.Shared.Access") 
                                                           });
            lookup.AddType(typeof(Pacom.Core.Contracts.Schedule));
            lookup.AddType(typeof(Pacom.Core.Contracts.AreaAccessPrivilege));
            return lookup;
        }

        private bool parseSetConfiguration(XDocument xdoc)
        {
            var xRequest = xdoc.Element("request");
            string configAsString = xRequest.Value;
            if (string.IsNullOrEmpty(configAsString) == false)
            {
                byte[] configBeforeBase64 = Encoding.ASCII.GetBytes(configAsString);
                byte[] asnData = Base64.Decode(configBeforeBase64);

                CommonUtilities.DeleteFile(FileSystemPaths.WebTemplateDownloadFilePath);
                if (CommonUtilities.CreateOrAppendToFileWithRetries(FileSystemPaths.WebTemplateDownloadFilePath, FileMode.Create, asnData) == false)
                {
                    string message = string.Format("CCM: Template configuration import failed. Unable to create file {0} in the system.", FileSystemPaths.WebTemplateDownloadFilePath);
                    Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return message;
                    });
                    return false;
                }

                ConfigurationManager.Instance.LoadFromDtp("/WebTemplateDownload", null, ConfigurationManager.WebServerUser, true,
                                          typeof(Configuration.ConfigurationCommon.Device8003Configuration));
                return true;
            }
            return false;
        }

        private byte[] parseGetConfiguration()
        {
            try
            {
                ConfigurationManager.Instance.PrepareDtpUpload("/WebTemplateUpload");
                byte[] data;
                using (FileStream fileStream = new FileStream(FileSystemPaths.WebTemplateUploadFilePath, FileMode.Open))
                {
                    data = new byte[(int)fileStream.Length];
                    fileStream.Read(data, 0, data.Length);
                }
                byte[] data64 = Base64.Encode(data, 0, data.Length);
                data = null;
                var xml = new XElement("response",
                            new XAttribute("type", "configurationdata"),
                            new XCData(Encoding.ASCII.GetString(data64, 0, data64.Length)));
                data64 = null;
                return Encoding.ASCII.GetBytes(xml.ToString());
            }
            catch (Exception ex)
            {
                return responseError(ex.Message);
            }
        }

        private byte[] responseNoData()
        {
            return Encoding.ASCII.GetBytes("<response type='nodata' />");
        }

        private byte[] responseOk()
        {
            return Encoding.ASCII.GetBytes("<response type='Ok' />");
        }

        private byte[] responseError()
        {
            return Encoding.ASCII.GetBytes("<response type='error' />");
        }

        private byte[] responseError(string message)
        {
            return Encoding.ASCII.GetBytes(string.Format("<response type='error'><message>{0}</message></response>", message));
        }

        #region IDisposable Members

        bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.              
                connection.Dispose();
                connection = null;
            }

            // Free any unmanaged objects here.            
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}

#endif
