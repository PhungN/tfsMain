﻿#if DEBUG
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Threading;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Protocol;
using Pacom.Peripheral.AccessControl;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Applications
{
    public class CardholderConnectionData : IDisposable
    {
        private TcpIPConnection connection;
        private byte[] dataReceived = new byte[0];

        public CardholderConnectionData(TcpIPConnection connection)
        {
            this.connection = connection;
        }
        
        public void ProcessCommand(byte[] rawCommand)
        {
            byte[] dataReceivedNew = new byte[dataReceived.Length + rawCommand.Length];
            Array.Copy(dataReceived, 0, dataReceivedNew, 0, dataReceived.Length);
            Array.Copy(rawCommand, 0, dataReceivedNew, dataReceived.Length, rawCommand.Length);
            dataReceived = dataReceivedNew;
            // Discard data if too much
            if (dataReceived.Length > 500000)
            {
                dataReceived = new byte[0];
            }
            // Check if closing tag has been found
            if (closingResponseFound(dataReceived) == true)
            {
                try
                {
                    XDocument xdoc = processRawCommand(dataReceived);
                    switch (getRequestType(xdoc))
                    {
                        case RequestType.SetCardholder:
                            {
                                CardInformation cardInformation = null;
                                cardInformation = parseCardholderItem(xdoc);
                                if (cardInformation != null)
                                {
                                    AccessControlManager.Instance.AddOrUpdateCardInformation(cardInformation);
                                    connection.Send(responseOk(), null);
                                }
                                else
                                {
                                    connection.Send(responseError(), null);
                                }
                            }
                            break;
                        case RequestType.GetCardholder:
                            {
                                long cardId = parseCardholderId(xdoc);
                                CardInformation cardInformation;
                                CardNumberHolder cardNumber = new CardNumberHolder(cardId);
                                if (AccessControlManager.Instance.GetCardInformation(cardNumber, out cardInformation) == true)
                                {
                                    connection.Send(responseCardholderItem(cardInformation), null);
                                }
                                else
                                {
                                    connection.Send(responseNoData(), null);
                                }
                            }
                            break;
                        case RequestType.GetCardholderIds:
                            {
                                List<long> cardholderIds = AccessControlManager.Instance.CardHashes();
                                if (cardholderIds != null && cardholderIds.Count > 0)
                                    connection.Send(responseCardholderIds(cardholderIds), null);
                                else
                                    connection.Send(responseNoData(), null);
                            }
                            break;

                        case RequestType.GetUniqueCardholderIds:
                            {
                                var cardholders = AccessControlManager.Instance.GetUniqueCardHolderIDs();
                                if (cardholders != null && cardholders.Count > 0)
                                    connection.Send(responseCardholders(cardholders), null);
                                else
                                    connection.Send(responseNoData(), null);
                            }
                            break;
                        case RequestType.GetUniqueCardholder:
                            {
                                var cardHolder = parseUniqueCardholder(xdoc);
                                CardInformation cardInformation = AccessControlManager.Instance.GetCardInformation(cardHolder);
                                if (cardInformation != null)
                                    connection.Send(responseCardholderItem(cardInformation), null);
                                else
                                    connection.Send(responseNoData(), null);
                            }
                            break;
                            
                        case RequestType.CountCardholder:
                            connection.Send(responseCount(AccessControlManager.Instance.CountCards()), null);
                            break;
                        case RequestType.DeleteCardholder:
                            {
                                long cardId = parseCardholderId(xdoc);
                                CardNumberHolder cardNumber = null;
                                if (cardId > 0)
                                {
                                    cardNumber = new CardNumberHolder(cardId);
                                    AccessControlManager.Instance.DeleteCard(cardNumber, false, true);
                                    connection.Send(responseOk(), null);
                                }
                            }
                            break;
                        case RequestType.GetElevatorFloorsAccess:
                            {
                                var cardHolder = parseUniqueCardholder(xdoc);
                                CardInformation cardInformation = AccessControlManager.Instance.GetCardInformation(cardHolder);
                                if (cardInformation != null)
                                    connection.Send(getElevatorFloorsAccessItem(cardInformation), null);
                                else
                                    connection.Send(responseNoData(), null);
                            }
                            break;
                        case RequestType.SetElevatorFloorsAccess:
                            {
                                CardInformation cardInformation = null;
                                cardInformation = setElevatorFloorsAccessItem(xdoc);
                                if (cardInformation != null)
                                {
                                    AccessControlManager.Instance.UpdateElevatorFloorsAccess(cardInformation);
                                    connection.Send(responseOk(), null);
                                }
                                else
                                {
                                    connection.Send(responseError(), null);
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
                finally
                {
                    dataReceived = new byte[0];
                }
            }
        }

        private bool closingResponseFound(byte[] data)
        {
            byte[] responseEnd = Encoding.ASCII.GetBytes(@"</request>");
            if (data.Length < responseEnd.Length)
                return false;

            for (int i = 1; i <= responseEnd.Length; i++)
            {
                if (data[data.Length - i] != responseEnd[responseEnd.Length - i])
                {
                    return false;
                }
            }
            return true;
        }

        private enum RequestType
        {
            Unknown,
            GetCardholder,
            SetCardholder,
            DeleteCardholder,
            CountCardholder,
            GetCardholderIds,
            GetUniqueCardholderIds,
            GetUniqueCardholder,
            GetElevatorFloorsAccess,
            SetElevatorFloorsAccess,

        }

        private XDocument processRawCommand(byte[] rawCommand)
        {
            try
            {
                string commandAsString = Encoding.ASCII.GetString(rawCommand, 0, rawCommand.Length);
                return XDocument.Parse(commandAsString);
            }
            catch
            {
                return null;
            }
        }

        private RequestType getRequestType(XDocument xdoc)
        {

            /*
            * <request type='???'>
            *    ....
            * </request>
            */

            if (xdoc == null)
                return RequestType.Unknown;

            RequestType result = RequestType.Unknown;
            try
            {
                var request = xdoc.Element("request");
                XAttribute xRequestType = request.Attribute("type");

                if (xRequestType != null && xRequestType.Value != null)
                {
                    switch (xRequestType.Value.ToLower())
                    {
                        case "getcardholder": result = RequestType.GetCardholder; break;
                        case "getcardholderids": result = RequestType.GetCardholderIds; break;
                        case "setcardholder": result = RequestType.SetCardholder; break;
                        case "countcardholder": result = RequestType.CountCardholder; break;
                        case "deletecardholder": result = RequestType.DeleteCardholder; break;
                        case "getuniquecardholderids": result = RequestType.GetUniqueCardholderIds; break;
                        case "getuniquecardholder": result = RequestType.GetUniqueCardholder; break;
                        case "getelevatorfloorsaccess": result = RequestType.GetElevatorFloorsAccess; break;
                        case "setelevatorfloorsaccess": result = RequestType.SetElevatorFloorsAccess; break;
                    }
                }
            }
            catch
            {
                result = RequestType.Unknown;
            }
            return result;
        }

        private byte[] responseCardholderItem(CardInformation cardInformation)
        {
            try
            {
                string cardholderId="";
                if (cardInformation.CardNumber.Legacy != null && cardInformation.CardNumber.Legacy.IsValid)
                    cardholderId = cardInformation.CardNumber.Legacy.AsLong().ToString();
                StringBuilder sb = new StringBuilder();
                sb.Append("<response type='cardholder'>");
                sb.AppendFormat("<cardholder cardholderid='{0}'>", cardholderId);
                sb.AppendFormat("<userpin>{0}</userpin>", cardInformation.UserPin);
                sb.AppendFormat("<groupid>{0}</groupid>", cardInformation.GroupId);
                sb.AppendFormat("<blocked>{0}</blocked>", cardInformation.Blocked);
                sb.AppendFormat("<expired>{0}</expired>", cardInformation.Expired);
                sb.AppendFormat("<userflags>{0}</userflags>", (int)cardInformation.UserFlags);
                sb.AppendFormat("<lastused>{0}</lastused>", cardInformation.LastUsed.Ticks);
                sb.AppendFormat("<startdate>{0}</startdate>", cardInformation.StartDate.ToString("dd/MM/yyyy"));
                sb.AppendFormat("<enddate>{0}</enddate>", cardInformation.EndDate.ToString("dd/MM/yyyy"));
                sb.AppendFormat("<schedules>{0}</schedules>", getReaderSchedules(cardInformation));
                sb.AppendFormat("<version>{0}</version>", CardStorageParameters.FrameVersionLegacy);
                sb.AppendFormat("<floors>{0}</floors>", getFloorsAccess(cardInformation));
                sb.AppendFormat("<floorsAccessTimezoneId>{0}</floorsAccessTimezoneId>", cardInformation.FloorsAccessTimezoneId);
                sb.Append("</cardholder></response>");
                return Encoding.ASCII.GetBytes(sb.ToString());
            }
            catch
            {
                return responseError();
            }
        }

        private byte[] responseCardholderIds(List<long> cardholderIds)
        {
            try
            {
                string response = "<response type='cardholderids'>";
                foreach (var cardholderId in cardholderIds)
                {
                    response += string.Format("<id>{0}</id>", cardholderId);
                }
                response += "</response>";
                return Encoding.ASCII.GetBytes(response);
            }
            catch
            {
                return responseError();
            }
        }

        private CardInformation parseCardholderItem(XDocument xdoc)
        {
            CardInformation result = null;
            try
            {
                var xRequest = xdoc.Element("request");
                var xCardholder = xRequest.Element("cardholder");

                result = new CardInformation(DateTime.UtcNow);
                result.CardNumber = new CardNumberHolder(long.Parse(xCardholder.Attribute("cardholderid").Value));
                result.UserPin = int.Parse(xCardholder.Element("userpin").Value);
                result.GroupId = int.Parse(xCardholder.Element("groupid").Value);
                if (xCardholder.Element("blocked").Value.ToLower() == "true")
                    result.Blocked = true;
                else
                    result.Blocked = false;
                if (xCardholder.Element("expired").Value.ToLower() == "true")
                    result.Expired = true;
                else
                    result.Expired = false;

                try
                {
                    int userFlags = int.Parse(xCardholder.Element("userflags").Value);
                    result.UserFlags = (LegacyCardUserFlags)userFlags;
                }
                catch
                {
                    result.UserFlags = LegacyCardUserFlags.None;
                }

                result.SetStartDate(xCardholder.Element("startdate").Value.ToLower());
                result.SetEndDate(xCardholder.Element("enddate").Value.ToLower());

                var xSchedules = xCardholder.Elements("schedules");
                if (xSchedules != null)
                {
                    var xScheduleList = xSchedules.Elements("schedule");
                    if (xScheduleList != null)
                    {
                        int[] scheduleIds = new int[CardInformation.LegacyReaderScheduleCount];
                        foreach (XElement xSchedule in xScheduleList)
                        {
                            int readerId = int.Parse(xSchedule.Attribute("readerid").Value);
                            int scheduleId = int.Parse(xSchedule.Value);
                            scheduleIds[readerId - 1] = scheduleId;
                        }
                        result.SetSchedules(scheduleIds);
                    }
                }

                var xFloors = xCardholder.Elements("floors");
                if (xFloors != null)
                {
                    var xFloorList = xFloors.Elements("floor");
                    if (xFloorList != null)
                    {
                        bool[] floors = new bool[CardInformation.LegacyFloorAccessCount];
                        foreach (XElement xFloor in xFloorList)
                        {
                            int floorId = int.Parse(xFloor.Value);
                            floors[floorId - 1] = true;
                        }
                        result.FloorsAccess = floors;
                    }
                }
                result.FloorsAccessTimezoneId = int.Parse(xCardholder.Element("floorsAccessTimezoneId").Value);

            }
            catch
            {
                result = null;
            }

            return result;
        }

        private long parseCardholderId(XDocument xdoc)
        {

            long cardId = -1;

            /*
            * <request type='getcardholder'>
            *    <cardholderid>1</cardholderid>
            * </request>
            */
            try
            {
                var request = xdoc.Element("request");
                var xCardholderid = request.Element("cardholderid");
                if (xCardholderid != null)
                {
                    cardId = long.Parse(xCardholderid.Value);
                }
            }
            catch
            {
                cardId = -1;
            }

            return cardId;
        }

        private byte[] responseCount(int count)
        {
            return Encoding.ASCII.GetBytes(string.Format("<response type='cardholdercount'><count>{0}</count></response>", count.ToString()));
        }

        private byte[] responseNoData()
        {
            return Encoding.ASCII.GetBytes("<response type='nodata'></response>");
        }

        private byte[] responseOk()
        {
            return Encoding.ASCII.GetBytes("<response type='Ok'></response>");
        }

        private byte[] responseError()
        {
            return Encoding.ASCII.GetBytes("<response type='error'></response>");
        }

        private byte[] responseCardholders(List<UniqueCardHolderId> cardholders)
        {
            try
            {
                StringBuilder sb = new StringBuilder("<response type='uniquecardholderids'>");
                foreach (var cardholder in cardholders)
                {
                    sb.AppendFormat("<cardholder>{0}</cardholder>", cardholder.ToString());
                }
                sb.Append("</response>");
                return Encoding.ASCII.GetBytes(sb.ToString());
            }
            catch
            {
                return responseError();
            }
        }

        private UniqueCardHolderId parseUniqueCardholder(XDocument xdoc)
        {
            var cardHolder = new UniqueCardHolderId();
            var request = xdoc.Element("request");
            try
            {
                cardHolder.Id = long.Parse(request.Element("id").Value);
            }
            catch { }

            cardHolder.StartDate = CardInformation.ParseStartDate(request.Element("startdate").Value);
            cardHolder.EndDate = CardInformation.ParseEndDate(request.Element("enddate").Value);
            return cardHolder;
        }

        private string getReaderSchedules(CardInformation cardInformation)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i <= CardInformation.LegacyReaderScheduleCount; i++)
            {
                if (cardInformation.GetSchedule(i) >= 1)
                {
                    sb.AppendFormat("<schedule readerid='{0}'>{1}</schedule>", i, cardInformation.GetSchedule(i));
                }
            }
            return sb.ToString();
        }

        private string getFloorsAccess(CardInformation cardInformation)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < cardInformation.FloorsAccess.Length; i++)
            {
                if (cardInformation.FloorsAccess[i] == true)
                    sb.AppendFormat("<floor>{0}</floor>", i + 1);
            }
            return sb.ToString();
        }

        private byte[] getElevatorFloorsAccessItem(CardInformation cardInformation)
        {
            try
            {
                string cardNumber = "";
                if (cardInformation.CardNumber.Legacy != null && cardInformation.CardNumber.Legacy.IsValid)
                    cardNumber = cardInformation.CardNumber.Legacy.AsLong().ToString();
                StringBuilder sb = new StringBuilder();
                sb.Append("<response type='ElevatorFloorsAccess'>");
                sb.AppendFormat("<cardholder id='{0}' number='{1}'>", cardInformation.CardId, cardNumber);
                sb.AppendFormat("<startdate>{0}</startdate>", cardInformation.StartDate.ToString("dd/MM/yyyy"));
                sb.AppendFormat("<enddate>{0}</enddate>", cardInformation.EndDate.ToString("dd/MM/yyyy"));
                sb.AppendFormat("<floors>{0}</floors>", getFloorsAccess(cardInformation));
                sb.AppendFormat("<floorsAccessTimezoneId>{0}</floorsAccessTimezoneId>", cardInformation.FloorsAccessTimezoneId);
                sb.Append("</cardholder></response>");
                return Encoding.ASCII.GetBytes(sb.ToString());
            }
            catch
            {
                return responseError();
            }
        }

        private CardInformation setElevatorFloorsAccessItem(XDocument xdoc)
        {
            CardInformation result = null;
            try
            {
                var xRequest = xdoc.Element("request");
                var xCardholder = xRequest.Element("cardholder");
                result = new CardInformation(DateTime.UtcNow);
                result.CardId = int.Parse(xCardholder.Attribute("id").Value);
                result.CardNumber = new CardNumberHolder(long.Parse(xCardholder.Attribute("number").Value));
                result.SetStartDate(xCardholder.Element("startdate").Value.ToLower());
                result.SetEndDate(xCardholder.Element("enddate").Value.ToLower());
                var xFloors = xCardholder.Elements("floors");
                if (xFloors != null)
                {
                    var xFloorList = xFloors.Elements("floor");
                    if (xFloorList != null)
                    {
                        bool[] floors = new bool[CardInformation.LegacyFloorAccessCount];
                        foreach (XElement xFloor in xFloorList)
                        {
                            int floorId = int.Parse(xFloor.Value);
                            floors[floorId - 1] = true;
                        }
                        result.FloorsAccess = floors;
                    }
                }
                result.FloorsAccessTimezoneId = int.Parse(xCardholder.Element("floorsAccessTimezoneId").Value);
            }
            catch
            {
                result = null;
            }

            return result;
        }

#region IDisposable Members

        bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.              
                connection.Dispose();
                connection = null;
            }

            // Free any unmanaged objects here.            
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

#endregion

    }
}
#endif
