﻿using System;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.AccessControl;
using Pacom.Peripheral.AlarmManagement;
using Pacom.Peripheral.Aperio;
using Pacom.Peripheral.AsisProprietaryReader;
using Pacom.Peripheral.CellularManagement;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.SQLCE;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.DeviceLoop;
using Pacom.Peripheral.EventQueue;
using Pacom.Peripheral.FrontEndConnection;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.InovonicsDeviceLoop;
using Pacom.Peripheral.LocalDevice;
using Pacom.Peripheral.Macros;
using Pacom.Peripheral.OsdpDeviceLoop;
using Pacom.Peripheral.Protocol;
using Pacom.Peripheral.WebServer;
using Pacom.Peripheral.PeerToPeerCommunications;

namespace Pacom.Peripheral.Applications
{
    /// <summary>
    /// The 8003 application.
    /// </summary>
    class ControllerApplication
    {
        private static SingletonList singletons = null;

        static void Main(string[] args)
        {
            System.AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
            SingletonList.ForcedResetRequired += new EventHandler<EventArgs>(Program_ForcedResetRequired);
            ThreadExtensions.ForcedResetRequired += new EventHandler<EventArgs>(Program_ForcedResetRequired);

            Adc.CreateInstance();

            // Deactivate the RS485 transmit enable pin
            Hal.Gpio.ClearOutput(GpioPort.PortB, 28);

            // Is the 8003 in the functional test jig?
            if (Hal.Pcb.FctInput)
            {
                // The application should now take over control of the watchdog timer from the OS
                Fct.PerformFct();
            }

            if (Hal.Pcb.PcbType != PcbType.Pacom8003)
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return "8003 firmware must be run on 8003 hardware!";
                });

                // Enable watchdog timer
                Hal.Gpio.ClearOutput(GpioPort.PortA, 9);
                Hal.Gpio.ConfigurePin(GpioPort.PortA, 9, true, false, false);
                Hal.Gpio.ClearOutput(GpioPort.PortC, 11);
                Hal.Gpio.ConfigurePin(GpioPort.PortC, 11, true, false, false);

                return;
            }

            Pcb.ResetButtonPressed += new EventHandler(Pcb_ResetButtonPressed);
            Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
            {
                return string.Format("Starting [Version {0}]", Assembly.GetExecutingAssembly().GetName().Version);
            });
#if DEBUG
            if (Directory.Exists("\\PublicRegion") == false)
            {
                if (initializeStorage() == false)
                {
                    Hal.WatchdogTimer.CreateInstance(WatchdogType.Native).EnableWatchdogTimer();
                    Application.Closing = true;
                    return;
                }
            }
#else
            if (initializeStorage() == false)
            {
                Hal.WatchdogTimer.CreateInstance(WatchdogType.Native).EnableWatchdogTimer();
                Application.Closing = true;
                return;
            }
#endif

            // The application should now take over control of the watchdog timer from the OS
            // The Fct would create managed instance, the application is using native.
            Hal.WatchdogTimer.CreateInstance(WatchdogType.Native).EnableWatchdogTimer();

            // Add to the shut down file.
            ProcessorResetType resetType;
            try
            {
                Hal.WatchdogTimer.Instance.ReadResetType(out resetType);
            }
            catch
            {
                resetType = ProcessorResetType.Unknown;
            }
            Logger.WriteStartUpDetails(resetType);

            // Read dip switches once only. Prevent changes of the read value by the user.
            bool factoryDefaultConfiguration = Hal.Pcb.DipSwitch1Pin1;    // SW1-1
            bool unusedSwitch = Hal.Pcb.DipSwitch1Pin2;                   // SW1-2

            if (factoryDefaultConfiguration == true)
            {
                Logger.LogWarnMessage(LoggerClassPrefixes.HostingApplication, () => "SW1-1 active, returning to factory defaults");
            }

            try
            {
                setMaxThreadPoolThreads();

                if (factoryDefaultConfiguration == true)
                {
                    // Delete the configuration
                    FileSystemPaths.DeleteFrontEndConfiguration(true);

                    // Delete the card schedules
                    try
                    {
                        File.Delete(FileSystemPaths.LegacyAccessSchedulesConfigFilePath);
                    }
                    catch
                    {
                    }

                    // Remove the users/access database
                    SqlCeDatabase.DeleteDatabase();
                    SramCardAccessor.EraseAll();
                }

                using (singletons = new SingletonList())
                {
#if DEBUG
                    Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return string.Format("Start loading singletons: {0}", NativeMemoryStatus.GetMemoryStatus());
                    });
#endif
                    singletons.CreateInstanceAndRegister<NetworkAdapter>();
                    singletons.CreateInstanceAndRegister<Common.SQLCE.SqlCeDatabase>();
                    singletons.CreateInstanceAndRegister<TimerManager>();

                    if (Common.SQLCE.SqlCeDatabase.Instance.DefaultDatabaseIsValid == true && Directory.Exists(FileSystemPaths.SDCardDataTransferPath) == false)
                    {
                        DirectoryExtensions.Recreate(FileSystemPaths.SDCardDataTransferPath);
                        DirectoryExtensions.Recreate(FileSystemPaths.DataTransferPath);
                    }

                    LicenseManager.CreateInstance(DataFlash.Instance);
                    singletons.CreateInstanceAndRegister<AccessCardManager>();
                    singletons.CreateInstanceAndRegister<ConfigurationManager>
                        (Sram.Instance, DataFlash.Instance, NetworkAdapter.Instance, AccessCardManager.Instance, Adc.Instance);
                    while (singletons.Instance<ConfigurationManager>().Initialize(ConfigurationUpdateReason.Initial, ConfigurationElementsAffected.All, ConfigurationManager.SystemUser) == false)
                    {
                        FileSystemPaths.DeleteFrontEndConfiguration(false);
                    }
                    NetworkAdapter.Instance.BindConfigurationChanged();
                    singletons.CreateInstanceAndRegister<StatusManager>(Sram.Instance, DataFlash.Instance, AccessCardManager.Instance);
                    AccessCardManager.Instance.UpdateStatusManager();
                    StatusLed.SetStatus(SystemStatus.OfflineToFrontEnd);
                    StatusLed.SubscribeConfigurationAndStatusManager();
                    singletons.CreateInstanceAndRegister<SiaOverIPAuthenticatorFactory>();

                    if (factoryDefaultConfiguration == true)
                    {
                        StatusManager.Instance.ClearStorage();
                    }
                    StatusManager.Instance.UpdateFromConfigurationFirstTime();
                    singletons.Instance<NetworkAdapter>().UpdateStatusManager();

                    singletons.CreateInstanceAndRegister<NetworkFirewall>();
                    singletons.CreateInstanceAndRegister<TcpIPManager>();
                    singletons.CreateInstanceAndRegister<UdpIPManager>();

                    singletons.CreateInstanceAndRegister<SyslogManager>();
                    singletons.CreateInstanceAndRegister<EventQueueManager>();
                    Hal.Pcb.InitializeConfiguration();

                    if (factoryDefaultConfiguration == true)
                    {
                        // Delete all configuration stored in SRAM
                        ControllerConnectionTable.DecommisionAll(Sram.Instance);
                        ConfigurationManager.Instance.TimeZoneOffsetMinutes = 0;
                        ConfigurationManager.Instance.Users.RemoveAll();

                        // Flush the event queue
                        EventQueueManager.Instance.Flush();                        
                    }

                    // Start enrolling for events from here
                    EnqueueEventDelegate enqueueEventMethod = singletons.Instance<EventQueueManager>().EnqueueEvent;
                    singletons.CreateInstanceAndRegister<AlarmManager>(enqueueEventMethod);
                    singletons.CreateInstanceAndRegister<StatusAndConfigurationAlarmSubscriber>();
                    singletons.Instance<StatusManager>().SetAlarmManager(singletons.Instance<AlarmManager>());

                    singletons.CreateInstanceAndRegister<FirmwareManager>(new NandFlash());
                    singletons.CreateInstanceAndRegister<FirmwareUpdateAlarmSubscriber>();

                    UsbDevice_DeviceDisconnected(null, null);
                    UsbDevice.Instance.DeviceConnected += new EventHandler<EventArgs>(UsbDevice_DeviceConnected);
                    UsbDevice.Instance.DeviceDisconnected += new EventHandler<EventArgs>(UsbDevice_DeviceDisconnected);

                    OnboardOutputs.ClearAllOutputs();

                    singletons.CreateInstanceAndRegister<ExpansionCardManager>();
                    // The cellular cards are on expension cards. Run this manager after expansion card manager.
                    singletons.CreateInstanceAndRegister<CellularManager>();

                    singletons.CreateInstanceAndRegister<OnboardInputsManager>();
                    // If the 8003 controller need to be auto configured then update the Status Manager accordingly
                    ConfigurationManager.Instance.ControllerConfiguration.AutoConfigureExpansionCards(ExpansionCardManager.Instance.ExpansionCardTypes);
                    singletons.Instance<ExpansionCardManager>().SetStatusForLocalDevice();
                    Hal.Pcb.SetStatusForLocalDevice();

                    singletons.CreateInstanceAndRegister<PeerToPeerConnectionManager>();
                    singletons.CreateInstanceAndRegister<InterlockManager>(); // Has to be before AccessControlAlarmSubscriber
                    singletons.CreateInstanceAndRegister<AccessControlManager>();
                    singletons.CreateInstanceAndRegister<AccessControlAlarmSubscriber>();
                    singletons.CreateInstanceAndRegister<CardScanProcessor>();
                    singletons.Instance<CardScanProcessor>().SetAccessControlManager(singletons.Instance<AccessControlManager>());

                    if (factoryDefaultConfiguration == true)
                    {
                        try
                        {
                            AccessControlManager.Instance.DeleteAll();
                        }
                        catch (Exception ex)
                        {
                            Logger.LogErrorMessage(LoggerClassPrefixes.HostingApplication, () => string.Format("Error returning to factory defaults, unable to clean card database: {0}", ex.Message));
                        }
                    }

                    singletons.CreateInstanceAndRegister<LocalDeviceManager>();
                    singletons.Instance<StatusManager>().SetLocalDevice(singletons.Instance<LocalDeviceManager>());

                    #region Create Device Loops Section

                    singletons.CreateInstanceAndRegister<DeviceLoopManager>();
                    singletons.CreateInstanceAndRegister<DeviceLoopAlarmSubscriber>();
                    singletons.Instance<StatusManager>().SetDeviceLoopManager(singletons.Instance<DeviceLoopManager>());
                    singletons.Instance<DeviceLoopManager>().SetAccessControlManager(singletons.Instance<AccessControlManager>());
                    singletons.Instance<DeviceLoopManager>().RequestKeypadStateMachineInstance += new EventHandler<RequestKeypadStateMachineEventArgs>(deviceLoop_RequestKeypadStateMachineInstance);
                    singletons.CreateInstanceAndRegister<OsdpDeviceLoopManager>();
                    singletons.Instance<OsdpDeviceLoopManager>().SetLocalDeviceLoopManager(singletons.Instance<LocalDeviceManager>());
                    singletons.CreateInstanceAndRegister<AsisProprietaryReaderPortManager>();
                    singletons.Instance<AsisProprietaryReaderPortManager>().SetLocalDeviceLoopManager(singletons.Instance<LocalDeviceManager>());
                    singletons.CreateInstanceAndRegister<InovonicsDeviceLoopManager>();
                    singletons.CreateInstanceAndRegister<AperioManager>();
                    singletons.Instance<AperioManager>().SetAccessControlManager(singletons.Instance<AccessControlManager>());

                    #endregion

                    singletons.Instance<ExpansionCardManager>().ForceInitialExpansionCardsStatus();
                    singletons.Instance<FirmwareManager>().SetDeviceLoopManager(singletons.Instance<DeviceLoopManager>());
                    singletons.CreateInstanceAndRegister<MacroManager>();
                    singletons.Instance<MacroManager>().SetCellularManager(singletons.Instance<CellularManager>());
                    singletons.CreateInstanceAndRegister<ExpressionAlarmSubscriber>();
#if DEBUG
                    singletons.CreateInstanceAndRegister<CcmManager>();
                    singletons.CreateInstanceAndRegister<EventQueueInjector>();
#endif

                    Pcb.OneTouchButtonPressed += new EventHandler(Pcb_OneTouchButtonPressed);

                    singletons.CreateInstanceAndRegister<FrontEndConnectionManager>(singletons.Instance<AccessControlManager>());
                    singletons.CreateInstanceAndRegister<FrontEndAlarmSubscriber>();
                    // The web application is loaded into the memory
                    singletons.CreateInstanceAndRegister<WebServerManager>(new Website.WebsiteRequestHandler());

#if DEBUG
                    Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return string.Format("Finished loading singletons: {0}", NativeMemoryStatus.GetMemoryStatus());
                    });
#endif
                    TimerManager.Instance.Start();

					Hal.Pcb.StartMonitoringUsbFlashDrive();

                    Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return string.Format("Ready [Version {0}]", Assembly.GetExecutingAssembly().GetName().Version);
                    });
#if DEBUG
                    int memoryStatusCounter = 0;
                    while (Application.Closing == false)
                    {
                        if (memoryStatusCounter <= 0)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                            {
                                return NativeMemoryStatus.GetMemoryStatus();
                            });
                            memoryStatusCounter = 3 * 60 * 10; // status every 3 minute
                        }
                        else
                        {
                            memoryStatusCounter--;
                        }
                        Thread.Sleep(100);
                    }
#else
                    Application.WaitOnClose();
#endif
                    StatusManager.Instance.SignalControllerRestarting();

                    #region Device Loops Shutdown Section

                    DeviceLoopManager.Instance.Shutdown();
                    OsdpDeviceLoopManager.Instance.Shutdown();
                    AsisProprietaryReaderPortManager.Instance.Shutdown();
                    InovonicsDeviceLoopManager.Instance.Shutdown();
                    AperioManager.Instance.Shutdown();

                    #endregion

                    StatusManager.Instance.RequestStatusToStorageBeforeRestart();
                    Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return "Restarting...";
                    });
                }
            }
            catch (Exception ex)
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return string.Format("Application caught an unhandled exception : {0}", ex.ToString());
                });
            }

            // Application is not working anymore. Turnoff the state led.
            Hal.StatusLed.SetStatus(SystemStatus.Terminating);

            Application.Closing = true;
            Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
            {
                return "Closed.";
            });
            Thread.Sleep(300);
            Hal.Gpio.ClearOutput(GpioPort.PortB, 28);

            // Write why we are shutting down to file.
            Logger.WriteShutDownReason(false);

            // In case the watchdog was freed by means of ForcedResetRequired the instance my be already null
            // Most important during testing in both release and debug.
            if (Hal.WatchdogTimer.Instance != null)
                Hal.WatchdogTimer.Instance.Dispose();
#if !DEBUG
            // Enable watchdog timer
            Hal.Gpio.ClearOutput(GpioPort.PortA, 9);
            Hal.Gpio.ConfigurePin(GpioPort.PortA, 9, true, false, false);
            Hal.Gpio.ClearOutput(GpioPort.PortC, 11);
            Hal.Gpio.ConfigurePin(GpioPort.PortC, 11, true, false, false);
#endif
        }

        private static void deviceLoop_RequestKeypadStateMachineInstance(object sender, RequestKeypadStateMachineEventArgs e)
        {
            e.KeypadStateMachine = null;
            if (e.Protocol == PortProtocol.PacomDeviceLoopProtocol && (e.Device == DeviceType.Pacom1061 || e.Device == DeviceType.Pacom8101 || e.Device == DeviceType.Pacom8105))
            {
                KeypadLcdDisplayProperties display = KeypadLcdDisplayProperties.LcdDisplayProperties[e.Device];
                if (e.Device == DeviceType.Pacom8101 || e.Device == DeviceType.Pacom8105)
                {
                    // Pacom8101 keypads require cloning of the display properties because of the 8105 keypads that register as Pacom8101 devices but change the
                    // LineWidth that is stored in display properties instance
                    display = display.Clone();
                }
                e.KeypadStateMachine = new LcdKeypadStateMachine.PacomLcdKeypadStateMachine(ConfigurationManager.Instance.GetDeviceConfiguration(e.LogicalDeviceId), display);
            }
            if (e.KeypadStateMachine != null)
            {
                e.KeypadStateMachine.AlarmManager = singletons.Instance<AlarmManager>();
                e.KeypadStateMachine.EventQueueManager = singletons.Instance<EventQueueManager>();
            }
        }

        /// <summary>
        /// Maximum thread pool threads that will be created. Must be less than 200.
        /// For now we'll set it to 50
        /// </summary>
        const int MaxThreadPoolThreads = 50;
        private static void setMaxThreadPoolThreads()
        {
            int workerThreadCount = 0;
            int ioThreadCount = 0;
            ThreadPool.GetMaxThreads(out workerThreadCount, out ioThreadCount);
            if (workerThreadCount < MaxThreadPoolThreads)
                ThreadPool.SetMaxThreads(MaxThreadPoolThreads, ioThreadCount);
        }

        static bool initializeStorage()
        {
            try
            {
                StringBuilder storeManagerLogger = new StringBuilder();
                using (StringWriter storeManagerLoggerWriter = new StringWriter(storeManagerLogger))
                {
                    StoreManager.CreateInstance();
                    StoreManager.Instance.LogWriter = storeManagerLoggerWriter;
                    if (StoreManager.Instance.RestoreDisks() == true)
                    {
                        // Recreate logs directory
                        if (Directory.Exists(FileSystemPaths.LogsDirectory) == false)
                            Directory.CreateDirectory(FileSystemPaths.LogsDirectory);
                        // Recreate configuration directory
                        if (Directory.Exists(FileSystemPaths.ConfigurationDirectory) == false)
                            Directory.CreateDirectory(FileSystemPaths.ConfigurationDirectory);
                        // Save to boot.log
                        StreamWriter logFile = new StreamWriter("\\PublicRegion\\Logs\\boot.log");
                        logFile.WriteLine(storeManagerLogger);
                        logFile.Flush();
                        logFile.Close();
                        logFile = null;
                        return true;
                    }
                    else
                    {
                        if (Application.Closing == false)
                        {
                            Application.Closing = true;
                            Thread.Sleep(100);
                            StatusLed.SetStatus(SystemStatus.HardwareError);
                        }
                        return false;
                    }
                }
            }
            catch
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return "Fatal error while restoring storage devices.";
                });
                Application.Closing = true;
                Thread.Sleep(100);
                StatusLed.SetStatus(SystemStatus.HardwareError);
                return false;
            }
        }

        static void UsbDevice_DeviceConnected(object sender, EventArgs e)
        {
            Logger.WriteLogsToDisk();
            UsbDevice.Instance.AllowNewUsbConnection();
        }

        static void UsbDevice_DeviceDisconnected(object sender, EventArgs e)
        {
            while (true)
            {
                if (Directory.Exists("\\PublicRegion"))
                    break;
                Thread.Sleep(100);
            }
            try
            {
                // Look for update file. The bdt and epr files must have same name before extension.
                string[] eprFiles = Directory.GetFiles("\\PublicRegion", "*.epr");

                string[] bdtFiles = Directory.GetFiles("\\PublicRegion", "*.bdt");
                if (eprFiles.Length == 1)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return "USB is connected. Found update image. Processing...";
                    });
                    FirmwareManager.Instance.ProcessFirmwareDownload(eprFiles[0], "/Firmware/Pacom8003/00.00");
                }

                if (eprFiles.Length != 0 || bdtFiles.Length != 0)
                {
                    // Cleanup epr and bdt files
                    Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return "USB is disconnected. Cleaning up Public Region.";
                    });
                    foreach (string file in eprFiles)
                    {
                        File.Delete(file);
                    }
                    foreach (string file in bdtFiles)
                    {
                        File.Delete(file);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return string.Format("UpdateException {0}", ex.ToString());
                });
            }
        }

        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
            {
                return string.Format("UnhandledException {0}", e.ExceptionObject.ToString());
            });

            Logger.WriteShutDownReason(true);
        }

        /// <summary>
        /// Run device loop autoconfiguration function
        /// </summary>
        /// <param name="sender">Unused</param>
        /// <param name="e">Unused</param>
        static void Pcb_OneTouchButtonPressed(object sender, EventArgs e)
        {
            Logger.LogWarnMessage(LoggerClassPrefixes.HostingApplication, () =>
            {
                return "One-touch button is not used!";
            });
        }

        static void Pcb_ResetButtonPressed(object sender, EventArgs e)
        {
            Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
            {
                return "*** Pcb_ResetButtonPressed... Rebooting. ***";
            });
            Application.Closing = true;
            SingletonList.Closing = true;
        }

        /// <summary>
        /// During disposing singleton list will call this method when reset is required.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        static void Program_ForcedResetRequired(object sender, EventArgs e)
        {
            // Write why we are shutting down to file.
            Logger.WriteShutDownReason(true);

            Hal.WatchdogTimer.Instance.Dispose();
#if !DEBUG
            // Enable watchdog timer
            Hal.Gpio.ClearOutput(GpioPort.PortA, 9);
            Hal.Gpio.ConfigurePin(GpioPort.PortA, 9, true, false, false);
            Hal.Gpio.ClearOutput(GpioPort.PortC, 11);
            Hal.Gpio.ConfigurePin(GpioPort.PortC, 11, true, false, false);
#endif
        }
    }
}
