﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pacom.ConfigurationEditor.WPF.View;
using Pacom.ConfigurationEditor.WPF;

namespace CcmUnitTests
{
    [TestClass]
    public class Tests
    {
#if DEBUG
        [TestMethod]
        public void TestTranslations()
        {
            Assert.IsTrue(Translation.GetLanguage("en") != null, "English language is missing");
            Assert.IsTrue(Translation.GetLanguage("es") != null, "Spanish language is missing");
            Assert.IsTrue(Translation.GetLanguage("fr") != null, "French language is missing");

            Language language = Translation.GetLanguage("en");
            Assert.IsTrue(MenuView.GetFailedTranslations(language).Count == 0, "There are missing translations for " + language.EnglishName);
        }

        [TestMethod]
        public void TestMessageConversionTemplate()
        {
            Assert.IsTrue(MenuView.VerifyMessageConversions(), "Error with the Digital Received XML conversion template!");
        }

        [TestMethod]
        public void TestMacroView()
        {
            string format = "(Controller).SendToPeer({2},(Variable[{0}]).SetValue({1}))";
            string action = "(Controller).SendToPeer(5050,(Variable[1]).SetValue(30))";
            Assert.IsTrue(MacroView.GetDataValue(format, action, 0) == "1", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 1) == "30", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 2) == "5050", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 3) == "", "Error with GetDataValue!");

            format = "(Variable[{0}]).SetValue({1})";
            action = "(Variable[5]).SetValue(1)";
            Assert.IsTrue(MacroView.GetDataValue(format, action, 0) == "5", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 1) == "1", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 2) == "", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 3) == "", "Error with GetDataValue!");

            format = "{0}]).SetValue({1})";
            action = "5]).SetValue(1)";
            Assert.IsTrue(MacroView.GetDataValue(format, action, 0) == "5", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 1) == "1", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 2) == "", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 3) == "", "Error with GetDataValue!");

            format = "(Variable[{0}]).SetValue({1}";
            action = "(Variable[5]).SetValue(1";
            Assert.IsTrue(MacroView.GetDataValue(format, action, 0) == "5", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 1) == "1", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 2) == "", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 3) == "", "Error with GetDataValue!");

            format = "(Calendar.IsTime(\"{1}\")==true)";
            action = "(Calendar.IsTime(\"1234\")==true)";
            Assert.IsTrue(MacroView.GetDataValue(format, action, 0) == "", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 1) == "1234", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 2) == "", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 3) == "", "Error with GetDataValue!");

            format = "Output.ActivateInArea({0},{1})";
            action = "Output.ActivateInArea(12,34)";
            Assert.IsTrue(MacroView.GetDataValue(format, action, 0) == "12", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 1) == "34", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 2) == "", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 3) == "", "Error with GetDataValue!");

            format = "(AccessCard.IsSingleBadge==true)";
            action = "(AccessCard.IsSingleBadge==true)";
            Assert.IsTrue(MacroView.GetDataValue(format, action, 0) == "", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 1) == "", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 2) == "", "Error with GetDataValue!");
            Assert.IsTrue(MacroView.GetDataValue(format, action, 3) == "", "Error with GetDataValue!");
        }
#endif
    }
}
