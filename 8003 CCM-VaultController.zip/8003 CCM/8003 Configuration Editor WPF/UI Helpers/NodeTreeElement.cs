﻿using System;
using System.Collections.Generic;
using System.Windows.Controls;
using Pacom.ConfigurationEditor.WPF.View;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF
{
    public class NodeTreeElement
    {
        private readonly List<NodeTreeElement> children = new List<NodeTreeElement>();

        static int id = 0;
        static int lastDisplayedId = -1;
        static Grid lastDisplayedGrid;

        readonly int instanceId;
        string defaultName;
        ConfigurationBase configurationItem;
        Type viewType;

        public NodeTreeElement(string displayName, string imageSource, ConfigurationBase configurationItem, Type viewType, bool expand = true)
        {
            ImageSource = imageSource;
            IsExpanded = expand;
            this.viewType = viewType;

            this.configurationItem = configurationItem;
            if ((this.configurationItem is NodeConfiguration) == false)
                defaultName = displayName;

            instanceId = id;
            id++;
        }

        public NodeTreeElement(string displayName, string imageSource)
        {
            defaultName = displayName;
            ImageSource = imageSource;
            IsExpanded = true;

            instanceId = id;
            id++;
        }

        public List<NodeTreeElement> Children
        {
            get
            {
                return children;
            }
        }

        public string ImageSource { get; set; }
        public bool IsExpanded { get; set; }
        public bool IsSelected { get; set; }

        public bool Enabled
        {
            get
            {
                NodeConfiguration nodeConfiguration = configurationItem as NodeConfiguration;
                if (nodeConfiguration == null)
                    return true;
                return nodeConfiguration.Enabled;
            }
        }

        public string DisplayName
        {
            get
            {
                if (defaultName != null)
                    return defaultName;
                NodeConfiguration nodeConfiguration = configurationItem as NodeConfiguration;
                if (nodeConfiguration == null)
                    return defaultName;
                return nodeConfiguration.Name;
            }
            set
            {
                defaultName = value;
            }
        }

        public ConfigurationBase ConfigurationItem
        {
            get
            {
                return configurationItem;
            }
            set
            {
                configurationItem = value;
                NodeTreeView.Instance.RefreshConfigurationView();
            }
        }

        public Grid ConfigurationView
        {
            get
            {
                if (lastDisplayedId == instanceId)
                    return lastDisplayedGrid;

                lastDisplayedId = instanceId;
                if (configurationItem == null && viewType == null)
                    lastDisplayedGrid = null;
                else if (viewType == typeof(ElevatorConfigurationView))
                    lastDisplayedGrid = new GridViewBase(ConfigurationItem, viewType);
                else if (viewType == typeof(UnisonElevatorConfigurationView))
                    lastDisplayedGrid = new GridViewBase(ConfigurationItem, viewType);
                else if (viewType == typeof(ElevatorFloorConfigurationView))
                    lastDisplayedGrid = new GridViewBase(ConfigurationItem, viewType);
                else if (viewType == typeof(VaultControllerInterlockGroupsFolderView))
                    lastDisplayedGrid = new GridViewBase(ConfigurationManager.ControllerConfiguration, typeof(VaultControllerView));
                else if (viewType == typeof(DeviceView) && configurationItem is Device1076VCConfiguration)
                    lastDisplayedGrid = new GridViewBase(configurationItem, typeof(VaultDeviceView), true);
                else if (configurationItem == null)
                    lastDisplayedGrid = Activator.CreateInstance(viewType, new object[] { this }) as Grid;
                else
                    lastDisplayedGrid = Activator.CreateInstance(viewType, new object[] { configurationItem, this }) as Grid;
                return lastDisplayedGrid;
            }
        }

        public static void ClearCache()
        {
            lastDisplayedId = -1;
            lastDisplayedGrid = null;
        }
    }
}
