﻿
namespace Pacom.ConfigurationEditor.WPF.View
{
    public interface IUnloadable
    {
        void Unload();
    }
}