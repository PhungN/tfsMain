﻿
namespace Pacom.ConfigurationEditor.WPF
{
    public class ComboBoxItemContents
    {
        public ComboBoxItemContents(string displayName, object value, bool enabled = true)
        {
            DisplayName = displayName;
            Value = value;
            Enabled = true;
        }

        public string DisplayName { get; set; }
        public object Value { get; set; }
        public bool Enabled { get; set; }

        public override string ToString()
        {
            return DisplayName;
        }
    }
}