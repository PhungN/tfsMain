﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;

namespace Pacom.ConfigurationEditor.WPF
{
    public class InovonicsSerialNumberEventArgs : EventArgs
    {
        private readonly int serialNumber;

        public InovonicsSerialNumberEventArgs(int serialNumber)
        {
            this.serialNumber = serialNumber;
        }

        public int NewSerialNumber
        {
            get { return serialNumber; }
        }
    }

    public class InovonicsSerialNumberPropertyInfo : PropertyInfo
    {
        public override object GetValue(object obj, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture)
        {
            InovonicsDeviceConfigurationBase inovonicsDevice = obj as InovonicsDeviceConfigurationBase;
            if (inovonicsDevice != null)
                return inovonicsDevice.DeviceLoopAddress;
            return null;
        }

        public override string Name
        {
            get
            {
                return "SerialNumber";
            }
        }

        public override Type DeclaringType
        {
            get
            {
                return null;
            }
        }

        public override object[] GetCustomAttributes(bool inherit)
        {
            return null;
        }

        public event EventHandler<InovonicsSerialNumberEventArgs> SerialNumberChanged;
        public override void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture)
        {
            if (SerialNumberChanged != null)
                SerialNumberChanged(this, new InovonicsSerialNumberEventArgs((int)value));
        }

        public override PropertyAttributes Attributes
        {
            get
            {
                return new PropertyAttributes();
            }
        }

        public override MethodInfo GetSetMethod(bool nonPublic)
        {
            return null;
        }

        public override MethodInfo GetGetMethod(bool nonPublic)
        {
            return null;
        }

        public override ParameterInfo[] GetIndexParameters()
        {
            return new ParameterInfo[0];
        }

        public override Type PropertyType
        {
            get
            {
                return typeof(int);
            }
        }

        public override MethodInfo[] GetAccessors(bool nonPublic)
        {
            return null;
        }

        public override bool CanRead
        {
            get
            {
                return true;
            }
        }

        public override bool CanWrite
        {
            get
            {
                return true;
            }
        }

        public override Type ReflectedType
        {
            get
            {
                return null;
            }
        }

        public override bool IsDefined(Type attributeType, bool inherit)
        {
            return false;
        }

        public override object[] GetCustomAttributes(Type attributeType, bool inherit)
        {
            ControllerAttribute[] attributes = new ControllerAttribute[1];
            attributes[0] = new ControllerAttribute(DisplayCategory.Identification, 4);
            return attributes;
        }
    }
}
