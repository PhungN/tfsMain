﻿#if DEBUG
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;

namespace Pacom.ConfigurationEditor.WPF
{
    public class HotKeyManager
    {
        [DllImport("User32.dll")]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("User32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        private HwndSource source;
        private const int HOTKEY_ID = 9000;
        private WindowInteropHelper helper;

        public event EventHandler F5Pressed;

        public HotKeyManager(Window window)
        {
            helper = new WindowInteropHelper(window);
            source = HwndSource.FromHwnd(helper.Handle);
            source.AddHook(HwndHook);

            const uint VK_F5 = 0x74;
            const uint MOD_CTRL = 0x0002;

            RegisterHotKey(helper.Handle, HOTKEY_ID, MOD_CTRL, VK_F5);
        }

        public void Dispose()
        {
            if (source != null)
            {
                source.RemoveHook(HwndHook);
                source = null;
            }
            UnregisterHotKey(helper.Handle, HOTKEY_ID);
        }

        private IntPtr HwndHook(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            const int WM_HOTKEY = 0x0312;
            switch (msg)
            {
                case WM_HOTKEY:
                    switch (wParam.ToInt32())
                    {
                        case HOTKEY_ID:
                            if (F5Pressed != null)
                                F5Pressed(null, new EventArgs());
                            handled = true;
                            break;
                    }
                    break;
            }
            return IntPtr.Zero;
        }
    }
}
#endif