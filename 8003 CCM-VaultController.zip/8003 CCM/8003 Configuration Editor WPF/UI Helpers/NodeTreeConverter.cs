﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;

namespace Pacom.ConfigurationEditor.WPF
{
    [ValueConversion(typeof(bool), typeof(Visibility))]
    public class NodeTreeConverter : MarkupExtension, IValueConverter
    {
        private static NodeTreeConverter converter = null;

        public NodeTreeConverter()
        {
        }

        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            if (converter == null)
                converter = new NodeTreeConverter();
            return converter;
        }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if ((bool)value == false)
                return TextDecorations.Strikethrough;
            else
                return null;
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return new NotImplementedException();
        }
    }
}
