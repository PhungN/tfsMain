﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;

namespace Pacom.ConfigurationEditor.WPF
{
    public enum PortRS232ControllerProtocols
    {
        Debug,
        InovonicsEchoStream,
    }

    public class PortRS232ControllerProtocolsEventArgs : EventArgs
    {
        private readonly PortRS232ControllerProtocols protocol;

        public PortRS232ControllerProtocolsEventArgs(PortRS232ControllerProtocols protocol)
        {
            this.protocol = protocol;
        }

        public PortRS232ControllerProtocols NewProtocol
        {
            get { return protocol; }
        }
    }

    public class RS232ProtocolPropertyInfo : PropertyInfo
    {
        public override object GetValue(object obj, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture)
        {
            if (obj is Port8003RS232DebugPortConfiguration)
                return PortRS232ControllerProtocols.Debug;
            if (obj is Port8003RS232InovonicsPortConfiguration)
                return PortRS232ControllerProtocols.InovonicsEchoStream;
            return null;
        }

        public override string Name
        {
            get
            {
                return "Protocol";
            }
        }

        public override Type DeclaringType
        {
            get
            {
                return null;
            }
        }

        public override object[] GetCustomAttributes(bool inherit)
        {
            return null;
        }

        public event EventHandler<PortRS232ControllerProtocolsEventArgs> ProtocolChanged;
        public override void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture)
        {
            if (ProtocolChanged != null)
                ProtocolChanged(this, new PortRS232ControllerProtocolsEventArgs((PortRS232ControllerProtocols)value));
        }

        public override PropertyAttributes Attributes
        {
            get
            {
                return new PropertyAttributes();
            }
        }

        public override MethodInfo GetSetMethod(bool nonPublic)
        {
            return null;
        }

        public override MethodInfo GetGetMethod(bool nonPublic)
        {
            return null;
        }

        public override ParameterInfo[] GetIndexParameters()
        {
            return new ParameterInfo[0];
        }

        public override Type PropertyType
        {
            get
            {
                return typeof(PortRS232ControllerProtocols);
            }
        }

        public override MethodInfo[] GetAccessors(bool nonPublic)
        {
            return null;
        }

        public override bool CanRead
        {
            get
            {
                return true;
            }
        }

        public override bool CanWrite
        {
            get
            {
                return true;
            }
        }

        public override Type ReflectedType
        {
            get
            {
                return null;
            }
        }

        public override bool IsDefined(Type attributeType, bool inherit)
        {
            return false;
        }

        public override object[] GetCustomAttributes(Type attributeType, bool inherit)
        {
            ControllerAttribute[] attributes = new ControllerAttribute[1];
            attributes[0] = new ControllerAttribute(DisplayCategory.Identification);
            return attributes;
        }
    }
}
