﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;

namespace Pacom.ConfigurationEditor.WPF
{
    public enum PortRS485ControllerProtocols
    {
        Pacom,
        Osdp,
        Aprp,
        Aperio
    }

    public class PortRS485ControllerProtocolsEventArgs : EventArgs
    {
        private readonly PortRS485ControllerProtocols protocol;

        public PortRS485ControllerProtocolsEventArgs(PortRS485ControllerProtocols protocol)
        {
            this.protocol = protocol;
        }

        public PortRS485ControllerProtocols NewProtocol
        {
            get { return protocol; }
        }
    }

    public class RS485ProtocolPropertyInfo : PropertyInfo
    {
        public override object GetValue(object obj, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture)
        {
            if (obj is Port8003RS485DeviceLoopPortConfiguration)
                return PortRS485ControllerProtocols.Pacom;
            if (obj is Port8003RS485OsdpDeviceLoopPortConfiguration)
                return PortRS485ControllerProtocols.Osdp;
            if (obj is Port8003RS485AsisProprietaryReaderPortConfiguration)
                return PortRS485ControllerProtocols.Aprp;
            if (obj is Port8003RS485AperioPortConfiguration)
                return PortRS485ControllerProtocols.Aperio;
            return null;
        }

        public override string Name
        {
            get
            {
                return "Protocol";
            }
        }

        public override Type DeclaringType
        {
            get
            {
                return null;
            }
        }

        public override object[] GetCustomAttributes(bool inherit)
        {
            return null;
        }

        public event EventHandler<PortRS485ControllerProtocolsEventArgs> ProtocolChanged;
        public override void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, object[] index, CultureInfo culture)
        {
            if (ProtocolChanged != null)
                ProtocolChanged(this, new PortRS485ControllerProtocolsEventArgs((PortRS485ControllerProtocols)value));
        }

        public override PropertyAttributes Attributes
        {
            get
            {
                return new PropertyAttributes();
            }
        }

        public override MethodInfo GetSetMethod(bool nonPublic)
        {
            return null;
        }

        public override MethodInfo GetGetMethod(bool nonPublic)
        {
            return null;
        }

        public override ParameterInfo[] GetIndexParameters()
        {
            return new ParameterInfo[0];
        }

        public override Type PropertyType
        {
            get
            {
                return typeof(PortRS485ControllerProtocols);
            }
        }

        public override MethodInfo[] GetAccessors(bool nonPublic)
        {
            return null;
        }

        public override bool CanRead
        {
            get
            {
                return true;
            }
        }

        public override bool CanWrite
        {
            get
            {
                return true;
            }
        }

        public override Type ReflectedType
        {
            get
            {
                return null;
            }
        }

        public override bool IsDefined(Type attributeType, bool inherit)
        {
            return false;
        }

        public override object[] GetCustomAttributes(Type attributeType, bool inherit)
        {
            ControllerAttribute[] attributes = new ControllerAttribute[1];
            attributes[0] = new ControllerAttribute(DisplayCategory.Identification);
            return attributes;
        }
    }
}
