﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace Pacom.ConfigurationEditor.WPF.UserControls
{
    /// <summary>
    /// Interaction logic for PasswordRevealBox.xaml
    /// </summary>
    public partial class PasswordRevealBox
    {
        public PasswordRevealBox()
        {
            InitializeComponent();
        }

        public event RoutedEventHandler PasswordChanged;

        public bool IsPasswordEncrypted { get; set; }

        private string password = string.Empty;
        public string Password
        {
            get
            {
                return password;
            }
            set
            {
                if (IsPasswordEncrypted)
                {
                    password = ControllerConfigurationManager.EncryptIfRequired(value);
                    if (password.Length > 4)
                        TxtPasswordbox.Password = ControllerConfigurationManager.Decrypt(password.Substring(4));
                    else
                        TxtPasswordbox.Password = password;
                }
                else
                {
                    password = value;
                    TxtPasswordbox.Password = password;
                }
            }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            ImgShowHide.Source = new BitmapImage(new Uri(@"\EmbeddedResources\Images\Show.png", UriKind.Relative));
        }

        private void ImgShowHide_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            ShowPassword();
        }


        private void ImgShowHide_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            HidePassword();
        }


        private void ImgShowHide_MouseLeave(object sender, MouseEventArgs e)
        {
            HidePassword();
        }

        private void ShowPassword()
        {
            ImgShowHide.Source = new BitmapImage(new Uri(@"\EmbeddedResources\Images\Hide.png", UriKind.Relative));
            TxtVisiblePasswordbox.Visibility = Visibility.Visible;
            TxtPasswordbox.Visibility = Visibility.Hidden;
            TxtVisiblePasswordbox.Text = TxtPasswordbox.Password;
        }

        private void HidePassword()
        {
            ImgShowHide.Source = new BitmapImage(new Uri(@"\EmbeddedResources\Images\Show.png", UriKind.Relative));
            TxtVisiblePasswordbox.Visibility = Visibility.Hidden;
            TxtPasswordbox.Visibility = Visibility.Visible;
            TxtPasswordbox.Focus();
        }

        private void txtPasswordbox_PasswordChanged(object sender, RoutedEventArgs e)
        {
#if !DEBUG
            if (IsPasswordEncrypted == false)
#endif
            {
                ImgShowHide.Visibility = TxtPasswordbox.Password.Length > 0 ?
                    Visibility.Visible : Visibility.Hidden;
            }
            if (IsPasswordEncrypted)
                password = ControllerConfigurationManager.EncryptIfRequired(TxtPasswordbox.Password);
            else
                password = TxtPasswordbox.Password;

            if (PasswordChanged != null)
                PasswordChanged(this, e);
        }
    }
}

