﻿using System;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.UserControls
{
    /// <summary>
    /// Interaction logic for ScheduleControl.xaml
    /// </summary>
    public partial class ScheduleControl : UserControl
    {
        private Schedule configurationItem { get; set; }

        private Reader8003ScheduleLevel selectedScheduleLevel = Reader8003ScheduleLevel.CardOnly;

        private RadioButton[] radioButtons;
        private ScheduleIntervalControl[] scheduleIntervalControls;

        public ScheduleControl(Schedule schedule)
        {
            configurationItem = schedule;

            if (schedule.Schedules.Length < 10 ||
                GetScheduleRecord(DayType.Monday) == null ||
                GetScheduleRecord(DayType.Tuesday) == null ||
                GetScheduleRecord(DayType.Wednesday) == null ||
                GetScheduleRecord(DayType.Thursday) == null ||
                GetScheduleRecord(DayType.Friday) == null ||
                GetScheduleRecord(DayType.Saturday) == null ||
                GetScheduleRecord(DayType.Sunday) == null ||
                GetScheduleRecord(DayType.Holiday1) == null ||
                GetScheduleRecord(DayType.Holiday2) == null ||
                GetScheduleRecord(DayType.Holiday3) == null)
            {
                int newSchedulesLength = 10;
                if (GetScheduleRecord(DayType.Holiday4) != null)
                    newSchedulesLength++;
                if (GetScheduleRecord(DayType.Holiday5) != null)
                    newSchedulesLength++;
                ScheduleRecord[] newSchedules = new ScheduleRecord[newSchedulesLength];

                for (int i = 0; i < 10; i++)
                {
                    DayType day = (DayType)(i + 1);
                    newSchedules[i] = GetScheduleRecord(day);
                    if (newSchedules[i] == null)
                        newSchedules[i] = ConfigurationManager.CreateScheduleRecord(day);
                }

                if (GetScheduleRecord(DayType.Holiday4) != null)
                    newSchedules[10] = GetScheduleRecord(DayType.Holiday4);
                if (GetScheduleRecord(DayType.Holiday5) != null)
                    newSchedules[newSchedulesLength - 1] = GetScheduleRecord(DayType.Holiday5);

                schedule.Schedules = newSchedules;
                schedule.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            }

            InitializeComponent();
            radioButtonCard.Resources["ScheduleLevel"] = Reader8003ScheduleLevel.CardOnly;
            radioButtonUnlocked.Resources["ScheduleLevel"] = Reader8003ScheduleLevel.Unlocked;
            radioButtonLocked.Resources["ScheduleLevel"] = Reader8003ScheduleLevel.Blocked;
            radioButtonCardAndPin.Resources["ScheduleLevel"] = Reader8003ScheduleLevel.CardAndPin;
            radioButtons = new RadioButton[] { radioButtonCard, radioButtonUnlocked, radioButtonLocked, radioButtonCardAndPin };
            scheduleIntervalControls = new ScheduleIntervalControl[] {
                scheduleIntervalMonday,
                scheduleIntervalTuesday,
                scheduleIntervalWednesday,
                scheduleIntervalThursday,
                scheduleIntervalFriday,
                scheduleIntervalSaturday,
                scheduleIntervalSunday,
                scheduleIntervalHoliday1,
                scheduleIntervalHoliday2,
                scheduleIntervalHoliday3 };

            foreach (RadioButton radioButton in radioButtons)
            {
                radioButton.Checked += radioButton_Checked;
            }
            foreach (ScheduleIntervalControl scheduleIntervalControl in scheduleIntervalControls)
            {
                scheduleIntervalControl.SelectedScheduleLevel = selectedScheduleLevel;
                ScheduleRecord scheduleRecord = GetScheduleRecord(scheduleIntervalControl.DayType);
                if (scheduleRecord != null)
                {
                    scheduleIntervalControl.ConfigurationItem = scheduleRecord;
                    scheduleIntervalControl.ScheduleIntervalChanged += ScheduleIntervalControl_ScheduleIntervalChanged;
                }
                else
                {
                    System.Diagnostics.Debugger.Break();
                }
            }

            label.Content = Translation.GetTranslatedMisc("UseMouseWheelToZoom");
            groupBox1Title.Content = Translation.GetTranslatedMisc("Reader/Egress/Area");
            groupBox2Title.Content = Translation.GetTranslatedMisc("Reader Only");
            radioButtonCard.Content = Translation.GetTranslatedMisc("Card/Disabled/Armed");
            radioButtonUnlocked.Content = Translation.GetTranslatedMisc("Unlocked/Enabled/Disarmed");

            radioButtonLocked.Content = Translation.GetTranslatedMisc("Locked");
            radioButtonCardAndPin.Content = Translation.GetTranslatedMisc("Card+Pin");

        }

        private void ScheduleIntervalControl_ScheduleIntervalChanged(object sender, EventArgs e)
        {
            App.ConfigurationModified = true;
            configurationItem.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
        }

        private ScheduleRecord GetScheduleRecord(DayType dayType)
        {
            foreach (ScheduleRecord scheduleRecord in configurationItem.Schedules)
            {
                if (scheduleRecord.DayType == dayType)
                    return scheduleRecord;
            }
            return null;
        }

        private void radioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton activeRadioButton = (RadioButton)sender;
            if (activeRadioButton.IsChecked == true)
            {
                selectedScheduleLevel = (Reader8003ScheduleLevel)activeRadioButton.Resources["ScheduleLevel"];

                foreach (RadioButton radioButton in radioButtons)
                {
                    if (radioButton != activeRadioButton)
                        radioButton.IsChecked = false;
                }

                foreach (ScheduleIntervalControl scheduleIntervalControl in scheduleIntervalControls)
                {
                    scheduleIntervalControl.SelectedScheduleLevel = selectedScheduleLevel;
                }
            }
        }
    }
}
