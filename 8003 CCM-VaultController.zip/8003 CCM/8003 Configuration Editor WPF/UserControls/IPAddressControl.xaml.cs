﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Pacom.ConfigurationEditor.WPF.UserControls
{
    /// <summary>
    /// Interaction logic for IPAddressControl.xaml
    /// </summary>
    public partial class IPAddressControl
    {
        public event TextChangedEventHandler TextChanged;

        private TextBox[] textBoxes;
        private Color blue = Color.FromRgb(128, 181, 234);
        private Color grey = Color.FromRgb(189, 191, 195);
        private Color focusedBlue = Color.FromRgb(86, 157, 229);
        private int tabKeyDownIndex = 0;

        #region Constructor
        /// <summary>
        ///  Constructor for the control.
        /// </summary>
        public IPAddressControl()
        {
            InitializeComponent();
            textBoxes = new TextBox[4] { TxtboxFirstPart, TxtboxSecondPart, TxtboxThirdPart, TxtboxFourthPart };
            for (int i = 0; i < textBoxes.Length; i++)
            {
                textBoxes[i].Resources["Index"] = i;
            }
        }
        #endregion

        public string Text
        {
            get
            {
                return TxtboxFirstPart.Text + "." + TxtboxSecondPart.Text + "." + TxtboxThirdPart.Text + "." + TxtboxFourthPart.Text;
            }
            set
            {
                try
                {
                    for (int i = 0; i < textBoxes.Length; i++)
                    {
                        textBoxes[i].TextChanged -= txtbox_TextChanged;
                    }

                    string[] splitValues = new string[0];
                    if (string.IsNullOrEmpty(value) == false)
                        splitValues = value.Split('.');

                    if (splitValues.Length == 4)
                    {
                        TxtboxFirstPart.Text = splitValues[0];
                        TxtboxSecondPart.Text = splitValues[1];
                        TxtboxThirdPart.Text = splitValues[2];
                        TxtboxFourthPart.Text = splitValues[3];
                    }
                    else
                    {
                        TxtboxFirstPart.Text = "0";
                        TxtboxSecondPart.Text = "0";
                        TxtboxThirdPart.Text = "0";
                        TxtboxFourthPart.Text = "0";
                    }

                    for (int i = 0; i < textBoxes.Length; i++)
                    {
                        textBoxes[i].TextChanged += txtbox_TextChanged;
                    }
                }
                catch
                {
                }
            }
        }

        private void txtbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                TextBox txtbox = (TextBox)sender;

                StringBuilder numberBuilder = new StringBuilder();
                foreach (char c in txtbox.Text)
                {
                    if (char.IsNumber(c))
                        numberBuilder.Append(c);
                }
                txtbox.Text = numberBuilder.ToString();

                if (txtbox.Text.Length > 0)
                {
                    int number = Convert.ToInt32(txtbox.Text);
                    if (number > 255)
                    {
                        txtbox.Text = "255";
                        txtbox.CaretIndex = 5;
                    }
                    else if (number < 0)
                    {
                        txtbox.Text = "0";
                        txtbox.CaretIndex = 5;
                    }

                    if (txtbox.Text.Length == 3)
                    {
                        int index = (int)txtbox.Resources["Index"];
                        if (index < 3)
                        {
                            textBoxes[index + 1].Focus();
                            textBoxes[index + 1].SelectAll();
                        }
                    }
                }

                TextChanged?.Invoke(this, e);
            }
            catch
            {
            }
        }

        private void txtbox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                tabKeyDownIndex = 0;
                if (e.Key == Key.OemPeriod || e.Key == Key.Decimal || e.Key == Key.Tab)
                {
                    TextBox txtbox = (TextBox)sender;
                    int index = (int)txtbox.Resources["Index"];
                    tabKeyDownIndex = index;
                    if (index < 3)
                    {
                        textBoxes[index + 1].Focus();
                        textBoxes[index + 1].SelectAll();
                        e.Handled = true;
                    }
                    else if (e.Key == Key.OemPeriod || e.Key == Key.Decimal)
                    {
                        e.Handled = true;
                    }
                }
                else if (e.Key == Key.Back || e.Key == Key.Delete)
                {
                    TextBox txtbox = (TextBox)sender;
                    if (txtbox.Text.Length == 0)
                    {
                        int index = (int)txtbox.Resources["Index"];
                        if (index > 0)
                        {
                            textBoxes[index - 1].Focus();
                            textBoxes[index - 1].CaretIndex = 5;
                            e.Handled = true;
                        }
                    }
                }
                else if (e.Key == Key.Left)
                {
                    TextBox txtbox = (TextBox)sender;
                    int index = (int)txtbox.Resources["Index"];
                    if (txtbox.CaretIndex == 0 && index > 0)
                    {
                        textBoxes[index - 1].Focus();
                        textBoxes[index - 1].CaretIndex = 5;
                        e.Handled = true;
                    }
                    else
                    {
                        e.Handled = false;
                    }
                }
                else if (e.Key == Key.Right)
                {
                    TextBox txtbox = (TextBox)sender;
                    int index = (int)txtbox.Resources["Index"];
                    if (txtbox.CaretIndex == txtbox.Text.Length && index < 3)
                    {
                        textBoxes[index + 1].Focus();
                        textBoxes[index + 1].CaretIndex = 0;
                        e.Handled = true;
                    }
                    else
                    {
                        e.Handled = false;
                    }
                }
                else if (e.Key == Key.Home || e.Key == Key.End)
                {
                    e.Handled = false;
                }
                else if ((e.Key < Key.D0 || e.Key > Key.D9) && (e.Key < Key.NumPad0 || e.Key > Key.NumPad9))
                {
                    e.Handled = true;
                }
                else if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
                {
                    e.Handled = true;
                }
            }
            catch
            {
            }
        }

        private void txtbox_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Key == Key.Tab)
                {
                    if (tabKeyDownIndex != 2 && textBoxes[3].IsFocused)
                    {
                        textBoxes[0].Focus();
                        textBoxes[0].SelectAll();
                    }
                    e.Handled = true;
                    tabKeyDownIndex = 0;
                    return;
                }
            }
            catch
            {
            }
        }

        #region Border Color
        private void OnMouseEnter(object sender, MouseEventArgs e)
        {
            if (TxtboxFirstPart.IsFocused ||
                TxtboxSecondPart.IsFocused ||
                TxtboxThirdPart.IsFocused ||
                TxtboxFourthPart.IsFocused) return;
            Border.BorderBrush = new SolidColorBrush(blue);
        }

        private void OnMouseLeave(object sender, MouseEventArgs e)
        {
            if (TxtboxFirstPart.IsFocused ||
                TxtboxSecondPart.IsFocused ||
                TxtboxThirdPart.IsFocused ||
                TxtboxFourthPart.IsFocused) return;
            Border.BorderBrush = new SolidColorBrush(grey);
        }

        private void OnGotFocus(object sender, RoutedEventArgs e)
        {
            Border.BorderBrush = new SolidColorBrush(focusedBlue);
        }

        private void OnLostFocus(object sender, RoutedEventArgs e)
        {
            Border.BorderBrush = new SolidColorBrush(grey);
        }
        #endregion
    }
}
