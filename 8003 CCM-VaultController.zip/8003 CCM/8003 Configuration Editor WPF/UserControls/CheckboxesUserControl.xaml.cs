﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pacom.ConfigurationEditor.WPF.UserControls
{
    /// <summary>
    /// Interaction logic for CheckboxesUserControl.xaml
    /// </summary>
    public partial class CheckBoxesUserControl : UserControl
    {
        private int selectedRow = 0;
        public CheckBoxesUserControl()
        {
            InitializeComponent();
            this.DataContext = this;
            selectAllButton.Click += SelectAllButton_Click;
            selectPopup.MouseLeave += SelectPopup_MouseLeave;
        }

        private void SelectPopup_MouseLeave(object sender, MouseEventArgs e)
        {
            selectPopup.IsOpen = false;
        }

        private void SelectAllButton_Click(object sender, RoutedEventArgs e)
        {
            selectedRow = -1;   // Select All
            selectPopupTextBlock.Text = $"{HeaderText}: 1 - {Rows * Columns}";
            selectPopup.IsOpen = true;
        }

        public static readonly DependencyProperty RowsProperty = DependencyProperty.Register("Rows", typeof(int), typeof(CheckBoxesUserControl), new FrameworkPropertyMetadata(OnRowsChanged));
        public static readonly DependencyProperty ColumnsProperty = DependencyProperty.Register("Columns", typeof(int), typeof(CheckBoxesUserControl), new FrameworkPropertyMetadata(OnColumnsChanged));
        public static readonly DependencyProperty DataProperty = DependencyProperty.Register("Data", typeof(bool[]), typeof(CheckBoxesUserControl), new FrameworkPropertyMetadata(OnDataChanged));
        public static readonly DependencyProperty IntArrayDataProperty = DependencyProperty.Register("IntArrayData", typeof(int[]), typeof(CheckBoxesUserControl), new FrameworkPropertyMetadata(OnIntArrayDataChanged));
        public static readonly DependencyProperty EnableGroupSelectButtonsProperty = DependencyProperty.Register("EnableGroupSelectButtons", typeof(bool), typeof(CheckBoxesUserControl), new FrameworkPropertyMetadata(OnEnableGroupSelectButtonsChanged));
        public static readonly DependencyProperty HeaderTextProperty = DependencyProperty.Register("HeaderText", typeof(string), typeof(CheckBoxesUserControl), new FrameworkPropertyMetadata(OnHeaderTextChanged));
        public static readonly DependencyProperty HeaderBackgroundProperty = DependencyProperty.Register("HeaderBackground", typeof(Brush), typeof(CheckBoxesUserControl), new FrameworkPropertyMetadata(OnHeaderBackgroundChanged));
        public static readonly DependencyProperty HeaderForegroundProperty = DependencyProperty.Register("HeaderForeground", typeof(Brush), typeof(CheckBoxesUserControl), new FrameworkPropertyMetadata(OnHeaderForegroundChanged));

        public class DataChangedEventArgs : RoutedEventArgs
        {
            private readonly bool[] data;
            public DataChangedEventArgs(bool[] data)
            {
                this.data = data;
            }
            public bool[] Data { get { return data; } }
        }
        public delegate void DataChangedEventHandler(object sender, DataChangedEventArgs e);
        public static readonly RoutedEvent DataChangedEvent = EventManager.RegisterRoutedEvent("DataChanged", RoutingStrategy.Bubble, typeof(DataChangedEventHandler), typeof(CheckBoxesUserControl));
        public event DataChangedEventHandler DataChanged
        {
            add
            {
                AddHandler(DataChangedEvent, value);
            }
            remove
            {
                RemoveHandler(DataChangedEvent, value);
            }
        }
        private void OnDataChanged()
        {
            DataChangedEventArgs args = new DataChangedEventArgs(Data);
            args.RoutedEvent = DataChangedEvent;
            RaiseEvent(args);
        }

        public int Rows
        {
            get { return (int)GetValue(RowsProperty); }
            set { SetValue(RowsProperty, value); }
        }
        public int Columns
        {
            get { return (int)GetValue(ColumnsProperty); }
            set { SetValue(ColumnsProperty, value); }
        }
        public bool[] Data
        {
            get { return (bool[])GetValue(DataProperty); }
            set { SetValue(DataProperty, value); }
        }
        public int[] IntArrayData
        {
            get { return (int[])GetValue(IntArrayDataProperty); }
            set { SetValue(IntArrayDataProperty, value); }
        }
        public bool EnableGroupSelectButtons
        {
            get { return (bool)GetValue(EnableGroupSelectButtonsProperty); }
            set { SetValue(EnableGroupSelectButtonsProperty, value); }
        }
        public string HeaderText
        {
            get { return (string)GetValue(HeaderTextProperty); }
            set { SetValue(HeaderTextProperty, value); }
        }

        public Brush HeaderBackground
        {
            get { return (Brush)GetValue(HeaderBackgroundProperty); }
            set { SetValue(HeaderBackgroundProperty, value); }
        }

        public Brush HeaderForeground
        {
            get { return (Brush)GetValue(HeaderForegroundProperty); }
            set { SetValue(HeaderForegroundProperty, value); }
        }
        private static void OnColumnsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CheckBoxesUserControl cb = d as CheckBoxesUserControl;
            if (cb != null)
            {
                cb.Columns = (int)e.NewValue;
            }

        }

        private static void OnRowsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CheckBoxesUserControl cb = d as CheckBoxesUserControl;
            if (cb != null)
            {
                cb.Rows = (int)e.NewValue;
            }
        }

        private static void OnDataChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CheckBoxesUserControl cb = d as CheckBoxesUserControl;
            if (cb != null)
            {
                cb.Data = e.NewValue as bool[];
                cb.UpdateCheckBoxes();
            }
        }

        private static void OnIntArrayDataChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CheckBoxesUserControl cb = d as CheckBoxesUserControl;
            if (cb != null)
            {
                
            }
        }

        private static void OnEnableGroupSelectButtonsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CheckBoxesUserControl cb = d as CheckBoxesUserControl;
            if (cb != null)
            {
                cb.EnableGroupSelectButtons = (bool)e.NewValue;
            }
        }

        private static void OnHeaderTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CheckBoxesUserControl cb = d as CheckBoxesUserControl;
            if (cb != null)
            {
                cb.HeaderText = (string)e.NewValue;
                cb.headerTextBlock.Text = cb.HeaderText;
            }
        }

        private static void OnHeaderBackgroundChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CheckBoxesUserControl cb = d as CheckBoxesUserControl;
            if (cb != null)
            {
                cb.HeaderBackground = (Brush)e.NewValue;
                cb.headerBorder.Background = cb.HeaderBackground;
            }
        }

        private static void OnHeaderForegroundChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CheckBoxesUserControl cb = d as CheckBoxesUserControl;
            if (cb != null)
            {
                cb.HeaderForeground = (Brush)e.NewValue;
                cb.headerTextBlock.Foreground = cb.HeaderForeground;
            }
        }

        public void UpdateCheckBoxes()
        {
            if (Data == null)
                return;
            checkboxesGrid.Children.Clear();
            bool enableGroupSelectButtons = EnableGroupSelectButtons;
            if (enableGroupSelectButtons == true)
            {
                selectButtonsGrid.Children.Clear();
                selectButtonsGrid.Rows = Rows;
            }
            if (enableGroupSelectButtons == false)
                mainCheckboxesContainer.ColumnDefinitions[1].Width = new GridLength(0);

            selectButtonsGrid.Visibility = enableGroupSelectButtons == true ? Visibility.Visible : Visibility.Hidden;
            bool[] checkboxesBits = Data;
            checkboxesGrid.Rows = Rows;
            checkboxesGrid.Columns = Columns;
            int cnt = 0;
            for (int row = 0; row < Rows; row++)
            {
                for (int column = 0; column < Columns; column++)
                {
                    CheckBox checkBox = new CheckBox() { Content = $"{row * Columns + column + 1}" };
                    checkBox.Margin = new Thickness(1, 0, 1, 1);
                    checkBox.VerticalAlignment = VerticalAlignment.Center;
                    if (checkboxesBits != null && checkboxesBits.Length > cnt)
                        checkBox.IsChecked = checkboxesBits[cnt];
                    checkBox.Checked += CheckBox_Checked;
                    checkBox.Unchecked += CheckBox_Unchecked;
                    cnt += 1;
                    checkboxesGrid.Children.Add(checkBox);
                }
                if (enableGroupSelectButtons == true)
                {
                    Button button = new Button();
                    button.Margin = new Thickness(1, 1, 1, 1);
                    button.Background = selectAllButton.Background;
                    button.Click += Button_Click;
                    button.Tag = $"{row}";
                    var dataTemplate = mainWindow.Resources["buttonTemplate"] as DataTemplate;
                    if (dataTemplate != null)
                        button.ContentTemplate = dataTemplate;
                    selectButtonsGrid.Children.Add(button);
                }
            }
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            if(checkBox != null)
            {
                updataData(int.Parse(checkBox.Content as string)-1, false);
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            if (checkBox != null)
            {
                updataData(int.Parse(checkBox.Content as string)-1, true);
            }
        }

        private void updataData(int id, bool state)
        {
            if (Data == null)
                return;
            bool[] checkboxesBits = Data;
            if (id >= 0 && id < checkboxesBits.Length && checkboxesBits[id] != state)
            {
                checkboxesBits[id] = state;
                Data = checkboxesBits;
                OnDataChanged();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null)
            {
                selectedRow = int.Parse((string)btn.Tag);
                selectPopupTextBlock.Text = $"{HeaderText}: {selectedRow * Columns + 1} - {selectedRow * Columns + Columns}";
                selectPopup.PopupAnimation = System.Windows.Controls.Primitives.PopupAnimation.Slide;
                selectPopup.IsOpen = false;
                selectPopup.IsOpen = true;
            }
        }

        private void setCheckboxes(int startIndex, int count, bool isChecked)
        {
            for (int i = startIndex; i < startIndex + count; i++)
            {
                var item = checkboxesGrid.Children[i] as CheckBox;
                if (item != null)
                    item.IsChecked = isChecked;
            }
        }
        private void invertCheckboxes(int startIndex, int count)
        {
            for (int i = startIndex; i < startIndex + count; i++)
            {
                var item = checkboxesGrid.Children[i] as CheckBox;
                if (item != null)
                    item.IsChecked = !item.IsChecked;
            }
        }
        private void ButtonClosePopup_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null)
            {
                if ((string)(btn.Content) == "Invert")
                {
                    if (selectedRow == -1)
                        invertCheckboxes(0, checkboxesGrid.Children.Count);
                    else
                        invertCheckboxes(selectedRow * checkboxesGrid.Columns, Columns);
                }
                else
                {
                    bool isChecked = (string)(btn.Content) == "Select";
                    if (selectedRow == -1)
                        setCheckboxes(0, checkboxesGrid.Children.Count, isChecked);
                    else
                        setCheckboxes(selectedRow * checkboxesGrid.Columns, Columns, isChecked);
                }

            }
        }
    }
}
