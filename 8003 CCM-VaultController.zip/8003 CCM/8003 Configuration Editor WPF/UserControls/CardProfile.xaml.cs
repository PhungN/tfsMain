﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;

namespace Pacom.ConfigurationEditor.WPF.UserControls
{
    public class MaskItem : IEditableObject, INotifyPropertyChanged
    {
        public string MaskBit { get; set; }

        private string _mask;
        public string MaskValue
        {
            get
            {
                return _mask;
            }

            set
            {
                _mask = value;
                OnPropertyChanged(new PropertyChangedEventArgs("MaskValue"));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        // Implements IEditableObject
        void IEditableObject.BeginEdit()
        {
        }

        void IEditableObject.CancelEdit()
        {
        }

        void IEditableObject.EndEdit()
        {
        }
    }

    /// <summary>
    /// Interaction logic for CardProfile.xaml
    /// </summary>
    public partial class CardProfile : UserControl
    {
        private Dictionary<CardProfileBitType, Brush> bitColorMap = new Dictionary<CardProfileBitType, Brush>()
        {
            { CardProfileBitType.CardNumber, Brushes.LightGreen},
            { CardProfileBitType.FacilityCode, Brushes.LightBlue},
            { CardProfileBitType.Issue, Brushes.LightCyan},
            { CardProfileBitType.EvenParity, Brushes.LightPink},
            { CardProfileBitType.OddParity, Brushes.Khaki}
        };

        private SortedDictionary<int, CardProfileBitType> bitDefinitionMap = new SortedDictionary<int, CardProfileBitType>();
        private SortedDictionary<int, CardProfileBitType> dragBitTypeMap = new SortedDictionary<int, CardProfileBitType>();

        ObservableCollection<MaskItem> evenParityDataList = new ObservableCollection<MaskItem>();
        ObservableCollection<MaskItem> oddParityDataList = new ObservableCollection<MaskItem>();

        public LegacyCardFormat ConfigurationItem { get; set; }

        int startColumn = 0;
        int endColumn = 0;
        ToggleButton toggleControl = null;
        private int maskStartColumn = 0;
        private int maskEndColumn = 0;

        //normal is Cursor.Arrow, profile is Cursor.Cross for (card, fac, issue, parity), MaskValue is Cursor.Cross for mask values
        public enum CardProfileBitType { CardNumber, FacilityCode, Issue, EvenParity, OddParity }

        public CardProfile(LegacyCardFormat node)
        {
            InitializeComponent();

            floatingTip.Child = new TextBlock();
            ConfigurationItem = node;

            dataGridEvenParityMask.DataContext = evenParityDataList;
            dataGridOddParityMask.DataContext = oddParityDataList;

            btnCardNumber.Background = bitColorMap[CardProfileBitType.CardNumber];
            btnClearCardNumber.Background = bitColorMap[CardProfileBitType.CardNumber];
            btnFacilityCode.Background = bitColorMap[CardProfileBitType.FacilityCode];
            btnClearFacilityCode.Background = bitColorMap[CardProfileBitType.FacilityCode];
            btnCardIssue.Background = bitColorMap[CardProfileBitType.Issue];
            btnClearCardIssue.Background = bitColorMap[CardProfileBitType.Issue];
            btnEvenParity.Background = bitColorMap[CardProfileBitType.EvenParity];
            btnClearEvenParity.Background = bitColorMap[CardProfileBitType.EvenParity];
            btnOddParity.Background = bitColorMap[CardProfileBitType.OddParity];
            btnClearOddParity.Background = bitColorMap[CardProfileBitType.OddParity];

            for (int i = ConfigurationItem.CodeOffset; i < ConfigurationItem.CodeOffset + ConfigurationItem.CodeLength; i++)
            {
                bitDefinitionMap[i] = CardProfileBitType.CardNumber;
                btnCardNumber.IsEnabled = false;
            }
            for (int i = ConfigurationItem.FacilityOffset; i < ConfigurationItem.FacilityOffset + ConfigurationItem.FacilityLength; i++)
            {
                bitDefinitionMap[i] = CardProfileBitType.FacilityCode;
                btnFacilityCode.IsEnabled = false;
            }
            for (int i = ConfigurationItem.IssueOffset; i < ConfigurationItem.IssueOffset + ConfigurationItem.IssueLength; i++)
            {
                bitDefinitionMap[i] = CardProfileBitType.Issue;
                btnCardIssue.IsEnabled = false;
            }

            if (ConfigurationItem.ParityConfiguration != null)
            {
                foreach (LegacyCardParity parity in ConfigurationItem.ParityConfiguration)
                {
                    switch (parity.ParityType)
                    {
                        case CardParity.Odd:
                            bitDefinitionMap[parity.Offset] = CardProfileBitType.OddParity;
                            oddParityDataList.Add(new MaskItem { MaskBit = parity.Offset.ToString(), MaskValue = parity.Mask.ToString("X16") });
                            break;
                        case CardParity.Even:
                            bitDefinitionMap[parity.Offset] = CardProfileBitType.EvenParity;
                            evenParityDataList.Add(new MaskItem { MaskBit = parity.Offset.ToString(), MaskValue = parity.Mask.ToString("X16") });
                            break;
                    }
                }
            }

            textBoxCardNumberBitCount.Text = ConfigurationItem.CodeLength.ToString();
            textBoxFacilityCodeBitCount.Text = ConfigurationItem.FacilityLength.ToString();
            textBoxIssueBitCount.Text = ConfigurationItem.IssueLength.ToString();
            textBoxCardNumberBitStart.Text = ConfigurationItem.CodeOffset.ToString();
            textBoxFacilityCodeBitStart.Text = ConfigurationItem.FacilityOffset.ToString();
            textBoxIssueBitStart.Text = ConfigurationItem.IssueOffset.ToString();

            checkBoxReverseBits.Checked -= checkBoxReverseBits_CheckBoxChanged;
            checkBoxReverseBits.IsChecked = ConfigurationItem.ReverseCardBits;
            checkBoxReverseBits.Checked += checkBoxReverseBits_CheckBoxChanged;
            checkBoxInvertBits.Checked -= checkBoxInvertBits_CheckBoxChanged;
            checkBoxInvertBits.IsChecked = ConfigurationItem.InvertCardBits;
            checkBoxInvertBits.Checked += checkBoxInvertBits_CheckBoxChanged;
            TotalBits.ValueChanged -= TotalBits_ValueChanged;
            TotalBits.Value = ConfigurationItem.NumberOfBits;
            TotalBits.ValueChanged += TotalBits_ValueChanged;
            ShowOrHideMaskColumns((int)TotalBits.Value);

            if (evenParityDataList.Count + oddParityDataList.Count >= 3)
            {
                btnOddParity.IsEnabled = false;
                btnEvenParity.IsEnabled = false;
            }

            btnClearCardNumber.IsEnabled = !btnCardNumber.IsEnabled;
            btnClearFacilityCode.IsEnabled = !btnFacilityCode.IsEnabled;
            btnClearCardIssue.IsEnabled = !btnCardIssue.IsEnabled;

            if (evenParityDataList.Count == 0)
                btnClearEvenParity.IsEnabled = false;
            if (oddParityDataList.Count == 0)
                btnClearOddParity.IsEnabled = false;

            btnCardNumber.Resources["CardProfileBitType"] = CardProfileBitType.CardNumber;
            btnFacilityCode.Resources["CardProfileBitType"] = CardProfileBitType.FacilityCode;
            btnCardIssue.Resources["CardProfileBitType"] = CardProfileBitType.Issue;
            btnEvenParity.Resources["CardProfileBitType"] = CardProfileBitType.EvenParity;
            btnOddParity.Resources["CardProfileBitType"] = CardProfileBitType.OddParity;

            btnClearCardNumber.Resources["btnProfile"] = btnCardNumber;
            btnClearCardNumber.Resources["textBoxBitStart"] = textBoxCardNumberBitStart;
            btnClearCardNumber.Resources["textBoxBitCount"] = textBoxCardNumberBitCount;
            btnClearCardNumber.Resources["CardProfileBitType"] = CardProfileBitType.CardNumber;

            btnClearFacilityCode.Resources["btnProfile"] = btnFacilityCode;
            btnClearFacilityCode.Resources["textBoxBitStart"] = textBoxFacilityCodeBitStart;
            btnClearFacilityCode.Resources["textBoxBitCount"] = textBoxFacilityCodeBitCount;
            btnClearFacilityCode.Resources["CardProfileBitType"] = CardProfileBitType.FacilityCode;

            btnClearCardIssue.Resources["btnProfile"] = btnCardIssue;
            btnClearCardIssue.Resources["textBoxBitStart"] = textBoxIssueBitStart;
            btnClearCardIssue.Resources["textBoxBitCount"] = textBoxIssueBitCount;
            btnClearCardIssue.Resources["CardProfileBitType"] = CardProfileBitType.Issue;

            btnClearEvenParity.Resources["btnParity"] = btnEvenParity;
            btnClearEvenParity.Resources["CardProfileBitType"] = CardProfileBitType.EvenParity;
            btnClearEvenParity.Resources["ParityDataList"] = evenParityDataList;
            btnClearEvenParity.Resources["maskDataGridBits"] = maskEvenDataGridBits;

            btnClearOddParity.Resources["btnParity"] = btnOddParity;
            btnClearOddParity.Resources["CardProfileBitType"] = CardProfileBitType.OddParity;
            btnClearOddParity.Resources["ParityDataList"] = oddParityDataList;
            btnClearOddParity.Resources["maskDataGridBits"] = maskOddDataGridBits;

            btnClearEvenParityMask.Resources["DataGridParityMask"] = dataGridEvenParityMask;
            btnClearOddParityMask.Resources["DataGridParityMask"] = dataGridOddParityMask;

            btnRemoveEvenParityMask.Resources["DataGridParityMask"] = dataGridEvenParityMask;
            btnRemoveOddParityMask.Resources["DataGridParityMask"] = dataGridOddParityMask;

            maskEvenDataGridBits.Resources["DataGridParityMask"] = dataGridEvenParityMask;
            maskOddDataGridBits.Resources["DataGridParityMask"] = dataGridOddParityMask;

            dataGridEvenParityMask.Resources["MaskDataGridBits"] = maskEvenDataGridBits;
            dataGridEvenParityMask.Resources["ParityDataList"] = evenParityDataList;
            dataGridEvenParityMask.Resources["btnClearParityMask"] = btnClearEvenParityMask;
            dataGridEvenParityMask.Resources["GroupBoxMaskValue"] = groupBoxEvenMaskValue;
            dataGridEvenParityMask.Resources["CardProfileBitType"] = CardProfileBitType.EvenParity;

            dataGridOddParityMask.Resources["MaskDataGridBits"] = maskOddDataGridBits;
            dataGridOddParityMask.Resources["ParityDataList"] = oddParityDataList;
            dataGridOddParityMask.Resources["btnClearParityMask"] = btnClearOddParityMask;
            dataGridOddParityMask.Resources["GroupBoxMaskValue"] = groupBoxOddMaskValue;
            dataGridOddParityMask.Resources["CardProfileBitType"] = CardProfileBitType.OddParity;

            redrawControl(bitDefinitionMap);
        }

        private Style getStyle(CardProfileBitType profile)
        {
            Style style = new Style(typeof(DataGridColumnHeader));
            Brush brush = bitColorMap[profile];
            style.Setters.Add(new Setter
            {
                Property = BackgroundProperty,
                Value = brush,
            });
            style.Setters.Add(new Setter(BorderThicknessProperty, new Thickness(0, 0, 1, 0)));
            return style;
        }

        private void resetToggleState(ToggleButton exempt)
        {
            // Reset toggle controls that are in the ON position
            foreach (ToggleButton control in ProfileElements.Children)
            {
                if (control.IsChecked == true && control != exempt)
                    control.IsChecked = false;
            }
        }

        private void btnProfile_Checked(object sender, RoutedEventArgs e)
        {
            ToggleButton toggleButton = (ToggleButton)sender;
            resetToggleState(toggleButton);
            groupBoxProfileValues.BorderBrush = bitColorMap[(CardProfileBitType)toggleButton.Resources["CardProfileBitType"]];
        }

        private void btnProfile_Unchecked(object sender, RoutedEventArgs e)
        {
            Cursor = Cursors.Arrow;
        }

        private void btnClearProfile_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            ToggleButton btnProfile = (ToggleButton)button.Resources["btnProfile"];
            TextBox textBoxBitStart = (TextBox)button.Resources["textBoxBitStart"];
            TextBox textBoxBitCount = (TextBox)button.Resources["textBoxBitCount"];
            CardProfileBitType cardProfileBitType = (CardProfileBitType)button.Resources["CardProfileBitType"];

            textBoxBitStart.Text = "0";
            textBoxBitCount.Text = "0";
            Cursor = Cursors.Arrow;
            btnProfile.IsEnabled = true;
            btnProfile.IsChecked = false;
            button.IsEnabled = false;
            BrushConverter converter = new BrushConverter();
            removeBits(cardProfileBitType);
            redrawControl(bitDefinitionMap);

            updateConfigurationItem();
        }

        private void btnClearParity_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            ToggleButton btnProfile = (ToggleButton)button.Resources["btnParity"];
            CardProfileBitType cardProfileBitType = (CardProfileBitType)button.Resources["CardProfileBitType"];
            ObservableCollection<MaskItem> parityDataList = (ObservableCollection<MaskItem>)button.Resources["ParityDataList"];
            DataGrid maskDataGridBits = (DataGrid)button.Resources["maskDataGridBits"];


            Cursor = Cursors.Arrow;
            btnProfile.IsChecked = false;
            removeBits(cardProfileBitType);
            redrawControl(bitDefinitionMap);
            parityDataList.Clear();
            if (evenParityDataList.Count + oddParityDataList.Count < 3)
            {
                btnOddParity.IsEnabled = true;
                btnEvenParity.IsEnabled = true;
            }
            button.IsEnabled = false;
            clearMaskColours(maskDataGridBits);

            updateConfigurationItem();
        }

        private static void copyDictionary(SortedDictionary<int, CardProfileBitType> source, SortedDictionary<int, CardProfileBitType> destination)
        {
            destination.Clear();
            foreach (KeyValuePair<int, CardProfileBitType> kvp in source)
            {
                destination.Add(kvp.Key, kvp.Value);
            }
        }

        private void redrawControl(SortedDictionary<int, CardProfileBitType> source)
        {
            for (int i = 0; i < dataGridBits.Columns.Count; i++)
            {
                CardProfileBitType profile;
                if (source.TryGetValue(i + 1, out profile))
                    dataGridBits.Columns[i].HeaderStyle = getStyle(profile);
                else
                    dataGridBits.Columns[i].HeaderStyle = null;
            }
        }

        private void dataGridBits_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount != 1)
                return;

            Point position = e.GetPosition(dataGridBits);
            startColumn = getColumnIndex(position, dataGridBits);

            // Find which control is in toggle mode
            foreach (ToggleButton control in ProfileElements.Children)
            {
                if (control.IsChecked == true)
                {
                    toggleControl = control;
                    break;
                }
            }
        }

        private void dataGridBits_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            Point position = e.GetPosition(dataGridBits);

            if (toggleControl == null && e.LeftButton != MouseButtonState.Pressed)
            {
                int column = getColumnIndex(position, dataGridBits);
                drawToolTip(column + 1, column + 1, position);
                return;
            }

            CardProfileBitType profile = CardProfileBitType.CardNumber;
            if (toggleControl != null)
                profile = (CardProfileBitType)toggleControl.Resources["CardProfileBitType"];

            copyDictionary(bitDefinitionMap, dragBitTypeMap);
            endColumn = getColumnIndex(position, dataGridBits);

            int sIndex = startColumn + 1;
            int eIndex = endColumn + 1;

            // allow only one bit for parity
            if (profile == CardProfileBitType.EvenParity || profile == CardProfileBitType.OddParity)
            {
                dataGridBits.PreviewMouseMove -= dataGridBits_PreviewMouseMove;
                eIndex = sIndex;
            }
            else
            {
                if (startColumn > endColumn)
                {
                    sIndex = endColumn;
                    eIndex = startColumn;
                }
            }

            for (int i = sIndex; i <= eIndex; i++)
            {
                dragBitTypeMap[i] = profile;
            }

            drawToolTip(sIndex, eIndex, position);
            redrawControl(dragBitTypeMap);
        }

        private void dataGridBits_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            dataGridBits.PreviewMouseMove -= dataGridBits_PreviewMouseMove;

            if (toggleControl != null)
            {
                Cursor = Cursors.Arrow;
                CardProfileBitType profile = (CardProfileBitType)toggleControl.Resources["CardProfileBitType"];
                toggleControl.IsChecked = false;
                toggleControl = null;

                // Before accepting the changes check that the card number, facility and issue bits have no breaks in the bit stream
                if (checkBitValidity(dragBitTypeMap))
                {
                    copyDictionary(dragBitTypeMap, bitDefinitionMap);

                    List<MaskItem> evenParityTempList = evenParityDataList.ToList();
                    List<MaskItem> oddParityTempList = oddParityDataList.ToList();

                    //create mask row
                    int evenParitySelectedIndex = dataGridEvenParityMask.SelectedIndex;
                    int oddParitySelectedIndex = dataGridEvenParityMask.SelectedIndex;

                    oddParityDataList.Clear();
                    evenParityDataList.Clear();
                    foreach (KeyValuePair<int, CardProfileBitType> kvp in dragBitTypeMap)
                    {
                        switch (kvp.Value)
                        {
                            case CardProfileBitType.OddParity:
                                MaskItem oddResult = oddParityTempList.Find(x => x.MaskBit == kvp.Key.ToString());
                                oddParityDataList.Add(new MaskItem { MaskBit = kvp.Key.ToString(), MaskValue = oddResult == null ? "0000000000000000" : oddResult.MaskValue });
                                break;
                            case CardProfileBitType.EvenParity:
                                MaskItem evenResult = evenParityTempList.Find(x => x.MaskBit == kvp.Key.ToString());
                                evenParityDataList.Add(new MaskItem { MaskBit = kvp.Key.ToString(), MaskValue = evenResult == null ? "0000000000000000" : evenResult.MaskValue });
                                break;
                        }
                    }

                    if (profile == CardProfileBitType.EvenParity)
                        evenParitySelectedIndex = dataGridEvenParityMask.Items.Count - 1;
                    else
                        oddParitySelectedIndex = dataGridOddParityMask.Items.Count - 1;

                    if (dataGridEvenParityMask.Items.Count > 0)
                    {
                        if (dataGridEvenParityMask.Items.Count > evenParitySelectedIndex)
                            dataGridEvenParityMask.SelectedIndex = evenParitySelectedIndex;
                        else
                            dataGridEvenParityMask.SelectedIndex = 1;
                    }
                    if (dataGridOddParityMask.Items.Count > 0)
                    {
                        if (dataGridOddParityMask.Items.Count > oddParitySelectedIndex)
                            dataGridOddParityMask.SelectedIndex = oddParitySelectedIndex;
                        else
                            dataGridOddParityMask.SelectedIndex = 1;
                    }

                    updateConfigurationItem();
                }
                else
                {
                    redrawControl(bitDefinitionMap);
                }
            }

            startColumn = 0;
            endColumn = 0;
            dragBitTypeMap.Clear();
        }

        private void dataGridBits_MouseEnter(object sender, MouseEventArgs e)
        {
            foreach (ToggleButton control in ProfileElements.Children)
            {
                if (control.IsChecked == true)
                {
                    Point position = e.GetPosition(dataGridBits);
                    int column = getColumnIndex(position, dataGridBits);
                    floatingTip.IsOpen = true;
                    drawToolTip(column + 1, column + 1, position);
                    Cursor = Cursors.Cross;
                    dataGridBits.PreviewMouseMove += dataGridBits_PreviewMouseMove;

                    break;
                }
            }
        }

        private void drawToolTip(int startIndex, int endIndex, Point position)
        {
            if (floatingTip.IsOpen == false)
                return;

            TextBlock txtToolTip = floatingTip.Child as TextBlock;
            txtToolTip.Text = string.Format("{0} - {1}", (startIndex).ToString("0"), (endIndex).ToString("0"));
            txtToolTip.Foreground = Brushes.Black;
            txtToolTip.Background = Brushes.White;
            floatingTip.HorizontalOffset = position.X + 14;
            floatingTip.VerticalOffset = 5;
        }

        private void dataGridBits_MouseLeave(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.Arrow;
            floatingTip.IsOpen = false;
            if (toggleControl == null)
                dataGridBits.PreviewMouseMove -= dataGridBits_PreviewMouseMove;
        }

        private static bool checkBitValidity(SortedDictionary<int, CardProfileBitType> source)
        {
            CardProfileBitType previousProfile = CardProfileBitType.EvenParity;
            int index = 0;
            bool cardNumberFound = false;
            bool facilityCodeFound = false;
            bool issueFound = false;
            foreach (KeyValuePair<int, CardProfileBitType> kvp in source)
            {
                switch (kvp.Value)
                {
                    case CardProfileBitType.CardNumber:
                        if ((previousProfile == kvp.Value && index != kvp.Key - 1) || (previousProfile != kvp.Value && cardNumberFound))
                        {
                            Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                                Translation.GetTranslatedError(ErrorMessage.ContiguousCardNumber),
                                Translation.GetTranslatedError(ErrorMessage.Error));

                            return false;
                        }
                        cardNumberFound = true;
                        previousProfile = kvp.Value;
                        index = kvp.Key;
                        break;
                    case CardProfileBitType.FacilityCode:
                        if ((previousProfile == kvp.Value && index != kvp.Key - 1) || (previousProfile != kvp.Value && facilityCodeFound))
                        {
                            Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                                Translation.GetTranslatedError(ErrorMessage.ContiguousFacilityCode),
                                Translation.GetTranslatedError(ErrorMessage.Error));

                            return false;
                        }
                        facilityCodeFound = true;
                        previousProfile = kvp.Value;
                        index = kvp.Key;
                        break;
                    case CardProfileBitType.Issue:
                        if ((previousProfile == kvp.Value && index != kvp.Key - 1) || (previousProfile != kvp.Value && issueFound))
                        {
                            Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                                Translation.GetTranslatedError(ErrorMessage.ContiguousIssue),
                                Translation.GetTranslatedError(ErrorMessage.Error));

                            return false;
                        }
                        issueFound = true;
                        previousProfile = kvp.Value;
                        index = kvp.Key;
                        break;
                    default:
                        break;
                }
            }
            return true;
        }

        private int getTotalBits(SortedDictionary<int, CardProfileBitType> source)
        {
            int totalBits = 0;
            for (int i = 0; i < dataGridBits.Columns.Count; i++)
            {
                CardProfileBitType profile;
                if (source.TryGetValue(i, out profile))
                    totalBits = i;
            }
            return totalBits;
        }

        private void updateConfigurationItem()
        {
            App.ConfigurationModified = true;
            ConfigurationItem.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            ConfigurationItem.NumberOfBits = 0;
            ConfigurationItem.FacilityLength = 0;
            ConfigurationItem.FacilityOffset = 0;
            ConfigurationItem.IssueLength = 0;
            ConfigurationItem.IssueOffset = 0;
            ConfigurationItem.CodeLength = 0;
            ConfigurationItem.CodeOffset = 0;

            int parityBits = evenParityDataList.Count + oddParityDataList.Count;
            ConfigurationItem.ParityConfiguration = new LegacyCardParity[parityBits];
            int bits = getTotalBits(bitDefinitionMap);
            if (bits > TotalBits.Value)
            {
                TotalBits.ValueChanged -= TotalBits_ValueChanged;
                TotalBits.Value = bits;
                TotalBits.ValueChanged += TotalBits_ValueChanged;
                ShowOrHideMaskColumns((int)TotalBits.Value);
            }

            ConfigurationItem.NumberOfBits = (int)TotalBits.Value;

            int index = 0;
            foreach (MaskItem evenParity in evenParityDataList)
            {
                if (evenParity.MaskBit != null)
                {
                    LegacyCardParity parity = new LegacyCardParity();
                    parity.ParityType = CardParity.Even;
                    parity.Offset = Convert.ToByte(evenParity.MaskBit);
                    parity.Mask = string.IsNullOrEmpty(evenParity.MaskValue) ? 0 : Convert.ToInt64(evenParity.MaskValue, 16);
                    ConfigurationItem.ParityConfiguration[index] = parity;
                    index++;
                }
            }
            foreach (MaskItem oddParity in oddParityDataList)
            {
                if (oddParity.MaskBit != null)
                {
                    LegacyCardParity parity = new LegacyCardParity();
                    parity.ParityType = CardParity.Odd;
                    parity.Offset = Convert.ToByte(oddParity.MaskBit);
                    parity.Mask = string.IsNullOrEmpty(oddParity.MaskValue) ? 0 : Convert.ToInt64(oddParity.MaskValue, 16);
                    ConfigurationItem.ParityConfiguration[index] = parity;
                    index++;
                }
            }

            for (int i = 0; i < parityBits; i++)
            {
                if (ConfigurationItem.ParityConfiguration[i] == null)
                {
                    LegacyCardParity parity = new LegacyCardParity();
                    parity.ParityType = CardParity.None;
                    parity.Offset = 0;
                    parity.Mask = 0;
                    ConfigurationItem.ParityConfiguration[index] = parity;
                }
            }

            CardProfileBitType previousProfile = CardProfileBitType.EvenParity;

            // Card Number, Facility Code and Issue are only allowed once
            btnCardNumber.IsEnabled = true;
            btnClearCardNumber.IsEnabled = false;
            btnFacilityCode.IsEnabled = true;
            btnClearFacilityCode.IsEnabled = false;
            btnCardIssue.IsEnabled = true;
            btnClearCardIssue.IsEnabled = false;

            foreach (KeyValuePair<int, CardProfileBitType> kvp in bitDefinitionMap)
            {
                switch (kvp.Value)
                {
                    case CardProfileBitType.CardNumber:
                        if ((previousProfile != kvp.Value) || (previousProfile == kvp.Value && ConfigurationItem.CodeOffset > kvp.Key))
                            ConfigurationItem.CodeOffset = kvp.Key;
                        ConfigurationItem.CodeLength += 1;
                        btnClearCardNumber.IsEnabled = true;
                        btnCardNumber.IsEnabled = false;
                        break;
                    case CardProfileBitType.FacilityCode:
                        if ((previousProfile != kvp.Value) || (previousProfile == kvp.Value && ConfigurationItem.FacilityOffset > kvp.Key))
                            ConfigurationItem.FacilityOffset = kvp.Key;
                        ConfigurationItem.FacilityLength += 1;
                        btnClearFacilityCode.IsEnabled = true;
                        btnFacilityCode.IsEnabled = false;
                        break;
                    case CardProfileBitType.Issue:
                        if ((previousProfile != kvp.Value) || (previousProfile == kvp.Value && ConfigurationItem.IssueOffset > kvp.Key))
                            ConfigurationItem.IssueOffset = kvp.Key;
                        ConfigurationItem.IssueLength += 1;
                        btnClearCardIssue.IsEnabled = true;
                        btnCardIssue.IsEnabled = false;
                        break;
                }
                previousProfile = kvp.Value;
            }

            if (evenParityDataList.Count + oddParityDataList.Count >= 3)
            {
                btnOddParity.IsEnabled = false;
                btnEvenParity.IsEnabled = false;
            }
            else
            {
                btnOddParity.IsEnabled = true;
                btnEvenParity.IsEnabled = true;
            }

            if (evenParityDataList.Count == 0)
                btnClearEvenParity.IsEnabled = false;
            else
                btnClearEvenParity.IsEnabled = true;

            if (oddParityDataList.Count == 0)
                btnClearOddParity.IsEnabled = false;
            else
                btnClearOddParity.IsEnabled = true;

            textBoxCardNumberBitCount.Text = ConfigurationItem.CodeLength.ToString();
            textBoxCardNumberBitStart.Text = ConfigurationItem.CodeOffset.ToString();

            textBoxFacilityCodeBitCount.Text = ConfigurationItem.FacilityLength.ToString();
            textBoxFacilityCodeBitStart.Text = ConfigurationItem.FacilityOffset.ToString();

            textBoxIssueBitCount.Text = ConfigurationItem.IssueLength.ToString();
            textBoxIssueBitStart.Text = ConfigurationItem.IssueOffset.ToString();

            ConfigurationItem.ReverseCardBits = (bool)checkBoxReverseBits.IsChecked;
            ConfigurationItem.InvertCardBits = (bool)checkBoxInvertBits.IsChecked;
        }

        private static int getColumnIndex(Point position, DataGrid grid)
        {
            int column = 0;
            double accumulatedWidth = 0.0;

            // calculate the column the mouse was over
            foreach (DataGridColumn columnDefinition in grid.Columns)
            {
                accumulatedWidth += columnDefinition.ActualWidth;
                if (accumulatedWidth >= position.X)
                    break;
                column++;
            }
            return column;
        }

        private void removeBits(CardProfileBitType controlProfile)
        {
            List<int> toRemove = new List<int>();
            foreach (KeyValuePair<int, CardProfileBitType> kvp in bitDefinitionMap)
            {
                if (kvp.Value == controlProfile)
                    toRemove.Add(kvp.Key);
            }

            foreach (int i in toRemove)
            {
                bitDefinitionMap.Remove(i);
            }
        }

        private void btnClearAll_Click(object sender, RoutedEventArgs e)
        {
            clearMaskColours(maskEvenDataGridBits);
            clearMaskColours(maskOddDataGridBits);

            // Reset toggle controls that are in the ON position
            foreach (ToggleButton control in ProfileElements.Children)
            {
                control.IsEnabled = true;
            }

            // Reset toggle controls that are in the OFF position
            foreach (Button control in ClearProfileElements.Children)
            {
                control.IsEnabled = false;
            }

            resetToggleState(null);
            bitDefinitionMap.Clear();
            redrawControl(bitDefinitionMap);
            evenParityDataList.Clear();
            oddParityDataList.Clear();
            dataGridBits.PreviewMouseMove -= dataGridBits_PreviewMouseMove;
            toggleControl = null;
            ShowOrHideMaskColumns((int)TotalBits.Value);

            textBoxCardNumberBitCount.Text = "0";
            textBoxFacilityCodeBitCount.Text = "0";
            textBoxIssueBitCount.Text = "0";
            textBoxCardNumberBitStart.Text = "0";
            textBoxFacilityCodeBitStart.Text = "0";
            textBoxIssueBitStart.Text = "0";

            updateConfigurationItem();
        }

        private void TotalBits_ValueChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            ShowOrHideMaskColumns((int)TotalBits.Value);

            int maxIndex = (int)TotalBits.Value;
            for (int i = maxIndex; i < dataGridBits.Columns.Count; i++)
            {
                dataGridBits.Columns[i].HeaderStyle = null;
                if (bitDefinitionMap.ContainsKey(i + 1))
                    bitDefinitionMap.Remove(i + 1);
            }

            ulong mask = (ulong)Math.Pow(2, maxIndex) - 1;

            for (int i = 0; i < evenParityDataList.Count; i++)
            {
                int parityBit = int.Parse(evenParityDataList[i].MaskBit);
                if (parityBit > maxIndex)
                {
                    evenParityDataList.RemoveAt(i);
                    i--;
                }
                else
                {
                    ulong parityMask = string.IsNullOrEmpty(evenParityDataList[i].MaskValue) ? 0 : Convert.ToUInt64(evenParityDataList[i].MaskValue, 16);
                    parityMask = parityMask & mask;
                    evenParityDataList[i].MaskValue = parityMask.ToString("X16");
                }
            }
            for (int i = 0; i < oddParityDataList.Count; i++)
            {
                int parityBit = int.Parse(oddParityDataList[i].MaskBit);
                if (parityBit > maxIndex)
                {
                    oddParityDataList.RemoveAt(i);
                    i--;
                }
                else
                {
                    ulong parityMask = string.IsNullOrEmpty(oddParityDataList[i].MaskValue) ? 0 : Convert.ToUInt64(oddParityDataList[i].MaskValue, 16);
                    parityMask = parityMask & mask;
                    oddParityDataList[i].MaskValue = parityMask.ToString("X16");
                }
            }

            if (evenParityDataList.Count + oddParityDataList.Count < 3)
            {
                btnOddParity.IsEnabled = true;
                btnEvenParity.IsEnabled = true;
            }

            if (evenParityDataList.Count == 0)
                btnClearEvenParity.IsEnabled = false;
            if (oddParityDataList.Count == 0)
                btnClearOddParity.IsEnabled = false;

            updateConfigurationItem();
        }

        private void ShowOrHideMaskColumns(int maxLength)
        {
            int end = 64;
            if (maxLength < 64)
            {
                //show or hide columns
                end = maxLength;
            }

            for (int i = 0; i < 64; i++)
            {
                if (i >= end)
                {
                    maskEvenDataGridBits.Columns[i].Visibility = Visibility.Hidden;
                    maskEvenDataGridBits.Columns[i].HeaderStyle = null;
                    maskOddDataGridBits.Columns[i].Visibility = Visibility.Hidden;
                    maskOddDataGridBits.Columns[i].HeaderStyle = null;
                }
                else
                {
                    maskEvenDataGridBits.Columns[i].Visibility = Visibility.Visible;
                    maskOddDataGridBits.Columns[i].Visibility = Visibility.Visible;
                }
            }
        }

        private void checkBoxReverseBits_CheckBoxChanged(object sender, RoutedEventArgs e)
        {
            ConfigurationItem.ReverseCardBits = (bool)checkBoxReverseBits.IsChecked;

            updateConfigurationItem();
        }

        private void checkBoxInvertBits_CheckBoxChanged(object sender, RoutedEventArgs e)
        {
            ConfigurationItem.InvertCardBits = (bool)checkBoxInvertBits.IsChecked;

            updateConfigurationItem();
        }

        private void clearMaskColours(DataGrid grid)
        {
            // mask is limited to 64 bits
            for (int i = 0; i < grid.Columns.Count; i++)
            {
                grid.Columns[i].HeaderStyle = null;
            }
            Cursor = Cursors.Arrow;
        }

        private static string calculateMaskValue(DataGrid grid)
        {
            ulong result = 0;
            for (int i = 0; i < grid.Columns.Count; i++)
            {
                if (grid.Columns[i].HeaderStyle != null)
                    result |= ((ulong)1 << i);
            }
            return result.ToString("X16");
        }

        private void btnClearParityMask_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Button button = (Button)sender;
            DataGrid dataGridParityMask = (DataGrid)button.Resources["DataGridParityMask"];

            DataGrid maskDataGridBits = (DataGrid)dataGridParityMask.Resources["MaskDataGridBits"];
            ObservableCollection<MaskItem> parityDataList = (ObservableCollection<MaskItem>)dataGridParityMask.Resources["ParityDataList"];

            clearMaskColours(maskDataGridBits);
            if (dataGridParityMask.SelectedIndex != -1)
            {
                parityDataList[dataGridParityMask.SelectedIndex].MaskValue = "0000000000000000";
                dataGridParityMask.Items.Refresh();
            }
        }

        private void btnRemoveParityMask_PreviewMouseLeftButtonDown(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            DataGrid dataGridParityMask = (DataGrid)button.Resources["DataGridParityMask"];

            int selectedIndex = dataGridParityMask.SelectedIndex;
            if (selectedIndex != -1)
            {
                DataGrid maskDataGridBits = (DataGrid)dataGridParityMask.Resources["MaskDataGridBits"];
                ObservableCollection<MaskItem> parityDataList = (ObservableCollection<MaskItem>)dataGridParityMask.Resources["ParityDataList"];

                int bitIndex = int.Parse(((MaskItem)dataGridParityMask.SelectedItem).MaskBit);
                parityDataList.RemoveAt(selectedIndex);
                bitDefinitionMap.Remove(bitIndex);
            }
            redrawControl(bitDefinitionMap);
            updateConfigurationItem();

            if (dataGridParityMask.Items.Count > 0)
                dataGridParityMask.SelectedIndex = 0;
        }

        private void dataGridParityMask_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dataGridParityMask = (DataGrid)sender;
            GroupBox groupBoxMaskValue = (GroupBox)dataGridParityMask.Resources["GroupBoxMaskValue"];
            DataGrid maskDataGridBits = (DataGrid)dataGridParityMask.Resources["MaskDataGridBits"];
            CardProfileBitType cardProfileBitType = (CardProfileBitType)dataGridParityMask.Resources["CardProfileBitType"];

            if (dataGridParityMask.SelectedIndex == -1)
            {
                groupBoxMaskValue.IsEnabled = false;
                clearMaskColours(maskDataGridBits);
            }
            else
            {
                groupBoxMaskValue.IsEnabled = true;
                groupBoxMaskValue.BorderBrush = bitColorMap[cardProfileBitType];
                ulong mask = Convert.ToUInt64(((MaskItem)dataGridParityMask.Items[dataGridParityMask.SelectedIndex]).MaskValue, 16);

                Style headerStyle = getStyle(cardProfileBitType);

                //mask is limited to 64 bits
                for (int i = 0; i < maskDataGridBits.Columns.Count; i++)
                {
                    if ((mask & ((ulong)1 << i)) == 0)
                        maskDataGridBits.Columns[i].HeaderStyle = null;
                    else
                        maskDataGridBits.Columns[i].HeaderStyle = headerStyle;
                }
            }
        }

        // startHeaderStyle defines whether the cells are set or cleared. 
        Style initialHeaderStyle = null;

        private void maskDataGridBits_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount != 1)
                return;

            DataGrid maskDataGridBits = (DataGrid)sender;
            Point position = e.GetPosition(maskDataGridBits);
            maskStartColumn = getColumnIndex(position, maskDataGridBits);

            // defines whether the cells are set or cleared. So if the first mouse down is already set then all other will also be set otherwise be cleared
            initialHeaderStyle = maskDataGridBits.Columns[maskStartColumn].HeaderStyle;

            maskDataGridBits.PreviewMouseMove += maskDataGridBits_PreviewMouseMove;
        }

        private void maskDataGridBits_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Released)
                return;

            DataGrid maskDataGridBits = (DataGrid)sender;
            DataGrid dataGridParityMask = (DataGrid)maskDataGridBits.Resources["DataGridParityMask"];
            CardProfileBitType cardProfileBitType = (CardProfileBitType)dataGridParityMask.Resources["CardProfileBitType"];

            Point position = e.GetPosition(maskDataGridBits);
            maskEndColumn = getColumnIndex(position, maskDataGridBits);
            int sIndex = maskStartColumn;
            int eIndex = maskEndColumn;

            if (maskStartColumn > maskEndColumn)
            {
                sIndex = maskEndColumn;
                eIndex = maskStartColumn;
            }


            int maxIndex = 63;
            if (maxIndex > (TotalBits.Value - 1))
                maxIndex = (int)TotalBits.Value - 1;
            if (eIndex > maxIndex)
                eIndex = maxIndex;

            // follow the start position heading (initialHeaderStyle)
            for (int i = sIndex; i <= eIndex; i++)
            {
                if (initialHeaderStyle == null)
                    maskDataGridBits.Columns[i].HeaderStyle = getStyle(cardProfileBitType);
                else
                    maskDataGridBits.Columns[i].HeaderStyle = null;
            }
        }

        private void maskDataGridBits_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            DataGrid maskDataGridBits = (DataGrid)sender;
            DataGrid dataGridParityMask = (DataGrid)maskDataGridBits.Resources["DataGridParityMask"];
            ObservableCollection<MaskItem> parityDataList = (ObservableCollection<MaskItem>)dataGridParityMask.Resources["ParityDataList"];

            maskDataGridBits.PreviewMouseMove -= maskDataGridBits_PreviewMouseMove;

            maskStartColumn = 0;
            maskEndColumn = 0;

            if (dataGridParityMask.SelectedIndex != -1)
            {
                parityDataList[dataGridParityMask.SelectedIndex].MaskValue = calculateMaskValue(maskDataGridBits);
                updateConfigurationItem();
            }
        }

        private void maskDataGridBits_MouseEnter(object sender, MouseEventArgs e)
        {
            DataGrid maskDataGridBits = (DataGrid)sender;
            DataGrid dataGridParityMask = (DataGrid)maskDataGridBits.Resources["DataGridParityMask"];

            if (dataGridParityMask.SelectedIndex != -1)
                Cursor = Cursors.Cross;
        }

        private void maskDataGridBits_MouseLeave(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.Arrow;
        }

        private void dataGridParityMask_Loaded(object sender, RoutedEventArgs e)
        {
            DataGrid dataGridParityMask = (DataGrid)sender;

            if (dataGridParityMask.Items.Count > 0)
                dataGridParityMask.SelectedIndex = 0;
        }
    }
}
