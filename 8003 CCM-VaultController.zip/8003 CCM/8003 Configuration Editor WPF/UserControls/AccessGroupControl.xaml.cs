﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.UserControls
{
    public class ScheduleWrapper
    {
        public Schedule Schedule { get; private set; }
        public ScheduleWrapper(Schedule schedule)
        {
            Schedule = schedule;
        }

        public override string ToString()
        {
            return Translation.GetTranslatedNodeTreeItem("Schedule") + ":" + Schedule.Id;
        }
    }

    public class PermissionItem : IEditableObject, INotifyPropertyChanged
    {
        public event EventHandler ConfigurationChanged;

        private static List<NodeConfiguration> additionalNodes = new List<NodeConfiguration>();
        public static List<NodeConfiguration> AdditionalNodes { get { return additionalNodes; } }

        public static ObservableCollection<NodeConfiguration> NodeComboItems
        {
            get
            {
                ObservableCollection<NodeConfiguration> allItems = new ObservableCollection<NodeConfiguration>();
                foreach (NodeConfiguration node in additionalNodes)
                {
                    allItems.Add(node);
                }
                foreach (Area8003Configuration area in ConfigurationManager.Areas.Values)
                {
                    allItems.Add(area);
                }
                foreach (Reader8003Configuration reader in ConfigurationManager.UnisonReaders.Values)
                {
                    allItems.Add(reader);
                }
                return allItems;
            }
        }

        private NodeConfiguration node;
        public NodeConfiguration Node
        {
            get { return node; }
            set { node = value; ConfigurationChanged(this, new EventArgs()); }
        }

        public void SetNode(NodeConfiguration node)
        {
            this.node = node;
            OnPropertyChanged(new PropertyChangedEventArgs("Node"));
        }

        public static ObservableCollection<ScheduleWrapper> ScheduleItems
        {
            get;
            set;
        }

        private ScheduleWrapper schedule;
        public ScheduleWrapper Schedule
        {
            get { return schedule; }
            set { schedule = value; ConfigurationChanged(this, new EventArgs()); }
        }

        public void SetSchedule(ScheduleWrapper schedule)
        {
            this.schedule = schedule;
            OnPropertyChanged(new PropertyChangedEventArgs("Schedule"));
        }

        private DateTime validFrom;
        public DateTime ValidFrom
        {
            get { return validFrom; }
            set
            {
                validFrom = new DateTime(value.Year, value.Month, value.Day, 0, 0, 0);
                ConfigurationChanged(this, new EventArgs());
            }
        }

        public string FormattedValidFrom
        {
            get
            {
                return ValidFrom.ToShortDateString();
            }
        }

        public void SetValidFrom(DateTime date)
        {
            validFrom = date;
            OnPropertyChanged(new PropertyChangedEventArgs("ValidFrom"));
        }

        private DateTime validTo;
        public DateTime ValidTo
        {
            get { return validTo; }
            set
            {
                validTo = new DateTime(value.Year, value.Month, value.Day, 23, 59, 59);
                ConfigurationChanged(this, new EventArgs());
            }
        }

        public string FormattedValidTo
        {
            get
            {
                return ValidTo.ToShortDateString();
            }
        }

        public void SetValidTo(DateTime date)
        {
            validTo = date;
            OnPropertyChanged(new PropertyChangedEventArgs("ValidTo"));
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        // Implements IEditableObject
        void IEditableObject.BeginEdit()
        {
        }

        void IEditableObject.CancelEdit()
        {
        }

        void IEditableObject.EndEdit()
        {
        }
    }

    /// <summary>
    /// Interaction logic for AccessGroupControl.xaml
    /// </summary>
    public partial class AccessGroupControl : UserControl
    {
        ObservableCollection<PermissionItem> collectionPermissions = new ObservableCollection<PermissionItem>();
        ObservableCollection<ScheduleWrapper> allSchedules = new ObservableCollection<ScheduleWrapper>();

        AccessGroup configurationItem { get; set; }
        public AccessGroupControl(AccessGroup node)
        {
            InitializeComponent();

            dataGridPermissions.Columns[0].Header = Translation.GetTranslatedMisc("Node");
            dataGridPermissions.Columns[1].Header = Translation.GetTranslatedNodeTreeItem("Schedule");
            dataGridPermissions.Columns[2].Header = Translation.GetTranslatedNodeTreeItem("ValidFrom");
            dataGridPermissions.Columns[3].Header = Translation.GetTranslatedNodeTreeItem("ValidTo");
            dataGridPermissions.Columns[4].Header = Translation.GetTranslatedMisc("Delete");

            addButton.Content = Translation.GetTranslatedMisc("AddPermission");

            dataGridPermissions.DataContext = collectionPermissions;

            configurationItem = node;

            PermissionItem.AdditionalNodes.Clear();
            PermissionItem.ScheduleItems = allSchedules;
            foreach (Schedule schedule in ConfigurationManager.Schedules.Values)
            {
                allSchedules.Add(new ScheduleWrapper(schedule));
            }

            if (node.AccessGroupMembers == null)
                node.AccessGroupMembers = new AccessGroupMember[0];
            for (int i = 0; i < node.AccessGroupMembers.Length; i++)
            {
                PermissionItem permissionItem = new PermissionItem();
                if (node.AccessGroupMembers[i].NodeCategory == NodeCategory.Area)
                {
                    Area8003Configuration area = null;
                    if (ConfigurationManager.Areas.TryGetValue(node.AccessGroupMembers[i].NodeId, out area) == false)
                    {
                        area = new Area8003Configuration();
                        area.SetDefaults();
                        area.Id = node.AccessGroupMembers[i].NodeId;
                        area.Name = Translation.GetTranslatedString(typeof(Area8003Configuration)) + "-" + area.Id.ToString();
                        PermissionItem.AdditionalNodes.Add(area);
                    }
                    permissionItem.SetNode(area);
                }
                else if (node.AccessGroupMembers[i].NodeCategory == NodeCategory.Reader)
                {
                    Reader8003Configuration reader = null;
                    if (ConfigurationManager.UnisonReaders.TryGetValue(node.AccessGroupMembers[i].NodeId, out reader) == false)
                    {
                        reader = new Reader8003Configuration();
                        reader.SetDefaults();
                        reader.Id = node.AccessGroupMembers[i].NodeId;
                        reader.Name = Translation.GetTranslatedString(typeof(Reader8003Configuration)) + "-" + reader.Id.ToString();
                        PermissionItem.AdditionalNodes.Add(reader);
                    }
                    permissionItem.SetNode(reader);
                }

                foreach (ScheduleWrapper possibleSchedule in allSchedules)
                {
                    if (possibleSchedule.Schedule.Id == node.AccessGroupMembers[i].ScheduleId)
                    {
                        permissionItem.SetSchedule(possibleSchedule);
                        break;
                    }
                }
                permissionItem.SetValidFrom(node.AccessGroupMembers[i].ValidFrom);
                permissionItem.SetValidTo(node.AccessGroupMembers[i].ValidTo);
                permissionItem.ConfigurationChanged += PermissionItem_ConfigurationChanged;
                collectionPermissions.Add(permissionItem);
            }
        }

        private void saveAccessGroup()
        {
            if (configurationItem != null)
            {
                App.ConfigurationModified = true;
                configurationItem.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                List<AccessGroupMember> accessGroupMembers = new List<AccessGroupMember>();
                for (int i = 0; i < collectionPermissions.Count; i++)
                {
                    if (collectionPermissions[i].Node != null && collectionPermissions[i].Schedule != null)
                    {
                        AccessGroupMember accessGroupMember = new AccessGroupMember();
                        accessGroupMember.NodeCategory = collectionPermissions[i].Node.Category;
                        accessGroupMember.NodeId = collectionPermissions[i].Node.Id;
                        accessGroupMember.ScheduleId = collectionPermissions[i].Schedule.Schedule.Id;
                        accessGroupMember.ValidFrom = collectionPermissions[i].ValidFrom;
                        accessGroupMember.ValidTo = collectionPermissions[i].ValidTo;
                        accessGroupMembers.Add(accessGroupMember);
                    }
                }
                configurationItem.AccessGroupMembers = accessGroupMembers.ToArray();
            }
        }

        private void OnDelete_Permission(object sender, RoutedEventArgs e)
        {
            PermissionItem permissionItem = collectionPermissions[dataGridPermissions.SelectedIndex];
            permissionItem.PropertyChanged -= PermissionItem_ConfigurationChanged;
            collectionPermissions.Remove(permissionItem);
            saveAccessGroup();
        }

        private void PermissionItem_ConfigurationChanged(object sender, EventArgs e)
        {
            saveAccessGroup();
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            PermissionItem permissionItem = new PermissionItem();
            if (PermissionItem.NodeComboItems.Count > 0)
            {
                permissionItem.SetNode(PermissionItem.NodeComboItems[0]);

                // If there is more then 1 node, select the first node that doesn't already have permissions applied.
                if (PermissionItem.NodeComboItems.Count > 1)
                {
                    for (int i = 0; i < PermissionItem.NodeComboItems.Count; i++)
                    {
                        bool match = false;
                        foreach (PermissionItem collectionPermission in collectionPermissions)
                        {
                            if (collectionPermission.Node == PermissionItem.NodeComboItems[i])
                            {
                                match = true;
                                break;
                            }
                        }
                        if (match == false)
                        {
                            permissionItem.SetNode(PermissionItem.NodeComboItems[i]);
                            break;
                        }
                    }
                }
            }
            if (PermissionItem.ScheduleItems.Count > 0)
                permissionItem.SetSchedule(PermissionItem.ScheduleItems[0]);
            permissionItem.SetValidFrom(new DateTime(1753, 1, 1));
            permissionItem.SetValidTo(new DateTime(9999, 12, 31, 23, 59, 59));
            permissionItem.ConfigurationChanged += PermissionItem_ConfigurationChanged;
            collectionPermissions.Add(permissionItem);

            saveAccessGroup();
        }
    }
}
