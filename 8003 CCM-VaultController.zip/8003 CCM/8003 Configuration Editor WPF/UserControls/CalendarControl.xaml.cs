﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Pacom.Core.Contracts;

namespace Pacom.ConfigurationEditor.WPF.UserControls
{
    public class HolidayItem : IEditableObject, INotifyPropertyChanged
    {
        public ObservableCollection<string> PeriodComboItems
        {
            get
            {
                ObservableCollection<string> allItems = new ObservableCollection<string>();
                foreach (Core.Access.RecurrenceType holidayPeriod in Enum.GetValues(typeof(Core.Access.RecurrenceType)))
                {
                    allItems.Add(Translation.GetTranslatedString(holidayPeriod, typeof(Core.Access.RecurrenceType)));
                }
                return allItems;
            }
        }

        public string HolidayDate { get; set; }

        private Core.Access.RecurrenceType period;
        public string HolidayPeriod
        {
            get
            {
                return Translation.GetTranslatedString(period, typeof(Core.Access.RecurrenceType));
            }
            set
            {
                foreach (Core.Access.RecurrenceType holidayPeriod in Enum.GetValues(typeof(Core.Access.RecurrenceType)))
                {
                    if (Translation.GetTranslatedString(holidayPeriod, typeof(Core.Access.RecurrenceType)) == value)
                    {
                        Period = holidayPeriod;
                        break;
                    }
                }
            }
        }

        public Core.Access.RecurrenceType Period
        {
            get
            {
                return period;
            }
            set
            {
                period = value;
                OnPropertyChanged(new PropertyChangedEventArgs("HolidayPeriod"));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        // Implements IEditableObject
        void IEditableObject.BeginEdit()
        {
        }

        void IEditableObject.CancelEdit()
        {
        }

        void IEditableObject.EndEdit()
        {
        }
    }

    /// <summary>
    /// Interaction logic for CalendarControl.xaml
    /// </summary>
    public partial class CalendarControl : UserControl
    {
        ObservableCollection<HolidayItem> collectionHoliday1 = new ObservableCollection<HolidayItem>();
        ObservableCollection<HolidayItem> collectionHoliday2 = new ObservableCollection<HolidayItem>();
        ObservableCollection<HolidayItem> collectionHoliday3 = new ObservableCollection<HolidayItem>();

        Border selectionBorder;

        Pacom.Core.Access.Calendar configurationItem { get; set; }
        public CalendarControl(Pacom.Core.Access.Calendar node)
        {
            InitializeComponent();

            labelHoliday1.Content = Translation.GetTranslatedString(DayType.Holiday1, typeof(DayType));
            labelHoliday2.Content = Translation.GetTranslatedString(DayType.Holiday2, typeof(DayType));
            labelHoliday3.Content = Translation.GetTranslatedString(DayType.Holiday3, typeof(DayType));

            dataGridHoliday1.Columns[0].Header = Translation.GetTranslatedMisc("Date");
            dataGridHoliday1.Columns[1].Header = Translation.GetTranslatedMisc("Recurrence");
            dataGridHoliday1.Columns[2].Header = Translation.GetTranslatedMisc("Delete");

            dataGridHoliday2.Columns[0].Header = Translation.GetTranslatedMisc("Date");
            dataGridHoliday2.Columns[1].Header = Translation.GetTranslatedMisc("Recurrence");
            dataGridHoliday2.Columns[2].Header = Translation.GetTranslatedMisc("Delete");

            dataGridHoliday3.Columns[0].Header = Translation.GetTranslatedMisc("Date");
            dataGridHoliday3.Columns[1].Header = Translation.GetTranslatedMisc("Recurrence");
            dataGridHoliday3.Columns[2].Header = Translation.GetTranslatedMisc("Delete");

            dataGridHoliday1.DataContext = collectionHoliday1;
            dataGridHoliday2.DataContext = collectionHoliday2;
            dataGridHoliday3.DataContext = collectionHoliday3;

            comboBoxPeriod.Items.Add(new ComboBoxItemContents(Translation.GetTranslatedString(Core.Access.RecurrenceType.Annually, typeof(Core.Access.RecurrenceType)), Core.Access.RecurrenceType.Annually));
            comboBoxPeriod.Items.Add(new ComboBoxItemContents(Translation.GetTranslatedString(Core.Access.RecurrenceType.Monthly, typeof(Core.Access.RecurrenceType)), Core.Access.RecurrenceType.Monthly));
            comboBoxPeriod.Items.Add(new ComboBoxItemContents(Translation.GetTranslatedString(Core.Access.RecurrenceType.OneOff, typeof(Core.Access.RecurrenceType)), Core.Access.RecurrenceType.OneOff));

            configurationItem = node;
            if (configurationItem.DayTypes != null)
            {
                for (int i = 0; i < node.DayTypes.Length; i++)
                {
                    string date = node.DayTypes[i].Date.ToString("dd/MM/yyyy");
                    switch (node.DayTypes[i].DayType)
                    {
                        case DayType.Holiday1:
                            collectionHoliday1.Add(new HolidayItem { HolidayDate = date, Period = node.DayTypes[i].Recurrence });
                            break;
                        case DayType.Holiday2:
                            collectionHoliday2.Add(new HolidayItem { HolidayDate = date, Period = node.DayTypes[i].Recurrence });
                            break;
                        case DayType.Holiday3:
                            collectionHoliday3.Add(new HolidayItem { HolidayDate = date, Period = node.DayTypes[i].Recurrence });
                            break;
                    }
                }
            }

            radioButton1.Visibility = Visibility.Hidden;
            radioButton2.Visibility = Visibility.Hidden;
            radioButton3.Visibility = Visibility.Hidden;

            selectionBorder = new Border();
            selectionBorder.BorderBrush = Brushes.Black;
            selectionBorder.BorderThickness = new Thickness(2);
            selectionBorder.SetValue(Grid.RowProperty, 0);
            selectionBorder.SetValue(Grid.ColumnProperty, 0);
            selectionBorder.SetValue(Grid.ColumnSpanProperty, 2);
            Holiday1Grid.Children.Add(selectionBorder);
        }

        private void Calendar_SelectedDatesChanged(object sender, SelectionChangedEventArgs e)
        {
            Calendar calendarControl = (Calendar)sender;
            if (calendarControl.SelectedDate.HasValue)
            {
                string selectedDate = calendarControl.SelectedDate.Value.ToString("dd/MM/yyyy");

                if (radioButton1.IsChecked == true)
                {
                    removeHoliday(collectionHoliday1, selectedDate);
                    collectionHoliday1.Add(new HolidayItem { HolidayDate = selectedDate, Period = (Core.Access.RecurrenceType)((ComboBoxItemContents)comboBoxPeriod.SelectedItem).Value });
                    saveCalendar();
                }
                else if (radioButton2.IsChecked == true)
                {
                    removeHoliday(collectionHoliday2, selectedDate);
                    collectionHoliday2.Add(new HolidayItem { HolidayDate = selectedDate, Period = (Core.Access.RecurrenceType)((ComboBoxItemContents)comboBoxPeriod.SelectedItem).Value });
                    saveCalendar();
                }
                else
                {
                    removeHoliday(collectionHoliday3, selectedDate);
                    collectionHoliday3.Add(new HolidayItem { HolidayDate = selectedDate, Period = (Core.Access.RecurrenceType)((ComboBoxItemContents)comboBoxPeriod.SelectedItem).Value });
                    saveCalendar();
                }
            }
            calendarControl.SelectedDate = null;
        }

        private void saveCalendar()
        {
            if (configurationItem != null)
            {
                App.ConfigurationModified = true;
                configurationItem.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                configurationItem.DayTypes = new Core.Access.CalendarRecord[collectionHoliday1.Count + collectionHoliday2.Count + collectionHoliday3.Count];
                for (int i = 0; i < configurationItem.DayTypes.Length; i++)
                {
                    configurationItem.DayTypes[i] = new Core.Access.CalendarRecord
                    { DayType = DayType.Holiday1, Recurrence = Core.Access.RecurrenceType.Annually, Date = DateTime.Now };
                }
                int indexOffset = -1;
                for (int i = 0; i < collectionHoliday1.Count; i++)
                {
                    indexOffset++;
                    configurationItem.DayTypes[i].DayType = DayType.Holiday1;
                    configurationItem.DayTypes[i].Recurrence = collectionHoliday1[i].Period;
                    int year = Convert.ToInt16(collectionHoliday1[i].HolidayDate.Substring(6, 4));
                    int month = Convert.ToInt16(collectionHoliday1[i].HolidayDate.Substring(3, 2));
                    int day = Convert.ToInt16(collectionHoliday1[i].HolidayDate.Substring(0, 2));
                    configurationItem.DayTypes[i].Date = new DateTime(year, month, day);
                }

                for (int i = 0; i < collectionHoliday2.Count; i++)
                {
                    indexOffset++;
                    configurationItem.DayTypes[indexOffset].DayType = DayType.Holiday2;
                    configurationItem.DayTypes[indexOffset].Recurrence = collectionHoliday2[i].Period;
                    int year = Convert.ToInt16(collectionHoliday2[i].HolidayDate.Substring(6, 4));
                    int month = Convert.ToInt16(collectionHoliday2[i].HolidayDate.Substring(3, 2));
                    int day = Convert.ToInt16(collectionHoliday2[i].HolidayDate.Substring(0, 2));
                    configurationItem.DayTypes[indexOffset].Date = new DateTime(year, month, day);
                }

                for (int i = 0; i < collectionHoliday3.Count; i++)
                {
                    indexOffset++;
                    configurationItem.DayTypes[indexOffset].DayType = DayType.Holiday3;
                    configurationItem.DayTypes[indexOffset].Recurrence = collectionHoliday3[i].Period;
                    int year = Convert.ToInt16(collectionHoliday3[i].HolidayDate.Substring(6, 4));
                    int month = Convert.ToInt16(collectionHoliday3[i].HolidayDate.Substring(3, 2));
                    int day = Convert.ToInt16(collectionHoliday3[i].HolidayDate.Substring(0, 2));
                    configurationItem.DayTypes[indexOffset].Date = new DateTime(year, month, day);
                }
            }
        }

        private static void removeHoliday(ObservableCollection<HolidayItem> collection, string date)
        {
            HolidayItem itemToRemove = null;
            foreach (HolidayItem item in collection)
            {
                if (item.HolidayDate.Equals(date))
                {
                    itemToRemove = item;
                    break;
                }
            }
            if (itemToRemove != null)
                collection.Remove(itemToRemove);
        }

        private void radioButton1_Checked(object sender, RoutedEventArgs e)
        {
            if (radioButton2 == null)
                return;

            Holiday2Grid.Children.Remove(selectionBorder);
            Holiday3Grid.Children.Remove(selectionBorder);
            Holiday1Grid.Children.Add(selectionBorder);

            radioButton2.Checked -= radioButton2_Checked;
            radioButton3.Checked -= radioButton3_Checked;
            radioButton2.IsChecked = false;
            radioButton3.IsChecked = false;
            radioButton2.Checked += radioButton2_Checked;
            radioButton3.Checked += radioButton3_Checked;

        }

        private void radioButton2_Checked(object sender, RoutedEventArgs e)
        {
            Holiday1Grid.Children.Remove(selectionBorder);
            Holiday3Grid.Children.Remove(selectionBorder);
            Holiday2Grid.Children.Add(selectionBorder);

            radioButton1.Checked -= radioButton1_Checked;
            radioButton3.Checked -= radioButton3_Checked;
            radioButton1.IsChecked = false;
            radioButton3.IsChecked = false;
            radioButton1.Checked += radioButton1_Checked;
            radioButton3.Checked += radioButton3_Checked;
        }

        private void radioButton3_Checked(object sender, RoutedEventArgs e)
        {
            Holiday1Grid.Children.Remove(selectionBorder);
            Holiday2Grid.Children.Remove(selectionBorder);
            Holiday3Grid.Children.Add(selectionBorder);

            radioButton1.Checked -= radioButton1_Checked;
            radioButton2.Checked -= radioButton2_Checked;
            radioButton1.IsChecked = false;
            radioButton2.IsChecked = false;
            radioButton1.Checked += radioButton1_Checked;
            radioButton2.Checked += radioButton2_Checked;
        }

        private void dataGridHoliday1_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            radioButton1.IsChecked = true;
        }

        private void dataGridHoliday2_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            radioButton2.IsChecked = true;
        }

        private void dataGridHoliday3_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            radioButton3.IsChecked = true;
        }

        private void OnDelete_Holiday1(object sender, RoutedEventArgs e)
        {
            collectionHoliday1.RemoveAt(dataGridHoliday1.SelectedIndex);
            saveCalendar();
        }

        private void OnDelete_Holiday2(object sender, RoutedEventArgs e)
        {
            collectionHoliday2.RemoveAt(dataGridHoliday2.SelectedIndex);
            saveCalendar();
        }

        private void OnDelete_Holiday3(object sender, RoutedEventArgs e)
        {
            collectionHoliday3.RemoveAt(dataGridHoliday3.SelectedIndex);
            saveCalendar();
        }

        private void HolidayPeriod_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            saveCalendar();
        }

        private void DatePicker_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            base.OnPreviewMouseUp(e);
            if (Mouse.Captured is Calendar || Mouse.Captured is System.Windows.Controls.Primitives.CalendarItem)
            {
                Mouse.Capture(null);
            }
        }
    }
}
