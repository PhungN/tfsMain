﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.UserControls
{
    public class AccessGroupWrapper
    {
        public AccessGroup AccessGroup { get; private set; }
        public AccessGroupWrapper(AccessGroup accessGroup)
        {
            AccessGroup = accessGroup;
        }

        public override string ToString()
        {
            return Translation.GetTranslatedNodeTreeItem("AccessGroup") + ":" + AccessGroup.Id;
        }
    }

    public class UserPermissionItem : IEditableObject, INotifyPropertyChanged
    {
        public event EventHandler ConfigurationChanged;

        public static ObservableCollection<AccessGroupWrapper> AccessGroupItems
        {
            get;
            set;
        }

        private AccessGroupWrapper accessGroup;
        public AccessGroupWrapper AccessGroup
        {
            get { return accessGroup; }
            set { accessGroup = value; ConfigurationChanged(this, new EventArgs()); }
        }

        public void SetAccessGroup(AccessGroupWrapper accessGroup)
        {
            this.accessGroup = accessGroup;
            OnPropertyChanged(new PropertyChangedEventArgs("AccessGroup"));
        }

        private DateTime validFrom;
        public DateTime ValidFrom
        {
            get { return validFrom; }
            set
            {
                validFrom = new DateTime(value.Year, value.Month, value.Day, 0, 0, 0);
                ConfigurationChanged(this, new EventArgs());
            }
        }

        public string FormattedValidFrom
        {
            get
            {
                return ValidFrom.ToShortDateString();
            }
        }

        public void SetValidFrom(DateTime date)
        {
            validFrom = date;
            OnPropertyChanged(new PropertyChangedEventArgs("ValidFrom"));
        }

        private DateTime validTo;
        public DateTime ValidTo
        {
            get { return validTo; }
            set
            {
                validTo = new DateTime(value.Year, value.Month, value.Day, 23, 59, 59);
                ConfigurationChanged(this, new EventArgs());
            }
        }

        public string FormattedValidTo
        {
            get
            {
                return ValidTo.ToShortDateString();
            }
        }

        public void SetValidTo(DateTime date)
        {
            validTo = date;
            OnPropertyChanged(new PropertyChangedEventArgs("ValidTo"));
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        // Implements IEditableObject
        void IEditableObject.BeginEdit()
        {
        }

        void IEditableObject.CancelEdit()
        {
        }

        void IEditableObject.EndEdit()
        {
        }
    }

    /// <summary>
    /// Interaction logic for UnisonUserPermissionControl.xaml
    /// </summary>
    public partial class UnisonUserPermissionControl : UserControl
    {
        ObservableCollection<UserPermissionItem> collectionPermissions = new ObservableCollection<UserPermissionItem>();
        ObservableCollection<AccessGroupWrapper> allAccessGroups = new ObservableCollection<AccessGroupWrapper>();

        User configurationItem { get; set; }
        public UnisonUserPermissionControl(User node)
        {
            InitializeComponent();

            dataGridPermissions.Columns[0].Header = Translation.GetTranslatedNodeTreeItem("AccessGroup");
            dataGridPermissions.Columns[1].Header = Translation.GetTranslatedNodeTreeItem("ValidFrom");
            dataGridPermissions.Columns[2].Header = Translation.GetTranslatedNodeTreeItem("ValidTo");
            dataGridPermissions.Columns[3].Header = Translation.GetTranslatedMisc("Delete");

            addButton.Content = Translation.GetTranslatedMisc("AddAccessGroup");

            dataGridPermissions.DataContext = collectionPermissions;

            configurationItem = node;

            UserPermissionItem.AccessGroupItems = allAccessGroups;
            foreach (AccessGroup accessGroup in ConfigurationManager.UnisonAccessGroups.Values)
            {
                allAccessGroups.Add(new AccessGroupWrapper(accessGroup));
            }

            if (node.AccessGroups == null)
                node.AccessGroups = new UserAccess[0];
            for (int i = 0; i < node.AccessGroups.Length; i++)
            {
                UserPermissionItem permissionItem = new UserPermissionItem();
                foreach (AccessGroupWrapper possibleAccessGroup in allAccessGroups)
                {
                    if (possibleAccessGroup.AccessGroup.Id == node.AccessGroups[i].AccessGroupId)
                    {
                        permissionItem.SetAccessGroup(possibleAccessGroup);
                        break;
                    }
                }
                if (node.AccessGroups[i].StartDateTime.HasValue)
                    permissionItem.SetValidFrom(node.AccessGroups[i].StartDateTime.Value);
                else
                    permissionItem.SetValidFrom(new DateTime(1753, 1, 1));

                if (node.AccessGroups[i].EndDateTime.HasValue)
                    permissionItem.SetValidTo(node.AccessGroups[i].EndDateTime.Value);
                else
                    permissionItem.SetValidTo(new DateTime(9999, 12, 31, 23, 59, 59));
                permissionItem.ConfigurationChanged += PermissionItem_ConfigurationChanged;
                collectionPermissions.Add(permissionItem);
            }
        }

        private void saveUserPermissions()
        {
            if (configurationItem != null)
            {
                App.ConfigurationModified = true;
                configurationItem.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                List<UserAccess> accessGroups = new List<UserAccess>();
                for (int i = 0; i < collectionPermissions.Count; i++)
                {
                    if (collectionPermissions[i].AccessGroup != null)
                    {
                        UserAccess userAccess = new UserAccess();
                        userAccess.AccessGroupId = collectionPermissions[i].AccessGroup.AccessGroup.Id;
                        userAccess.StartDateTime = collectionPermissions[i].ValidFrom;
                        userAccess.EndDateTime = collectionPermissions[i].ValidTo;
                        accessGroups.Add(userAccess);
                    }
                }
                configurationItem.AccessGroups = accessGroups.ToArray();
            }
        }

        private void OnDelete_Permission(object sender, RoutedEventArgs e)
        {
            UserPermissionItem permissionItem = collectionPermissions[dataGridPermissions.SelectedIndex];
            permissionItem.PropertyChanged -= PermissionItem_ConfigurationChanged;
            collectionPermissions.Remove(permissionItem);
            saveUserPermissions();
        }

        private void PermissionItem_ConfigurationChanged(object sender, EventArgs e)
        {
            saveUserPermissions();
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            UserPermissionItem permissionItem = new UserPermissionItem();
            if (UserPermissionItem.AccessGroupItems.Count > 0)
            {
                permissionItem.SetAccessGroup(UserPermissionItem.AccessGroupItems[0]);

                // If there is more then 1 access group, select the first access group that doesn't already have permissions applied.
                if (UserPermissionItem.AccessGroupItems.Count > 1)
                {
                    for (int i = 0; i < UserPermissionItem.AccessGroupItems.Count; i++)
                    {
                        bool match = false;
                        foreach (UserPermissionItem collectionPermission in collectionPermissions)
                        {
                            if (collectionPermission.AccessGroup == UserPermissionItem.AccessGroupItems[i])
                            {
                                match = true;
                                break;
                            }
                        }
                        if (match == false)
                        {
                            permissionItem.SetAccessGroup(UserPermissionItem.AccessGroupItems[i]);
                            break;
                        }
                    }
                }
            }
            permissionItem.SetValidFrom(new DateTime(1753, 1, 1));
            permissionItem.SetValidTo(new DateTime(9999, 12, 31, 23, 59, 59));
            permissionItem.ConfigurationChanged += PermissionItem_ConfigurationChanged;
            collectionPermissions.Add(permissionItem);

            saveUserPermissions();
        }
    }
}
