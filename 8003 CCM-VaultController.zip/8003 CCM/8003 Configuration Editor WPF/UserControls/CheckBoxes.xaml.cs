﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pacom.ConfigurationEditor.WPF.UserControls
{
    /// <summary>
    /// Interaction logic for CheckBoxes.xaml
    /// </summary>
    public partial class CheckBoxes : UserControl
    {
        public CheckBoxes()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        public int Count
        {
            get { return (int)GetValue(CountProperty); }
            set { SetValue(CountProperty, value); }
        }
        public int Data
        {
            get { return (int)GetValue(DataProperty); }
            set { SetValue(DataProperty, value); }
        }

        public static readonly DependencyProperty CountProperty = DependencyProperty.Register("Count", typeof(int), typeof(CheckBoxes), new FrameworkPropertyMetadata(OnCountChanged));
        public static readonly DependencyProperty DataProperty = DependencyProperty.Register("Data", typeof(int), typeof(CheckBoxes), new FrameworkPropertyMetadata(OnDataChanged));

        private static void OnCountChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CheckBoxes cb = d as CheckBoxes;
            if (cb != null)
            {
                cb.Count = (int)e.NewValue;
                cb.UpdateCheckBoxes();
            }
        }

        private static void OnDataChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CheckBoxes cb = d as CheckBoxes;
            if (cb != null)
            {
                cb.Data = (int)e.NewValue;
                cb.UpdateCheckBoxes(cb.Data);
            }
        }

        public void UpdateCheckBoxes()
        {
            checkboxesGrid.Children.Clear();
            checkboxesGrid.Rows = 1;
            checkboxesGrid.Columns = Count;
            for (int column = 0; column < Count; column++)
            {
                CheckBox checkBox = new CheckBox() { Content = $"{column + 1}" };
                checkBox.Margin = new Thickness(1, 0, 1, 1);
                checkBox.VerticalAlignment = VerticalAlignment.Center;
                checkBox.Checked += CheckBox_Checked;
                checkBox.Unchecked += CheckBox_Unchecked;
                checkboxesGrid.Children.Add(checkBox);
            }

        }

        public void UpdateCheckBoxes(int data)
        {
            for (int column = 0; column < Count; column++)
            {
                if ((data & 1) == 1 == true)
                    Data |= (1 << column);
                else
                    Data &= ~(1 << column);
                CheckBox checkBox = checkboxesGrid.Children[column] as CheckBox;
                if(checkBox != null)
                    checkBox.IsChecked = (data & 1) == 1;
                data >>= 1;
            }
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            if (checkBox != null)
            {
                updataData(int.Parse(checkBox.Content as string) - 1, false);
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            if (checkBox != null)
            {
                updataData(int.Parse(checkBox.Content as string) - 1, true);
            }
        }

        private void updataData(int id, bool state)
        {
            if (state == true)
                Data |= (1 << id);
            else
                Data &= ~(1 << id);
            OnDataChanged();          
        }

        public class DataChangedEventArgs : RoutedEventArgs
        {
            private readonly int data;
            public DataChangedEventArgs(int data)
            {
                this.data = data;
            }
            public int Data { get { return data; } }
        }
        public delegate void DataChangedEventHandler(object sender, DataChangedEventArgs e);
        public static readonly RoutedEvent DataChangedEvent = EventManager.RegisterRoutedEvent("DataChanged", RoutingStrategy.Bubble, typeof(DataChangedEventHandler), typeof(CheckBoxes));
        public event DataChangedEventHandler DataChanged
        {
            add
            {
                AddHandler(DataChangedEvent, value);
            }
            remove
            {
                RemoveHandler(DataChangedEvent, value);
            }
        }
        private void OnDataChanged()
        {
            DataChangedEventArgs args = new DataChangedEventArgs(Data);
            args.RoutedEvent = DataChangedEvent;
            RaiseEvent(args);
        }
    }
}
