﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Pacom.ConfigurationEditor.WPF.Model
{
    public class CustomCheckBox : CheckBox
    {
        public CustomCheckBox()
        {
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            if (IsChecked.Value)
            {
                Border slider = Template.FindName("slider", this) as Border;
                if (slider != null)
                {
                    TransformGroup transformGroup = new TransformGroup();
                    transformGroup.Children.Add(new ScaleTransform(1, 1));
                    transformGroup.Children.Add(new SkewTransform(0, 0));
                    transformGroup.Children.Add(new RotateTransform(0));
                    transformGroup.Children.Add(new TranslateTransform(53, 0));

                    slider.RenderTransform = transformGroup;
                    slider.UpdateLayout();
                }
            }
        }
    }
}