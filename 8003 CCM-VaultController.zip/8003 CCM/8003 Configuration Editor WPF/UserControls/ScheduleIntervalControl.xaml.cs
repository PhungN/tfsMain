﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Xml;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;

namespace Pacom.ConfigurationEditor.WPF.UserControls
{
    public class IntervalItem
    {
        public DateTime StartDate { get; set; }
        public int Level { get; set; }
    }

    /// <summary>
    /// Interaction logic for ScheduleInterval.xaml
    /// </summary>
    public partial class ScheduleIntervalControl : UserControl, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChange(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public event EventHandler<EventArgs> ScheduleIntervalChanged;

        private int selectionStartColumn;
        private Reader8003ScheduleLevel selectionLeftProfile;
        private Reader8003ScheduleLevel selectionRightProfile;
        int selectionLeftProfileStart = 0;
        int selectionRightProfileEnd = 0;

        //bitDefinitionMap is max 1440 size (i.e. 1 minute resolution).
        //displayable window is defined by gridViewLeftBoundary and gridViewRightBoundary and maps to the scheduleIntervalGrid which is 144 columns
        //For zoom 1 then displayable window is 0 to 1439 (24 hours) and gridViewLeftBoundary=0; gridViewRightBoundary=1439, with each column representing 10 minutes.
        //For zoom 2 the displayable window is 720 (12 hours) and gridViewLeftBoundary=LLL; gridViewRightBoundary=RRR where RRR-LLL is 720, with each column representing 5 minutes.
        //For zoom 3 the displayable window is 144 (2 hours 24 minute) and gridViewLeftBoundary=LLL; gridViewRightBoundary=RRR where RRR-LLL is 144, with each column representing 1 minute.
        private const int bitDefinitionMapLength = 1440;
        private SortedDictionary<int, Reader8003ScheduleLevel> bitDefinitionMap = new SortedDictionary<int, Reader8003ScheduleLevel>();
        private SortedDictionary<int, Reader8003ScheduleLevel> dragBitTypeMap = new SortedDictionary<int, Reader8003ScheduleLevel>();

        private int gridViewLeftBoundary = 0;
        private int gridViewRightBoundary = 1439;

        private Brush defaultBrush = new BrushConverter().ConvertFromString("#FFDDDDDD") as SolidColorBrush;
        private Brush buttonEnabledBrush = Brushes.GreenYellow;

        //Most zoomed out is 1 , 3 is the most zoomed in
        private int zoomLevel = 1;

        //Disabled = 0, Enabled = 1 (Egress and Card)
        //CardOnly = 0, Unlocked = 1, Blocked = 2, CardAndPin = 3, PinOrCard = 4 (Reader)
        //Armed = 0, Disarmed = 1 (Area)
        private Dictionary<Reader8003ScheduleLevel, Brush> bitColorMap = new Dictionary<Reader8003ScheduleLevel, Brush>()
        {
            { Reader8003ScheduleLevel.CardOnly, Brushes.DarkSeaGreen},      //0
            { Reader8003ScheduleLevel.Unlocked, Brushes.PaleVioletRed},     //1
            { Reader8003ScheduleLevel.Blocked, Brushes.Coral },             //2
            { Reader8003ScheduleLevel.CardAndPin, Brushes.LightSkyBlue },   //3
        };

        //labels
        private Label[] timeLabels;
        private Label[] zoomLevel1Labels;
        private Label[] zoomLevel2Labels;
        private Label[] zoomLevel3Labels;

        public ScheduleRecord ConfigurationItem
        {
            get;
            set;
        }

        private Reader8003ScheduleLevel selectedScheduleLevel;
        public Reader8003ScheduleLevel SelectedScheduleLevel
        {
            get
            {
                return selectedScheduleLevel;
            }
            set
            {
                selectedScheduleLevel = value;
                buttonSetAll.Background = bitColorMap[selectedScheduleLevel];
            }
        }

        public DayType DayType { get; set; }

        public ScheduleIntervalControl()
        {
            InitializeComponent();

            timeLabels = new Label[] { label_time_0, label_time_1, label_time_2, label_time_3, label_time_4, label_time_5, label_time_6, label_time_7, label_time_8, label_time_9, label_time_10, label_time_11, label_time_12, label_time_13, label_time_14 };

            zoomLevel1Labels = new Label[] { label_Z1_Marker_0, label_Z1_Marker_1, label_Z1_Marker_2, label_Z1_Marker_3, label_Z1_Marker_4, label_Z1_Marker_5, label_Z1_Marker_6, label_Z1_Marker_7, label_Z1_Marker_8, label_Z1_Marker_9, label_Z1_Marker_10,
                                             label_Z1_Marker_11, label_Z1_Marker_12, label_Z1_Marker_13, label_Z1_Marker_14, label_Z1_Marker_15, label_Z1_Marker_16, label_Z1_Marker_17, label_Z1_Marker_18, label_Z1_Marker_19, label_Z1_Marker_20,
                                             label_Z1_Marker_21, label_Z1_Marker_22, label_Z1_Marker_23, label_Z1_Marker_24, label_Z1_Marker_25, label_Z1_Marker_26, label_Z1_Marker_27, label_Z1_Marker_28, label_Z1_Marker_29, label_Z1_Marker_30,
                                             label_Z1_Marker_31, label_Z1_Marker_32, label_Z1_Marker_33, label_Z1_Marker_34, label_Z1_Marker_35, label_Z1_Marker_36, label_Z1_Marker_37, label_Z1_Marker_38, label_Z1_Marker_39, label_Z1_Marker_40,
                                             label_Z1_Marker_41, label_Z1_Marker_42, label_Z1_Marker_43, label_Z1_Marker_44, label_Z1_Marker_45, label_Z1_Marker_46, label_Z1_Marker_47, label_Z1_Marker_48, label_Z1_Marker_49, label_Z1_Marker_50,
                                             label_Z1_Marker_51, label_Z1_Marker_52, label_Z1_Marker_53, label_Z1_Marker_54, label_Z1_Marker_55, label_Z1_Marker_56, label_Z1_Marker_57, label_Z1_Marker_58, label_Z1_Marker_59, label_Z1_Marker_60,
                                             label_Z1_Marker_61, label_Z1_Marker_62, label_Z1_Marker_63, label_Z1_Marker_64, label_Z1_Marker_65, label_Z1_Marker_66, label_Z1_Marker_67, label_Z1_Marker_68, label_Z1_Marker_69, label_Z1_Marker_70,
                                             label_Z1_Marker_71, label_Z1_Marker_72 };

            zoomLevel2Labels = new Label[] { label_Z2_Marker_0, label_Z2_Marker_1, label_Z2_Marker_2, label_Z2_Marker_3, label_Z2_Marker_4, label_Z2_Marker_5, label_Z2_Marker_6, label_Z2_Marker_7, label_Z2_Marker_8, label_Z2_Marker_9, label_Z2_Marker_10,
                                             label_Z2_Marker_11, label_Z2_Marker_12, label_Z2_Marker_13, label_Z2_Marker_14, label_Z2_Marker_15, label_Z2_Marker_16, label_Z2_Marker_17, label_Z2_Marker_18, label_Z2_Marker_19, label_Z2_Marker_20,
                                             label_Z2_Marker_21, label_Z2_Marker_22, label_Z2_Marker_23, label_Z2_Marker_24, label_Z2_Marker_25, label_Z2_Marker_26, label_Z2_Marker_27, label_Z2_Marker_28, label_Z2_Marker_29, label_Z2_Marker_30,
                                             label_Z2_Marker_31, label_Z2_Marker_32, label_Z2_Marker_33, label_Z2_Marker_34, label_Z2_Marker_35, label_Z2_Marker_36, label_Z2_Marker_37, label_Z2_Marker_38, label_Z2_Marker_39, label_Z2_Marker_40,
                                             label_Z2_Marker_41, label_Z2_Marker_42, label_Z2_Marker_43, label_Z2_Marker_44, label_Z2_Marker_45, label_Z2_Marker_46, label_Z2_Marker_47, label_Z2_Marker_48};

            zoomLevel3Labels = new Label[] { label_Z3_Marker_0, label_Z3_Marker_1, label_Z3_Marker_2, label_Z3_Marker_3, label_Z3_Marker_4, label_Z3_Marker_5, label_Z3_Marker_6, label_Z3_Marker_7, label_Z3_Marker_8, label_Z3_Marker_9, label_Z3_Marker_10,
                                             label_Z3_Marker_11, label_Z3_Marker_12, label_Z3_Marker_13, label_Z3_Marker_14, label_Z3_Marker_15, label_Z3_Marker_16, label_Z3_Marker_17, label_Z3_Marker_18, label_Z3_Marker_19, label_Z3_Marker_20, label_Z3_Marker_21,
                                             label_Z3_Marker_22, label_Z3_Marker_23, label_Z3_Marker_24, label_Z3_Marker_25, label_Z3_Marker_26, label_Z3_Marker_27, label_Z3_Marker_28};
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            labelIntervalName.Content = Translation.GetTranslatedScheduleRecord(DayType);

            for (int i = 0; i < bitDefinitionMapLength; i++)
                bitDefinitionMap[i] = Reader8003ScheduleLevel.CardOnly;

            if (ConfigurationItem != null)
            {
                foreach (ScheduleInterval scheduleInterval in ConfigurationItem.Intervals)
                {
                    int startIndex = (scheduleInterval.StartTime.Hour * 60) + scheduleInterval.StartTime.Minute;
                    for (int i = startIndex; i < bitDefinitionMap.Count; i++)
                    {
                        bitDefinitionMap[i] = (Reader8003ScheduleLevel)scheduleInterval.Level;
                    }
                }
            }

            UpdateLabels();
            RedrawControl(bitDefinitionMap);

            SetNavigationButtons();

            buttonSetAll.Content = Translation.GetTranslatedMisc("__24h__");
            buttonLeft.ToolTip = Translation.GetTranslatedMisc("ClickToScrollLeft");
            buttonRight.ToolTip = Translation.GetTranslatedMisc("ClickToScrollRight");

            Loaded -= UserControl_Loaded;
        }

        private static void copyDictionary(SortedDictionary<int, Reader8003ScheduleLevel> source, SortedDictionary<int, Reader8003ScheduleLevel> destination)
        {
            destination.Clear();
            foreach (KeyValuePair<int, Reader8003ScheduleLevel> kvp in source)
            {
                destination[kvp.Key] = kvp.Value;
            }
        }

        private void displayIntervalResizeCursor(Point position, int column)
        {
            bool resize = false;
            int virtualIndex = GetColumnVirtualLocation(position, column);
            if (virtualIndex >= 0 && virtualIndex < bitDefinitionMap.Count)
            {
                Reader8003ScheduleLevel mouseLocationProfile = bitDefinitionMap[virtualIndex];
                for (int i = 0; i < GetZoomIncrement() + 1; i++)
                {
                    int leftIndex = virtualIndex - i;
                    if (leftIndex < 0)
                        leftIndex = 0;
                    selectionLeftProfile = bitDefinitionMap[leftIndex];

                    if (selectionLeftProfile != mouseLocationProfile)
                    {
                        resize = true;
                        selectionStartColumn = leftIndex;
                        selectionRightProfile = mouseLocationProfile;
                        break;
                    }

                    int rightIndex = virtualIndex + i;
                    if (rightIndex > (bitDefinitionMap.Count - 1))
                        rightIndex = bitDefinitionMap.Count - 1;
                    if (rightIndex == 0)
                        continue;
                    selectionRightProfile = bitDefinitionMap[rightIndex];

                    if (selectionRightProfile != mouseLocationProfile)
                    {
                        resize = true;
                        selectionStartColumn = rightIndex - 1;
                        selectionLeftProfile = mouseLocationProfile;
                        break;
                    }
                }
            }
            if (resize)
            {
                Cursor = Cursors.SizeWE;

                int temp;
                GetRangeIndices(selectionLeftProfile, selectionStartColumn, out selectionLeftProfileStart, out temp);
                GetRangeIndices(selectionRightProfile, selectionStartColumn, out temp, out selectionRightProfileEnd);
            }
            else
            {
                Cursor = Cursors.Cross;
                selectionStartColumn = virtualIndex;
            }
        }

        private void scheduleIntervalGrid_MouseEnter(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Cross;
            this.scheduleIntervalGrid.PreviewMouseMove += scheduleIntervalGrid_PreviewMouseMove;
        }

        private void scheduleIntervalGrid_MouseLeave(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Arrow;
            this.scheduleIntervalGrid.PreviewMouseMove -= scheduleIntervalGrid_PreviewMouseMove;
            floatingTip.IsOpen = false;
        }

        private static int GetColumnIndex(Point position, DataGrid grid)
        {
            int columnIndex = 0;
            double accumulatedWidth = 0.0;

            // calc col mouse was over
            foreach (DataGridColumn columnDefinition in grid.Columns)
            {
                accumulatedWidth += columnDefinition.ActualWidth;
                if (accumulatedWidth > position.X)
                    break;

                columnIndex++;
            }
            return columnIndex;
        }

        private void scheduleIntervalGrid_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount != 1)
                return;

            scheduleIntervalGrid.PreviewMouseMove += scheduleIntervalGrid_PreviewMouseMove;
        }

        private void GetRangeIndices(Reader8003ScheduleLevel clickedProfile, int id, out int startIndex, out int endIndex)
        {
            startIndex = id;
            while (true)
            {
                if (startIndex == 0)
                    break;
                startIndex--;
                if (bitDefinitionMap[startIndex] != clickedProfile)
                {
                    startIndex++;
                    break;
                }
            }

            endIndex = id;
            while (true)
            {
                if (endIndex == (bitDefinitionMap.Count - 1))
                    break;
                endIndex++;
                if (bitDefinitionMap[endIndex] != clickedProfile)
                {
                    endIndex--;
                    break;
                }
            }
        }

        private void scheduleIntervalGrid_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            int startIndex;
            int endIndex;
            Point position = e.GetPosition(scheduleIntervalGrid);
            int currentColumn = GetColumnIndex(position, scheduleIntervalGrid);
            if (e.LeftButton != MouseButtonState.Pressed)
            {
                //tooltip and interval resize
                displayIntervalResizeCursor(position, currentColumn);

                Reader8003ScheduleLevel profile;
                int virtualIndex = GetColumnVirtualLocation(position, currentColumn);
                if (bitDefinitionMap.TryGetValue(virtualIndex, out profile) == true)
                {
                    GetRangeIndices(profile, virtualIndex, out startIndex, out endIndex);
                    DrawToolTip(startIndex, endIndex, position, profile);
                }
                else
                {
                    floatingTip.IsOpen = false;
                }
                return;
            }

            //button is pressed and mouse moving
            copyDictionary(bitDefinitionMap, dragBitTypeMap);

            int currentSelectedColumn = GetColumnVirtualLocation(position, currentColumn);

            if (currentSelectedColumn >= bitDefinitionMap.Count)
            {
                //dragged to right over the edge
                currentSelectedColumn = bitDefinitionMap.Count - 1;
                if (zoomLevel > 1 && gridViewRightBoundary < (bitDefinitionMap.Count - 1))
                {
                    AdjustGridViewRight();
                    UpdateLabels();
                }
            }

            if (position.X <= -1)
            {
                //dragged to left over the edge
                currentSelectedColumn = 0;
                if (zoomLevel > 1 && gridViewLeftBoundary > 0)
                {
                    AdjustGridViewLeft();
                    UpdateLabels();
                }
            }

            Reader8003ScheduleLevel scheduleLevel;
            if (Cursor == Cursors.SizeWE)
            {
                // Resize selection
                if (currentSelectedColumn < selectionStartColumn)
                {
                    scheduleLevel = selectionRightProfile;
                    startIndex = currentSelectedColumn;
                    endIndex = selectionRightProfileEnd;
                }
                else
                {
                    scheduleLevel = selectionLeftProfile;
                    startIndex = selectionLeftProfileStart;
                    endIndex = currentSelectedColumn;
                }
            }
            else
            {
                // New range
                scheduleLevel = selectedScheduleLevel;

                startIndex = selectionStartColumn;
                endIndex = currentSelectedColumn;

                if (selectionStartColumn > currentSelectedColumn)
                {
                    startIndex = currentSelectedColumn;
                    endIndex = selectionStartColumn;
                }
            }

            for (int i = startIndex; i <= endIndex; i++)
            {
                dragBitTypeMap[i] = scheduleLevel;
            }

            if (Cursor == Cursors.SizeWE)
            {
                scheduleLevel = selectionLeftProfile;
                startIndex = selectionLeftProfileStart;
                endIndex = currentSelectedColumn;
            }

            DrawToolTip(startIndex, endIndex, position, scheduleLevel);
            RedrawControl(dragBitTypeMap);
        }

        private int GetColumnVirtualLocation(Point position, int actualLocation)
        {
            int result = 0;
            switch (zoomLevel)
            {
                case 1:
                    result = actualLocation * 10; //10 minute chunks
                    result += (int)(position.X % 10);
                    break;
                case 2:
                    result = gridViewLeftBoundary + (actualLocation * 5); //5 minute chunks
                    result += (int)(position.X % 5);
                    break;
                case 3:
                    result = (actualLocation + gridViewLeftBoundary); //1 minute chunks
                    break;
            }
            return result;
        }

        private void scheduleIntervalGrid_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            this.scheduleIntervalGrid.PreviewMouseMove -= scheduleIntervalGrid_PreviewMouseMove;

            if (dragBitTypeMap.Count > 0)
                copyDictionary(dragBitTypeMap, bitDefinitionMap);

            UpdateConfigurationItem();

            dragBitTypeMap.Clear();
            floatingTip.IsOpen = false;
        }

        private void DrawToolTip(int startIndex, int endIndex, Point position, Reader8003ScheduleLevel ctrlName)
        {
            if (!floatingTip.IsOpen) { floatingTip.IsOpen = true; }
            TextBlock txt = floatingTip.Child as TextBlock;
            int totalMinutes = startIndex;
            int startHour = totalMinutes / 60;
            int startMinutes = totalMinutes - (startHour * 60);
            totalMinutes = endIndex + 1;
            int endHour = totalMinutes / 60;
            int endMinutes = totalMinutes - (endHour * 60);
            txt.Text = string.Format("{0}:{1} - {2}:{3}", startHour.ToString("00"), startMinutes.ToString("00"), endHour.ToString("00"), endMinutes.ToString("00"));
            Brush brush;
            bitColorMap.TryGetValue(ctrlName, out brush);
            txt.Foreground = brush;
            txt.Background = Brushes.White;
            floatingTip.HorizontalOffset = position.X + 40;
            floatingTip.VerticalOffset = position.Y - 20;
        }

        private void RedrawControl(SortedDictionary<int, Reader8003ScheduleLevel> dataSource)
        {
            int gridColumnIndex = -1;
            Reader8003ScheduleLevel profile;
            int increment = GetZoomIncrement();
            for (int i = gridViewLeftBoundary; i <= gridViewRightBoundary; i += increment)
            {
                switch (zoomLevel)
                {
                    case 1:
                    case 2:
                    {
                        gridColumnIndex = (i - gridViewLeftBoundary) / increment;

                        if (gridColumnIndex > 143)
                            gridColumnIndex = 143;
                        break;
                    }
                    case 3:
                    {
                        gridColumnIndex++;
                        break;
                    }
                }
                profile = dataSource[i];
                scheduleIntervalGrid.Columns[gridColumnIndex].HeaderStyle = GetStyle(profile);
            }
        }

        private static Dictionary<Reader8003ScheduleLevel, Style> styleDictionary = new Dictionary<Reader8003ScheduleLevel, Style>();
        private Style GetStyle(Reader8003ScheduleLevel profile)
        {
            Style style;
            if (styleDictionary.TryGetValue(profile, out style))
                return style;

            style = new Style(typeof(System.Windows.Controls.Primitives.DataGridColumnHeader));
            Brush brush;
            bitColorMap.TryGetValue(profile, out brush);
            style.Setters.Add(new Setter
            {
                Property = BackgroundProperty,
                Value = brush,
            });

            style.Setters.Add(new Setter(BorderThicknessProperty, new Thickness(0, 0, 0, 0)));
            style.Setters.Add(new Setter
            {
                Property = BorderBrushProperty,
                Value = brush,
            });

            styleDictionary[profile] = style;
            return style;
        }

        private void UpdateConfigurationItem()
        {
            ScheduleIntervalChanged(this, new EventArgs());
            ConfigurationItem.Intervals = null;

            Reader8003ScheduleLevel startProfile = 0;
            Reader8003ScheduleLevel profile;
            List<IntervalItem> intervalList = new List<IntervalItem>();
            for (int i = 0; i < bitDefinitionMap.Count; i++)
            {
                bitDefinitionMap.TryGetValue(i, out profile);
                if (startProfile != profile)
                {
                    startProfile = profile;
                    int level = (int)profile;
                    IntervalItem interval = new IntervalItem { StartDate = DateTime.Now, Level = 0 };
                    interval.Level = level;
                    int totalMinutes = i;
                    int startHour = totalMinutes / 60;
                    int startMinutes = totalMinutes - (startHour * 60);
                    interval.StartDate = new DateTime(interval.StartDate.Year, interval.StartDate.Month, interval.StartDate.Day, startHour, startMinutes, 0);
                    intervalList.Add(interval);
                }
            }

            ConfigurationItem.Intervals = new ScheduleInterval[intervalList.Count];
            for (int i = 0; i < intervalList.Count; i++)
            {
                ConfigurationItem.Intervals[i] = new ScheduleInterval { Level = intervalList[i].Level, StartTime = intervalList[i].StartDate };
            }
        }

        private void buttonSetAll_Click(object sender, RoutedEventArgs e)
        {
            bitDefinitionMap.Clear();

            for (int i = 0; i < bitDefinitionMapLength; i++)
                bitDefinitionMap.Add(i, selectedScheduleLevel);

            zoomLevel = 1;
            SetNewZoom(0, 1);
            UpdateConfigurationItem();
        }

        //time increment for each column in different zoom settings
        private int GetZoomIncrement()
        {
            int increment = 1;
            switch (zoomLevel)
            {
                case 1:
                    increment = 10;
                    break;
                case 2:
                    increment = 5;
                    break;
                case 3:
                    increment = 1;
                    break;
            }
            return increment;
        }

        private void AdjustGridViewRight()
        {
            int zoomIncrement = GetZoomIncrement();
            gridViewRightBoundary += zoomIncrement;
            gridViewLeftBoundary += zoomIncrement;
            if (gridViewRightBoundary > 1439)    //minutes in one day - 1
            {
                gridViewRightBoundary = 1439;
                switch (zoomLevel)
                {
                    case 1:
                        gridViewLeftBoundary = 0;
                        break;
                    case 2:
                        gridViewLeftBoundary = gridViewRightBoundary - 719;
                        break;
                    case 3:
                        gridViewLeftBoundary = gridViewRightBoundary - 143;
                        break;
                }
            }

            //keep nearest to the increment boundary
            gridViewLeftBoundary = gridViewLeftBoundary - (gridViewLeftBoundary % zoomIncrement);
            SetNavigationButtons();
        }

        private void AdjustGridViewLeft()
        {
            int zoomIncrement = GetZoomIncrement();
            gridViewRightBoundary -= zoomIncrement;
            gridViewLeftBoundary -= zoomIncrement;
            if (gridViewLeftBoundary < 0)
            {
                gridViewLeftBoundary = 0;
                switch (zoomLevel)
                {
                    case 1:
                        gridViewRightBoundary = 1439;
                        break;
                    case 2:
                        gridViewRightBoundary = 719;
                        break;
                    case 3:
                        gridViewRightBoundary = 143;
                        break;
                }
            }

            //keep nearest to the increment boundary
            gridViewLeftBoundary = gridViewLeftBoundary - (gridViewLeftBoundary % zoomIncrement);
            SetNavigationButtons();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (buttonLeft.IsPressed || sender == buttonLeft)
                AdjustGridViewLeft();
            else if (buttonRight.IsPressed || sender == buttonRight)     // Condition is required to stop an additional move on mouse up
                AdjustGridViewRight();
            UpdateLabels();
            RedrawControl(bitDefinitionMap);
        }

        int ticks = 0;
        bool scrolling = false;
        private void button_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            scrolling = false;
            ticks = Environment.TickCount;
            ((Button)sender).PreviewMouseMove += button_PreviewMouseMove;
        }

        private void button_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Pressed)
                return;

            if (scrolling == false)
            {
                if ((Environment.TickCount - ticks) > 400)
                {
                    ticks = Environment.TickCount;
                    scrolling = true;
                    button_Click(sender, new RoutedEventArgs());
                }
            }
            else
            {
                if ((Environment.TickCount - ticks) > 10)
                {
                    ticks = Environment.TickCount;
                    button_Click(sender, new RoutedEventArgs());
                }
            }

            scheduleIntervalGrid.Dispatcher.BeginInvoke(new Action(() => button_PreviewMouseMove(this, new MouseEventArgs(e.MouseDevice, 0))), System.Windows.Threading.DispatcherPriority.Background);
        }

        private void button_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            buttonLeft.PreviewMouseMove -= button_PreviewMouseMove;
        }

        private void scheduleIntervalGrid_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            int oldZoomIndex = zoomLevel;
            int newZoomIndex = zoomLevel;
            //clockwise increment is + 120 (zoom in), anti-clockwise is -120 (zoom out)
            int absValue = Math.Abs(e.Delta);
            if (absValue >= 120)
            {
                if (e.Delta > 0)
                {
                    //zoom in
                    newZoomIndex++;
                    if (newZoomIndex > 3)
                        newZoomIndex = 3;
                }
                else
                {
                    newZoomIndex--;
                    if (newZoomIndex < 1)
                        newZoomIndex = 1;
                }

                if (newZoomIndex != oldZoomIndex)
                {
                    Point position = e.GetPosition(scheduleIntervalGrid);
                    //get column where zoom is in progress
                    int col = GetColumnIndex(position, scheduleIntervalGrid);
                    SetNewZoom(col, newZoomIndex);
                }
            }
        }

        private void SetNewZoom(int column, int newZoomIndex)
        {
            int virtuaIndex = 0;
            switch (newZoomIndex)
            {
                case 1:
                    gridViewLeftBoundary = 0;
                    gridViewRightBoundary = 1439;
                    foreach (Label label in zoomLevel2Labels)
                        label.Visibility = Visibility.Hidden;
                    foreach (Label label in zoomLevel3Labels)
                        label.Visibility = Visibility.Hidden;
                    break;
                case 2:
                    virtuaIndex = GetColumnVirtualLocation(new Point(0,0), column);
                    if (virtuaIndex >= 1080)
                    {
                        gridViewLeftBoundary = 720;
                        gridViewRightBoundary = 1439;
                    }
                    else
                    {
                        gridViewLeftBoundary = virtuaIndex - 360;
                        if (gridViewLeftBoundary < 0) gridViewLeftBoundary = 0;
                        gridViewRightBoundary = gridViewLeftBoundary + 719;
                    }

                    foreach (Label label in zoomLevel1Labels)
                        label.Visibility = Visibility.Hidden;
                    foreach (Label label in zoomLevel3Labels)
                        label.Visibility = Visibility.Hidden;
                    break;
                case 3:
                    virtuaIndex = GetColumnVirtualLocation(new Point(0, 0), column);
                    if (virtuaIndex >= 1296)
                    {
                        gridViewLeftBoundary = 1296;
                        gridViewRightBoundary = 1439;
                    }
                    else
                    {
                        gridViewLeftBoundary = virtuaIndex - 72;
                        if (gridViewLeftBoundary < 0) gridViewLeftBoundary = 0;
                        gridViewRightBoundary = gridViewLeftBoundary + 143;
                    }

                    foreach (Label label in zoomLevel1Labels)
                        label.Visibility = Visibility.Hidden;
                    foreach (Label label in zoomLevel2Labels)
                        label.Visibility = Visibility.Hidden;
                    break;
            }

            zoomLevel = newZoomIndex;
            
            //keep nearest to the increment boundary
            gridViewLeftBoundary = gridViewLeftBoundary - (gridViewLeftBoundary % GetZoomIncrement());

            SetNavigationButtons();

            UpdateLabels();
            RedrawControl(bitDefinitionMap);
        }

        private void SetNavigationButtons()
        {
            if (gridViewLeftBoundary == 0)
            {
                buttonLeft.IsEnabled = false;
                buttonLeft.Background = defaultBrush;
                buttonLeft.Foreground = Brushes.DarkGray;
            }
            else
            {
                buttonLeft.IsEnabled = true;
                buttonLeft.Background = buttonEnabledBrush;
                buttonLeft.Foreground = Brushes.Black;
            }

            if (gridViewRightBoundary == 1439)
            {
                buttonRight.IsEnabled = false;
                buttonRight.Background = defaultBrush;
                buttonRight.Foreground = Brushes.DarkGray;
            }
            else
            {
                buttonRight.IsEnabled = true;
                buttonRight.Background = buttonEnabledBrush;
                buttonRight.Foreground = Brushes.Black;
            }
        }

        private Dictionary<int, string[]> labelTimeMap = new Dictionary<int, string[]>()
        {
            // each column separated 10 pix, 12 columns between two labels, each column has different time value under zoom 1 (10 min), 2 (5 min) and 3 (1 min)
            { 1, new string[] { "00:00", "02:00", "04:00", "06:00", "08:00", "10:00", "12:00", "14:00", "16:00", "18:00", "20:00", "22:00", "24:00" } },            // 10 min per column
            { 2, new string[] { "00:00", "01:00", "02:00", "03:00", "04:00", "05:00", "06:00", "07:00", "08:00", "09:00", "10:00", "11:00", "12:00", "13:00",       // 5 min per column
                                "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00", "23:00", "24:00"  }},
            { 3, new string[] { "00:00", "00:10", "00:20", "00:30", "00:40", "00:50", "01:00", "01:10", "01:20", "01:30", "01:40", "01:50", "02:00", "02:10",       // 1 min per column
                                "02:20", "02:30", "02:40", "02:50", "03:00", "03:10", "03:20", "03:30", "03:40", "03:50", "04:00", "04:10", "04:20", "04:30",
                                "04:40", "04:50", "05:00", "05:10", "05:20", "05:30", "05:40", "05:50", "06:00", "06:10", "06:20", "06:30", "06:40", "06:50",
                                "07:00", "07:10", "07:20", "07:30", "07:40", "07:50", "08:00", "08:10", "08:20", "08:30", "08:40", "08:50", "09:00", "09:10",
                                "09:20", "09:30", "09:40", "09:50", "10:00", "10:10", "10:20", "10:30", "10:40", "10:50", "11:00", "11:10", "11:20", "11:30",
                                "11:40", "11:50", "12:00", "12:10", "12:20", "12:30", "12:40", "12:50", "13:00", "13:10", "13:20", "13:30", "13:40", "13:50",
                                "14:00", "14:10", "14:20", "14:30", "14:40", "14:50", "15:00", "15:10", "15:20", "15:30", "15:40", "15:50", "16:00", "16:10",
                                "16:20", "16:30", "16:40", "16:50", "17:00", "17:10", "17:20", "17:30", "17:40", "17:50", "18:00", "18:10", "18:20", "18:30",
                                "18:40", "18:50", "19:00", "19:10", "19:20", "19:30", "19:40", "19:50", "20:00", "20:10", "20:20", "20:30", "20:40", "20:50",
                                "21:00", "21:10", "21:20", "21:30", "21:40", "21:50", "22:00", "22:10", "22:20", "22:30", "22:40", "22:50", "23:00", "23:10",
                                "23:20", "23:30", "23:40", "23:50", "24:00" }}
        };

        private int FindFirstTimeLabelLocation(int boundaryMinutes)
        {
            int offset = 0;
            string[] labels = null;
            labelTimeMap.TryGetValue(zoomLevel, out labels);
            if (labels != null)
            {
                //work out where the labels start
                int i = 0;
                int labelMinutes = 0;
                foreach (string lbl in labels)
                {
                    labelMinutes = ((Convert.ToInt16(lbl.Substring(0, 2)) * 60) + (Convert.ToInt16(lbl.Substring(3, 2))));
                    if (labelMinutes >= boundaryMinutes)
                    {
                        offset = labelMinutes - boundaryMinutes;
                        break;
                    }

                    i++;
                }
            }
            return offset;
        }

        private void UpdateLabels()
        {
            int timeLabelSpan = 0;      //in minutes
            int markerLabelSpan = 0;    //in minutes
            int markerLeftMargin = (int)labelIntervalName.Width;  //start of label
            Label[] markers = null;
            switch (zoomLevel)
            {
                case 1:
                    markers = zoomLevel1Labels;
                    timeLabelSpan = 120;
                    markerLabelSpan = 20;
                    break;
                case 2:
                    markers = zoomLevel2Labels;
                    timeLabelSpan = 60;
                    markerLabelSpan = 15;
                    break;
                case 3:
                    markers = zoomLevel3Labels;
                    timeLabelSpan = 10;
                    markerLabelSpan = 5;
                    break;
            }

            int left = 0;
            int markerIndex = 0;
            int timeHeaderIndex = 0;

            int firstTimeLabel = FindFirstTimeLabelLocation(gridViewLeftBoundary);
            int marker = 0;
            while (((gridViewLeftBoundary + marker) % markerLabelSpan != 0) && (marker < markerLabelSpan))
                marker++;

            int firstMarkerLabel = marker;
            int columnTimeIncrement = GetZoomIncrement();
            //set time headings every timeLabelSpan minutes
            //set markers every 
            for (int i = 0; i < timeLabels.Length; i++)
                timeLabels[i].Visibility = Visibility.Hidden;

            for (int i = 0; i <= 144; i++)
            {
                //place marker
                if (((i * columnTimeIncrement) == firstMarkerLabel) || ((i * columnTimeIncrement) == ((markerIndex * markerLabelSpan) + firstMarkerLabel)))
                {
                    left = markerLeftMargin + (i * 10);   //10 pixels
                    if (zoomLevel == 1)
                        markers[markerIndex].Margin = new Thickness(left, markers[markerIndex].Margin.Top, markers[markerIndex].Margin.Right, markers[markerIndex].Margin.Bottom);
                    else
                        markers[markerIndex].Margin = new Thickness(left, 0, 0, 16);


                    markers[markerIndex].Visibility = Visibility.Visible;
                    markerIndex++;
                    if (markerIndex < markers.Length)
                        markers[markerIndex].Visibility = Visibility.Hidden;
                }

                //place time heading
                if (((i * columnTimeIncrement) == firstTimeLabel) || ((i * columnTimeIncrement) == ((timeHeaderIndex * timeLabelSpan) + firstTimeLabel)))
                {
                    //position the time heading
                    left = markerLeftMargin - 11 + (i * 10);   // pixels
                    timeLabels[timeHeaderIndex].Content = GetNextLabel(gridViewLeftBoundary + firstTimeLabel + (timeHeaderIndex * timeLabelSpan));
                    timeLabels[timeHeaderIndex].Margin = new Thickness(left, -8, 0, 0);
                    timeLabels[timeHeaderIndex].Visibility = Visibility.Visible;

                    //fix marker margin height if on the hour and raise mid marker
                    if (markerIndex > 0 && timeLabels[timeHeaderIndex].Content.ToString().Substring(3, 2) == "00")
                    {
                        int currentMarker = markerIndex - 1;
                        markers[currentMarker].Margin = new Thickness(markers[currentMarker].Margin.Left, -1, 0, 17);
                        int midMarkerIndex = timeLabelSpan / markerLabelSpan / 2;
                        if (currentMarker >= midMarkerIndex)
                            markers[currentMarker - midMarkerIndex].Margin = new Thickness(markers[currentMarker - midMarkerIndex].Margin.Left, 0, 0, 22);
                    }

                    timeHeaderIndex++;
                }
            }
        }

        private static string GetNextLabel(int minutes)
        {
            int boundaryHour = minutes / 60;
            int boundaryMinutes = minutes - (boundaryHour * 60);
            string time = string.Format("{0}:{1}", boundaryHour.ToString("00"), boundaryMinutes.ToString("00"));
            return time;
        }
    }
}
