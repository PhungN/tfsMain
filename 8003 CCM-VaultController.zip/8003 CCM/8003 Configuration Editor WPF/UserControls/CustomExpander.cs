﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Pacom.ConfigurationEditor.WPF.Model
{
    public class CustomExpander : Expander
    {
        public CustomExpander()
        {
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            if (IsExpanded)
            {
                ContentPresenter expandSite = Template.FindName("ExpandSite", this) as ContentPresenter;
                if (expandSite != null)
                {
                    expandSite.LayoutTransform = new ScaleTransform(1, 1);
                    expandSite.UpdateLayout();
                }
                ToggleButton header = Template.FindName("HeaderSite", this) as ToggleButton;
                if (header != null)
                {
                    header.ApplyTemplate();
                    Path arrow = findChild<Path>(header, "arrow");
                    arrow.RenderTransform = new RotateTransform(180, 0, 0);
                    arrow.UpdateLayout();
                }
            }
        }

        public static T findChild<T>(DependencyObject parent, string childName) where T : DependencyObject
        {
            // Confirm parent and childName are valid. 
            if (parent == null)
                return null;

            T foundChild = null;

            int childrenCount = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < childrenCount; i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(parent, i);
                // If the child is not of the request child type child
                T childType = child as T;
                if (childType == null)
                {
                    // Recursively drill down the tree
                    foundChild = findChild<T>(child, childName);

                    // If the child is found, break so we do not overwrite the found child. 
                    if (foundChild != null)
                        break;
                }
                else if (!string.IsNullOrEmpty(childName))
                {
                    FrameworkElement frameworkElement = child as FrameworkElement;
                    // If the child's name is set for search
                    if (frameworkElement == null || frameworkElement.Name != childName)
                        continue;

                    // If the child's name is of the request name
                    foundChild = (T)child;
                    break;
                }
                else
                {
                    // Child element found.
                    foundChild = (T)child;
                    break;
                }
            }

            return foundChild;
        }
    }
}