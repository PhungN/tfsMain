﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace Pacom.Common.CompactFramework.Helpers
{
    internal static class EnumHelper
    {
        /// <summary>
        /// Retrieves an array of the values of the constants in a specified enumeration.
        /// </summary>
        /// <param name="enumType">An enumeration type.</param>
        /// <returns>An System.Array of the values of the constants in enumType. The elements of the array are sorted by the values of the enumeration constants.</returns>
        /// <exception cref="System.ArgumentException">enumType parameter is not an System.Enum</exception>
        /// <seealso cref="M:System.Enum.GetValues(System.Type)">System.Enum.GetValues Method</seealso>
        public static Enum[] GetValues(Type enumType)
        {
            if (enumType.BaseType == Type.GetType("System.Enum"))
            {
                //get the public static fields (members of the enum)
                System.Reflection.FieldInfo[] fi = enumType.GetFields(BindingFlags.Static | BindingFlags.Public);

                //create a new enum array
                System.Enum[] values = new System.Enum[fi.Length];

                //populate with the values
                for (int iEnum = 0; iEnum < fi.Length; iEnum++)
                {
                    values[iEnum] = (System.Enum)fi[iEnum].GetValue(null);
                }

                //return the array
                return values;
            }
            else
            {
                //the type supplied does not derive from enum
                throw new ArgumentException("enumType parameter is not an System.Enum");
            }
        }
    }
}
