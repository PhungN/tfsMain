﻿using Microsoft.Win32;
using System.Net;

namespace Pacom.ConfigurationEditor.WPF
{
    public static class Settings
    {
        const string keyName = @"HKEY_CURRENT_USER\Software\Pacom Systems\CCM";

        public static string Language
        {
            get
            {
                return (string)Registry.GetValue(keyName, "Language", null);
            }
            set
            {
                Registry.SetValue(keyName, "Language", value);
            }
        }
#if DEBUG
        public static IPAddress ControllerIPAddress
        {
            get
            {
                try
                {
                    string address = (string)Registry.GetValue(keyName, "ControllerIPAddress", null);
                    return IPAddress.Parse(address); // if address is not set (null), will throw exception and go to the catch
                }
                catch
                {
                    return IPAddress.Parse("10.1.1.1");
                }
            }
            set
            {
                string address = value.ToString();
                Registry.SetValue(keyName, "ControllerIPAddress", address);
            }

        }
#endif
    }
}
