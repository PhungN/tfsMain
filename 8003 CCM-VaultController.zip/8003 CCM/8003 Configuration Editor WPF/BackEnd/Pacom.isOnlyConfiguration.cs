﻿using Pacom.Core.Contracts;

namespace Pacom.ConfigurationEditor.WPF
{
    public class PacomSiteTemplatePortConfiguration : ConfigurationBase
    {
    }

    public class PacomSiteTemplateTimerConfiguration : ConfigurationBase
    {
    }

    public class Pacom8003SiteTemplateConfiguration : ConfigurationBase
    {
    }
}
