﻿using System;
using System.Diagnostics;
using System.Text;
using Pacom.Configuration.ConfigurationCommon;

public static class Logger
{
    public const string DateTimeFormat = "dd/MM/yy HH:mm:ss.fff";
    private const LoggingLevel loggingLevel = LoggingLevel.Debug;

    public static void LogMessage(LoggingLevel level, string message, params object[] parameters)
    {
        if ((int)level <= (int)loggingLevel)
        {
            Logger.LogMessage(level, String.Format(message, parameters));
        }
    }

    public static void LogMessage(LoggingLevel level, string message)
    {
        if ((int)level <= (int)loggingLevel)
        {
            StringBuilder sb = new StringBuilder(DateTimeFormat.Length + 2 + message.Length);
            sb.Append(DateTime.Now.ToString(DateTimeFormat));
            sb.Append(": ");
            sb.Append(message);
            Trace.WriteLine(sb.ToString());
        }
    }
}
