﻿namespace Pacom.ConfigurationEditor.WPF
{
    public static class UntranslatedStrings
    {
        public const string ControllerName = "Controller";
        public const string None = "None";
    }
}
