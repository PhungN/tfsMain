﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum ErrorMessage
    {
        Error,
        Warning,
        AddingNewNode,
        LoadingConfiguration,
        UnisonConfigurationFound,
        SavingConfiguration,
        ContiguousCardNumber,
        ContiguousFacilityCode,
        ContiguousIssue,
        LicenseCapacity,
        ImportingTemplate,
        ExportingTemplate,
        UnsavedConfiguration,
        SelectConfigurationToRemove,
        RemoveUnison,
        RemoveGms,
        Cancel,
        UnisonConfigurationWillBeRemoved,
        EnableChildNodes,
        DisableChildNodes,
    }
}
