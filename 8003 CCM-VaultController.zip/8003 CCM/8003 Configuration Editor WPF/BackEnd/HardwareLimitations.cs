﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common
{
    public static class HardwareLimitations
    {
        static Dictionary<Type, Dictionary<Type, int>> availableDevicePointLimit = new Dictionary<Type, Dictionary<Type, int>>();
        public static int GetAvailableDevicePointLimit(int parentId, Type childType)
        {
            // Find the parent device type
            Type parentDeviceType = null;
            if (parentId == ConfigurationManager.ControllerConfiguration.Id)
            {
                parentDeviceType = typeof(Device8003Configuration);
            }
            else
            {
                DeviceConfigurationBase device = null;
                ExpansionCardDeviceConfigurationBase expansionCard = null;

                if (ConfigurationManager.Devices.TryGetValue(parentId, out device) && device.Enabled)
                {
                    parentDeviceType = device.GetType();
                }
                else if (ConfigurationManager.ExpansionCards.TryGetValue(parentId, out expansionCard) && expansionCard.Enabled)
                {
                    parentDeviceType = expansionCard.GetType();
                }
            }

            if (parentDeviceType == null)
                return 0;

            if (parentDeviceType == typeof(Device1065IOConfiguration))
            {
                if (childType == typeof(Input8003Configuration))
                {
                    int numberOfOutputs = 0;
                    foreach (var output in ConfigurationManager.Outputs.Values)
                    {
                        if (output.ParentDeviceId == parentId)
                            numberOfOutputs++;
                    }
                    if (numberOfOutputs > 12)
                        return 16;
                    else if (numberOfOutputs > 4)
                        return 32;
                    return 48;
                }
                else if (childType == typeof(Output8003Configuration))
                {
                    int numberOfInputs = 0;
                    foreach (var input in ConfigurationManager.Inputs.Values)
                    {
                        if (input.ParentDeviceId == parentId)
                            numberOfInputs++;
                    }
                    if (numberOfInputs > 32)
                        return 4;
                    else if (numberOfInputs > 16)
                        return 12;
                    return 20;
                }
            }
            // Use reflection to find the number of available points on the device
            int limit;
            Dictionary<Type, int> devicePointLimitForDevice = null;
            if (availableDevicePointLimit.TryGetValue(parentDeviceType, out devicePointLimitForDevice))
            {
                if (devicePointLimitForDevice.TryGetValue(childType, out limit))
                    return limit;
            }
            limit = -1;
            List <object> customAttributes = parentDeviceType.GetCustomAttributes(false).ToList();
            foreach (object customAttribute in customAttributes)
            {
                MaximumNodesAttribute maximumNodesAttribute = customAttribute as MaximumNodesAttribute;
                if (maximumNodesAttribute != null)
                {
                    if (maximumNodesAttribute.NodeType == childType)
                        limit = maximumNodesAttribute.Maximum;
                }
            }
            if (limit == -1)
            {
                foreach (object customAttribute in customAttributes)
                {
                    MaximumNodesAttribute maximumNodesAttribute = customAttribute as MaximumNodesAttribute;
                    if (maximumNodesAttribute != null)
                    {
                        if (maximumNodesAttribute.NodeType == childType.BaseType || maximumNodesAttribute.NodeType.BaseType == childType)
                            limit = maximumNodesAttribute.Maximum;
                    }
                }
            }
            if (limit == -1)
                limit = 0;
            if (availableDevicePointLimit.ContainsKey(parentDeviceType) == false)
                availableDevicePointLimit[parentDeviceType] = new Dictionary<Type, int>();
            availableDevicePointLimit[parentDeviceType][childType] = limit;

            return limit;
        }
    }
}