﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using Microsoft.VisualBasic.FileIO;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;

namespace Pacom.ConfigurationEditor.WPF
{
    public static class Translation
    {
        /// <summary>
        /// Languages available
        /// </summary>
        /// <remark>
        /// The order they are here is how they will appear in the Language menu
        /// </remark>
        static public Language[] Languages =
           {
            new Language("en", "English", "_English", "en", "English"),
            new Language("es", "Spanish", "E_spañol", "es-ES", "Spanish"),
            new Language("fr", "French", "_Français", "fr-FR", "French")
           };

        static public Language CurrentLanguage { get; private set; }
        static public Language FallbackLanguage { get; private set; }

#if DEBUG
        // These are for tracking missing UI translation items, that aren't found by reflecting upon
        // configuration types.

        /// <summary>
        /// The language that MissingCcmItems is for
        /// </summary>
        static private string missingCcmLanguage = "";

        /// <summary>
        /// Accumulated Ccm_ items that failed to translate
        /// </summary>
        static public HashSet<string> MissingCcmItems = new HashSet<string>();
#endif

        /// <summary>
        /// Prefix added to keypad translations, for the internal translation lookups
        /// </summary>
        private const string keypadLanguageStringPrefix = "KeypadLanguageString_";

        /// <summary>
        /// Use the OS's regional setting to determine the language to use.  If nothing matches, use English
        /// </summary>
        static public Language RecommendedLanguage
        {
            get
            {
                CultureInfo ci = CultureInfo.CurrentCulture;
                Language lang = GetLanguage(ci.Name); // name could be something like "en", "fr" or "fr-FR"
                if (lang != null)
                {
                    return lang;
                }

                // For regions like "en-AU", the parent will be just "en", so do a lookup on that
                if (ci.Parent != null)
                {
                    lang = GetLanguage(ci.Parent.Name);
                    if (lang != null)
                    {
                        return lang;
                    }
                }

                // default to english
                return GetLanguage("en");
            }
        }

        /// <summary>
        /// Get a language from its two-letter code
        /// </summary>
        /// <param name="code">Two-letter language code</param>
        static public Language GetLanguage(string code)
        {
            return Array.Find(Languages, language => language.Code == code);
        }

        /// <summary>
        /// Set the main and fallback languages to use for future translations
        /// </summary>
        /// <param name="main">Preferred language</param>
        /// <param name="fallback">Fallback language, can be null</param>
        static public void SetLanguage(Language main, Language fallback)
        {
            CurrentLanguage = main;
            FallbackLanguage = fallback;

#if DEBUG
            // For tracking of failed CCM UI translations
            if (main.Code != missingCcmLanguage)
            {
                // Language change, reset the list of missing Ccm items
                MissingCcmItems.Clear();
                missingCcmLanguage = main.Code;
            }
#endif
        }

        /// <summary>
        /// Set the language for future translations
        /// </summary>
        /// <param name="main">Language to use</param>
        /// <param name="fallbackToEnglish">true to use English if the main language doesn't have a translation</param>
        static public void SetLanguage(Language main, bool fallbackToEnglish = true)
        {
            if (fallbackToEnglish && main.Code != "en")
            {
                SetLanguage(main, GetLanguage("en"));
            }
            else
            {
                SetLanguage(main, null);
            }
        }

        /// <summary>
        /// Load an embedded resource translation CSV file
        /// </summary>
        /// <param name="resourceName">Name of the embedded resource that is a CSV file of translations</param>
        /// <param name="entryPrefix">Optional prefix to put on all translation keys</param>
        private static void load(string resourceName, string entryPrefix = "")
        {
            // Row format: MessageKey,Category,lang1,lang2,...langN
            // Language "langN" code in header is used to determine which Language to store the translation in
            
            try
            {
                using (Stream ms = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
                {
                    System.Text.Encoding wind1252 = System.Text.Encoding.GetEncoding(1252);
                    using (TextFieldParser parser = new TextFieldParser(ms, wind1252))
                    {
                        parser.TextFieldType = FieldType.Delimited;
                        parser.SetDelimiters(",");
                        parser.TrimWhiteSpace = false;
                        parser.HasFieldsEnclosedInQuotes = true;
                        bool header = true;
                        int[] columnForLanguage = new int[Languages.Length]; // From examining the header, which column the n'th language is in
                        while (parser.EndOfData == false)
                        {
                            string[] fields = parser.ReadFields();
                            if (header == true)
                            {
                                // Header row.  Look at the language codes and find the corresponding Language
                                for (int i = 0; i < fields.Length; i++)
                                {
                                    string code = fields[i];
                                    if (string.IsNullOrEmpty(code))
                                    {
                                        continue;
                                    }
                                    for (int j = 0; j < Languages.Length; j++)
                                    {
                                        if (code == Languages[j].ColumnName || code == Languages[j].KeypadColumnName)
                                        {
                                            columnForLanguage[j] = i;
                                        }
                                    }
                                }
                                header = false;
                            }
                            else
                            {
                                // Translation row.  Pick out each Language's translation
                                for (int j = 0; j < Languages.Length; j++)
                                {
                                    int col = columnForLanguage[j];
                                    if (col != 0 && col < fields.Length)
                                    {
                                        string translation = fields[col];
                                        if (string.IsNullOrEmpty(translation) == false)
                                        {
                                            Languages[j].Translations[entryPrefix + fields[0]] = translation;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
            }
        }

        static Translation()
        {
            // Load translations from embedded resources.  Loaded in order of increasing priority.
            load("Pacom.ConfigurationEditor.WPF.EmbeddedResources.ResourceMessage.csv");
            load("Pacom.ConfigurationEditor.WPF.EmbeddedResources.CcmMessage.csv");
            load("Pacom.ConfigurationEditor.WPF.EmbeddedResources.KeypadLanguageStrings.csv", keypadLanguageStringPrefix);

            Language language = null;
            string languageCode = Settings.Language;
            if (string.IsNullOrEmpty(languageCode))
            {
                // No user selection yet, use auto-detected language
                language = RecommendedLanguage;
            }
            else
            {
                // Follow user's preference
                language = GetLanguage(languageCode);
            }
            if (language == null)
            {
                // Unable to figure out a language to use, use the first one we have available
                language = Languages[0];
            }
            SetLanguage(language);
        }

        #region GetTranslatedXYZ functions
        public static string GetTranslatedTitle()
        {
            FileVersionInfo version = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);
            Version configurationAssemblyVersion = typeof(Device8003Configuration).Assembly.GetName().Version;
            return translateKey("Ccm_ApplicationTitle") + " V" + version.FileMajorPart + "." + version.FileMinorPart + " (" + configurationAssemblyVersion.Major + "." + configurationAssemblyVersion.Minor + "." + configurationAssemblyVersion.Build + ")";
        }

        internal static string GetTranslatedError(ErrorMessage errorMessage)
        {
            return translateKey("Ccm_ErrorMessage_" + errorMessage.ToString());
        }

        public static string GetTranslatedString(DisplayCategory category)
        {
            return translateKey("Ccm_DisplayCategory_" + category.ToString());
        }

        public static string GetTranslatedString(PropertyInfo propertyInfo)
        {
            string translation = translateKey("PacomObjectGeneric_Display_" + propertyInfo.Name, false);
            if (translation.StartsWith("PacomObjectGeneric_Display_") == false)
                return translation;

            translation = translateKey("SiteManager_DualReporting_ControllerConnection8003Entry_" + propertyInfo.Name);
            if (translation.StartsWith("SiteManager_DualReporting_ControllerConnection8003Entry_") == false)
                return translation;

            return "PacomObjectGeneric_Display_" + propertyInfo.Name;
        }

        public static string GetTranslatedString(string displayName)
        {
            string translation = translateKey("PacomObjectGeneric_Display_" + displayName, false);
            if (translation.StartsWith("PacomObjectGeneric_Display_") == false)
                return translation;
            return "PacomObjectGeneric_Display_" + displayName;
        }

        public static List<string> GetTranslatedEnum(Type enumType)
        {
            List<string> list = new List<string>();
            foreach (var item in Enum.GetValues(enumType))
            {
                string typeName = item.GetType().Name;
                string typeValue = Enum.GetName(item.GetType(), item);
                list.Add(translateKey($"PacomObjectGeneric_Enum_{typeName}_{typeValue}", false));
            }
            return list;
        }
        /// <summary>
        /// Some enums have a display type that is different to the type that contains translation.
        /// Check for both types.
        /// </summary>
        public static string GetTranslatedString(Enum value, Type alternateType)
        {
            string translation = translateKey("PacomObjectGeneric_Enum_" + value.GetType().Name + "_" + Enum.GetName(value.GetType(), value), false);
            if (translation.StartsWith("PacomObjectGeneric_Enum_") == false || alternateType.IsEnum == false)
                return translation;

            translation = translateKey("PacomObjectGeneric_Enum_" + alternateType.Name + "_" + Enum.GetName(alternateType, Convert.ToInt32(value)), false);
            if (translation.StartsWith("PacomObjectGeneric_Enum_") == false)
                return translation;

            translation = translateKey("SiteManager_DualReporting_" + alternateType.Name + "_" + Enum.GetName(alternateType, Convert.ToInt32(value)));
            if (translation.StartsWith("SiteManager_DualReporting_") == false)
                return translation;

            return "PacomObjectGeneric_Enum_" + alternateType.Name + "_" + Enum.GetName(alternateType, Convert.ToInt32(value));
        }

        public static string GetTranslatedString(Type type)
        {
            return translateKey("ObjectExplorerGeneral_" + type.Name.ToString());
        }

        public static string GetTranslatedMisc(string value)
        {
            return translateKey("Ccm_Misc_" + value);
        }

        public static string GetTranslatedMacroString(string value)
        {
            string translatedValue = translateKey("Ccm_Expression_" + value, false);
            if (translatedValue != "Ccm_Expression_" + value)
                return translatedValue;
            return translateKey("SiteManager_Expression_" + value);
        }

        public static string GetTranslatedMacroDataTypeString(string value)
        {
            return translateKey("Ccm_MacroDataType_" + value);
        }

        public static string GetTranslatedScheduleRecord(DayType scheduleRecordName)
        {
            return translateKey("Ccm_DayType_" + scheduleRecordName);
        }

        public static string GetTranslatedMenu(string menuName)
        {
            return translateKey("Ccm_Menu_" + menuName);
        }

        public static string GetTranslatedPortName(Pacom8003PhysicalPort port)
        {
            return translateKey("Ccm_Port_" + port.ToString() + "_Name");
        }

        public static string GetTranslatedPortShortName(Pacom8003PhysicalPort port)
        {
            return translateKey("Ccm_Short_Port_" + port.ToString() + "_Name");
        }

        public static string GetTranslatedAddButton(Type folderViewType)
        {
            return translateKey("Ccm_AddButton_" + folderViewType.Name.ToString());
        }

        public static string GetTranslatedText(string textId)
        {
            return translateKey("Ccm_Text_" + textId);
        }

        public static string GetTranslatedNodeTreeItem(string nodeTreeItem)
        {
            return translateKey("Ccm_NodeTreeItem_" + nodeTreeItem);
        }

        public static string GetTranslatedDefaultName(Type configurationItem)
        {
            return translateKey("Ccm_Default_" + configurationItem.Name.ToString() + "_Name");
        }

        public static string GetTranslatedNewDefaultName(Type configurationItem)
        {
            string translatedValue = translateKey("Ccm_New_Default_" + configurationItem.Name.ToString() + "_Name");
            if (translatedValue.StartsWith("Ccm_New_Default_") == false)
                return translatedValue;
            return GetTranslatedDefaultName(configurationItem);
        }

        public static string GetTranslatedKeypadString(string propertyName, string defaultIfNotFound)
        {
            string key = keypadLanguageStringPrefix + propertyName;
            string translated = translateKey(key);
            if (translated != key)
            {
                return translated;
            }
            else
            {
                return defaultIfNotFound;
            }
        }
#endregion

        /// <summary>
        /// Translate a key using the current language settings, in preference of selected language, fallback (if any), or returning the key itself
        /// </summary>
        /// <param name="key">key for item to translate</param>
        /// <returns>Translated text</returns>
        private static string translateKey(string key, bool trackFailure = true)
        {
            string value;
            if (CurrentLanguage.Translations.TryGetValue(key, out value))
            {
                return value; // primary language translation
            }
            if (FallbackLanguage != null && FallbackLanguage.Translations.TryGetValue(key, out value))
            {
                return value; // fallback language translation
            }
#if DEBUG
            // Track items we were unable to translate
            if (trackFailure && key.StartsWith("Ccm_"))
            {
                MissingCcmItems.Add(key);
            }
#endif
            return key; // Last resort, return the key
        }
    }
}
