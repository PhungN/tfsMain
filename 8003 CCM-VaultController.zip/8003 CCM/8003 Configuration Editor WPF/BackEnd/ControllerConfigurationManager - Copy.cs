﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.View;
using Pacom.Core.Access;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utils;
using Pacom.Serialization.Formatters.Asn1;

namespace Pacom.ConfigurationEditor.WPF
{
    public static class ControllerConfigurationManager
    {

        static ControllerConfigurationManager()
        {
            ControllerFirmwareSupportsEncryption = false;            
        }

        public static void LoadDefaults()
        {
            App.ConfigurationModified = false;
            ConfigurationManager.Clear();
            ControllerFirmwareSupportsEncryption = false;

            // Create 8003 controller configuration
            ConfigurationManager.ControllerConfiguration = new Device8003Configuration();
            ConfigurationManager.AutoConfigure(ConfigurationManager.ControllerConfiguration);
            ConfigurationManager.ControllerConfiguration.WebserverPassword = EncryptIfRequired(ConfigurationManager.ControllerConfiguration.WebserverPassword);

            // Set keypad message translations
            // For each item with a Category of KeypadLanguage in Device8003Configuration, replace with translated version
            foreach (PropertyInfo propertyInfo in typeof(Device8003Configuration).GetProperties(BindingFlags.Instance | BindingFlags.Public))
            {
                if (propertyInfo.CanRead == false || propertyInfo.CanWrite == false)
                    continue;

                CategoryAttribute attr = propertyInfo.GetCustomAttribute(typeof(CategoryAttribute)) as CategoryAttribute;
                if (attr == null || attr.CategoryName != "KeypadLanguage")
                    continue;

                string translated = Translation.GetTranslatedKeypadString(propertyInfo.Name, propertyInfo.GetValue(ConfigurationManager.ControllerConfiguration) as string);
                propertyInfo.SetValue(ConfigurationManager.ControllerConfiguration, translated);
            }

            // Create default area
            Area8003Configuration area = new Area8003Configuration();
            ConfigurationManager.AutoConfigure(area);
            area.Name = Translation.GetTranslatedDefaultName(typeof(Area8003Configuration));

            // Create controller Ethernet
            Port8003IPPortConfiguration ipPort = new Port8003IPPortConfiguration();
            ConfigurationManager.AutoConfigure(ipPort, ConfigurationManager.ControllerConfiguration.Id, Pacom8003PhysicalPort.Ethernet);
            ipPort.Name = Translation.GetTranslatedPortShortName(Pacom8003PhysicalPort.Ethernet);

            // Create controller RS485 ports
            Port8003RS485DeviceLoopPortConfiguration rs485Port = new Port8003RS485DeviceLoopPortConfiguration();
            ConfigurationManager.AutoConfigure(rs485Port, ConfigurationManager.ControllerConfiguration.Id, Pacom8003PhysicalPort.RS485, 0);
            rs485Port.Name = Translation.GetTranslatedPortShortName(Pacom8003PhysicalPort.RS485);

            // Create controller RS232 port
            Port8003RS232DebugPortConfiguration rs232Port = new Port8003RS232DebugPortConfiguration();
            ConfigurationManager.AutoConfigure(rs232Port, ConfigurationManager.ControllerConfiguration.Id, Pacom8003PhysicalPort.RS232);
            rs232Port.Name = Translation.GetTranslatedPortShortName(Pacom8003PhysicalPort.RS232);

            // Create default controller connection table
            ControllerConnection8003Table controllerConnectionTable1 = new ControllerConnection8003Table();
            ControllerConnection8003Table controllerConnectionTable2 = new ControllerConnection8003Table();
            ConfigurationManager.AutoConfigure(controllerConnectionTable1, 1, true);
            ConfigurationManager.AutoConfigure(controllerConnectionTable2, 2, false);
            controllerConnectionTable1.Password = EncryptIfRequired(controllerConnectionTable1.Password);
            controllerConnectionTable2.Password = EncryptIfRequired(controllerConnectionTable2.Password);

            // Create default Calendar Configuration
            Calendar calendar = new Calendar();
            calendar.SetDefaults();
            calendar.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            ConfigurationManager.Calendar = calendar;

            // Create default group
            Group8003Configuration group = new Group8003Configuration();
            ConfigurationManager.AutoConfigure(group);
            ConfigurationManager.Groups[group.Id] = group;

            // Create Default Admin User
            User8003Configuration userConfiguration = new User8003Configuration();
            ConfigurationManager.AutoConfigure(userConfiguration);
            ConfigurationManager.Users[userConfiguration.Id] = userConfiguration;

            // Create default vault controller
            //var vaultController = new VaultController8003Configuration();
            //vaultController.SetDefaults();
            //ConfigurationManager.VaultConfiguration = vaultController;

            MainWindow.Instance.Title = Translation.GetTranslatedTitle() + " - " + Translation.GetTranslatedMisc("Untitled");
            MenuView.Instance.SetTemplateStatusItem(false);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }

        public static bool ControllerFirmwareSupportsEncryption { get; set; }
        public static string EncryptIfRequired(string password)
        {
            if (string.IsNullOrEmpty(password))
                return string.Empty;

            if (password.StartsWith("enc:") && password.Length > 4)
            {
                try
                {
                    // Test if decrypt works otherwise encrypt
                    // This is triggered if a password is selected that starts with "enc:"
                    Decrypt(password.Substring(4));
                    ControllerFirmwareSupportsEncryption = true;
                    return password;
                }
                catch
                {
                }
            }

            if (ControllerFirmwareSupportsEncryption)
                return "enc:" + Encrypt(password);
            return password;
        }

        /// <summary>
        /// Encrypting a string with key { 0xA5, 0x04, 0x09, 0x20, 0x18, 0x20, 0x80, 0x03, 0x20, 0x86, 0x03, 0x20, 0x85, 0x01, 0x20, 0x5A }
        /// </summary>
        /// <param name="source"></param>
        /// <returns>encrypted base 64 string</returns>
        public static string Encrypt(string source)
        {
            byte[] encryptedData = null;
            using (Rijndael rijndael = Rijndael.Create())
            {
                rijndael.Padding = PaddingMode.Zeros;
                rijndael.Mode = CipherMode.CBC;
                var key = new byte[] { 0xA5, 0x04, 0x09, 0x20, 0x18, 0x20, 0x80, 0x03, 0x20, 0x86, 0x03, 0x20, 0x85, 0x01, 0x20, 0x5A };
                using (var cryptoTransform = rijndael.CreateEncryptor(key, new byte[16]))
                {
                    byte[] plainBytes = Encoding.ASCII.GetBytes(source);
                    encryptedData = cryptoTransform.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
                }
            }
            return encryptedData != null ? Convert.ToBase64String(encryptedData) : string.Empty;
        }

        /// <summary>
        /// Decrypt a base 64 string with key { 0xA5, 0x04, 0x09, 0x20, 0x18, 0x20, 0x80, 0x03, 0x20, 0x86, 0x03, 0x20, 0x85, 0x01, 0x20, 0x5A }
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static string Decrypt(string source)
        {
            byte[] decryptedData = null;
            if (string.IsNullOrEmpty(source) == false)
            {
                using (Rijndael rijndael = Rijndael.Create())
                {
                    rijndael.Padding = PaddingMode.None;
                    rijndael.Mode = CipherMode.CBC;
                    var key = new byte[] { 0xA5, 0x04, 0x09, 0x20, 0x18, 0x20, 0x80, 0x03, 0x20, 0x86, 0x03, 0x20, 0x85, 0x01, 0x20, 0x5A };
                    using (var cryptoTransform = rijndael.CreateDecryptor(key, new byte[16]))
                    {
                        byte[] encryptedData = Convert.FromBase64String(source);
                        decryptedData = cryptoTransform.TransformFinalBlock(encryptedData, 0, encryptedData.Length);
                    }
                }
            }
            return decryptedData != null ? Encoding.UTF8.GetString(decryptedData, 0, decryptedData.Length).TrimEnd('\0') : string.Empty;
        }

        public static HashTypeLookup GetListOfTypes()
        {
            HashTypeLookup lookup = new HashTypeLookup(new List<Assembly>() {
                                                             Assembly.Load("Pacom.Shared.Configuration"),
                                                             Assembly.Load("Pacom.Shared.Access")
                                                           });
            lookup.AddType(typeof(Schedule));
            lookup.AddType(typeof(AreaAccessPrivilege));
            lookup.AddType(typeof(Pacom8003SiteTemplateConfiguration));
            lookup.AddType(typeof(PacomSiteTemplatePortConfiguration));
            lookup.AddType(typeof(PacomSiteTemplateTimerConfiguration));
            return lookup;
        }

        public static bool LoadFromFile(string filePath)
        {
            App.ConfigurationModified = false;
            ConfigurationManager.Clear();
            ControllerFirmwareSupportsEncryption = false;

            StreamingContext context = new StreamingContext();
            ITypeLookup typesList = GetListOfTypes();


            Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(typesList, true, context);
            asn1Serializer.SerializeDefaultValues = true;
            int errorCount = 0;
            bool unisonConfigurationFound = false;
            bool gmsConfigurationFound = false;
            try
            {
                Dictionary<Type, PropertyInfo[]> reflectionDictionary = new Dictionary<Type, PropertyInfo[]>();
                using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
                {
                    while (fileStream.Position < fileStream.Length)
                    {
                        try
                        {
                            ConfigurationBase configurationItem = (ConfigurationBase)asn1Serializer.Deserialize(fileStream);
                            if (configurationItem == null || configurationItem.Id < 1)
                                continue;
                            System.Diagnostics.Debug.WriteLine($"--- configurationItem: {configurationItem}");
                            if (configurationItem is Pacom8003SiteTemplateConfiguration ||
                                configurationItem is PacomSiteTemplatePortConfiguration ||
                                configurationItem is PacomSiteTemplateTimerConfiguration)
                                continue;

                            Device8003Configuration controllerConfiguration = configurationItem as Device8003Configuration;
                            if (controllerConfiguration != null)
                            {
                                controllerConfiguration.WebserverPassword = EncryptIfRequired(controllerConfiguration.WebserverPassword);
                                ConfigurationManager.ControllerConfiguration = controllerConfiguration;
                                continue;
                            }

                            ControllerConnection8003Table controllerConnectionTable = configurationItem as ControllerConnection8003Table;
                            if (controllerConnectionTable != null)
                            {
                                ConfigurationManager.ControllerConnectionTables[controllerConnectionTable.Id] = controllerConnectionTable;
                                continue;
                            }

                            ExpansionCardDeviceConfigurationBase expansionCard = configurationItem as ExpansionCardDeviceConfigurationBase;
                            if (expansionCard != null)
                            {
                                ConfigurationManager.ExpansionCards[expansionCard.Id] = expansionCard;
                                continue;
                            }

                            DeviceConfigurationBase devices = configurationItem as DeviceConfigurationBase;
                            if (devices != null)
                            {
                                ConfigurationManager.Devices[devices.Id] = devices;
                                continue;
                            }

                            Area8003Configuration area = configurationItem as Area8003Configuration;
                            if (area != null)
                            {
                                ConfigurationManager.Areas[area.Id] = area;
                                continue;
                            }

                            Input8003Configuration input = configurationItem as Input8003Configuration;
                            if (input != null)
                            {
                                ConfigurationManager.Inputs[input.Id] = input;
                                continue;
                            }

                            Output8003Configuration output = configurationItem as Output8003Configuration;
                            if (output != null)
                            {
                                ConfigurationManager.Outputs[output.Id] = output;
                                continue;
                            }

                            var legacyElevator = configurationItem as LegacyElevator8003Configuration;
                            if (legacyElevator != null)
                            {
                                ConfigurationManager.LegacyElevators[legacyElevator.Id] = legacyElevator;
                                continue;
                            }

                            var elevator = configurationItem as Elevator8003Configuration;
                            if (elevator != null)
                            {
                                ConfigurationManager.UnisonElevators[elevator.Id] = elevator;
                                continue;
                            }

                            var elevatorFloor = configurationItem as ElevatorFloor8003Configuration;
                            if (elevatorFloor != null)
                            {
                                ConfigurationManager.ElevatorFloors[elevatorFloor.Id] = elevatorFloor;
                                continue;
                            }

                            Door8003Configuration door = configurationItem as Door8003Configuration;
                            if (door != null)
                            {
                                ConfigurationManager.Doors[door.Id] = door;
                                continue;
                            }

                            Interlock8003Configuration interlockGroup = configurationItem as Interlock8003Configuration;
                            if (interlockGroup != null)
                            {
                                ConfigurationManager.InterlockGroups[interlockGroup.Id] = interlockGroup;
                                continue;
                            }

                            VaultControllerInterlock8003Configuration vaultControllerInterlockGroup = configurationItem as VaultControllerInterlock8003Configuration;
                            if (vaultControllerInterlockGroup != null)
                            {
                                ConfigurationManager.VaultControllerInterlockGroups[vaultControllerInterlockGroup.Id] = vaultControllerInterlockGroup;
                                continue;
                            }

                            Reader8003LegacyWiegandConfiguration reader = configurationItem as Reader8003LegacyWiegandConfiguration;
                            if (reader != null)
                            {
                                gmsConfigurationFound = true;
                                ConfigurationManager.Readers[reader.Id] = reader;
                                continue;
                            }

                            Group8003Configuration group = configurationItem as Group8003Configuration;
                            if (group != null)
                            {
                                ConfigurationManager.Groups[group.Id] = group;
                                continue;
                            }

                            Port8003ConfigurationBase port = configurationItem as Port8003ConfigurationBase;
                            if (port != null)
                            {
                                ConfigurationManager.Ports[port.Id] = port;
                                continue;
                            }

                            User8003Configuration user = configurationItem as User8003Configuration;
                            if (user != null)
                            {
                                gmsConfigurationFound = true;
                                ConfigurationManager.Users[user.Id] = user;
                                if (user.AreaAccessPrivilege == null || user.AreaIds.Length != user.AreaAccessPrivilege.Length)
                                {
                                    user.AreaAccessPrivilege = new AreaAccessPrivilege[user.AreaIds.Length];
                                    for (int i = 0; i < user.AreaAccessPrivilege.Length; i++)
                                    {
                                        user.AreaAccessPrivilege[i] = new AreaAccessPrivilege();
                                        user.AreaAccessPrivilege[i].SetDefaults();
                                    }
                                }
                                continue;
                            }

                            Macro8003Configuration macro = configurationItem as Macro8003Configuration;
                            if (macro != null)
                            {
                                ConfigurationManager.Macros[macro.Id] = macro;
                                continue;
                            }

                            LegacyCardFormat cardFormat = configurationItem as LegacyCardFormat;
                            if (cardFormat != null)
                            {
                                gmsConfigurationFound = true;
                                ConfigurationManager.CardFormats[cardFormat.Id] = cardFormat;
                                continue;
                            }

                            Schedule schedule = configurationItem as Schedule;
                            if (schedule != null)
                            {
                                ConfigurationManager.Schedules[schedule.Id] = schedule;
                                continue;
                            }

                            PresenceZone8003Configuration presenceZone = configurationItem as PresenceZone8003Configuration;
                            if (presenceZone != null)
                            {
                                ConfigurationManager.PresenceZones[presenceZone.Id] = presenceZone;
                                continue;
                            }

                            Calendar calendar = configurationItem as Calendar;
                            if (calendar != null)
                            {
                                ConfigurationManager.Calendar = calendar;
                                continue;
                            }

                            //VaultController8003Configuration vaultControllerConfig = configurationItem as VaultController8003Configuration;
                            //if(vaultControllerConfig != null)
                            //{
                            //    ConfigurationManager.VaultConfiguration = vaultControllerConfig;
                            //    continue;
                            //}

                            Reader8003Configuration unisonReader = configurationItem as Reader8003Configuration;
                            if (unisonReader != null)
                            {
                                unisonConfigurationFound = true;
                                ConfigurationManager.UnisonReaders[unisonReader.Id] = unisonReader;
                                continue;
                            }

                            User unisonUser = configurationItem as User;
                            if (unisonUser != null)
                            {
                                unisonConfigurationFound = true;
                                ConfigurationManager.UnisonUsers[unisonUser.Id] = unisonUser;
                                continue;
                            }

                            AccessGroup unisonAccessGroup = configurationItem as AccessGroup;
                            if (unisonAccessGroup != null)
                            {
                                unisonConfigurationFound = true;
                                ConfigurationManager.UnisonAccessGroups[unisonAccessGroup.Id] = unisonAccessGroup;
                                continue;
                            }

                            // Cards shouldn't be present in the configuration and will be removed upon save
                            Credential credential = configurationItem as Credential;
                            if (credential != null)
                            {
                                unisonConfigurationFound = true;
                                continue;
                            }

                            OpenPacomToDigitalReceiver8003Template openPacomToDigitalReceiver8003Template = configurationItem as OpenPacomToDigitalReceiver8003Template;
                            if (openPacomToDigitalReceiver8003Template != null)
                            {
                                ConfigurationManager.OpenPacomToDigitalReceiverTemplates[1] = openPacomToDigitalReceiver8003Template;
                                continue;
                            }
                        }
                        catch (Exception ex)
                        {
                            errorCount++;
                            if (errorCount < 3)
                            {
                                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                                    Translation.GetTranslatedError(ErrorMessage.LoadingConfiguration) + " " + ex.Message,
                                    Translation.GetTranslatedError(ErrorMessage.Error));
                            }
                            else if (errorCount > 100)
                            {
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.LoadingConfiguration) + " " + ex.Message,
                    Translation.GetTranslatedError(ErrorMessage.Error));
            }

            bool success = true;
            if (ConfigurationManager.ControllerConfiguration == null)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.LoadingConfiguration),
                    Translation.GetTranslatedError(ErrorMessage.Error));
                LoadDefaults();
                success = false;
            }
            else if (App.GmsConfigurationOnly && unisonConfigurationFound)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.UnisonConfigurationWillBeRemoved),
                    Translation.GetTranslatedError(ErrorMessage.Error));

                RemoveUnisonConfigurationItems();
            }
            else if (unisonConfigurationFound && gmsConfigurationFound)
            {
                DeleteGmsOrUnison deleteGmsOrUnisonDialog = new DeleteGmsOrUnison();
                deleteGmsOrUnisonDialog.ShowDialog();
                if (deleteGmsOrUnisonDialog.DeleteGmsConfiguration == true && deleteGmsOrUnisonDialog.DeleteUnisonConfiguration == false)
                {
                    RemoveGmsConfigurationItems();
                }
                else if (deleteGmsOrUnisonDialog.DeleteGmsConfiguration == false && deleteGmsOrUnisonDialog.DeleteUnisonConfiguration == true)
                {
                    RemoveUnisonConfigurationItems();
                }
                else
                {
                    LoadDefaults();
                    success = false;
                }
            }

            if (success)
            {
                if (ConfigurationManager.Calendar == null)
                {
                    ConfigurationManager.Calendar = new Calendar();
                    ConfigurationManager.Calendar.Id = 1;
                    ConfigurationManager.Calendar.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                }

                ControllerConnection8003Table controllerConnectionTable1;
                ControllerConnection8003Table controllerConnectionTable2;
                switch (ConfigurationManager.ControllerConnectionTables.Count)
                {
                    case 0:
                        controllerConnectionTable1 = new ControllerConnection8003Table();
                        controllerConnectionTable2 = new ControllerConnection8003Table();
                        ConfigurationManager.AutoConfigure(controllerConnectionTable1, 1, false);
                        ConfigurationManager.AutoConfigure(controllerConnectionTable2, 2, false);
                        controllerConnectionTable1.Password = EncryptIfRequired(controllerConnectionTable1.Password);
                        controllerConnectionTable2.Password = EncryptIfRequired(controllerConnectionTable2.Password);
                        break;
                    case 1:
                        int existingId = ConfigurationManager.ControllerConnectionTables.Keys[0];
                        if (existingId == 1)
                        {
                            controllerConnectionTable2 = new ControllerConnection8003Table();
                            ConfigurationManager.AutoConfigure(controllerConnectionTable2, 2, false);
                            controllerConnectionTable2.Password = EncryptIfRequired(controllerConnectionTable2.Password);
                        }
                        else
                        {
                            controllerConnectionTable1 = new ControllerConnection8003Table();
                            ConfigurationManager.AutoConfigure(controllerConnectionTable1, 1, false);
                            controllerConnectionTable1.Password = EncryptIfRequired(controllerConnectionTable1.Password);
                        }
                        break;
                }

                MainWindow.Instance.Title = Translation.GetTranslatedTitle() + " - " + Path.GetFileName(filePath);
            }

            bool hasTemplate = ConfigurationManager.OpenPacomToDigitalReceiverTemplates.ContainsKey(1);
            MenuView.Instance.SetTemplateStatusItem(hasTemplate);

            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
            return success;
        }

        public static void RemoveGmsConfigurationItems()
        {
            ConfigurationManager.Readers.Clear();
            ConfigurationManager.Users.Clear();
            ConfigurationManager.CardFormats.Clear();
            ConfigurationManager.LegacyElevators.Clear();
        }

        public static void RemoveUnisonConfigurationItems()
        {
            ConfigurationManager.UnisonReaders.Clear();
            ConfigurationManager.UnisonUsers.Clear();
            ConfigurationManager.UnisonAccessGroups.Clear();
            ConfigurationManager.UnisonElevators.Clear();
        }

        public static bool SaveToFile(string filePath)
        {
            try
            {
                // Write the new configuration out to a file.
                using (FileStream fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    // Create the Asn.1 Serializer instance
                    StreamingContext context = new StreamingContext();
                    Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(true, context);
                    asn1Serializer.SerializeDefaultValues = true;

                    save(ConfigurationManager.Areas.Values.ToArray(), asn1Serializer, fileStream);
                    save(new ConfigurationBase[] { ConfigurationManager.ControllerConfiguration }, asn1Serializer, fileStream);
                    save(ConfigurationManager.Devices.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.ExpansionCards.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.Doors.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.InterlockGroups.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.VaultControllerInterlockGroups.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.Inputs.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.Macros.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.Outputs.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.UnisonElevators.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.LegacyElevators.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.ElevatorFloors.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.Ports.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.Readers.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.UnisonReaders.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.PresenceZones.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.Schedules.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.Users.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.UnisonUsers.Values.ToArray(), asn1Serializer, fileStream);
                    save(new ConfigurationBase[] { ConfigurationManager.Calendar }, asn1Serializer, fileStream);
                    save(ConfigurationManager.CardFormats.Values.ToArray(), asn1Serializer, fileStream);

                    List<ControllerConnection8003Table> connectionTables = new List<ControllerConnection8003Table>();
                    foreach (ControllerConnection8003Table connectionTable in ConfigurationManager.ControllerConnectionTables.Values)
                    {
                        if (connectionTable.ConnectionEntry.Length > 0)
                            connectionTables.Add(connectionTable);
                    }
                    if (connectionTables.Count > 0)
                        save(connectionTables.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.Groups.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.OpenPacomToDigitalReceiverTemplates.Values.ToArray(), asn1Serializer, fileStream);
                    save(ConfigurationManager.UnisonAccessGroups.Values.ToArray(), asn1Serializer, fileStream);
                    //save(new ConfigurationBase[] { ConfigurationManager.VaultConfiguration }, asn1Serializer, fileStream);
                }

                MainWindow.Instance.Title = Translation.GetTranslatedTitle() + " - " + Path.GetFileName(filePath);
                App.ConfigurationModified = false;
            }
            catch (Exception ex)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.SavingConfiguration) + " " + ex.Message,
                    Translation.GetTranslatedError(ErrorMessage.Error));
                return false;
            }
            return true;
        }

        private static void save(ConfigurationBase[] configurationList, Asn1DerFormatter asn1Serializer, FileStream fileStream)
        {
            foreach (ConfigurationBase configurationItem in configurationList)
            {
                asn1Serializer.Serialize(fileStream, configurationItem);
            }
        }

        public static List<ComboBoxItemContents> GetAvailableDaysOfWeek()
        {
            List<ComboBoxItemContents> daysOfWeek = new List<ComboBoxItemContents>();
            foreach (DayTypeDisplay day in Enum.GetValues(typeof(DayTypeDisplay)))
            {
                daysOfWeek.Add(new ComboBoxItemContents(Translation.GetTranslatedString(day, typeof(DayType)), day));
            }            
            return daysOfWeek;
        }

        public static List<ComboBoxItemContents> GetAvailableAreas(bool includeNone)
        {
            List<ComboBoxItemContents> areas = new List<ComboBoxItemContents>();
            if (includeNone)
                areas.Add(new ComboBoxItemContents(UntranslatedStrings.None, 0));
            foreach (Area8003Configuration area in ConfigurationManager.Areas.Values)
            {
                areas.Add(new ComboBoxItemContents(area.Name, area.Id));
            }
            return areas;
        }

        public static List<ComboBoxItemContents> GetAvailableUserGroups()
        {
            List<ComboBoxItemContents> userGroups = new List<ComboBoxItemContents>();
            userGroups.Add(new ComboBoxItemContents(UntranslatedStrings.None, 0));
            foreach (Group8003Configuration userGroup in ConfigurationManager.Groups.Values)
            {
                userGroups.Add(new ComboBoxItemContents(userGroup.Name, userGroup.Id));
            }
            return userGroups;
        }
        public static List<ComboBoxItemContents> GetAllInputs()
        {
            List<ComboBoxItemContents> inputs = new List<ComboBoxItemContents>();
            foreach (Input8003Configuration input in ConfigurationManager.Inputs.Values)
            {
                inputs.Add(new ComboBoxItemContents(input.Name, input.Id));
            }
            return inputs;
        }

        public static List<ComboBoxItemContents> GetAllOutputs()
        {
            List<ComboBoxItemContents> outputs = new List<ComboBoxItemContents>();
            foreach (Output8003Configuration output in ConfigurationManager.Outputs.Values)
            {
                outputs.Add(new ComboBoxItemContents(output.Name, output.Id));
            }
            return outputs;
        }

        public static List<ComboBoxItemContents> GetAllElevators()
        {
            List<ComboBoxItemContents> elevators = new List<ComboBoxItemContents>();
            if(ConfigurationManager.UnisonConfigurationPresent)
            {
                foreach (var elevator in ConfigurationManager.UnisonElevators.Values)
                {
                    elevators.Add(new ComboBoxItemContents(elevator.Name, elevator.Id));
                }
            }
            else
            {
                foreach (var elevator in ConfigurationManager.LegacyElevators.Values)
                {
                    elevators.Add(new ComboBoxItemContents(elevator.Name, elevator.Id));
                }
            }
            
            return elevators;
        }

        public static List<ComboBoxItemContents> GetAllElevatorFloors()
        {
            List<ComboBoxItemContents> elevatorFloors = new List<ComboBoxItemContents>();
            foreach (var elevatorFloor in ConfigurationManager.ElevatorFloors.Values)
            {
                elevatorFloors.Add(new ComboBoxItemContents(elevatorFloor.Name, elevatorFloor.Id));
            }
            return elevatorFloors;
        }

        public static List<ComboBoxItemContents> GetAllReaders()
        {
            List<ComboBoxItemContents> readers = new List<ComboBoxItemContents>();
            foreach (Reader8003LegacyWiegandConfiguration reader in ConfigurationManager.Readers.Values)
            {
                readers.Add(new ComboBoxItemContents(reader.Name, reader.Id));
            }
            foreach (Reader8003Configuration reader in ConfigurationManager.UnisonReaders.Values)
            {
                readers.Add(new ComboBoxItemContents(reader.Name, reader.Id));
            }
            return readers;
        }

        public static List<ComboBoxItemContents>  GetInterlockGroups()
        {
            List<ComboBoxItemContents> interlockGroups = new List<ComboBoxItemContents>();
            foreach (var interlockGroup in ConfigurationManager.InterlockGroups.Values)
            {
                interlockGroups.Add(new ComboBoxItemContents(interlockGroup.Name, interlockGroup.Id));
            }
            return interlockGroups;
        }

        public static List<ComboBoxItemContents> GetVaultControllerInterlockGroups()
        {
            List<ComboBoxItemContents> interlockGroups = new List<ComboBoxItemContents>();
            foreach (var interlockGroup in ConfigurationManager.VaultControllerInterlockGroups.Values)
            {
                interlockGroups.Add(new ComboBoxItemContents(interlockGroup.Name, interlockGroup.Id));
            }
            return interlockGroups;
        }

        public static List<ComboBoxItemContents> GetAllVaultControllers()
        {
            List<ComboBoxItemContents> vaultControllers = new List<ComboBoxItemContents>();
            foreach (var device in ConfigurationManager.Devices.Values)
            {
                if (device != null && device is Device1076VCConfiguration)
                {
                    //vaultControllers.Add(new ComboBoxItemContents(device.Name, ((Device1076VCConfiguration)device).VaultControllerNumber));
                    vaultControllers.Add(new ComboBoxItemContents(device.Name, device.Id));
                }
            }
            return vaultControllers;
        }

        public static List<ComboBoxItemContents> GetAllDoors()
        {
            List<ComboBoxItemContents> doors = new List<ComboBoxItemContents>();
            foreach (var door in ConfigurationManager.Doors.Values)
            {
                doors.Add(new ComboBoxItemContents(door.Name, door.Id));
            }
            return doors;
        }

        public static List<ComboBoxItemContents> GetAvailableAccessDeniedReasons()
        {
            List<ComboBoxItemContents> reasons = new List<ComboBoxItemContents>();
            foreach (AccessDeniedReasonDisplay reason in Enum.GetValues(typeof(AccessDeniedReasonDisplay)))
            {
                reasons.Add(new ComboBoxItemContents(Translation.GetTranslatedString(reason, typeof(AccessDeniedReason)), reason));
            }
            return reasons;
        }

        public static List<ComboBoxItemContents> GetAvailableUsers()
        {
            List<ComboBoxItemContents> users = new List<ComboBoxItemContents>();
            foreach (User8003Configuration user in ConfigurationManager.Users.Values)
            {
                users.Add(new ComboBoxItemContents(user.Name, user.Id));
            }
            foreach (User user in ConfigurationManager.UnisonUsers.Values)
            {
                users.Add(new ComboBoxItemContents(user.Name, user.Id));
            }
            return users;
        }

        public static List<ComboBoxItemContents> GetAllKeypads()
        {
            List<ComboBoxItemContents> keypads = new List<ComboBoxItemContents>();
            foreach (DeviceConfigurationBase keypad in ConfigurationManager.Devices.Values)
            {
                if (keypad is Device8003KeypadConfiguration)
                    keypads.Add(new ComboBoxItemContents(keypad.Name, keypad.Id));
            }
            return keypads;
        }

        public static List<ComboBoxItemContents> GetAvailableCardFormats()
        {
            List<ComboBoxItemContents> cardFormats = new List<ComboBoxItemContents>();
            foreach (LegacyCardFormat cardFormat in ConfigurationManager.CardFormats.Values)
            {
                cardFormats.Add(new ComboBoxItemContents(Translation.GetTranslatedNodeTreeItem("CardProfile") + " " + cardFormat.Id.ToString(), cardFormat.Id));
            }
            return cardFormats;
        }

        public static List<ComboBoxItemContents> GetAvailablePresenceZones()
        {
            List<ComboBoxItemContents> presenceZones = new List<ComboBoxItemContents>();
            foreach (PresenceZone8003Configuration presenceZone in ConfigurationManager.PresenceZones.Values)
            {
                presenceZones.Add(new ComboBoxItemContents(presenceZone.Name, presenceZone.Id));
            }
            return presenceZones;
        }

        public static List<ComboBoxItemContents> GetAvailableSchedules()
        {
            List<ComboBoxItemContents> schedules = new List<ComboBoxItemContents>();
            schedules.Add(new ComboBoxItemContents(UntranslatedStrings.None, 0));
            foreach (Schedule schedule in ConfigurationManager.Schedules.Values)
            {
                schedules.Add(new ComboBoxItemContents(Translation.GetTranslatedMisc("Schedule_") + schedule.Id.ToString(), schedule.Id));
            }
            return schedules;
        }

        private static void disable(List<ComboBoxItemContents> readers, int readerId)
        {
            foreach (ComboBoxItemContents reader in readers)
            {
                if ((int)reader.Value == readerId)
                {
                    reader.Enabled = false;
                    return;
                }
            }
        }

        public static List<ComboBoxItemContents> GetAvailableReaders(int currentReaderId)
        {
            List<ComboBoxItemContents> readers = new List<ComboBoxItemContents>();
            readers.Add(new ComboBoxItemContents(UntranslatedStrings.None, 0));
            foreach (Reader8003LegacyWiegandConfiguration reader in ConfigurationManager.Readers.Values)
            {
                readers.Add(new ComboBoxItemContents(reader.Name, reader.Id));
            }
            foreach (Reader8003Configuration reader in ConfigurationManager.UnisonReaders.Values)
            {
                readers.Add(new ComboBoxItemContents(reader.Name, reader.Id));
            }

            foreach (Door8003Configuration door in ConfigurationManager.Doors.Values)
            {
                foreach (ComboBoxItemContents reader in readers)
                {
                    if ((int)reader.Value != currentReaderId && (int)reader.Value != 0 &&
                        ((int)reader.Value == door.ReaderInId || (int)reader.Value == door.ReaderOutId))
                    {
                        reader.Enabled = false;
                    }
                }
            }
            return readers;
        }

        public static List<ComboBoxItemContents> GetAvailableReaderModes()
        {
            List<ComboBoxItemContents> list = new List<ComboBoxItemContents>();
            foreach (ReaderModeDisplay item in Enum.GetValues(typeof(ReaderModeDisplay)))
            {
                list.Add(new ComboBoxItemContents(Translation.GetTranslatedString(item, typeof(ReaderMode)), item));
            }
            return list;
        }

        public static List<ComboBoxItemContents> GetAvailableReaderStates()
        {
            List<ComboBoxItemContents> list = new List<ComboBoxItemContents>();
            foreach (ReaderStateDisplay item in Enum.GetValues(typeof(ReaderStateDisplay)))
            {
                list.Add(new ComboBoxItemContents(Translation.GetTranslatedString(item, typeof(ReaderState)), item));
            }
            return list;
        }

        public static List<ComboBoxItemContents> GetAvailableCardStatus()
        {
            List<ComboBoxItemContents> list = new List<ComboBoxItemContents>();
            foreach (CardStatusDisplay item in Enum.GetValues(typeof(CardStatusDisplay)))
            {
                list.Add(new ComboBoxItemContents(Translation.GetTranslatedString(item, typeof(CardStatus)), item));
            }
            return list;
        }

        public static List<ComboBoxItemContents> GetAvailableReaderCategory()
        {
            List<ComboBoxItemContents> list = new List<ComboBoxItemContents>();
            foreach (ReaderCategoryDisplay item in Enum.GetValues(typeof(ReaderCategoryDisplay)))
            {
                list.Add(new ComboBoxItemContents(Translation.GetTranslatedString(item, typeof(ReaderCategory)), item));
            }
            return list;
        }

        public static List<ComboBoxItemContents> GetAvailableDevices(Type childType, int currentParent)
        {
            List<ComboBoxItemContents> devices = new List<ComboBoxItemContents>();
            Device8003Configuration controllerConfiguration = ConfigurationManager.ControllerConfiguration;
            devices.Add(new ComboBoxItemContents(controllerConfiguration.Name, controllerConfiguration.Id));

            foreach (DeviceConfigurationBase device in ConfigurationManager.Devices.Values)
            {
                devices.Add(new ComboBoxItemContents(device.Name, device.Id));
            }

            foreach (DeviceConfigurationBase expansionCard in ConfigurationManager.ExpansionCards.Values)
            {
                devices.Add(new ComboBoxItemContents(expansionCard.Name, expansionCard.Id));
            }

            for (int i = 0; i < devices.Count; i++)
            {
                if (currentParent == (int)devices[i].Value)
                    continue;

                List<ComboBoxItemContents> availableDevicePoints = GetAvailableDevicePoints((int)devices[i].Value, childType, 0);
                if (availableDevicePoints.Count == 0)
                {
                    devices.RemoveAt(i);
                    i--;
                }
                else
                {
                    bool anyPointsAvailable = false;
                    foreach (ComboBoxItemContents point in availableDevicePoints)
                    {
                        if (point.Enabled == true)
                        {
                            anyPointsAvailable = true;
                            break;
                        }
                    }

                    if (anyPointsAvailable == false)
                        devices[i].Enabled = false;
                }
            }

            return devices;
        }

        public static List<ComboBoxItemContents> GetAvailableDevicePoints(int parentId, Type childType, int currentPoint)
        {
            List<ComboBoxItemContents> availableDevicePoints = new List<ComboBoxItemContents>();
            int hardwareLimitations = HardwareLimitations.GetAvailableDevicePointLimit(parentId, childType);

            if (hardwareLimitations == int.MaxValue)
            {
                if (currentPoint == 0)
                    currentPoint = 1;
                availableDevicePoints.Add(new ComboBoxItemContents(currentPoint.ToString(), currentPoint));
                return availableDevicePoints;
            }

            for (int i = 1; i <= hardwareLimitations; i++)
            {
                availableDevicePoints.Add(new ComboBoxItemContents(i.ToString(), i));
            }

            // Disable used points
            if (childType == typeof(Input8003Configuration))
            {
                foreach (Input8003Configuration input in ConfigurationManager.Inputs.Values)
                {
                    if (input.ParentDeviceId == parentId && input.PointNumberOnParent != currentPoint)
                    {
                        try
                        {
                            availableDevicePoints[input.PointNumberOnParent - 1].Enabled = false;
                        }
                        catch
                        {
                        }
                    }
                }
            }
            else if (childType == typeof(Output8003Configuration))
            {
                foreach (Output8003Configuration output in ConfigurationManager.Outputs.Values)
                {
                    if (output.ParentDeviceId == parentId && output.PointNumberOnParent != currentPoint)
                    {
                        try
                        {
                            availableDevicePoints[output.PointNumberOnParent - 1].Enabled = false;
                        }
                        catch
                        {
                        }
                    }
                }
            }
            else if (childType == typeof(Door8003Configuration))
            {
                foreach (Door8003Configuration door in ConfigurationManager.Doors.Values)
                {
                    if (door.ParentDeviceId == parentId && door.PointNumberOnParent != currentPoint)
                    {
                        try
                        {
                            availableDevicePoints[door.PointNumberOnParent - 1].Enabled = false;
                        }
                        catch
                        {
                        }
                    }
                }
            }
            else if (childType == typeof(Reader8003LegacyWiegandConfiguration))
            {
                foreach (Reader8003LegacyWiegandConfiguration reader in ConfigurationManager.Readers.Values)
                {
                    if (reader.ParentDeviceId == parentId && reader.PointNumberOnParent != currentPoint)
                    {
                        try
                        {
                            availableDevicePoints[reader.PointNumberOnParent - 1].Enabled = false;
                        }
                        catch
                        {
                        }
                    }
                }
            }
            else if (childType == typeof(Reader8003Configuration))
            {
                foreach (Reader8003Configuration reader in ConfigurationManager.UnisonReaders.Values)
                {
                    if (reader.ParentDeviceId == parentId && reader.PointNumberOnParent != currentPoint)
                    {
                        try
                        {
                            availableDevicePoints[reader.PointNumberOnParent - 1].Enabled = false;
                        }
                        catch
                        {
                        }
                    }
                }
            }
            else if (childType.BaseType == typeof(ExpansionCardDeviceConfigurationBase))
            {
                foreach (ExpansionCardDeviceConfigurationBase expansionCard in ConfigurationManager.ExpansionCards.Values)
                {
                    if (expansionCard.ParentDeviceId == parentId && expansionCard.ExpansionCardSlot != currentPoint)
                    {
                        try
                        {
                            availableDevicePoints[expansionCard.ExpansionCardSlot - 1].Enabled = false;
                        }
                        catch
                        {
                        }
                    }
                }
            }
            else if (childType.BaseType == typeof(DeviceLoopDeviceConfigurationBase))
            {
                foreach (DeviceConfigurationBase device in ConfigurationManager.Devices.Values)
                {
                    DeviceLoopDeviceConfigurationBase deviceLoopDevice = device as DeviceLoopDeviceConfigurationBase;
                    if (deviceLoopDevice != null && deviceLoopDevice.ParentDeviceId == parentId && deviceLoopDevice.DeviceLoopAddress != currentPoint)
                    {
                        try
                        {
                            availableDevicePoints[deviceLoopDevice.DeviceLoopAddress - 1].Enabled = false;
                        }
                        catch
                        {
                        }
                    }
                }
            }
            else if (childType == typeof(InovonicsReceiverDeviceConfiguration))
            {
                foreach (DeviceConfigurationBase device in ConfigurationManager.Devices.Values)
                {
                    InovonicsReceiverDeviceConfiguration inovonicsReceiver = device as InovonicsReceiverDeviceConfiguration;
                    if (inovonicsReceiver != null)
                    {
                        try
                        {
                            availableDevicePoints[0].Enabled = false;
                        }
                        catch
                        {
                        }
                    }
                }
            }
            return availableDevicePoints;
        }

        public static List<ComboBoxItemContents> GetAvailableElevatorDevices()
        {
            List<ComboBoxItemContents> devices = new List<ComboBoxItemContents>();
            Device8003Configuration controllerConfiguration = ConfigurationManager.ControllerConfiguration;
            devices.Add(new ComboBoxItemContents(UntranslatedStrings.None, 0));
            foreach (var device in ConfigurationManager.Devices.Values)
            {
                if (device != null && device.HardwareType == HardwareType.Pacom1065ElevatorController)
                    devices.Add(new ComboBoxItemContents(device.Name, ((DeviceLoopDeviceConfigurationBase)device).DeviceLoopAddress));
            }
            return devices;
        }
    }
}
