﻿using System;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public static class StringExtensions
    {
        /// <summary>
        /// Converts a string containing HEX digits to a byte array
        /// </summary>
        /// <param name="hexCharacters">HEX digit string</param>
        /// <returns></returns>
        public static byte[] ConvertHexStringToByteArray(this string hexCharacters)
        {
            try
            {
                int NumberChars = hexCharacters.Length;
                byte[] bytes = new byte[NumberChars / 2];
                for (int i = 0; i < NumberChars; i += 2)
                {
                    bytes[i / 2] = Convert.ToByte(hexCharacters.Substring(i, 2), 16);
                }
                return bytes;
            }
            catch
            {
                return null;
            }
        }
    }
}