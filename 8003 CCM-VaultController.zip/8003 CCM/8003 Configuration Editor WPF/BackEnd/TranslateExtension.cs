﻿using System;
using System.Windows.Markup;

namespace Pacom.ConfigurationEditor.WPF
{
    public class TranslateExtension : MarkupExtension
    {
        public TranslateExtension()
        {
        }

        public TranslateExtension(string text)
        {
            Text = text;
        }

        public string Text { get; set; } = string.Empty;
        public string UnTranslateText { get; set; } = string.Empty;
        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            if (string.IsNullOrWhiteSpace(UnTranslateText))
                return Translation.GetTranslatedString(Text);
            else
                return $"{Translation.GetTranslatedString(Text)} {UnTranslateText}";
        }
    }
}
