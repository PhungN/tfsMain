﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{
    public enum ControllerMode
    {
        /// <summary>8003 controller is in GMS / EMCS mode of operation</summary>
        GmsEmcs = 0,
        /// <summary>8003 controller is in Unison mode of operation</summary>
        Unison,
    }
}
