﻿using System.Collections.Generic;

namespace Pacom.ConfigurationEditor.WPF
{
    public class Language
    {
        /// <summary>Windows' base language code, ("en", "fr")</summary>
        public string Code;
        /// <summary>Name of the language, for where it appears in English UI ("English", "French")</summary>
        public string EnglishName;
        /// <summary>Native name of the language, as appears in the Language menu, with shortcut key ("_English","_Français")</summary>
        public string MenuName;
        /// <summary=>The column name in the CcmMessage.csv and ResourceMessage.csv files ("en","fr-FR")</summary>
        public string ColumnName;
        /// <summary=>The column name in the KeypadLanguageStrings.csv files ("English","French")</summary>
        public string KeypadColumnName;

        /// <summary>
        /// Dictionary of key to translated text
        /// </summary>
        public Dictionary<string, string> Translations = new Dictionary<string, string>();

        /// <summary>
        /// A dictionary of translations for a single language
        /// </summary>
        /// <param name="code">Windows' base language code, ("en", "fr")</param>
        /// <param name="englishName">Name of the language, for where it appears in English UI ("English", "French")</param>
        /// <param name="menuName">Native name of the language, as appears in the Language menu, with shortcut key ("_English","_Français")</param>
        /// <param name="columnName">The column name in the CcmMessage.csv and ResourceMessage.csv files ("en","fr-FR")</param>
        public Language(string code, string englishName, string menuName, string columnName, string keypadColumnName)
        {
            Code = code;
            EnglishName = englishName;
            MenuName = menuName;
            ColumnName = columnName;
            KeypadColumnName = keypadColumnName;
        }
    }
}
