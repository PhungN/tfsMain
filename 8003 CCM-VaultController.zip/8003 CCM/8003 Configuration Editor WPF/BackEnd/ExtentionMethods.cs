﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Text;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common.Utils
{
    public static class ExtentionMethods
    {
        public static void SetDefaults(this ControllerConnection8003Entry connectionEntry)
        {
            setDefaultsUsingReflection(connectionEntry);
        }

        public static void SetDefaults(this AreaAccessPrivilege areaAccessPrivilege)
        {
            setDefaultsUsingReflection(areaAccessPrivilege);
        }

        private static T firstOrDefault<T>(this T[] collection)
        {
            if (collection.Length > 0)
                return collection[0];
            return default(T);
        }

        private static void setDefaultsUsingReflection(object o)
        {
            foreach (PropertyInfo property in o.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (property.CanWrite)
                {
                    DefaultValueAttribute defaultAttribute = (DefaultValueAttribute)property.GetCustomAttributes(typeof(DefaultValueAttribute), false).firstOrDefault();
                    if (defaultAttribute != null)
                    {
                        if (property.PropertyType == typeof(TimeSpan))
                        {   // Timespans should be cast from milliseconds.
                            property.SetValue(o, new TimeSpan(0, 0, 0, 0, (int)defaultAttribute.Value), null);
                        }
                        else
                        {
                            property.SetValue(o, defaultAttribute.Value, null);
                        }
                    }
                }
            }
        }
    }
}
