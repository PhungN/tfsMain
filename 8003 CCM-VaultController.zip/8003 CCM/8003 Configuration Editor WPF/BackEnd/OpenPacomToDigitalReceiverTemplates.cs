﻿using System;
using System.Xml;
using System.IO;
using System.Text;
using Pacom.Configuration.ConfigurationCommon;
using System.Collections.Generic;
using Pacom.Core.Contracts;
using Pacom.Events.EventsCommon;

namespace Pacom.Peripheral.Common.Configuration
{
    public enum DigitalReceiverMessageFormat
    {
        ContactId,
        Sia,
    }


    public enum ConversionTemplateFieldType
    {
        None,
        LogicalId,
        AreaId,
        UserId
    }

    public sealed class OpenPacomToDigitalReceiverTemplateEntry
    {
        public OpenPacomToDigitalReceiverTemplateEntry()
        {
            EventCategory = NodeCategory.None;
            LogicalIdMinimum = 0;
            LogicalIdMaximum = 0;
            ZoneFieldType = ConversionTemplateFieldType.None;
            GroupFieldType = ConversionTemplateFieldType.None;
            ZoneOffset = 0;
            GroupOffset = 0;
        }

        public NodeCategory EventCategory
        {
            get;
            set;
        }

        public string EventName
        {
            get;
            set;
        }

        public bool Restore
        {
            get;
            set;
        }

        public int LogicalIdMinimum
        {
            get;
            set;
        }

        public int LogicalIdMaximum
        {
            get;
            set;
        }

        public string EventCode
        {
            get;
            set;
        }

        public ConversionTemplateFieldType ZoneFieldType
        {
            get;
            set;
        }

        public ConversionTemplateFieldType GroupFieldType
        {
            get;
            set;
        }

        public int ZoneOffset
        {
            get;
            set;
        }

        public int GroupOffset
        {
            get;
            set;
        }

        public HardwareType? HardwareType
        {
            get;
            set;
        }

        public InputCategory? InputType
        {
            get;
            set;
        }

        public int? UserId
        {
            get;
            set;
        }

        public int? StateValueChange
        {
            get;
            set;
        }

        public int? StateValue
        {
            get;
            set;
        }

        public ListenInDeviceConnectStatus? ConnectStatus { get; set; }

        internal void ExportToXML(XmlTextWriter templateWriter)
        {
            if (templateWriter == null || templateWriter.BaseStream == null)
                return;

            try
            {
                templateWriter.WriteStartElement("OpenPacomToDigitalReceiverConversionTemplateEntry");
                templateWriter.WriteElementString("Enabled", "true");
                templateWriter.WriteElementString("OpenPacomMessageType", EventCategory.ToString());
                templateWriter.WriteElementString("OpenPacomEventType", EventName);
                templateWriter.WriteElementString("Restore", Restore ? "true" : "false");
                templateWriter.WriteElementString("ObjectIdMinimum", LogicalIdMinimum.ToString());
                templateWriter.WriteElementString("ObjectIdMaximum", LogicalIdMaximum.ToString());
                templateWriter.WriteElementString("EventCode", EventCode);
                if (ZoneFieldType != ConversionTemplateFieldType.None)
                {
                    templateWriter.WriteElementString("ZoneFieldName", ZoneFieldType == ConversionTemplateFieldType.LogicalId ? "Id" : ZoneFieldType.ToString());
                }
                if (GroupFieldType != ConversionTemplateFieldType.None)
                {
                    templateWriter.WriteElementString("GroupFieldName", GroupFieldType == ConversionTemplateFieldType.LogicalId ? "Id" : GroupFieldType.ToString());
                }
                if (GroupOffset != 0)
                {
                    templateWriter.WriteElementString("GroupOffset", GroupOffset.ToString());
                }
                if (ZoneOffset != 0)
                {
                    templateWriter.WriteElementString("ZoneOffset", ZoneOffset.ToString());
                }
                if (HardwareType.HasValue == true ||
                    InputType.HasValue == true ||
                    UserId.HasValue == true ||
                    StateValue.HasValue == true ||
                    ConnectStatus.HasValue == true ||
                    StateValueChange.HasValue == true)
                {
                    // Add all extra restrictions
                    try
                    {
                        templateWriter.WriteStartElement("ExtraRestrictions");
                        if (HardwareType.HasValue == true)
                        {
                            // Add hardware type restriction
                            templateWriter.WriteStartElement("SerializableKeyValuePair");
                            templateWriter.WriteElementString("Key", "HardwareType");
                            templateWriter.WriteElementString("Value", HardwareType.ToString());
                            templateWriter.WriteEndElement();
                        }
                        if (InputType.HasValue == true)
                        {
                            // Add hardware type restriction
                            templateWriter.WriteStartElement("SerializableKeyValuePair");
                            templateWriter.WriteElementString("Key", "InputType");
                            templateWriter.WriteElementString("Value", InputType.ToString());
                            templateWriter.WriteEndElement();
                        }
                        if (ConnectStatus.HasValue == true)
                        {
                            // Add hardware type restriction
                            templateWriter.WriteStartElement("SerializableKeyValuePair");
                            templateWriter.WriteElementString("Key", "ConnectStatus");
                            templateWriter.WriteElementString("Value", ConnectStatus.ToString());
                            templateWriter.WriteEndElement();
                        }
                        if (UserId.HasValue == true)
                        {
                            // Add hardware type restriction
                            templateWriter.WriteStartElement("SerializableKeyValuePair");
                            templateWriter.WriteElementString("Key", "UserId");
                            templateWriter.WriteElementString("Value", UserId.ToString());
                            templateWriter.WriteEndElement();
                        }
                        if (StateValueChange.HasValue == true)
                        {
                            // Add state value change restriction
                            templateWriter.WriteStartElement("SerializableKeyValuePair");
                            templateWriter.WriteElementString("Key", "StateValueChange");
                            templateWriter.WriteElementString("Value", ((int)StateValueChange).ToString());
                            templateWriter.WriteEndElement();
                        }
                        if (StateValue.HasValue == true)
                        {
                            // Add state value restriction
                            templateWriter.WriteStartElement("SerializableKeyValuePair");
                            templateWriter.WriteElementString("Key", "StateValue");
                            templateWriter.WriteElementString("Value", ((int)StateValue).ToString());
                            templateWriter.WriteEndElement();
                        }
                    }
                    finally
                    {
                        templateWriter.WriteEndElement();
                    }
                }
            }
            finally
            {
                templateWriter.WriteEndElement();
            }
        }
    }

    public sealed class OpenPacomToDigitalReceiverTemplate
    {
        public int Id
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        private readonly Dictionary<DigitalReceiverMessageFormat, Dictionary<int, List<OpenPacomToDigitalReceiverTemplateEntry>>> conversionEntries = new Dictionary<DigitalReceiverMessageFormat, Dictionary<int, List<OpenPacomToDigitalReceiverTemplateEntry>>>()
        {
            { DigitalReceiverMessageFormat.ContactId, new Dictionary<int, List<OpenPacomToDigitalReceiverTemplateEntry>>() },
            { DigitalReceiverMessageFormat.Sia, new Dictionary<int, List<OpenPacomToDigitalReceiverTemplateEntry>>() }
        };

        /// <summary>
        /// Get the count of conversion entry for the supplied message template format: CID or SIA
        /// </summary>
        /// <param name="templateFormat">Message Conversion Format</param>
        /// <returns>The number of conversion entries</returns>
        public int this[DigitalReceiverMessageFormat templateFormat]
        {
            get
            {
                Dictionary<int, List<OpenPacomToDigitalReceiverTemplateEntry>> siaCidTemplate = conversionEntries[templateFormat];
                if (siaCidTemplate.Count == 0)
                    return 0;

                int count = 0;
                foreach (var entries in siaCidTemplate.Values)
                {
                    count += entries.Count;
                }
                return count;
            }
        }

        /// <summary>
        /// The logical Id of the digital receiver template
        /// </summary>
        public const int DigitalReceiverTemplateId = 1;

        public OpenPacomToDigitalReceiverTemplate()
        {
            Id = 1;
            Name = "";
        }

        public OpenPacomToDigitalReceiverTemplate(OpenPacomToDigitalReceiver8003Template template)
        {
            convertFromBase(template);
        }

        private void convertFromBase(OpenPacomToDigitalReceiver8003Template template)
        {
            Id = template.Id;
            Name = template.TemplateId;

            foreach (OpenPacomToDigitalReceiverConversionTemplateEntry conversionEntry in template.ConversionEntries)
            {
                try
                {
                    if (conversionEntry.Enabled == false)
                        continue;

                    if (Enum.IsDefined(typeof(NodeCategory), conversionEntry.OpenPacomMessageType) == false)
                        continue;

                    OpenPacomToDigitalReceiverTemplateEntry newEntry = new OpenPacomToDigitalReceiverTemplateEntry();
                    newEntry.EventCategory = (NodeCategory)Enum.Parse(typeof(NodeCategory), conversionEntry.OpenPacomMessageType, true);
                    newEntry.EventName = conversionEntry.OpenPacomEventType;
                    newEntry.Restore = conversionEntry.Restore;
                    newEntry.LogicalIdMinimum = conversionEntry.ObjectIdMinimum;
                    newEntry.LogicalIdMaximum = conversionEntry.ObjectIdMaximum;
                    newEntry.EventCode = conversionEntry.EventCode;

                    if (conversionEntry.ZoneFieldName != null && conversionEntry.ZoneFieldName.Length > 0)
                    {
                        if (conversionEntry.ZoneFieldName[0] == 'u' || conversionEntry.ZoneFieldName[0] == 'U')
                            newEntry.ZoneFieldType = ConversionTemplateFieldType.UserId;
                        else if (conversionEntry.ZoneFieldName[0] == 'i' || conversionEntry.ZoneFieldName[0] == 'I')
                            newEntry.ZoneFieldType = ConversionTemplateFieldType.LogicalId;
                        else if (conversionEntry.ZoneFieldName[0] == 'a' || conversionEntry.ZoneFieldName[0] == 'A')
                            newEntry.ZoneFieldType = ConversionTemplateFieldType.AreaId;
                    }

                    if (conversionEntry.GroupFieldName != null && conversionEntry.GroupFieldName.Length > 0)
                    {
                        if (conversionEntry.GroupFieldName[0] == 'u' || conversionEntry.GroupFieldName[0] == 'U')
                            newEntry.GroupFieldType = ConversionTemplateFieldType.UserId;
                        else if (conversionEntry.GroupFieldName[0] == 'i' || conversionEntry.GroupFieldName[0] == 'I')
                            newEntry.GroupFieldType = ConversionTemplateFieldType.LogicalId;
                        else if (conversionEntry.GroupFieldName[0] == 'a' || conversionEntry.GroupFieldName[0] == 'A')
                            newEntry.GroupFieldType = ConversionTemplateFieldType.AreaId;
                    }

                    if (conversionEntry.ZoneOffset.HasValue)
                        newEntry.ZoneOffset = conversionEntry.ZoneOffset.Value;
                    if (conversionEntry.GroupOffset.HasValue)
                        newEntry.GroupOffset = conversionEntry.GroupOffset.Value;

                    if (conversionEntry.ExtraRestrictions != null)
                    {
                        foreach (var extraRestriction in conversionEntry.ExtraRestrictions)
                        {
                            if (extraRestriction.Key[0] == 'h' || extraRestriction.Key[0] == 'H') // HardwareType
                            {
                                newEntry.HardwareType = (HardwareType)Enum.Parse(typeof(HardwareType), extraRestriction.Value, true);
                            }
                            else if (extraRestriction.Key[0] == 'i' || extraRestriction.Key[0] == 'I') // InputType
                            {
                                newEntry.InputType = (InputCategory)Enum.Parse(typeof(InputCategory), extraRestriction.Value, true);
                            }
                            else if (extraRestriction.Key[0] == 'u' || extraRestriction.Key[0] == 'U') // UserId
                            {
                                int userId;
                                if (tryParseInteger(extraRestriction.Value, out userId) == true)
                                    newEntry.UserId = userId;
                            }
                            else if (extraRestriction.Key[0] == 'c' || extraRestriction.Key[0] == 'C') // ConnectStatus
                            {
                                newEntry.ConnectStatus = (ListenInDeviceConnectStatus)Enum.Parse(typeof(ListenInDeviceConnectStatus), extraRestriction.Value, true);
                            }
                            else if (extraRestriction.Key[0] == 's' || extraRestriction.Key[0] == 'S')
                            {
                                if (extraRestriction.Key.Length == 10)
                                {
                                    int stateValue;
                                    if (tryParseInteger(extraRestriction.Value, out stateValue) == true)
                                        newEntry.StateValue = stateValue;
                                }
                                else
                                {
                                    int stateValueChange;
                                    if (tryParseInteger(extraRestriction.Value, out stateValueChange) == true)
                                        newEntry.StateValueChange = stateValueChange;
                                }
                            }
                        }
                    }

                    DigitalReceiverMessageFormat templateFormat = isSiaConversionEntry(newEntry.EventCode) == true ? DigitalReceiverMessageFormat.Sia : DigitalReceiverMessageFormat.ContactId;
                    Dictionary<int, List<OpenPacomToDigitalReceiverTemplateEntry>> siaCidTemplate = null;
                    if (conversionEntries.TryGetValue(templateFormat, out siaCidTemplate) == true)
                    {
                        int hash = getHash(newEntry.EventName, newEntry.EventCategory);
                        if (siaCidTemplate.ContainsKey(hash) == false)
                            siaCidTemplate.Add(hash, new List<OpenPacomToDigitalReceiverTemplateEntry>());
                        siaCidTemplate[hash].Add(newEntry);
                    }
                    else
                    {
                        Logger.LogMessage(LoggingLevel.Debug, string.Format("Unable to find [{0}] digital receiver template entries list.", templateFormat.ToString()));
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogMessage(LoggingLevel.Error, string.Format("Failed loading OpenPacom to Digital Receiver template entry. {0}", ex));
                }
            }
        }

        /// <summary>
        /// Check if this EventCode is a SIA DC-03 template message conversion entry
        /// </summary>
        /// <param name="eventCode">Event Code to check</param>
        /// <returns>True if </returns>
        private static bool isSiaConversionEntry(string eventCode)
        {
            return string.IsNullOrEmpty(eventCode) == false && eventCode.Length == 2 &&
                   Char.IsUpper(eventCode[0]) == true && Char.IsUpper(eventCode[1]) == true;
        }

        private int getHash(string eventName, NodeCategory eventCategory)
        {
            return eventName.GetHashCode() ^ (int)eventCategory;
        }

        internal bool ImportFromXML(Stream fileStream, out OpenPacomToDigitalReceiver8003Template template)
        {
            template = null;
            try
            {
                template = new OpenPacomToDigitalReceiver8003Template();
                OpenPacomToDigitalReceiverConversionTemplateEntry entry = null;
                List<OpenPacomToDigitalReceiverConversionTemplateEntry> conversionEntries = new List<OpenPacomToDigitalReceiverConversionTemplateEntry>();
                SerializableKeyValuePair kvp = new SerializableKeyValuePair();
                List<SerializableKeyValuePair> extraRestrictions = new List<SerializableKeyValuePair>();
                string temp;

                using (XmlTextReader xmlTextReader = new XmlTextReader(fileStream))
                {
                    xmlTextReader.WhitespaceHandling = WhitespaceHandling.None;
                    xmlTextReader.MoveToContent();
                    while (xmlTextReader.Read())
                    {
                        switch (xmlTextReader.Name)
                        {
                            case "TemplateId":
                                template.TemplateId = xmlTextReader.ReadString();
                                break;
                            case "ConversionEntries":
                                if (xmlTextReader.NodeType == XmlNodeType.EndElement)
                                    template.ConversionEntries = conversionEntries.ToArray();
                                break;
                            case "OpenPacomToDigitalReceiver8003Template":
                            case "OpenPacomToDigitalReceiverConversionTemplate":
                                break;
                            case "ExtraRestrictions":
                                if (xmlTextReader.NodeType == XmlNodeType.EndElement)
                                {
                                    entry.ExtraRestrictions = extraRestrictions.ToArray();
                                    extraRestrictions.Clear();
                                }
                                break;
                            case "SerializableKeyValuePair":
                                if (xmlTextReader.NodeType == XmlNodeType.EndElement)
                                    extraRestrictions.Add(new SerializableKeyValuePair() { Key = kvp.Key, Value = kvp.Value });
                                break;
                            case "OpenPacomToDigitalReceiverConversionTemplateEntry":
                                if (xmlTextReader.NodeType == XmlNodeType.Element)
                                    entry = new OpenPacomToDigitalReceiverConversionTemplateEntry();
                                else
                                    conversionEntries.Add(entry);
                                break;
                            case "Enabled":
                                temp = xmlTextReader.ReadString();
                                if (temp[0] == 't' || temp[0] == 'T')
                                    entry.Enabled = true;
                                else
                                    entry.Enabled = false;
                                break;
                            case "OpenPacomMessageType":
                                entry.OpenPacomMessageType = xmlTextReader.ReadString();
                                break;
                            case "OpenPacomEventType":
                                entry.OpenPacomEventType = xmlTextReader.ReadString();
                                break;
                            case "Restore":
                                temp = xmlTextReader.ReadString();
                                if (temp[0] == 't' || temp[0] == 'T')
                                    entry.Restore = true;
                                else
                                    entry.Restore = false;
                                break;
                            case "ObjectIdMinimum":
                                temp = xmlTextReader.ReadString();
                                entry.ObjectIdMinimum = int.Parse(temp);
                                break;
                            case "ObjectIdMaximum":
                                temp = xmlTextReader.ReadString();
                                entry.ObjectIdMaximum = int.Parse(temp);
                                break;
                            case "EventCode":
                                entry.EventCode = xmlTextReader.ReadString();
                                break;
                            case "ZoneFieldName":
                                entry.ZoneFieldName = xmlTextReader.ReadString();
                                break;
                            case "GroupFieldName":
                                entry.GroupFieldName = xmlTextReader.ReadString();
                                break;
                            case "ZoneOffset":
                                temp = xmlTextReader.ReadString();
                                entry.ZoneOffset = int.Parse(temp);
                                break;
                            case "GroupOffset":
                                temp = xmlTextReader.ReadString();
                                entry.GroupOffset = int.Parse(temp);
                                break;
                            case "Key":
                                kvp.Key = xmlTextReader.ReadString();
                                break;
                            case "Value":
                                kvp.Value = xmlTextReader.ReadString();
                                break;
                            default:
                                break;
                        }
                    }
                }
                template.Id = DigitalReceiverTemplateId;
                template.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                convertFromBase(template);
                return true;
            }
            catch (IOException ex)
            {
                Logger.LogMessage(LoggingLevel.Error, string.Format("Digital Receiver Template file conversion failed: {0}", ex.ToString()));
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Error, string.Format("Digital Receiver Template file conversion failed: {0}", ex.ToString()));
            }
            return false;
        }

        /// <summary>
        /// Export digital receiver template to a XML file
        /// </summary>
        /// <param name="xmlFilePath">XML file path</param>
        /// <returns>True if export is successful / False otherwise.</returns>
        internal bool ExportToXML(string xmlFilePath)
        {
            XmlTextWriter templateWriter = null;

            try
            {
                using (templateWriter = new XmlTextWriter(xmlFilePath, Encoding.UTF8))
                {
                    // Use indenting for readability.
                    templateWriter.Formatting = Formatting.Indented;

                    // Write the XML declaration. 
                    templateWriter.WriteStartDocument(true);

                    // Write the template root element
                    try
                    {
                        templateWriter.WriteStartElement("OpenPacomToDigitalReceiver8003Template");
                        templateWriter.WriteAttributeString("xmlns", "xsi", null, "http://www.w3.org/2001/XMLSchema-instance");

                        int cidEntriesCount = this[DigitalReceiverMessageFormat.ContactId];
                        int siaEntriesCount = this[DigitalReceiverMessageFormat.Sia];
                        // Write digital receiver template ID
                        templateWriter.WriteElementString("TemplateId", "OpenPacomToContactIDSia_8003_Default");

                        // Add template conversion entries
                        if (cidEntriesCount > 0 || siaEntriesCount > 0)
                        {
                            templateWriter.WriteStartElement("ConversionEntries");
                            if (cidEntriesCount > 0)
                            {
                                Dictionary<int, List<OpenPacomToDigitalReceiverTemplateEntry>> entries = conversionEntries[DigitalReceiverMessageFormat.ContactId];
                                templateWriter.WriteComment(Environment.NewLine + "    Contact ID format" + Environment.NewLine + "    ");
                                foreach (var hash in entries.Keys)
                                {
                                    foreach (var digitalReceiverTemplateEntry in entries[hash])
                                    {
                                        digitalReceiverTemplateEntry.ExportToXML(templateWriter);
                                    }
                                }
                            }
                            if (siaEntriesCount > 0)
                            {
                                Dictionary<int, List<OpenPacomToDigitalReceiverTemplateEntry>> entries = conversionEntries[DigitalReceiverMessageFormat.Sia];
                                templateWriter.WriteComment(Environment.NewLine + "    SIA DC-03 format" + Environment.NewLine + "    ");
                                foreach (var hash in entries.Keys)
                                {
                                    foreach (var digitalReceiverTemplateEntry in entries[hash])
                                    {
                                        digitalReceiverTemplateEntry.ExportToXML(templateWriter);
                                    }
                                }
                            }
                            templateWriter.WriteEndElement();
                        }
                    }
                    finally
                    {
                        // Write root element end tag
                        templateWriter.WriteEndElement();
                    }

                    // Write XML document end
                    templateWriter.WriteEndDocument();

                    // Write the XML to file and close the writer.
                    templateWriter.Flush();
                    return templateWriter.BaseStream.Length > 0 && File.Exists(xmlFilePath) == true;
                }
            }
            catch (IOException ex)
            {
                Logger.LogMessage(LoggingLevel.Error, string.Format("Save OpenPacom to Digital Receiver conversion template has failed. {0}", ex));
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Error, string.Format("Save OpenPacom to Digital Receiver conversion template has failed. {0}", ex));
            }

            return false;
        }

        private static bool tryParseInteger(string inputValue, out int parsedValue)
        {
            parsedValue = 0;
            if (string.IsNullOrEmpty(inputValue))
                return false;

            try
            {
                parsedValue = int.Parse(inputValue);
                return true;
            }
            catch
            {
            }
            return false;
        }
    }
}
