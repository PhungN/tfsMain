﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Core.Contracts;
using System.Diagnostics;
using Pacom.Serialization.Formatters.Asn1;
using System.IO;
using Pacom.ConfigurationEditor.WPF;
using Pacom.Core.Attributes;
using Pacom.ConfigurationEditor.WPF.View;

namespace Pacom.Peripheral.Common.Configuration
{
    public enum ConfigurationType { None, Gms, Unison }
    public static class ConfigurationManager
    {
        #region Configuration Storage
        private static Device8003Configuration controllerConfiguration;
        public static Device8003Configuration ControllerConfiguration
        {
            get { return controllerConfiguration; }
            set { controllerConfiguration = value; }
        }

        private static Calendar calendar;
        public static Calendar Calendar
        {
            get { return calendar; }
            set { calendar = value; }
        }

        //private static VaultController8003Configuration vaultConfiguration;
        //public static VaultController8003Configuration VaultConfiguration
        //{
        //    get { return vaultConfiguration; }
        //    set { vaultConfiguration = value; }
        //}

        private static SortedList<int, DeviceConfigurationBase> devices = new SortedList<int, DeviceConfigurationBase>();
        public static SortedList<int, DeviceConfigurationBase> Devices
        {
            get { return devices; }
            set { devices = value; }
        }

        private static SortedList<int, ExpansionCardDeviceConfigurationBase> expansionCards = new SortedList<int, ExpansionCardDeviceConfigurationBase>();
        public static SortedList<int, ExpansionCardDeviceConfigurationBase> ExpansionCards
        {
            get { return expansionCards; }
            set { expansionCards = value; }
        }

        private static SortedList<int, Port8003ConfigurationBase> ports = new SortedList<int, Port8003ConfigurationBase>();
        public static SortedList<int, Port8003ConfigurationBase> Ports
        {
            get { return ports; }
        }

        private static SortedList<int, ControllerConnection8003Table> controllerConnectionTables = new SortedList<int, ControllerConnection8003Table>();
        public static SortedList<int, ControllerConnection8003Table> ControllerConnectionTables
        {
            get { return controllerConnectionTables; }
        }

        private static SortedList<int, Group8003Configuration> groups = new SortedList<int, Group8003Configuration>();
        public static SortedList<int, Group8003Configuration> Groups
        {
            get { return groups; }
            set { groups = value; }
        }

        private static SortedList<int, LegacyCardFormat> cardFormats = new SortedList<int, LegacyCardFormat>();
        public static SortedList<int, LegacyCardFormat> CardFormats
        {
            get { return cardFormats; }
        }

        private static SortedList<int, Input8003Configuration> inputs = new SortedList<int, Input8003Configuration>();
        public static SortedList<int, Input8003Configuration> Inputs
        {
            get { return inputs; }
        }

        private static SortedList<int, Output8003Configuration> outputs = new SortedList<int, Output8003Configuration>();
        public static SortedList<int, Output8003Configuration> Outputs
        {
            get { return outputs; }
        }

        private static SortedList<int, Elevator8003Configuration> unisonElevators = new SortedList<int, Elevator8003Configuration>();
        private static SortedList<int, LegacyElevator8003Configuration> legacyElevators = new SortedList<int, LegacyElevator8003Configuration>();
        public static SortedList<int, Elevator8003Configuration> UnisonElevators
        {
            get { return unisonElevators; }
        }
        public static SortedList<int, LegacyElevator8003Configuration> LegacyElevators
        {
            get { return legacyElevators; }
        }

        private static SortedList<int, ElevatorFloor8003Configuration> elevatorFloors = new SortedList<int, ElevatorFloor8003Configuration>();
        public static SortedList<int, ElevatorFloor8003Configuration> ElevatorFloors
        {
            get { return elevatorFloors; }
        }

        private static SortedList<int, Door8003Configuration> doors = new SortedList<int, Door8003Configuration>();
        public static SortedList<int, Door8003Configuration> Doors
        {
            get { return doors; }
        }

        private static SortedList<int, Interlock8003Configuration> interlockGroups = new SortedList<int, Interlock8003Configuration>();
        public static SortedList<int, Interlock8003Configuration> InterlockGroups
        {
            get { return interlockGroups; }
        }

        private static SortedList<int, VaultControllerInterlock8003Configuration> vaultControllerInterlockGroups = new SortedList<int, VaultControllerInterlock8003Configuration>();
        public static SortedList<int, VaultControllerInterlock8003Configuration> VaultControllerInterlockGroups
        {
            get { return vaultControllerInterlockGroups; }
        }

        private static SortedList<int, Macro8003Configuration> macros = new SortedList<int, Macro8003Configuration>();
        public static SortedList<int, Macro8003Configuration> Macros
        {
            get { return macros; }
        }

        private static SortedList<int, PresenceZone8003Configuration> presenceZones = new SortedList<int, PresenceZone8003Configuration>();
        public static SortedList<int, PresenceZone8003Configuration> PresenceZones
        {
            get { return presenceZones; }
        }

        private static SortedList<int, Reader8003LegacyWiegandConfiguration> readers = new SortedList<int, Reader8003LegacyWiegandConfiguration>();
        public static SortedList<int, Reader8003LegacyWiegandConfiguration> Readers
        {
            get { return readers; }
        }

        private static SortedList<int, OpenPacomToDigitalReceiver8003Template> openPacomToDigitalReceiverTemplates = new SortedList<int, OpenPacomToDigitalReceiver8003Template>();
        public static SortedList<int, OpenPacomToDigitalReceiver8003Template> OpenPacomToDigitalReceiverTemplates
        {
            get { return openPacomToDigitalReceiverTemplates; }
            set { openPacomToDigitalReceiverTemplates = value; }
        }

        private static SortedList<int, Area8003Configuration> areas = new SortedList<int, Area8003Configuration>();
        public static SortedList<int, Area8003Configuration> Areas
        {
            get { return areas; }
        }

        private static SortedList<int, Schedule> schedules = new SortedList<int, Schedule>();
        public static SortedList<int, Schedule> Schedules
        {
            get { return schedules; }
        }

        private static SortedList<int, User8003Configuration> users = new SortedList<int, User8003Configuration>();
        public static SortedList<int, User8003Configuration> Users
        {
            get { return users; }
        }

        private static SortedList<int, Reader8003Configuration> unisonReaders = new SortedList<int, Reader8003Configuration>();
        public static SortedList<int, Reader8003Configuration> UnisonReaders
        {
            get { return unisonReaders; }
        }

        private static SortedList<int, User> unisonUsers = new SortedList<int, User>();
        public static SortedList<int, User> UnisonUsers
        {
            get { return unisonUsers; }
        }

        private static SortedList<int, AccessGroup> unisonAccessGroups = new SortedList<int, AccessGroup>();
        public static SortedList<int, AccessGroup> UnisonAccessGroups
        {
            get { return unisonAccessGroups; }
        }

        public static void Clear()
        {
            controllerConfiguration = null;
            calendar = null;
            controllerConnectionTables.Clear();
            devices.Clear();
            areas.Clear();
            inputs.Clear();
            outputs.Clear();
            unisonElevators.Clear();
            legacyElevators.Clear();
            elevatorFloors.Clear();
            doors.Clear();
            interlockGroups.Clear();
            vaultControllerInterlockGroups.Clear();
            groups.Clear();
            presenceZones.Clear();
            readers.Clear();
            ports.Clear();
            users.Clear();
            macros.Clear();
            cardFormats.Clear();
            expansionCards.Clear();
            schedules.Clear();
            openPacomToDigitalReceiverTemplates.Clear();
            unisonReaders.Clear();
            unisonUsers.Clear();
            unisonAccessGroups.Clear();
        }
        #endregion

        #region Next IDs
        private static int getNextAvailableId(List<int> usedIds, int firstId = 1)
        {
            for (int i = firstId; i < int.MaxValue; i++)
            {
                if (usedIds.Contains(i) == false)
                    return i;
            }
            return -1;
        }

        private static int NextDeviceIdForDeviceType(HardwareType hardwareType)
        {
            List<int> usedIds = new List<int>(devices.Count + expansionCards.Count);
            usedIds.AddRange(devices.Keys);
            usedIds.AddRange(expansionCards.Keys);
            usedIds.Add(controllerConfiguration.Id);

            if (hardwareType == HardwareType.Pacom8101 || hardwareType == HardwareType.Pacom8101A)
                return getNextAvailableId(usedIds);
            if (hardwareType == HardwareType.Pacom8303 || hardwareType == HardwareType.Pacom8308)
            {
                int id = getNextAvailableId(usedIds, 9);
                if (id > 12)
                    return getNextAvailableId(usedIds);
                return id;
            }

            return getNextAvailableId(usedIds, 13);
        }

        public static int NextAreaId
        {
            get
            {
                return getNextAvailableId(new List<int>(areas.Keys));
            }
        }

        public static int NextInputId
        {
            get
            {
                return getNextAvailableId(new List<int>(inputs.Keys));
            }
        }

        public static int NextOutputId
        {
            get
            {
                return getNextAvailableId(new List<int>(outputs.Keys));
            }
        }

        public static int NextElevatorId
        {
            get
            {
                return Math.Max(getNextAvailableId(new List<int>(unisonElevators.Keys)), getNextAvailableId(new List<int>(legacyElevators.Keys)));
            }
        }

        public static int NextElevatorFloorId
        {
            get
            {
                return getNextAvailableId(new List<int>(elevatorFloors.Keys));
            }
        }
        public static int NextReaderId
        {
            get
            {
                return Math.Max(getNextAvailableId(new List<int>(readers.Keys)), getNextAvailableId(new List<int>(unisonReaders.Keys)));
            }
        }

        public static int NextDoorId
        {
            get
            {
                return getNextAvailableId(new List<int>(doors.Keys));
            }
        }

        public static int NextInterlockGroupId
        {
            get
            {
                return getNextAvailableId(new List<int>(InterlockGroups.Keys));
            }
        }

        public static int NextVaultControllerInterlockGroupId
        {
            get
            {
                return getNextAvailableId(new List<int>(VaultControllerInterlockGroups.Keys));
            }
        }

        public static int NextPortId
        {
            get
            {
                return getNextAvailableId(new List<int>(ports.Keys));
            }
        }

        public static int NextPresenceZoneId
        {
            get
            {
                return getNextAvailableId(new List<int>(presenceZones.Keys));
            }
        }

        public static int NextScheduleId
        {
            get
            {
                return getNextAvailableId(new List<int>(schedules.Keys));
            }
        }

        public static int NextGroupId
        {
            get
            {
                return getNextAvailableId(new List<int>(Groups.Keys));
            }
        }

        public static int NextUserId
        {
            get
            {
                return getNextAvailableId(new List<int>(Users.Keys));
            }
        }

        public static int NextCardFormatId
        {
            get
            {
                return getNextAvailableId(new List<int>(cardFormats.Keys));
            }
        }

        public static int NextMacroId
        {
            get
            {
                return getNextAvailableId(new List<int>(macros.Keys));
            }
        }

        public static int NextUnisonReaderId
        {
            get
            {
                return getNextAvailableId(new List<int>(unisonReaders.Keys));
            }
        }

        public static int NextUnisonUserId
        {
            get
            {
                return getNextAvailableId(new List<int>(unisonUsers.Keys));
            }
        }

        public static int NextUnisonAccessGroupId
        {
            get
            {
                return getNextAvailableId(new List<int>(unisonAccessGroups.Keys));
            }
        }

        #endregion

        private static void removeDevicesWhere<T>(SortedList<int, T> list, Func<T, bool> test) where T : NodeConfiguration
        {
            List<int> toRemove = new List<int>();
            foreach (T node in list.Values)
            {
                if (test(node) == true)
                {
                    toRemove.Add(node.Id);
                }
            }
            foreach (int id in toRemove)
            {
                list.Remove(id);
            }
        }

        public static void RemoveDevice(int deviceId)
        {
            ExpansionCards.Remove(deviceId);
            Devices.Remove(deviceId);

            removeDevicesWhere(inputs, node => node.ParentDeviceId == deviceId);
            removeDevicesWhere(outputs, node => node.ParentDeviceId == deviceId);
            removeDevicesWhere(readers, node => node.ParentDeviceId == deviceId);
            removeDevicesWhere(unisonReaders, node => node.ParentDeviceId == deviceId);
            removeDevicesWhere(doors, node => node.ParentDeviceId == deviceId);

            // Expansion card on the 8003, remove associated ports
            ExpansionCardDeviceConfigurationBase expansionCard;
            if (ExpansionCards.TryGetValue(deviceId, out expansionCard) &&  // is an expansion card
                expansionCard.ParentDeviceId == controllerConfiguration.Id) // on the 8003 itself
            {
                if (expansionCard.ExpansionCardSlot == 1)
                {
                    removeDevicesWhere(ports, node => node.PortNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot1);
                }
                else if (expansionCard.ExpansionCardSlot == 2)
                {
                    removeDevicesWhere(ports, node => node.PortNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot2);
                }
            }

            // Recursively remove devices where the device itself can have children
            List<int> childDevices = new List<int>();
            foreach (DeviceConfigurationBase node in devices.Values)
            {
                if (node.ParentDeviceId == deviceId)
                    childDevices.Add(node.Id);
            }
            foreach (DeviceConfigurationBase node in expansionCards.Values)
            {
                if (node.ParentDeviceId == deviceId)
                    childDevices.Add(node.Id);
            }
            foreach (int id in childDevices)
            {
                RemoveDevice(id);
            }
        }

        public static void Remove(ConfigurationBase configuration)
        {
            App.ConfigurationModified = true;
 
            NodeConfiguration nodeConfiguration = configuration as NodeConfiguration;
            if (nodeConfiguration != null)
            {
                switch (nodeConfiguration.Category)
                {
                    case NodeCategory.Port:
                        Ports.Remove(configuration.Id);
                        break;
                    case NodeCategory.Device:
                        DeviceConfigurationBase device = configuration as DeviceConfigurationBase;
                        if(device != null && device.HardwareType == HardwareType.Pacom1065ElevatorController)
                        {
                            DeviceLoopDeviceConfigurationBase deviceLoopDevice = device as DeviceLoopDeviceConfigurationBase;
                            if(deviceLoopDevice != null)
                            {
                                ElevatorConfigurationViewBase.RemoveSelectedFloorControllerAddress(deviceLoopDevice.DeviceLoopAddress);
                            }
                        }
                        RemoveDevice(configuration.Id);
                        break;
                    case NodeCategory.Macro:
                        Macros.Remove(configuration.Id);
                        break;
                    case NodeCategory.PresenceZone:
                        PresenceZones.Remove(configuration.Id);
                        break;
                    case NodeCategory.Reader:
                        if(configuration is Reader8003LegacyWiegandConfiguration)
                            Readers.Remove(configuration.Id);
                        else if(configuration is Reader8003Configuration)
                            UnisonReaders.Remove(configuration.Id);
                        break;
                    case NodeCategory.Door:
                        Doors.Remove(configuration.Id);
                        break;
                    case NodeCategory.Interlock:
                        InterlockGroups.Remove(configuration.Id);
                        break;
                    case NodeCategory.VaultControllerInterlock:
                        VaultControllerInterlockGroups.Remove(configuration.Id);
                        break;
                    case NodeCategory.Area:
                        Areas.Remove(configuration.Id);
                        break;
                    case NodeCategory.Input:
                        Inputs.Remove(configuration.Id);
                        break;
                    case NodeCategory.Output:
                        Outputs.Remove(configuration.Id);
                        break;
                    case NodeCategory.Elevator:
                        ElevatorConfigurationViewBase.RemoveSelectedFloorControllerAddress(configuration as Elevator8003Configuration);
                        if (configuration is LegacyElevator8003Configuration)
                            LegacyElevators.Remove(configuration.Id);
                        else
                            UnisonElevators.Remove(configuration.Id);
                        break;
                    case NodeCategory.Floor:
                        ElevatorFloors.Remove(configuration.Id);
                        break;
                }
            }
            else
            {
                if (configuration is Schedule)
                    Schedules.Remove(configuration.Id);
                else if (configuration is LegacyCardFormat)
                    removeCardFormat(configuration.Id);                    
                else if (configuration is AccessGroup)
                    UnisonAccessGroups.Remove(configuration.Id);
                else if (configuration is Group8003Configuration)
                    Groups.Remove(configuration.Id);
                else if (configuration is User8003Configuration)
                    Users.Remove(configuration.Id);
                else if (configuration is User)
                    UnisonUsers.Remove(configuration.Id);
            }

            ConfigurationEditor.WPF.View.NodeTreeView.LoadTree();
            ConfigurationEditor.WPF.View.NodeTreeView.SetSelection(null);
        }

        private static void removeCardFormat(int id)
        {
            // Remove the card format
            CardFormats.Remove(id);

            // And remove it from any readers that reference it
            foreach (Reader8003LegacyWiegandConfiguration reader in Readers.Values)
            {
                if (reader.CardFormatIds == null)
                {
                    continue;
                }
                List<int> newCardFormats = new List<int>();
                foreach (int formatId in reader.CardFormatIds)
                {
                    if (formatId != id)
                    {
                        newCardFormats.Add(formatId);
                    }
                }
                reader.CardFormatIds = newCardFormats.ToArray();
            }
        }

        #region AutoConfigure
        private static void createInputsOutputsDoorsAndReaders(DeviceConfigurationBase device)
        {
            int inputs = ControllerConfigurationManager.GetAvailableDevicePoints(device.Id, typeof(Input8003Configuration), 0).Count;
            int outputs = ControllerConfigurationManager.GetAvailableDevicePoints(device.Id, typeof(Output8003Configuration), 0).Count;
            int doors = ControllerConfigurationManager.GetAvailableDevicePoints(device.Id, typeof(Door8003Configuration), 0).Count;
            int readers = ControllerConfigurationManager.GetAvailableDevicePoints(device.Id, typeof(Reader8003LegacyWiegandConfiguration), 0).Count;

            if (device.GetType() == typeof(Device8208ExpansionConfiguration))
            {
                inputs = 0;
                outputs = 0;
            }
            else if (device.GetType() == typeof(Device8603DCConfiguration))
            {
                inputs = 2;
                outputs = 0;
            }
            else if (device.GetType() == typeof(Device8501DCConfiguration))
            {
                doors = 0;
                readers = 0;
            }
            else if (device.GetType() == typeof(Device1065IOConfiguration))
            {
                inputs = 16;
                outputs = 4;
                doors = 0;
                readers = 0;
            }
            else if (readers > 0)
            {
                inputs = 0;
                outputs = 0;
            }

            for (int i = 0; i < inputs; i++)
            {
                Input8003Configuration input = new Input8003Configuration();
                AutoConfigure(input, device.Id, i + 1);
            }
            for (int i = 0; i < outputs; i++)
            {
                Output8003Configuration output = new Output8003Configuration();
                AutoConfigure(output, device.Id, i + 1);
            }

            Reader8003Configuration[] deviceReaders = new Reader8003Configuration[readers];
            for (int i = 0; i < readers; i++)
            {
                if (ConfigurationType == ConfigurationType.Unison)
                {
                    Reader8003Configuration reader = new Reader8003Configuration();
                    AutoConfigure(reader, device.Id, i + 1);
                    deviceReaders[i] = reader;
                }
                else
                {
                    Reader8003LegacyWiegandConfiguration reader = new Reader8003LegacyWiegandConfiguration();
                    AutoConfigure(reader, device.Id, i + 1);
                    deviceReaders[i] = reader;
                }
            }

            if (readers == 1 && doors == 1)
            {
                Door8003Configuration door = new Door8003Configuration();
                AutoConfigure(door, device.Id, 1, deviceReaders[0], null);
            }
            else if (readers == 2 && doors == 1)
            {
                Door8003Configuration door = new Door8003Configuration();
                AutoConfigure(door, device.Id, 1, deviceReaders[0], deviceReaders[1]);
            }
            else if (readers == 2 && doors == 2)
            {
                Door8003Configuration door = new Door8003Configuration();
                AutoConfigure(door, device.Id, 1, deviceReaders[0], null);
                door = new Door8003Configuration();
                AutoConfigure(door, device.Id, 2, deviceReaders[1], null);
            }
            else if (readers == 4 && doors == 2)
            {
                Door8003Configuration door = new Door8003Configuration();
                AutoConfigure(door, device.Id, 1, deviceReaders[0], deviceReaders[2]);
                door = new Door8003Configuration();
                AutoConfigure(door, device.Id, 2, deviceReaders[1], deviceReaders[3]);
            }
        }

        public static void UpdateName(NodeConfiguration configurationNode, int pointOnParent)
        {
            Type configurationType = configurationNode.GetType();
            NodeConfiguration tempConfiguration = (NodeConfiguration)Activator.CreateInstance(configurationType);
            AutoConfigure(tempConfiguration, configurationNode.ParentDeviceId, pointOnParent, true);
            configurationNode.Name = tempConfiguration.Name;
        }

        private static ConfigurationBase configureInputConfiguration(ConfigurationBase configuration, int parent, int pointOnParent)
        {
            Input8003Configuration inputConfiguration = configuration as Input8003Configuration;
            if (inputConfiguration != null)
            {
                inputConfiguration.SetDefaults();
                inputConfiguration.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
                inputConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                inputConfiguration.Id = NextInputId;
                if (ControllerHasCapacity<Input8003Configuration>() == false)
                    inputConfiguration.Enabled = false;
                inputConfiguration.ParentDeviceId = parent;
                inputConfiguration.PointNumberOnParent = pointOnParent;
                inputConfiguration.Name = getNodeName(parent, pointOnParent, inputConfiguration.GetType());
                return inputConfiguration;
            }
            return null;
        }
        public static void AutoConfigure(ConfigurationBase configuration, int parent, int pointOnParent, bool tempConfig = false)
        {
            ExpansionCardDeviceConfigurationBase expansionCardDeviceConfiguration = configuration as ExpansionCardDeviceConfigurationBase;
            if (expansionCardDeviceConfiguration != null)
            {
                expansionCardDeviceConfiguration.SetDefaults();
                expansionCardDeviceConfiguration.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                expansionCardDeviceConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                expansionCardDeviceConfiguration.Id = NextDeviceIdForDeviceType(expansionCardDeviceConfiguration.HardwareType);
                expansionCardDeviceConfiguration.ExpansionCardSlot = pointOnParent;
                expansionCardDeviceConfiguration.ParentDeviceId = parent;
                expansionCardDeviceConfiguration.Name = string.Format("{0}-{1}", expansionCardDeviceConfiguration.GetType().Name.ToString().Replace("Device","").Replace("ExpansionConfiguration", "").Replace("8201", Translation.GetTranslatedMisc("Cellular")), expansionCardDeviceConfiguration.Id);
                expansionCards[expansionCardDeviceConfiguration.Id] = expansionCardDeviceConfiguration;

                Type portToCreate = null;
                List<object> customAttributes = expansionCardDeviceConfiguration.GetType().GetCustomAttributes(false).ToList();
                foreach (object customAttribute in customAttributes)
                {
                    MaximumNodesAttribute maximumNodesAttribute = customAttribute as MaximumNodesAttribute;
                    if (maximumNodesAttribute != null)
                    {
                        if (maximumNodesAttribute.NodeType.BaseType == typeof(Port8003ConfigurationBase))
                        {
                            portToCreate = maximumNodesAttribute.NodeType;
                            break;
                        }
                    }
                }

                createInputsOutputsDoorsAndReaders(expansionCardDeviceConfiguration);
                if (parent == controllerConfiguration.Id && portToCreate != null)
                {
                    if (portToCreate == typeof(Port8003GprsPortConfiguration))
                    {
                        Port8003GprsPortConfiguration port = new Port8003GprsPortConfiguration();
                        port.SetDefaults();
                        port.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                        port.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                        port.Id = NextPortId;
                        port.ParentDeviceId = controllerConfiguration.Id;
                        if (expansionCardDeviceConfiguration.ExpansionCardSlot == 1)
                            port.PortNumberOnParent = Pacom8003PhysicalPort.ExpansionSlot1;
                        else
                            port.PortNumberOnParent = Pacom8003PhysicalPort.ExpansionSlot2;
                        port.Name = Translation.GetTranslatedPortShortName(port.PortNumberOnParent) + " " + Translation.GetTranslatedMisc("GPRS");
                        port.InitializationString = string.Empty;
                        port.DialModifier = string.Empty;
                        ports[port.Id] = port;
                    }
                    else if (portToCreate == typeof(Port8003RS485PortConfiguration))
                    {
                        Port8003RS485DeviceLoopPortConfiguration port = new Port8003RS485DeviceLoopPortConfiguration();
                        Pacom8003PhysicalPort portNumberOnParent;
                        if (expansionCardDeviceConfiguration.ExpansionCardSlot == 1)
                            portNumberOnParent = Pacom8003PhysicalPort.ExpansionSlot1;
                        else
                            portNumberOnParent = Pacom8003PhysicalPort.ExpansionSlot2;
                        AutoConfigure(port, ControllerConfiguration.Id, portNumberOnParent, null);
                    }
                    else if (portToCreate == typeof(Port8003DialupPortConfiguration))
                    {
                        Port8003DialupPortConfiguration port = new Port8003DialupPortConfiguration();
                        port.SetDefaults();
                        port.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                        port.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                        port.Id = NextPortId;
                        port.ParentDeviceId = controllerConfiguration.Id;
                        if (expansionCardDeviceConfiguration.ExpansionCardSlot == 1)
                            port.PortNumberOnParent = Pacom8003PhysicalPort.ExpansionSlot1;
                        else
                            port.PortNumberOnParent = Pacom8003PhysicalPort.ExpansionSlot2;
                        port.Name = Translation.GetTranslatedPortShortName(port.PortNumberOnParent) + " " + Translation.GetTranslatedMisc("Dialup");
                        port.InitializationString = string.Empty;
                        port.ToneDialing = true;
                        port.StopBits = System.IO.Ports.StopBits.One;
                        ports[port.Id] = port;
                    }
                }
                return;
            }

            DeviceLoopDeviceConfigurationBase peripheralDeviceConfiguration = configuration as DeviceLoopDeviceConfigurationBase;
            if (peripheralDeviceConfiguration != null)
            {
                peripheralDeviceConfiguration.SetDefaults();
                peripheralDeviceConfiguration.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
                peripheralDeviceConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                peripheralDeviceConfiguration.Id = NextDeviceIdForDeviceType(peripheralDeviceConfiguration.HardwareType);
                peripheralDeviceConfiguration.DeviceLoopAddress = pointOnParent;
                peripheralDeviceConfiguration.ParentDeviceId = parent;
                devices[peripheralDeviceConfiguration.Id] = peripheralDeviceConfiguration;

                if (peripheralDeviceConfiguration is Device8003KeypadConfiguration)
                {
                    // Don't create the I/O/D/R on the keypad
                    peripheralDeviceConfiguration.Name = string.Format("{0}-{1}", Translation.GetTranslatedString(peripheralDeviceConfiguration.GetType()), peripheralDeviceConfiguration.Id);
                }
                else
                {
                    peripheralDeviceConfiguration.Name = string.Format("{0}-{1}", peripheralDeviceConfiguration.GetType().Name.ToString().Replace("Device", "").Replace("Configuration", "").Replace("PowerSupply", "").Replace("Keypad", ""), peripheralDeviceConfiguration.Id);
                    if (peripheralDeviceConfiguration is Device8501ECConfiguration)
                        peripheralDeviceConfiguration.Name = peripheralDeviceConfiguration.Name.Replace("8501", "");
                    //else if(peripheralDeviceConfiguration is Device1076VCConfiguration)
                    //{
                    //    var vcDevice = peripheralDeviceConfiguration as Device1076VCConfiguration;
                    //    List<int> usedIds = new List<int>();
                    //    foreach (var device in devices.Values)
                    //    {
                    //        if(device is Device1076VCConfiguration && device != vcDevice)
                    //        {
                    //            usedIds.Add(((Device1076VCConfiguration)device).VaultControllerNumber);
                    //        }
                    //    }
                    //    vcDevice.VaultControllerNumber = getNextAvailableId(usedIds);
                    //}
                    createInputsOutputsDoorsAndReaders(peripheralDeviceConfiguration);
                }
                return;
            }

            InovonicsDeviceConfigurationBase inovonicsDeviceConfiguration = configuration as InovonicsDeviceConfigurationBase;
            if (inovonicsDeviceConfiguration != null)
            {
                inovonicsDeviceConfiguration.SetDefaults();
                inovonicsDeviceConfiguration.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
                inovonicsDeviceConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                inovonicsDeviceConfiguration.DeviceLoopAddress = 0;
                inovonicsDeviceConfiguration.ParentDeviceId = parent;

                if (inovonicsDeviceConfiguration is InovonicsReceiverDeviceConfiguration)
                {
                    inovonicsDeviceConfiguration.DeviceType = InovonicsDeviceType.ES4000;
                    inovonicsDeviceConfiguration.Id = NextDeviceIdForDeviceType(HardwareType.InovonicsSerialReceiver);
                }
                else if (inovonicsDeviceConfiguration is InovonicsRepeaterDeviceConfiguration)
                {
                    inovonicsDeviceConfiguration.DeviceType = InovonicsDeviceType.ES5000;
                    inovonicsDeviceConfiguration.Id = NextDeviceIdForDeviceType(HardwareType.InovonicsRepeater);
                }
                else
                {
                    inovonicsDeviceConfiguration.DeviceType = InovonicsDeviceType.ES1233S;
                    inovonicsDeviceConfiguration.Id = NextDeviceIdForDeviceType(HardwareType.InovonicsTransceiver);
                }
                inovonicsDeviceConfiguration.Name = inovonicsDeviceConfiguration.DeviceType.ToString();
                devices[inovonicsDeviceConfiguration.Id] = inovonicsDeviceConfiguration;

                if (inovonicsDeviceConfiguration.DeviceType == InovonicsDeviceType.ES1233S)
                {
                    // Add 1 input
                    Input8003Configuration input = new Input8003Configuration();
                    AutoConfigure(input, inovonicsDeviceConfiguration.Id, 1);
                }
                return;
            }

            Reader8003LegacyWiegandConfiguration readerLegacyWiegandConfiguration = configuration as Reader8003LegacyWiegandConfiguration;
            if (readerLegacyWiegandConfiguration != null)
            {
                readerLegacyWiegandConfiguration.SetDefaults();
                readerLegacyWiegandConfiguration.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
                readerLegacyWiegandConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                readerLegacyWiegandConfiguration.Id = NextReaderId;
                if (ControllerHasCapacity<Reader8003LegacyWiegandConfiguration>() == false)
                    readerLegacyWiegandConfiguration.Enabled = false;
                readerLegacyWiegandConfiguration.ParentDeviceId = parent;
                readerLegacyWiegandConfiguration.PointNumberOnParent = pointOnParent;

                readerLegacyWiegandConfiguration.Name = getNodeName(parent, pointOnParent, readerLegacyWiegandConfiguration.GetType());
                readers[readerLegacyWiegandConfiguration.Id] = readerLegacyWiegandConfiguration;
                return;
            }

            Reader8003Configuration readerConfiguration = configuration as Reader8003Configuration;
            if (readerConfiguration != null)
            {
                readerConfiguration.SetDefaults();
                readerConfiguration.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
                readerConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                readerConfiguration.Id = NextReaderId;
                if (ControllerHasCapacity<Reader8003Configuration>() == false)
                    readerConfiguration.Enabled = false;
                readerConfiguration.ParentDeviceId = parent;
                readerConfiguration.PointNumberOnParent = pointOnParent;

                readerConfiguration.Name = getNodeName(parent, pointOnParent, readerConfiguration.GetType());
                unisonReaders[readerConfiguration.Id] = readerConfiguration;
                return;
            }

            //Input8003Configuration inputConfiguration = configuration as Input8003Configuration;
            //if (inputConfiguration != null)
            //{
            //    inputConfiguration.SetDefaults();
            //    inputConfiguration.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
            //    inputConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            //    inputConfiguration.Id = NextInputId;
            //    if (ControllerHasCapacity<Input8003Configuration>() == false)
            //        inputConfiguration.Enabled = false;
            //    inputConfiguration.ParentDeviceId = parent;
            //    inputConfiguration.PointNumberOnParent = pointOnParent;
            //    inputConfiguration.Name = getNodeName(parent, pointOnParent, inputConfiguration.GetType());
            //    if(tempConfig == false)
            //    inputs[inputConfiguration.Id] = inputConfiguration;
            //    return;
            //}

            var inputConfiguration = configureInputConfiguration(configuration, parent, pointOnParent);
            if (inputConfiguration != null)
            {
                if (tempConfig == false)
                    inputs[inputConfiguration.Id] = inputConfiguration as Input8003Configuration;
                return;
            }

            Output8003Configuration outputConfiguration = configuration as Output8003Configuration;
            if (outputConfiguration != null)
            {
                outputConfiguration.SetDefaults();
                outputConfiguration.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
                outputConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                outputConfiguration.Id = NextOutputId;
                if (ControllerHasCapacity<Output8003Configuration>() == false)
                    outputConfiguration.Enabled = false;
                outputConfiguration.ParentDeviceId = parent;
                outputConfiguration.PointNumberOnParent = pointOnParent;
                outputConfiguration.Name = getNodeName(parent, pointOnParent, outputConfiguration.GetType());
                outputs[outputConfiguration.Id] = outputConfiguration;
                return;
            }

            Door8003Configuration doorConfiguration = configuration as Door8003Configuration;
            if (doorConfiguration != null)
            {
                AutoConfigure(doorConfiguration, parent, pointOnParent, null, null);
                return;
            }
            Debugger.Break();
        }

        private static string getNodeName(int parentId, int nodeId, Type nodeType)
        {
            DeviceConfigurationBase parentDevice;
            if (parentId == controllerConfiguration.Id)
            {
                parentDevice = controllerConfiguration;
            }
            else
            {
                if (Devices.TryGetValue(parentId, out parentDevice) == false)
                {
                    ExpansionCardDeviceConfigurationBase expansionCard;
                    ExpansionCards.TryGetValue(parentId, out expansionCard);
                    parentDevice = expansionCard;
                }
            }
            return string.Format("{0} {1}:{2}", Translation.GetTranslatedString(nodeType), parentDevice.Name, nodeId);
        }

        public static void AutoConfigure(ConfigurationBase configuration)
        {
            Device8003Configuration deviceConfiguration = configuration as Device8003Configuration;
            if (deviceConfiguration != null)
            {
                deviceConfiguration.SetDefaults();

                int heartbeatInterval = (int)deviceConfiguration.ContactIdHeartbeatInterval.TotalSeconds;
                if (heartbeatInterval > 0)
                {
                    if (heartbeatInterval < 60)
                        deviceConfiguration.ContactIdHeartbeatInterval = TimeSpan.FromMinutes(1);
                    else
                        deviceConfiguration.ContactIdHeartbeatInterval = TimeSpan.FromMinutes((int)deviceConfiguration.ContactIdHeartbeatInterval.TotalMinutes);
                }
                deviceConfiguration.GprsDataUsageReportingStartDate = DateTime.Now;
                deviceConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                deviceConfiguration.AutoConfigureDeviceLoop = true;
                deviceConfiguration.ParentDeviceId = deviceConfiguration.Id;
                deviceConfiguration.Name = Translation.GetTranslatedDefaultName(typeof(Device8003Configuration));
                controllerConfiguration = deviceConfiguration;

                // Create onboard inputs: IN1 and IN2 only
                for (int i = 0; i < 2; i++)
                {
                    Input8003Configuration input = new Input8003Configuration();
                    AutoConfigure(input, deviceConfiguration.Id, i + 1);
                }

                // Create readers
                Reader8003LegacyWiegandConfiguration[] deviceReaders = new Reader8003LegacyWiegandConfiguration[4];
                for (int i = 0; i < deviceReaders.Length; i++)
                {
                    Reader8003LegacyWiegandConfiguration reader = new Reader8003LegacyWiegandConfiguration();
                    AutoConfigure(reader, deviceConfiguration.Id, i + 1);
                    deviceReaders[i] = reader;
                }

                // Create doors
                Door8003Configuration door = new Door8003Configuration();
                AutoConfigure(door, deviceConfiguration.Id, 1, deviceReaders[0], deviceReaders[2]);
                door = new Door8003Configuration();
                AutoConfigure(door, deviceConfiguration.Id, 2, deviceReaders[1], deviceReaders[3]);
                return;
            }

            Interlock8003Configuration interlockGroup = configuration as Interlock8003Configuration;
            if (interlockGroup != null)
            {
                interlockGroup.SetDefaults();
                interlockGroup.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                interlockGroup.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                interlockGroup.ParentDeviceId = controllerConfiguration.Id;
                interlockGroup.Id = NextInterlockGroupId;
                interlockGroup.Name = Translation.GetTranslatedString(interlockGroup.GetType()) + "-" + interlockGroup.Id.ToString();
                interlockGroups[interlockGroup.Id] = interlockGroup;
                return;
            }

            VaultControllerInterlock8003Configuration vaultControllerInterlockGroup = configuration as VaultControllerInterlock8003Configuration;
            if (vaultControllerInterlockGroup != null)
            {
                vaultControllerInterlockGroup.SetDefaults();
                vaultControllerInterlockGroup.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                vaultControllerInterlockGroup.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                vaultControllerInterlockGroup.ParentDeviceId = controllerConfiguration.Id;
                vaultControllerInterlockGroup.Id = NextInterlockGroupId;
                vaultControllerInterlockGroup.Name = Translation.GetTranslatedString(vaultControllerInterlockGroup.GetType()) + "-" + vaultControllerInterlockGroup.Id.ToString();
                vaultControllerInterlockGroups[vaultControllerInterlockGroup.Id] = vaultControllerInterlockGroup;
                return;
            }

            Group8003Configuration groupConfiguration = configuration as Group8003Configuration;
            if (groupConfiguration != null)
            {
                groupConfiguration.SetDefaults();
                groupConfiguration.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                groupConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                groupConfiguration.Id = NextGroupId;
                groupConfiguration.Name = Translation.GetTranslatedString(groupConfiguration.GetType()) + "-" + groupConfiguration.Id.ToString();
                groups[groupConfiguration.Id] = groupConfiguration;
                return;
            }

            User8003Configuration userConfiguration = configuration as User8003Configuration;
            if (userConfiguration != null)
            {
                userConfiguration.AreaIds = new int[0];
                userConfiguration.AreaAccessPrivilege = new AreaAccessPrivilege[0];

                userConfiguration.SetDefaults();
                userConfiguration.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                userConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                userConfiguration.Id = NextUserId;
                userConfiguration.Name = "Admin";
                userConfiguration.UserPin = 2461;
                userConfiguration.OutsideHoursAccess = true;
                userConfiguration.UserManagementPrivilege = true;
                userConfiguration.AutoIsolateDeisolatePoints = false;
                userConfiguration.AreaIds = new int[1] { 1 };
                userConfiguration.AreaAccessPrivilege = new AreaAccessPrivilege[1] { new AreaAccessPrivilege() { CanIsolate = true } };
                users[userConfiguration.Id] = userConfiguration;
                return;
            }

            User unisonUserConfiguration = configuration as User;
            if (unisonUserConfiguration != null)
            {
                unisonUserConfiguration.SetDefaults();
                unisonUserConfiguration.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                unisonUserConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                unisonUserConfiguration.Id = NextUserId;
                unisonUserConfiguration.AccessGroups = new UserAccess[0];
                unisonUserConfiguration.AlarmUserId = unisonUserConfiguration.Id;
                unisonUserConfiguration.Name = "Admin";
                unisonUserConfiguration.UserFlags = UserFlags.AfterHoursAccess | UserFlags.UserManagementPriviliges;
                unisonUserConfiguration.UserPin = 2461;
                unisonUserConfiguration.ValidFrom = new DateTime(1753, 1, 1);
                unisonUserConfiguration.ValidTo = new DateTime(9999, 12, 31, 23, 59, 59);
                unisonUsers[unisonUserConfiguration.Id] = unisonUserConfiguration;
                return;
            }

            Area8003Configuration areaConfiguration = configuration as Area8003Configuration;
            if (areaConfiguration != null)
            {
                areaConfiguration.SetDefaults();
                areaConfiguration.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                areaConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                areaConfiguration.Id = NextAreaId;
                areaConfiguration.ParentDeviceId = controllerConfiguration.Id;
                areaConfiguration.Name = Translation.GetTranslatedString(areaConfiguration.GetType()) + "-" + areaConfiguration.Id.ToString();
                areas[areaConfiguration.Id] = areaConfiguration;
                return;
            }

            Device8003KeypadConfiguration keypadConfiguration = configuration as Device8003KeypadConfiguration;
            if (keypadConfiguration != null)
            {
                keypadConfiguration.SetDefaults();
                keypadConfiguration.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                keypadConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                if (Areas.ContainsKey(1))
                    keypadConfiguration.AreaIds = new int[1] { 1 };
                else
                    keypadConfiguration.AreaIds = new int[0];
                keypadConfiguration.Id = NextDeviceIdForDeviceType(HardwareType.Pacom8101);
                keypadConfiguration.DeviceLoopAddress = keypadConfiguration.Id;
                keypadConfiguration.ParentDeviceId = controllerConfiguration.Id;
                devices[keypadConfiguration.Id] = keypadConfiguration;
                return;
            }

            PresenceZone8003Configuration presenceZoneConfiguration = configuration as PresenceZone8003Configuration;
            if (presenceZoneConfiguration != null)
            {
                presenceZoneConfiguration.SetDefaults();
                presenceZoneConfiguration.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
                presenceZoneConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                presenceZoneConfiguration.Id = NextPresenceZoneId;
                presenceZoneConfiguration.ParentDeviceId = controllerConfiguration.Id;
                presenceZoneConfiguration.Name = Translation.GetTranslatedString(presenceZoneConfiguration.GetType()) + "-" + presenceZoneConfiguration.Id.ToString();
                presenceZones[presenceZoneConfiguration.Id] = presenceZoneConfiguration;
                return;
            }

            LegacyCardFormat cardFormat = configuration as LegacyCardFormat;
            if (cardFormat != null)
            {
                cardFormat.SetDefaults();
                cardFormat.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
                cardFormat.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                cardFormat.Id = NextCardFormatId;
                cardFormats[cardFormat.Id] = cardFormat;
                return;
            }

            Schedule schedule = configuration as Schedule;
            if (schedule != null)
            {
                schedule.Id = NextScheduleId;
                schedule.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                schedule.Schedules = createScheduleRecords().ToArray();
                Schedules[schedule.Id] = schedule;
                return;
            }

            Macro8003Configuration macro = configuration as Macro8003Configuration;
            if (macro != null)
            {
                macro.SetDefaults();
                macro.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
                macro.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                macro.ParentDeviceId = controllerConfiguration.Id;
                macro.Id = NextMacroId;
                macro.Name = Translation.GetTranslatedString(macro.GetType()) + "-" + macro.Id.ToString();
                macros[macro.Id] = macro;
                return;
            }

            AccessGroup accessGroup = configuration as AccessGroup;
            if (accessGroup != null)
            {
                accessGroup.SetDefaults();
                accessGroup.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
                accessGroup.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                accessGroup.Id = NextUnisonAccessGroupId;
                unisonAccessGroups[accessGroup.Id] = accessGroup;
                return;
            }

            var legacyElevator = configuration as LegacyElevator8003Configuration;
            if (legacyElevator != null)
            {
                legacyElevator.SetDefaults();
                legacyElevator.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                legacyElevator.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                legacyElevator.ParentDeviceId = controllerConfiguration.Id;
                legacyElevator.Id = NextElevatorId;
                legacyElevator.Name = Translation.GetTranslatedString(legacyElevator.GetType()) + "-" + legacyElevator.Id.ToString();
                legacyElevators[legacyElevator.Id] = legacyElevator;
                return;
            }

            var elevator = configuration as Elevator8003Configuration;
            if (elevator != null)
            {
                elevator.SetDefaults();
                elevator.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                elevator.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                elevator.ParentDeviceId = controllerConfiguration.Id;
                elevator.Id = NextElevatorId;
                elevator.Name = Translation.GetTranslatedString(elevator.GetType()) + "-" + elevator.Id.ToString();
                unisonElevators[elevator.Id] = elevator;
                return;
            }

            var elevatorFloor = configuration as ElevatorFloor8003Configuration;
            if (elevatorFloor != null)
            {
                elevatorFloor.SetDefaults();
                elevatorFloor.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                elevatorFloor.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                elevatorFloor.ParentDeviceId = controllerConfiguration.Id;
                elevatorFloor.Id = NextElevatorFloorId;
                elevatorFloor.Name = Translation.GetTranslatedString(elevatorFloor.GetType()) + "-" + elevatorFloor.Id.ToString();
                elevatorFloors[elevatorFloor.Id] = elevatorFloor;
                return;
            }

            Debugger.Break();
        }

        private static void setNodeConfiguration(NodeConfiguration configuration, int id, int parentId)
        {
            if(parentId > 0)
                configuration.ParentDeviceId = parentId;
            configuration.Id = id;
            configuration.Name = $"{Translation.GetTranslatedString(configuration.GetType())}-{id}";
        }

        private static IEnumerable<ScheduleRecord> createScheduleRecords()
        {
            return new List<ScheduleRecord>
            {
                CreateScheduleRecord(DayType.Monday),
                CreateScheduleRecord(DayType.Tuesday),
                CreateScheduleRecord(DayType.Wednesday),
                CreateScheduleRecord(DayType.Thursday),
                CreateScheduleRecord(DayType.Friday),
                CreateScheduleRecord(DayType.Saturday),
                CreateScheduleRecord(DayType.Sunday),
                CreateAccessScheduleRecord(DayType.Holiday1),
                CreateAccessScheduleRecord(DayType.Holiday2),
                CreateAccessScheduleRecord(DayType.Holiday3)
            };
        }

        public static void AddConfiguration(ConfigurationBase configuration)
        {
            configuration.SetDefaults();
            configuration.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
            configuration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;

            if (configuration is Group8003Configuration)
            {
                configuration.Id = NextGroupId;
                ((Group8003Configuration)configuration).Name = Translation.GetTranslatedString(configuration.GetType()) + "-" + configuration.Id.ToString();
                groups[configuration.Id] = configuration as Group8003Configuration;
            }
            else if (configuration is Schedule)
            {
                configuration.Id = NextScheduleId;
                ((Schedule)configuration).Schedules = createScheduleRecords().ToArray();
                Schedules[configuration.Id] = configuration as Schedule;
            }
            else if (configuration is Area8003Configuration)
            {
                setNodeConfiguration(configuration as NodeConfiguration, NextAreaId, controllerConfiguration.Id);
                areas[configuration.Id] = configuration as Area8003Configuration;
            }
            else if (configuration is LegacyElevator8003Configuration)
            {
                setNodeConfiguration(configuration as NodeConfiguration, NextElevatorId, controllerConfiguration.Id);
                legacyElevators[configuration.Id] = configuration as LegacyElevator8003Configuration;
            }
            else if (configuration is Elevator8003Configuration)
            {
                setNodeConfiguration(configuration as NodeConfiguration, NextElevatorId, controllerConfiguration.Id);
                unisonElevators[configuration.Id] = configuration as Elevator8003Configuration;
            }
            else if (configuration is ElevatorFloor8003Configuration)
            {
                setNodeConfiguration(configuration as NodeConfiguration, NextElevatorFloorId, controllerConfiguration.Id);
                elevatorFloors[configuration.Id] = configuration as ElevatorFloor8003Configuration;
            }
            else if(configuration is Macro8003Configuration)
            {
                setNodeConfiguration(configuration as NodeConfiguration, NextMacroId, controllerConfiguration.Id);
                macros[configuration.Id] = configuration as Macro8003Configuration;
            }
            else if(configuration is LegacyCardFormat)
            {
                configuration.Id = NextCardFormatId;
                cardFormats[configuration.Id] = configuration as LegacyCardFormat;
            }
            else if(configuration is PresenceZone8003Configuration)
            {
                setNodeConfiguration(configuration as NodeConfiguration, NextPresenceZoneId, controllerConfiguration.Id);
                presenceZones[configuration.Id] = configuration as PresenceZone8003Configuration;
            }
            else if(configuration is Interlock8003Configuration)
            {
                setNodeConfiguration(configuration as NodeConfiguration, NextInterlockGroupId, controllerConfiguration.Id);
                interlockGroups[configuration.Id] = configuration as Interlock8003Configuration;
            }
            else if (configuration is VaultControllerInterlock8003Configuration)
            {
                setNodeConfiguration(configuration as NodeConfiguration, NextVaultControllerInterlockGroupId, controllerConfiguration.Id);
                vaultControllerInterlockGroups[configuration.Id] = configuration as VaultControllerInterlock8003Configuration;
            }
            else if(configuration is AccessGroup)
            {
                configuration.Id = NextUnisonAccessGroupId;
                unisonAccessGroups[configuration.Id] = configuration as AccessGroup;
            }
            else if(configuration is User8003Configuration)
            {
                User8003Configuration gmsUser = configuration as User8003Configuration;
                configuration.Id = NextUserId;
                gmsUser.AreaIds = new int[0];
                gmsUser.AreaAccessPrivilege = new AreaAccessPrivilege[0];
                gmsUser.Name = "Admin";
                gmsUser.UserPin = 2461;
                gmsUser.OutsideHoursAccess = true;
                gmsUser.UserManagementPrivilege = true;
                gmsUser.AutoIsolateDeisolatePoints = false;
                gmsUser.AreaIds = new int[1] { 1 };
                gmsUser.AreaAccessPrivilege = new AreaAccessPrivilege[1] { new AreaAccessPrivilege() { CanIsolate = true } };
                users[configuration.Id] = gmsUser;
            }
            else if(configuration is User)
            {
                User unisonUser = configuration as User;
                configuration.Id = NextUserId;
                unisonUser.AccessGroups = new UserAccess[0];
                unisonUser.AlarmUserId = configuration.Id;
                unisonUser.Name = "Admin";
                unisonUser.UserFlags = UserFlags.AfterHoursAccess | UserFlags.UserManagementPriviliges;
                unisonUser.UserPin = 2461;
                unisonUser.ValidFrom = new DateTime(1753, 1, 1);
                unisonUser.ValidTo = new DateTime(9999, 12, 31, 23, 59, 59);
                unisonUsers[configuration.Id] = unisonUser;
            }
        }
        public static void AddNewConfiguration(ConfigurationBase configuration)
        {
            App.ConfigurationModified = true;
            AddConfiguration(configuration);
            ConfigurationEditor.WPF.View.NodeTreeView.LoadTree();
            ConfigurationEditor.WPF.View.NodeTreeView.SetSelection(configuration);
        }
        public static void AutoConfigure(ConfigurationBase port, int parentId, Pacom8003PhysicalPort physicalPort, int? firstDeviceAddress = null)
        {
            int portId = port.Id;
            if (portId == 0)
                portId = NextPortId;
            Port8003IPPortConfiguration ipPortConfiguration = port as Port8003IPPortConfiguration;
            if (ipPortConfiguration != null)
            {
                ipPortConfiguration.SetDefaults();
                ipPortConfiguration.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                ipPortConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                ipPortConfiguration.Id = portId;
                ipPortConfiguration.ParentDeviceId = controllerConfiguration.Id;
                ipPortConfiguration.PortNumberOnParent = physicalPort;
                ipPortConfiguration.Name = Translation.GetTranslatedPortShortName(Pacom8003PhysicalPort.Ethernet);
                ports[ipPortConfiguration.Id] = ipPortConfiguration;
                return;
            }
            Port8003RS485DeviceLoopPortConfiguration deviceLoopPort = port as Port8003RS485DeviceLoopPortConfiguration;
            if (deviceLoopPort != null)
            {
                deviceLoopPort.SetDefaults();
                deviceLoopPort.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                deviceLoopPort.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                deviceLoopPort.Id = portId;
                deviceLoopPort.ParentDeviceId = parentId;
                deviceLoopPort.PortNumberOnParent = physicalPort;
                deviceLoopPort.Name = Translation.GetTranslatedPortShortName(physicalPort);

                if (firstDeviceAddress.HasValue && firstDeviceAddress > 0 && firstDeviceAddress < 66)
                    deviceLoopPort.FirstDeviceAddress = firstDeviceAddress.Value;
                else if (physicalPort == Pacom8003PhysicalPort.ExpansionSlot1)
                    deviceLoopPort.FirstDeviceAddress = 33;
                else if (physicalPort == Pacom8003PhysicalPort.ExpansionSlot2)
                    deviceLoopPort.FirstDeviceAddress = 65;
                else
                    deviceLoopPort.FirstDeviceAddress = 1;
                ports[deviceLoopPort.Id] = deviceLoopPort;
                return;
            }
            Port8003RS232DebugPortConfiguration debugPort = port as Port8003RS232DebugPortConfiguration;
            if (debugPort != null)
            {
                debugPort.SetDefaults();
                debugPort.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                debugPort.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                debugPort.Id = portId;
                debugPort.ParentDeviceId = parentId;
                debugPort.PortNumberOnParent = physicalPort;
                debugPort.Name = Translation.GetTranslatedPortShortName(Pacom8003PhysicalPort.RS232);
                ports[debugPort.Id] = debugPort;
                return;
            }
            Port8003GprsPortConfiguration gprsPort = port as Port8003GprsPortConfiguration;
            if (gprsPort != null)
            {
                gprsPort.SetDefaults();
                gprsPort.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                gprsPort.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                gprsPort.Id = portId;
                gprsPort.ParentDeviceId = parentId;
                gprsPort.PortNumberOnParent = physicalPort;
                gprsPort.Name = Translation.GetTranslatedPortShortName(physicalPort) + " " + Translation.GetTranslatedMisc("GPRS");
                gprsPort.InitializationString = string.Empty;
                gprsPort.DialModifier = string.Empty;
                ports[gprsPort.Id] = gprsPort;
                return;
            }
            Port8003DialupPortConfiguration dialupPort = port as Port8003DialupPortConfiguration;
            if (dialupPort != null)
            {
                dialupPort.SetDefaults();
                dialupPort.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                dialupPort.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                dialupPort.Id = portId;
                dialupPort.ParentDeviceId = parentId;
                dialupPort.PortNumberOnParent = physicalPort;
                dialupPort.Name = Translation.GetTranslatedPortShortName(physicalPort) + " " + Translation.GetTranslatedMisc("Dialup");
                dialupPort.InitializationString = string.Empty;
                ports[dialupPort.Id] = dialupPort;
                return;
            }
            Port8003RS485OsdpDeviceLoopPortConfiguration osdpPort = port as Port8003RS485OsdpDeviceLoopPortConfiguration;
            if (osdpPort != null)
            {
                osdpPort.SetDefaults();
                osdpPort.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                osdpPort.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                osdpPort.Id = portId;
                osdpPort.ParentDeviceId = parentId;
                osdpPort.PortNumberOnParent = physicalPort;
                osdpPort.Name = Translation.GetTranslatedPortShortName(physicalPort) + " " + Translation.GetTranslatedMisc("OSDP");
                osdpPort.SecureChannelBaseKey = null;

                ports[osdpPort.Id] = osdpPort;
                return;
            }
            Port8003RS232InovonicsPortConfiguration inovonicsPort = port as Port8003RS232InovonicsPortConfiguration;
            if (inovonicsPort != null)
            {
                inovonicsPort.SetDefaults();
                inovonicsPort.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                inovonicsPort.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                inovonicsPort.Id = portId;
                inovonicsPort.ParentDeviceId = parentId;
                inovonicsPort.PortNumberOnParent = physicalPort;
                inovonicsPort.Name = Translation.GetTranslatedPortShortName(physicalPort);
                ports[inovonicsPort.Id] = inovonicsPort;
                return;
            }
            Port8003RS485AsisProprietaryReaderPortConfiguration asisPort = port as Port8003RS485AsisProprietaryReaderPortConfiguration;
            if (asisPort != null)
            {
                asisPort.SetDefaults();
                asisPort.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                asisPort.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                asisPort.Id = portId;
                asisPort.ParentDeviceId = parentId;
                asisPort.PortNumberOnParent = physicalPort;
                asisPort.Name = Translation.GetTranslatedPortShortName(physicalPort);
                ports[asisPort.Id] = asisPort;
                return;
            }

            Port8003RS485AperioPortConfiguration aperioPort = port as Port8003RS485AperioPortConfiguration;
            if (aperioPort != null)
            {
                aperioPort.SetDefaults();
                aperioPort.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
                aperioPort.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                aperioPort.Id = portId;
                aperioPort.ParentDeviceId = parentId;
                aperioPort.PortNumberOnParent = physicalPort;
                aperioPort.Name = Translation.GetTranslatedPortShortName(physicalPort);
                aperioPort.RS485BaudRate = RS485BaudRate.Baud19200;
                ports[aperioPort.Id] = aperioPort;
                return;
            }

            AperioDriverConfiguration aperioDriver = port as AperioDriverConfiguration;
            if (aperioDriver != null)
            {
                aperioDriver.SetDefaults();
                aperioDriver.SetComplianceLevelDefaults(ControllerConfiguration.ComplianceLevel);
                aperioDriver.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
                aperioDriver.ParentDeviceId = parentId;
                aperioDriver.Id = NextDeviceIdForDeviceType(aperioDriver.HardwareType);
                aperioDriver.PortNumberOnParent = physicalPort;

                // Find the port configuration on the parent for the specified port number
                foreach (Port8003ConfigurationBase portValue in ConfigurationManager.Ports.Values)
                {
                    if (portValue.PortNumberOnParent == physicalPort)
                    {
                        aperioDriver.Name = string.Format(Translation.GetTranslatedText("AperioOnPort"), portValue.Name);
                        break;
                    }
                }
                devices[aperioDriver.Id] = aperioDriver;

                return;
            }
            Debugger.Break();
        }

        public static void DeleteAllElevatorFloors()
        {
            App.ConfigurationModified = true;
            ElevatorFloors.Clear();
            ConfigurationEditor.WPF.View.NodeTreeView.LoadTree();
            ConfigurationEditor.WPF.View.NodeTreeView.SetSelection(null);
        }
        private const int maximumInputCount = 96;
        private const int maximumOutputCount = 40;
        private const int maximumDoorCount = 8;
        private const int maximumReaderCount = 16;

        public static bool ControllerHasCapacity<T>() where T : NodeConfiguration
        {
            int enabledNodes = 0;
            int limit = 0;
            IList<T> nodeList = null;

            if (typeof(T) == typeof(Input8003Configuration))
            {
                nodeList = ConfigurationManager.Inputs.Values as IList<T>;
                limit = maximumInputCount;
            }
            else if (typeof(T) == typeof(Output8003Configuration))
            {
                nodeList = ConfigurationManager.Outputs.Values as IList<T>;
                limit = maximumOutputCount;
            }
            else if (typeof(T) == typeof(Door8003Configuration))
            {
                nodeList = ConfigurationManager.Doors.Values as IList<T>;
                limit = maximumDoorCount;
            }
            else if (typeof(T) == typeof(Reader8003LegacyWiegandConfiguration))
            {
                nodeList = ConfigurationManager.Readers.Values as IList<T>;
                limit = maximumReaderCount;
            }
            else if (typeof(T) == typeof(Reader8003Configuration))
            {
                nodeList = ConfigurationManager.UnisonReaders.Values as IList<T>;
                limit = maximumReaderCount;
            }

            foreach (NodeConfiguration node in nodeList)
            {
                if (node.Enabled)
                {
                    enabledNodes++;
                    if (enabledNodes == limit)
                        return false;
                }
            }

            return true;
        }

        public static void AutoConfigure(Door8003Configuration doorConfiguration, int parentDeviceId, int pointNumberOnParent, Reader8003Configuration inReader, Reader8003Configuration outReader)
        {
            doorConfiguration.SetDefaults();
            doorConfiguration.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
            doorConfiguration.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            doorConfiguration.Id = NextDoorId;
            doorConfiguration.ParentDeviceId = parentDeviceId;
            doorConfiguration.PointNumberOnParent = pointNumberOnParent;
            doorConfiguration.AreaId = Areas.ContainsKey(1) ? 1 : 0;
            doorConfiguration.ReaderInId = (inReader == null) ? 0 : inReader.Id;
            doorConfiguration.ReaderOutId = (outReader == null) ? 0 : outReader.Id;
            doorConfiguration.Name = getNodeName(parentDeviceId, pointNumberOnParent, doorConfiguration.GetType());
            if (ControllerHasCapacity<Door8003Configuration>() == false)
                doorConfiguration.Enabled = false;
            doors[doorConfiguration.Id] = doorConfiguration;
        }

        public static void AutoConfigure(ControllerConnection8003Table controllerConnectionTable, int id, bool createConnectionEntry)
        {
            controllerConnectionTable.SetDefaults();
            controllerConnectionTable.SetComplianceLevelDefaults(controllerConfiguration.ComplianceLevel);
            controllerConnectionTable.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            controllerConnectionTable.Id = id;

            if (createConnectionEntry)
            {
                controllerConnectionTable.ConnectionEntry = new ControllerConnection8003Entry[1];
                controllerConnectionTable.ConnectionEntry[0] = new ControllerConnection8003Entry();
                // Set Defaults for connection entry
                SetDefaults(controllerConnectionTable.ConnectionEntry[0]);
            }
            else
            {
                controllerConnectionTable.ConnectionEntry = new ControllerConnection8003Entry[0];
            }
            controllerConnectionTables[controllerConnectionTable.Id] = controllerConnectionTable;
        }

        public static void SetDefaults(object configuration)
        {
            foreach (PropertyInfo property in configuration.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (property.CanWrite)
                {
                    DefaultValueAttribute defaultAttribute = (DefaultValueAttribute)property.GetCustomAttributes(typeof(DefaultValueAttribute), false).FirstOrDefault();
                    if (defaultAttribute != null)
                    {
                        if (property.PropertyType == typeof(TimeSpan))
                        {   // Timespans should be cast from milliseconds.
                            property.SetValue(configuration, new TimeSpan(0, 0, 0, 0, (int)defaultAttribute.Value), null);
                        }
                        else
                        {
                            property.SetValue(configuration, defaultAttribute.Value, null);
                        }
                    }
                }
            }
        }

        public static ScheduleRecord CreateScheduleRecord(DayType dayType)
        {
            ScheduleRecord schedule = new ScheduleRecord();
            schedule.DayType = dayType;
            schedule.Intervals = new ScheduleInterval[1];
            ScheduleInterval interval = new ScheduleInterval();
            DateTime now = DateTime.UtcNow;
            DateTime today = new DateTime(now.Year, now.Month, now.Day);
            if (interval != null)
            {
                interval.StartTime = today;
                interval.Level = 0;
                schedule.Intervals[0] = interval;
            }
            return schedule;
        }

        public static ScheduleRecord CreateAccessScheduleRecord(DayType dayType)
        {
            ScheduleRecord schedule = new ScheduleRecord();
            schedule.DayType = dayType;
            DateTime now = DateTime.UtcNow;
            DateTime today = new DateTime(now.Year, now.Month, now.Day);
            schedule.Intervals = new ScheduleInterval[3];
            ScheduleInterval interval = new ScheduleInterval();
            if (interval != null)
            {
                interval.StartTime = today;
                interval.Level = (int)AccessLevel.Deny;
                schedule.Intervals[0] = interval;
            }
            interval = new ScheduleInterval();
            if (interval != null)
            {
                interval.StartTime = new DateTime(today.Year, today.Month, today.Day, 9, 0, 0, DateTimeKind.Local);
                interval.Level = (int)AccessLevel.Allow;
                schedule.Intervals[1] = interval;
            }
            interval = new ScheduleInterval();
            if (interval != null)
            {
                interval.StartTime = new DateTime(today.Year, today.Month, today.Day, 17, 0, 0, DateTimeKind.Local);
                interval.Level = (int)AccessLevel.Deny;
                schedule.Intervals[2] = interval;
            }
            return schedule;
        }
        #endregion

        public static ConfigurationType ConfigurationType
        {
            get
            {
                if (GmsConfigurationPresent == true)
                    return ConfigurationType.Gms;
                else if (UnisonConfigurationPresent == true)
                    return ConfigurationType.Unison;
                return ConfigurationType.None;
            }
        }
        public static bool UnisonConfigurationPresent
        {
            get
            {
                if (unisonReaders.Count > 0 || unisonUsers.Count > 0 || unisonAccessGroups.Count > 0 || UnisonElevatorsCount > 0)
                    return true;
                return false;
            }
        }

        public static bool GmsConfigurationPresent
        {
            get
            {
                if (readers.Count > 0 || users.Count > 0 || cardFormats.Count > 0 || GmsElevatorsCount > 0)
                    return true;
                return false;
            }
        }

        public static int UnisonElevatorsCount
        {
            get
            {
                if (unisonElevators == null || unisonElevators.Count == 0)
                    return 0;
                return unisonElevators.Values.Count;
            }
        }
        public static int GmsElevatorsCount
        {
            get
            {
                if (legacyElevators == null || legacyElevators.Count == 0)
                    return 0;
                return legacyElevators.Values.Count;
            }
        }
    }
}
