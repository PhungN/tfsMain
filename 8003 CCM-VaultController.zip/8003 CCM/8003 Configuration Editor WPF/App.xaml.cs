﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.IsolatedStorage;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.Windows.Markup;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.View;
using Pacom.Core.Access;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Serialization.Formatters.Asn1;

namespace Pacom.ConfigurationEditor.WPF
{
    public partial class App
    {
        public static bool ConfigurationModified { get; set; }
        public static bool FileUpdated { get; set; }
        private static List<string> resourceFiles = new List<string>();
        public static bool GmsConfigurationOnly { get; set; }

#if DEBUG
        public static bool SkipValidate;
        public static bool Closing = false;
#endif
        private static string tempPath = Path.GetTempPath();

        static App()
        {
            ConfigurationModified = false;
            FileUpdated = false;

            // Ensure the current culture passed into bindings is the OS culture.
            // By default, WPF uses en-US as the culture, regardless of the system settings.
            FrameworkElement.LanguageProperty.OverrideMetadata(typeof(FrameworkElement),
              new FrameworkPropertyMetadata(XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag)));

#if DEBUG
            // So that we can step into functions.  DLLs provided by the resolver can't be stepped into.
            if (Debugger.IsAttached)
                return;
#endif

                Assembly executingAssembly = Assembly.GetExecutingAssembly();
            string[] resourceNames = executingAssembly.GetManifestResourceNames();

            Stream resourceStream = executingAssembly.GetManifestResourceStream("Pacom.ConfigurationEditor.WPF.EmbeddedAssemblies.Pacom.Shared.Configuration.dll");
            byte[] data = new byte[resourceStream.Length];
            resourceStream.Read(data, 0, data.Length);
            resourceStream.Dispose();
            Version configurationAssemblyVersion = Assembly.Load(data).GetName().Version;

            tempPath = Path.GetTempPath() + "Pacom CCM " + " (" + configurationAssemblyVersion.Major + "." + configurationAssemblyVersion.Minor + "." + configurationAssemblyVersion.Build + ")";
            Directory.CreateDirectory(tempPath);
            foreach (string resourceName in resourceNames)
            {
                if (resourceName.Contains("EmbeddedAssemblies"))
                {
                    string filename = tempPath + "\\" + resourceName.Replace("Pacom.ConfigurationEditor.WPF.EmbeddedAssemblies.", "");
                    resourceFiles.Add(filename);

                    try
                    {
                        resourceStream = executingAssembly.GetManifestResourceStream(resourceName);
                        data = new byte[resourceStream.Length];
                        resourceStream.Read(data, 0, data.Length);
                        resourceStream.Dispose();
                        File.WriteAllBytes(filename, data);
                    }
                    catch
                    {
                    }
                }
            }

            AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(Resolver);
            AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve += new ResolveEventHandler(Resolver);
        }

        /// <summary>
        /// Tried to use Assembly.Load but the following line would return false when it should return true.
        /// Device8003Configuration controllerConfiguration = configurationItem as Device8003Configuration;
        /// </summary>
        static Assembly Resolver(object sender, ResolveEventArgs args)
        {
            string[] portions = args.Name.Split(new char[] { ',' });
            string filename = tempPath + "\\" + portions[0] + ".dll";
            if (resourceFiles.Find(file => string.Compare(file, filename, true) == 0) != null)
            {
                // This is a file we've put into the temporary folder
                try
                {
                    Assembly assembly = Assembly.LoadFrom(filename);
                    return assembly;
                }
                catch
                {
                }
            }
            return null;
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

#if DEBUG
            // This is used by the 8003 simulator
            try
            {
                string[] arguments = Environment.GetCommandLineArgs();
                if (arguments.Length == 7)
                {
                    // 8003 CCM.exe <Output Path> <Site Id> <IP Address> <Pacom .is IP Address> <8003 Listening IP Port> <Pacom .is IP Port>
                    string outputPath = arguments[1];
                    int siteId = int.Parse(arguments[2]);
                    IPAddress controllerIPAddress = IPAddress.Parse(arguments[3]);
                    IPAddress emcsIPAddress = IPAddress.Parse(arguments[4]);
                    int listeningPort = int.Parse(arguments[5]);
                    int emcsPort = int.Parse(arguments[6]);

                    if (Directory.Exists(outputPath))
                    {
                        MainWindow mainWindows = new WPF.MainWindow();
                        MenuView menuView = new MenuView();

                        string[] configurationFiles = new string[] { "areas.asn1", "devices.asn1", "doors.asn1", "inputs.asn1", "macros.asn1", "outputs.asn1", "ports.asn1", "readers.asn1", "presencezones.asn1", "schedules.asn1", "users.asn1", "calendars.asn1", "cardprofiles.asn1", "useraccessgroups.asn1", "connections.asn1", "accessgroups.asn1", "openpacomtodigitalreceivertemplate.asn1" };
                        if (File.Exists(outputPath + "\\devices.asn1"))
                        {
                            // Load an existing configuration
                            using (FileStream outputFileStream = new FileStream(outputPath + "\\localChange.asn1", FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                            {
                                foreach (string file in configurationFiles)
                                {
                                    if (File.Exists(outputPath + "\\" + file))
                                    {
                                        byte[] data = File.ReadAllBytes(outputPath + "\\" + file);
                                        outputFileStream.Write(data, 0, data.Length);
                                    }
                                }
                            }

                            if (ControllerConfigurationManager.LoadFromFile(outputPath + "\\localChange.asn1") == false)
                            {
                                Application.Current.Shutdown();
                                return;
                            }
                        }
                        else
                        {
                            // Create a new configuration
                            ControllerConfigurationManager.LoadDefaults();
                        }

                        ConfigurationManager.ControllerConfiguration.SiteId = siteId;
                        ConfigurationManager.ControllerConfiguration.PowerSupplyType = PowerSupplyType.None;
                        foreach (Port8003ConfigurationBase port in ConfigurationManager.Ports.Values)
                        {
                            Port8003IPPortConfiguration ipPort = port as Port8003IPPortConfiguration;
                            if (port is Port8003IPPortConfiguration)
                            {
                                ipPort.IPAddress = controllerIPAddress.ToString();
                                ipPort.PacomIsPortNumber = listeningPort;
                                ipPort.IPDeviceLoopPortNumber = listeningPort;
                                break;
                            }
                        }
                        bool found = false;
                        foreach (ControllerConnection8003Table connectionTable in ConfigurationManager.ControllerConnectionTables.Values)
                        {
                            foreach (ControllerConnection8003Entry entry in connectionTable.ConnectionEntry)
                            {
                                if (entry.IPDestinationAddress == emcsIPAddress.ToString() &&
                                    entry.IPDestinationPort == emcsPort)
                                {
                                    found = true;
                                    break;
                                }
                            }
                            if (found)
                                break;
                        }
                        if (found == false)
                        {
                            bool set = false;
                            foreach (ControllerConnection8003Table connectionTable in ConfigurationManager.ControllerConnectionTables.Values)
                            {
                                foreach (ControllerConnection8003Entry entry in connectionTable.ConnectionEntry)
                                {
                                    if (entry.ProtocolType == MessageFormat.Asn1)
                                    {
                                        entry.IPDestinationAddress = emcsIPAddress.ToString();
                                        entry.IPDestinationPort = emcsPort;
                                        set = true;
                                        break;
                                    }
                                }
                                if (set)
                                    break;
                            }
                        }

                        foreach (string file in configurationFiles)
                        {
                            if (File.Exists(outputPath + "\\" + file))
                                File.Delete(outputPath + "\\" + file);
                            if (File.Exists(outputPath + "\\" + file.Replace(".asn1", ".idx")))
                                File.Delete(outputPath + "\\" + file.Replace(".asn1", ".idx"));
                            if (File.Exists(outputPath + "\\" + file.Replace(".asn1", ".idxb")))
                                File.Delete(outputPath + "\\" + file.Replace(".asn1", ".idxb"));
                        }
                        ControllerConfigurationManager.SaveToFile(outputPath + "\\localChange.asn1");
                        splitConfiguration(outputPath);
                        File.Delete(outputPath + "\\localChange.asn1");

                        Application.Current.Shutdown();
                        return;
                    }
                }
            }
            catch
            {
            }
#endif

            GmsConfigurationOnly = false;
            MainWindow window = new MainWindow();
            window.Show();

            try
            {
                string[] arguments = Environment.GetCommandLineArgs();
                if (arguments.Length > 1)
                {
                    GmsConfigurationOnly = true;
                    for (int i = 0; i < 100; i++)
                    {
                        try
                        {
                                byte[] data = File.ReadAllBytes(arguments[1]);
                                if (data.Length > 0)
                                    break;
                            }
                        catch
                        {
                        }
                        Thread.Sleep(100);
                    }

                    MenuView.Instance.SetFileName(arguments[1]);
                    ControllerConfigurationManager.LoadFromFile(arguments[1]);
                }
#if DEBUG
                MenuView.Instance.SetParentWindow(window);
#endif

            }
            catch (Exception ex)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(WPF.MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.LoadingConfiguration) + " " + ex.Message,
                    Translation.GetTranslatedError(ErrorMessage.Error));
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
#if DEBUG
            Closing = true;
#endif
            if (FileUpdated)
                e.ApplicationExitCode = 42;

            foreach (string fileToDelete in resourceFiles)
            {
            try
            {
                    File.Delete(fileToDelete);
                }
            catch
            {
            }
        }
            try
            {
                Directory.Delete(tempPath);
            }
            catch
            {
            }
        }


#if DEBUG
        private static HashTypeLookup getListOfTypes()
        {
            HashTypeLookup lookup = new HashTypeLookup(new List<Assembly>() {
                                                             Assembly.Load("Pacom.Shared.Configuration"),
                                                             Assembly.Load("Pacom.Shared.Access")
                                                           });
            lookup.AddType(typeof(Pacom.Core.Contracts.Schedule));
            lookup.AddType(typeof(Pacom.Core.Contracts.AreaAccessPrivilege));
            return lookup;
        }

        private void splitConfiguration(string outputPath)
        {
            Pacom.Common.CompactFramework.Helpers.StreamingContext context = new Pacom.Common.CompactFramework.Helpers.StreamingContext();
            ITypeLookup typesList = ControllerConfigurationManager.GetListOfTypes();
            Asn1DerFormatter asn1Serializer = new Asn1DerFormatter(typesList, true, context);
            asn1Serializer.SerializeDefaultValues = true;

            List<ConfigurationBaseWithStreamOffsetAndLength> configuration = new List<ConfigurationBaseWithStreamOffsetAndLength>();

            string inputFilePath = outputPath + "\\localChange.asn1";
            using (FileStream fileStream = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                while (fileStream.Position < fileStream.Length)
                {
                    try
                    {
                        ConfigurationBaseWithStreamOffsetAndLength configurationBaseWithStreamOffsetAndLength = new ConfigurationBaseWithStreamOffsetAndLength();
                        configurationBaseWithStreamOffsetAndLength.Offset = (int)fileStream.Position;

                        ConfigurationBase configurationItem = (ConfigurationBase)asn1Serializer.Deserialize(fileStream);
                        if (configurationItem == null)
                        {
                            // Deserialisation of the item failed, move onto next
                            continue;
                        }
                        configurationBaseWithStreamOffsetAndLength.Configuration = configurationItem;
                        configurationBaseWithStreamOffsetAndLength.Length = (int)fileStream.Position - configurationBaseWithStreamOffsetAndLength.Offset;
                        configuration.Add(configurationBaseWithStreamOffsetAndLength);
                    }
#pragma warning disable 0168
#if DEBUG
                    catch (Exception ex)
#else
                    catch
#endif
#pragma warning restore 0168
                    {
                    }
                }
            }

            ConfigurationBaseWithStreamOffsetAndLength[] areas;
            ConfigurationBaseWithStreamOffsetAndLength[] devices;
            ConfigurationBaseWithStreamOffsetAndLength[] doors;
            ConfigurationBaseWithStreamOffsetAndLength[] inputs;
            ConfigurationBaseWithStreamOffsetAndLength[] macros;
            ConfigurationBaseWithStreamOffsetAndLength[] outputs;
            ConfigurationBaseWithStreamOffsetAndLength[] ports;
            ConfigurationBaseWithStreamOffsetAndLength[] readers;
            ConfigurationBaseWithStreamOffsetAndLength[] presenceZones;
            ConfigurationBaseWithStreamOffsetAndLength[] schedules;
            ConfigurationBaseWithStreamOffsetAndLength[] accessSchedules;
            ConfigurationBaseWithStreamOffsetAndLength[] users;
            ConfigurationBaseWithStreamOffsetAndLength[] calendars;
            ConfigurationBaseWithStreamOffsetAndLength[] cardProfiles;
            ConfigurationBaseWithStreamOffsetAndLength[] controllerConnectionTables;
            ConfigurationBaseWithStreamOffsetAndLength[] groups;
            ConfigurationBaseWithStreamOffsetAndLength[] openPacomToDigitalReceiverTemplates;
            Credential[] cards;
            ConfigurationBaseWithStreamOffsetAndLength[] userAccessGroups;
            categoriseConfiguration(configuration, out areas, out devices, out doors, out inputs, out macros, out outputs, out ports, out readers, out presenceZones,
                                    out schedules, out accessSchedules, out users, out calendars, out cardProfiles, out controllerConnectionTables, out groups,
                                    out cards, out userAccessGroups, out openPacomToDigitalReceiverTemplates);

            if (areas.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\areas.asn1", inputFilePath, areas);
            if (devices.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\devices.asn1", inputFilePath, devices);
            if (doors.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\doors.asn1", inputFilePath, doors);
            if (inputs.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\inputs.asn1", inputFilePath, inputs);
            if (macros.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\macros.asn1", inputFilePath, macros);
            if (outputs.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\outputs.asn1", inputFilePath, outputs);
            if (ports.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\ports.asn1", inputFilePath, ports);
            if (readers.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\readers.asn1", inputFilePath, readers);
            if (presenceZones.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\presencezones.asn1", inputFilePath, presenceZones);
            if (schedules.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\schedules.asn1", inputFilePath, schedules);
            if (accessSchedules.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\accessschedules.asn1", inputFilePath, accessSchedules);
            if (users.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\users.asn1", inputFilePath, users);
            if (calendars.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\calendars.asn1", inputFilePath, calendars);
            if (cardProfiles.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\cardprofiles.asn1", inputFilePath, cardProfiles);
            if (controllerConnectionTables.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\connections.asn1", inputFilePath, controllerConnectionTables);
            if (groups.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\accessgroups.asn1", inputFilePath, groups);
            if (userAccessGroups.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\useraccessgroups.asn1", inputFilePath, userAccessGroups);
            if (openPacomToDigitalReceiverTemplates.Length > 0)
                WriteOutConfigurationAndIndexFile(outputPath + "\\openpacomtodigitalreceivertemplate.asn1", inputFilePath, openPacomToDigitalReceiverTemplates);
        }

        internal static void WriteOutConfigurationAndIndexFile(string outputFilePath, string inputFilePath, ConfigurationBaseWithStreamOffsetAndLength[] configuration)
        {
            string indexFileName = outputFilePath.Replace(".asn1", ".idx");
            List<ConfigurationIndexFileEntry> indexFileEntries;

            // The existing files should be deleted
            indexFileEntries = new List<ConfigurationIndexFileEntry>();

            using (FileStream inputFileStream = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                using (FileStream outputFileStream = new FileStream(outputFilePath, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                {
                    foreach (ConfigurationBaseWithStreamOffsetAndLength configurationBaseWithStreamOffsetAndLength in configuration)
                    {
                        inputFileStream.Position = configurationBaseWithStreamOffsetAndLength.Offset;
                        byte[] data = new byte[configurationBaseWithStreamOffsetAndLength.Length];
                        inputFileStream.Read(data, 0, data.Length);

                        ConfigurationIndexFileEntry indexFileEntry = new ConfigurationIndexFileEntry();
                        indexFileEntry.Offset = (int)outputFileStream.Position;
                        indexFileEntry.Id = configurationBaseWithStreamOffsetAndLength.Configuration.Id;
                        indexFileEntry.Length = data.Length;

                        outputFileStream.Write(data, 0, data.Length);

                        indexFileEntries.Add(indexFileEntry);
                    }
                }
            }

            using (FileStream fileStream = new FileStream(indexFileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
            {
                foreach (ConfigurationIndexFileEntry indexFileEntry in indexFileEntries)
                {
                    fileStream.Write(BitConverter.GetBytes(indexFileEntry.Id), 0, 4);
                    fileStream.Write(BitConverter.GetBytes(indexFileEntry.Offset), 0, 4);
                    fileStream.Write(BitConverter.GetBytes(indexFileEntry.Length), 0, 4);
                }
            }
        }

        private static void categoriseConfiguration(List<ConfigurationBaseWithStreamOffsetAndLength> configuration,
            out ConfigurationBaseWithStreamOffsetAndLength[] areas,
            out ConfigurationBaseWithStreamOffsetAndLength[] devices,
            out ConfigurationBaseWithStreamOffsetAndLength[] doors,
            out ConfigurationBaseWithStreamOffsetAndLength[] inputs,
            out ConfigurationBaseWithStreamOffsetAndLength[] macros,
            out ConfigurationBaseWithStreamOffsetAndLength[] outputs,
            out ConfigurationBaseWithStreamOffsetAndLength[] ports,
            out ConfigurationBaseWithStreamOffsetAndLength[] readers,
            out ConfigurationBaseWithStreamOffsetAndLength[] presenceZones,
            out ConfigurationBaseWithStreamOffsetAndLength[] schedules,
            out ConfigurationBaseWithStreamOffsetAndLength[] accessSchedules,
            out ConfigurationBaseWithStreamOffsetAndLength[] users,
            out ConfigurationBaseWithStreamOffsetAndLength[] calendars,
            out ConfigurationBaseWithStreamOffsetAndLength[] cardProfiles,
            out ConfigurationBaseWithStreamOffsetAndLength[] controllerConnectionTables,
            out ConfigurationBaseWithStreamOffsetAndLength[] groups,
            out Credential[] cards,
            out ConfigurationBaseWithStreamOffsetAndLength[] userAccessGroups,
            out ConfigurationBaseWithStreamOffsetAndLength[] openPacomToDigitalReceiverTemplates)
        {

            if (configuration == null || configuration.Count == 0)
            {
                areas = new ConfigurationBaseWithStreamOffsetAndLength[0];
                devices = new ConfigurationBaseWithStreamOffsetAndLength[0];
                doors = new ConfigurationBaseWithStreamOffsetAndLength[0];
                inputs = new ConfigurationBaseWithStreamOffsetAndLength[0];
                macros = new ConfigurationBaseWithStreamOffsetAndLength[0];
                outputs = new ConfigurationBaseWithStreamOffsetAndLength[0];
                ports = new ConfigurationBaseWithStreamOffsetAndLength[0];
                readers = new ConfigurationBaseWithStreamOffsetAndLength[0];
                presenceZones = new ConfigurationBaseWithStreamOffsetAndLength[0];
                schedules = new ConfigurationBaseWithStreamOffsetAndLength[0];
                accessSchedules = new ConfigurationBaseWithStreamOffsetAndLength[0];
                users = new ConfigurationBaseWithStreamOffsetAndLength[0];
                calendars = new ConfigurationBaseWithStreamOffsetAndLength[0];
                cardProfiles = new ConfigurationBaseWithStreamOffsetAndLength[0];
                controllerConnectionTables = new ConfigurationBaseWithStreamOffsetAndLength[0];
                groups = new ConfigurationBaseWithStreamOffsetAndLength[0];
                cards = new Credential[0];
                userAccessGroups = new ConfigurationBaseWithStreamOffsetAndLength[0];
                openPacomToDigitalReceiverTemplates = new ConfigurationBaseWithStreamOffsetAndLength[0];
                return;
            }

            List<ConfigurationBaseWithStreamOffsetAndLength> localAreaList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localDeviceList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localDoorList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localInputList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localMacroList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localOutputList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localPortList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localReaderList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localPresenceZoneList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localScheduleList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localAccessScheduleList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localUserList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localCalendarList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localCardProfileList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localControllerConnectionTableList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localGroupList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<Credential> localCardsList = new List<Credential>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localUserAccessGroupsList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<ConfigurationBaseWithStreamOffsetAndLength> localOpenPacomToDigitalReceiverTemplateList = new List<ConfigurationBaseWithStreamOffsetAndLength>();
            List<string> localUpdatedIdentifiersList = new List<string>();

            foreach (ConfigurationBaseWithStreamOffsetAndLength configurationItem in configuration)
            {
                Area8003Configuration area8003Configuration = configurationItem.Configuration as Area8003Configuration;
                if (area8003Configuration != null)
                {
                    localAreaList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Area/{0}", area8003Configuration.Id));
                    continue;
                }

                ControllerConnection8003Table controllerConnection8003Table = configurationItem.Configuration as ControllerConnection8003Table;
                if (controllerConnection8003Table != null)
                {
                    localControllerConnectionTableList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Connection/{0}", controllerConnection8003Table.Id));
                    continue;
                }

                DeviceConfigurationBase device = configurationItem.Configuration as DeviceConfigurationBase;
                if (device != null)
                {
                    localDeviceList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Device/{0}", device.Id));
                    continue;
                }

                Door8003Configuration door8003Configuration = configurationItem.Configuration as Door8003Configuration;
                if (door8003Configuration != null)
                {
                    localDoorList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Door/{0}", door8003Configuration.Id));
                    continue;
                }

                Group8003Configuration group8003Configuration = configurationItem.Configuration as Group8003Configuration;
                if (group8003Configuration != null)
                {
                    localGroupList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/AccessGroups/{0}", group8003Configuration.Id));
                    continue;
                }

                AnalogueInput8003Configuration analogueInput8003Configuration = configurationItem.Configuration as AnalogueInput8003Configuration;
                if (analogueInput8003Configuration != null)
                {
                    localInputList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Input/{0}", analogueInput8003Configuration.Id));
                    continue;
                }

                Input8003Configuration input8003Configuration = configurationItem.Configuration as Input8003Configuration;
                if (input8003Configuration != null)
                {
                    localInputList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Input/{0}", input8003Configuration.Id));
                    continue;
                }

                Macro8003Configuration macro8003Configuration = configurationItem.Configuration as Macro8003Configuration;
                if (macro8003Configuration != null)
                {
                    localMacroList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Macro/{0}", macro8003Configuration.Id));
                    continue;
                }

                Output8003Configuration output8003Configuration = configurationItem.Configuration as Output8003Configuration;
                if (output8003Configuration != null)
                {
                    localOutputList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Output/{0}", output8003Configuration.Id));
                    continue;
                }

                PresenceZone8003Configuration presenceZone8003Configuration = configurationItem.Configuration as PresenceZone8003Configuration;
                if (presenceZone8003Configuration != null)
                {
                    localPresenceZoneList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/PresenceZone/{0}", presenceZone8003Configuration.Id));
                    continue;
                }

                Reader8003LegacyWiegandConfiguration reader8003LegacyWiegandConfiguration = configurationItem.Configuration as Reader8003LegacyWiegandConfiguration;
                if (reader8003LegacyWiegandConfiguration != null)
                {
                    localReaderList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Reader/{0}", reader8003LegacyWiegandConfiguration.Id));
                    continue;
                }

                Reader8003Configuration reader8003Configuration = configurationItem.Configuration as Reader8003Configuration;
                if (reader8003Configuration != null)
                {
                    localReaderList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Reader/{0}", reader8003Configuration.Id));
                    continue;
                }

                Credential card = configurationItem.Configuration as Credential;
                if (card != null)
                {
                    localCardsList.Add(card);
                    localUpdatedIdentifiersList.Add(String.Format("/Cards/{0}", card.Id));
                    continue;
                }

                AccessSchedule accessSchedule = configurationItem.Configuration as AccessSchedule;
                if (accessSchedule != null)
                {
                    localAccessScheduleList.Add(configurationItem);
                    continue;
                }

                Schedule schedule = configurationItem.Configuration as Schedule;
                if (schedule != null)
                {
                    localScheduleList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Schedules/{0}", schedule.Id));
                    continue;
                }

                Port8003GprsPortConfiguration port8003GprsPortConfiguration = configurationItem.Configuration as Port8003GprsPortConfiguration;
                if (port8003GprsPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003GprsPortConfiguration.Id));
                    continue;
                }

                Port8003IPPortConfiguration port8003IPPortConfiguration = configurationItem.Configuration as Port8003IPPortConfiguration;
                if (port8003IPPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003IPPortConfiguration.Id));
                    continue;
                }

                Port8003RS485OsdpDeviceLoopPortConfiguration port8003RS485OsdpDeviceLoopPortConfiguration = configurationItem.Configuration as Port8003RS485OsdpDeviceLoopPortConfiguration;
                if (port8003RS485OsdpDeviceLoopPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003RS485OsdpDeviceLoopPortConfiguration.Id));
                    continue;
                }

                Port8003RS485AsisProprietaryReaderPortConfiguration port8003RS485AsisProprietaryReaderPortConfiguration = configurationItem.Configuration as Port8003RS485AsisProprietaryReaderPortConfiguration;
                if (port8003RS485AsisProprietaryReaderPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003RS485AsisProprietaryReaderPortConfiguration.Id));
                    continue;
                }

                Port8003RS485AperioPortConfiguration port8003RS485AperioConfiguration = configurationItem.Configuration as Port8003RS485AperioPortConfiguration;
                if (port8003RS485AperioConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003RS485AperioConfiguration.Id));
                    continue;
                }

                Port8003RS485DeviceLoopPortConfiguration port8003RS485DeviceLoopPortConfiguration = configurationItem.Configuration as Port8003RS485DeviceLoopPortConfiguration;
                if (port8003RS485DeviceLoopPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003RS485DeviceLoopPortConfiguration.Id));
                    continue;
                }

                Port8003DialupPortConfiguration port8003DialupPortConfiguration = configurationItem.Configuration as Port8003DialupPortConfiguration;
                if (port8003DialupPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003DialupPortConfiguration.Id));
                    continue;
                }

                Port8003RS232InovonicsPortConfiguration port8003RS232InovonicsPortConfiguration = configurationItem.Configuration as Port8003RS232InovonicsPortConfiguration;
                if (port8003RS232InovonicsPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003RS232InovonicsPortConfiguration.Id));
                    continue;
                }

                Port8003RS232DebugPortConfiguration port8003RS232DebugPortConfiguration = configurationItem.Configuration as Port8003RS232DebugPortConfiguration;
                if (port8003RS232DebugPortConfiguration != null)
                {
                    localPortList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Nodes/Port/{0}", port8003RS232DebugPortConfiguration.Id));
                    continue;
                }

                User8003Configuration user8003Configuration = configurationItem.Configuration as User8003Configuration;
                if (user8003Configuration != null)
                {
                    localUserList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Users/{0}", user8003Configuration.Id));
                    continue;
                }

                User userConfiguration = configurationItem.Configuration as User;
                if (userConfiguration != null)
                {
                    localUserList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Users/{0}", userConfiguration.Id));
                    continue;
                }

                Pacom.Core.Access.Calendar calendarItem = configurationItem.Configuration as Pacom.Core.Access.Calendar;
                if (calendarItem != null)
                {
                    localCalendarList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/Calendars/{0}", calendarItem.Id));
                    continue;
                }

                LegacyCardFormat legacyCardFormat = configurationItem.Configuration as LegacyCardFormat;
                if (legacyCardFormat != null)
                {
                    localCardProfileList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/CardProfiles/{0}", legacyCardFormat.Id));
                    continue;
                }

                AccessGroup accessGroupConfiguration = configurationItem.Configuration as AccessGroup;
                if (accessGroupConfiguration != null)
                {
                    localUserAccessGroupsList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/UserAccessGroups/{0}", accessGroupConfiguration.Id));
                    continue;
                }

                OpenPacomToDigitalReceiver8003Template openPacomToDigitalReceiver8003Template = configurationItem.Configuration as OpenPacomToDigitalReceiver8003Template;
                if (openPacomToDigitalReceiver8003Template != null)
                {
                    localOpenPacomToDigitalReceiverTemplateList.Add(configurationItem);
                    localUpdatedIdentifiersList.Add(String.Format("/OpenPacomToDigitalReceiverTemplate/{0}", openPacomToDigitalReceiver8003Template.Id));
                    continue;
                }
            }

            areas = localAreaList.ToArray();
            devices = localDeviceList.ToArray();
            doors = localDoorList.ToArray();
            inputs = localInputList.ToArray();
            macros = localMacroList.ToArray();
            outputs = localOutputList.ToArray();
            ports = localPortList.ToArray();
            readers = localReaderList.ToArray();
            presenceZones = localPresenceZoneList.ToArray();
            schedules = localScheduleList.ToArray();
            accessSchedules = localAccessScheduleList.ToArray();
            users = localUserList.ToArray();
            calendars = localCalendarList.ToArray();
            cardProfiles = localCardProfileList.ToArray();
            controllerConnectionTables = localControllerConnectionTableList.ToArray();
            groups = localGroupList.ToArray();
            cards = localCardsList.ToArray();
            userAccessGroups = localUserAccessGroupsList.ToArray();
            openPacomToDigitalReceiverTemplates = localOpenPacomToDigitalReceiverTemplateList.ToArray();
        }
#endif
    }
}
