﻿using System.IO;
using System.Windows;
using System.Windows.Media;
using Pacom.ConfigurationEditor.WPF.View;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;

namespace Pacom.ConfigurationEditor.WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
#if DEBUG
        private HotKeyManager hotKey = null;
#endif

        public MainWindow()
        {
            Instance = this;
            InitializeComponent();
#if DEBUG
            this.Loaded += MainWindow_Loaded;
            NodeTreeView.Background = Brushes.Aqua;
            PropertiesView.Background = Brushes.Aqua;
#endif

            ConfigurationGrid = this.PropertiesView;

        }

#if DEBUG

        private void MainWindow_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            hotKey = new HotKeyManager(this);
            hotKey.F5Pressed += HotKey_F5Pressed;
        }

        private void HotKey_F5Pressed(object sender, System.EventArgs e)
        {
            string tempPath = Path.GetTempPath() + "PacomCCMTemp.asn1";
            string title = Title;
            NodeTreeElement selection = MainWindow.Instance.NodeTreeView.NodeTree.SelectedItem as NodeTreeElement;
            ControllerConfigurationManager.SaveToFile(tempPath);
            ControllerConfigurationManager.LoadFromFile(tempPath);
            NodeTreeView.SetSelection(selection?.ConfigurationItem);
            Title = title;
        }
#endif

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
#if DEBUG
            if (hotKey != null)
                hotKey.Dispose();
#endif
            if (App.ConfigurationModified)
            {
                MessageBoxResult result = Xceed.Wpf.Toolkit.MessageBox.Show(this,
                    Translation.GetTranslatedError(ErrorMessage.UnsavedConfiguration),
                    Translation.GetTranslatedError(ErrorMessage.Warning), MessageBoxButton.OKCancel);

                if (result == MessageBoxResult.Cancel)
                    e.Cancel = true;
            }
        }

        public static ConfigurationView ConfigurationGrid
        {
            get;
            private set;
        }

        public static MainWindow Instance
        {
            get;
            private set;
        }
    }
}
