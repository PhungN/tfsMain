﻿#if DEBUG
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.AccessControl;

namespace Pacom.Peripheral.ConfigurationEditorFor8003
{
    public partial class FormViewCardholders : Form
    {
        public FormViewCardholders()
        {
            InitializeComponent();
        }

        CardholderDownloader downloader = new CardholderDownloader();

        private void btnDownload_Click(object sender, EventArgs e)
        {
            listCardholders.Items.Clear();

            txtLastResponse.Text = "Waiting...";

            if (downloader.Download() == true)
            {
                if (downloader.CardholdersExists == true)
                {

                    txtLastResponse.Text = "Populating list...";
                    listCardholders.BeginUpdate();
                    try
                    {
                        // display received cards
                        foreach (var item in downloader.ReceivedCardholderItems)
                        {
                            ListViewItem listItem = new ListViewItem(new string[] {
                                item.CardholderId.ToString(),
                                ((int)((item.CardholderId & 0x7FFF000000000000) >> 48)).ToString(),
                                ((int)((item.CardholderId & 0x0000FF0000000000) >> 40)).ToString(),
                                ((int)((item.CardholderId & 0x000000FFFFFFFFFF))).ToString(),
                                item.UserPin.ToString(),
                                item.GroupId.ToString(),
                                item.Blocked ? "Yes" : "No",
                                item.Expired ? "Yes" : "No",
                                getSchedules(item),
                                item.UserFlags.ToString()
                            });
                            listCardholders.Items.Add(listItem);
                        }
                    }
                    finally
                    {
                        listCardholders.EndUpdate();
                    }
                    txtLastResponse.Text = string.Format("OK (Count = {0})", downloader.ReceivedCardholderItems.Count);
                }
                else
                {
                    txtLastResponse.Text = "OK (No items)";
                }
            }
            else
            {
                txtLastResponse.Text = "Error (No details)";
            }
        }

        private string getSchedules(CardholderItem item)
        {
            string result = string.Empty;
            for (int i = 0; i < item.ReaderSchedules.Count; i++)
            {
                result += string.Format("R{0}={1} ", item.ReaderSchedules[i].ReaderId.ToString(), item.ReaderSchedules[i].ScheduleId.ToString());
            }
            return result;
        }

        private void listCardholders_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control == true && e.KeyCode == Keys.C)
            {
                if (listCardholders.SelectedItems.Count == 1)
                {
                    Clipboard.SetText(listCardholders.SelectedItems[0].SubItems[0].Text);
                }
            }
        }
    }
}
#endif