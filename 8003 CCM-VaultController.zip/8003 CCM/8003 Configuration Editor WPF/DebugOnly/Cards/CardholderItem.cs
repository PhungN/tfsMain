﻿#if DEBUG
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.ConfigurationEditorFor8003
{
    public class CardholderItem
    {
        public CardholderItem()
        {
            this.blocked = true;
            this.expired = true;
            this.cardholderId = -1;
            this.lastUsed = DateTime.Now;
            this.startDate = new DateTime(2000, 1, 1);
            this.endDate = new DateTime(9999, 12, 31);
        }

        public CardholderItem(long cardHolderId)
        {
            this.cardholderId = cardHolderId;
            this.lastUsed = DateTime.Now;
        }

        public CardholderItem(long cardHolderId, int userPin, int groupId, bool blocked, bool expired)
        {
            this.cardholderId = cardHolderId;
            this.userPin = userPin;
            this.groupId = groupId;
            this.blocked = blocked;
            this.expired = expired;
        }

        public CardholderItem(long cardHolderId, int userPin, int groupId, bool blocked, bool expired, DateTime lastUsed, int version)
        {
            this.cardholderId = cardHolderId;
            this.userPin = userPin;
            this.groupId = groupId;
            this.blocked = blocked;
            this.expired = expired;
            this.lastUsed = lastUsed;
            this.version = version;
        }

        protected long cardholderId;

        public long CardholderId
        {
            get
            {
                return cardholderId;
            }
            set
            {
                this.cardholderId = value;
            }
        }

        protected int userPin = -1;

        public int UserPin
        {
            get
            {
                return userPin;
            }
            set
            {
                this.userPin = value;
            }
        }

        protected int groupId = -1;

        public int GroupId
        {
            get
            {
                return groupId;
            }
            set
            {
                this.groupId = value;

            }
        }

        protected bool blocked = true;

        /// <summary>
        /// Indicates if the cardholder is blocked
        /// </summary>
        public bool Blocked
        {
            get
            {
                return blocked;
            }
            set
            {
                this.blocked = value;
            }
        }

        protected bool expired = true;

        /// <summary>
        /// Indicates if the cardholder is expired
        /// </summary>
        public bool Expired
        {
            get
            {
                return expired;
            }
            set
            {
                this.expired = value;
            }
        }

        public bool[] FloorsAccess { get; set; }
        public int FloorsAccessTimezoneId { get; set; }
        public long Id { get; set; }

        protected LegacyCardUserFlags cardUserFlags = LegacyCardUserFlags.None;
        public LegacyCardUserFlags UserFlags
        {
            get { return cardUserFlags; }
            set { cardUserFlags = value; }
        }

        protected DateTime startDate;
        public DateTime StartDate
        {
            get { return startDate; }
            set { startDate = value; }
        }
        protected DateTime endDate;
        public DateTime EndDate
        {
            get { return endDate; }
            set { endDate = value; }
        }

        protected DateTime lastUsed;

        /// <summary>
        /// Last time used read or write
        /// </summary>
        public DateTime LastUsed
        {
            get
            {
                return lastUsed;
            }
            set
            {
                this.lastUsed = value;
            }
        }

        protected int version = -1;

        /// <summary>
        /// Version of the frame.
        /// </summary>
        public int Version
        {
            get
            {
                return this.version;
            }
            set
            {
                this.version = value;
            }
        }

        private readonly List<ReaderScheduleIdPair> readerSchedules = new List<ReaderScheduleIdPair>();

        /// <summary>
        /// 64 cardholder schedules.
        /// </summary>
        public List<ReaderScheduleIdPair> ReaderSchedules
        {
            get
            {
                return readerSchedules;
            }
        }

        public long Facility
        {
           get { return (cardholderId & 0x7FFF000000000000) >> 48; }
        }
        public long Issue
        {
            get { return (cardholderId & 0x0000FF0000000000) >> 40; }
        }

        public long Code
        {
            get { return (cardholderId & 0x000000FFFFFFFFFF); }
        }

        public string CardNumber
        {
            get { return $"{Facility}/{Issue}/{Code}"; }

        }
        public bool IsPermanantCard
        {
            get
            {
                return
                    StartDate.Date == (new DateTime(2000, 1, 1)).Date &&
                    EndDate.Date == (new DateTime(9999, 12, 31)).Date;
            }
        }
        public override string ToString()
        {
            string str = $"{CardNumber.PadRight(20, ' ')} - PIN:{userPin.ToString().PadRight(8, ' ')} - UserFlags:{UserFlags}";
            return str;
        }
    }
}
#endif