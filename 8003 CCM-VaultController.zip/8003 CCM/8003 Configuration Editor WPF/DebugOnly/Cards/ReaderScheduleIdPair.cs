﻿#if DEBUG
namespace Pacom.Peripheral.Common.AccessControl
{
    public class ReaderScheduleIdPair
    {
        public int ReaderId = -1;
        public int ScheduleId = -1;

        public ReaderScheduleIdPair()
        {
        }

        public ReaderScheduleIdPair(int readerId, int scheduleId)
        {
            ReaderId = readerId;
            ScheduleId = scheduleId;
        }

        public override string ToString()
        {
            return string.Format("Reader Id: {0} Schedule Id: {1}", ReaderId.ToString(), ScheduleId.ToString());
        }
    }
}
#endif