﻿#if DEBUG
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{
    public class LegacyCardNumberFormat
    {
        public LegacyCardNumberFormat(byte[] facility, byte[] issue, byte[] code)
        {
            Facility = 0;
            Issue = 0;
            Code = 0;
            createFromData(facility, issue, code);
        }

        public LegacyCardNumberFormat(int facility, int issue, long code)
        {
            Facility = facility;
            Issue = issue;
            Code = code;
        }

        public int Facility
        {
            get;
            set;
        }

        public int Issue
        {
            get;
            set;
        }

        public long Code
        {
            get;
            set;
        }

        public bool IsValid
        {
            get { return Code > 0; }
        }

        public long AsLong()
        {
            long cardNumber = (long)(Facility & 0xFFFF) << 48;
            cardNumber |= (long)(Issue & 0xFF) << 40;
            cardNumber |= (long)(Code & 0xFFFFFFFFFF);
            return cardNumber;
        }

        public override bool Equals(object obj)
        {
            LegacyCardNumberFormat cardNumber = obj as LegacyCardNumberFormat;
            if (cardNumber == null)
                return false;

            if (cardNumber.Facility.Equals(Facility) == false)
                return false;
            if (cardNumber.Issue.Equals(Issue) == false)
                return false;
            if (cardNumber.Code.Equals(Code) == false)
                return false;

            return true;
        }

        public override int GetHashCode()
        {
            return Facility.GetHashCode() ^
                   Issue.GetHashCode() ^
                   Code.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("{0}/{1}/{2}", Code, Issue, Facility);
        }

        private void createFromData(byte[] facility, byte[] issue, byte[] code)
        {
            if (facility != null && facility.Length > 0)
            {
                Facility = getIntFromData(facility);
            }

            if (issue != null && issue.Length > 0)
            {
                Issue = getIntFromData(issue);
            }

            if (code != null && code.Length > 0)
            {
                Code = getLongFromData(code);
            }
        }

        private static int getIntFromData(byte[] data)
        {
            if (data == null || data.Length == 0)
                return 0;

            int k = 0,
                result = 0;
            for (int i = data.Length - 1; i >= 0; i--)
            {
                if (data[i] == 0x00)
                    continue;
                result += data[i] << 8 * k;
                k++;
            }
            return result;
        }

        private static long getLongFromData(byte[] data)
        {
            if (data == null || data.Length == 0)
                return 0;

            int k = 0,
                result = 0;
            for (int i = data.Length - 1; i >= 0; i--)
            {
                if (data[i] == 0x00)
                    continue;
                result += data[i] << 8 * k;
                k++;
            }
            return result;
        }
    }
}
#endif