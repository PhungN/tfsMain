﻿#if DEBUG
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading;
using System.Xml.Linq;
using Pacom.ConfigurationEditor.WPF;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.Peripheral.Protocol;

namespace Pacom.Peripheral.ConfigurationEditorFor8003
{
    public class CardholderDownloader : IDisposable
    {
        private TcpIPConnection cardholderConnection = null;
        private Int32 cardholderPort;
        private IPAddress cardholderRemoteAddr;

        private byte[] dataReceived = new byte[0];
        private ManualResetEvent dataReceivedEvent = new ManualResetEvent(false);
        
        private List<long> receivedCardholderIds = new List<long>();
        private List<Tuple<long, DateTime, DateTime>> receivedUniqueCardholderIds = new List<Tuple<long, DateTime, DateTime>>();
        private CardholderItem receivedCardholderItem = null;
        private List<CardholderItem> receivedCardholderItems = new List<CardholderItem>();
        private bool receivedNoItems = false;

        public List<CardholderItem> ReceivedCardholderItems
        {
            get
            {
                return receivedCardholderItems;
            }
        }

        public bool CardholdersExists
        {
            get
            {
                return receivedNoItems == false;
            }
        }

        private ManualResetEvent responseReceivedEvent = new ManualResetEvent(false);

        public enum DownloadStateProgressType
        {
            None,
            SendRequestForCardholderIds,
            WaitForCardholderIds,
            SendRequestToGetCardholder,
            WaitForCardholder,
            Finished,
            SendRequestForUniqueCardholderIds,
            WaitForUniqueCardholderIds,
            SendRequestToGetUniqueCardholder,
            WaitForUniqueCardholder,
            SendRequestToGetElevatorFloorsAccess,
            WaitForElevatorFloorsAccess,
        }

        private DownloadStateProgressType downloadProgressState = DownloadStateProgressType.None;

        public bool Download()
        {
            bool result = false;
            downloadProgressState = DownloadStateProgressType.None;
            receivedCardholderIds.Clear();
            receivedCardholderItems.Clear();
            try
            {
                connectToController();

                int cardholderRequestIndex = -1;
                while (true)
                {
                    switch (downloadProgressState)
                    {
                        case DownloadStateProgressType.None:
                            {
                                downloadProgressState = DownloadStateProgressType.SendRequestForCardholderIds;
                            }
                            break;
                        case DownloadStateProgressType.SendRequestForCardholderIds:
                            {
                                receivedCardholderIds.Clear();
                                responseReceivedEvent.Reset();
                                receivedNoItems = false;
                                string query = string.Format(
                                    "<request type='getcardholderids'>" +
                                    "</request>");
                                if (cardholderConnection != null)
                                    cardholderConnection.Send(Encoding.ASCII.GetBytes(query), null);
                                downloadProgressState = DownloadStateProgressType.WaitForCardholderIds;
                            }
                            break;
                        case DownloadStateProgressType.WaitForCardholderIds:
                            {
                                if (responseReceivedEvent.WaitOne(30 * 1000) == false)
                                {
                                    result = false;
                                    downloadProgressState = DownloadStateProgressType.Finished;                                    
                                }
                                else
                                {
                                    if (receivedCardholderIds.Count <= 0)
                                    {
                                        if (receivedNoItems == true)
                                            result = true;
                                        else
                                            result = false;
                                        downloadProgressState = DownloadStateProgressType.Finished;                                        
                                    }
                                    else
                                    {
                                        cardholderRequestIndex = 0;
                                        downloadProgressState = DownloadStateProgressType.SendRequestToGetCardholder;
                                    }
                                }
                            }
                            break;
                        case DownloadStateProgressType.SendRequestToGetCardholder:
                            {
                                responseReceivedEvent.Reset();
                                receivedCardholderItem = null;
                                string query = string.Format(
                                    "<request type='getcardholder'>" +
                                    "  <cardholderid>{0}</cardholderid>" +
                                    "</request>", receivedCardholderIds[cardholderRequestIndex++]);
                                
                                if (cardholderConnection != null)
                                    cardholderConnection.Send(Encoding.ASCII.GetBytes(query), null);

                                downloadProgressState = DownloadStateProgressType.WaitForCardholder;
                            }
                            break;
                        case DownloadStateProgressType.WaitForCardholder:
                            {
                                if (responseReceivedEvent.WaitOne(30 * 1000) == false)
                                {
                                    result = false;
                                    downloadProgressState = DownloadStateProgressType.Finished;
                                }
                                else
                                {
                                    if (receivedCardholderItem == null)
                                    {
                                        result = false;
                                        downloadProgressState = DownloadStateProgressType.Finished;
                                    }
                                    else
                                    {
                                        receivedCardholderItems.Add(receivedCardholderItem);                                        
                                        if (cardholderRequestIndex >= receivedCardholderIds.Count)
                                        {
                                            result = true;
                                            downloadProgressState = DownloadStateProgressType.Finished;
                                        }
                                        else
                                        {
                                            downloadProgressState = DownloadStateProgressType.SendRequestToGetCardholder;
                                        }
                                    }
                                }
                            }
                            break;
                        case DownloadStateProgressType.Finished:
                            return result;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        private void connectToController()
        {
            dataReceivedEvent.Reset();
            dataReceived = new byte[0];
            if (cardholderConnection == null)
            {
                cardholderPort = 8282;
                cardholderRemoteAddr = Settings.ControllerIPAddress;

                cardholderConnection = new TcpIPConnection(new IPEndPoint(cardholderRemoteAddr, cardholderPort));
                cardholderConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(cardholderConnection_DataReceived);
                cardholderConnection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(cardholderConnection_ConnectionStateChanged);
                cardholderConnection.Connect();
            }
        }

        private void cardholderConnection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            byte[] dataReceivedNew = new byte[dataReceived.Length + e.Data.Length];
            Array.Copy(dataReceived, 0, dataReceivedNew, 0, dataReceived.Length);
            Array.Copy(e.Data, 0, dataReceivedNew, dataReceived.Length, e.Data.Length);
            dataReceived = dataReceivedNew;
            // Discard data if too much
            if (dataReceived.Length > 500000)
                dataReceived = new byte[0];
            // Check if closing tag has been found
            if (closingResponseFound(dataReceived) == true)
            {
                // Parse response
                XDocument xdoc = processRawCommand(dataReceived);
                switch (getResponseType(xdoc))
                {
                    case ResponseType.CardholderIds:
                        parseCardholderIds(xdoc);
                        responseReceivedEvent.Set();
                        break;
                    case ResponseType.UniqueCardholderIds:
                        parseUniqueCardholderIds(xdoc);
                        responseReceivedEvent.Set();
                        break;
                    case ResponseType.Cardholder:
                        parseCardholder(xdoc);
                        responseReceivedEvent.Set();
                        break;
                    case ResponseType.ElevatorFloorsAccess:
                        parseElevatorFloorsAccess(xdoc);
                        responseReceivedEvent.Set();
                        break;
                    case ResponseType.NoData:
                        receivedNoItems = true;
                        responseReceivedEvent.Set();
                        break;
                    default:
                        responseReceivedEvent.Set();
                        break;
                }
                dataReceivedEvent.Set();
                dataReceived = new byte[0];
            }
        }

        private bool closingResponseFound(byte[] data)
        {
            byte[] responseEnd = Encoding.ASCII.GetBytes(@"</response>");
            if (data.Length < responseEnd.Length)
                return false;

            for (int i = 1; i <= responseEnd.Length; i++)
            {
                if (data[data.Length - i] != responseEnd[responseEnd.Length - i])
                {
                    return false;
                }
            }
            return true;
        }

        private void cardholderConnection_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (e.NewConnectionState == Pacom.Peripheral.Protocol.ConnectionState.Disconnected)
            {
                disconnectConnection();
            }
        }

        private void disconnectConnection()
        {
            if (cardholderConnection != null)
            {
                try
                {
                    cardholderConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(cardholderConnection_DataReceived);
                    cardholderConnection.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(cardholderConnection_ConnectionStateChanged);
                    cardholderConnection.Dispose();
                    cardholderConnection = null;
                }
                catch (Exception)
                {                    
                }
            }
        }

        private enum ResponseType
        {
            Unknown,
            NoData,
            Ok,
            Error,
            CardholderIds,
            Cardholder,
            UniqueCardholderIds,
            ElevatorFloorsAccess,
        }

        private XDocument processRawCommand(byte[] rawCommand)
        {
            XDocument result = null;
            try
            {
                string commandAsString = Encoding.ASCII.GetString(rawCommand, 0, rawCommand.Length);
                result = XDocument.Parse(commandAsString);
            }
            catch
            {
                result = null;
            }
            return result;
        }

        private ResponseType getResponseType(XDocument xdoc)
        {

            /*
            * <response type='?????'>
            *    ....
            * </response>
            */

            if (xdoc == null)
                return ResponseType.Unknown;

            ResponseType result = ResponseType.Unknown;
            try
            {
                var request = xdoc.Element("response");
                XAttribute xRequestType = request.Attribute("type");

                if (xRequestType != null && xRequestType.Value != null)
                {
                    switch(xRequestType.Value.ToLower())
                    {
                        case "nodata": result = ResponseType.NoData; break;
                        case "error": result = ResponseType.Error; break;
                        case "Ok": result = ResponseType.Ok; break;
                        case "cardholder": result = ResponseType.Cardholder; break;
                        case "cardholderids": result = ResponseType.CardholderIds; break;
                        case "uniquecardholderids": result = ResponseType.UniqueCardholderIds; break;
                        case "elevatorfloorsaccess": result = ResponseType.ElevatorFloorsAccess; break;
                    }
                    
                }
            }
            catch
            {
                result = ResponseType.Unknown;
            }
            return result;
        }

        private void parseCardholder(XDocument xdoc)
        {
            /*
            *  <response type='cardholder'> 
            *      <cardholder cardholderid='77834873'>
            *         <userpin>221</userpin>
            *         <groupid>1</groupid>
            *         <blocked>False</blocked>
            *         <expired>True</expired>
            *         <lastused>9873875975974395</lastused>
            *         <version></version>
            *      </cardholder>
            *  </response>
            */
            try
            {
                CardholderItem item = new CardholderItem();

                var xRequest = xdoc.Element("response");
                var xCardholder = xRequest.Element("cardholder");
                item.CardholderId = long.Parse(xCardholder.Attribute("cardholderid").Value);

                item.UserPin = int.Parse(xCardholder.Element("userpin").Value);
                item.GroupId = int.Parse(xCardholder.Element("groupid").Value);
                if (xCardholder.Element("blocked").Value.ToLower() == "true")
                    item.Blocked = true;
                else
                    item.Blocked = false;

                if (xCardholder.Element("expired").Value.ToLower() == "true")
                    item.Expired = true;
                else
                    item.Expired = false;
                try
                {
                    long lastUserTicks = long.Parse(xCardholder.Element("lastused").Value);
                    item.LastUsed = new DateTime(lastUserTicks);
                }
                catch
                {
                    item.LastUsed = DateTime.Now.ToUniversalTime();
                }

                var xSchedules = xCardholder.Elements("schedules");
                if (xSchedules != null)
                {
                    var xScheduleList = xSchedules.Elements("schedule");
                    if (xScheduleList != null)
                    {
                        foreach (XElement xSchedule in xScheduleList)
                        {
                            int readerId = int.Parse(xSchedule.Attribute("readerid").Value);
                            int scheduleId = int.Parse(xSchedule.Value);
                            item.ReaderSchedules.Add(new ReaderScheduleIdPair(readerId, scheduleId));
                        }
                    }
                }

                int userFlags = int.Parse(xCardholder.Element("userflags").Value);
                item.UserFlags = (Configuration.ConfigurationCommon.LegacyCardUserFlags)(userFlags);
                var startDateString = xCardholder.Element("startdate").Value;
                var endDateString = xCardholder.Element("enddate").Value;
                DateTime startDate;
                if (DateTime.TryParse(startDateString, out startDate) == true)
                    item.StartDate = startDate;
                DateTime endDate;
                if (DateTime.TryParse(endDateString, out endDate) == true)
                    item.EndDate = endDate;

                item.Version = byte.Parse(xCardholder.Element("version").Value);

                var xFloors = xCardholder.Elements("floors");
                if(xFloors != null)
                {
                    var xFloorList = xFloors.Elements("floor");
                    if(xFloorList != null)
                    {
                        item.FloorsAccess = new bool[128];
                        foreach(XElement xFloor in xFloorList)
                        {
                            int floor = int.Parse(xFloor.Value);
                            if (floor > 0 && floor <= 128)
                                item.FloorsAccess[floor - 1] = true;
                        }
                        
                    }
                }
                item.FloorsAccessTimezoneId = int.Parse(xCardholder.Element("floorsAccessTimezoneId").Value);

                receivedCardholderItem = item;
            }
            catch
            {
                receivedCardholderItem = null;
            }
        }

        private void parseElevatorFloorsAccess(XDocument xdoc)
        {
            try
            {
                CardholderItem item = new CardholderItem();

                var xRequest = xdoc.Element("response");
                var xCardholder = xRequest.Element("cardholder");
                if (xCardholder != null)
                {
                    item.CardholderId = long.Parse(xCardholder.Attribute("number").Value);
                    item.Id = long.Parse(xCardholder.Attribute("id").Value);
                    var startDateString = xCardholder.Element("startdate").Value;
                    var endDateString = xCardholder.Element("enddate").Value;
                    DateTime startDate;
                    if (DateTime.TryParse(startDateString, out startDate) == true)
                        item.StartDate = startDate;
                    DateTime endDate;
                    if (DateTime.TryParse(endDateString, out endDate) == true)
                        item.EndDate = endDate;

                    var xFloors = xCardholder.Elements("floors");
                    if (xFloors != null)
                    {
                        var xFloorList = xFloors.Elements("floor");
                        if (xFloorList != null)
                        {
                            item.FloorsAccess = new bool[128];
                            foreach (XElement xFloor in xFloorList)
                            {
                                int floor = int.Parse(xFloor.Value);
                                if (floor > 0 && floor <= 128)
                                    item.FloorsAccess[floor - 1] = true;
                            }

                        }
                    }
                    item.FloorsAccessTimezoneId = int.Parse(xCardholder.Element("floorsAccessTimezoneId").Value);
                    receivedCardholderItem = item;
                }
                
            }
            catch
            {
                receivedCardholderItem = null;
            }
        }

        private void parseCardholderIds(XDocument xdoc)
        {
            /*
            *  <response type='cardholderids'> 
            *      <id>111</id>
            *      <id>222</id>
            *      <id>333</id>
            *  </response>
            */
            try
            {
                var xRequest = xdoc.Element("response");
                var xIdList = xRequest.Elements("id");
                if (xIdList != null)
                {
                    foreach (XElement xId in xIdList)
                    {
                        receivedCardholderIds.Add(long.Parse(xId.Value));
                    }
                }
            }
            catch
            {
                receivedCardholderIds.Clear();
            }
        }

        private void parseUniqueCardholderIds(XDocument xdoc)
        {
            try
            {
                var xRequest = xdoc.Element("response");
                var xCardHolderList = xRequest.Elements("cardholder");
                if (xCardHolderList != null)
                {
                    foreach (XElement cardHolder in xCardHolderList)
                    {
                        var id = cardHolder.Element("id").Value;
                        var startDate = cardHolder.Element("startdate").Value;
                        var endDate = cardHolder.Element("enddate").Value;
                        receivedUniqueCardholderIds.Add(new Tuple<long, DateTime, DateTime>(long.Parse(id), DateTime.Parse(startDate), DateTime.Parse(endDate)));
                    }
                }
            }
            catch
            {
            }
        }

        #region IDisposable Members

        bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.
                disconnectConnection();
            }

            // Free any unmanaged objects here.            
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

        public void RequestDownload(DownloadStateProgressType initialState = DownloadStateProgressType.None)
        {
            Thread downloadThread = new Thread(new ParameterizedThreadStart(startRequest));
            downloadThread.Start(initialState);
        }

        private void startRequest(object initialState)
        {
            downloadProgressState = (DownloadStateProgressType)initialState;
            receivedCardholderIds.Clear();
            receivedCardholderItems.Clear();
            try
            {
                connectToController();

                int cardholderRequestIndex = -1;
                while (true)
                {
                    switch (downloadProgressState)
                    {
                        case DownloadStateProgressType.SendRequestForUniqueCardholderIds:
                            {
                                receivedUniqueCardholderIds.Clear();
                                responseReceivedEvent.Reset();
                                receivedNoItems = false;
                                if (cardholderConnection != null)
                                {
                                    System.Diagnostics.Debug.WriteLine("---------------- SendRequestForUniqueCardholderIds");
                                    cardholderConnection.Send(Encoding.ASCII.GetBytes("<request type='getuniquecardholderids'></request>"), null);
                                    downloadProgressState = DownloadStateProgressType.WaitForUniqueCardholderIds;
                                }

                            }
                            break;
                        case DownloadStateProgressType.WaitForUniqueCardholderIds:
                            {
                                System.Diagnostics.Debug.WriteLine("---------------- WaitForUniqueCardholderIds");
                                if (responseReceivedEvent.WaitOne(30 * 1000) == false)
                                {
                                    downloadProgressState = DownloadStateProgressType.Finished;
                                }
                                else
                                {
                                    if (receivedUniqueCardholderIds.Count <= 0)
                                    {
                                        downloadProgressState = DownloadStateProgressType.Finished;
                                    }
                                    else
                                    {
                                        cardholderRequestIndex = 0;
                                        downloadProgressState = DownloadStateProgressType.SendRequestToGetElevatorFloorsAccess;
                                    }
                                }
                            }
                            break;
                        case DownloadStateProgressType.SendRequestToGetElevatorFloorsAccess:
                            {
                                responseReceivedEvent.Reset();
                                receivedCardholderItem = null;
                                if (cardholderConnection != null)
                                {
                                    System.Diagnostics.Debug.WriteLine("---------------- SendRequestToGetElevatorFloorsAccess");
                                    var card = receivedUniqueCardholderIds[cardholderRequestIndex++];
                                    string query = $"<request type='getelevatorfloorsaccess'><id>{card.Item1}</id><startdate>{card.Item2.ToString("dd/MM/yyyy")}</startdate><enddate>{card.Item3.ToString("dd/MM/yyyy")}</enddate></request>";
                                    cardholderConnection.Send(Encoding.ASCII.GetBytes(query), null);
                                    downloadProgressState = DownloadStateProgressType.WaitForElevatorFloorsAccess;
                                }
                            }
                            break;
                        case DownloadStateProgressType.WaitForElevatorFloorsAccess:
                            {
                                if (responseReceivedEvent.WaitOne(30 * 1000) == false)
                                {
                                    downloadProgressState = DownloadStateProgressType.Finished;
                                }
                                else
                                {
                                    if (receivedCardholderItem == null)
                                    {
                                        downloadProgressState = DownloadStateProgressType.Finished;
                                    }
                                    else
                                    {
                                        CardDataReceived?.Invoke(this, new CardDataEventArgs(receivedCardholderItem));
                                        receivedCardholderItems.Add(receivedCardholderItem);
                                        if (cardholderRequestIndex >= receivedUniqueCardholderIds.Count)
                                        {
                                            downloadProgressState = DownloadStateProgressType.Finished;
                                        }
                                        else
                                        {
                                            downloadProgressState = DownloadStateProgressType.SendRequestToGetElevatorFloorsAccess;
                                        }
                                    }
                                }
                            }
                            break;
                        case DownloadStateProgressType.Finished:
                            CardDataReceivedFinish?.Invoke(this, EventArgs.Empty);
                            return;
                    }
                }
            }
            catch (Exception ex)
            {
                string s = ex.Message;
                return;
            }

        }
        public event EventHandler<CardDataEventArgs> CardDataReceived = null;
        public event EventHandler CardDataReceivedFinish = null;
        public class CardDataEventArgs : EventArgs
        {
            public CardholderItem Data { get; private set; }
            public CardDataEventArgs(CardholderItem data)
            {
                Data = data;
            }
        }
    }
}
#endif