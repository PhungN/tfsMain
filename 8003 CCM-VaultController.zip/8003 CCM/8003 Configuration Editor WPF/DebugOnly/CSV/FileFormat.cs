#if DEBUG
using System;

namespace Utilities.FileParsers
{
	public enum FileFormat
	{
		FixedWidth,
		Delimited,
	}
}
#endif