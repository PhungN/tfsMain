﻿#if DEBUG
using System.Windows.Forms;

namespace Pacom.ConfigurationEditor.WPF.DebugOnly
{
    public partial class FormTranslationFailures : Form
    {
        public FormTranslationFailures(string text)
        {
            InitializeComponent();

            textBox1.Text = text;
            textBox1.SelectionStart = 0;
            textBox1.SelectionLength = 0;
        }

        private void KeyPressed(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 27)
            {
                this.Close();
            }
        }
    }
}
#endif