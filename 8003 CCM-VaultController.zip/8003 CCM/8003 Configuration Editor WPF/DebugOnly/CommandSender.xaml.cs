﻿#if DEBUG
using Pacom.Core.Contracts;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Common.CompactFramework.Helpers;
using System.Text;
using Pacom.Commands.CommandsCommon;

namespace Pacom.ConfigurationEditor.WPF.DebugOnly
{
    /// <summary>
    /// Interaction logic for CommandSender.xaml
    /// </summary>
    public partial class CommandSender : Window
    {
        private readonly string historyFile = Path.Combine(Path.Combine(Path.GetTempPath(), "Pacom CCM"), "History.asn1");
        private readonly Dictionary<Type, CommandMessageBase> history = new Dictionary<Type, CommandMessageBase>();

        /// <summary>
        /// Don't show these in the list of commands to send.
        /// </summary>
        private Type[] hideTypes = { typeof(SetMasterKeyCommand) }; // not yet supported in CCM

        private class categoryHint
        {
            public Type Type;
            public NodeCategory Category;

            public categoryHint(Type type, NodeCategory category)
            {
                Type = type;
                Category = category;
            }
        }

        private categoryHint[] categoryHints =
            {
                new categoryHint(typeof(ActivateCommand), NodeCategory.Output),
                new categoryHint(typeof(AccessCommand), NodeCategory.Reader),
                new categoryHint(typeof(ArmAllCommand), NodeCategory.Area),
                new categoryHint(typeof(ArmCommand), NodeCategory.Area),
                new categoryHint(typeof(BlockCommand), NodeCategory.Reader),
                new categoryHint(typeof(CardAndPinOperationCommand), NodeCategory.Reader),
                new categoryHint(typeof(CardOperationCommand), NodeCategory.Reader),
                new categoryHint(typeof(IsolateCommand), NodeCategory.Device),
                new categoryHint(typeof(LoadTestCommand), NodeCategory.Device),
                new categoryHint(typeof(RestartCommand), NodeCategory.Device),
                new categoryHint(typeof(RestoreCommand), NodeCategory.Area),
                new categoryHint(typeof(SetMessageCommand), NodeCategory.Device),
                new categoryHint(typeof(TestCommand), NodeCategory.Area),
                new categoryHint(typeof(UnforceCommand), NodeCategory.Reader),
                new categoryHint(typeof(UnlockCommand), NodeCategory.Reader),
                new categoryHint(typeof(ListenInCommand), NodeCategory.Device)
            };

        private class listItem
        {
            public Type Type;
            public listItem(Type type)
            {
                Type = type;
            }

            public override string ToString()
            {
                string name = Type.ToString();
                int n = name.LastIndexOf('.');
                if (n != -1)
                {
                    name = name.Substring(n + 1);
                }
                return name;
            }
        }
        byte[] payload = null;

        private readonly Asn1DerFormatter asn1Serializer;
        string[] hiddenProperties = new string[] { "CommandType", "Address", "SourceAddress", "Topic", "UtcTimestamp", "CommandName", "CommandId" };

        public CommandSender()
        {
            InitializeComponent();
            lbCommandList.SelectionChanged += lbCommandList_SelectionChanged;
            propertyGrid.PropertyValueChanged += propertyGrid_PropertyValueChanged;
            
            bnSend.Click += bnSend_Click;
            bnClose.Click += bnClose_Click;

            asn1Serializer = new Asn1DerFormatter(getListOfHashTypes(), true, new StreamingContext());
            fillCommandList();
            loadHistory();
        }

        private void loadHistory()
        {
            history.Clear();
            if (File.Exists(historyFile) == false)
            {
                return;
            }

            using (FileStream stream = File.OpenRead(historyFile))
            {
                while (stream.Position < stream.Length)
                {
                    try
                    {
                        CommandMessageBase cmd = asn1Serializer.Deserialize(stream) as CommandMessageBase;
                        if (cmd == null)
                        {
                            continue;
                        }
                        history[cmd.GetType()] = cmd;
                    }
                    catch
                    {
                    }
                }
            }
        }

        private void addToHistory(CommandMessageBase message)
        {
            history[message.GetType()] = message;
            saveHistory();
        }

        private void saveHistory()
        {
            FileInfo hist = new FileInfo(historyFile);
            if (hist.Exists)
            {
                try
                {
                    hist.Delete();
                }
                catch
                {
                    return;
                }
            }
            try
            {
                hist.Directory.Create();
                using (var stream = hist.OpenWrite())
                {
                    foreach (var item in history.Values)
                    {
                        if ((item is CommandMessageBase) == false)
                        {
                            continue;
                        }
                        asn1Serializer.Serialize(stream, item);
                    }
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Get the list of types from assembly
        /// </summary>
        /// <returns>Hashed list of types</returns>
        private HashTypeLookup getListOfHashTypes()
        {
            var lookup = new HashTypeLookup(new List<Assembly>());
            foreach (listItem item in getListOfTypes())
            {
                lookup.AddType(item.Type);
            }
            return lookup;
        }


        private listItem[] getListOfTypes()
        {
            Assembly assembly = Assembly.Load("Pacom.Shared.Commands");
            List<listItem> result = new List<listItem>();
            foreach (Type commandType in assembly.GetTypes())
            {
                if (commandType.IsClass == false ||
                    commandType.IsInterface == true ||
                    commandType.IsAbstract == true ||
                    commandType.IsSubclassOf(typeof(CommandMessageBase)) == false ||
                    Array.IndexOf(hideTypes, commandType) != -1)
                {
                    continue;
                }
                result.Add(new listItem(commandType));
            }
            return result.ToArray();
        }

        private void fillCommandList()
        {
            listItem[] types = getListOfTypes();
            Array.Sort(types, (x, y) => x.ToString().CompareTo(y.ToString()));

            lbCommandList.Items.Clear();
            foreach (var t in types)
            {
                lbCommandList.Items.Add(new listItem(t.Type));
            }
        }

        private void lbCommandList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var item = lbCommandList.SelectedItem;
            if (item == null)
            {
                propertyGrid.SelectedObject = null;
                updateASN1();
                return;
            }

            Type type = ((listItem)item).Type;
            CommandMessageBase commandObject = null;
            if (history.ContainsKey(type))
            {
                commandObject = clone(history[type]);
            }
            if (commandObject == null)
            {
                commandObject = (CommandMessageBase)Activator.CreateInstance(type);

                foreach (var hint in categoryHints)
                {
                    if (hint.Type == type)
                    {
                        commandObject.Category = hint.Category;
                        break;
                    }
                }
            }

            var setMasterKeyCommand = commandObject as SetMasterKeyCommand;
            if (setMasterKeyCommand != null)
            {
                setMasterKeyCommand.MasterKey = new byte[32];
            }

            propertyGrid.SelectedObject = commandObject;

            for (int i = propertyGrid.Properties.Count - 1; i >= 0; i--)
            {
                var prop = ((Xceed.Wpf.Toolkit.PropertyGrid.PropertyItem)propertyGrid.Properties[i]);
                if (Array.IndexOf(hiddenProperties, prop.DisplayName) != -1)
                {
                    prop.Visibility = Visibility.Collapsed;
                    continue;
                }
            }

            updateASN1();
        }

        private void propertyGrid_PropertyValueChanged(object sender, Xceed.Wpf.Toolkit.PropertyGrid.PropertyValueChangedEventArgs e)
        {
            updateASN1();
        }

        private CommandMessageBase clone(CommandMessageBase cmd)
        {
            // Clone the command
            using (MemoryStream cloneStream = new MemoryStream())
            {
                asn1Serializer.Serialize(cloneStream, cmd);
                cloneStream.Position = 0;
                CommandMessageBase clone  = asn1Serializer.Deserialize(cloneStream) as CommandMessageBase;
                return clone;
            }
        }

        private void updateASN1()
        {
            string txt = "ERROR";
            try
            {
                object command = propertyGrid.SelectedObject;
                if (command == null)
                {
                    return;
                }

                using (MemoryStream stream = new MemoryStream())
                {
                    var setMasterKeyCommand = command as SetMasterKeyCommand;
                    if (setMasterKeyCommand != null)
                    {
                        // To implement setting the password (which needs to be encrypted), see the code in EMCS simulator:
                        //    TFSMain\WinCE-Firmware\Utilities\EmcsSimulator\CommandGenerator\FormMain.cs
                        // ..near line 144.
                    }

                    asn1Serializer.Serialize(stream, command);
                    if (stream.Length > 0)
                    {
                        payload = new byte[stream.Length];
                        stream.Position = 0;
                        stream.Read(payload, 0, (int)stream.Length);
                    }
                }
                txt = BitConverter.ToString(payload).Replace("-", "");
            }
            catch
            {
            }
            finally
            {
                txtAsASN1.Text = txt;
            }
        }

        private void bnSend_Click(object sender, RoutedEventArgs e)
        {
            if (payload == null || payload.Length == 0)
            {
                return;
            }
            StringBuilder command = new StringBuilder();
            command.Append("<asn1command>");
            command.Append(Convert.ToBase64String(payload, 0, payload.Length));
            command.Append("</asn1command>");
            commandSender.SendCommand("asn1command", command.ToString());
            addToHistory(propertyGrid.SelectedObject as CommandMessageBase);
        }

        private void bnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
#endif
