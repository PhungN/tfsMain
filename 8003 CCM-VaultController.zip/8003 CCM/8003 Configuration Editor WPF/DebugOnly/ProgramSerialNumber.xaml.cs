﻿#if DEBUG
using System.Windows;

namespace Pacom.ConfigurationEditor.WPF.DebugOnly
{
    /// <summary>
    /// Interaction logic for ProgramSerialNumber.xaml
    /// </summary>
    public partial class ProgramSerialNumber : Window
    {
        public ProgramSerialNumber()
        {
            InitializeComponent();
            tbAddress.Focus();
            bnSend.Click += bnSend_Click;
        }

        private void bnSend_Click(object sender, RoutedEventArgs e)
        {
            int addr;

            if (int.TryParse(tbAddress.Text, out addr) == false || addr < 1 || addr > 129)
            {
                if (MessageBox.Show("Invalid device loop address.  Ignore?", "Program Serial Number", MessageBoxButton.YesNo, MessageBoxImage.Error) != MessageBoxResult.Yes)
                {
                    return;
                }
            }

            if (System.Text.RegularExpressions.Regex.IsMatch(tbSerial.Text, "^[0-9]{3}[A-Z]-[0-9]{4}-[0-9]{6}$") == false)
            {
                if (MessageBox.Show("Invalid serial number.  Ignore?", "Program Serial Number", MessageBoxButton.YesNo, MessageBoxImage.Error) != MessageBoxResult.Yes)
                {
                    return;
                }
            }
            
            string command = string.Format("<serial>{0}</serial><deviceaddress>{1}</deviceaddress>", tbSerial.Text, tbAddress.Text);
            commandSender.SendCommand("programserialnumber", command);
        }
    }
}
#endif