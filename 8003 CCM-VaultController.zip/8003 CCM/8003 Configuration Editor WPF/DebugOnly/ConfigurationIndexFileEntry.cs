﻿#if DEBUG
using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.InteropServices;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common
{
    public class ConfigurationIndexFileEntry
    {
        public int Id
        {
            get;
            set;
        }

        public int Offset
        {
            get;
            set;
        }

        public int Length
        {
            get;
            set;
        }

        public bool MarkedForDeletion
        {
            get;
            set;
        }
    }
}
#endif