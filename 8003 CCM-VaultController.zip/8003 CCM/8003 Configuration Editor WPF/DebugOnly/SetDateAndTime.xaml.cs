﻿#if DEBUG
using System.Windows;

namespace Pacom.ConfigurationEditor.WPF.DebugOnly
{
    /// <summary>
    /// Interaction logic for SetDateAndTime.xaml
    /// </summary>
    public partial class SetDateAndTime : Window
    {
        public SetDateAndTime()
        {
            InitializeComponent();
            bnSend.Focus();
            bnSend.Click += bnSend_Click;
        }

        private void bnSend_Click(object sender, RoutedEventArgs e)
        {
            System.DateTime now = System.DateTime.UtcNow;
            string nowString = now.ToString("yyyy-MM-dd HH:mm:ss");
            string command = string.Format("<datetime>{0}</datetime>", nowString);
            commandSender.SendCommand("setDateTime", command);
        }
    }
}
#endif
