﻿#if DEBUG

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Xml.Linq;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Protocol;
using Pacom.Peripheral.ConfigurationEditorFor8003;
using System.Net;
using System.Collections.ObjectModel;
using System.Windows.Controls;

namespace Pacom.ConfigurationEditor.WPF.DebugOnly
{
    /// <summary>
    /// Interaction logic for GmsElevatorFloorsAccess.xaml
    /// </summary>
    public partial class GmsElevatorFloorsAccess : Window
    {
        private CardholderDownloader downloader;
        private ObservableCollection<CardholderItem> elevatorFloorsData;
        private ObservableCollection<ElevatorFloorsViewItem> elevatorFloorsViewItems;
        private CardholderItem selectCardHolderItem = null;
        private ElevatorDownloadHelper uploadDownloadHelper;
        public GmsElevatorFloorsAccess()
        {
            InitializeComponent();
            elevatorFloorsData = new ObservableCollection<CardholderItem>();
            elevatorFloorsViewItems = new ObservableCollection<ElevatorFloorsViewItem>();
            downloader = new CardholderDownloader();
            downloader.CardDataReceived += OnCardDataReceived;
            downloader.CardDataReceivedFinish += OnCardDataReceivedFinish;
            uploadDownloadHelper = new ElevatorDownloadHelper(downloader);
            uploadDownloadHelper.DataLoaded += OnDataLoaded;

            cardHoldersListView.ItemsSource = elevatorFloorsViewItems;
            scheduleIdList.ItemsSource = ControllerConfigurationManager.GetAvailableSchedules();
        }

        private void OnCardDataReceivedFinish(object sender, EventArgs e)
        {
            //loadButton.IsEnabled = true;
            enableLoadButton();
        }

        private void OnCardDataReceived(object sender, CardholderDownloader.CardDataEventArgs e)
        {
            addItem(e.Data);
        }

        private void enableLoadButton()
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.Invoke(new Action(enableLoadButton));
            }
            else
            {
                loadButton.IsEnabled = true;
            }
        }
        private void addItem(CardholderItem item)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.Invoke(new Action<CardholderItem>(addItem), item);
            }
            else
            {
                elevatorFloorsData.Add(item);

                elevatorFloorsViewItems.Add(new ElevatorFloorsViewItem()
                {
                    CardNumber = item.CardNumber,
                    TooltipText = $"Card Holder ID: {item.CardholderId}{Environment.NewLine}"
                });

                if(selectCardHolderItem == null)
                {
                    selectCardHolderItem = item;
                    cardHoldersListView.SelectedIndex = 0;
                }
            }
        }
        private void OnDataLoaded(object sender, EventArgs e)
        {
            //elevatorFloorsData = uploadDownloadHelper.CardHolderItems;
            //populateCardHoldersListBox();
            //if (elevatorFloorsData.Count > 0)
            //    cardHoldersListView.SelectedIndex = 0;
        }

        //private void populateCardHoldersListBox()
        //{
        //    if (!Dispatcher.CheckAccess())
        //    {
        //        Dispatcher.Invoke(new Action(populateCardHoldersListBox));
        //    }
        //    else
        //    {
        //        cardHoldersListView.ItemsSource = null;
        //        List<ElevatorFloorsViewItem> items = new List<ElevatorFloorsViewItem>();
        //        foreach (var item in elevatorFloorsData)
        //        {
        //            StringBuilder sb = new StringBuilder();
        //            sb.Append($"Card Holder ID: {item.CardholderId}{Environment.NewLine}");
        //            items.Add(new ElevatorFloorsViewItem()
        //            {
        //                CardNumber = item.CardNumber,
        //                TooltipText = sb.ToString()
        //            }); ;
        //        }
        //        cardHoldersListView.ItemsSource = items;
        //    }
        //}


        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            uploadDownloadHelper.CardHolderItems.Clear();
            uploadDownloadHelper.LoadData();
            loadButton.IsEnabled = false;
            selectCardHolderItem = null;
            elevatorFloorsData.Clear();
            elevatorFloorsViewItems.Clear();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (selectCardHolderItem == null)
                return;
            uploadDownloadHelper.SaveData(selectCardHolderItem);
        }

        private void floorsAccessCheckBoxes_DataChanged(object sender, UserControls.CheckBoxesUserControl.DataChangedEventArgs e)
        {
            if (e.Data != null && e.Data.Length > 0)
            {
                selectCardHolderItem.FloorsAccess = e.Data;
            }
        }

        private void cardHoldersListView_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            int index = cardHoldersListView.SelectedIndex;
            if (index >= 0 && index < elevatorFloorsData.Count)
            {
                selectCardHolderItem = elevatorFloorsData[index];
                saveButton.IsEnabled = true;
                this.DataContext = selectCardHolderItem;
                floorsAccessCheckBoxes.Data = selectCardHolderItem.FloorsAccess;

                int currentSchedule = selectCardHolderItem.FloorsAccessTimezoneId;
                for(int i=0; i<scheduleIdList.Items.Count; i++)
                {
                    ComboBoxItemContents comboBoxItem = scheduleIdList.Items[i] as ComboBoxItemContents;
                    if(comboBoxItem != null)
                    {
                        if((int)comboBoxItem.Value == currentSchedule)
                        {
                            scheduleIdList.SelectedIndex = i;
                            break;
                        }
                    }
                }

            }
            else
            {
                selectCardHolderItem = null;
                saveButton.IsEnabled = false;
            }
        }

        private void AccessScheduleIdList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            ComboBox comboBox = sender as ComboBox;
            if (comboBox != null)
            {
                ComboBoxItemContents selectedItem = comboBox.SelectedItem as ComboBoxItemContents;
                if (selectedItem != null && selectCardHolderItem != null)
                {
                    selectCardHolderItem.FloorsAccessTimezoneId = (int)selectedItem.Value;
                }
            }
        }

        private void ReaderScheduleIdList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {

        }
    }

    public class ElevatorDownloadHelper
    {
#region private members
        private CardholderDownloader downloader;
        private TcpIPConnection cardholderConnection = null;
        private const Int32 cardholderPort = 8282;
        private byte[] dataReceived = new byte[0];
        private List<CardholderItem> cardHolderItems = new List<CardholderItem>();
#endregion

#region constructors
        public ElevatorDownloadHelper(CardholderDownloader downloader)
        {
            this.downloader = downloader;
        }
#endregion

#region private methods

        private void cardholderConnection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            byte[] dataBuffer = new byte[dataReceived.Length + e.Data.Length];
            Array.Copy(dataReceived, 0, dataBuffer, 0, dataReceived.Length);
            Array.Copy(e.Data, 0, dataBuffer, dataReceived.Length, e.Data.Length);
            dataReceived = dataBuffer;
            // Discard data if too much
            if (dataReceived.Length > 500000)
                dataReceived = new byte[0];
            // Check if closing tag has been found
            if (closingResponseFound(dataReceived) == true)
            {
                // Parse response
                XDocument xdoc = processRawCommand(dataReceived);
                switch (getResponseType(xdoc))
                {
                    case ResponseType.Cardholder:
                        //parseCardholder(xdoc);
                        break;
                    case ResponseType.Ok:
                        //dataReceivedResponseOk = true;
                        break;
                    default:
                        break;
                }
                dataReceived = new byte[0];
            }
        }

        private void cardholderConnection_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (e.NewConnectionState == Pacom.Peripheral.Protocol.ConnectionState.Disconnected)
            {
                disconnectConnection();
            }
            else if (e.NewConnectionState == Pacom.Peripheral.Protocol.ConnectionState.Connected)
            {
                //cardholderProcessStatus.Text = string.Format("Connected to {0}:{1}", cardholderRemoteAddr.ToString(), cardholderPort.ToString());
            }
        }

        private void disconnectConnection()
        {
            if (cardholderConnection != null)
            {
                try
                {
                    cardholderConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(cardholderConnection_DataReceived);
                    cardholderConnection.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(cardholderConnection_ConnectionStateChanged);
                    cardholderConnection.Dispose();
                    cardholderConnection = null;
                }
                catch (Exception ex)
                {
                    Logger.LogMessage(LoggingLevel.Error, "Editor: Error while disconnecting. {0}", ex.Message);
                }
            }
        }
        private bool closingResponseFound(byte[] data)
        {
            byte[] responseEnd = Encoding.ASCII.GetBytes(@"</response>");
            if (data.Length < responseEnd.Length)
                return false;

            for (int i = 1; i <= responseEnd.Length; i++)
            {
                if (data[data.Length - i] != responseEnd[responseEnd.Length - i])
                {
                    return false;
                }
            }
            return true;
        }

        private enum ResponseType
        {
            Unknown,
            NoData,
            Ok,
            Error,
            Cardholder,
            CardholderCount
        }

        private XDocument processRawCommand(byte[] rawCommand)
        {
            try
            {
                string commandAsString = Encoding.ASCII.GetString(rawCommand, 0, rawCommand.Length);
                return XDocument.Parse(commandAsString);
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Error, "Editor: Error while processing incoming message. {0}", ex.Message);
                return null;
            }
        }

        private ResponseType getResponseType(XDocument xdoc)
        {
            if (xdoc == null)
                return ResponseType.Unknown;

            ResponseType result = ResponseType.Unknown;
            try
            {
                var request = xdoc.Element("response");
                XAttribute xRequestType = request.Attribute("type");
                if (xRequestType != null && xRequestType.Value != null)
                {
                    switch(xRequestType.Value)
                    {
                        case "nodata": result = ResponseType.NoData; break;
                        case "error": result = ResponseType.Error; break;
                        case "Ok": result = ResponseType.Ok; break;
                        case "cardholder": result = ResponseType.Cardholder; break;
                        case "cardholdercount": result = ResponseType.CardholderCount; break;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Error, "Editor: Error while parsing response type. {0}", ex.Message);
                result = ResponseType.Unknown;
            }
            return result;
        }

        private byte[] floorsAccessItemToXmlByteArray(CardholderItem item)
        {
            string cardNumber = item.CardholderId.ToString();
            var xml = new XElement("request",
               new XAttribute("type", "setelevatorfloorsaccess"),
               new XElement("cardholder",
                   new XAttribute("id", item.Id.ToString()), 
                   new XAttribute("number", cardNumber),
                   new XElement("startdate", item.StartDate.ToString("dd/MM/yyyy")),
                   new XElement("enddate", item.EndDate.ToString("dd/MM/yyyy")),
                   getFloorAccessAsXml(item),
                   new XElement("floorsAccessTimezoneId", item.FloorsAccessTimezoneId.ToString())
                   )
            );
            return Encoding.ASCII.GetBytes(xml.ToString());
        }

        private XContainer getFloorAccessAsXml(CardholderItem item)
        {
            var xFloors = new XElement("floors");
            if (item.FloorsAccess != null && item.FloorsAccess.Length > 0)
            {
                for (int i = 0; i < item.FloorsAccess.Length; i++)
                {
                    if (item.FloorsAccess[i] == true)
                        xFloors.Add(new XElement("floor", i + 1));
                }
            }
            return xFloors;
        }

#endregion

#region public properties
        public List<CardholderItem> CardHolderItems
        {
            get { return cardHolderItems; }
        }
#endregion

#region public events
        public event EventHandler DataLoaded;
#endregion

#region public methods
        public void LoadData()
        {
            cardHolderItems.Clear();

            downloader.RequestDownload(CardholderDownloader.DownloadStateProgressType.SendRequestForUniqueCardholderIds);
            {
                if (downloader.CardholdersExists == true)
                {
                    foreach (var item in downloader.ReceivedCardholderItems)
                    {
                        cardHolderItems.Add(item);
                    }

                    DataLoaded?.Invoke(this, EventArgs.Empty);
                }
            }
        }

        public void SaveData(CardholderItem item)
        {
            dataReceived = new byte[0];
            if (cardholderConnection == null)
            {
                cardholderConnection = new TcpIPConnection(new IPEndPoint(Settings.ControllerIPAddress, cardholderPort));
                cardholderConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(cardholderConnection_DataReceived);
                cardholderConnection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(cardholderConnection_ConnectionStateChanged);
                cardholderConnection.Connect();
            }
            if (cardholderConnection != null)
            {
                cardholderConnection.Send(floorsAccessItemToXmlByteArray(item), null);
            }
        }
#endregion
    }

    public class ElevatorFloorsViewItem
    {
        public string CardNumber { get; set; }
        public string TooltipText { get; set; }
    }
}
#else
using System.Windows;
namespace Pacom.ConfigurationEditor.WPF.DebugOnly
{
    /// <summary>
    /// Interaction logic for ElevatorFloorsAccess.xaml
    /// </summary>
    public partial class GmsElevatorFloorsAccess : Window
    {
        public GmsElevatorFloorsAccess()
        {
            InitializeComponent();
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
        }

        private void cardHoldersListView_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
        }

        private void AccessScheduleIdList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
        }

        
    }
}
#endif