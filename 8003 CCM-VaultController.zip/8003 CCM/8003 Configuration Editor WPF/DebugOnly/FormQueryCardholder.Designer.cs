﻿#if DEBUG
namespace Pacom.Peripheral.ConfigurationEditorFor8003
{
    partial class FormQueryCardholder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

#region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormQueryCardholder));
            this.btnQuery = new System.Windows.Forms.Button();
            this.CardholderId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ScheduleList = new System.Windows.Forms.ListBox();
            this.ScheduleListCtx = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuScheduleAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuScheduleDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuScheduleEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSave = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.UserPin = new System.Windows.Forms.TextBox();
            this.GroupId = new System.Windows.Forms.TextBox();
            this.Blocked = new System.Windows.Forms.ComboBox();
            this.Expired = new System.Windows.Forms.ComboBox();
            this.LastUsed = new System.Windows.Forms.TextBox();
            this.Version = new System.Windows.Forms.TextBox();
            this.btnQueryCount = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.cardholderProcessStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.CardholderCount = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnLoadFromCSV = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.FacilityEdit = new System.Windows.Forms.TextBox();
            this.IssueEdit = new System.Windows.Forms.TextBox();
            this.CodeEdit = new System.Windows.Forms.TextBox();
            this.UpdateCardHolderId = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.UserFlagsListBox = new System.Windows.Forms.CheckedListBox();
            this.ScheduleListCtx.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnQuery
            // 
            this.btnQuery.Location = new System.Drawing.Point(771, 19);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(75, 23);
            this.btnQuery.TabIndex = 10;
            this.btnQuery.Text = "Query";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // CardholderId
            // 
            this.CardholderId.Location = new System.Drawing.Point(111, 23);
            this.CardholderId.Name = "CardholderId";
            this.CardholderId.Size = new System.Drawing.Size(428, 20);
            this.CardholderId.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Cardholder Id:";
            // 
            // ScheduleList
            // 
            this.ScheduleList.ContextMenuStrip = this.ScheduleListCtx;
            this.ScheduleList.FormattingEnabled = true;
            this.ScheduleList.Items.AddRange(new object[] {
            ""});
            this.ScheduleList.Location = new System.Drawing.Point(560, 39);
            this.ScheduleList.Name = "ScheduleList";
            this.ScheduleList.Size = new System.Drawing.Size(198, 225);
            this.ScheduleList.TabIndex = 9;
            // 
            // ScheduleListCtx
            // 
            this.ScheduleListCtx.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuScheduleAdd,
            this.mnuScheduleDelete,
            this.mnuScheduleEdit});
            this.ScheduleListCtx.Name = "ScheduleListCtx";
            this.ScheduleListCtx.Size = new System.Drawing.Size(158, 70);
            // 
            // mnuScheduleAdd
            // 
            this.mnuScheduleAdd.Name = "mnuScheduleAdd";
            this.mnuScheduleAdd.Size = new System.Drawing.Size(157, 22);
            this.mnuScheduleAdd.Text = "Add schedule";
            this.mnuScheduleAdd.Click += new System.EventHandler(this.mnuScheduleAdd_Click);
            // 
            // mnuScheduleDelete
            // 
            this.mnuScheduleDelete.Name = "mnuScheduleDelete";
            this.mnuScheduleDelete.Size = new System.Drawing.Size(157, 22);
            this.mnuScheduleDelete.Text = "Delete schedule";
            this.mnuScheduleDelete.Click += new System.EventHandler(this.mnuScheduleDelete_Click);
            // 
            // mnuScheduleEdit
            // 
            this.mnuScheduleEdit.Name = "mnuScheduleEdit";
            this.mnuScheduleEdit.Size = new System.Drawing.Size(157, 22);
            this.mnuScheduleEdit.Text = "Edit schedule";
            this.mnuScheduleEdit.Click += new System.EventHandler(this.mnuScheduleEdit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(771, 48);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(557, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Schedules";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "User pin:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(57, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Group Id:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(59, 164);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Blocked";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(63, 191);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Expired";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 224);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Last used (readonly):";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 249);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Version (readonly):";
            // 
            // UserPin
            // 
            this.UserPin.Location = new System.Drawing.Point(111, 108);
            this.UserPin.Name = "UserPin";
            this.UserPin.Size = new System.Drawing.Size(87, 20);
            this.UserPin.TabIndex = 5;
            // 
            // GroupId
            // 
            this.GroupId.Location = new System.Drawing.Point(111, 134);
            this.GroupId.Name = "GroupId";
            this.GroupId.Size = new System.Drawing.Size(87, 20);
            this.GroupId.TabIndex = 6;
            // 
            // Blocked
            // 
            this.Blocked.FormattingEnabled = true;
            this.Blocked.Items.AddRange(new object[] {
            "True",
            "False"});
            this.Blocked.Location = new System.Drawing.Point(111, 160);
            this.Blocked.Name = "Blocked";
            this.Blocked.Size = new System.Drawing.Size(87, 21);
            this.Blocked.TabIndex = 7;
            // 
            // Expired
            // 
            this.Expired.FormattingEnabled = true;
            this.Expired.Items.AddRange(new object[] {
            "True",
            "False"});
            this.Expired.Location = new System.Drawing.Point(111, 188);
            this.Expired.Name = "Expired";
            this.Expired.Size = new System.Drawing.Size(87, 21);
            this.Expired.TabIndex = 8;
            // 
            // LastUsed
            // 
            this.LastUsed.Location = new System.Drawing.Point(111, 221);
            this.LastUsed.Name = "LastUsed";
            this.LastUsed.ReadOnly = true;
            this.LastUsed.Size = new System.Drawing.Size(171, 20);
            this.LastUsed.TabIndex = 17;
            // 
            // Version
            // 
            this.Version.Location = new System.Drawing.Point(111, 247);
            this.Version.Name = "Version";
            this.Version.ReadOnly = true;
            this.Version.Size = new System.Drawing.Size(41, 20);
            this.Version.TabIndex = 18;
            // 
            // btnQueryCount
            // 
            this.btnQueryCount.Location = new System.Drawing.Point(771, 76);
            this.btnQueryCount.Name = "btnQueryCount";
            this.btnQueryCount.Size = new System.Drawing.Size(75, 23);
            this.btnQueryCount.TabIndex = 12;
            this.btnQueryCount.Text = "Query Count";
            this.btnQueryCount.UseVisualStyleBackColor = true;
            this.btnQueryCount.Click += new System.EventHandler(this.btnQueryCount_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(801, 109);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "Cardholder count:";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.cardholderProcessStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 310);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(939, 22);
            this.statusStrip1.TabIndex = 22;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(68, 17);
            this.toolStripStatusLabel1.Text = "Connected:";
            // 
            // cardholderProcessStatus
            // 
            this.cardholderProcessStatus.Name = "cardholderProcessStatus";
            this.cardholderProcessStatus.Size = new System.Drawing.Size(86, 17);
            this.cardholderProcessStatus.Text = "Not connected";
            // 
            // CardholderCount
            // 
            this.CardholderCount.AutoSize = true;
            this.CardholderCount.Location = new System.Drawing.Point(774, 109);
            this.CardholderCount.Name = "CardholderCount";
            this.CardholderCount.Size = new System.Drawing.Size(27, 13);
            this.CardholderCount.TabIndex = 23;
            this.CardholderCount.Text = "N/A";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(771, 136);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 13;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnLoadFromCSV
            // 
            this.btnLoadFromCSV.Location = new System.Drawing.Point(771, 187);
            this.btnLoadFromCSV.Name = "btnLoadFromCSV";
            this.btnLoadFromCSV.Size = new System.Drawing.Size(75, 35);
            this.btnLoadFromCSV.TabIndex = 14;
            this.btnLoadFromCSV.Text = "Load from CSV";
            this.btnLoadFromCSV.UseVisualStyleBackColor = true;
            this.btnLoadFromCSV.Click += new System.EventHandler(this.btnLoadFromCSV_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(852, 188);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 98);
            this.button1.TabIndex = 16;
            this.button1.Text = "Create template CSV";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(771, 230);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 56);
            this.button2.TabIndex = 15;
            this.button2.Text = "Download from controller";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            // 
            // FacilityEdit
            // 
            this.FacilityEdit.Location = new System.Drawing.Point(111, 60);
            this.FacilityEdit.Name = "FacilityEdit";
            this.FacilityEdit.Size = new System.Drawing.Size(87, 20);
            this.FacilityEdit.TabIndex = 1;
            // 
            // IssueEdit
            // 
            this.IssueEdit.Location = new System.Drawing.Point(204, 60);
            this.IssueEdit.Name = "IssueEdit";
            this.IssueEdit.Size = new System.Drawing.Size(87, 20);
            this.IssueEdit.TabIndex = 2;
            // 
            // CodeEdit
            // 
            this.CodeEdit.Location = new System.Drawing.Point(298, 60);
            this.CodeEdit.Name = "CodeEdit";
            this.CodeEdit.Size = new System.Drawing.Size(87, 20);
            this.CodeEdit.TabIndex = 3;
            // 
            // UpdateCardHolderId
            // 
            this.UpdateCardHolderId.Location = new System.Drawing.Point(391, 50);
            this.UpdateCardHolderId.Name = "UpdateCardHolderId";
            this.UpdateCardHolderId.Size = new System.Drawing.Size(148, 38);
            this.UpdateCardHolderId.TabIndex = 4;
            this.UpdateCardHolderId.Text = "Update Cardholder Id or\r\nFacility / Isssue / Code";
            this.UpdateCardHolderId.UseVisualStyleBackColor = true;
            this.UpdateCardHolderId.Click += new System.EventHandler(this.UpdateCardHolderId_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(63, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 39);
            this.label10.TabIndex = 35;
            this.label10.Text = "Facility\r\nIssue\r\nCode";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.UserFlagsListBox);
            this.groupBox1.Location = new System.Drawing.Point(286, 94);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(264, 173);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "User Flags";
            // 
            // UserFlagsListBox
            // 
            this.UserFlagsListBox.FormattingEnabled = true;
            this.UserFlagsListBox.Items.AddRange(new object[] {
            "Dual User Control",
            "Extended Shunt/Strike Time",
            "Add Last Code Byte to PIN",
            "Store Code for Degraded Mode",
            "Use PIN to Access",
            "Supervisor Operation",
            "Executive Operation",
            "Escort Capable",
            "Escort Required",
            "Permanent User"});
            this.UserFlagsListBox.Location = new System.Drawing.Point(3, 15);
            this.UserFlagsListBox.Name = "UserFlagsListBox";
            this.UserFlagsListBox.Size = new System.Drawing.Size(256, 154);
            this.UserFlagsListBox.TabIndex = 6;
            // 
            // FormQueryCardholder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(939, 332);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.CodeEdit);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.UpdateCardHolderId);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.IssueEdit);
            this.Controls.Add(this.FacilityEdit);
            this.Controls.Add(this.btnLoadFromCSV);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.CardholderCount);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnQueryCount);
            this.Controls.Add(this.Version);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.Blocked);
            this.Controls.Add(this.LastUsed);
            this.Controls.Add(this.Expired);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GroupId);
            this.Controls.Add(this.UserPin);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ScheduleList);
            this.Controls.Add(this.btnQuery);
            this.Controls.Add(this.CardholderId);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(737, 370);
            this.Name = "FormQueryCardholder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Cardholder query";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormQueryCardholder_FormClosing);
            this.Load += new System.EventHandler(this.FormQueryCardholder_Load);
            this.ScheduleListCtx.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

#endregion

        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.TextBox CardholderId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox ScheduleList;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox UserPin;
        private System.Windows.Forms.TextBox GroupId;
        private System.Windows.Forms.ComboBox Blocked;
        private System.Windows.Forms.ComboBox Expired;
        private System.Windows.Forms.TextBox LastUsed;
        private System.Windows.Forms.TextBox Version;
        private System.Windows.Forms.Button btnQueryCount;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel cardholderProcessStatus;
        private System.Windows.Forms.Label CardholderCount;
        private System.Windows.Forms.ContextMenuStrip ScheduleListCtx;
        private System.Windows.Forms.ToolStripMenuItem mnuScheduleAdd;
        private System.Windows.Forms.ToolStripMenuItem mnuScheduleDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuScheduleEdit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnLoadFromCSV;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox FacilityEdit;
        private System.Windows.Forms.TextBox IssueEdit;
        private System.Windows.Forms.TextBox CodeEdit;
        private System.Windows.Forms.Button UpdateCardHolderId;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckedListBox UserFlagsListBox;
    }
}
#endif