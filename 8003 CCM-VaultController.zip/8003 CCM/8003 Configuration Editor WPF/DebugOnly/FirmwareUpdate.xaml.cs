﻿#if DEBUG
using System.Text;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using System;
using Pacom.Peripheral.Common;

namespace Pacom.ConfigurationEditor.WPF.DebugOnly
{
    /// <summary>
    /// Interaction logic for FirmwareUpdate.xaml
    /// </summary>
    public partial class FirmwareUpdate : Window
    {
        public FirmwareUpdate()
        {
            InitializeComponent();
            bnBrowse.Click += bnBrowse_Click;
            bnSend.Click += bnSend_Click;
            string[] names = Enum.GetNames(typeof(DeviceType));
            foreach (string name in names)
            {
                cbDeviceType.Items.Add(name);
            }

            tbEprFile.Focus();
        }

        private void bnBrowse_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "EPR Files (*.epr)|*.epr|All Files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == false)
            {
                return;
            }
            tbEprFile.Text = openFileDialog.FileName;
        }

        private void bnSend_Click(object sender, RoutedEventArgs e)
        {
            byte[] data = null;
            try
            {
                data = File.ReadAllBytes(tbEprFile.Text);
            }
            catch
            {
                MessageBox.Show("Unable to read from " + tbEprFile.Text, "Firmware Update", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            StringBuilder command = new StringBuilder();
            command.Append("<firmwareupdateimage>");
            command.Append("<version>");
            command.Append(Base64.Encode(tbVersion.Text));
            command.Append("</version>");
            command.Append("<devicetype>");
            command.Append(Base64.Encode(cbDeviceType.Text));
            command.Append("</devicetype>");
            command.Append("<image>");
            command.Append(Convert.ToBase64String(data, 0, data.Length));
            command.Append("</image>");
            command.Append("</firmwareupdateimage>");
            commandSender.SendCommand("firmwareupdateimage", command.ToString());
        }
    }
}
#endif