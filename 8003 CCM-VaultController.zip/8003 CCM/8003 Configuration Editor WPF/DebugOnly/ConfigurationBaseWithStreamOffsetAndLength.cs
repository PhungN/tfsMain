﻿#if DEBUG
using Pacom.Core.Contracts;

namespace Pacom.Peripheral.Common
{
    public class ConfigurationBaseWithStreamOffsetAndLength
    {
        public ConfigurationBase Configuration
        {
            get;
            set;
        }

        public int Offset
        {
            get;
            set;
        }

        public int Length
        {
            get;
            set;
        }
    }
}
#endif