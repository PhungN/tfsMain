﻿#if DEBUG
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Threading;
using System.IO;
using System.Xml.Linq;
using Pacom.Core.Contracts;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Protocol;
using Pacom.Serialization.Formatters.Asn1;
using Pacom.Peripheral.Common.Configuration;
using Utilities.FileParsers;
using Pacom.Peripheral.Common.AccessControl;
using Pacom.ConfigurationEditor.WPF;

namespace Pacom.Peripheral.ConfigurationEditorFor8003
{
    public partial class FormQueryCardholder : Form
    {
        private delegate void UpdateCardholderDelegate(CardholderItem item);
        private UpdateCardholderDelegate UpdateCardholderMethod = null;

        private delegate void UpdateCardholderCountDelegate(int count);
        private UpdateCardholderCountDelegate UpdateCardholderCountMethod = null;
        private LegacyCardUserFlags cardUserFlags = LegacyCardUserFlags.None;

        public FormQueryCardholder()
        {
            InitializeComponent();
            UpdateCardholderMethod = frmUpdateCardholderMethod;
            UpdateCardholderCountMethod = frmUpdateCardholderCountMethod;

            UserFlagsListBox.ItemCheck += UserFlagsListBox_ItemCheck;
        }

        private void UserFlagsListBox_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            int val = (int)cardUserFlags;
            if(e.NewValue == CheckState.Checked)
                val |= (1 << e.Index);
            else
                val &= ~(1 << e.Index);
            cardUserFlags = (LegacyCardUserFlags)val;
        }

        private TcpIPConnection cardholderConnection = null;
        private Int32 cardholderPort;
        private IPAddress cardholderRemoteAddr;

        private byte[] dataReceived = new byte[0];
        private ManualResetEvent dataReceivedEvent = new ManualResetEvent(false);
        private bool dataReceivedResponseOk = false;

        private List<ReaderScheduleIdPair> readerScheduleList = new List<ReaderScheduleIdPair>();
        private int sortReaderScheduleListMethod(ReaderScheduleIdPair x, ReaderScheduleIdPair y)
        {
            if (x.ReaderId < y.ReaderId)
                return -1;
            else if (x.ReaderId > y.ReaderId)
                return 1;
            else
                return 0;
        }         

        private void connectToController()
        {
            dataReceivedEvent.Reset();
            dataReceived = new byte[0];
            if (cardholderConnection == null)
            {
                cardholderPort = 8282;
                cardholderRemoteAddr = Settings.ControllerIPAddress;

                cardholderConnection = new TcpIPConnection(new IPEndPoint(cardholderRemoteAddr, cardholderPort));
                cardholderConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(cardholderConnection_DataReceived);
                cardholderConnection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(cardholderConnection_ConnectionStateChanged);
                cardholderConnection.Connect();
            }
        }
        
        private void btnQuery_Click(object sender, EventArgs e)
        {
            connectToController();            
            string query = string.Format(
                "<request type='getcardholder'>" +
                "  <cardholderid>{0}</cardholderid>" +
                "</request>", CardholderId.Text);
            
            clearForm();
            if (cardholderConnection != null)
                cardholderConnection.Send(Encoding.ASCII.GetBytes(query), null);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            connectToController();           
            if (cardholderConnection != null)
            {
                CardholderItem item = new CardholderItem();
                if (string.IsNullOrEmpty(CardholderId.Text) == false)
                    item.CardholderId = long.Parse(CardholderId.Text);
                if (string.IsNullOrEmpty(UserPin.Text) == false)
                    item.UserPin = int.Parse(UserPin.Text);
                if (string.IsNullOrEmpty(GroupId.Text) == false)
                    item.GroupId = int.Parse(GroupId.Text);
                item.Blocked = Blocked.SelectedIndex == 0 ? true : false;
                item.Expired = Expired.SelectedIndex == 0 ? true : false;
                item.UserFlags = cardUserFlags;

                foreach (var itemList in readerScheduleList)
                {
                    item.ReaderSchedules.Add(itemList);
                }
                cardholderConnection.Send(sendCardholderItem(item), null);
                clearForm();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            connectToController();
            string query = string.Format(
                "<request type='deletecardholder'>" +
                "  <cardholderid>{0}</cardholderid>" +
                "</request>", CardholderId.Text);

            clearForm();
            if (cardholderConnection != null)
                cardholderConnection.Send(Encoding.ASCII.GetBytes(query), null);
        }

        private void btnQueryCount_Click(object sender, EventArgs e)
        {
            connectToController();
            string query = string.Format(
                "<request type='countcardholder'>" +
                "</request>", CardholderId.Text);

            if (cardholderConnection != null)
            {
                clearForm();
                cardholderConnection.Send(Encoding.ASCII.GetBytes(query), null);
            }
        }

        private byte[] sendCardholderItem(CardholderItem item)
        {
             var xml = new XElement("request",
                new XAttribute("type", "setcardholder"),
                new XElement("cardholder",
                    new XAttribute("cardholderid", item.CardholderId.ToString()),
                    new XElement("userpin", item.UserPin.ToString()),
                    new XElement("groupid", item.GroupId.ToString()),
                    new XElement("blocked", item.Blocked.ToString()),
                    new XElement("expired", item.Expired.ToString()),
                    new XElement("userflags", (int)item.UserFlags),
                    new XElement("startdate", item.StartDate.ToString()),
                    new XElement("enddate", item.EndDate.ToString()),
                    getSchedulesAsXml(item))
             );
             return Encoding.ASCII.GetBytes(xml.ToString());
        }

        private XContainer getSchedulesAsXml(CardholderItem item)
        {
            var xSchedules = new XElement("schedules");
            foreach (var readerScheduleIdPair in item.ReaderSchedules)
            {
                xSchedules.Add(new XElement("schedule", readerScheduleIdPair.ScheduleId,
                    new XAttribute("readerid", readerScheduleIdPair.ReaderId)));
            }
            return xSchedules;
        }
               
        private void cardholderConnection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            byte[] dataReceivedNew = new byte[dataReceived.Length + e.Data.Length];
            Array.Copy(dataReceived, 0, dataReceivedNew, 0, dataReceived.Length);
            Array.Copy(e.Data, 0, dataReceivedNew, dataReceived.Length, e.Data.Length);
            dataReceived = dataReceivedNew;
            // Discard data if too much
            if (dataReceived.Length > 500000)
                dataReceived = new byte[0];
            // Check if closing tag has been found
            if (closingResponseFound(dataReceived) == true)
            {
                // Parse response
                XDocument xdoc = processRawCommand(dataReceived);
                switch (getResponseType(xdoc))
                {
                    case ResponseType.CardholderCount:
                        parseCardholderCount(xdoc);
                        break;
                    case ResponseType.Cardholder:
                        parseCardholder(xdoc);
                        break;
                    case ResponseType.Ok:
                        dataReceivedResponseOk = true;
                        break;
                    default:
                        break;
                }
                dataReceivedEvent.Set();
                dataReceived = new byte[0];
            }
        }

        private bool closingResponseFound(byte[] data)
        {
            byte[] responseEnd = Encoding.ASCII.GetBytes(@"</response>");
            if (data.Length < responseEnd.Length)
                return false;

            for (int i = 1; i <= responseEnd.Length; i++)
            {
                if (data[data.Length - i] != responseEnd[responseEnd.Length - i])
                {
                    return false;
                }
            }
            return true;
        }


        private enum ResponseType
        {
            Unknown,
            NoData,
            Ok,
            Error,
            Cardholder,
            CardholderCount
        }

        private XDocument processRawCommand(byte[] rawCommand)
        {
            try
            {
                string commandAsString = Encoding.ASCII.GetString(rawCommand, 0, rawCommand.Length);
                return XDocument.Parse(commandAsString);
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Error, "Editor: Error while processing incoming message. {0}", ex.Message);
                return null;
            }
        }

        private ResponseType getResponseType(XDocument xdoc)
        {

            /*
            * <response type='?????'>
            *    ....
            * </response>
            */

            if (xdoc == null)
                return ResponseType.Unknown;

            ResponseType result = ResponseType.Unknown;
            try
            {
                var request = xdoc.Element("response");
                XAttribute xRequestType = request.Attribute("type");

                if (xRequestType != null && xRequestType.Value != null)
                {
                    if (string.Compare(xRequestType.Value, "nodata", true) == 0)
                        result = ResponseType.NoData;
                    else if (string.Compare(xRequestType.Value, "error", true) == 0)
                        result = ResponseType.Error;
                    else if (string.Compare(xRequestType.Value, "Ok", true) == 0)
                        result = ResponseType.Ok;
                    else if (string.Compare(xRequestType.Value, "cardholder", true) == 0)
                        result = ResponseType.Cardholder;
                    else if (string.Compare(xRequestType.Value, "cardholdercount", true) == 0)
                        result = ResponseType.CardholderCount;                    
                }
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Error, "Editor: Error while parsing response type. {0}", ex.Message);
                result = ResponseType.Unknown;
            }
            return result;
        }

        private void parseCardholderCount(XDocument xdoc)
        {
            try
            {
                var xRequest = xdoc.Element("response");
                var xCount = xRequest.Element("count");
                if (xCount != null)
                {
                    int count = int.Parse(xCount.Value);
                    CardholderCount.Invoke(UpdateCardholderCountMethod, count);
                }
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Error, "Editor: Error while parsing incoming cardholder count data. {0}", ex.Message);
            }
        }

        private void parseCardholder(XDocument xdoc)
        {
            /*
            *  <response type='cardholder'> 
            *      <cardholder cardholderid='77834873'>
            *         <userpin>221</userpin>
            *         <groupid>1</groupid>
            *         <blocked>False</blocked>
            *         <expired>True</expired>
            *         <lastused>9873875975974395</lastused>
            *         <version></version>
            *      </cardholder>
            *  </response>
            */
            try
            {
                CardholderItem item = new CardholderItem();
                cardUserFlags = LegacyCardUserFlags.None;

                var xRequest = xdoc.Element("response");
                var xCardholder = xRequest.Element("cardholder");
                if (xCardholder != null)
                {
                    item.CardholderId = long.Parse(xCardholder.Attribute("cardholderid").Value);
                }
                item.UserPin = int.Parse(xCardholder.Element("userpin").Value);
                item.GroupId = int.Parse(xCardholder.Element("groupid").Value);
                item.Version = byte.Parse(xCardholder.Element("version").Value);

                if (xCardholder.Element("blocked").Value.ToLower() == "true")
                    item.Blocked = true;
                else
                    item.Blocked = false;

                if (xCardholder.Element("expired").Value.ToLower() == "true")
                    item.Expired = true;
                else
                    item.Expired = false;

                LegacyCardUserFlags userFlags = LegacyCardUserFlags.None;
                if(Enum.TryParse<LegacyCardUserFlags>(xCardholder.Element("userflags").Value, out userFlags))
                {
                    item.UserFlags = userFlags;
                }

                try
                {
                    item.StartDate = DateTime.Parse(xCardholder.Element("startdate").Value);
                }
                catch
                {
                    item.StartDate = new DateTime(2000, 1, 1);
                }
                try
                {
                    item.EndDate = DateTime.Parse(xCardholder.Element("enddate").Value);
                }
                catch
                {
                    item.EndDate = new DateTime(9999, 12, 31);
                }

                try
                {
                    long lastUserTicks = long.Parse(xCardholder.Element("lastused").Value);
                    item.LastUsed = new DateTime(lastUserTicks);                    
                }
                catch
                {
                    item.LastUsed = DateTime.Now.ToUniversalTime();
                }

                var xSchedules = xCardholder.Elements("schedules");
                if (xSchedules != null)
                {
                    var xScheduleList = xSchedules.Elements("schedule");
                    if (xScheduleList != null)
                    {
                        foreach (XElement xSchedule in xScheduleList)
                        {
                            int readerId = int.Parse(xSchedule.Attribute("readerid").Value);
                            int scheduleId = int.Parse(xSchedule.Value);
                            item.ReaderSchedules.Add(new ReaderScheduleIdPair(readerId, scheduleId));
                        }
                    }
                }

                this.Invoke(UpdateCardholderMethod, item);
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Error, "Editor: Error while parsing incoming cardholder data. {0}", ex.Message);
            }
        }

        private void cardholderConnection_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (e.NewConnectionState == Pacom.Peripheral.Protocol.ConnectionState.Disconnected)
            {
                disconnectConnection();
            }
            else if (e.NewConnectionState == Pacom.Peripheral.Protocol.ConnectionState.Connected)
            {
                cardholderProcessStatus.Text = string.Format("Connected to {0}:{1}", cardholderRemoteAddr.ToString(), cardholderPort.ToString());
            }
        }

        private void disconnectConnection()
        {
            if (cardholderConnection != null)
            {
                try
                {
                    cardholderConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(cardholderConnection_DataReceived);
                    cardholderConnection.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(cardholderConnection_ConnectionStateChanged);
                    cardholderConnection.Dispose();
                    cardholderConnection = null;
                }
                catch (Exception ex)
                {
                    Logger.LogMessage(LoggingLevel.Error, "Editor: Error while disconnecting. {0}", ex.Message);
                }
            }
            cardholderProcessStatus.Text = "Not Connected";
        }

        private void FormQueryCardholder_FormClosing(object sender, FormClosingEventArgs e)
        {
            disconnectConnection();
        }

        private void frmUpdateCardholderCountMethod(int count)
        {
            CardholderCount.Text = count.ToString();
        }

        private void frmUpdateCardholderMethod(CardholderItem item)
        {
            CardholderId.Text = item.CardholderId.ToString();
            UserPin.Text = item.UserPin.ToString();
            GroupId.Text = item.GroupId.ToString();
            Blocked.Text = item.Blocked.ToString();
            Expired.Text = item.Expired.ToString();

            if (item.UserFlags.HasFlag(LegacyCardUserFlags.DualUserControl))
                UserFlagsListBox.SetItemCheckState(0, CheckState.Checked);
            else
                UserFlagsListBox.SetItemCheckState(0, CheckState.Unchecked);

            if (item.UserFlags.HasFlag(LegacyCardUserFlags.ExtendedShuntStrikeTime))
                UserFlagsListBox.SetItemCheckState(1, CheckState.Checked);
            else
                UserFlagsListBox.SetItemCheckState(1, CheckState.Unchecked);

            if (item.UserFlags.HasFlag(LegacyCardUserFlags.AddLastCodeByteToPin))
                UserFlagsListBox.SetItemCheckState(2, CheckState.Checked);
            else
                UserFlagsListBox.SetItemCheckState(2, CheckState.Unchecked);

            if (item.UserFlags.HasFlag(LegacyCardUserFlags.StoreCodeForDegradedMode))
                UserFlagsListBox.SetItemCheckState(3, CheckState.Checked);
            else
                UserFlagsListBox.SetItemCheckState(3, CheckState.Unchecked);

            if (item.UserFlags.HasFlag(LegacyCardUserFlags.UsePinToAccess))
                UserFlagsListBox.SetItemCheckState(4, CheckState.Checked);
            else
                UserFlagsListBox.SetItemCheckState(4, CheckState.Unchecked);

            if (item.UserFlags.HasFlag(LegacyCardUserFlags.SupervisorOperation))
                UserFlagsListBox.SetItemCheckState(5, CheckState.Checked);
            else
                UserFlagsListBox.SetItemCheckState(5, CheckState.Unchecked);

            if (item.UserFlags.HasFlag(LegacyCardUserFlags.ExecutiveOperation))
                UserFlagsListBox.SetItemCheckState(6, CheckState.Checked);
            else
                UserFlagsListBox.SetItemCheckState(6, CheckState.Unchecked);

            if (item.UserFlags.HasFlag(LegacyCardUserFlags.EscortCapable))
                UserFlagsListBox.SetItemCheckState(7, CheckState.Checked);
            else
                UserFlagsListBox.SetItemCheckState(7, CheckState.Unchecked);

            if (item.UserFlags.HasFlag(LegacyCardUserFlags.EscortRequred))
                UserFlagsListBox.SetItemCheckState(8, CheckState.Checked);
            else
                UserFlagsListBox.SetItemCheckState(8, CheckState.Unchecked);

            if (item.UserFlags.HasFlag(LegacyCardUserFlags.PermanentUser))
                UserFlagsListBox.SetItemCheckState(9, CheckState.Checked);
            else
                UserFlagsListBox.SetItemCheckState(9, CheckState.Unchecked);

            LastUsed.Text = item.LastUsed.ToString();
            Version.Text = item.Version.ToString();
                        
            readerScheduleList.Clear();
            foreach (var readerScheduleIdPair in item.ReaderSchedules)
            {
                readerScheduleList.Add(readerScheduleIdPair);
            }
            readerScheduleList.Sort(sortReaderScheduleListMethod);
            ScheduleList.DataSource = null;
            ScheduleList.DataSource = readerScheduleList;
        }

        private void clearForm()
        {
            CardholderCount.Text = "N/A";
            CardholderId.Text = "";
            UserPin.Text = "";
            GroupId.Text = "";
            Blocked.Text = "";
            Expired.Text = "";
            LastUsed.Text = "";
            Version.Text = "";            
            ScheduleList.DataSource = null;
            readerScheduleList.Clear();
            ScheduleList.DataSource = readerScheduleList;
        }

        private void mnuScheduleAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (readerScheduleList.Count < 64)
                {
                    FormEditSchedule formAdd = new FormEditSchedule();
                    if (formAdd.ShowDialog() == DialogResult.OK)
                    {
                        if (formAdd.ReaderId < 1 || formAdd.ReaderId > 64)
                        {
                            MessageBox.Show("Reader Id value can be between 1 and 64.");
                        }
                        else
                        {
                            if (formAdd.ReaderId >= 0 && formAdd.ScheduleId >= 0)
                            {
                                // Only one readerId allowed
                                bool valid = true;
                                for (int i = 0; i < readerScheduleList.Count; i++)
                                {
                                    ReaderScheduleIdPair checkReaderItem = readerScheduleList[i];
                                    if (checkReaderItem.ReaderId == formAdd.ReaderId)
                                    {
                                        valid = false;
                                        break;
                                    }
                                }
                                if (valid == true)
                                {
                                    readerScheduleList.Add(new ReaderScheduleIdPair(formAdd.ReaderId, formAdd.ScheduleId));
                                }
                                else
                                {
                                    MessageBox.Show("Reader Id already exist.");
                                }
                            }
                            readerScheduleList.Sort(sortReaderScheduleListMethod);
                            ScheduleList.DataSource = null;
                            ScheduleList.DataSource = readerScheduleList;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Only 64 readers are allowed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("Error while adding reader schedule. {0}", ex.Message));
            }
        }

        private void mnuScheduleDelete_Click(object sender, EventArgs e)
        {
            if (ScheduleList.SelectedIndex >= 0)
            {
                readerScheduleList.RemoveAt(ScheduleList.SelectedIndex);                
                ScheduleList.DataSource = null;
                ScheduleList.DataSource = readerScheduleList;
            }
        }

        private void mnuScheduleEdit_Click(object sender, EventArgs e)
        {
            if (ScheduleList.SelectedIndex >= 0)
            {
                ReaderScheduleIdPair readerItem = readerScheduleList[ScheduleList.SelectedIndex];
                FormEditSchedule formEdit = new FormEditSchedule();
                formEdit.ReaderId = readerItem.ReaderId;
                formEdit.ScheduleId = readerItem.ScheduleId;
                formEdit.Owner = this;
                if (formEdit.ShowDialog() == DialogResult.OK)
                {
                    if (formEdit.ReaderId < 1 || formEdit.ReaderId > 64)
                    {
                        MessageBox.Show("Reader Id value can be between 1 and 64.");
                    }
                    else
                    {
                        if (formEdit.ReaderId == readerItem.ReaderId)
                        {
                            // readerId did not change
                            readerItem.ScheduleId = formEdit.ScheduleId;
                            ScheduleList.DataSource = null;
                            ScheduleList.DataSource = readerScheduleList;
                        }
                        else
                        {
                            // Only one raederId allowed
                            bool valid = true;
                            for (int i = 0; i < ScheduleList.Items.Count; i++)
                            {
                                ReaderScheduleIdPair checkReaderItem = readerScheduleList[i];
                                if (checkReaderItem.ReaderId == formEdit.ReaderId)
                                {
                                    valid = false;
                                    break;
                                }
                            }
                            if (valid == true)
                            {
                                readerItem.ReaderId = formEdit.ReaderId;
                                readerItem.ScheduleId = formEdit.ScheduleId;
                                readerScheduleList.Sort(sortReaderScheduleListMethod);
                                ScheduleList.DataSource = null;
                                ScheduleList.DataSource = readerScheduleList;
                            }
                            else
                            {
                                MessageBox.Show("Reader Id already exist.");
                            }
                        }
                    }
                }
            }
        }

        private void FormQueryCardholder_Load(object sender, EventArgs e)
        {           
        }

        private List<CardholderItem> csvItemList = new List<CardholderItem>();

        private void btnLoadFromCSV_Click(object sender, EventArgs e)
        {
            clearForm();
            OpenFileDialog openFile = new OpenFileDialog();
            if (openFile.ShowDialog() != DialogResult.OK)
                return;

            connectToController();
            TextFieldParser tfp;
            tfp = new TextFieldParser(openFile.FileName);
            TextFieldCollection fields = getFieldCollection();
            tfp.TextFields = fields;
            tfp.RecordFound += new RecordFoundHandler(tfp_RecordFound);
            tfp.RecordFailed += new RecordFailedHandler(tfp_RecordFailed);

            csvItemList.Clear();
            tfp.ParseFile();

            Logger.LogMessage(LoggingLevel.Error, "Editor: Loaded {0} cardholders from CSV file.", tfp.CurrentLineNumber);

            Thread workerCSVProcessorThread = new Thread(new ThreadStart(workerCSVProcessor));
            workerCSVProcessorThread.Start();
                           
        }

        private void workerCSVProcessor()
        {
            if (cardholderConnection == null)
            {
                Logger.LogMessage(LoggingLevel.Error, "Editor: Not connected. Upload is aborted.");
                return;
            }

            for (int i = 0; i < csvItemList.Count; i++)
            {
                dataReceivedResponseOk = false;
                dataReceivedEvent.Reset();
                dataReceived = new byte[0];

                cardholderConnection.Send(sendCardholderItem(csvItemList[i]), null);
                if (dataReceivedEvent.WaitOne(10000) == true && dataReceivedResponseOk == true)
                {
                    Logger.LogMessage(LoggingLevel.Error, "Editor: Cardholder {0} sent Ok. Record number {1}.", csvItemList[i].CardholderId, i + 1);
                }
                else
                {
                    Logger.LogMessage(LoggingLevel.Error, "Editor: Uploading cardholders has been interrupted by inproper response.");
                    break;
                }
            }
            Logger.LogMessage(LoggingLevel.Error, "Editor: Loading finished.");
        }

        private void tfp_RecordFailed(ref int CurrentLineNumber, string LineText, string ErrorMessage, ref bool Continue)
        {
            if (CurrentLineNumber == 1)
            {
                if (LineText.StartsWith("CardholderId") == true)
                {
                    Continue = true;
                }
                else
                {
                    Continue = false;
                }
            }
            else
            {
                Continue = true;
            }
        }

        private void tfp_RecordFound(ref int CurrentLineNumber, TextFieldCollection TextFields)
        {
            CardholderItem item = new CardholderItem();
            item.CardholderId = (Int64)TextFields[0].Value;
            item.UserPin = (Int32)TextFields[1].Value;
            item.GroupId = (Int32)TextFields[2].Value;
            item.Blocked = (Boolean)TextFields[3].Value;
            item.Expired = (Boolean)TextFields[4].Value;
            for (int i = 0; i < 64; i++)
            {
                int scheduleId = (Int32)TextFields[5 + i].Value;
                int readerId = i + 1;
                if (scheduleId > 0)
                    item.ReaderSchedules.Add(new ReaderScheduleIdPair(readerId, scheduleId));
            }
            csvItemList.Add(item);
        }

        private TextFieldCollection getFieldCollection()
        {
            TextFieldCollection fields = new TextFieldCollection();
            fields.Add(new TextField("CardholderId", TypeCode.Int64, true));
            fields.Add(new TextField("UserPin", TypeCode.Int32, true));
            fields.Add(new TextField("GroupId", TypeCode.Int32, true));
            fields.Add(new TextField("Blocked", TypeCode.Boolean, true));
            fields.Add(new TextField("Expired", TypeCode.Boolean, true));
            fields.Add(new TextField("Reader01Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader02Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader03Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader04Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader05Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader06Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader07Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader08Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader09Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader10Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader11Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader12Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader13Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader14Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader15Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader16Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader17Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader18Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader19Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader20Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader21Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader22Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader23Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader24Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader25Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader26Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader27Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader28Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader29Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader30Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader31Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader32Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader33Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader34Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader35Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader36Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader37Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader38Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader39Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader40Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader41Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader42Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader43Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader44Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader45Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader46Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader47Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader48Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader49Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader50Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader51Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader52Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader53Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader54Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader55Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader56Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader57Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader58Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader59Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader60Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader61Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader62Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader63Schedule", TypeCode.Int32, true));
            fields.Add(new TextField("Reader64Schedule", TypeCode.Int32, true));
            return fields;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            if (saveFile.ShowDialog() != DialogResult.OK)
                return;

            TextFieldCollection fields = getFieldCollection();
            string line1 = string.Empty;
            string line2 = string.Empty;
            for (int i=0; i< fields.Count; i++)
            {                
                line1 += fields[i].Name;
                if (fields[i].Name == "CardholderId")
                    line2 += "1";
                else if (fields[i].Name == "UserPin")
                    line2 += "1234";
                else if (fields[i].Name == "GroupId")
                    line2 += "5678";
                else if (fields[i].Name == "Blocked")
                    line2 += "False";
                else if (fields[i].Name == "Expired")
                    line2 += "False";
                else 
                    line2 += "-1";                

                if (i < fields.Count - 1)
                {
                    line1 += ",";
                    line2 += ",";
                }
            }
            using (FileStream stream = new FileStream(saveFile.FileName, FileMode.Create))
            {
                using (StreamWriter sw = new StreamWriter(stream))
                {
                    sw.WriteLine(line1);
                    sw.WriteLine(line2);
                }
            }
        }

        private void UpdateCardHolderId_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(FacilityEdit.Text) == false && string.IsNullOrEmpty(CodeEdit.Text) == false)
            {
                // Recalculate the Card holder id
                var facility = int.Parse(FacilityEdit.Text);
                var issue = int.Parse(IssueEdit.Text);
                var code = long.Parse(CodeEdit.Text);

                if (code > 0)
                {
                    long cardholderId = new LegacyCardNumberFormat(facility, issue, code).AsLong();
                    CardholderId.Text = cardholderId.ToString();
                    CardholderId.Refresh();
                }
                else
                {
                    long cardholderId = long.Parse(CardholderId.Text);
                    if (cardholderId > 0)
                    {
                        facility = (int)((cardholderId & 0x7FFF000000000000) >> 48);
                        issue = (int)((cardholderId & 0x0000FF0000000000) >> 40);
                        code = (long)(cardholderId & 0x000000FFFFFFFFFF);
                        FacilityEdit.Text = facility.ToString();
                        IssueEdit.Text = issue.ToString();
                        CodeEdit.Text = code.ToString();
                    }
                }
            }
            else if (string.IsNullOrEmpty(CardholderId.Text) == false)
            {
                // Update facility, issue and code edits
                ulong cardholderId = ulong.Parse(CardholderId.Text);
                if (cardholderId > 0)
                {
                    var facility = (int)((cardholderId & 0x7FFF000000000000) >> 48);
                    var issue = (int)((cardholderId & 0x0000FF0000000000) >> 40);
                    var code = (long)(cardholderId & 0x000000FFFFFFFFFF);
                    FacilityEdit.Text = facility.ToString();
                    IssueEdit.Text = issue.ToString();
                    CodeEdit.Text = code.ToString();
                }
            }
        }
    }
}
#endif