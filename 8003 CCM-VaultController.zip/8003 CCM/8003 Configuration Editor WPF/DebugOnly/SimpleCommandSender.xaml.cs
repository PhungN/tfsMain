﻿#if DEBUG
using System;
using System.Text;
using System.Threading;
using System.Windows.Controls;
using System.Net;
using Pacom.Peripheral.Protocol;
using System.Xml.Linq;

namespace Pacom.ConfigurationEditor.WPF.DebugOnly
{
    /// <summary>
    /// Interaction logic for SimpleCommandSender.xaml
    /// </summary>
    public partial class SimpleCommandSender : UserControl
    {
        public SimpleCommandSender()
        {
            InitializeComponent();

            replyTimer = new System.Threading.Timer(replyTimerProc, null, Timeout.Infinite, Timeout.Infinite);
        }

        private void setConnectionStatus(string text)
        {
            if (CheckAccess() == false) // CheckAccess returns true if you're on the dispatcher thread
            {
                Dispatcher.Invoke(() => { tbConnectionStatus.Text = text; });
                return;
            }
            tbConnectionStatus.Text = text;
        }

        private void setCommandResult(string text)
        {
            if (CheckAccess() == false) // CheckAccess returns true if you're on the dispatcher thread
            {
                Dispatcher.Invoke(() => { tbCommandResult.Text = text; });
                return;
            }
            tbCommandResult.Text = text;
        }

        public delegate void DisplayCommandStatusDelegate(string text);
        public delegate void DisplayConnectionStatusDelegate(string text);

        private TcpIPConnection commandConnection = null;
        private byte[] dataReceived = new byte[0];
        private ManualResetEvent dataReceivedEvent = new ManualResetEvent(false);

        private Int32 commandConnectionPort;
        private IPAddress commandConnectionRemoteAddr;

        private Timer replyTimer = null;

        private void connectToController()
        {
            setCommandResult("");
            dataReceivedEvent.Reset();
            dataReceived = new byte[0];
            if (commandConnection == null)
            {
                commandConnectionPort = 8284;
                commandConnectionRemoteAddr = Settings.ControllerIPAddress;

                commandConnection = new TcpIPConnection(new IPEndPoint(commandConnectionRemoteAddr, commandConnectionPort));
                commandConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(commandConnection_DataReceived);
                commandConnection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(commandConnection_ConnectionStateChanged);
                commandConnection.Connect();
            }
        }

        private void disconnectConnection()
        {
            if (commandConnection != null)
            {
                try
                {
                    commandConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(commandConnection_DataReceived);
                    commandConnection.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(commandConnection_ConnectionStateChanged);
                    commandConnection.Dispose();
                    commandConnection = null;
                }
                catch (Exception ex)
                {
                    setConnectionStatus(string.Format("Editor: Error while disconnecting. {0}", ex.Message));
                    return;
                }
            }
            setConnectionStatus("Not Connected");
        }

        private void commandConnection_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (e.NewConnectionState == Pacom.Peripheral.Protocol.ConnectionState.Disconnected)
            {
                disconnectConnection();
                setCommandResult("Unable to connect.");
            }
            else if (e.NewConnectionState == Pacom.Peripheral.Protocol.ConnectionState.Connected)
            {
                setConnectionStatus(string.Format("Connected to {0}:{1}", commandConnectionRemoteAddr.ToString(), commandConnectionPort.ToString()));
            }
        }

        private bool closingResponseFound(byte[] data)
        {
            byte[] responseEnd = Encoding.ASCII.GetBytes(@"</response>");
            if (data.Length < responseEnd.Length)
                return false;

            for (int i = 1; i <= responseEnd.Length; i++)
            {
                if (data[data.Length - i] != responseEnd[responseEnd.Length - i])
                {
                    return false;
                }
            }
            return true;
        }

        private enum ResponseType
        {
            Unknown,
            NoData,
            Ok,
            Error,
            Data,
        }

        private XDocument processRawCommand(byte[] rawCommand)
        {
            try
            {
                string commandAsString = Encoding.ASCII.GetString(rawCommand, 0, rawCommand.Length);
                return XDocument.Parse(commandAsString);
            }
            catch (Exception ex)
            {
                setCommandResult(string.Format("Editor: Error while processing incoming message. {0}", ex.Message));
                return null;
            }
        }

        private ResponseType getResponseType(XDocument xdoc)
        {

            /*
            * <response type='?????'>
            *    ....
            * </response>
            */

            if (xdoc == null)
                return ResponseType.Unknown;

            ResponseType result = ResponseType.Unknown;
            try
            {
                var request = xdoc.Element("response");
                XAttribute xRequestType = request.Attribute("type");

                if (xRequestType != null && xRequestType.Value != null)
                {
                    if (string.Compare(xRequestType.Value, "nodata", true) == 0)
                        result = ResponseType.NoData;
                    else if (string.Compare(xRequestType.Value, "error", true) == 0)
                        result = ResponseType.Error;
                    else if (string.Compare(xRequestType.Value, "Ok", true) == 0)
                        result = ResponseType.Ok;
                    else if (string.Compare(xRequestType.Value, "data", true) == 0)
                        result = ResponseType.Data;
                    else
                        result = ResponseType.Unknown;
                }
            }
            catch (Exception ex)
            {

                setCommandResult(string.Format("Editor: Error while parsing response type. {0}", ex.Message));
                result = ResponseType.Unknown;
            }
            return result;
        }

        private void commandConnection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            byte[] dataReceivedNew = new byte[dataReceived.Length + e.Data.Length];
            Array.Copy(dataReceived, 0, dataReceivedNew, 0, dataReceived.Length);
            Array.Copy(e.Data, 0, dataReceivedNew, dataReceived.Length, e.Data.Length);
            dataReceived = dataReceivedNew;
            // Discard data if too much
            if (dataReceived.Length > 500000)
                dataReceived = new byte[0];
            // Check if closing tag has been found
            if (closingResponseFound(dataReceived) == true)
            {
                // Parse response
                XDocument xdoc = processRawCommand(dataReceived);
                switch (getResponseType(xdoc))
                {
                    case ResponseType.Data:
                        ParseResponseData(xdoc.Element("response"));
                        break;
                    case ResponseType.Ok:
                        setCommandResult("OK");
                        break;
                    case ResponseType.Error:
                        {
                            string message = xdoc.Element("response").Value;
                            if (string.IsNullOrEmpty(message))
                            {
                                message = "Error";
                            }
                            setCommandResult(message);
                            break;
                        }
                    case ResponseType.NoData:
                        setCommandResult("No data");
                        break;
                    default:
                        setCommandResult("Unknown");
                        break;
                }
                dataReceivedEvent.Set();
                replyTimer.Change(Timeout.Infinite, Timeout.Infinite);
                dataReceived = new byte[0];
            }
        }
        /// <summary>
        /// Send XML data to the controller.
        /// </summary>
        /// <param name="command">String representing command name.</param>
        /// <param name="commandAndXmlPart">Extracted XML string.</param>
        /// <returns></returns>
        public bool SendCommand(string command, string commandAndXmlPart)
        {
            connectToController();

            string query = string.Format("<request type='{0}'>{1}</request>", command, commandAndXmlPart);

            bool result = false;
            if (commandConnection != null)
            {
                result = commandConnection.Send(Encoding.ASCII.GetBytes(query), null);
                replyTimer.Change(WaitForResponseTimeout, Timeout.Infinite);
            }
            else
            {
                result = false;
                setCommandResult("Unable to send command.");
            }
            return result;
        }

        private void replyTimerProc(object state)
        {
            if (dataReceivedEvent.WaitOne(1) == true)
                return;
            try
            {
                setCommandResult("Controller did not respond.");
            }
            catch
            {
            }
        }

        public int WaitForResponseTimeout = 1500;

        /// <summary>
        /// Returns data returned by the controller.
        /// </summary>
        /// <param name="data"></param>
        public virtual void ParseResponseData(XElement data)
        {
        }
    }
}
#endif
