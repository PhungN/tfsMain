﻿#if DEBUG
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using System.Threading;
using Pacom.ConfigurationEditor.WPF;
//using Pacom.Peripheral.Hal;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// A factory that produces TcpIPConnection instances.
    /// This class also takes care of producing TcpIPConnection instances for incoming connections.
    /// </summary>
    public class TcpIPManager : IDisposable
    {
        /// <summary>
        /// Triggered on a new incoming connection.
        /// </summary>
        public event EventHandler<IncomingConnectionEventArgs> OnIncomingConnection;

        private TcpListener portListener;
        private readonly object listenerLock = new object();
        private bool disposed;
        private bool listening;
        private bool continueListeningAfterConnection;
        private Thread portListenerThread;

        /// <summary>
        /// Produces a new TcpIPConnection instance.
        /// </summary>
        /// <param name="remoteEndPoint">The IP address of the remote party.</param>
        /// <returns>A new TcpIPConnection instance.</returns>
        public TcpIPConnection CreateConnection(IPEndPoint remoteEndPoint)
        {
            return new TcpIPConnection(remoteEndPoint);
        }

        /// <summary>
        /// Produces a new TcpIPConnection instance.
        /// </summary>
        /// <param name="remoteAddress">The IP address of the remote party.</param>
        /// <param name="localAddress">The local address to bind the port to.</param>
        /// <returns>A new TcpIPConnection instance.</returns>
        public TcpIPConnection CreateConnection(IPEndPoint remoteEndPoint, IPEndPoint localEndPoint)
        {
            return new TcpIPConnection(remoteEndPoint, localEndPoint);
        }

        /// <summary>
        /// Starts listening for incoming TCP/IP connections.
        /// </summary>
        /// <param name="listenPortNumber">The port number to listen on.</param>
        /// <param name="continueListeningAfterConnection">Set to true to allow multiple connections or to false to only accept one connection.</param>
        public void StartListening(int listenPortNumber, bool continueListeningAfterConnection)
        {
            StartListening(listenPortNumber, IPAddress.Any, continueListeningAfterConnection);
        }

        /// <summary>
        /// Starts listening for incoming TCP/IP connections.
        /// </summary>
        /// <param name="listenPortNumber">The port number to listen on.</param>
        /// <param name="listenAddress">The IP address to listen on.</param>
        /// <param name="continueListeningAfterConnection">Set to true to allow multiple connections or to false to only accept one connection.</param>
        public void StartListening(int listenPortNumber, string listenAddress, bool continueListeningAfterConnection)
        {
            try
            {
                StartListening(listenPortNumber, IPAddress.Parse(listenAddress), continueListeningAfterConnection);
            }
            catch (FormatException ex)
            {
                Logger.LogMessage(LoggingLevel.Error, ex.ToString());
            }
        }

        /// <summary>
        /// Starts listening for incoming TCP/IP connections.
        /// </summary>
        /// <param name="listenPortNumber">The port number to listen on.</param>
        /// <param name="listenAddress">The IP address to listen on.</param>
        /// <param name="continueListeningAfterConnection">Set to true to allow multiple connections or to false to only accept one connection.</param>
        public void StartListening(int listenPortNumber, IPAddress listenAddress, bool continueListeningAfterConnection)
        {
            if (disposed)
                return;

            IPEndPoint localEndPoint = new IPEndPoint(listenAddress, listenPortNumber);
            bool portStarted = false;

            try
            {
                StartListening(localEndPoint, continueListeningAfterConnection);
                portStarted = true;
            }
            catch (SocketException ex)
            {
                Logger.LogMessage(LoggingLevel.Error, ex.ToString());
            }
            catch (InvalidOperationException ex)
            {
                StopListening();
                Logger.LogMessage(LoggingLevel.Error, ex.ToString());
            }

            if (!portStarted)
            {
                Logger.LogMessage(LoggingLevel.Debug, "Restarting TCP port on ANY interface.");

                localEndPoint = new IPEndPoint(IPAddress.Any, listenPortNumber);

                try
                {
                    StartListening(localEndPoint, continueListeningAfterConnection);
                }
                catch (SocketException ex)
                {
                    StopListening();
                    Logger.LogMessage(LoggingLevel.Error, ex.ToString());
                }
                catch (InvalidOperationException ex)
                {
                    StopListening();
                    Logger.LogMessage(LoggingLevel.Error, ex.ToString());
                }
            }
        }

        /// <summary>
        /// Starts listening for incoming TCP/IP connections.
        /// </summary>
        /// <param name="localEndPoint">The IP address and port number to listen on.</param>
        /// <param name="continueListeningAfterConnection">Set to true to allow multiple connections or to false to only accept one connection.</param>
        public void StartListening(IPEndPoint localEndPoint, bool continueListeningAfterConnection)
        {
            if (disposed)
                return;

            lock (listenerLock)
            {
                if (listening)
                    return;
                this.continueListeningAfterConnection = continueListeningAfterConnection;
                listening = true;
                if (this.portListener != null)
                    StopListening();
                this.portListener = new TcpListener(localEndPoint);
                this.portListener.Start();

                portListenerThread = new Thread(new ThreadStart(portListenerThreadMethod));
                portListenerThread.Name = "TCP Port Listener Thread";
                portListenerThread.IsBackground = true;
                portListenerThread.Priority = ThreadPriority.BelowNormal;
                portListenerThread.Start();
            }
        }

        /// <summary>
        /// Stops listening for new incoming TCP/IP connections.
        /// </summary>
        public void StopListening()
        {
            lock (listenerLock)
            {
                listening = false;
                if (this.portListener != null)
                {
                    Logger.LogMessage(LoggingLevel.Debug, "TcpIPManager.StopListening was called.");
                    this.portListener.Server.Close();
                    this.portListener = null;
                }
            }
        }

        /// <summary>
        /// Returns true if the instance is listening for incoming TCP/IP connections.
        /// </summary>
        public bool Listening
        {
            get { return listening; }
        }

        private void portListenerThreadMethod()
        {
            TcpListener listener;
            TcpClient client = null;
            while (App.Closing == false && disposed == false && listening == true)
            {
                lock (listenerLock)
                {
                    listener = this.portListener;
                }

                try
                {
                    if (listener != null)
                        client = listener.AcceptTcpClient();
                    else
                        client = null;
                }
                catch (SocketException ex)
                {
                    // This is likely because we have been instructed to stop listening.

                    Logger.LogMessage(LoggingLevel.Debug, "SocketException occurred while listening : " + ex.ToString());
                    break;
                }
                catch (ObjectDisposedException ex)
                {
                    Logger.LogMessage(LoggingLevel.Debug, "ObjectDisposedException occurred while listening : " + ex.ToString());
                    break;
                }
                catch (ThreadAbortException)
                {
                    Logger.LogMessage(LoggingLevel.Debug, "TCP/IP Listener Thread Aborted.");
                    break;
                }
                catch (Exception ex)
                {
                    Logger.LogMessage(LoggingLevel.Debug, "Exception occurred while listening : " + ex.ToString());
                    break;
                }

                try
                {
                    if (client != null)
                    {
                        IPEndPoint remoteEndPoint = client.Client.RemoteEndPoint as IPEndPoint;

                        if (remoteEndPoint != null)
                        {
                            TcpIPConnection connection = new TcpIPConnection(remoteEndPoint, client);

                            if (this.OnIncomingConnection != null)
                                this.OnIncomingConnection(this, new IncomingConnectionEventArgs(connection));
                        }
                    }

                    if (continueListeningAfterConnection == false || listening == false)
                        break;
                }
                catch (Exception ex)
                {
                    Logger.LogMessage(LoggingLevel.Error, ex.ToString());
                }
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            disposed = true;
            StopListening();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
#endif
