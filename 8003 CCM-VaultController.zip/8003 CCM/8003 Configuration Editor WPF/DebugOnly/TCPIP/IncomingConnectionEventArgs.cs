﻿#if DEBUG
using System;

namespace Pacom.Peripheral.Protocol
{
    public class IncomingConnectionEventArgs : EventArgs
    {
        private readonly ProtocolConnectionBase connection;

        public IncomingConnectionEventArgs(ProtocolConnectionBase connection)
        {
            this.connection = connection;
        }

        public ProtocolConnectionBase Connection
        {
            get { return connection; }
        }
    }
}
#endif
