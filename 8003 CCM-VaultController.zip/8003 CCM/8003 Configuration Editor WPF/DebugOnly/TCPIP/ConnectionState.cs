﻿#if DEBUG
using System;

namespace Pacom.Peripheral.Protocol
{
    public enum ConnectionState
    {
        Disconnected,
        Connecting,
        Connected,
    };
}
#endif
