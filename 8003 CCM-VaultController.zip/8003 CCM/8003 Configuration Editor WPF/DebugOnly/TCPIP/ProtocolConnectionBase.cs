﻿#if DEBUG
using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// The abstract class that all session / link / physical layer protocol classes are derived from.
    /// </summary>
    public abstract class ProtocolConnectionBase : IDisposable
    {
        protected ProtocolConnectionBase lowerLayerConnection;
        protected Dictionary<string, object> blankDictionary = new Dictionary<string, object>();

        /// <summary>
        /// Triggered when a complete message has been received and successfully parsed. The original message
        /// can be found as a byte array, while the parsed message is available in the 'DeviceLoopMessage'
        /// element in the dictionary.
        /// </summary>
        public abstract event EventHandler<ReceivedDataEventArgs> DataReceived;

        /// <summary>
        /// Triggered when the connection changes state (Disconnected, Connecting, Connected)
        /// </summary>
        public abstract event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;

        /// <summary>
        /// Send a message on the connection.
        /// </summary>
        /// <param name="data">The data to send.</param>
        /// <param name="metadata">The data to send.</param>
        /// <returns>True if successfully sent out on the physical connection.</returns>
        public abstract bool Send(byte[] data, Dictionary<string, object> metadata);

        /// <summary>
        /// Initiates the connection.
        /// A ConnectionStateChanged event will be fired to indicate the final result of the call.
        /// </summary>
        /// <returns>True on success.</returns>
        public abstract bool Connect();

        /// <summary>
        /// The current state (Disconnected, Connecting, Connected) of the connection.
        /// </summary>
        public ConnectionState ConnectionState
        {
            get;
            protected set;
        }

        /// <summary>
        /// Used to implement a protocol stack pattern.
        /// </summary>
        /// <param name="lowerLayerConnection">The protocol layer one layer down.</param>
        public virtual void SetLowerLayerConnection(ProtocolConnectionBase lowerLayerConnection)
        {
            this.lowerLayerConnection = lowerLayerConnection;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (lowerLayerConnection != null)
                lowerLayerConnection.Dispose();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
#endif
