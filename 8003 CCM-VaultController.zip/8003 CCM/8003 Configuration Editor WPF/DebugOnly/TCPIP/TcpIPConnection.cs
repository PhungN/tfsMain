#if DEBUG
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;
using System.Collections.Generic;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// The physcial level connection to implement a TCP/IP connection.
    /// </summary>
    public class TcpIPConnection : ProtocolConnectionBase, IDisposable
    {
        /// <summary>
        /// Triggered when bytes are received on the port, returned in the byte array.
        /// </summary>
        public override event EventHandler<ReceivedDataEventArgs> DataReceived;

        /// <summary>
        /// Triggered when the connection changes state (Disconnected, Connecting, Connected)
        /// </summary>
        public override event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;

        private readonly TcpClient client;
        protected IPEndPoint remoteAddress;
        private readonly object tcpClientLock = new object();
        private readonly AutoResetEvent tcpWriteLock = new AutoResetEvent(true);
        private readonly byte[] receiveBuffer = new byte[1500];
        private bool disposed;
        private const int writeLockTimeOut = 20000;
        private bool callOnDisconnected = true;

        /// <summary>
        /// Store disconnection status for Disconnect() function.
        /// </summary>
        private DisconnectionReason connectionFailureReason = DisconnectionReason.Other;

        /// <summary>
        /// Constructor. Used to create an outgoing connection to a remote party.
        /// </summary>
        /// <param name="remoteAddress">The IP address of the remote party.</param>
        public TcpIPConnection(IPEndPoint remoteAddress)
            : this(remoteAddress, new TcpClient(AddressFamily.InterNetwork))
        {
            ConnectionState = ConnectionState.Disconnected;
        }

        /// <summary>
        /// Constructor. Used to create an outgoing connection to a remote party from a specific port number.
        /// </summary>
        /// <param name="remoteAddress">The IP address of the remote party.</param>
        /// <param name="localAddress">The local address to bind the port to.</param>
        public TcpIPConnection(IPEndPoint remoteAddress, IPEndPoint localAddress)
            : this(remoteAddress, new TcpClient(localAddress))
        {
            ConnectionState = ConnectionState.Disconnected;
        }

        /// <summary>
        /// Constructor. Used to accept an incomming connection from a remote party.
        /// </summary>
        /// <param name="remoteAddress">The IP address of the remote party.</param>
        /// <param name="client">The incoming connection.</param>
        public TcpIPConnection(IPEndPoint remoteAddress, TcpClient client)
        {
            this.client = client;
            this.remoteAddress = remoteAddress;

            if (this.client.Client.Connected)
                ConnectionState = ConnectionState.Connecting;

            connectionFailureReason = DisconnectionReason.Other;
        }

        private void writeCompleteCallback(IAsyncResult ar)
        {
            if (ConnectionState != ConnectionState.Connected)
                return;

            try
            {
                bool forceDisconnect = false;

                lock (tcpClientLock)
                {
                    if (disposed)
                        return;

                    try
                    {
                        if ((this.clientExists) && (this.client.Client.Connected))
                        {
                            client.GetStream().EndWrite(ar);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: Error while finishing writing to TCP/IP socket. " + ex.Message);
                        forceDisconnect = true;
                    }
                    finally
                    {
                        tcpWriteLock.Set();
                    }
                }

                if (forceDisconnect)
                {
                    Dispose();
                }
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: Error while handling writing to TCP/IP socket. " + ex.Message);
            }
        }

        private void completeRead(IAsyncResult ar)
        {
            bool forceDisconnect = false;

            try
            {
                byte[] receivedData = null;

                lock (tcpClientLock)
                {
                    if (disposed)
                        return;

                    if ((this.clientExists) && (this.client.Client.Connected))
                    {
                        int bytesRead = 0;
                        try
                        {
                            NetworkStream dataStream = this.client.GetStream();
                            bytesRead = dataStream.EndRead(ar);
                        }
                        catch (InvalidCastException ex)
                        {
                            Logger.LogMessage(LoggingLevel.Debug, "Invalid Socket Cast Exception: " + ex.ToString());
                        }
                        catch (Exception ex)
                        {
                            Logger.LogMessage(LoggingLevel.Debug, "Unknown Socket Exception: " + ex.ToString());
                        }
                        if (bytesRead > 0)
                        {
                            receivedData = new byte[bytesRead];
                            Buffer.BlockCopy(this.receiveBuffer, 0, receivedData, 0, bytesRead);
                        }
                        else
                        {
                            Logger.LogMessage(LoggingLevel.Debug, "TcpConnection: Remote end closed connection.");
                            ConnectionState = ConnectionState.Disconnected;
                            if (ConnectionStateChanged != null)
                            {
                                ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState, DisconnectionReason.TcpIPRemoteEndClosed));
                                callOnDisconnected = false;
                            }
                            forceDisconnect = true;
                        }
                    }
                }

                if (!forceDisconnect)
                {
                    if (receivedData != null)
                    {
                        if (DataReceived != null)
                        {
                            Logger.LogMessage(LoggingLevel.TracedComms, "Received on TCP", receivedData);
                            DataReceived(this, new ReceivedDataEventArgs(receivedData, new Dictionary<string, object>()));
                        }
                    }

                    lock (tcpClientLock)
                    {
                        if (disposed)
                            return;

                        if ((this.clientExists) && (this.client.Client.Connected))
                        {
                            NetworkStream dataStream = this.client.GetStream();
                            dataStream.BeginRead(receiveBuffer, 0, receiveBuffer.Length, new AsyncCallback(readCompleteCallback), dataStream);
                        }
                    }
                }
            }
            catch (SocketException ex)
            {
                Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: Error while reading from TCP/IP port. " + ex.Message);
                forceDisconnect = true;
            }
            catch (IOException ex)
            {
                if (ex.InnerException is SocketException && ((SocketException)ex.InnerException).ErrorCode == 10054)
                {
                    ConnectionState = ConnectionState.Disconnected;
                    if (ConnectionStateChanged != null)
                    {
                        ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState, DisconnectionReason.Other));
                        callOnDisconnected = false;
                    }
                }
                else
                {
                    Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: Error while finishing reading from TCP/IP socket. " + ex.Message);
                }
                forceDisconnect = true;
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: Error while reading from TCP/IP socket. " + ex.Message);
                forceDisconnect = true;
            }

            try
            {
                if (forceDisconnect)
                    Dispose();
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: " + ex.ToString());
            }
        }

        private void readCompleteCallback(IAsyncResult ar)
        {
            if (ConnectionState != ConnectionState.Connected)
                return;

            try
            {
                if (ar.CompletedSynchronously)
                {
                    ThreadPool.QueueUserWorkItem(new WaitCallback(delegate(object context)
                    {
                        try
                        {
                            completeRead(ar);
                        }
                        catch (Exception ex)
                        {
                            Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: " + ex.ToString());
                        }
                    }
                    ));
                }
                else
                    completeRead(ar);
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: " + ex.ToString());
            }
        }

        private bool clientExists
        {
            get { return (this.client != null && this.client.Client != null); }
        }

        private void completeConnection()
        {
            bool forceDisconnect = false;

            lock (tcpClientLock)
            {
                if (disposed)
                    return;

                try
                {
                    if ((this.clientExists) && (this.client.Client.Connected))
                    {
                        ConnectionState = ConnectionState.Connected;

                        NetworkStream dataStream = this.client.GetStream();
                        dataStream.BeginRead(receiveBuffer, 0, receiveBuffer.Length, new AsyncCallback(readCompleteCallback), dataStream);
                    }
                    else
                    {
                        ConnectionState = ConnectionState.Disconnected;
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: " + ex.ToString());
                    forceDisconnect = true;
                }
            }

            if (forceDisconnect)
            {
                Dispose();
                return;
            }

            if (ConnectionStateChanged != null)
                ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState, DisconnectionReason.Other));

        }

        /// <summary>
        /// A non-blocking call to send a byte array on the connection.
        /// </summary>
        /// <param name="data">The data to send on the port.</param>
        /// <param name="metadata">unused</param>
        /// <returns>True if successfully sent out on the physical connection.</returns>
        public override bool Send(byte[] data, Dictionary<string, object> metadata)
        {
            if (ConnectionState != ConnectionState.Connected)
                return false;

            bool forceDisconnect = false;
            Logger.LogMessage(LoggingLevel.TracedComms, "Sending on TCP", data);

            try
            {
                if (disposed)
                    return false;

                if (tcpWriteLock.WaitOne(writeLockTimeOut, false))
                {
                    if (disposed)
                        return false;

                    lock (tcpClientLock)
                    {
                        if ((this.clientExists) && (this.client.Client.Connected))
                        {
                            client.GetStream().BeginWrite(data, 0, data.Length, new AsyncCallback(writeCompleteCallback), this);
                        }
                        else
                        {
                            tcpWriteLock.Set();
                        }
                    }
                }
                else
                {
                    forceDisconnect = true;
                }
            }
            catch (SocketException ex)
            {
                Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: " + ex.ToString());
                forceDisconnect = true;
            }
            catch (InvalidOperationException ex)
            {
                Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: " + ex.ToString());
                forceDisconnect = true;
            }
            catch (IOException ex)
            {
                Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: " + ex.ToString());
                forceDisconnect = true;
            }

            if (forceDisconnect)
            {
                Dispose();
                return false;
            }
            return true;
        }

        /// <summary>
        /// A blocking call to initiate the connection.
        /// </summary>
        /// <returns>True on success.</returns>
        public override bool Connect()
        {
            connectionFailureReason = DisconnectionReason.Other;

            if (ConnectionState == ConnectionState.Connecting)
                completeConnection();

            if (ConnectionState == ConnectionState.Connected)
                return true;

            bool forceDisconnect = false;

            try
            {
                lock (tcpClientLock)
                {
                    if (disposed)
                        return false;

                    if (clientExists == false)
                    {
                        Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: Client is null.");
                        return false;
                    }

                    callOnDisconnected = true;

                    if (!this.client.Client.Connected)
                    {
                        ConnectionState = ConnectionState.Connecting;
                        Logger.LogMessage(LoggingLevel.Debug, "TcpConnection.Connect");
                        this.client.Connect(remoteAddress);
                        completeConnection();
                    }
                }
            }
            catch (SocketException ex)
            {
                Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: " + ex.Message);
                forceDisconnect = true;
                // Address already in use.
                // Typically, only one usage of each socket address (protocol/IP address/port) is permitted.
                // 8001 firmware up to 4.09D had check forcing source port to 3435. It has been relaxed after this version.
                // The port requirement is still honored in this code for legacy (<= 4.09D) versions.
                if (ex.ErrorCode == 10048)
                {
                    connectionFailureReason = DisconnectionReason.TcpIPAddressAlreadyInUse;
                }
            }
            catch (InvalidOperationException ex)
            {
                Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: " + ex.ToString());
                forceDisconnect = true;
            }
            catch (IOException ex)
            {
                Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: " + ex.ToString());
                forceDisconnect = true;
            }

            if (forceDisconnect)
            {
                Dispose();
                return false;
            }

            return true;
        }

        private bool disconnect()
        {
            lock (tcpClientLock)
            {
                try
                {
                    if ((this.clientExists) && (this.client.Client.Connected))
                    {
                        this.client.Client.Shutdown(SocketShutdown.Both);
                        this.client.Client.Close();
                        Logger.LogMessage(LoggingLevel.Debug, "TcpConnection.Disconnect");
                    }
                }
                catch (SocketException ex)
                {
                    Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: Error while disconnecting TCP/IP socket. " + ex.Message);
                }
                // Send state change to allow start of a new connection.
                try
                {
                    ConnectionState = ConnectionState.Disconnected;
                    if (callOnDisconnected == true)
                    {
                        callOnDisconnected = false;
                        if (ConnectionStateChanged != null)
                            ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState, connectionFailureReason));
                    }
                }
                catch (SocketException ex)
                {
                    Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: Unable to send notification on connection state change. " + ex.Message);
                }
                return true;
            }
        }

        protected override void Dispose(bool disposing)
        {
            lock (tcpClientLock)
            {
                if (disposed)
                    return;
                disposed = true;

                try
                {
                    disconnect();
                    client.Close();
                    tcpWriteLock.Set();
                    tcpWriteLock.Close();
                    Logger.LogMessage(LoggingLevel.Debug, "TcpConnection.Disposed");
                }
                catch (Exception ex)
                {
                    Logger.LogMessage(LoggingLevel.Warn, "TcpConnection: Error while disposing TCP/IP connection object. " + ex.Message);
                }
            }
            base.Dispose(true);
        }
    }
}
#endif
