#if DEBUG
using System;

namespace Pacom.Peripheral.Protocol
{
    public enum DisconnectionReason
    {
        Other,
        TcpIPAddressAlreadyInUse,
        TcpIPRemoteEndClosed
    };
}
#endif