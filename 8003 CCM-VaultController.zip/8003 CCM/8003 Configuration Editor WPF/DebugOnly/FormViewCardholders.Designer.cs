﻿#if DEBUG
namespace Pacom.Peripheral.ConfigurationEditorFor8003
{
    partial class FormViewCardholders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

#region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDownload = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.txtLastResponse = new System.Windows.Forms.ToolStripStatusLabel();
            this.listCardholders = new System.Windows.Forms.ListView();
            this.colCardholderId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colFacility = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colIssue = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colUserPin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colGroupId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colBlocked = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colExpired = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSchedules = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colUserFlags = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDownload
            // 
            this.btnDownload.Location = new System.Drawing.Point(12, 12);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(75, 23);
            this.btnDownload.TabIndex = 0;
            this.btnDownload.Text = "Download";
            this.btnDownload.UseVisualStyleBackColor = true;
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.txtLastResponse});
            this.statusStrip1.Location = new System.Drawing.Point(0, 617);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(984, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(81, 17);
            this.toolStripStatusLabel1.Text = "Last response:";
            // 
            // txtLastResponse
            // 
            this.txtLastResponse.Name = "txtLastResponse";
            this.txtLastResponse.Size = new System.Drawing.Size(36, 17);
            this.txtLastResponse.Text = "None";
            // 
            // listCardholders
            // 
            this.listCardholders.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listCardholders.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colCardholderId,
            this.colFacility,
            this.colIssue,
            this.colCode,
            this.colUserPin,
            this.colGroupId,
            this.colBlocked,
            this.colExpired,
            this.colSchedules,
            this.colUserFlags});
            this.listCardholders.Location = new System.Drawing.Point(12, 41);
            this.listCardholders.Name = "listCardholders";
            this.listCardholders.Size = new System.Drawing.Size(963, 567);
            this.listCardholders.TabIndex = 3;
            this.listCardholders.UseCompatibleStateImageBehavior = false;
            this.listCardholders.View = System.Windows.Forms.View.Details;
            this.listCardholders.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listCardholders_KeyDown);
            // 
            // colCardholderId
            // 
            this.colCardholderId.Text = "CardholderId";
            this.colCardholderId.Width = 116;
            // 
            // colFacility
            // 
            this.colFacility.Text = "Facility";
            this.colFacility.Width = 66;
            // 
            // colIssue
            // 
            this.colIssue.Text = "Issue";
            // 
            // colCode
            // 
            this.colCode.Text = "Code";
            this.colCode.Width = 67;
            // 
            // colUserPin
            // 
            this.colUserPin.Text = "User Pin";
            this.colUserPin.Width = 95;
            // 
            // colGroupId
            // 
            this.colGroupId.Text = "GroupId";
            // 
            // colBlocked
            // 
            this.colBlocked.Text = "Blocked";
            this.colBlocked.Width = 73;
            // 
            // colExpired
            // 
            this.colExpired.Text = "Expired";
            // 
            // colSchedules
            // 
            this.colSchedules.Text = "Schedules";
            this.colSchedules.Width = 151;
            // 
            // colUserFlags
            // 
            this.colUserFlags.Text = "User Flags";
            this.colUserFlags.Width = 200;
            // 
            // FormViewCardholders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 639);
            this.Controls.Add(this.listCardholders);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.btnDownload);
            this.Name = "FormViewCardholders";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "View cardholders";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

#endregion

        private System.Windows.Forms.Button btnDownload;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel txtLastResponse;
        private System.Windows.Forms.ListView listCardholders;
        private System.Windows.Forms.ColumnHeader colCardholderId;
        private System.Windows.Forms.ColumnHeader colUserPin;
        private System.Windows.Forms.ColumnHeader colBlocked;
        private System.Windows.Forms.ColumnHeader colFacility;
        private System.Windows.Forms.ColumnHeader colIssue;
        private System.Windows.Forms.ColumnHeader colCode;
        private System.Windows.Forms.ColumnHeader colExpired;
        private System.Windows.Forms.ColumnHeader colSchedules;
        private System.Windows.Forms.ColumnHeader colGroupId;
        private System.Windows.Forms.ColumnHeader colUserFlags;
    }
}
#endif