﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.Commands;
using Pacom.Peripheral.Common.Configuration;
using System.Windows.Markup;
using System.Linq;
using System.Collections.Generic;

namespace Pacom.ConfigurationEditor.WPF.View
{
    /// <summary>
    /// Interaction logic for ElevatorConfigurationView.xaml
    /// </summary>
    public partial class UnisonElevatorConfigurationView : ElevatorConfigurationViewBase
    {
        public ObservableCollection<ElevatorFloor8003Configuration> AvailableFloors { get; private set; }
        public RelayCommand AddFloorsCommand { get; set; }
        public RelayCommand RemoveFloorsCommand { get; set; }
        public RelayCommand OpenPopupCommand { get; set; }
        public RelayCommand ClosePopupCommand { get; set; }
        public UnisonElevatorConfigurationView(Elevator8003Configuration elevatorConfiguration) : base(elevatorConfiguration)
        {
            InitializeComponent();
            if (elevatorConfiguration == null)
                elevatorConfiguration = new Elevator8003Configuration();
            this.elevatorConfiguration = elevatorConfiguration;
            DataContext = this;
            AvailableFloors = new ObservableCollection<ElevatorFloor8003Configuration>();
            updateFloorData(elevatorConfiguration.FloorIds);

            setFloorControllerAddresses(findLogicalChildren<ComboBox>(floorRelaysControllerAddressPanel));

            AddFloorsCommand = new RelayCommand(items =>
            {
                var selectedItems = items as IList<object>;
                if (selectedItems != null && selectedItems.Count > 0)
                {
                    var floorIds = elevatorConfiguration.FloorIds?.ToList() ?? new List<int>();
                    var selectedIds = from item in selectedItems select ((ElevatorFloor8003Configuration)item).Id;
                    floorIds = floorIds.Union(selectedIds).ToList();
                    elevatorConfiguration.FloorIds = floorIds.ToArray();
                    updateFloorData(floorIds);
                }
                addFloorsPopup.IsOpen = false;
            });
            RemoveFloorsCommand = new RelayCommand(items => 
            {
                var selectedItems = items as IList<object>;
                if (selectedItems != null && selectedItems.Count > 0)
                {
                    var selectedIds = from item in selectedItems select ((ElevatorFloor8003Configuration)item).Id;
                    var floorIds = elevatorConfiguration.FloorIds.Except(selectedIds).ToArray();
                    elevatorConfiguration.FloorIds = floorIds;
                    updateFloorData(floorIds);
                }
            },
            _ => { return floorsListView.SelectedItems.Count > 0; });
            OpenPopupCommand = new RelayCommand(_ => 
            {
                addFloorsPopup.IsOpen = true;
            }, _ =>
            {
                var allIds = (from item in ConfigurationManager.ElevatorFloors.Values select item.Id).ToList();
                var usedIds = elevatorConfiguration.FloorIds?.ToList() ?? new List<int>();
                var floorIds = allIds.Except(usedIds);
                return floorIds.Count() > 0;
            });
            ClosePopupCommand = new RelayCommand(_ => { addFloorsPopup.IsOpen = false; });
        }

        private void updateFloorData(IEnumerable<int> floorIds)
        {
            AvailableFloors.Clear();
            if (floorIds != null && floorIds.Count() > 0)
            {
                foreach (var floor in ConfigurationManager.ElevatorFloors.Values)
                {
                    if (floorIds.Contains(floor.Id))
                    {
                        AvailableFloors.Add(floor);
                    }
                }
            }
        }

        private void addFloorsPopup_Opened(object sender, EventArgs e)
        {
            var allIds = (from item in ConfigurationManager.ElevatorFloors.Values select item.Id).ToList();
            var usedIds = elevatorConfiguration.FloorIds?.ToList() ?? new List<int>();
            var floorIds = allIds.Except(usedIds);
            elevatorFloorsListBox.Items.Clear();
            if (floorIds != null && floorIds.Count() > 0)
            {
                foreach(var floor in ConfigurationManager.ElevatorFloors.Values)
                {
                    if(floorIds.Contains(floor.Id))
                        elevatorFloorsListBox.Items.Add(floor);
                }
            }
        }

        private void floorRelaysControllerAddressPanel_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            onFloorControllerAddressSelectionChange(e.OriginalSource as ComboBox);
        }

    }
}
