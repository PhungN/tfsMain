﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.Model;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using Xceed.Wpf.Toolkit;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class GridViewBase : Grid
    {
        private ConfigurationBase nodeConfiguration = null;

        public GridViewBase(ConfigurationBase configuration, Type viewType)
        { 
            nodeConfiguration = configuration;
            Grid grid = new Grid();
            grid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            grid.DataContext = configuration;
            int expanderRow = 0;

            //CustomExpander idExpander = viewType == typeof(VaultControllerView) ? createIdentityExpander(configuration.GetType(), false, new string[] { "Id" }) : createIdentityExpander(configuration.GetType(), viewType);
            //Grid.SetRow(idExpander, expanderRow++);
            //grid.Children.Add(idExpander);
            if(viewType != typeof(VaultControllerView))
            {
                CustomExpander idExpander = createIdentityExpander(configuration.GetType(), viewType);
                Grid.SetRow(idExpander, expanderRow++);
                grid.Children.Add(idExpander);
            }

            CustomExpander viewExpander = createViewTypeExpander(configuration, viewType);
            Grid.SetRow(viewExpander, expanderRow++);
            grid.Children.Add(viewExpander);
#if DEBUG
            CustomExpander debugOnlyExpander = createDebugOnlyExpander(configuration.GetType());
            Grid.SetRow(debugOnlyExpander, expanderRow++);
            grid.Children.Add(debugOnlyExpander);
#endif
            ResourceDictionary style = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\ExpanderStyle.xaml", UriKind.Relative));
            foreach (var expander in findLogicalChildren<Expander>(grid))
            {
                expander.Style = (Style)style["ExpanderStyle1"];
            }
            ScrollViewer scrollViewer = new ScrollViewer();
            scrollViewer.Content = grid;
            scrollViewer.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            this.Children.Clear();
            this.Children.Add(scrollViewer);
        }

        public GridViewBase(ConfigurationBase configuration, Type viewType, bool test)
        {
            nodeConfiguration = configuration;
            Grid grid = new Grid();
            grid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            grid.DataContext = configuration;
            CustomExpander idExpander = viewType == typeof(VaultControllerView) ? createIdentityExpander(configuration.GetType(), false, new string[] { "Id" }) : createIdentityExpander(configuration.GetType(), viewType);
            Grid.SetRow(idExpander, 0);
            grid.Children.Add(idExpander);

            Grid testGrid = Activator.CreateInstance(viewType, new object[] { configuration }) as Grid;
            if (testGrid != null)
            {
                Grid.SetRow(testGrid, 1);
                grid.Children.Add(testGrid);
            }
                
#if DEBUG
            CustomExpander debugOnlyExpander = createDebugOnlyExpander(configuration.GetType());
            Grid.SetRow(debugOnlyExpander, 2);
            grid.Children.Add(debugOnlyExpander);
#endif
            ResourceDictionary style = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\ExpanderStyle.xaml", UriKind.Relative));
            foreach (var expander in findLogicalChildren<Expander>(grid))
            {
                expander.Style = (Style)style["ExpanderStyle1"];
            }
            ScrollViewer scrollViewer = new ScrollViewer();
            scrollViewer.Content = grid;
            scrollViewer.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            this.Children.Clear();
            this.Children.Add(scrollViewer);
        }

        private Grid createExpanderHeader(bool includeDeleteButton)
        {
            Grid grid = new Grid { Margin = new Thickness(1) };
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            TextBlock textBlock = new TextBlock
            {
                Text = Translation.GetTranslatedString(Core.Attributes.DisplayCategory.Identification),
                Padding = new Thickness(0, 2, 0, 0)
            };
            textBlock.SetValue(Grid.ColumnProperty, 0);
            grid.Children.Add(textBlock);
            
            if(includeDeleteButton == true)
            {
                Button button = new Button();
                button.SetValue(Grid.ColumnProperty, 1);
                button.HorizontalAlignment = HorizontalAlignment.Right;
                button.Width = 13;
                button.Margin = new Thickness(4);
                button.Padding = new Thickness(2);
                ResourceDictionary buttonStyle = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\CrossButton.xaml", UriKind.Relative));
                button.Style = (Style)buttonStyle["CrossButtonStyle"];
                button.Click += (sender, e) => { ConfigurationManager.Remove(nodeConfiguration); };
                grid.Children.Add(button);
            }
            
            return grid;
        }

        private CustomExpander createIdentityExpander(Type configurationType, bool includeDeleteButton, string[] propertyNames )
        {
            CustomExpander expander = new CustomExpander()
            {
                IsExpanded = true,
                VerticalAlignment = VerticalAlignment.Stretch,
                Header = createExpanderHeader(includeDeleteButton),
            };

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition());

            SortedDictionary<int, Tuple<string, Type>> identities = new SortedDictionary<int, Tuple<string, Type>>();
            foreach (var pr in configurationType.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                ControllerAttribute attr = pr.GetCustomAttribute(typeof(ControllerAttribute)) as ControllerAttribute;
                if (attr != null && attr.Category == DisplayCategory.Identification)
                {
                    if(propertyNames.Contains(pr.Name) == true)
                    {
                        Type controlType = typeof(TextBox);
                        if (pr.PropertyType == typeof(bool))
                            controlType = typeof(CheckBox);
                        else if (pr.Name == "AreaId")
                            controlType = typeof(ComboBox);
                        else if (pr.Name == "Id")
                            controlType = typeof(IntegerUpDown);
                        if (configurationType == typeof(ElevatorFloor8003Configuration) && pr.Name == "Enabled")
                            continue;
                        identities.Add(attr.Order, new Tuple<string, Type>(pr.Name, controlType));
                    }
                }
            }

            int row = 0;
            foreach (var item in identities)
            {
                addRow(grid, row, item.Value);
                row += 1;
            }
            expander.Content = grid;
            return expander;
        }
        private CustomExpander createIdentityExpander(Type configurationType, Type viewType)
        {
            CustomExpander expander = new CustomExpander()
            {
                IsExpanded = true,
                VerticalAlignment = VerticalAlignment.Stretch,
                Header = createExpanderHeader(viewType == typeof(VaultControllerView) ? false : true),
            };

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition());

            SortedDictionary<int, Tuple<string, Type>> identities = new SortedDictionary<int, Tuple<string, Type>>();
            foreach (var pr in configurationType.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                ControllerAttribute attr = pr.GetCustomAttribute(typeof(ControllerAttribute)) as ControllerAttribute;
                if (attr != null && attr.Category == DisplayCategory.Identification)
                {
                    //var v = configurationType.GetType().GetProperty(pr.Name).GetValue(configurationType, null);
                    var t = configurationType.GetType();
                    if(t != null)
                    {
                        var p = t.GetProperty(pr.Name);
                        if(p != null)
                        {
                            var va = p.GetValue(configurationType, null);
                        }
                    }

                    Type controlType = typeof(TextBox);
                    if (pr.PropertyType == typeof(bool))
                        controlType = typeof(CheckBox);
                    else if (pr.Name == "AreaId")
                        controlType = typeof(ComboBox);
                    else if (pr.Name == "Id")
                        controlType = typeof(IntegerUpDown);
                    if (configurationType == typeof(ElevatorFloor8003Configuration) && pr.Name == "Enabled")
                        continue;

                    identities.Add(attr.Order, new Tuple<string, Type>(pr.Name, controlType));
                }
            }

            int row = 0;
            foreach(var item in identities)
            {
                addRow(grid, row, item.Value);
                row += 1;
            }
            expander.Content = grid;
            return expander;
        }

        private CustomExpander createViewTypeExpander(ConfigurationBase configuration, Type viewType)
        {
            CustomExpander expander = new CustomExpander()
            {
                IsExpanded = true,
                VerticalAlignment = VerticalAlignment.Stretch,
                Header = viewType == typeof(VaultControllerView) ? Translation.GetTranslatedString(DisplayCategory.Operation) : Translation.GetTranslatedString("ElevatorSettings")
            };

            Grid grid = Activator.CreateInstance(viewType, new object[] { configuration }) as Grid;
            if (grid != null)
                expander.Content = grid;
            return expander;
        }

        private CustomExpander createDebugOnlyExpander(Type configurationType)
        {
            CustomExpander expander = new CustomExpander()
            {
                IsExpanded = false,
                VerticalAlignment = VerticalAlignment.Stretch,
                Header = Translation.GetTranslatedString(Core.Attributes.DisplayCategory.Hidden),
            };

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition());

            int row = 0;
            foreach (var pr in configurationType.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                ControllerAttribute attr = pr.GetCustomAttribute(typeof(ControllerAttribute)) as ControllerAttribute;
                if (attr != null && attr.Category == DisplayCategory.Hidden)
                {
                    if (pr.PropertyType == typeof(bool))
                        addRow(grid, row, new Tuple<string, Type>(pr.Name, typeof(CheckBox)), false);
                    else
                        addRow(grid, row, new Tuple<string, Type>(pr.Name, typeof(TextBox)));
                    row += 1;
                }
            }
            
            expander.Content = grid;
            return expander;
        }

        private void addRow(Grid grid, int row, Tuple<string, Type> identity, bool isEnabled=true)
        {
            grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(40) });
            Control label = createLabel(identity.Item1);
            Control control = null;
            if (identity.Item2 == typeof(CheckBox))
                control = createCheckBox(identity.Item1);
            else if (identity.Item2 == typeof(ComboBox))
                control = createComboBox(identity.Item1);
            else if (identity.Item2 == typeof(IntegerUpDown))
                control = createUpDownControl(identity.Item1);
            else
                control = createTextBox(identity.Item1);
            control.Margin = new Thickness(5);
            control.IsEnabled = isEnabled;

            Grid.SetRow(label, row);
            Grid.SetColumn(label, 0);
            Grid.SetRow(control, row);
            Grid.SetColumn(control, 1);
            grid.Children.Add(label);
            grid.Children.Add(control);
        }

        private Control createLabel(string text)
        {
            Label label = new Label();
            label.Content = Translation.GetTranslatedString(text);
            label.Margin = new Thickness(5);
            label.Foreground = Brushes.Black;
            return label;
        }

        private Control createTextBox(string propertyName)
        {
            TextBox textBox = new TextBox();
            textBox.Height = 30;
            textBox.Padding = new Thickness(5, 5, 0, 0);
            setBinding(textBox, TextBox.TextProperty, propertyName, UpdateSourceTrigger.PropertyChanged);
            textBox.TextChanged += (sender, e) => { NodeTreeView.Instance.RefreshDataContext(); };
            return textBox;
        }

        private Control createComboBox(string propertyName)
        {
            ComboBox comboBox = new ComboBox();
            comboBox.MaxDropDownHeight = 200;
            comboBox.Height = 30;
            comboBox.Padding = new Thickness(7, 5, 0, 0);
            List<ComboBoxItemContents> areas = ControllerConfigurationManager.GetAvailableAreas(true);
            foreach (ComboBoxItemContents area in areas)
            {
                comboBox.Items.Add(area);
            }
            setBinding(comboBox, ComboBox.SelectedIndexProperty, propertyName);
            return comboBox;
        }

        private Control createCheckBox(string propertyName)
        {
            CustomCheckBox checkBox = new CustomCheckBox();
            checkBox.Style = (Style)((ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\CheckboxSliderStyle.xaml", UriKind.Relative)))["OrangeSwitchStyle"];
            checkBox.VerticalAlignment = VerticalAlignment.Center;
            checkBox.HorizontalAlignment = HorizontalAlignment.Center;
            checkBox.SetValue(FrameworkElement.HorizontalAlignmentProperty, HorizontalAlignment.Left);
            setBinding(checkBox, CheckBox.IsCheckedProperty, propertyName);
            return checkBox;
        }

        private Control createUpDownControl(string propertyName)
        {
            IntegerUpDown integerUpDown = new IntegerUpDown();
            integerUpDown.Height = 30;
            integerUpDown.Padding = new Thickness(0, 0, 5, 0);
            RangeAttribute rangeAttribute = new RangeAttribute(int.MinValue, int.MaxValue);
            integerUpDown.Minimum = rangeAttribute.Minimum;
            integerUpDown.Maximum = rangeAttribute.Maximum;
            integerUpDown.TextAlignment = TextAlignment.Left;
            if (propertyName == "Id")
                integerUpDown.IsReadOnly = true;
            setBinding(integerUpDown, IntegerUpDown.ValueProperty, propertyName);
            return integerUpDown;
        }

        private void setBinding(FrameworkElement control, DependencyProperty dp, string path)
        {
            Binding binding = new Binding();
            binding.Mode = BindingMode.TwoWay;
            binding.Path = new PropertyPath(path);
            control.SetBinding(dp, binding);
        }

        private void setBinding(FrameworkElement control, DependencyProperty dp, string path, UpdateSourceTrigger updateSourceTrigger)
        {
            Binding binding = new Binding();
            binding.Mode = BindingMode.TwoWay;
            binding.Path = new PropertyPath(path);
            binding.UpdateSourceTrigger = updateSourceTrigger;
            control.SetBinding(dp, binding);
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            ResourceDictionary style = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\ExpanderStyle.xaml", UriKind.Relative));
            foreach (var expander in findLogicalChildren<Expander>(this))
            {
                expander.Style = (Style)style["ExpanderStyle1"];
                //expander.Foreground = new SolidColorBrush(Color.FromRgb(0, 0, 0));
            }

        }

        private IEnumerable<T> findLogicalChildren<T>(DependencyObject dependencyObject) where T : DependencyObject
        {
            if (dependencyObject != null)
            {
                foreach (var rawChild in LogicalTreeHelper.GetChildren(dependencyObject))
                {
                    if (rawChild is DependencyObject)
                    {
                        DependencyObject child = (DependencyObject)rawChild;
                        if (child is T)
                        {
                            yield return (T)child;
                        }

                        foreach (T childOfChild in findLogicalChildren<T>(child))
                        {
                            yield return childOfChild;
                        }
                    }
                }
            }
        }
    }

}
