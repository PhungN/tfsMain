﻿using Pacom.Configuration.ConfigurationCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pacom.ConfigurationEditor.WPF.View
{
    /// <summary>
    /// Interaction logic for VaultControllerView.xaml
    /// </summary>
    public partial class VaultControllerView : Grid
    {
        //public VaultController8003Configuration Configuration { get; set; }
        public Device8003Configuration Configuration { get; set; }
        public VaultControllerView(Device8003Configuration vaultConfiguration)
        {
            InitializeComponent();
            Configuration = vaultConfiguration;
            //if(Configuration.Interlocks == null)
            //    Configuration.Interlocks = new int[8];
            //interlockGroup1.Data = Configuration.Interlocks[0];
            //interlockGroup2.Data = Configuration.Interlocks[1];
            //interlockGroup3.Data = Configuration.Interlocks[2];
            //interlockGroup4.Data = Configuration.Interlocks[3];
            //interlockGroup5.Data = Configuration.Interlocks[4];
            //interlockGroup6.Data = Configuration.Interlocks[5];
            //interlockGroup7.Data = Configuration.Interlocks[6];
            //interlockGroup8.Data = Configuration.Interlocks[7];
        }

        private void interlockGroup1_DataChanged(object sender, UserControls.CheckBoxes.DataChangedEventArgs e)
        {
            //Configuration.Interlocks[0] = (UInt16)e.Data;
        }

        private void interlockGroup2_DataChanged(object sender, UserControls.CheckBoxes.DataChangedEventArgs e)
        {
            //Configuration.Interlocks[1] = (UInt16)e.Data;
        }

        private void interlockGroup3_DataChanged(object sender, UserControls.CheckBoxes.DataChangedEventArgs e)
        {
            //Configuration.Interlocks[2] = (UInt16)e.Data;
        }

        private void interlockGroup4_DataChanged(object sender, UserControls.CheckBoxes.DataChangedEventArgs e)
        {
            //Configuration.Interlocks[3] = (UInt16)e.Data;
        }

        private void interlockGroup5_DataChanged(object sender, UserControls.CheckBoxes.DataChangedEventArgs e)
        {
            //Configuration.Interlocks[4] = (UInt16)e.Data;
        }

        private void interlockGroup6_DataChanged(object sender, UserControls.CheckBoxes.DataChangedEventArgs e)
        {
            //Configuration.Interlocks[5] = (UInt16)e.Data;
        }

        private void interlockGroup7_DataChanged(object sender, UserControls.CheckBoxes.DataChangedEventArgs e)
        {
            //Configuration.Interlocks[6] = (UInt16)e.Data;
        }

        private void interlockGroup8_DataChanged(object sender, UserControls.CheckBoxes.DataChangedEventArgs e)
        {
            //Configuration.Interlocks[7] = (UInt16)e.Data;
        }
    }
}
