﻿
namespace Pacom.ConfigurationEditor.WPF.View
{
    /// <summary>
    /// Interaction logic for PropertiesView.xaml
    /// </summary>
    public partial class ConfigurationView
    {
        public ConfigurationView()
        {
            InitializeComponent();
        }
    }
}
