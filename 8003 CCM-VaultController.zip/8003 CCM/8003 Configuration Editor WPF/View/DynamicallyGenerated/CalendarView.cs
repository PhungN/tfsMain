﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.UserControls;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class CalendarView : ConfigurationViewBase<Pacom.Core.Access.Calendar>
    {
        public CalendarView(Core.Access.Calendar calendar, NodeTreeElement nodeTreeElement) : base(calendar, nodeTreeElement)
        {
            createDefaultView(false);

            categoryGrids[DisplayCategory.Operation].RowDefinitions.Add(new RowDefinition());
            CalendarControl calendarControl = new CalendarControl(calendar);
            calendarControl.SetValue(Grid.RowProperty, 1);
            calendarControl.SetValue(Grid.ColumnProperty, 0);
            calendarControl.SetValue(Grid.ColumnSpanProperty, 2);
            calendarControl.Margin = new Thickness(5);
            categoryGrids[DisplayCategory.Operation].Children.Add(calendarControl);
        }

        protected override ControllerAttribute updateControllerAttribute(PropertyInfo propertyInfo, ControllerAttribute controllerAttribute)
        {
            if (controllerAttribute == null)
                return new ControllerAttribute(DisplayCategory.Hidden);

            return base.updateControllerAttribute(propertyInfo, controllerAttribute);
        }

        protected override void addAdditionalElements(SortedDictionary<DisplayCategory, List<PropertyInfo>> categorisedProperties)
        {
            categorisedProperties[DisplayCategory.Operation] = new List<PropertyInfo>();
        }
    }
}

