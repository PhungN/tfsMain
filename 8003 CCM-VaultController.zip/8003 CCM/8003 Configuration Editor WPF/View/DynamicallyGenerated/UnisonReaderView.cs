﻿using System;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class UnisonReaderView : ConfigurationViewBase<Reader8003Configuration>
    {
        public UnisonReaderView(Reader8003Configuration reader, NodeTreeElement nodeTreeElement) : base(reader, nodeTreeElement)
        {
            createDefaultView(true);
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.UnisonReaders.Remove(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }

        protected override object preSetValue(FrameworkElement frameworkElement, PropertyInfo property, object newValue)
        {
            if (property.Name == "Enabled" && (bool)newValue == true
                && ConfigurationManager.ControllerHasCapacity<Reader8003Configuration>() == false)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.LicenseCapacity),
                    Translation.GetTranslatedError(ErrorMessage.Warning));
            }

            return base.preSetValue(frameworkElement, property, newValue);
        }
    }
}
