﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public enum UserPermissionType
    {
        ArmAndDisarm,
        Isolate
    }

    public class UserView : ConfigurationViewBase<User8003Configuration>
    {
        Dictionary<int, AreaAccessPrivilege> userPermissions = new Dictionary<int, AreaAccessPrivilege>();

        public UserView(User8003Configuration user, NodeTreeElement nodeTreeElement) : base(user, nodeTreeElement)
        {
            createDefaultView(true);

            if (configurationItem.AreaIds == null)
                configurationItem.AreaIds = new int[0];
            if (configurationItem.AreaAccessPrivilege == null)
                configurationItem.AreaAccessPrivilege = new AreaAccessPrivilege[0];
            if (configurationItem.AreaIds.Length != configurationItem.AreaAccessPrivilege.Length)
                configurationItem.AreaAccessPrivilege = new AreaAccessPrivilege[configurationItem.AreaIds.Length];
            for (int i = 0; i < configurationItem.AreaIds.Length; i++)
            {
                if (configurationItem.AreaAccessPrivilege[i] == null)
                    userPermissions[configurationItem.AreaIds[i]] = new AreaAccessPrivilege() { CanIsolate = true };
                else
                    userPermissions[configurationItem.AreaIds[i]] = configurationItem.AreaAccessPrivilege[i];
            }

            categoryGrids[DisplayCategory.UserPermissions].RowDefinitions.Add(new RowDefinition());
            ScrollViewer scrollViewer = new ScrollViewer();
            Grid userPermissionsGrid = new Grid();
            scrollViewer.SetValue(Grid.ColumnSpanProperty, 2);
            scrollViewer.Content = userPermissionsGrid;
            scrollViewer.VerticalScrollBarVisibility = ScrollBarVisibility.Disabled;
            scrollViewer.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            categoryGrids[DisplayCategory.UserPermissions].Children.Add(scrollViewer);

            // Add columns
            for (int i = 0; i < (ConfigurationManager.Areas.Count + 2); i++)
            {
                userPermissionsGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            }

            // Add rows
            for (int i = 0; i < 3; i++)
            {
                userPermissionsGrid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            }
            userPermissionsGrid.RowDefinitions[0].MinHeight = 50;

            Label label = new Label();
            label.Content = Translation.GetTranslatedMisc("ArmDisarm");
            label.SetValue(Grid.RowProperty, 1);
            label.SetValue(Grid.ColumnProperty, 0);
            label.Margin = new Thickness(3);
            userPermissionsGrid.Children.Add(label);

            label = new Label();
            label.Content = Translation.GetTranslatedMisc("IsolatePoints");
            label.SetValue(Grid.RowProperty, 2);
            label.SetValue(Grid.ColumnProperty, 0);
            label.Margin = new Thickness(3);
            userPermissionsGrid.Children.Add(label);

            for (int i = 0; i < ConfigurationManager.Areas.Count; i++)
            {
                label = new Label();
                label.Content = ConfigurationManager.Areas.Values[i].Name;
                label.SetValue(Grid.RowProperty, 0);
                label.SetValue(Grid.ColumnProperty, 1 + i);
                label.Margin = new Thickness(3);
                label.LayoutTransform = new RotateTransform(270);
                userPermissionsGrid.Children.Add(label);
            }

            for (int column = 0; column < (ConfigurationManager.Areas.Count + 1); column++)
            {
                CheckBox armAndDisarmPermissionCheckBox = null;
                for (int row = 0; row < 2; row++)
                {
                    Border border = new Border();
                    border.BorderBrush = Brushes.Black;
                    border.BorderThickness = new Thickness(0, 0, 1, 0);
                    border.SetValue(Grid.RowProperty, row + 1);
                    border.SetValue(Grid.ColumnProperty, column);
                    userPermissionsGrid.Children.Add(border);

                    if (column > 0)
                    {
                        CheckBox checkBox = new CheckBox();
                        checkBox.SetValue(Grid.RowProperty, row + 1);
                        checkBox.SetValue(Grid.ColumnProperty, column);
                        checkBox.Margin = new Thickness(10);

                        int areaId = ConfigurationManager.Areas.Values[column - 1].Id;
                        checkBox.Resources["AreaId"] = areaId;
                        if (row == 0)
                        {
                            checkBox.Resources["UserPermissionType"] = UserPermissionType.ArmAndDisarm;
                            checkBox.Resources["Children"] = new List<CheckBox>();
                            if (userPermissions.ContainsKey(areaId))
                                checkBox.IsChecked = true;
                            armAndDisarmPermissionCheckBox = checkBox;
                        }
                        else if (row == 1)
                        {
                            checkBox.Resources["UserPermissionType"] = UserPermissionType.Isolate;
                            checkBox.Resources["ArmAndDisarmPermissionCheckBox"] = armAndDisarmPermissionCheckBox;
                            ((List<CheckBox>)armAndDisarmPermissionCheckBox.Resources["Children"]).Add(checkBox);
                            if (armAndDisarmPermissionCheckBox.IsChecked == false)
                            {
                                checkBox.IsEnabled = false;
                            }
                            else
                            {
                                if (userPermissions[areaId].CanIsolate)
                                    checkBox.IsChecked = true;
                            }
                        }
                        checkBox.Checked += CheckBox_Checked;
                        checkBox.Unchecked += CheckBox_Checked;
                        userPermissionsGrid.Children.Add(checkBox);
                    }
                }
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = (CheckBox)sender;
            UserPermissionType userPermissionType = (UserPermissionType)checkBox.Resources["UserPermissionType"];
            int areaId = (int)checkBox.Resources["AreaId"];

            if (checkBox.Resources.Contains("Children"))
            {
                List<CheckBox> children = (List<CheckBox>)checkBox.Resources["Children"];
                if (checkBox.IsChecked == true)
                {
                    foreach (CheckBox child in children)
                    {
                        child.IsEnabled = true;
                    }
                }
                else
                {
                    foreach (CheckBox child in children)
                    {
                        child.IsChecked = false;
                        child.IsEnabled = false;
                    }
                }
            }

            if (userPermissionType == UserPermissionType.ArmAndDisarm)
            {
                if (checkBox.IsChecked == true)
                    userPermissions[areaId] = new AreaAccessPrivilege();
                else
                    userPermissions.Remove(areaId);
            }
            else if (userPermissionType == UserPermissionType.Isolate)
            {
                userPermissions[areaId].CanIsolate = checkBox.IsChecked.Value;
            }

            // Update the configurationItem with a sorted set of permissons.
            List<int> areaIds = new List<int>(userPermissions.Keys);
            areaIds.Sort();
            configurationItem.AreaIds = areaIds.ToArray();
            configurationItem.AreaAccessPrivilege = new AreaAccessPrivilege[configurationItem.AreaIds.Length];
            for (int i = 0; i < areaIds.Count; i++)
            {
                configurationItem.AreaAccessPrivilege[i] = userPermissions[areaIds[i]];
            }
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.Users.Remove(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }

        protected override void addAdditionalElements(SortedDictionary<DisplayCategory, List<PropertyInfo>> categorisedProperties)
        {
            categorisedProperties[DisplayCategory.UserPermissions] = new List<PropertyInfo>();
        }
    }
}
