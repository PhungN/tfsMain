﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.UserControls;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class ScheduleView : ConfigurationViewBase<Schedule>
    {
        public ScheduleView(Schedule schedule, NodeTreeElement nodeTreeElement) : base(schedule, nodeTreeElement)
        {
            createDefaultView(true);

            categoryGrids[DisplayCategory.ScheduleSettings].RowDefinitions.Add(new RowDefinition());
            ScheduleControl scheduleControl = new ScheduleControl(schedule);
            scheduleControl.SetValue(Grid.RowProperty, 1);
            scheduleControl.SetValue(Grid.ColumnProperty, 0);
            scheduleControl.SetValue(Grid.ColumnSpanProperty, 2);
            scheduleControl.Margin = new Thickness(5);
            categoryGrids[DisplayCategory.ScheduleSettings].Children.Add(scheduleControl);
        }

        protected override ControllerAttribute updateControllerAttribute(PropertyInfo propertyInfo, ControllerAttribute controllerAttribute)
        {
            if (controllerAttribute == null)
                return new ControllerAttribute(DisplayCategory.Hidden);

            return base.updateControllerAttribute(propertyInfo, controllerAttribute);
        }

        protected override void addAdditionalElements(SortedDictionary<DisplayCategory, List<PropertyInfo>> categorisedProperties)
        {
            categorisedProperties[DisplayCategory.ScheduleSettings] = new List<PropertyInfo>();
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.Schedules.Remove(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }
    }
}
