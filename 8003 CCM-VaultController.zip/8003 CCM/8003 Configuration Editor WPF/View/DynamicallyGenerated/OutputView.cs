﻿using System;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class OutputView : ConfigurationViewBase<Output8003Configuration>
    {
        public OutputView(Output8003Configuration output, NodeTreeElement nodeTreeElement) : base(output, nodeTreeElement)
        {
            createDefaultView(true);
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.Outputs.Remove(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }

        protected override object preSetValue(FrameworkElement frameworkElement, PropertyInfo property, object newValue)
        {
            if (property.Name == "Enabled" && (bool)newValue == true
                && ConfigurationManager.ControllerHasCapacity<Output8003Configuration>() == false)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.LicenseCapacity),
                    Translation.GetTranslatedError(ErrorMessage.Warning));
            }

            return base.preSetValue(frameworkElement, property, newValue);
        }
    }
}
