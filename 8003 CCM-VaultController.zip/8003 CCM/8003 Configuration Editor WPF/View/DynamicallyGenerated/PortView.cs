﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class PortView : ConfigurationViewBase<Port8003ConfigurationBase>
    {
        public PortView(Port8003ConfigurationBase port, NodeTreeElement nodeTreeElement) : base(port, nodeTreeElement)
        {
            createDefaultView(false);

            Port8003IPPortConfiguration ipPort = port as Port8003IPPortConfiguration;
            if (ipPort != null)
            {
                if (ipPort.UseDhcpServer == true)
                {
                    getUIElement("IPAddress").IsEnabled = false;
                    getUIElement("SubnetMask").IsEnabled = false;
                    getUIElement("DnsServer").IsEnabled = false;
                    getUIElement("DefaultGateway").IsEnabled = false;
                }
            }

            Port8003GprsPortConfiguration gprsPort = configurationItem as Port8003GprsPortConfiguration;
            if (gprsPort != null)
            {
                getUIElement("DialModifier").IsEnabled = (gprsPort.DialModifier.Length > 0);
            }
        }

        protected override void addAdditionalElements(SortedDictionary<DisplayCategory, List<PropertyInfo>> categorisedProperties)
        {
            // Add a protocol dropdown if this is an RS485 type port
            if (configurationItem is Port8003RS485PortConfiguration)
            {
                RS485ProtocolPropertyInfo propertyInfo = new RS485ProtocolPropertyInfo();
                propertyInfo.ProtocolChanged += PropertyInfo_RS485ProtocolChanged;
                categorisedProperties[DisplayCategory.Identification].Add(propertyInfo);
                return;
            }

            // Add a protocol dropdown if this is a RS232 type port
            if (configurationItem is Port8003RS232PortConfiguration)
            {
                RS232ProtocolPropertyInfo propertyInfo = new RS232ProtocolPropertyInfo();
                propertyInfo.ProtocolChanged += PropertyInfo_RS232ProtocolChanged;
                categorisedProperties[DisplayCategory.Identification].Add(propertyInfo);
            }

            Port8003GprsPortConfiguration gprsPort = configurationItem as Port8003GprsPortConfiguration;
            if (gprsPort != null)
            {
                CellularAutomaticAccessPointNamePropertyInfo propertyInfo = new CellularAutomaticAccessPointNamePropertyInfo();
                propertyInfo.ValueChanged += PropertyInfo_ValueChanged;
                categorisedProperties[DisplayCategory.General].Add(propertyInfo);
            }
        }

        protected override string getLabelText(PropertyInfo propertyInfo)
        {
            if (propertyInfo.Name == "DialModifier")
            {
                Port8003GprsPortConfiguration gprsPort = configurationItem as Port8003GprsPortConfiguration;
                if (gprsPort != null)
                {
                    if (gprsPort.DialModifier.Length > 0 && gprsPort.DialModifier[0] == '+')
                        return Translation.GetTranslatedString(propertyInfo);
                    else
                        return Translation.GetTranslatedMisc("AccessPointName");
                }
            }

            return base.getLabelText(propertyInfo);
        }

        private void PropertyInfo_ValueChanged(object sender, CellularAutomaticAccessPointNameEventArgs e)
        {
            if (e.AutomaticApn)
            {
                getUIElement("DialModifier").IsEnabled = false;
                Port8003GprsPortConfiguration gprsPort = configurationItem as Port8003GprsPortConfiguration;
                if (gprsPort != null)
                {
                    gprsPort.DialModifier = string.Empty;
                    nodeTreeElement.ConfigurationItem = configurationItem;
                }
            }
            else
            {
                getUIElement("DialModifier").IsEnabled = true;
            }
        }

        private void PropertyInfo_RS485ProtocolChanged(object sender, PortRS485ControllerProtocolsEventArgs e)
        {
            Port8003ConfigurationBase newPort = null;

            if (e.NewProtocol == PortRS485ControllerProtocols.Pacom)
                newPort = new Port8003RS485DeviceLoopPortConfiguration();
            else if (e.NewProtocol == PortRS485ControllerProtocols.Osdp)
                newPort = new Port8003RS485OsdpDeviceLoopPortConfiguration();
            else if (e.NewProtocol == PortRS485ControllerProtocols.Aprp)
                newPort = new Port8003RS485AsisProprietaryReaderPortConfiguration();
            else if (e.NewProtocol == PortRS485ControllerProtocols.Aperio)
                newPort = new Port8003RS485AperioPortConfiguration();
            updatePort(newPort);
        }

        private void PropertyInfo_RS232ProtocolChanged(object sender, PortRS232ControllerProtocolsEventArgs e)
        {
            Port8003ConfigurationBase newPort = null;

            if (e.NewProtocol == PortRS232ControllerProtocols.Debug)
                newPort = new Port8003RS232DebugPortConfiguration();
            else if (e.NewProtocol == PortRS232ControllerProtocols.InovonicsEchoStream)
                newPort = new Port8003RS232InovonicsPortConfiguration();
            updatePort(newPort);
        }

        private void updatePort(Port8003ConfigurationBase newPort)
        {
            App.ConfigurationModified = true;
            newPort.Id = configurationItem.Id;
            ConfigurationManager.AutoConfigure(newPort, configurationItem.ParentDeviceId, configurationItem.PortNumberOnParent);
            newPort.ParentDeviceId = configurationItem.ParentDeviceId;
            newPort.PortNumberOnParent = configurationItem.PortNumberOnParent;
            newPort.Name = configurationItem.Name;
            newPort.Enabled = configurationItem.Enabled;

            nodeTreeElement.ConfigurationItem = newPort;

            // If this is an Aperio port, then there must be a (hidden) Aperio Driver.
            // If this is not (or no longer) an Aperio port, there should not be an Aperio Driver.

            bool portIsAperio = newPort.PortType == PortType.RS485Aperio;

            // See if there is an Aperio Driver associated with this port
            AperioDriverConfiguration aperioDriver = null;
            foreach (DeviceConfigurationBase dev in ConfigurationManager.Devices.Values)
            {
                if (dev.ParentDeviceId == ConfigurationManager.ControllerConfiguration.Id &&
                    dev is AperioDriverConfiguration && 
                    (dev as AperioDriverConfiguration).PortNumberOnParent == newPort.PortNumberOnParent)
                {
                    aperioDriver = dev as AperioDriverConfiguration;
                    break;
                }
            }

            bool foundAperioDriver = aperioDriver != null;

            if (portIsAperio == false && foundAperioDriver == true)
            {
                // Port shouldn't have a driver, but there is one. Remove the driver

                ConfigurationManager.RemoveDevice(aperioDriver.Id); // Remove the no longer needed Aperio driver, along with any dependent doors and readers
                NodeTreeView.LoadTree(); // In case RemoveDevice removed some Doors and/or Readers
                NodeTreeView.SetSelection(newPort); // LoadTree selects the root node, so set the selection back to us
            }
            else if (portIsAperio == true && foundAperioDriver == false)
            {
                // Port short have a driver, but there isn't one. Add the Aperio driver
                AperioDriverConfiguration newObject = new AperioDriverConfiguration();
                ConfigurationManager.AutoConfigure(newObject, 1, newPort.PortNumberOnParent);
            }
        }

        protected override ControllerAttribute updateControllerAttribute(PropertyInfo propertyInfo, ControllerAttribute controllerAttribute)
        {
            if (configurationItem is Port8003IPPortConfiguration)
            {
                if (propertyInfo.Name == "Enabled")
                    return new ControllerAttribute(DisplayCategory.Hidden);
            }
            if (propertyInfo.Name == "ParentDeviceId" ||
                propertyInfo.Name == "PortNumberOnParent")
                return new ControllerAttribute(DisplayCategory.Hidden);

            return base.updateControllerAttribute(propertyInfo, controllerAttribute);
        }

        protected override object preSetValue(FrameworkElement frameworkElement, PropertyInfo property, object newValue)
        {
            if (property.Name == "UseDhcpServer")
            {
                bool useDhcpServer = (bool)newValue;
                getUIElement("IPAddress").IsEnabled = !useDhcpServer;
                getUIElement("SubnetMask").IsEnabled = !useDhcpServer;
                getUIElement("DnsServer").IsEnabled = !useDhcpServer;
                getUIElement("DefaultGateway").IsEnabled = !useDhcpServer;
            }
            return newValue;
        }
    }
}
