﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using System.Windows;
using System.Windows.Input;
using Pacom.ConfigurationEditor.WPF.Model;
using System.Windows.Media;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Core.Contracts;
using Pacom.ConfigurationEditor.WPF.UserControls;
using Xceed.Wpf.Toolkit;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class ConnectionTableView : ConfigurationViewBase<ControllerConnection8003Table>
    {
        public ConnectionTableView(ControllerConnection8003Table connectionTable, NodeTreeElement nodeTreeElement) : base(connectionTable, nodeTreeElement)
        {
            RowDefinitions.Add(new RowDefinition());
            ScrollViewer scrollViewer = new ScrollViewer();
            parentGrid = new Grid();

            scrollViewer.Content = parentGrid;
            Children.Add(scrollViewer);

            // Get the properties for the connection entries
            List<PropertyInfo> connectionEntryProperties = new List<PropertyInfo>();
            Type currentType = typeof(ControllerConnection8003Entry);
            foreach (PropertyInfo propertyInfo in currentType.GetProperties(BindingFlags.Instance | BindingFlags.Public))
            {
                if (propertyInfo.CanRead == false || propertyInfo.CanWrite == false)
                    continue;

                connectionEntryProperties.Add(propertyInfo);
            }

            // Create Expanders
            categoryGrids = new Dictionary<DisplayCategory, Grid>();
            for (int i = 0; i < connectionTable.ConnectionEntry.Length; i++)
            {
                categoryGrids[(DisplayCategory)i] = addExpander(parentGrid, Translation.GetTranslatedString(DisplayCategory.Connection), false, true, "Connection" + i.ToString(), "Index", i);

                // Add properties
                addPropertiesToGrid(connectionEntryProperties, categoryGrids[(DisplayCategory)i], connectionTable.ConnectionEntry[i]);

                // Select the appropriate IP / PSTN protocol of the digital receiver protocols based on the contents of the highLevelAddress (aka phone number) field.
                TextBox highLevelAddress = (TextBox)getUIElement("HighLevelAddress", categoryGrids[(DisplayCategory)i]);
                if (highLevelAddress.Text.Length == 0)
                {
                    ComboBox protocolTypeComboBox = (ComboBox)getUIElement("ProtocolType", categoryGrids[(DisplayCategory)i]);
                    MessageFormat8003Display protocol = (MessageFormat8003Display)((ComboBoxItemContents)protocolTypeComboBox.SelectedItem).Value;
                    bool changeRequired = false;
                    if (protocol == MessageFormat8003Display.ContactIdOverPstn)
                    {
                        protocol = MessageFormat8003Display.ContactIdOverIP;
                        changeRequired = true;
                    }
                    else if (protocol == MessageFormat8003Display.SiaOverPstn)
                    {
                        protocol = MessageFormat8003Display.SiaOverIP;
                        changeRequired = true;
                    }
                    if (changeRequired)
                    {
                        for (int comboBoxIndex = 0; comboBoxIndex < protocolTypeComboBox.Items.Count; comboBoxIndex++)
                        {
                            ComboBoxItemContents item = (ComboBoxItemContents)protocolTypeComboBox.Items[comboBoxIndex];
                            if ((int)item.Value == (int)protocol)
                            {
                                protocolTypeComboBox.SelectedIndex = comboBoxIndex;
                                break;
                            }
                        }
                    }
                }
                disablePropertiesBasedOnProtocol(categoryGrids[(DisplayCategory)i]);
            }

            List<PropertyInfo> connectionTableProperties = new List<PropertyInfo>();
            currentType = typeof(ControllerConnection8003Table);
            foreach (PropertyInfo propertyInfo in currentType.GetProperties(BindingFlags.Instance | BindingFlags.Public))
            {
                if (propertyInfo.CanRead == false || propertyInfo.CanWrite == false)
                    continue;

                if (propertyInfo.Name == "ConnectionEntry")
                    continue;
#if !DEBUG
                if (propertyInfo.Name == "Id")
                    continue;
                if (propertyInfo.Name == "RevisionId")
                    continue;
#endif

                connectionTableProperties.Add(propertyInfo);
            }

            // Add the password
            RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            Grid connectionTablePropertiesGrid = new Grid();
            connectionTablePropertiesGrid.SetValue(RowProperty, 1);
            Children.Add(connectionTablePropertiesGrid);
            addPropertiesToGrid(connectionTableProperties, connectionTablePropertiesGrid);

            // Add the new connection entry button
            RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            ResourceDictionary buttonStyle = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\ButtonStyle.xaml", UriKind.Relative));
            Button addButton = new Button
            {
                Height = 30,
                Width = 110,
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(5),
                Content = Translation.GetTranslatedMisc("AddConnection"),
                Style = (Style)buttonStyle["ButtonStyle1"]
            };
            addButton.Click += AddButton_Click;
            addButton.SetValue(RowProperty, 2);
            Children.Add(addButton);
        }

        private void disablePropertiesBasedOnProtocol(Grid grid)
        {
            ComboBox protocolTypeComboBox = (ComboBox)getUIElement("ProtocolType", grid);
            MessageFormat8003Display protocol = (MessageFormat8003Display)((ComboBoxItemContents)protocolTypeComboBox.SelectedItem).Value;

            if (protocol == MessageFormat8003Display.Asn1)
            {
                getUIElement("EncryptionKey", grid).IsEnabled = false;
                getUIElement("IPProtocolType", grid).IsEnabled = false;

                getUIElement("EnableEventReporting", grid).IsEnabled = true;
                getUIElement("EnableDtpTransfers", grid).IsEnabled = true;
                getUIElement("EnableFullDataEncryption", grid).IsEnabled = true;
                getUIElement("EncryptionMacType", grid).IsEnabled = true;
                getUIElement("HashType", grid).IsEnabled = true;
                getUIElement("ProtocolServiceAddress", grid).IsEnabled = true;
                getUIElement("ControllerHeartbeatType", grid).IsEnabled = true;
                getUIElement("HighLevelAddress", grid).IsEnabled = true;
                getUIElement("IPDestinationAddress", grid).IsEnabled = true;
                getUIElement("IPDestinationPort", grid).IsEnabled = true;
            }
            else if (protocol == MessageFormat8003Display.ContactIdOverIP || protocol == MessageFormat8003Display.SiaOverIP)
            {
                getUIElement("EnableEventReporting", grid).IsEnabled = false;
                getUIElement("EnableDtpTransfers", grid).IsEnabled = false;
                getUIElement("EnableFullDataEncryption", grid).IsEnabled = false;
                getUIElement("EncryptionMacType", grid).IsEnabled = false;
                getUIElement("HashType", grid).IsEnabled = false;
                getUIElement("ProtocolServiceAddress", grid).IsEnabled = false;
                getUIElement("ControllerHeartbeatType", grid).IsEnabled = false;
                ((TextBox)getUIElement("HighLevelAddress", grid)).Text = "";
                getUIElement("HighLevelAddress", grid).IsEnabled = false;

                getUIElement("EncryptionKey", grid).IsEnabled = true;
                getUIElement("IPProtocolType", grid).IsEnabled = true;
                getUIElement("IPDestinationAddress", grid).IsEnabled = true;
                getUIElement("IPDestinationPort", grid).IsEnabled = true;
            }
            else if (protocol == MessageFormat8003Display.ContactIdOverPstn || protocol == MessageFormat8003Display.SiaOverPstn)
            {
                getUIElement("EnableEventReporting", grid).IsEnabled = false;
                getUIElement("EnableDtpTransfers", grid).IsEnabled = false;
                getUIElement("EnableFullDataEncryption", grid).IsEnabled = false;
                getUIElement("EncryptionMacType", grid).IsEnabled = false;
                getUIElement("HashType", grid).IsEnabled = false;
                getUIElement("ProtocolServiceAddress", grid).IsEnabled = false;
                getUIElement("ControllerHeartbeatType", grid).IsEnabled = false;
                getUIElement("EncryptionKey", grid).IsEnabled = false;
                getUIElement("IPProtocolType", grid).IsEnabled = false;
                ((IPAddressControl)getUIElement("IPDestinationAddress", grid)).Text = "0.0.0.0";
                getUIElement("IPDestinationAddress", grid).IsEnabled = false;
                ((IntegerUpDown)getUIElement("IPDestinationPort", grid)).Value = 0;
                getUIElement("IPDestinationPort", grid).IsEnabled = false;

                getUIElement("HighLevelAddress", grid).IsEnabled = true;
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            // Update the expanded categories
            Unload();

            List<ControllerConnection8003Entry> connectionEntries = new List<ControllerConnection8003Entry>(configurationItem.ConnectionEntry);
            ControllerConnection8003Entry newConnectionEntry = new ControllerConnection8003Entry();
            ConfigurationManager.SetDefaults(newConnectionEntry);
            connectionEntries.Add(newConnectionEntry);
            configurationItem.ConnectionEntry = connectionEntries.ToArray();
            NodeTreeView.Instance.RefreshConfigurationView();
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            DependencyObject element = (DependencyObject)sender;
            int index = -1;
            while (true)
            {
                CustomExpander expander = element as CustomExpander;
                if (expander != null)
                {
                    index = (int)expander.Resources["Index"];
                    break;
                }
                element = VisualTreeHelper.GetParent(element);
                if (element == null)
                    return;
            }

            List<ControllerConnection8003Entry> connectionEntries = new List<ControllerConnection8003Entry>(configurationItem.ConnectionEntry);
            connectionEntries.RemoveAt(index);
            configurationItem.ConnectionEntry = connectionEntries.ToArray();

            // Remove the Custom Expander so that the unload process works
            foreach (object child in Children)
            {
                ScrollViewer scrollViewer = child as ScrollViewer;
                if (scrollViewer != null)
                {
                    Grid grid = (Grid)scrollViewer.Content;

                    grid.Children.Remove((UIElement)element);

                    int i = 0;
                    foreach (object expander in grid.Children)
                    {
                        CustomExpander customExpander = (CustomExpander)expander;
                        customExpander.Name = "Connection" + i.ToString();
                        i++;
                    }
                    break;
                }
            }

            NodeTreeView.Instance.RefreshConfigurationView();
        }

        protected override object preSetValue(FrameworkElement frameworkElement, PropertyInfo property, object newValue)
        {
            if (property.Name == "ProtocolType")
            {
                int propertyType = (int)newValue;
                MessageFormat8003Display newProtocol = (MessageFormat8003Display)propertyType;
                if (propertyType > 100)
                    propertyType -= 100;
                newValue = propertyType;

                object parentItem = frameworkElement.Resources["ParentItem"];
                for (int i = 0; i < configurationItem.ConnectionEntry.Length; i++)
                {
                    if (parentItem == configurationItem.ConnectionEntry[i])
                    {
                        disablePropertiesBasedOnProtocol(categoryGrids[(DisplayCategory)i]);

                        if (newProtocol == MessageFormat8003Display.ContactIdOverPstn || newProtocol == MessageFormat8003Display.SiaOverPstn)
                        {
                            ComboBox physicalPortComboBox = (ComboBox)getUIElement("ControllerPhysicalPort", categoryGrids[(DisplayCategory)i]);
                            if ((int)((ComboBoxItemContents)physicalPortComboBox.SelectedItem).Value == (int)Pacom8003ConnectionTablePorts.Ethernet)
                                physicalPortComboBox.SelectedIndex++;
                        }

                        // This is required by the 8003 to function correctly.
                        if (newProtocol == MessageFormat8003Display.ContactIdOverIP || newProtocol == MessageFormat8003Display.SiaOverIP)
                        {
                            ComboBox ipProtocolTypeComboBox = (ComboBox)getUIElement("IPProtocolType", categoryGrids[(DisplayCategory)i]);
                            if (ipProtocolTypeComboBox.SelectedItem == null)
                                ipProtocolTypeComboBox.SelectedIndex = 0;
                            else
                                configurationItem.ConnectionEntry[i].IPProtocolType = (SiaOverIPPacketProtocol)((int)((ComboBoxItemContents)ipProtocolTypeComboBox.SelectedItem).Value);
                        }
                        else
                        {
                            configurationItem.ConnectionEntry[i].IPProtocolType = SiaOverIPPacketProtocol.Unknown;
                        }

                        break;
                    }
                }
            }

            return newValue;
        }

        protected override string ExpanderTypeName
        {
            get
            {
                return configurationItem.GetType().ToString() + configurationItem.Id.ToString();
            }
        }
    }
}
