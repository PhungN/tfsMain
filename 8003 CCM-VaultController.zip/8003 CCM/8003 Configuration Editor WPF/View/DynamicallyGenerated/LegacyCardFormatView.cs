﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.UserControls;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class LegacyCardFormatView : ConfigurationViewBase<LegacyCardFormat>
    {
        public LegacyCardFormatView(LegacyCardFormat cardFormat, NodeTreeElement nodeTreeElement) : base(cardFormat, nodeTreeElement)
        {
            createDefaultView(true);

            categoryGrids[DisplayCategory.ProfileSettings].RowDefinitions.Add(new RowDefinition());
            CardProfile cardProfile = new CardProfile(cardFormat);
            cardProfile.SetValue(Grid.RowProperty, 1);
            cardProfile.SetValue(Grid.ColumnProperty, 0);
            cardProfile.SetValue(Grid.ColumnSpanProperty, 2);
            cardProfile.Margin = new Thickness(5);
            categoryGrids[DisplayCategory.ProfileSettings].Children.Add(cardProfile);
        }

        protected override ControllerAttribute updateControllerAttribute(PropertyInfo propertyInfo, ControllerAttribute controllerAttribute)
        {
            if (controllerAttribute == null)
                return new ControllerAttribute(DisplayCategory.Hidden);

            return base.updateControllerAttribute(propertyInfo, controllerAttribute);
        }

        protected override void addAdditionalElements(SortedDictionary<DisplayCategory, List<PropertyInfo>> categorisedProperties)
        {
            categorisedProperties[DisplayCategory.ProfileSettings] = new List<PropertyInfo>();
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.CardFormats.Remove(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }
    }
}
