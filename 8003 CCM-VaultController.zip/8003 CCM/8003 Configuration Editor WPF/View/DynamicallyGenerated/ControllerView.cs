﻿using System;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.Model;
using Pacom.Core.Attributes;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class ControllerView : ConfigurationViewBase<Device8003Configuration>
    {
        public ControllerView(Device8003Configuration controller, NodeTreeElement nodeTreeElement) : base(controller, nodeTreeElement)
        {
            createDefaultView(false);

            if (controller.UseSiteIdAsContactIdAccountNumber == true)
                getUIElement("ContactIdAccountNumber").IsEnabled = false;
        }

        protected override ControllerAttribute updateControllerAttribute(PropertyInfo propertyInfo, ControllerAttribute controllerAttribute)
        {
            if (propertyInfo.Name == "Id" || 
                propertyInfo.Name == "ParentDeviceId" || 
                propertyInfo.Name == "Enabled")
                return new ControllerAttribute(DisplayCategory.Hidden);

            return base.updateControllerAttribute(propertyInfo, controllerAttribute);
        }

        protected override object preSetValue(FrameworkElement frameworkElement, PropertyInfo property, object newValue)
        {
            if (property.Name == "UseSiteIdAsContactIdAccountNumber")
            {
                bool useSiteIdAsContactIdAccountNumber = (bool)newValue;
                getUIElement("ContactIdAccountNumber").IsEnabled = !useSiteIdAsContactIdAccountNumber;
            }

            return newValue;
        }

        protected override void postSetValue(FrameworkElement frameworkElement, PropertyInfo property, object newValue)
        {
            if (property.Name == "ComplianceLevel")
            {
                ConfigurationManager.ControllerConfiguration.SetComplianceLevelDefaults((ComplianceLevel)newValue);

                foreach (Area8003Configuration area in ConfigurationManager.Areas.Values)
                {
                    area.SetComplianceLevelDefaults((ComplianceLevel)newValue);
                }

                foreach (Port8003ConfigurationBase port in ConfigurationManager.Ports.Values)
                {
                    port.SetComplianceLevelDefaults((ComplianceLevel)newValue);
                }

                Unload();
                NodeTreeView.Instance.RefreshConfigurationView();
            }
        }
    }
}
