﻿using System;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class ElevatorView : ConfigurationViewBase<Elevator8003Configuration>
    {
        public ElevatorView(Elevator8003Configuration elevatorConfiguration, NodeTreeElement nodeTreeElement) :
            base(elevatorConfiguration, nodeTreeElement)
        {
            createDefaultView(true);
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.UnisonElevators.Remove(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }

        protected override ControllerAttribute updateControllerAttribute(PropertyInfo propertyInfo, ControllerAttribute controllerAttribute)
        {
            if (controllerAttribute == null)
                return new ControllerAttribute(DisplayCategory.Hidden);
            else if (propertyInfo.Name == "ParentDeviceId")
                return new ControllerAttribute(DisplayCategory.Hidden);

            return base.updateControllerAttribute(propertyInfo, controllerAttribute);
        }
    }

    public class ElevatorFloorView : ConfigurationViewBase<ElevatorFloor8003Configuration>
    {
        public ElevatorFloorView(ElevatorFloor8003Configuration elevatorFloorConfiguration, NodeTreeElement nodeTreeElement) :
            base(elevatorFloorConfiguration, nodeTreeElement)
        {
            createDefaultView(true);
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.ElevatorFloors.Remove(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }

        protected override ControllerAttribute updateControllerAttribute(PropertyInfo propertyInfo, ControllerAttribute controllerAttribute)
        {
            if (controllerAttribute == null)
                return new ControllerAttribute(DisplayCategory.Hidden);
            else if (propertyInfo.Name == "ParentDeviceId")
                return new ControllerAttribute(DisplayCategory.Hidden);

            return base.updateControllerAttribute(propertyInfo, controllerAttribute);
        }
    }

}

