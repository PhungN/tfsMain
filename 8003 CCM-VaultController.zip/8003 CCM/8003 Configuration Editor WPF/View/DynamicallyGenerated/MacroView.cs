﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Xml.Linq;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using Xceed.Wpf.Toolkit;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class ExpressionCategory
    {
        public ExpressionCategory(string id, string text, List<ExpressionState> states)
        {
            Id = id;
            Text = text;
            States = states;
        }
        public string Id { get; set; }
        public string Text { get; set; }
        public List<ExpressionState> States { get; set; }

    }

    public class ExpressionState
    {
        public ExpressionState(string id, string text, string data, string dataType, string extraDataType, string dataType3, string format)
        {
            Id = id;
            Text = text;
            Data = data;
            DataType = dataType;
            ExtraDataType = extraDataType;
            DataType3 = dataType3;
            Format = format;
        }
        public string Id { get; set; }
        public string Text { get; set; }
        public string Data { get; set; }
        public string DataType { get; set; }
        public string ExtraDataType { get; set; }
        public string DataType3 { get; set; }
        public string Format { get; set; }
        public override string ToString()
        {
            return string.Format("{0},{1},{2},{3},{4},{5},{6}", Id, Text, Data, DataType, ExtraDataType, DataType3, Format);
        }
    }

    public class ExpressionEntry
    {
        public ExpressionEntry()
        {
            Format = null;
            Data = null;
            ExtraData = null;
            Data3 = null;
        }

        public string Format { get; set; }
        public string Data { get; set; }
        public string ExtraData { get; set; }
        public string Data3 { get; set; }
    }

    public class MacroView : ConfigurationViewBase<Macro8003Configuration>
    {
        private const string customMacro = "Custom";

        ScrollViewer conditionsScrollViewer = new ScrollViewer();
        ScrollViewer actionsScrollViewer = new ScrollViewer();

        List<ExpressionEntry> macroConditions = new List<ExpressionEntry>();
        List<ExpressionEntry> macroActions = new List<ExpressionEntry>();

        bool loading = true;
        string dataValue = null;
        string extraDataValue = null;
        string data3Value = null;

        public MacroView(Macro8003Configuration expression, NodeTreeElement nodeTreeElement) : base (expression, nodeTreeElement)
        {
            getMacroData();
            createDefaultView(true);

            ResourceDictionary buttonStyle = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\ButtonStyle.xaml", UriKind.Relative));

            Button conditionAddButton = new Button();
            Button actionAddButton = new Button();

            for (int i = 0; i < 2; i++)
            {
                DisplayCategory displayCategory;
                ScrollViewer scrollViewer;
                string addButtonText;
                List<ExpressionEntry> macroConditionsOrActions;
                Button addButton;
                if (i == 0)
                {
                    displayCategory = DisplayCategory.Conditions;
                    scrollViewer = conditionsScrollViewer;
                    addButtonText = Translation.GetTranslatedMisc("AddCondition");
                    macroConditionsOrActions = macroConditions;
                    addButton = conditionAddButton;
                }
                else
                {
                    displayCategory = DisplayCategory.Actions;
                    scrollViewer = actionsScrollViewer;
                    addButtonText = Translation.GetTranslatedMisc("AddAction");
                    macroConditionsOrActions = macroActions;
                    addButton = actionAddButton;
                }

                categoryGrids[displayCategory].RowDefinitions.Add(new RowDefinition());
                categoryGrids[displayCategory].RowDefinitions.Add(new RowDefinition());
                scrollViewer.SetValue(RowProperty, 0);
                scrollViewer.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
                scrollViewer.SetValue(ColumnSpanProperty, 2);
                Grid grid = new Grid();
                while (grid.ColumnDefinitions.Count < 5)
                {
                    grid.ColumnDefinitions.Add(new ColumnDefinition());
                }
                scrollViewer.Content = grid;
                scrollViewer.Height = 325;

                addButton.Height = 30;
                addButton.Width = 100;
                addButton.HorizontalAlignment = HorizontalAlignment.Left;
                addButton.VerticalAlignment = VerticalAlignment.Bottom;
                addButton.Margin = new Thickness(5);
                addButton.Content = addButtonText;
                addButton.Style = (Style)buttonStyle["ButtonStyle1"];
                addButton.Click += AddConditionOrActionButton_Click;
                addButton.SetValue(RowProperty, 1);
                addButton.Resources["ScrollViewer"] = scrollViewer;
                addButton.Resources["DisplayCategory"] = displayCategory;
                addButton.Resources["MacroConditionsOrActions"] = macroConditionsOrActions;
                categoryGrids[displayCategory].Children.Add(addButton);
                categoryGrids[displayCategory].Children.Add(scrollViewer);
            }

            if (configurationItem.Conditions != null)
            {
                foreach (string specifiedCondition in configurationItem.Conditions)
                {
                    bool specifiedConditionFound = false;
                    if (string.IsNullOrEmpty(specifiedCondition) == false)
                    {
                        foreach (KeyValuePair<string, ExpressionCategory> availableCondition in availableConditions)
                        {
                            foreach (ExpressionState expressionState in availableCondition.Value.States)
                            {
                                if (matchConditionOrAction(specifiedCondition, expressionState.Format))
                                {
                                    addConditionOrAction(conditionAddButton, availableCondition.Key, expressionState, specifiedCondition);
                                    specifiedConditionFound = true;
                                    break;
                                }
                            }
                            if (specifiedConditionFound)
                                break;
                        }
                        if (specifiedConditionFound == false)
                            addConditionOrAction(conditionAddButton, customMacro, null, specifiedCondition);
                    }
                }
            }
            if (configurationItem.Actions != null)
            {
                foreach (string specifiedAction in configurationItem.Actions)
                {
                    bool specifiedActionFound = false;
                    if (string.IsNullOrEmpty(specifiedAction) == false)
                    {
                        foreach (KeyValuePair<string, ExpressionCategory> availableAction in availableActions)
                        {
                            foreach (ExpressionState expressionState in availableAction.Value.States)
                            {
                                if (matchConditionOrAction(specifiedAction, expressionState.Format))
                                {
                                    addConditionOrAction(actionAddButton, availableAction.Key, expressionState, specifiedAction);
                                    specifiedActionFound = true;
                                    break;
                                }
                            }
                            if (specifiedActionFound)
                                break;
                        }
                        if (specifiedActionFound == false)
                            addConditionOrAction(actionAddButton, customMacro, null, specifiedAction);
                    }
                }
            }

            dataValue = null;
            extraDataValue = null;
            data3Value = null;
            loading = false;
        }

        private void addConditionOrAction(Button addButton, string expressionCategory, ExpressionState expressionState, string specifiedConditionOrAction)
        {
            if (expressionCategory == customMacro)
                dataValue = specifiedConditionOrAction;

            ComboBox groupTypeComboBox = addConditionOrAction(addButton);
            foreach (ComboBoxItemContents item in groupTypeComboBox.Items)
            {
                if (expressionCategory == (string)item.Value)
                {
                    groupTypeComboBox.SelectedItem = item;
                    break;
                }
            }

            if (expressionCategory == customMacro)
                return;

            dataValue = getDataValue(expressionState.Format, specifiedConditionOrAction, 0);
            extraDataValue = getDataValue(expressionState.Format, specifiedConditionOrAction, 1);
            data3Value = getDataValue(expressionState.Format, specifiedConditionOrAction, 2);

            ComboBox groupEventsComboBox = (ComboBox)groupTypeComboBox.Resources["GroupEventsComboBox"];
            foreach (ComboBoxItemContents item in groupEventsComboBox.Items)
            {
                if (expressionState == (ExpressionState)item.Value)
                {
                    groupEventsComboBox.SelectedItem = item;
                    break;
                }
            }
        }

        /// matchConditionOrAction is taken verbatim from EMCS code. If any bug fixes are made, please inform EMCS team.
        private static bool matchConditionOrAction(string action, string format)
        {
            if (action.Count(c => c == ',') != format.Count(c => c == ','))
                return false;
            format = "^" + format;
            format = format.Replace(" ", ".?");
            format = format.Replace("{0}", ".*");
            format = format.Replace("{1}", ".*");
            format = format.Replace("{2}", ".*");
            format = format.Replace(@"\", @"\\");
            format = format.Replace("[", @"\[");
            format = format.Replace("]", @"\]");
            format = format.Replace("(", @"\(?");
            format = format.Replace(")", @"\)?");
            format = format.Replace("=", @"\=");
            format += "$";

            return Regex.IsMatch(action, format, RegexOptions.IgnorePatternWhitespace);
        }

#if DEBUG
        /// Used by Unit Tests
        public static string GetDataValue(string format, string action, int index)
        {
            return getDataValue(format, action, index);
        }
#endif

        /// getDataValue is taken verbatim from EMCS code. If any bug fixes are made, please inform EMCS team.
        private static string getDataValue(string format, string action, int index)
        {
            const int maxParameters = 3;
            string cleanFormat = format.Replace("(", "").Replace(")", "").Replace(" ", "");
            string cleanAction = action.Replace("(", "").Replace(")", "").Replace(" ", "");

            string[] splitParameter = new string[maxParameters];
            int[] startOfData = new int[maxParameters];
            List<int> sortedStartOfData = new List<int>();
            bool anyParameters = false;
            for (int i = 0; i < maxParameters; i++)
            {
                splitParameter[i] = "{" + i.ToString() + "}";
                startOfData[i] = cleanFormat.IndexOf(splitParameter[i]);
                if (startOfData[i] >= 0)
                    anyParameters = true;
                else
                    startOfData[i] = int.MaxValue;
                sortedStartOfData.Add(startOfData[i]);
            }
            if (anyParameters == false || index >= maxParameters || startOfData[index] == int.MaxValue)
                return string.Empty;
            sortedStartOfData.Sort();

                int start = 0;
                int end = 0;
            string[] splits = cleanFormat.Split(splitParameter, StringSplitOptions.None);

            string[] foundData = new string[maxParameters];
            for (int i = 0; i < maxParameters; i++)
                    {
                foundData[i] = string.Empty;
                if (splits.Length >= (2 + i))
                        {
                    start = end + splits[i].Length;
                    end = cleanAction.IndexOf(splits[i + 1], start);
                    if (end <= start || string.IsNullOrEmpty(splits[i + 1]))
                                end = cleanAction.Length;
                    foundData[i] = cleanAction.Substring(start, end - start);
                }
            }

            return foundData[sortedStartOfData.IndexOf(startOfData[index])];
        }

        private void AddConditionOrActionButton_Click(object sender, RoutedEventArgs e)
        {
            addConditionOrAction((Button)sender);
        }

        private ComboBox addConditionOrAction(Button addButton)
        {
            ScrollViewer scrollViewer = (ScrollViewer)addButton.Resources["ScrollViewer"];
            DisplayCategory displayCategory = (DisplayCategory)addButton.Resources["DisplayCategory"];
            List<ExpressionEntry> macroConditionsOrActions = (List<ExpressionEntry>)addButton.Resources["MacroConditionsOrActions"];
            Grid grid = (Grid)scrollViewer.Content;
            ResourceDictionary buttonStyle = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\ButtonStyle.xaml", UriKind.Relative));

            RowDefinition newlyAddedRow = new RowDefinition();
            grid.RowDefinitions.Add(newlyAddedRow);
            if (grid.RowDefinitions.Count > 1)
            {
                Label lblAnd = new Label() { Content = Translation.GetTranslatedMisc("ExpressionLogicalAnd") };
                lblAnd.SetValue(Grid.RowProperty, grid.RowDefinitions.Count - 2);
                lblAnd.SetValue(Grid.ColumnProperty, 3);
                lblAnd.Margin = new Thickness(3);
                grid.Children.Add(lblAnd);
            }

            ComboBox groupTypeComboBox = new ComboBox();
            List<ComboBoxItemContents> macroConditions = getAvailableGroupTypes(displayCategory);
            foreach (ComboBoxItemContents macroCondition in macroConditions)
            {
                groupTypeComboBox.Items.Add(macroCondition);
            }
            groupTypeComboBox.SelectionChanged += GroupTypeComboBox_SelectionChanged;
            groupTypeComboBox.SetValue(Grid.RowProperty, grid.RowDefinitions.Count - 1);
            groupTypeComboBox.SetValue(Grid.ColumnProperty, 0);
            groupTypeComboBox.Margin = new Thickness(3);
            groupTypeComboBox.MinWidth = 100;
            groupTypeComboBox.Height = 30;
            grid.Children.Add(groupTypeComboBox);

            Button unselectButton = new Button { Content = "..." };
            unselectButton.SetValue(Grid.RowProperty, grid.RowDefinitions.Count - 1);
            unselectButton.SetValue(Grid.ColumnProperty, 1);
            unselectButton.Width = 40;
            unselectButton.Height = 30;
            unselectButton.Margin = new Thickness(3);
            unselectButton.Visibility = Visibility.Collapsed;
            unselectButton.Click += UnselectButton_Click;
            unselectButton.Style = (Style)buttonStyle["ButtonStyle1"];
            grid.Children.Add(unselectButton);

            ComboBox groupEventsComboBox = new ComboBox();
            groupEventsComboBox.SetValue(Grid.RowProperty, grid.RowDefinitions.Count - 1);
            groupEventsComboBox.SetValue(Grid.ColumnProperty, 2);
            groupEventsComboBox.SelectionChanged += GroupEventsComboBox_SelectionChanged;
            groupEventsComboBox.Margin = new Thickness(3);
            groupEventsComboBox.MinWidth = 450;
            groupEventsComboBox.Height = 30;
            grid.Children.Add(groupEventsComboBox);

            TextBox groupEventTextBox = new TextBox();
            groupEventTextBox.SetValue(Grid.RowProperty, grid.RowDefinitions.Count - 1);
            groupEventTextBox.SetValue(Grid.ColumnProperty, 2);
            groupEventTextBox.Margin = new Thickness(3);
            groupEventTextBox.MinWidth = 450;
            groupEventTextBox.Height = 30;
            groupEventTextBox.Visibility = Visibility.Collapsed;
            groupEventTextBox.TextChanged += GroupEventTextBox_TextChanged;
            grid.Children.Add(groupEventTextBox);

            ExpressionEntry expressionEntry = new ExpressionEntry();
            macroConditionsOrActions.Add(expressionEntry);

            unselectButton.Resources["GroupEventsComboBox"] = groupEventsComboBox;
            unselectButton.Resources["ParentGrid"] = grid;
            unselectButton.Resources["ParametersGrid"] = null;
            groupEventsComboBox.Resources["UnselectButton"] = unselectButton;
            groupEventsComboBox.Resources["ExpressionEntry"] = expressionEntry;
            groupTypeComboBox.Resources["DisplayCategory"] = displayCategory;
            groupTypeComboBox.Resources["GroupEventsComboBox"] = groupEventsComboBox;
            groupTypeComboBox.Resources["GroupEventTextBox"] = groupEventTextBox;
            groupEventTextBox.Resources["ExpressionEntry"] = expressionEntry;

            Button deleteButton = new Button
            {
                Height = 30,
                Width = 60,
                Margin = new Thickness(3),
                Content = Translation.GetTranslatedMisc("Delete"),
                Style = (Style)buttonStyle["ButtonStyle1"]
            };

            //Delete Button action
            deleteButton.Click += DeleteConditionOrActionButton_Click;
            deleteButton.SetValue(Grid.RowProperty, grid.RowDefinitions.Count - 1);
            deleteButton.SetValue(Grid.ColumnProperty, 4);
            deleteButton.Resources["ScrollViewer"] = scrollViewer;
            deleteButton.Resources["ExpressionEntry"] = expressionEntry;
            grid.Children.Add(deleteButton);

            foreach (ColumnDefinition column in grid.ColumnDefinitions)
            {
                column.Width = GridLength.Auto;
            }
            grid.ColumnDefinitions[1].Width = new GridLength(60);
            grid.ColumnDefinitions[2].MinWidth = 460;
            grid.ColumnDefinitions[3].MinWidth = 50;

            foreach (RowDefinition row in grid.RowDefinitions)
            {
                row.Height = new GridLength(40);
            }

            return groupTypeComboBox;
        }

        private void DeleteConditionOrActionButton_Click(object sender, RoutedEventArgs e)
        {
            Button deleteButton = (Button)sender;
            ScrollViewer scrollViewer = (ScrollViewer)deleteButton.Resources["ScrollViewer"];
            ExpressionEntry expressionEntry = (ExpressionEntry)deleteButton.Resources["ExpressionEntry"];
            Grid grid = (Grid)scrollViewer.Content;

            macroConditions.Remove(expressionEntry);
            macroActions.Remove(expressionEntry);

            int rowToDelete = (int)deleteButton.GetValue(Grid.RowProperty);

            List<UIElement> elementsToDelete = new List<UIElement>();
            foreach (UIElement child in grid.Children)
            {
                int row = (int)child.GetValue(Grid.RowProperty);
                if (rowToDelete == row)
                {
                    elementsToDelete.Add(child);
                }
                else if (row > rowToDelete)
                {
                    child.SetValue(Grid.RowProperty, row - 1);
                }
            }

            grid.RowDefinitions.Remove(grid.RowDefinitions[grid.RowDefinitions.Count - 1]);

            // Remove the AND if required
            rowToDelete = grid.RowDefinitions.Count - 1;
            foreach (UIElement child in grid.Children)
            {
                int row = (int)child.GetValue(Grid.RowProperty);
                if (rowToDelete == row && (int)child.GetValue(Grid.ColumnProperty) == 3)
                {
                    elementsToDelete.Add(child);
                }
            }

            foreach (UIElement child in elementsToDelete)
            {
                grid.Children.Remove(child);
            }
            updateMacro();
        }

        private void GroupTypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox groupTypeComboBox = (ComboBox)sender;
            ComboBox groupEventsComboBox = (ComboBox)groupTypeComboBox.Resources["GroupEventsComboBox"];
            DisplayCategory displayCategory = (DisplayCategory)groupTypeComboBox.Resources["DisplayCategory"];

            groupEventsComboBox.Items.Clear();

            string groupType = (string)((ComboBoxItemContents)groupTypeComboBox.SelectedItem).Value;
            if (groupType == customMacro)
            {
                Button unselectButton = (Button)groupEventsComboBox.Resources["UnselectButton"];
                if (unselectButton.Visibility == Visibility.Visible)
                    UnselectButton_Click(unselectButton, new RoutedEventArgs());

                groupEventsComboBox.Visibility = Visibility.Collapsed;

                TextBox groupEventTextBox = (TextBox)groupTypeComboBox.Resources["GroupEventTextBox"];
                groupEventTextBox.Visibility = Visibility.Visible;
                if (string.IsNullOrEmpty(dataValue) == false)
                    groupEventTextBox.Text = dataValue;
                else
                    groupEventTextBox.Text = string.Empty;

                ExpressionEntry expressionEntry = (ExpressionEntry)groupEventTextBox.Resources["ExpressionEntry"];
                expressionEntry.Format = groupEventTextBox.Text;
                expressionEntry.Data = null;
                expressionEntry.ExtraData = null;
            }
            else
            {
                TextBox groupEventTextBox = (TextBox)groupTypeComboBox.Resources["GroupEventTextBox"];
                groupEventTextBox.Visibility = Visibility.Collapsed;
                groupEventsComboBox.Visibility = Visibility.Visible;

                List<ComboBoxItemContents> groupEvents = getAvailableGroupEvents(groupType, displayCategory);

                foreach (ComboBoxItemContents groupEvent in groupEvents)
                {
                    groupEventsComboBox.Items.Add(groupEvent);
                }

                Button unselectButton = (Button)groupEventsComboBox.Resources["UnselectButton"];
                if (unselectButton.Visibility == Visibility.Visible)
                    UnselectButton_Click(unselectButton, new RoutedEventArgs());

                ExpressionEntry expressionEntry = (ExpressionEntry)groupEventsComboBox.Resources["ExpressionEntry"];
                expressionEntry.Format = null;
                expressionEntry.Data = null;
                expressionEntry.ExtraData = null;
            }
            updateMacro();
        }

        private void GroupEventTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox groupEventTextBox = (TextBox)sender;
            ExpressionEntry expressionEntry = (ExpressionEntry)groupEventTextBox.Resources["ExpressionEntry"];
            expressionEntry.Format = groupEventTextBox.Text;
            updateMacro();
        }

        private void GroupEventsComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox groupEventsComboBox = (ComboBox)sender;
            if (groupEventsComboBox.SelectedItem == null)
                return;

            Button unselectButton = (Button)groupEventsComboBox.Resources["UnselectButton"];
            ExpressionEntry expressionEntry = (ExpressionEntry)groupEventsComboBox.Resources["ExpressionEntry"];
            Grid parentGrid = (Grid)unselectButton.Resources["ParentGrid"];

            unselectButton.Visibility = Visibility.Visible;
            groupEventsComboBox.Visibility = Visibility.Collapsed;

            Grid parametersGrid = new Grid();
            parametersGrid.RowDefinitions.Add(new RowDefinition());
            parametersGrid.ColumnDefinitions.Add(new ColumnDefinition());

            ComboBoxItemContents selectedItem = (ComboBoxItemContents)groupEventsComboBox.SelectedItem;
            ExpressionState expressionState = (ExpressionState)selectedItem.Value;

            expressionEntry.Format = expressionState.Format;
            expressionEntry.Data = null;
            expressionEntry.ExtraData = null;

            int variable0Position = expressionState.Text.IndexOf("{0}", StringComparison.Ordinal);
            int variable1Position = expressionState.Text.IndexOf("{1}", StringComparison.Ordinal);
            int variable2Position = expressionState.Text.IndexOf("{2}", StringComparison.Ordinal);
            string[] sections = expressionState.Text.Split(new[] { "{0}", "{1}", "{2}" }, StringSplitOptions.None);

            Label label = new Label() { Content = sections[0] };
            label.Margin = new Thickness(3);
            parametersGrid.Children.Add(label);
            parametersGrid.ColumnDefinitions[parametersGrid.ColumnDefinitions.Count - 1].Width = GridLength.Auto;

            int offset = 0;
            if (variable0Position > 0)
            {
                addParameterToExpression(parametersGrid, expressionState.DataType, expressionEntry, 0);

                if (sections.Length > 1)
                {
                    parametersGrid.ColumnDefinitions.Add(new ColumnDefinition());
                    parametersGrid.ColumnDefinitions[parametersGrid.ColumnDefinitions.Count - 1].Width = GridLength.Auto;

                    label = new Label() { Content = sections[1] };
                    label.Margin = new Thickness(3);
                    label.SetValue(Grid.ColumnProperty, parametersGrid.ColumnDefinitions.Count - 1);
                    parametersGrid.Children.Add(label);
                }
                offset++;
            }

            if (variable1Position > 0)
            {
                addParameterToExpression(parametersGrid, expressionState.ExtraDataType, expressionEntry, 1);
                if (sections.Length > (1 + offset))
                {
                    parametersGrid.ColumnDefinitions.Add(new ColumnDefinition());
                    parametersGrid.ColumnDefinitions[parametersGrid.ColumnDefinitions.Count - 1].Width = GridLength.Auto;

                    label = new Label() { Content = sections[(1 + offset)] };
                    label.Margin = new Thickness(3);
                    label.SetValue(Grid.ColumnProperty, parametersGrid.ColumnDefinitions.Count - 1);
                    parametersGrid.Children.Add(label);
                }
                offset++;
            }

            if (variable2Position > 0)
            {
                addParameterToExpression(parametersGrid, expressionState.DataType3, expressionEntry, 2);
                if (sections.Length > (1 + offset))
                {
                    parametersGrid.ColumnDefinitions.Add(new ColumnDefinition());
                    parametersGrid.ColumnDefinitions[parametersGrid.ColumnDefinitions.Count - 1].Width = GridLength.Auto;

                    label = new Label() { Content = sections[(1 + offset)] };
                    label.Margin = new Thickness(3);
                    label.SetValue(Grid.ColumnProperty, parametersGrid.ColumnDefinitions.Count - 1);
                    parametersGrid.Children.Add(label);
                }
                offset++;
            }

            unselectButton.Resources["ParametersGrid"] = parametersGrid;
            parametersGrid.SetValue(Grid.ColumnProperty, 2);
            parametersGrid.SetValue(Grid.RowProperty, unselectButton.GetValue(Grid.RowProperty));
            parentGrid.Children.Add(parametersGrid);

            updateMacro();
        }

        private List<ComboBoxItemContents> createListboxItems(int start, int end)
        {
            List<ComboBoxItemContents> items = new List<ComboBoxItemContents>();
            for (int i = start; i <= end; i++)
            {
                items.Add(new ComboBoxItemContents(i.ToString(), i));
            }
            return items;
        }

        private void addParameterToExpression(Grid parametersGrid, string dataType, ExpressionEntry expressionEntry, int dataIndex)
        {
            parametersGrid.ColumnDefinitions.Add(new ColumnDefinition());

            ComboBox comboBox = new ComboBox();
            IntegerUpDown integerUpDown = new IntegerUpDown();
            List<ComboBoxItemContents> comboBoxContents = null;
            TimeSpanUpDown timeSpanUpDown = new TimeSpanUpDown();
            TextBox textBox = new TextBox();
            bool integer = false;
            bool timeSpan = false;
            bool text = false;

            switch (dataType.ToUpper())
            {
                case "CONTROLLER":
                case "NUMBER":
                case "STATUS":      // Variable value
                case "USERTYPE":
                    integer = true;
                    break;
                case "AREA":
                    comboBoxContents = ControllerConfigurationManager.GetAvailableAreas(true);
                    break;
                case "INPUT":
                    comboBoxContents = ControllerConfigurationManager.GetAllInputs();
                    break;
                case "KEYPAD":
                    comboBoxContents = ControllerConfigurationManager.GetAllKeypads();
                    break;
                case "OUTPUT":
                    comboBoxContents = ControllerConfigurationManager.GetAllOutputs();
                    break;
                case "ELEVATOR":
                    comboBoxContents = ControllerConfigurationManager.GetAllElevatorFloors();
                    break;
                case "READER":
                    comboBoxContents = ControllerConfigurationManager.GetAllReaders();
                    break;
                case "READERMODE":
                    comboBoxContents = ControllerConfigurationManager.GetAvailableReaderModes();
                    break;
                case "READERSTATE":
                    comboBoxContents = ControllerConfigurationManager.GetAvailableReaderStates();
                    break;
                case "READERDETECTS":
                    comboBoxContents = ControllerConfigurationManager.GetAvailableCardStatus();
                    break;
                case "READERCATEGORY":
                    comboBoxContents = ControllerConfigurationManager.GetAvailableReaderCategory();
                    break;
                case "DAYOFWEEK":
                    comboBoxContents = ControllerConfigurationManager.GetAvailableDaysOfWeek();
                    break;
                case "GROUP":
                    comboBoxContents = ControllerConfigurationManager.GetAvailableUserGroups();
                    break;
                case "USER":
                    comboBoxContents = ControllerConfigurationManager.GetAvailableUsers();
                    break;
                case "TIMER":
                case "VARIABLE":
                    comboBoxContents = createListboxItems(1, 256);
                    break;
                case "DAYOFMONTH":
                    comboBoxContents = createListboxItems(1, 31);
                    break;
                case "MONTH":
                    comboBoxContents = createListboxItems(1, 12);
                    break;
                case "SECONDS":
                case "TIME":
                    timeSpan = true;
                    break;
                case "PHONENUMBER":
                case "YEAR":
                    text = true;
                    break;
                case "DOOR":
                    comboBoxContents = ControllerConfigurationManager.GetAllDoors();
                    break;
                case "DOORACCESSDENIEDREASON":
                    comboBoxContents = ControllerConfigurationManager.GetAvailableAccessDeniedReasons();
                    break;
                case "INTERLOCK":
                    comboBoxContents = ControllerConfigurationManager.GetInterlockGroups();
                    break;
            }

            string displayValue = null;
            if (dataIndex == 0)
            {
                displayValue = dataValue;
                expressionEntry.Data = displayValue;
            }
            else if (dataIndex == 1)
            {
                displayValue = extraDataValue;
                expressionEntry.ExtraData = displayValue;
            }
            else if (dataIndex == 2)
            {
                displayValue = data3Value;
                expressionEntry.Data3 = displayValue;
            }

            if (displayValue == string.Empty)
                displayValue = null;

            if (comboBoxContents != null)
            {
                comboBox.MaxDropDownHeight = 200;
                comboBox.Height = 30;
                comboBox.Padding = new Thickness(7, 5, 0, 0);
                comboBox.Width = 300;
                comboBox.SetValue(Grid.ColumnProperty, parametersGrid.ColumnDefinitions.Count - 1);
                comboBox.Margin = new Thickness(5);
                comboBox.SelectionChanged += ComboBox_SelectionChanged;
                comboBox.Resources["ExpressionEntry"] = expressionEntry;
                comboBox.Resources["DataIndex"] = dataIndex;
                parametersGrid.Children.Add(comboBox);

                bool comboBoxItemFound = false;
                foreach (ComboBoxItemContents comboBoxItem in comboBoxContents)
                {
                    int insertedIndex = comboBox.Items.Add(comboBoxItem);
                    if (displayValue != null && comboBoxItem.Value.ToString() == displayValue)
                    {
                        comboBox.SelectedIndex = insertedIndex;
                        comboBoxItemFound = true;
                    }
                }
                if (displayValue != null && comboBoxItemFound == false)
                {
                    ComboBoxItemContents comboBoxItem = new ComboBoxItemContents(displayValue + " - " + Translation.GetTranslatedMisc("ExpressionNotFound"), displayValue);
                    int insertedIndex = comboBox.Items.Add(comboBoxItem);
                    comboBox.SelectedIndex = insertedIndex;
                }
                return;
            }
            else if (integer)
            {
                integerUpDown.Height = 30;
                integerUpDown.Padding = new Thickness(0, 0, 5, 0);
                integerUpDown.TextAlignment = TextAlignment.Left;
                integerUpDown.SetValue(Grid.ColumnProperty, parametersGrid.ColumnDefinitions.Count - 1);
                integerUpDown.Margin = new Thickness(5);
                integerUpDown.ValueChanged += IntegerUpDown_ValueChanged;
                integerUpDown.Resources["ExpressionEntry"] = expressionEntry;
                integerUpDown.Resources["DataIndex"] = dataIndex;
                if (displayValue != null)
                    integerUpDown.Text = displayValue;
                parametersGrid.Children.Add(integerUpDown);
                return;
            }
            else if(text)
            {
                textBox.Height = 30;
                textBox.Padding = new Thickness(7, 5, 0, 0);
                textBox.TextAlignment = TextAlignment.Left;
                textBox.SetValue(Grid.ColumnProperty, parametersGrid.ColumnDefinitions.Count - 1);
                textBox.Margin = new Thickness(5);
                textBox.TextChanged += TextBox_TextChanged;
                textBox.Resources["ExpressionEntry"] = expressionEntry;
                textBox.Resources["DataIndex"] = dataIndex;
                if (displayValue != null)
                    textBox.Text = displayValue;
                parametersGrid.Children.Add(textBox);
            }
            else if (timeSpan)
            {
                timeSpanUpDown.Minimum = TimeSpan.Zero;
                timeSpanUpDown.Maximum = TimeSpan.FromDays(1);
                timeSpanUpDown.Height = 30;
                timeSpanUpDown.Padding = new Thickness(0, 0, 5, 0);
                timeSpanUpDown.DisplayDefaultValueOnEmptyText = true;
                timeSpanUpDown.TextAlignment = TextAlignment.Left;
                timeSpanUpDown.SetValue(Grid.ColumnProperty, parametersGrid.ColumnDefinitions.Count - 1);
                timeSpanUpDown.Margin = new Thickness(5);
                timeSpanUpDown.ValueChanged += TimeSpanUpDown_ValueChanged;
                timeSpanUpDown.Resources["ExpressionEntry"] = expressionEntry;
                timeSpanUpDown.Resources["DataIndex"] = dataIndex;
                timeSpanUpDown.Resources["DataType"] = dataType;

                if (dataType == "Seconds")
                {
                    if (displayValue == null)
                    {
                        displayValue = "30";
                        if (dataIndex == 0)
                            dataValue = displayValue;
                        else if (dataIndex == 1)
                            extraDataValue = displayValue;
                        else if (dataIndex == 2)
                            data3Value = displayValue;
                    }

                    int seconds = int.Parse(displayValue);
                    TimeSpan value = new TimeSpan(0, 0, seconds);
                    timeSpanUpDown.Text = value.ToString("hh\\:mm\\:ss");
                }
                else if (dataType == "Time")
                {
                    if (displayValue == null)
                    {
                        displayValue = "12:00";
                        if (dataIndex == 0)
                            dataValue = displayValue;
                        else if (dataIndex == 1)
                            extraDataValue = displayValue;
                        else if (dataIndex == 2)
                            data3Value = displayValue;
                    }

                    timeSpanUpDown.Text = displayValue + ":00";
                }
                parametersGrid.Children.Add(timeSpanUpDown);
                return;
            }
        }

        private void TimeSpanUpDown_ValueChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            TimeSpanUpDown timeSpanUpDown = (TimeSpanUpDown)sender;
            ExpressionEntry expressionEntry = (ExpressionEntry)timeSpanUpDown.Resources["ExpressionEntry"];
            int dataIndex = (int)timeSpanUpDown.Resources["DataIndex"];

            string dataType = (string)timeSpanUpDown.Resources["DataType"];

            if (dataType == "Seconds")
            {
                if (dataIndex == 0)
                    expressionEntry.Data = timeSpanUpDown.Value.Value.TotalSeconds.ToString();
                else if (dataIndex == 1)
                    expressionEntry.ExtraData = timeSpanUpDown.Value.Value.TotalSeconds.ToString();
                else if (dataIndex == 2)
                    expressionEntry.Data3 = timeSpanUpDown.Value.Value.TotalSeconds.ToString();
            }
            else if (dataType == "Time")
            {
                if (dataIndex == 0)
                    expressionEntry.Data = timeSpanUpDown.Value.Value.ToString("hh\\:mm");
                else if (dataIndex == 1)
                    expressionEntry.ExtraData = timeSpanUpDown.Value.Value.ToString("hh\\:mm");
                else if (dataIndex == 2)
                    expressionEntry.Data3 = timeSpanUpDown.Value.Value.ToString("hh\\:mm");
            }

            updateMacro();
        }

        private void IntegerUpDown_ValueChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            IntegerUpDown integerUpDown = (IntegerUpDown)sender;
            ExpressionEntry expressionEntry = (ExpressionEntry)integerUpDown.Resources["ExpressionEntry"];
            int dataIndex = (int)integerUpDown.Resources["DataIndex"];

            if (dataIndex == 0)
                expressionEntry.Data = integerUpDown.Value.Value.ToString();
            else if (dataIndex == 1)
                expressionEntry.ExtraData = integerUpDown.Value.Value.ToString();
            else if (dataIndex == 2)
                expressionEntry.Data3 = integerUpDown.Value.Value.ToString();

            updateMacro();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            ExpressionEntry expressionEntry = (ExpressionEntry)textBox.Resources["ExpressionEntry"];
            int dataIndex = (int)textBox.Resources["DataIndex"];

            if (dataIndex == 0)
                expressionEntry.Data = textBox.Text.ToString();
            else if (dataIndex == 1)
                expressionEntry.ExtraData = textBox.Text.ToString();
            else if (dataIndex == 2)
                expressionEntry.Data3 = textBox.Text.ToString();

            updateMacro();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox comboBox = (ComboBox)sender;
            ExpressionEntry expressionEntry = (ExpressionEntry)comboBox.Resources["ExpressionEntry"];
            int dataIndex = (int)comboBox.Resources["DataIndex"];

            if (comboBox.SelectedItem != null)
            {
                ComboBoxItemContents selectedItem = (ComboBoxItemContents)comboBox.SelectedItem;
                if (dataIndex == 0)
                    expressionEntry.Data = selectedItem.Value.ToString();
                else if (dataIndex == 1)
                    expressionEntry.ExtraData = selectedItem.Value.ToString();
                else if (dataIndex == 2)
                    expressionEntry.Data3 = selectedItem.Value.ToString();

                updateMacro();
            }
        }

        private void UnselectButton_Click(object sender, RoutedEventArgs e)
        {
            Button unselectButton = (Button)sender;
            ComboBox groupEventsComboBox = (ComboBox)unselectButton.Resources["GroupEventsComboBox"];
            Grid parentGrid = (Grid)unselectButton.Resources["ParentGrid"];
            Grid parametersGrid = unselectButton.Resources["ParametersGrid"] as Grid;

            ExpressionEntry expressionEntry = (ExpressionEntry)groupEventsComboBox.Resources["ExpressionEntry"];
            expressionEntry.Format = null;
            expressionEntry.Data = null;
            expressionEntry.ExtraData = null;

            if (parametersGrid != null)
                parentGrid.Children.Remove(parametersGrid);

            unselectButton.Visibility = Visibility.Collapsed;
            groupEventsComboBox.Visibility = Visibility.Visible;
            updateMacro();
        }

        private void updateMacro()
        {
            // if we are still loading the page, don't update or we will override subsequent conditions or actions.
            if (loading)
                return;

            App.ConfigurationModified = true;
            List<string> conditions = new List<string>();
            foreach (ExpressionEntry expressionEntry in macroConditions)
            {
                if (expressionEntry.Format == null)
                    continue;

                bool containsData = expressionEntry.Format.Contains("{0}");
                bool containsExtraData = expressionEntry.Format.Contains("{1}");
                bool containsData3 = expressionEntry.Format.Contains("{2}");

                if ((containsData && expressionEntry.Data == null) ||
                    (containsExtraData && expressionEntry.ExtraData == null) ||
                    (containsData3 && expressionEntry.Data3 == null))
                    continue;

                string result = expressionEntry.Format;
                result = string.Format(result, expressionEntry.Data, expressionEntry.ExtraData, expressionEntry.Data3);
                conditions.Add(result);
            }

            List <string> actions = new List<string>();
            foreach (ExpressionEntry expressionEntry in macroActions)
            {
                if (expressionEntry.Format == null)
                    continue;

                bool containsData = expressionEntry.Format.Contains("{0}");
                bool containsExtraData = expressionEntry.Format.Contains("{1}");
                bool containsData3 = expressionEntry.Format.Contains("{2}");

                if ((containsData && expressionEntry.Data == null) ||
                    (containsExtraData && expressionEntry.ExtraData == null) ||
                    (containsData3 && expressionEntry.Data3 == null))
                    continue;

                string result = expressionEntry.Format;
                result = string.Format(result, expressionEntry.Data, expressionEntry.ExtraData, expressionEntry.Data3);
                actions.Add(result);
            }

            configurationItem.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;
            configurationItem.Conditions = conditions.ToArray();
            configurationItem.Actions = actions.ToArray();
        }

        protected override ControllerAttribute updateControllerAttribute(PropertyInfo propertyInfo, ControllerAttribute controllerAttribute)
        {
            if (controllerAttribute == null)
                return new ControllerAttribute(DisplayCategory.Hidden);
            else if (propertyInfo.Name == "ParentDeviceId")
                return new ControllerAttribute(DisplayCategory.Hidden);

            return base.updateControllerAttribute(propertyInfo, controllerAttribute);
        }

        protected override void addAdditionalElements(SortedDictionary<DisplayCategory, List<PropertyInfo>> categorisedProperties)
        {
            categorisedProperties[DisplayCategory.Conditions] = new List<PropertyInfo>();
            categorisedProperties[DisplayCategory.Actions] = new List<PropertyInfo>();
        }

        static Dictionary<string, ExpressionCategory> availableConditions;
        static Dictionary<string, ExpressionCategory> availableActions;
        static string lastLanguage = "";

        private static List<ComboBoxItemContents> getAvailableGroupTypes(DisplayCategory displayCategory)
        {
            List<ComboBoxItemContents> groupTypes = new List<ComboBoxItemContents>();

            Dictionary<string, ExpressionCategory> conditionsOrActions;
            if (displayCategory == DisplayCategory.Conditions)
                conditionsOrActions = availableConditions;
            else
                conditionsOrActions = availableActions;

            foreach (KeyValuePair<string, ExpressionCategory> conditionsOrAction in conditionsOrActions)
            {
                groupTypes.Add(new ComboBoxItemContents(conditionsOrAction.Value.Text, conditionsOrAction.Key));
            }
            groupTypes.Add(new ComboBoxItemContents(Translation.GetTranslatedMisc(customMacro), customMacro));
            return groupTypes;
        }

        private static List<ComboBoxItemContents> getAvailableGroupEvents(string groupType, DisplayCategory displayCategory)
        {
            List<ComboBoxItemContents> groupEvents = new List<ComboBoxItemContents>();

            Dictionary<string, ExpressionCategory> conditionsOrActions;
            if (displayCategory == DisplayCategory.Conditions)
                conditionsOrActions = availableConditions;
            else
                conditionsOrActions = availableActions;

            foreach (ExpressionState expressionState in conditionsOrActions[groupType].States)
            {
                string dataType = Translation.GetTranslatedMacroDataTypeString(expressionState.DataType);
                string extraDataType = Translation.GetTranslatedMacroDataTypeString(expressionState.ExtraDataType);
                string Data3Type = Translation.GetTranslatedMacroDataTypeString(expressionState.DataType3);
                string translatedText = string.Format(expressionState.Text, dataType, extraDataType, Data3Type);

                groupEvents.Add(new ComboBoxItemContents(translatedText, expressionState));
            }
            groupEvents = groupEvents.OrderBy(i => i.DisplayName).ToList();

            return groupEvents;
        }

        private static void getMacroData()
        {
            if (availableConditions != null && availableActions != null && lastLanguage == Translation.CurrentLanguage.Code)
                return;

            lastLanguage = Translation.CurrentLanguage.Code;
            XDocument macroData = null;
            string readData;
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Pacom.ConfigurationEditor.WPF.EmbeddedResources.Expressions.txt"))
            {
                using (StreamReader streamReader = new StreamReader(stream))
                {
                    readData = streamReader.ReadToEnd();
                }
            }
            readData = readData.Replace("''", "'");
            macroData = XDocument.Parse(readData, LoadOptions.None);

            availableConditions = macroData.Descendants("Trigger")
                .ToDictionary(t => t.Attribute("Type").Value,
                    t =>
                        new ExpressionCategory(t.Attribute("Type").Value,
                            t.Attribute("Text").Value,
                            t.Elements("State")
                                .Select(
                                    s =>
                                        new ExpressionState(
                                            s.Attribute("Id") != null ? s.Attribute("Id").Value : "",
                                            s.Attribute("Text") != null ? s.Attribute("Text").Value : "",
                                            s.Attribute("Data") != null ? s.Attribute("Data").Value : "",
                                            s.Attribute("DataType") != null ? s.Attribute("DataType").Value : "",
                                            s.Attribute("ExtraData") != null ? s.Attribute("ExtraData").Value : "",
                                            s.Attribute("DataType3") != null ? s.Attribute("DataType3").Value : "",
                                            s.Attribute("Format") != null ? s.Attribute("Format").Value : ""))
                                .ToList()));

            // Localise Text
            foreach (KeyValuePair<string, ExpressionCategory> trigger in availableConditions)
            {
                trigger.Value.Text = Translation.GetTranslatedMacroString(trigger.Key);
                foreach (ExpressionState state in trigger.Value.States)
                {
                    state.Text = Translation.GetTranslatedMacroString(state.Id);
                }
            }

            availableActions = macroData.Descendants("Action")
                .ToDictionary(t => t.Attribute("Type").Value,
                    t =>
                        new ExpressionCategory(t.Attribute("Type").Value,
                        t.Attribute("Text").Value,
                            t.Elements("State")
                                .Select(
                                    s =>
                                        new ExpressionState(
                                            s.Attribute("Id") != null ? s.Attribute("Id").Value : "",
                                            s.Attribute("Text") != null ? s.Attribute("Text").Value : "",
                                            s.Attribute("Data") != null ? s.Attribute("Data").Value : "",
                                            s.Attribute("DataType") != null ? s.Attribute("DataType").Value : "",
                                            s.Attribute("ExtraData") != null ? s.Attribute("ExtraData").Value : "",
                                            s.Attribute("DataType3") != null ? s.Attribute("DataType3").Value : "",
                                            s.Attribute("Format") != null ? s.Attribute("Format").Value : ""))
                                .ToList()));

            // Localise Text
            foreach (KeyValuePair<string, ExpressionCategory> action in availableActions)
            {
                action.Value.Text = Translation.GetTranslatedMacroString(action.Key);
                foreach (ExpressionState state in action.Value.States)
                {
                    state.Text = Translation.GetTranslatedMacroString(state.Id);
                }
            }
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.Macros.Remove(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }
    }
}
