﻿using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.ConfigurationEditor.WPF.UserControls;
using Pacom.Core.Access;
using Pacom.Core.Attributes;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class UnisonUserView : ConfigurationViewBase<User>
    {
        public UnisonUserView(User user, NodeTreeElement nodeTreeElement) : base(user, nodeTreeElement)
        {
            createDefaultView(true);

            categoryGrids[DisplayCategory.UserPermissions].RowDefinitions.Add(new RowDefinition());
            UnisonUserPermissionControl unisonUserPermissionControl = new UnisonUserPermissionControl(user);
            unisonUserPermissionControl.SetValue(Grid.RowProperty, 1);
            unisonUserPermissionControl.SetValue(Grid.ColumnProperty, 0);
            unisonUserPermissionControl.SetValue(Grid.ColumnSpanProperty, 2);
            categoryGrids[DisplayCategory.UserPermissions].Children.Add(unisonUserPermissionControl);
        }

        protected override void addAdditionalElements(SortedDictionary<DisplayCategory, List<PropertyInfo>> categorisedProperties)
        {
            categorisedProperties[DisplayCategory.UserPermissions] = new List<PropertyInfo>();
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.UnisonUsers.Remove(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }
    }
}
