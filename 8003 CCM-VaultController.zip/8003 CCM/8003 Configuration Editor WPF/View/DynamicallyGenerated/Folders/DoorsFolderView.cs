﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class DoorsFolderView : FolderViewBase
    {
        public DoorsFolderView(NodeTreeElement nodeTreeElement) : base(nodeTreeElement)
        {
        }

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> types = new SortedDictionary<string, Type>();
            Type type = typeof(Door8003Configuration);
            types[Translation.GetTranslatedString(type)] = type;
            return types;
        }
    }
}
