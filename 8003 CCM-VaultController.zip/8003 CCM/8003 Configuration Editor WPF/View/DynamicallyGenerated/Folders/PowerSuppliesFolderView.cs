﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Xceed.Wpf.Toolkit;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class PowerSuppliesFolderView : FolderViewBase
    {
        public PowerSuppliesFolderView(NodeTreeElement nodeTreeElement) : base(nodeTreeElement)
        {
        }

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> peripheralTypes = new SortedDictionary<string, Type>();
            Type[] typelist = Assembly.GetAssembly(typeof(DeviceLoopDeviceConfigurationBase)).GetTypes();
            foreach (Type type in typelist)
            {
                if (type.BaseType == typeof(DeviceLoopDeviceConfigurationBase))
                {
                    if (type == typeof(Device8303PowerSupplyConfiguration) ||
                        type == typeof(Device8308PowerSupplyConfiguration))
                        peripheralTypes[Translation.GetTranslatedString(type)] = type;
                }
            }
            return peripheralTypes;
        }
    }
}
