﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Xceed.Wpf.Toolkit;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class ExpansionCardsFolderView : FolderViewBase
    {
        public ExpansionCardsFolderView(NodeTreeElement nodeTreeElement) : base(nodeTreeElement)
        {
        }

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> expansionCardTypes = new SortedDictionary<string, Type>();
            Type[] typelist = Assembly.GetAssembly(typeof(ExpansionCardDeviceConfigurationBase)).GetTypes();
            foreach (Type type in typelist)
            {
                if (type.BaseType == typeof(ExpansionCardDeviceConfigurationBase))
                {
                    expansionCardTypes[Translation.GetTranslatedString(type)] = type;
                }
            }
            return expansionCardTypes;
        }
    }
}
