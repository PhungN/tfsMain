﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Xceed.Wpf.Toolkit;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class InovonicsReceiverFolderView : FolderViewBase
    {
        public InovonicsReceiverFolderView(DeviceConfigurationBase device, NodeTreeElement nodeTreeElement) : base(nodeTreeElement, null, device)
        {
            createDefaultView(true);
        }

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> inovonicsDeviceTypes = new SortedDictionary<string, Type>();
            Type[] typelist = Assembly.GetAssembly(typeof(InovonicsDeviceConfigurationBase)).GetTypes();
            foreach (Type type in typelist)
            {
                if (type.BaseType == typeof(InovonicsDeviceConfigurationBase) &&
                    type != typeof(InovonicsReceiverDeviceConfiguration))
                {
                    inovonicsDeviceTypes[Translation.GetTranslatedString(type)] = type;
                }
            }
            return inovonicsDeviceTypes;
        }

        protected override ControllerAttribute updateControllerAttribute(PropertyInfo propertyInfo, ControllerAttribute controllerAttribute)
        {
            if (propertyInfo.Name == "ParentDeviceId" &&
                configurationItem.GetType() == typeof(InovonicsReceiverDeviceConfiguration))
                return new ControllerAttribute(DisplayCategory.Hidden);

            if (propertyInfo.Name == "DeviceLoopAddress" &&
                (configurationItem.GetType() == typeof(InovonicsReceiverDeviceConfiguration)))
                return new ControllerAttribute(DisplayCategory.Hidden);

            if (propertyInfo.Name == "DeviceType" &&
                configurationItem.GetType() == typeof(InovonicsReceiverDeviceConfiguration))
                return new ControllerAttribute(DisplayCategory.Hidden);

            return base.updateControllerAttribute(propertyInfo, controllerAttribute);
        }

        protected override void addAdditionalElements(SortedDictionary<DisplayCategory, List<PropertyInfo>> categorisedProperties)
        {
            // Add a protocol dropdown if this is an RS485 type port
            if (configurationItem.GetType() == typeof(InovonicsReceiverDeviceConfiguration))
            {
                InovonicsSerialNumberPropertyInfo propertyInfo = new InovonicsSerialNumberPropertyInfo();
                propertyInfo.SerialNumberChanged += PropertyInfo_SerialNumberChanged;
                categorisedProperties[DisplayCategory.Identification].Add(propertyInfo);
                return;
            }
        }

        private void PropertyInfo_SerialNumberChanged(object sender, InovonicsSerialNumberEventArgs e)
        {
            InovonicsDeviceConfigurationBase inovonicsDevice = configurationItem as InovonicsDeviceConfigurationBase;
            inovonicsDevice.DeviceLoopAddress = e.NewSerialNumber;
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            List<int> deviceIdsToRemove = new List<int>();
            foreach (KeyValuePair<int, DeviceConfigurationBase> device in ConfigurationManager.Devices)
            {
                if (device.Value is InovonicsDeviceConfigurationBase)
                {
                    deviceIdsToRemove.Add(device.Key);
                }
            }
            foreach (int deviceIdToRemove in deviceIdsToRemove)
            {
                ConfigurationManager.RemoveDevice(deviceIdToRemove);
            }
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }

        protected override void postSetValue(FrameworkElement frameworkElement, PropertyInfo property, object newValue)
        {
            if (property.Name == "Enabled")
            {
                foreach (KeyValuePair<int, DeviceConfigurationBase> device in ConfigurationManager.Devices)
                {
                    if (device.Value is InovonicsDeviceConfigurationBase)
                    {
                        device.Value.Enabled = (bool)newValue;
                    }
                }
            }
        }
    }
}
