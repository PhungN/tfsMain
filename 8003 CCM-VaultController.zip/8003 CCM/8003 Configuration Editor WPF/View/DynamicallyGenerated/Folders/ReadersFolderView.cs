﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Xceed.Wpf.Toolkit;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class ReadersFolderView : FolderViewBase
    {
        public ReadersFolderView(NodeTreeElement nodeTreeElement) : base(nodeTreeElement, new DisplayCategory[] { DisplayCategory.Readers })
        {


        }

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> types = new SortedDictionary<string, Type>();
            switch(ConfigurationManager.ConfigurationType)
            {
                case ConfigurationType.Gms:
                    types["Reader"] = typeof(Reader8003LegacyWiegandConfiguration);
                    break;
                case ConfigurationType.Unison:
                    types["Reader"] = typeof(Reader8003Configuration);
                    break;
                default:
                    types["GmsReader"] = typeof(Reader8003LegacyWiegandConfiguration);
                    types["UnisonReader"] = typeof(Reader8003Configuration);
                    break;
            }

            return types;
        }
    }
}
