﻿using System;
using System.Collections.Generic;
using System.Windows;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Core.Contracts;
using System.Windows.Controls;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class ElevatorsFolderView : FolderViewBase
    {
        public ElevatorsFolderView(NodeTreeElement nodeTreeElement) : base(nodeTreeElement)
        {
        }

        //protected override SortedDictionary<string, Type> typesToAdd()
        //{
        //    SortedDictionary<string, Type> types = new SortedDictionary<string, Type>();
        //    Type type = typeof(Elevator8003Configuration);
        //    types[Translation.GetTranslatedString(type)] = type;
        //    return types;
        //}

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> types = new SortedDictionary<string, Type>();
            switch (ConfigurationManager.ConfigurationType)
            {
                case ConfigurationType.Gms:
                    types["Elevator"] = typeof(LegacyElevator8003Configuration);
                    break;
                case ConfigurationType.Unison:
                    types["Elevator"] = typeof(Elevator8003Configuration);
                    break;
                default:
                    types["GmsElevator"] = typeof(LegacyElevator8003Configuration);
                    types["UnisonElevator"] = typeof(Elevator8003Configuration);
                    break;
            }

            return types;
        }

        protected override void AddButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            NodeConfiguration configuration = null;
            if(typeEntries.Count == 1)
            {
                configuration = (NodeConfiguration)Activator.CreateInstance(typeEntries["Elevator"]);
            }
            else if(typeEntries.Count == 2)
            {
                Button button = sender as Button;
                if(((string)button.Content).ToUpper().Contains("GMS") == true)
                    configuration = (NodeConfiguration)Activator.CreateInstance(typeEntries["GmsElevator"]);
                else
                    configuration = (NodeConfiguration)Activator.CreateInstance(typeEntries["UnisonElevator"]);
            }
            if(configuration != null)
            {
                ConfigurationManager.AutoConfigure(configuration);
                configuration.Name = Translation.GetTranslatedString(configuration.GetType()) + "-" + configuration.Id.ToString();
                NodeTreeView.LoadTree();
                NodeTreeView.SetSelection(configuration);
            }
            
        }
    }
}
