﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Xceed.Wpf.Toolkit;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class InovonicsFolderView : FolderViewBase
    {
        public InovonicsFolderView(NodeTreeElement nodeTreeElement) : base(nodeTreeElement)
        {
        }

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> inovonicsDeviceTypes = new SortedDictionary<string, Type>();
            Type type = typeof(InovonicsReceiverDeviceConfiguration);
            inovonicsDeviceTypes[Translation.GetTranslatedString(type)] = type;
            return inovonicsDeviceTypes;
        }
    }
}
