﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class VaultControllerFolderView : FolderViewBase
    {
        public VaultControllerFolderView(NodeTreeElement nodeTreeElement) : base(nodeTreeElement)
        {

        }

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> types = new SortedDictionary<string, Type>();
            //Type type = typeof(VaultController8003Configuration);
            Type type = typeof(Device8003Configuration);
            types[Translation.GetTranslatedString(type)] = type;
            return types;
        }
    }
}
