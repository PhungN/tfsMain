﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Xceed.Wpf.Toolkit;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class FolderViewBase : ConfigurationViewBase<ConfigurationBase>
    {
        public FolderViewBase(NodeTreeElement nodeTreeElement, DisplayCategory[] displayCategoriesToShow = null, ConfigurationBase configurationItem = null) : base(ConfigurationManager.ControllerConfiguration, nodeTreeElement)
        {
            if (configurationItem != null)
                base.configurationItem = configurationItem;

            RowDefinitions.Add(new RowDefinition());
            RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

            SortedDictionary<string, Type> entriesToAdd = typesToAdd();
            typeEntries = entriesToAdd;
            UIElement addButton = null;
            if (entriesToAdd.Count > 1)
            {
                ResourceDictionary buttonStyle = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\DropDownButton.xaml", UriKind.Relative));
                addButton = new DropDownButton
                {
                    Height = 30,
                    Width = 300,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment = VerticalAlignment.Bottom,
                    Margin = new Thickness(5),
                    Content = addButtonText(),
                    DropDownContent = DropDownButtonOptions(entriesToAdd),
                    DropDownPosition = PlacementMode.Top,
                    Style = (Style)buttonStyle["DropDownButtonStyle"]
                };
            }
            else
            {
                foreach (KeyValuePair<string, Type> entryToAdd in entriesToAdd)
                {
                    ResourceDictionary buttonStyle = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\ButtonStyle.xaml", UriKind.Relative));
                    addButton = new Button
                    {
                        Height = 30,
                        Width = 300,
                        HorizontalAlignment = HorizontalAlignment.Left,
                        VerticalAlignment = VerticalAlignment.Bottom,
                        Margin = new Thickness(5),
                        Content = addButtonText(),
                        Style = (Style)buttonStyle["ButtonStyle1"]
                    };
                    ((Button)addButton).Click += AddButton_Click;
                    ((Button)addButton).Resources.Add("NewObjectType", entryToAdd.Value);
                }
            }
            if(addButton != null)
            {
                addButton.SetValue(RowProperty, 1);
                Children.Add(addButton);
            }

            if (displayCategoriesToShow != null)
                createDefaultView(false, displayCategoriesToShow);
        }

        protected SortedDictionary<string, Type> typeEntries;
        public SortedDictionary<string, Type> TypeEntries { get { return typeEntries; } }

        private StackPanel DropDownButtonOptions(SortedDictionary<string, Type> entriesToAdd)
        {
            StackPanel stackPanel = new StackPanel();
            ResourceDictionary buttonStyle = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\ButtonStyle.xaml", UriKind.Relative));

            foreach (KeyValuePair<string, Type> deviceType in entriesToAdd)
            {
                Button button = new Button
                {
                    Content = deviceType.Key,
                    BorderThickness = new Thickness(0),
                    Style = (Style)buttonStyle["ButtonStyle1"]
                };
                button.Resources.Add("NewObjectType", deviceType.Value);
                button.Click += AddButton_Click;
                stackPanel.Width = 295;
                stackPanel.Children.Add(button);
            }
            return stackPanel;
        }

        protected virtual string addButtonText()
        {
            return Translation.GetTranslatedAddButton(this.GetType());
        }

        protected virtual SortedDictionary<string, Type> typesToAdd()
        {
            return null;
        }

        public void AddConfiguration(Type type)
        {
            DeviceConfigurationBase parentDeviceConfiguration = configurationItem as DeviceConfigurationBase;
            if (parentDeviceConfiguration.Enabled == false)
                return;

            App.ConfigurationModified = true;
            NodeConfiguration newObject = (NodeConfiguration)Activator.CreateInstance(type);

            int parentDeviceId = 0;
            int pointOnParent = 0;

            List<ComboBoxItemContents> availableDevices = ControllerConfigurationManager.GetAvailableDevices(newObject.GetType(), 0);
            foreach (ComboBoxItemContents availableDevice in availableDevices)
            {
                List<ComboBoxItemContents> availablePoints = ControllerConfigurationManager.GetAvailableDevicePoints((int)availableDevice.Value, newObject.GetType(), 0);
                foreach (ComboBoxItemContents availablePoint in availablePoints)
                {
                    if (availablePoint.Enabled == true)
                    {
                        parentDeviceId = (int)availableDevice.Value;
                        pointOnParent = (int)availablePoint.Value;
                        break;
                    }
                }
                if (pointOnParent > 0)
                    break;
            }

            if (pointOnParent > 0)
            {
                ConfigurationManager.AutoConfigure(newObject, parentDeviceId, pointOnParent);

                NodeTreeView.LoadTree();
                NodeTreeView.SetSelection(newObject);
            }
            else
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.AddingNewNode),
                    Translation.GetTranslatedError(ErrorMessage.Error));
            }
        }

        protected virtual void AddButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            AddConfiguration((Type)button.Resources["NewObjectType"]);
        }
    }
}
