﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Xceed.Wpf.Toolkit;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class KeypadsFolderView : FolderViewBase
    {
        public KeypadsFolderView(NodeTreeElement nodeTreeElement) : base(nodeTreeElement, new DisplayCategory[] { DisplayCategory.Keypads, DisplayCategory.KeypadText })
        {


        }

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> types = new SortedDictionary<string, Type>();
            Type type = typeof(Device8003KeypadConfiguration);
            types[Translation.GetTranslatedString(type)] = type;
            return types;
        }
    }
}
