﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.Model;
using Pacom.Peripheral.Common.Configuration;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class ElevatorFloorsFolderView : FolderViewBase
    {      
        public ElevatorFloorsFolderView(NodeTreeElement nodeTreeElement) : base(nodeTreeElement)
        {
            var expander = createExpander();
            ScrollViewer scrollViewer = new ScrollViewer();
            scrollViewer.Content = expander;
            Children.Add(scrollViewer);

            Grid floorDataGrid = new Grid();
            floorDataGrid.ColumnDefinitions.Add(new ColumnDefinition());
            floorDataGrid.ColumnDefinitions.Add(new ColumnDefinition());
            expander.Content = floorDataGrid;

            int row = 0;
            foreach (var floor in ConfigurationManager.ElevatorFloors.Values)
            {
                addRow(floorDataGrid, floor, row);
                row++;
            }
        }

        private CustomExpander createExpander()
        {
            CustomExpander expander = new CustomExpander()
            {
                IsExpanded = true,
                VerticalAlignment = VerticalAlignment.Stretch,
                Header = Translation.GetTranslatedString("FloorSchedules")
            };
            ResourceDictionary style = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\ExpanderStyle.xaml", UriKind.Relative));
            expander.Style = (Style)style["ExpanderStyle1"];
            return expander;
        }
        private Control createLabel(string text)
        {
            Label label = new Label();
            label.Content = text;
            label.Margin = new Thickness(5,0,0,0);
            label.Foreground = System.Windows.Media.Brushes.Black;
            return label;
        }

        private Control createComboBox(ElevatorFloor8003Configuration floor)
        {
            ComboBox comboBox = new ComboBox();
            comboBox.MaxDropDownHeight = 200;
            comboBox.Height = 25;
            var schedules = ControllerConfigurationManager.GetAvailableSchedules();
            ResourceDictionary resource = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\ComboBoxItemStyle.xaml", UriKind.Relative));
            Style comboBoxItemStyle = (Style)resource["comboBoxItemStyle"];
            foreach (var schedule in schedules)
            {
                ComboBoxItem cbi = new ComboBoxItem();
                cbi.Content = schedule.DisplayName;
                cbi.Style = comboBoxItemStyle;
                comboBox.Items.Add(cbi);
            }
            comboBox.SelectedIndex = getScheduleIndex(floor.FloorScheduleId);
            comboBox.SelectionChanged += (sender, e) =>
            {
                var content = schedules[comboBox.SelectedIndex];
                floor.FloorScheduleId = int.Parse(content.Value.ToString());
            };

            return comboBox;
        }

        private int getScheduleIndex(int scheduleId)
        {
            for (int i = 0; i < ConfigurationManager.Schedules.Values.Count; i++)
            {
                if (ConfigurationManager.Schedules.Values[i].Id == scheduleId)
                    return i + 1;
            }
            return 0;
        }

        void addRow(Grid floorDataGrid, ElevatorFloor8003Configuration floor, int row)
        {
            floorDataGrid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            Control label = createLabel(floor.Name);
            Control comboBox = createComboBox(floor);
            Grid.SetRow(label, row);
            Grid.SetColumn(label, 0);
            Grid.SetRow(comboBox, row);
            Grid.SetColumn(comboBox, 1);
            floorDataGrid.Children.Add(label);
            floorDataGrid.Children.Add(comboBox);
        }

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> types = new SortedDictionary<string, Type>();
            if(ConfigurationManager.ElevatorFloors.Count < 128)
            {
                Type type = typeof(ElevatorFloor8003Configuration);
                types[Translation.GetTranslatedString(type)] = type;
            }

            return types;
        }

        protected override void AddButton_Click(object sender, RoutedEventArgs e)
        {
            ConfigurationManager.AddNewConfiguration(new ElevatorFloor8003Configuration());
        }
    }
}
