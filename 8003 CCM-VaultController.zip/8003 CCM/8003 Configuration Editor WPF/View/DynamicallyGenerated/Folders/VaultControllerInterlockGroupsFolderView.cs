﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Xceed.Wpf.Toolkit;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class VaultControllerInterlockGroupsFolderView : FolderViewBase
    {
        public VaultControllerInterlockGroupsFolderView(NodeTreeElement nodeTreeElement) : base(nodeTreeElement)
        {
        }

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> types = new SortedDictionary<string, Type>();
            Type type = typeof(VaultControllerInterlock8003Configuration);
            types[Translation.GetTranslatedString(type)] = type;
            return types;
        }

        protected override void AddButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            Button button = (Button)sender;
            var newObject = new VaultControllerInterlock8003Configuration();

            ConfigurationManager.AutoConfigure(newObject);
            newObject.Name = Translation.GetTranslatedString(newObject.GetType()) + " " + newObject.Id.ToString();

            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(newObject);
        }
    }
}
