﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Xceed.Wpf.Toolkit;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class UsersFolderView : FolderViewBase
    {
        public UsersFolderView(NodeTreeElement nodeTreeElement) : base(nodeTreeElement)
        {
        }

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> types = new SortedDictionary<string, Type>();
            switch(ConfigurationManager.ConfigurationType)
            {
                case ConfigurationType.Gms:
                    types["User"] = typeof(User8003Configuration);
                    break;
                case ConfigurationType.Unison:
                    types["User"] = typeof(User);
                    break;
                default:
                    types["GmsUser"] = typeof(User8003Configuration);
                    types["UnisonUser"] = typeof(User);
                    break;
            }
            return types;
        }

        protected override void AddButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            Button button = (Button)sender;
            UserConfigurationBase newObject = (UserConfigurationBase)Activator.CreateInstance((Type)button.Resources["NewObjectType"]);

            ConfigurationManager.AutoConfigure(newObject);
            newObject.Name = Translation.GetTranslatedString(newObject.GetType()) + "-" + newObject.Id.ToString();

            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(newObject);
        }
    }
}
