﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class SchedulesFolderView : FolderViewBase
    {
        public SchedulesFolderView(NodeTreeElement nodeTreeElement) : base(nodeTreeElement)
        {
        }

        protected override SortedDictionary<string, Type> typesToAdd()
        {
            SortedDictionary<string, Type> types = new SortedDictionary<string, Type>();
            Type type = typeof(Schedule);
            types[Translation.GetTranslatedString(type)] = type;
            return types;
        }

        protected override void AddButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            Button button = (Button)sender;
            Schedule newObject = new Schedule();

            ConfigurationManager.AutoConfigure(newObject);

            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(newObject);
        }
    }
}
