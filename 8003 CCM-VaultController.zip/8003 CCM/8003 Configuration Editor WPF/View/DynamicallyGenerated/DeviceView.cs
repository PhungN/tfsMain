﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class DeviceView : ConfigurationViewBase<DeviceConfigurationBase>
    {
        public DeviceView(DeviceConfigurationBase device, NodeTreeElement nodeTreeElement) : base(device, nodeTreeElement)
        {
            createDefaultView(true);
        }

        protected override ControllerAttribute updateControllerAttribute(PropertyInfo propertyInfo, ControllerAttribute controllerAttribute)
        {
            if (propertyInfo.Name == "ParentDeviceId" &&
                (configurationItem.GetType().BaseType == typeof(DeviceLoopDeviceConfigurationBase) ||
                 configurationItem.GetType().BaseType == typeof(InovonicsDeviceConfigurationBase) ||
                 configurationItem.GetType() == typeof(AperioDriverConfiguration)))
                return new ControllerAttribute(DisplayCategory.Hidden);

            if (propertyInfo.Name == "DeviceLoopAddress" &&
                (configurationItem.GetType() == typeof(InovonicsReceiverDeviceConfiguration) ||
                 configurationItem.GetType() == typeof(InovonicsRepeaterDeviceConfiguration) ||
                 configurationItem.GetType() == typeof(InovonicsSecurityDeviceConfiguration)))
                return new ControllerAttribute(DisplayCategory.Hidden);

            if (propertyInfo.Name == "DeviceType" &&
                (configurationItem.GetType() == typeof(InovonicsReceiverDeviceConfiguration) ||
                 configurationItem.GetType() == typeof(InovonicsRepeaterDeviceConfiguration)))
                return new ControllerAttribute(DisplayCategory.Hidden);

            return base.updateControllerAttribute(propertyInfo, controllerAttribute);
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.RemoveDevice(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }

        protected override object preSetValue(FrameworkElement frameworkElement, PropertyInfo property, object newValue)
        {
            if (property.Name == "ParentDeviceId")
            {
                ExpansionCardDeviceConfigurationBase expansionCard = configurationItem as ExpansionCardDeviceConfigurationBase;
                if (expansionCard != null)
                {
                    if (HardwareLimitations.GetAvailableDevicePointLimit(expansionCard.Id, typeof(Port8003ConfigurationBase)) > 0)
                    {
                        int oldParentId = expansionCard.ParentDeviceId;
                        int newParentId = (int)newValue;

                        if ((oldParentId == ConfigurationManager.ControllerConfiguration.Id ||
                            newParentId == ConfigurationManager.ControllerConfiguration.Id) && oldParentId != newParentId)
                        {
                            Unload();
                            if (oldParentId == ConfigurationManager.ControllerConfiguration.Id)
                            {
                                // Remove any port associated with the port if present
                                // I/O have the device as the parent so they don't need to be touched but ports only live on the controller.
                                int expansionCardSlot = expansionCard.ExpansionCardSlot;
                                if (expansionCardSlot > 0)
                                {
                                    int portId = -1;
                                    foreach (Port8003ConfigurationBase port in ConfigurationManager.Ports.Values)
                                    {
                                        if ((port.PortNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot1 && expansionCardSlot == 1) ||
                                            (port.PortNumberOnParent == Pacom8003PhysicalPort.ExpansionSlot2 && expansionCardSlot == 2))
                                        {
                                            portId = port.Id;
                                            break;
                                        }
                                    }
                                    if (portId != -1)
                                    {
                                        ConfigurationManager.Ports.Remove(portId);
                                        NodeTreeView.LoadTree();
                                        NodeTreeView.SetSelection(expansionCard);
                                    }
                                }
                            }
                            else
                            {
                                // Add a port associated with the expansion card
                                // To avoid code duplication, remove the old device and create a new one.

                                int oldId = expansionCard.Id;
                                string oldName = expansionCard.Name;
                                bool oldEnabled = expansionCard.Enabled;

                                int pointOnParent = 0;
                                List<ComboBoxItemContents> availablePoints = ControllerConfigurationManager.GetAvailableDevicePoints(newParentId, expansionCard.GetType(), 0);
                                foreach (ComboBoxItemContents availablePoint in availablePoints)
                                {
                                    if (availablePoint.Enabled)
                                    {
                                        pointOnParent = (int)availablePoint.Value;
                                        break;
                                    }
                                }

                                ConfigurationManager.RemoveDevice(expansionCard.Id);

                                ConfigurationManager.AutoConfigure(expansionCard, newParentId, pointOnParent);
                                ConfigurationManager.ExpansionCards.Remove(expansionCard.Id);
                                expansionCard.Id = oldId;
                                expansionCard.Name = oldName;
                                expansionCard.Enabled = oldEnabled;
                                ConfigurationManager.ExpansionCards[expansionCard.Id] = expansionCard;

                                NodeTreeView.LoadTree();
                                NodeTreeView.SetSelection(expansionCard);
                            }
                        }
                    }
                }
            }
            else if (property.Name == "Enabled")
            {
                if (configurationItem is InovonicsDeviceConfigurationBase &&
                    (configurationItem is InovonicsReceiverDeviceConfiguration == false))
                {
                    bool receiverDeviceEnabled = false;
                    foreach (KeyValuePair<int, DeviceConfigurationBase> device in ConfigurationManager.Devices)
                    {
                        if (device.Value is InovonicsReceiverDeviceConfiguration)
                        {
                            receiverDeviceEnabled = device.Value.Enabled;
                            break;
                        }
                    }
                    if (receiverDeviceEnabled == false)
                    {
                        NodeTreeView.Instance.RefreshConfigurationView();
                        return false;
                    }
                }
            }

            return base.preSetValue(frameworkElement, property, newValue);
        }
    }
}
