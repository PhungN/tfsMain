﻿using System;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class InputView : ConfigurationViewBase<Input8003Configuration>
    {
        public InputView(Input8003Configuration input, NodeTreeElement nodeTreeElement) : base(input, nodeTreeElement)
        {
            createDefaultView(true);
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.Inputs.Remove(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }

        protected override object preSetValue(FrameworkElement frameworkElement, PropertyInfo property, object newValue)
        {
            if (property.Name == "Enabled" && (bool)newValue == true
                && ConfigurationManager.ControllerHasCapacity<Input8003Configuration>() == false)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.LicenseCapacity),
                    Translation.GetTranslatedError(ErrorMessage.Warning));
            }
            else if (property.Name == "EntryDelayRunningActionType")
            {
                // TriggersEntryDelay is an obsolete property but if it is true will change the inputs behaviour
                configurationItem.TriggersEntryDelay = false;
            }

            return base.preSetValue(frameworkElement, property, newValue);
        }
    }
}
