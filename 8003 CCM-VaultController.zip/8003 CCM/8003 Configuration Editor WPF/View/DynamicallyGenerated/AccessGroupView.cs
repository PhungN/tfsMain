﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.UserControls;
using Pacom.Core.Access;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class AccessGroupView : ConfigurationViewBase<AccessGroup>
    {
        public AccessGroupView(AccessGroup accessGroup, NodeTreeElement nodeTreeElement) : base(accessGroup, nodeTreeElement)
        {
            createDefaultView(true);

            categoryGrids[DisplayCategory.Permissions].RowDefinitions.Add(new RowDefinition());
            AccessGroupControl accessGroupControl = new AccessGroupControl(accessGroup);
            accessGroupControl.SetValue(Grid.RowProperty, 1);
            accessGroupControl.SetValue(Grid.ColumnProperty, 0);
            accessGroupControl.SetValue(Grid.ColumnSpanProperty, 2);
            categoryGrids[DisplayCategory.Permissions].Children.Add(accessGroupControl);
        }

        protected override ControllerAttribute updateControllerAttribute(PropertyInfo propertyInfo, ControllerAttribute controllerAttribute)
        {
            if (controllerAttribute == null)
                return new ControllerAttribute(DisplayCategory.Hidden);

            return base.updateControllerAttribute(propertyInfo, controllerAttribute);
        }

        protected override void addAdditionalElements(SortedDictionary<DisplayCategory, List<PropertyInfo>> categorisedProperties)
        {
            categorisedProperties[DisplayCategory.Permissions] = new List<PropertyInfo>();
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.UnisonAccessGroups.Remove(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }
    }
}
