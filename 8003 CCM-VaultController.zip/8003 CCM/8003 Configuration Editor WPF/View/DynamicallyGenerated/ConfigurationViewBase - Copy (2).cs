﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using Pacom.Common.CompactFramework.Helpers;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.Model;
using Pacom.ConfigurationEditor.WPF.UserControls;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Xceed.Wpf.Toolkit;
using Xceed.Wpf.Toolkit.Primitives;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public abstract class ConfigurationViewBase<T> : Grid, IUnloadable where T : ConfigurationBase
    {
        protected T configurationItem;
        protected NodeTreeElement nodeTreeElement;
        protected ComboBox pointOnParentComboBox;
        protected Dictionary<DisplayCategory, Grid> categoryGrids;
        protected Grid parentGrid;

        protected static Dictionary<string, Dictionary<string, bool>> expandedCategoriesDictionary = new Dictionary<string, Dictionary<string, bool>>();

        public ConfigurationViewBase(T configurationItem, NodeTreeElement nodeTreeElement)
        {
            this.configurationItem = configurationItem;
            this.nodeTreeElement = nodeTreeElement;
        }

        public void Unload()
        {
            Dictionary<string, bool> expandedCategories = new Dictionary<string, bool>();
            if (parentGrid != null)
            {
                foreach (object child in parentGrid.Children)
                {
                    CustomExpander expander = child as CustomExpander;
                    if (expander != null)
                    {
                        expandedCategories[expander.Name] = expander.IsExpanded;
                    }
                }
                string expanderTypeName = ExpanderTypeName;
                if (string.IsNullOrEmpty(expanderTypeName) == false)
                    expandedCategoriesDictionary[expanderTypeName] = expandedCategories;
            }
        }

        protected virtual string ExpanderTypeName
        {
            get
            {
                return configurationItem.GetType().ToString();
            }
        }

        protected void createDefaultView(bool deletable, DisplayCategory[] controllerDisplayCategoriesToShow = null)
        {
            if (controllerDisplayCategoriesToShow == null && (this is InovonicsReceiverFolderView) == false)
                RowDefinitions.Add(new RowDefinition());
            ScrollViewer scrollViewer = new ScrollViewer();
            parentGrid = new Grid();

            scrollViewer.Content = parentGrid;
            Children.Add(scrollViewer);

            // Group all properties into categories
            SortedDictionary<DisplayCategory, List<PropertyInfo>> categorisedProperties = new SortedDictionary<DisplayCategory, List<PropertyInfo>>();
            Type currentType = configurationItem.GetType();
            foreach (PropertyInfo propertyInfo in currentType.GetProperties(BindingFlags.Instance | BindingFlags.Public))
            {
                if (propertyInfo.CanRead == false || propertyInfo.CanWrite == false)
                    continue;

                ControllerAttribute controllerAttribute = GetControllerAttribute(propertyInfo);
                controllerAttribute = updateControllerAttribute(propertyInfo, controllerAttribute);
                if (controllerAttribute == null)
                {
#if DEBUG
                    if (categorisedProperties.ContainsKey(DisplayCategory.UnAssigned) == false)
                        categorisedProperties[DisplayCategory.UnAssigned] = new List<PropertyInfo>();
                    categorisedProperties[DisplayCategory.UnAssigned].Add(propertyInfo);
#endif
                }
                else
                {
                    // Special categories are properties that are stored in the Device8003Configuration class but are displayed elsewhere
                    // They have display categories in the range 1001 - 2000 and 3001 - 4000 (start collapsed)
                    bool isSpecialCategory = true;
                    if ((int)controllerAttribute.Category < 1000 || ((int)controllerAttribute.Category > 2000 && (int)controllerAttribute.Category < 3000))
                        isSpecialCategory = false;

                    if ((controllerDisplayCategoriesToShow == null && isSpecialCategory == false) ||
                        (controllerDisplayCategoriesToShow != null && isSpecialCategory == true && controllerDisplayCategoriesToShow.Contains(controllerAttribute.Category)))
                    {
#if !DEBUG
                        if (controllerAttribute.Category != DisplayCategory.Hidden)
#endif
                        {
                            if (categorisedProperties.ContainsKey(controllerAttribute.Category) == false)
                                categorisedProperties[controllerAttribute.Category] = new List<PropertyInfo>();
                            categorisedProperties[controllerAttribute.Category].Add(propertyInfo);
                        }
                    }
                }
            }

            addAdditionalElements(categorisedProperties);

            // Create Expanders
            DisplayCategory[] categories = categorisedProperties.Keys.ToArray();
            categoryGrids = new Dictionary<DisplayCategory, Grid>();
            for (int i = 0; i < categories.Length; i++)
            {
                bool expanded = ((int)categories[i] < 2000) ? true : false;
                bool includeDeleteButton = deletable && i == 0;
                categoryGrids[categories[i]] = addExpander(parentGrid, Translation.GetTranslatedString(categories[i]), expanded, includeDeleteButton, categories[i].ToString());
            }

            // Add properties
            foreach (DisplayCategory category in categories)
            {
                List<PropertyInfo> properties = categorisedProperties[category];
                Grid categoryGrid = categoryGrids[category];
                addPropertiesToGrid(properties, categoryGrid);
            }
        }

#region Add properties
        protected void addPropertiesToGrid(List<PropertyInfo> properties, Grid grid, object parentItem = null)
        {
            if (parentItem == null)
                parentItem = configurationItem;

            Thickness marginThickness = new Thickness(5);
            properties.Sort(compareProperties);

            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition());

            for (int i = 0; i < properties.Count; i++)
            {
                ControllerAttribute controllerAttribute = GetControllerAttribute(properties[i]);
                if (controllerAttribute == null)
                    controllerAttribute = new ControllerAttribute(DisplayCategory.UnAssigned);

                grid.RowDefinitions.Add(new RowDefinition());

                Label label = new Label { Margin = marginThickness };
                label.Foreground = Brushes.Black;

                label.Content = new TextBlock() { Text = getLabelText(properties[i]), Foreground = Brushes.Black };
                label.SetValue(Grid.RowProperty, i);
                grid.Children.Add(label);

                FrameworkElement value = null;
                Type propertyType = properties[i].PropertyType;
                if (controllerAttribute.DisplayType != null)
                    propertyType = controllerAttribute.DisplayType;

                if (properties[i].Name == "AreaId")
                {
                    ComboBox comboBox = new ComboBox();
                    value = comboBox;
                    comboBox.MaxDropDownHeight = 200;
                    comboBox.Height = 30;
                    comboBox.Padding = new Thickness(7, 5, 0, 0);

                    // Add all areas to the combo box
                    int currentArea = (int)properties[i].GetValue(parentItem, null);
                    List<ComboBoxItemContents> areas = ControllerConfigurationManager.GetAvailableAreas(true);
                    foreach (ComboBoxItemContents area in areas)
                    {
                        int insertedIndex = comboBox.Items.Add(area);
                        if ((int)area.Value == currentArea)
                            comboBox.SelectedIndex = insertedIndex;
                    }
                    comboBox.SelectionChanged += ComboBox_SelectionChanged;
                }
                else if (properties[i].Name == "AreaIds")
                {
                    CheckComboBox comboBox = new CheckComboBox();
                    value = comboBox;
                    comboBox.MaxDropDownHeight = 200;
                    comboBox.Height = 30;
                    comboBox.Padding = new Thickness(7, 5, 0, 0);

                    // Add all areas to the combo box
                    int[] currentAreas = (int[])properties[i].GetValue(parentItem, null);
                    List<ComboBoxItemContents> areas = ControllerConfigurationManager.GetAvailableAreas(false);
                    foreach (ComboBoxItemContents area in areas)
                    {
                        int insertedIndex = comboBox.Items.Add(area);
                        if (currentAreas != null && currentAreas.Contains((int)area.Value))
                            comboBox.SelectedItems.Add(comboBox.Items[insertedIndex]);
                    }
                    comboBox.ItemSelectionChanged += ComboBox_IntArraySelectionChanged;
                }
                else if (properties[i].Name == "AreaModeFollows")
                {
                    CheckComboBox comboBox = new CheckComboBox();
                    value = comboBox;
                    comboBox.MaxDropDownHeight = 200;
                    comboBox.Height = 30;
                    comboBox.Padding = new Thickness(7, 5, 0, 0);

                    // Add all areas to the combo box
                    int[] currentAreas = (int[])properties[i].GetValue(parentItem, null);
                    List<ComboBoxItemContents> areas = ControllerConfigurationManager.GetAvailableAreas(false);
                    int aId = configurationItem.Id;
                    foreach (ComboBoxItemContents area in areas)
                    {
                        int areaId = (int)area.Value;
                        if (areaId == configurationItem.Id)
                            continue;
                        int insertedIndex = comboBox.Items.Add(area);
                        if (currentAreas != null && currentAreas.Contains(areaId))
                            comboBox.SelectedItems.Add(comboBox.Items[insertedIndex]);
                    }
                    comboBox.ItemSelectionChanged += ComboBox_IntArraySelectionChanged;
                }
                else if (properties[i].Name == "ParentDeviceId")
                {
                    ComboBox comboBox = new ComboBox();
                    value = comboBox;
                    comboBox.MaxDropDownHeight = 1;
                    comboBox.Height = 30;
                    comboBox.Padding = new Thickness(7, 5, 0, 0);

                    // Add available devices to the combo box
                    NodeConfiguration node = parentItem as NodeConfiguration;
                    int currentParent = node.ParentDeviceId;
                    List<ComboBoxItemContents> devices = ControllerConfigurationManager.GetAvailableDevices(configurationItem.GetType(), currentParent);
                    comboBox.ItemsSource = devices;
                    for (int comboBoxIndex = 0; comboBoxIndex < comboBox.Items.Count; comboBoxIndex++)
                    {
                        ComboBoxItemContents item = (ComboBoxItemContents)comboBox.Items[comboBoxIndex];
                        if ((int)item.Value == currentParent)
                        {
                            comboBox.SelectedIndex = comboBoxIndex;
                            break;
                        }
                    }
                    comboBox.SelectionChanged += ComboBox_SelectionChanged;
                    // The following is to disable the unavailable devices
                    comboBox.ItemContainerGenerator.StatusChanged += ItemContainerGenerator_StatusChanged;
                    comboBox.IsDropDownOpen = true;
                    comboBoxes[comboBox.ItemContainerGenerator] = comboBox;
                }
                else if (properties[i].Name == "PointNumberOnParent" || properties[i].Name == "ExpansionCardSlot" || properties[i].Name == "DeviceLoopAddress")
                {
                    // Add available points to the combo box
                    NodeConfiguration node = parentItem as NodeConfiguration;
                    int currentParent = node.ParentDeviceId;
                    int currentPoint = (int)properties[i].GetValue(parentItem, null);
                    List<ComboBoxItemContents> points = ControllerConfigurationManager.GetAvailableDevicePoints(currentParent, configurationItem.GetType(), currentPoint);

                    createPointOnParentComboBox(points, currentPoint, grid, i, properties[i], parentItem);
                    continue;
                }
                else if (controllerAttribute.Flags == ControllerAttributeFlag.IsPassword ||
                    controllerAttribute.Flags == ControllerAttributeFlag.IsPin)
                {
                    PasswordRevealBox passwordRevealBox = new PasswordRevealBox();
                    value = passwordRevealBox;
                    string currentValue = properties[i].GetValue(parentItem, null).ToString();
                    passwordRevealBox.IsPasswordEncrypted = (controllerAttribute.Flags == ControllerAttributeFlag.IsPassword) && (ControllerConfigurationManager.ControllerFirmwareSupportsEncryption);
                    if (properties[i].GetValue(parentItem, null) != null)
                        passwordRevealBox.Password = currentValue;
                    passwordRevealBox.PasswordChanged += TxtPasswordbox_PasswordChanged;
                }
                else if (controllerAttribute.Flags == ControllerAttributeFlag.IsIPAddress)
                {
                    IPAddressControl ipAddressControl = new IPAddressControl();
                    value = ipAddressControl;
                    if (properties[i].GetValue(parentItem, null) != null)
                        ipAddressControl.Text = properties[i].GetValue(parentItem, null).ToString();
                    else
                        ipAddressControl.Text = "0.0.0.0";
                    ipAddressControl.TextChanged += IpAddressControl_TextChanged;
                }
                else if (properties[i].Name.Contains("ScheduleId"))
                {
                    ComboBox comboBox = new ComboBox();
                    value = comboBox;
                    comboBox.MaxDropDownHeight = 200;
                    comboBox.Height = 30;
                    comboBox.Padding = new Thickness(7, 5, 0, 0);

                    int currentSchedule = (int)properties[i].GetValue(parentItem, null);
                    List<ComboBoxItemContents> schedules = ControllerConfigurationManager.GetAvailableSchedules();
                    foreach (ComboBoxItemContents schedule in schedules)
                    {
                        int insertedIndex = comboBox.Items.Add(schedule);
                        if ((int)schedule.Value == currentSchedule)
                            comboBox.SelectedIndex = insertedIndex;
                    }
                    comboBox.SelectionChanged += ComboBox_SelectionChanged;
                }
                else if (properties[i].Name.Contains("GroupId"))
                {
                    ComboBox comboBox = new ComboBox();
                    value = comboBox;
                    comboBox.MaxDropDownHeight = 200;
                    comboBox.Height = 30;
                    comboBox.Padding = new Thickness(7, 5, 0, 0);

                    int currentGroup = (int)properties[i].GetValue(parentItem, null);
                    List<ComboBoxItemContents> groups = ControllerConfigurationManager.GetAvailableUserGroups();
                    foreach (ComboBoxItemContents group in groups)
                    {
                        int insertedIndex = comboBox.Items.Add(group);
                        if ((int)group.Value == currentGroup)
                            comboBox.SelectedIndex = insertedIndex;
                    }
                    comboBox.SelectionChanged += ComboBox_SelectionChanged;
                }
                else if (properties[i].Name == "ReaderInId" || properties[i].Name == "ReaderOutId")
                {
                    ComboBox comboBox = new ComboBox();
                    value = comboBox;
                    comboBox.MaxDropDownHeight = 200;
                    comboBox.Height = 30;
                    comboBox.Padding = new Thickness(7, 5, 0, 0);

                    int currentReader = (int)properties[i].GetValue(parentItem, null);
                    List<ComboBoxItemContents> readers = ControllerConfigurationManager.GetAvailableReaders(currentReader);
                    foreach (ComboBoxItemContents reader in readers)
                    {
                        int insertedIndex = comboBox.Items.Add(reader);
                        if ((int)reader.Value == currentReader)
                            comboBox.SelectedIndex = insertedIndex;
                    }
                    comboBox.SelectionChanged += ComboBox_SelectionChanged;
                    // The following is to disable the unavailable devices
                    comboBox.ItemContainerGenerator.StatusChanged += ItemContainerGenerator_StatusChanged;
                    comboBox.IsDropDownOpen = true;
                    comboBoxes[comboBox.ItemContainerGenerator] = comboBox;
                }
                else if (propertyType == typeof(int))
                {
                    if (controllerAttribute.Flags == ControllerAttributeFlag.IsMilliUnit)
                    {
                        DoubleUpDown doubleUpDown = new DoubleUpDown();
                        value = doubleUpDown;
                        int? integer = properties[i].GetValue(parentItem, null) as int?;
                        doubleUpDown.Value = integer.Value;
                        doubleUpDown.Value = doubleUpDown.Value / 1000;
                        doubleUpDown.FormatString = "F2";
                        doubleUpDown.Increment = 0.1;
                        doubleUpDown.TextAlignment = TextAlignment.Left;
                        doubleUpDown.Height = 30;
                        doubleUpDown.Padding = new Thickness(0, 0, 5, 0);
                        RangeAttribute rangeAttribute = getRangeAttribute(properties[i]);
                        doubleUpDown.Minimum = rangeAttribute.Minimum / 1000.0;
                        doubleUpDown.Maximum = rangeAttribute.Maximum / 1000.0;
                        doubleUpDown.ValueChanged += DoubleUpDown_MilliValueChanged;
                    }
                    else
                    {
                        IntegerUpDown integerUpDown = new IntegerUpDown();
                        value = integerUpDown;
                        integerUpDown.Value = properties[i].GetValue(parentItem, null) as int?;
                        integerUpDown.Height = 30;
                        integerUpDown.Padding = new Thickness(0, 0, 5, 0);
                        RangeAttribute rangeAttribute = getRangeAttribute(properties[i]);
                        integerUpDown.Minimum = rangeAttribute.Minimum;
                        integerUpDown.Maximum = rangeAttribute.Maximum;
                        integerUpDown.TextAlignment = TextAlignment.Left;
                        integerUpDown.ValueChanged += IntegerUpDown_ValueChanged;
                        // ID is not editable
                        if (properties[i].Name == "Id")
                            integerUpDown.IsReadOnly = true;
                    }
                }
                else if (propertyType == typeof(long))
                {
                    LongUpDown integerUpDown = new LongUpDown();
                    value = integerUpDown;
                    integerUpDown.Value = properties[i].GetValue(parentItem, null) as long?;
                    integerUpDown.Height = 30;
                    integerUpDown.Padding = new Thickness(0, 0, 5, 0);
                    RangeAttribute rangeAttribute = getRangeAttribute(properties[i]);
                    integerUpDown.Minimum = rangeAttribute.Minimum;
                    integerUpDown.Maximum = rangeAttribute.Maximum;
                    integerUpDown.TextAlignment = TextAlignment.Left;
                    integerUpDown.ValueChanged += LongUpDown_ValueChanged;
                }
                else if (propertyType == typeof(bool))
                {
                    CustomCheckBox customCheckBox = new CustomCheckBox();
                    value = customCheckBox;
                    customCheckBox.IsChecked = properties[i].GetValue(parentItem, null) as bool?;
                    customCheckBox.Style = (Style)((ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\CheckboxSliderStyle.xaml", UriKind.Relative)))["OrangeSwitchStyle"];
                    customCheckBox.VerticalAlignment = VerticalAlignment.Center;
                    customCheckBox.HorizontalAlignment = HorizontalAlignment.Center;
                    customCheckBox.SetValue(FrameworkElement.HorizontalAlignmentProperty, HorizontalAlignment.Left);
                    customCheckBox.Checked += CustomCheckBox_Checked;
                    customCheckBox.Unchecked += CustomCheckBox_Checked;
                }
                else if (propertyType == typeof(TimeSpan) || propertyType == typeof(DateTime))
                {
                    if (propertyType == typeof(DateTime) && (controllerAttribute.Flags == ControllerAttributeFlag.IsStartDate || controllerAttribute.Flags == ControllerAttributeFlag.IsEndDate))
                    {
                        DatePicker datePicker = new DatePicker();
                        value = datePicker;
                        datePicker.Background = Brushes.White;
                        datePicker.SelectedDate = (DateTime)properties[i].GetValue(parentItem, null);
                        datePicker.MouseDoubleClick += DatePicker_MouseDoubleClick;
                        if (controllerAttribute.Flags == ControllerAttributeFlag.IsStartDate)
                            datePicker.SelectedDateChanged += DatePicker_SelectedStartDateChanged;
                        else
                            datePicker.SelectedDateChanged += DatePicker_SelectedEndDateChanged;
                    }
                    else
                    {
                        TimeSpanUpDown timeSpanUpDown = new TimeSpanUpDown();
                        value = timeSpanUpDown;
                        timeSpanUpDown.Minimum = TimeSpan.Zero;
                        timeSpanUpDown.Maximum = TimeSpan.FromDays(1);
                        timeSpanUpDown.Height = 30;
                        timeSpanUpDown.Padding = new Thickness(0, 0, 5, 0);
                        timeSpanUpDown.DisplayDefaultValueOnEmptyText = true;
                        timeSpanUpDown.TextAlignment = TextAlignment.Left;
                        RangeAttribute rangeAttribute = getRangeAttribute(properties[i]);
                        if (rangeAttribute.Minimum > 0)
                        {
                            timeSpanUpDown.Minimum = TimeSpan.FromMilliseconds(rangeAttribute.Minimum);
                            timeSpanUpDown.Maximum = TimeSpan.FromMilliseconds(rangeAttribute.Maximum);
                        }
                        if (properties[i].GetValue(parentItem, null) != null)
                        {
                            if (propertyType == typeof(DateTime))
                            {
                                DateTime dateTimeValue = (DateTime)properties[i].GetValue(parentItem, null);
                                timeSpanUpDown.Text = dateTimeValue.TimeOfDay.ToString();
                            }
                            else
                            {
                                timeSpanUpDown.Text = properties[i].GetValue(parentItem, null).ToString();
                            }
                        }
                        timeSpanUpDown.ValueChanged += TimeSpanUpDown_ValueChanged;
                    }
                }
                else if (propertyType.IsEnum)
                {
                    if (hasFlagsAttribute(propertyType))
                    {
                        CheckComboBox comboBox = new CheckComboBox();
                        value = comboBox;
                        comboBox.MaxDropDownHeight = 200;
                        comboBox.Height = 30;
                        comboBox.Padding = new Thickness(7, 5, 0, 0);

                        int currentValue = (int)properties[i].GetValue(parentItem, null);
                        Enum[] enumValues = EnumHelper.GetValues(propertyType);
                        foreach (Enum enumValue in enumValues)
                        {
                            int insertedIndex = comboBox.Items.Add(new ComboBoxItemContents(Translation.GetTranslatedString(enumValue, properties[i].PropertyType), enumValue));
                            int enumValueAsInt = (int)Enum.ToObject(propertyType, enumValue);
                            if ((enumValueAsInt & currentValue) != 0)
                                comboBox.SelectedItems.Add(comboBox.Items[insertedIndex]);
                        }
                        comboBox.ItemSelectionChanged += ComboBox_ItemSelectionChanged;
                    }
                    else
                    {
                        ComboBox comboBox = new ComboBox();
                        value = comboBox;
                        comboBox.MaxDropDownHeight = 200;
                        comboBox.Height = 30;
                        comboBox.Padding = new Thickness(7, 5, 0, 0);

                        int currentValue = (int)properties[i].GetValue(parentItem, null);
                        Enum[] enumValues = EnumHelper.GetValues(propertyType);
                        foreach (Enum enumValue in enumValues)
                        {
                            int insertedIndex = comboBox.Items.Add(new ComboBoxItemContents(Translation.GetTranslatedString(enumValue, properties[i].PropertyType), enumValue));
                            int enumValueAsInt = (int)Enum.ToObject(propertyType, enumValue);
                            if (enumValueAsInt == currentValue)
                                comboBox.SelectedIndex = insertedIndex;
                        }
                        comboBox.SelectionChanged += ComboBox_SelectionChanged;
                    }
                }
                else if (propertyType == typeof(string[]))
                {
                    TextBox textBox = new TextBox();
                    value = textBox;
                    textBox.AcceptsReturn = true;
                    if (properties[i].GetValue(parentItem, null) != null)
                    {
                        string[] strings = (string[])properties[i].GetValue(parentItem, null);
                        StringBuilder multilineString = new StringBuilder();
                        foreach (string s in strings)
                        {
                            multilineString.Append(s);
                            multilineString.Append("\r\n");
                        }
                        textBox.Text = multilineString.ToString();
                    }
                    textBox.Height = 160;
                    textBox.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
                    textBox.Padding = new Thickness(5, 5, 0, 0);
                    textBox.TextChanged += TextBox_MultilineTextChanged;
                }
                else if (controllerAttribute.ByteArrayLengths != null)
                {
                    TextBox textBox = new TextBox();
                    value = textBox;
                    byte[] data = null;
                    if (propertyType == typeof(byte[]))
                    {
                        data = (byte[])properties[i].GetValue(parentItem, null);
                    }
                    else if (propertyType == typeof(string))
                    {
                        string hexString = (string)properties[i].GetValue(parentItem, null);
                        data = hexString.ConvertHexStringToByteArray();
                    }
                    if (data == null && controllerAttribute.ByteArrayAllowNull == false)
                    {
                        List<int> byteArrayLengths = new List<int>(controllerAttribute.ByteArrayLengths);
                        byteArrayLengths.Sort();
                        data = new byte[byteArrayLengths[0]];
                    }
                    if (data != null && data.Length > 0)
                        textBox.Text = BitConverter.ToString(data).Replace("-", " ");
                    textBox.Height = 30;
                    textBox.Padding = new Thickness(5, 5, 0, 0);
                    textBox.TextChanged += TextBox_HexChanged;
                }
                else if (properties[i].Name == "CardFormatIds")
                {
                    CheckComboBox comboBox = new CheckComboBox();
                    value = comboBox;
                    comboBox.MaxDropDownHeight = 200;
                    comboBox.Height = 30;
                    comboBox.Padding = new Thickness(7, 5, 0, 0);

                    int[] selectedCardFormats = (int[])properties[i].GetValue(parentItem, null);
                    List<ComboBoxItemContents> availableCardFormats = ControllerConfigurationManager.GetAvailableCardFormats();
                    foreach (ComboBoxItemContents cardFormat in availableCardFormats)
                    {
                        int insertedIndex = comboBox.Items.Add(cardFormat);
                        if (selectedCardFormats != null && selectedCardFormats.Contains((int)cardFormat.Value))
                            comboBox.SelectedItems.Add(comboBox.Items[insertedIndex]);
                    }
                    comboBox.ItemSelectionChanged += ComboBox_CardFormatSelectionChanged;
                }
                else if (properties[i].Name == "EnterIntoPresenceZoneIds" || properties[i].Name == "ExitOutOfPresenceZoneIds")
                {
                    CheckComboBox comboBox = new CheckComboBox();
                    value = comboBox;
                    comboBox.MaxDropDownHeight = 200;
                    comboBox.Height = 30;
                    comboBox.Padding = new Thickness(7, 5, 0, 0);

                    int[] selectedPresenceZones = (int[])properties[i].GetValue(parentItem, null);
                    List<ComboBoxItemContents> availablePresenceZones = ControllerConfigurationManager.GetAvailablePresenceZones();
                    foreach (ComboBoxItemContents presenceZones in availablePresenceZones)
                    {
                        int insertedIndex = comboBox.Items.Add(presenceZones);
                        if (selectedPresenceZones != null && selectedPresenceZones.Contains((int)presenceZones.Value))
                            comboBox.SelectedItems.Add(comboBox.Items[insertedIndex]);
                    }
                    comboBox.ItemSelectionChanged += CardProfile_ComboBox_IntArraySelectionChanged;
                }
                else if (properties[i].Name == "DoorIds")
                {
                    CheckComboBox comboBox = new CheckComboBox();
                    value = comboBox;
                    comboBox.MaxDropDownHeight = 200;
                    comboBox.Height = 30;
                    comboBox.Padding = new Thickness(7, 5, 0, 0);

                    int[] selectedDoors = (int[])properties[i].GetValue(parentItem, null);
                    List<ComboBoxItemContents> availableDoors = ControllerConfigurationManager.GetAllDoors();
                    foreach (ComboBoxItemContents door in availableDoors)
                    {
                        int insertedIndex = comboBox.Items.Add(door);
                        if (selectedDoors != null && selectedDoors.Contains((int)door.Value))
                            comboBox.SelectedItems.Add(comboBox.Items[insertedIndex]);
                    }
                    comboBox.ItemSelectionChanged += ComboBox_IntArraySelectionChanged;
                }
                else if (properties[i].Name == "VaultControllerInterlocks")
                {
                    CheckComboBox comboBox = new CheckComboBox();
                    value = comboBox;
                    comboBox.MaxDropDownHeight = 200;
                    comboBox.Height = 30;
                    comboBox.Padding = new Thickness(7, 5, 0, 0);

                    int[] selectedVaultControllers = (int[])properties[i].GetValue(parentItem, null);
                    List<ComboBoxItemContents> availableVaultControllers = ControllerConfigurationManager.GetAllVaultControllers();
                    foreach (var vc in availableVaultControllers)
                    {
                        int insertedIndex = comboBox.Items.Add(vc);
                        if (selectedVaultControllers != null && selectedVaultControllers.Contains((int)vc.Value))
                            comboBox.SelectedItems.Add(comboBox.Items[insertedIndex]);
                    }
                    comboBox.ItemSelectionChanged += ComboBox_IntArraySelectionChanged;
                }
                else
                {
                    TextBox textBox = new TextBox();
                    value = textBox;
                    if (properties[i].GetValue(parentItem, null) != null)
                        textBox.Text = properties[i].GetValue(parentItem, null).ToString();
                    textBox.Height = 30;
                    textBox.Padding = new Thickness(5, 5, 0, 0);
                    textBox.TextChanged += TextBox_TextChanged;
                }
                value.SetValue(Grid.RowProperty, i);
                value.SetValue(Grid.ColumnProperty, 1);
                value.Margin = marginThickness;
                value.Name = properties[i].Name;
                value.Resources.Add("Property", properties[i]);
                value.Resources.Add("ParentItem", parentItem);
                grid.Children.Add(value);
            }
        }

        #endregion

        private void DatePicker_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            DatePicker frameworkElement = (DatePicker)sender;
            frameworkElement.IsDropDownOpen = !frameworkElement.IsDropDownOpen;
        }

        private void createPointOnParentComboBox(List<ComboBoxItemContents> points, int currentPoint, Grid grid, object row, object property, object parentItem)
        {
            ComboBox comboBox = new ComboBox();
            comboBox.MaxDropDownHeight = 1;
            comboBox.Height = 30;
            comboBox.Padding = new Thickness(7, 5, 0, 0);

            // Add available points to the combo box
            comboBox.ItemsSource = points;
            comboBox.SelectedIndex = currentPoint - 1;
            comboBox.SelectionChanged += ComboBox_SelectionChanged;
            // The following is to disable the unavailable points
            comboBox.ItemContainerGenerator.StatusChanged += ItemContainerGenerator_StatusChanged;
            comboBox.IsDropDownOpen = true;
            comboBoxes[comboBox.ItemContainerGenerator] = comboBox;

            comboBox.SetValue(Grid.RowProperty, row);
            comboBox.SetValue(Grid.ColumnProperty, 1);
            comboBox.Margin = new Thickness(5);
            comboBox.Resources.Add("Property", property);
            comboBox.Resources.Add("ParentItem", parentItem);
            grid.Children.Add(comboBox);
            pointOnParentComboBox = comboBox;
        }

        private Dictionary<ItemContainerGenerator, ComboBox> comboBoxes = new Dictionary<ItemContainerGenerator, ComboBox>();
        private void ItemContainerGenerator_StatusChanged(object sender, EventArgs e)
        {
            ItemContainerGenerator generator = sender as ItemContainerGenerator;
            if (generator.Status == System.Windows.Controls.Primitives.GeneratorStatus.ContainersGenerated)
            {
                foreach (ComboBoxItemContents item in generator.Items)
                {
                    if (item.Enabled == false)
                    {
                        ComboBoxItem container = (ComboBoxItem)generator.ContainerFromItem(item);
                        container.IsEnabled = false;
                    }
                }
                Dispatcher.InvokeAsync(() => comboBoxes[generator].IsDropDownOpen = false);
                Dispatcher.InvokeAsync(() => comboBoxes[generator].MaxDropDownHeight = 200);
                // Restore focus
                Dispatcher.InvokeAsync(() => Keyboard.Focus(NodeTreeView.Instance.NodeTree));
            }
        }

#region Value changes
        private void ComboBox_CardFormatSelectionChanged(object sender, ItemSelectionChangedEventArgs e)
        {
            CheckComboBox frameworkElement = (CheckComboBox)sender;
            if (frameworkElement.SelectedItems.Count > 4)
            {
                PropertyInfo property = (PropertyInfo)frameworkElement.Resources["Property"];
                object parentItem = frameworkElement.Resources["ParentItem"];
                int[] selectedCardFormats = (int[])property.GetValue(parentItem, null);
                frameworkElement.SelectedItems.Clear();
                foreach (ComboBoxItemContents cardFormat in frameworkElement.Items)
                {
                    if (selectedCardFormats != null && selectedCardFormats.Contains((int)cardFormat.Value))
                        frameworkElement.SelectedItems.Add(cardFormat);
                }
                return;
            }

            List<int> value = new List<int>();
            foreach (ComboBoxItemContents item in frameworkElement.SelectedItems)
            {
                value.Add((int)item.Value);
            }
            setValue(frameworkElement, value.ToArray());
        }

        private void CardProfile_ComboBox_IntArraySelectionChanged(object sender, ItemSelectionChangedEventArgs e)
        {
            CheckComboBox frameworkElement = (CheckComboBox)sender;
            if (frameworkElement.SelectedItems.Count > 4)
            {
                PropertyInfo property = (PropertyInfo)frameworkElement.Resources["Property"];
                object parentItem = frameworkElement.Resources["ParentItem"];
                int[] selectedValues = (int[])property.GetValue(parentItem, null);
                frameworkElement.SelectedItems.Clear();
                foreach (ComboBoxItemContents cardFormat in frameworkElement.Items)
                {
                    if (selectedValues != null && selectedValues.Contains((int)cardFormat.Value))
                        frameworkElement.SelectedItems.Add(cardFormat);
                }
                return;
            }

            List<int> value = new List<int>();
            foreach (ComboBoxItemContents item in frameworkElement.SelectedItems)
            {
                value.Add((int)item.Value);
            }
            setValue(frameworkElement, value.ToArray());
        }

        private void ComboBox_IntArraySelectionChanged(object sender, ItemSelectionChangedEventArgs e)
        {
            CheckComboBox frameworkElement = (CheckComboBox)sender;
            List<int> value = new List<int>();
            foreach (ComboBoxItemContents item in frameworkElement.SelectedItems)
            {
                value.Add((int)item.Value);
            }
            setValue(frameworkElement, value.ToArray());
        }

        private void DatePicker_SelectedStartDateChanged(object sender, SelectionChangedEventArgs e)
        {
            DatePicker frameworkElement = (DatePicker)sender;
            DateTime dateTime = frameworkElement.SelectedDate.Value;
            if (frameworkElement.SelectedDate.HasValue)
                setValue(frameworkElement, new DateTime(dateTime.Year, dateTime.Month, dateTime.Day, 0, 0, 0));
        }

        private void DatePicker_SelectedEndDateChanged(object sender, SelectionChangedEventArgs e)
        {
            DatePicker frameworkElement = (DatePicker)sender;
            DateTime dateTime = frameworkElement.SelectedDate.Value;
            if (frameworkElement.SelectedDate.HasValue)
                setValue(frameworkElement, new DateTime(dateTime.Year, dateTime.Month, dateTime.Day, 23, 59, 59));
        }

        private void TimeSpanUpDown_ValueChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            TimeSpanUpDown frameworkElement = (TimeSpanUpDown)sender;
            PropertyInfo property = (PropertyInfo)frameworkElement.Resources["Property"];
            if (property.PropertyType == typeof(DateTime))
            {
                DateTime time = new DateTime(2000, 1, 1, 0, 0, 0);
                if (frameworkElement.Value.HasValue)
                    time += frameworkElement.Value.Value;
                setValue(frameworkElement, time);
            }
            else
            {
                setValue(frameworkElement, frameworkElement.Value);
            }
        }

        private void IpAddressControl_TextChanged(object sender, TextChangedEventArgs e)
        {
            IPAddressControl frameworkElement = (IPAddressControl)sender;
            IPAddress ipAddress;
            if (IPAddress.TryParse(frameworkElement.Text, out ipAddress) && ipAddress.Address != 0)
            {
                setValue(frameworkElement, frameworkElement.Text);
            }
            else
            {
                PropertyInfo property = (PropertyInfo)frameworkElement.Resources["Property"];
                setValue(frameworkElement, getDefaultValue(property));
            }
        }

        private void ComboBox_ItemSelectionChanged(object sender, ItemSelectionChangedEventArgs e)
        {
            CheckComboBox frameworkElement = (CheckComboBox)sender;
            int value = 0;
            PropertyInfo property = (PropertyInfo)frameworkElement.Resources["Property"];
            foreach (ComboBoxItemContents item in frameworkElement.SelectedItems)
            {
                int enumValueAsInt = (int)Enum.ToObject(property.PropertyType, item.Value);
                value |= enumValueAsInt;
            }
            setValue(frameworkElement, value);
        }

        private void TxtPasswordbox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            PasswordRevealBox frameworkElement = (PasswordRevealBox)sender;
            PropertyInfo property = (PropertyInfo)frameworkElement.Resources["Property"];

            if (property.PropertyType == typeof(int))
            {
                int pin;
                if (int.TryParse(frameworkElement.Password, out pin))
                {
                    setValue(frameworkElement, pin);
                }
                else
                {
                    object parentItem = frameworkElement.Resources["ParentItem"];
                    int previousValue = (int)property.GetValue(parentItem, null);
                    frameworkElement.Password = previousValue.ToString();
                }
            }
            else
            {
                setValue(frameworkElement, frameworkElement.Password);
            }
        }

        private void TextBox_HexChanged(object sender, TextChangedEventArgs e)
        {
            TextBox frameworkElement = (TextBox)sender;
            string textValue = frameworkElement.Text;
            textValue = textValue.Replace("-", "").Replace("0x", "").Replace(",", "").Replace(" ", "").ToUpper();
            int cursorPosition = frameworkElement.CaretIndex;

            PropertyInfo property = (PropertyInfo)frameworkElement.Resources["Property"];
            object parentItem = frameworkElement.Resources["ParentItem"];
            ControllerAttribute controllerAttribute = GetControllerAttribute(property);

            bool successfullyParsed = true;
            foreach (char c in textValue)
            {
                if (c >= '0' && c <= '9')
                    continue;
                if (c >= 'A' && c <= 'F')
                    continue;
                successfullyParsed = false;
                break;
            }
            byte[] data = null;
            if (successfullyParsed)
            {
                if (textValue.Length == 0)
                {
                    if (controllerAttribute.ByteArrayAllowNull == true)
                        data = null;
                    else
                        data = new byte[0];
                }
                else
                {
                    List<int> byteArrayLengths = new List<int>(controllerAttribute.ByteArrayLengths);
                    byteArrayLengths.Sort();

                    int desiredLength = 0;
                    foreach (int byteArrayLength in byteArrayLengths)
                    {
                        desiredLength = (byteArrayLength * 2);
                        if (textValue.Length <= desiredLength)
                            break;
                        if (textValue.Length == (desiredLength + 1) && cursorPosition != frameworkElement.Text.Length)
                        {
                            break;
                        }
                    }

                    if (textValue.Length < desiredLength)
                    {
                        while (textValue.Length < desiredLength)
                        {
                            textValue = textValue + '0';
                        }
                    }
                    else if (textValue.Length > desiredLength)
                    {
                        textValue = textValue.Substring(0, desiredLength);
                    }
                }

                data = new byte[textValue.Length / 2];
                for (int i = 0; i < data.Length; i++)
                {
                    data[i] = byte.Parse(textValue.Substring(i * 2, 2), NumberStyles.HexNumber);
                }
            }

            if (successfullyParsed)
            {
                if (property.PropertyType == typeof(byte[]))
                    setValue(frameworkElement, data);
                else if (property.PropertyType == typeof(string))
                    setValue(frameworkElement, BitConverter.ToString(data).Replace("-",""));
            }

            if (property.PropertyType == typeof(byte[]))
            {
                data = (byte[])property.GetValue(parentItem, null);
            }
            else if (property.PropertyType == typeof(string))
            {
                string hexString = (string)property.GetValue(parentItem, null);
                data = hexString.ConvertHexStringToByteArray();
            }

            if (data == null && controllerAttribute.ByteArrayAllowNull == false)
            {
                List<int> byteArrayLengths = new List<int>(controllerAttribute.ByteArrayLengths);
                byteArrayLengths.Sort();
                data = new byte[byteArrayLengths[0]];
            }
            if (data != null && data.Length > 0)
                frameworkElement.Text = BitConverter.ToString(data).Replace("-", " ");
            else
                frameworkElement.Text = string.Empty;
            if (((cursorPosition - 1) % 3) != 0)
                cursorPosition++;
            frameworkElement.CaretIndex = cursorPosition;
        }

        private void TextBox_MultilineTextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox frameworkElement = (TextBox)sender;
            string value = frameworkElement.Text;
            value = value.Replace("\n", "\r").Replace("\r\r", "\r");
            string[] strings = value.Split(new char[] { '\r' }, StringSplitOptions.RemoveEmptyEntries);
            setValue(frameworkElement, strings);
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox frameworkElement = (TextBox)sender;
            setValue(frameworkElement, frameworkElement.Text);
        }

        private void CustomCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox frameworkElement = (CheckBox)sender;
            setValue(frameworkElement, frameworkElement.IsChecked);
        }

        private void LongUpDown_ValueChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            LongUpDown frameworkElement = (LongUpDown)sender;
            setValue(frameworkElement, frameworkElement.Value);
        }

        private void IntegerUpDown_ValueChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            IntegerUpDown frameworkElement = (IntegerUpDown)sender;
            setValue(frameworkElement, frameworkElement.Value);
        }

        private void DoubleUpDown_MilliValueChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            DoubleUpDown frameworkElement = (DoubleUpDown)sender;
            int milliValue;
            if (frameworkElement.Value == null)
            {
                milliValue = 0;
            }
            else
            {
                milliValue = (int)(frameworkElement.Value * 1000);
            }
            setValue(frameworkElement, milliValue);
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox frameworkElement = (ComboBox)sender;
            PropertyInfo property = (PropertyInfo)frameworkElement.Resources["Property"];

            if (property.Name == "ExpansionCardSlot")
            {
                int oldSlot = (configurationItem as ExpansionCardDeviceConfigurationBase).ExpansionCardSlot;
                int newSlot = (int)((ComboBoxItemContents)frameworkElement.SelectedItem).Value;

                Pacom8003PhysicalPort oldPort = Pacom8003PhysicalPort.ExpansionSlot1;
                Pacom8003PhysicalPort newPort = Pacom8003PhysicalPort.ExpansionSlot1;
                if (oldSlot == 2)
                    oldPort = Pacom8003PhysicalPort.ExpansionSlot2;
                if (newSlot == 2)
                    newPort = Pacom8003PhysicalPort.ExpansionSlot2;

                foreach (Port8003ConfigurationBase port in ConfigurationManager.Ports.Values)
                {
                    if (port.PortNumberOnParent == oldPort)
                    {
                        port.PortNumberOnParent = newPort;
                        break;
                    }
                }
            }

            if (frameworkElement.SelectedItem != null)
                setValue((FrameworkElement)sender, ((ComboBoxItemContents)frameworkElement.SelectedItem).Value);

            if (property.Name == "ReaderInId" || property.Name == "ReaderOutId")
                NodeTreeView.Instance.RefreshConfigurationView();
            //else if (property.Name == "ParentDeviceId")
            //{
            //    NodeConfiguration configurationNode = configurationItem as NodeConfiguration;
            //    if (configurationNode != null)
            //    {
            //        Type configurationType = configurationNode.GetType();
            //        int parentDeviceId = configurationNode.ParentDeviceId;
            //        ConfigurationManager.Remove(configurationNode);
            //        ConfigurationManager.AddConfiguration(configurationType, parentDeviceId);
            //    }
            //}
        }

        private List<NodeConfiguration> getDescendents(NodeConfiguration parent)
        {
            List<NodeConfiguration> descendents = new List<NodeConfiguration>();

            if (parent is Port8003RS485AperioPortConfiguration)
            {
                // Aperio RS485 port is a special case, where we can also disable the dependent (hidden) driver, doors and readers
                Port8003RS485AperioPortConfiguration port = parent as Port8003RS485AperioPortConfiguration;
                foreach (DeviceConfigurationBase node in ConfigurationManager.Devices.Values)
                {
                    AperioDriverConfiguration ap = node as AperioDriverConfiguration;
                    if (ap != null &&
                        ap.PortNumberOnParent == port.PortNumberOnParent &&
                        ap.Enabled == parent.Enabled)
                    {
                        descendents.Add(node);
                        descendents.AddRange(getDescendents(node));
                    }
                }
                return descendents;
            }

            if (parent is DeviceConfigurationBase == false && 
                parent is ExpansionCardDeviceConfigurationBase == false)
            {
                return descendents;
            }

            // All collections of items that might have our parent device
            var nodeCollections = new IEnumerable<NodeConfiguration>[]
                                            {
                                                    ConfigurationManager.Devices.Values,
                                                    ConfigurationManager.Doors.Values,
                                                    ConfigurationManager.ExpansionCards.Values,
                                                    ConfigurationManager.Inputs.Values,
                                                    ConfigurationManager.Macros.Values,
                                                    ConfigurationManager.Outputs.Values,
                                                    ConfigurationManager.Ports.Values,
                                                    ConfigurationManager.Readers.Values,
                                                    ConfigurationManager.UnisonReaders.Values
                                            };

            foreach (var nodeCollection in nodeCollections)
            {
                foreach (var node in nodeCollection)
                {
                    if (node.ParentDeviceId == parent.Id && node.Enabled == parent.Enabled)
                    {
                        descendents.Add(node);
                        descendents.AddRange(getDescendents(node));
                    }
                }
            }
            return descendents;
        }

        private void setValue(FrameworkElement value, object newValue)
        {
            App.ConfigurationModified = true;
            PropertyInfo property = (PropertyInfo)value.Resources["Property"];
            object parentItem = value.Resources["ParentItem"];

            bool setDescendentsEnabledState = parentItem is NodeConfiguration && property.Name == "Enabled";
            if (setDescendentsEnabledState == true)
            {
                List<NodeConfiguration> descendentNodes = getDescendents(parentItem as NodeConfiguration);
                if (descendentNodes.Count > 0)
                {
                    bool enable = (bool)newValue;
                    string message = enable ? Translation.GetTranslatedError(ErrorMessage.EnableChildNodes) : Translation.GetTranslatedError(ErrorMessage.DisableChildNodes);

                    MessageBoxResult result = Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                            string.Format(message, descendentNodes.Count),
                            Translation.GetTranslatedError(ErrorMessage.Warning),
                            MessageBoxButton.YesNoCancel);

                    if (result == MessageBoxResult.Cancel)
                    {
                        NodeTreeView.Instance.RefreshConfigurationView();
                        return;
                    }

                    if (result == MessageBoxResult.Yes)
                    {
                        foreach (NodeConfiguration descendent in descendentNodes)
                        {
                            descendent.Enabled = enable;
                        }
                    }
                }
            }

            newValue = preSetValue(value, property, newValue);
            property.SetValue(parentItem, newValue);

            if (property.Name != "RevisionId")
                configurationItem.RevisionId = ConfigurationBase.CreatedLocallyRevisionId;

            if (property.Name == "Enabled" || property.Name == "Name")
            {
                NodeTreeView.Instance.RefreshTree();
            }
            else if (property.Name == "ParentDeviceId" && pointOnParentComboBox != null)
            {
                foreach (Grid grid in categoryGrids.Values)
                {
                    if (grid.Children.Contains(pointOnParentComboBox))
                    {
                        grid.Children.Remove(pointOnParentComboBox);
                        comboBoxes.Remove(pointOnParentComboBox.ItemContainerGenerator);

                        NodeConfiguration node = parentItem as NodeConfiguration;
                        int currentParent = node.ParentDeviceId;
                        int currentPoint = 0;

                        property = (PropertyInfo)pointOnParentComboBox.Resources["Property"];
                        property.SetValue(parentItem, currentPoint);
                        List<ComboBoxItemContents> points = ControllerConfigurationManager.GetAvailableDevicePoints(currentParent, configurationItem.GetType(), currentPoint);
                        for (int i = 0; i < points.Count; i++)
                        {
                            if (points[i].Enabled)
                            {
                                currentPoint = (int)points[i].Value;
                                break;
                            }
                        }
                        property.SetValue(parentItem, currentPoint);

                        createPointOnParentComboBox(points, currentPoint, grid, pointOnParentComboBox.GetValue(Grid.RowProperty), property, parentItem);

                        ConfigurationManager.UpdateName(node, currentPoint);
                        NodeTreeView.Instance.RefreshTree();

                        //else if (property.Name == "ParentDeviceId")
                        //{
                        //    NodeConfiguration configurationNode = configurationItem as NodeConfiguration;
                        //    if (configurationNode != null)
                        //    {
                        //        Type configurationType = configurationNode.GetType();
                        //        int parentDeviceId = configurationNode.ParentDeviceId;
                        //        ConfigurationManager.Remove(configurationNode);
                        //        ConfigurationManager.AddConfiguration(configurationType, parentDeviceId);
                        //    }
                        //}

                        break;
                    }
                }
            }

            postSetValue(value, property, newValue);
        }
#endregion

        protected Grid addExpander(Grid parentGrid, string displayName, bool expanded, bool includeDeleteButton, string expanderName, string resourceKey = null, object resourceValue = null)
        {
            Dictionary<string, bool> expandedCategories;
            if (expandedCategoriesDictionary.TryGetValue(ExpanderTypeName, out expandedCategories))
            {
                bool tempExpanded;
                if (expandedCategories.TryGetValue(expanderName, out tempExpanded))
                    expanded = tempExpanded;
            }
            ResourceDictionary style = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\ExpanderStyle.xaml", UriKind.Relative));

            Grid headerGrid = new Grid { Margin = new Thickness(1) };
            headerGrid.ColumnDefinitions.Add(new ColumnDefinition());

            TextBlock headerLabel = new TextBlock
            {
                Text = displayName,
                Padding = new Thickness(0, 2, 0, 0)
            };
            headerLabel.SetValue(Grid.ColumnProperty, 0);
            headerGrid.Children.Add(headerLabel);

            if (includeDeleteButton)
            {
                headerGrid.ColumnDefinitions.Add(new ColumnDefinition());
                Button headerButton = new Button();
                headerButton.SetValue(Grid.ColumnProperty, 1);
                headerButton.HorizontalAlignment = HorizontalAlignment.Right;
                headerButton.Width = 13;
                headerButton.Margin = new Thickness(4);
                headerButton.Padding = new Thickness(2);

                ResourceDictionary buttonStyle = (ResourceDictionary)Application.LoadComponent(new Uri(@"\Styles\CrossButton.xaml", UriKind.Relative));
                headerButton.Style = (Style)buttonStyle["CrossButtonStyle"];
                headerButton.Click += DeleteButton_Click;
                headerGrid.Children.Add(headerButton);
            }

            parentGrid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            Expander expander = new CustomExpander()  { Header = headerGrid, Name = expanderName };
            if (resourceKey != null)
                expander.Resources.Add(resourceKey, resourceValue);

            expander.Content = new Grid();
            expander.IsExpanded = expanded;
            expander.SetValue(Grid.RowProperty, (parentGrid.RowDefinitions.Count - 1));
            expander.Style = (Style)style["ExpanderStyle1"];
            parentGrid.Children.Add(expander);
            return expander.Content as Grid;
        }

        private static int compareProperties(PropertyInfo property1, PropertyInfo property2)
        {
            int property1Order = 0;
            int property2Order = 0;
            ControllerAttribute controllerAttribute;

            controllerAttribute = GetControllerAttribute(property1);
            if (controllerAttribute != null)
                property1Order = controllerAttribute.Order;
            controllerAttribute = GetControllerAttribute(property2);
            if (controllerAttribute != null)
                property2Order = controllerAttribute.Order;

            if (property1Order != property2Order)
                return property1Order.CompareTo(property2Order);

            return Translation.GetTranslatedString(property1).CompareTo
                (Translation.GetTranslatedString(property2));
        }

        private static Dictionary<PropertyInfo, ControllerAttribute> controllerAttributeDictionary = new Dictionary<PropertyInfo, ControllerAttribute>();
        public static ControllerAttribute GetControllerAttribute(PropertyInfo propertyInfo)
        {
            ControllerAttribute controllerAttribute;
            if (controllerAttributeDictionary.TryGetValue(propertyInfo, out controllerAttribute))
                return controllerAttribute;

            List <Attribute> customAttributes = propertyInfo.GetCustomAttributes().ToList();
            foreach (Attribute customAttribute in customAttributes)
            {
                controllerAttribute = customAttribute as ControllerAttribute;
                if (controllerAttribute != null)
                {
                    controllerAttributeDictionary[propertyInfo] = controllerAttribute;
                    return controllerAttribute;
                }
            }
            controllerAttributeDictionary[propertyInfo] = null;
            return null;
        }

        private static Dictionary<PropertyInfo, object> defaultAttributeDictionary = new Dictionary<PropertyInfo, object>();
        private static object getDefaultValue(PropertyInfo propertyInfo)
        {
            object defaultValue;
            if (defaultAttributeDictionary.TryGetValue(propertyInfo, out defaultValue))
                return defaultValue;

            List<Attribute> customAttributes = propertyInfo.GetCustomAttributes().ToList();
            foreach (Attribute customAttribute in customAttributes)
            {
                DefaultValueAttribute defaultValueAttribute = customAttribute as DefaultValueAttribute;
                if (defaultValueAttribute != null)
                {
                    defaultAttributeDictionary[propertyInfo] = defaultValueAttribute.Value;
                    return defaultValueAttribute.Value;
                }
            }
            defaultAttributeDictionary[propertyInfo] = null;
            return null;
        }

        private static Dictionary<Type, bool> flagsAttributeDictionary = new Dictionary<Type, bool>();
        private static bool hasFlagsAttribute(Type enumType)
        {
            bool flagsAttributeFound = false;
            if (flagsAttributeDictionary.TryGetValue(enumType, out flagsAttributeFound))
                return flagsAttributeFound;

            List<Attribute> customAttributes = enumType.GetCustomAttributes().ToList();
            foreach (Attribute customAttribute in customAttributes)
            {
                FlagsAttribute flagsAttribute = customAttribute as FlagsAttribute;
                if (flagsAttribute != null)
                {
                    flagsAttributeFound = true;
                }
            }
            flagsAttributeDictionary[enumType] = flagsAttributeFound;
            return flagsAttributeFound;
        }

        private static Dictionary<PropertyInfo, RangeAttribute> rangeAttributeDictionary = new Dictionary<PropertyInfo, RangeAttribute>();
        private static RangeAttribute getRangeAttribute(PropertyInfo propertyInfo)
        {
#if DEBUG
            if (App.SkipValidate)
                return new RangeAttribute(int.MinValue, int.MaxValue);
#endif
            RangeAttribute rangeAttribute;
            if (rangeAttributeDictionary.TryGetValue(propertyInfo, out rangeAttribute))
                return rangeAttribute;

            rangeAttribute = null;
            List<Attribute> customAttributes = propertyInfo.GetCustomAttributes().ToList();
            foreach (Attribute customAttribute in customAttributes)
            {
                rangeAttribute = customAttribute as RangeAttribute;
                if (rangeAttribute != null)
                {
                    break;
                }
            }
            if (rangeAttribute == null)
                rangeAttribute = new RangeAttribute(int.MinValue, int.MaxValue);
            rangeAttributeDictionary[propertyInfo] = rangeAttribute;
            return rangeAttribute;
        }

        protected FrameworkElement getUIElement(string propertyName, Grid categoryGrid = null)
        {
            List<Grid> categoryGridsToSearch = new List<Grid>();
            if (categoryGrid == null)
                categoryGridsToSearch.AddRange(categoryGrids.Values);
            else
                categoryGridsToSearch.Add(categoryGrid);

            foreach (Grid grid in categoryGridsToSearch)
            {
                foreach (FrameworkElement child in grid.Children)
                {
                    if (child.Name == propertyName)
                    {
                        return child;
                    }
                }
            }
            return null;
        }

        protected virtual string getLabelText(PropertyInfo propertyInfo)
        {
            return Translation.GetTranslatedString(propertyInfo);
        }

        protected virtual ControllerAttribute updateControllerAttribute(PropertyInfo propertyInfo, ControllerAttribute controllerAttribute)
        {
            return controllerAttribute;
        }
        protected virtual object preSetValue(FrameworkElement frameworkElement, PropertyInfo property, object newValue)
        {
            return newValue;
        }

        protected virtual void postSetValue(FrameworkElement frameworkElement, PropertyInfo property, object newValue)
        {
        }

        protected virtual void addAdditionalElements(SortedDictionary<DisplayCategory, List<PropertyInfo>> categorisedProperties)
        {
        }

        protected virtual void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}
