﻿using System;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class UserGroupView : ConfigurationViewBase<Group8003Configuration>
    {
        public UserGroupView(Group8003Configuration userGroup, NodeTreeElement nodeTreeElement) : base(userGroup, nodeTreeElement)
        {
            createDefaultView(true);
        }

        protected override void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.Groups.Remove(configurationItem.Id);
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(null);
        }
    }
}
