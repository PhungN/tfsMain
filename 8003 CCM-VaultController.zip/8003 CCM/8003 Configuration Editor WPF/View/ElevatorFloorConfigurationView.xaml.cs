﻿using Pacom.Configuration.ConfigurationCommon;
using System.Collections.Generic;
using System.Windows.Controls;

namespace Pacom.ConfigurationEditor.WPF.View
{
    /// <summary>
    /// Interaction logic for ElevatorFloorConfigurationView.xaml
    /// </summary>
    public partial class ElevatorFloorConfigurationView : Grid
    {
        private ElevatorFloor8003Configuration configuration;
        public ElevatorFloorConfigurationView(ElevatorFloor8003Configuration elevatorFloorConfiguration)
        {
            configuration = elevatorFloorConfiguration;
            InitializeComponent();
            this.DataContext = configuration;

            int currentSchedule = configuration.FloorScheduleId;
            List<ComboBoxItemContents> schedules = ControllerConfigurationManager.GetAvailableSchedules();
            foreach (ComboBoxItemContents schedule in schedules)
            {
                int insertedIndex = floorScheduleList.Items.Add(schedule);
                if ((int)schedule.Value == currentSchedule)
                    floorScheduleList.SelectedIndex = insertedIndex;
            }
        }

        private void floorScheduleList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox comboBox = sender as ComboBox;
            if (comboBox != null)
            {
                ComboBoxItemContents selectedItem = comboBox.SelectedItem as ComboBoxItemContents;
                if (selectedItem != null)
                {
                    configuration.FloorScheduleId = (int)selectedItem.Value;
                }
            }
        }
    }
}
