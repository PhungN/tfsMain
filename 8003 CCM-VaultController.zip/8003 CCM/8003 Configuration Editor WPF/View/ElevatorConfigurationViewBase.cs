﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.Commands;
using Pacom.Peripheral.Common.Configuration;
using System;

namespace Pacom.ConfigurationEditor.WPF.View
{
    public class ElevatorConfigurationViewBase : Grid
    {
        protected static readonly List<int> selectedElevatorDevices = new List<int>();
        protected Elevator8003Configuration elevatorConfiguration;
        public ConfigurationData Configuration { get; private set; }
        public ElevatorConfigurationViewBase()
        {
        }
        public ElevatorConfigurationViewBase(Elevator8003Configuration configuration)
        {
            elevatorConfiguration = configuration;
            Configuration = new ConfigurationData(configuration);
        }

        #region Floor Controller
        protected int[] getFloorAddresses()
        {
            return new int[]
            {
                elevatorConfiguration.ElevatorController1To16Id,
                elevatorConfiguration.ElevatorController17To32Id,
                elevatorConfiguration.ElevatorController33To48Id,
                elevatorConfiguration.ElevatorController49To64Id,
                elevatorConfiguration.ElevatorController65To80Id,
                elevatorConfiguration.ElevatorController81To96Id,
                elevatorConfiguration.ElevatorController97To112Id,
                elevatorConfiguration.ElevatorController113To128Id,
            };
        }

        protected void setFloorControllerAddresses(IEnumerable<ComboBox> comboBoxes)
        {
            var elevatorDevices = ControllerConfigurationManager.GetAvailableElevatorDevices();
            foreach (var comboBox in comboBoxes)
            {
                foreach (var elevatorDevice in elevatorDevices)
                {
                    ComboBoxItem cbi = new ComboBoxItem() { Content = elevatorDevice };
                    comboBox.Items.Add(cbi);
                }
                int id = 0;
                if (int.TryParse(comboBox.Tag as string, out id) == true)
                {
                    int[] elevatorFloorAddress = getFloorAddresses();
                    int deviceAddress = elevatorFloorAddress[id - 1];
                    comboBox.SelectedIndex = getSelectedIndex(deviceAddress, elevatorDevices);
                }
            }
        }

        private int getSelectedIndex(int deviceLoopAddress, List<ComboBoxItemContents> devices)
        {
            for (int i = 0; i < devices.Count; i++)
            {
                int address = (int)devices[i].Value;
                if (address > 0 && address == deviceLoopAddress)
                    return i;
            }
            return 0;
        }

        protected void updateFloorControllerAddressBoxes(IEnumerable<ComboBox> comboBoxes)
        {
            foreach (var comboBox in comboBoxes)
            {
                foreach (ComboBoxItem cbi in comboBox.Items)
                {
                    ComboBoxItemContents cbiContents = cbi.Content as ComboBoxItemContents;
                    if (selectedElevatorDevices.Contains((int)cbiContents.Value) == true)
                        cbi.IsEnabled = false;
                    else
                        cbi.IsEnabled = true;
                }
            }
        }

        protected bool updateFloorControllerAddress(ComboBox comboBox)
        {
            if (comboBox != null)
            {
                ComboBoxItem cbi = comboBox.SelectedItem as ComboBoxItem;
                if (cbi != null)
                {
                    ComboBoxItemContents cbiContents = cbi.Content as ComboBoxItemContents;
                    if (cbiContents != null)
                    {
                        int[] elevatorFloorAddress = getFloorAddresses();
                        int id = 0;
                        if (int.TryParse(comboBox.Tag as string, out id) == true && id > 0)
                        {
                            int lastAddress = elevatorFloorAddress[id - 1];
                            if (lastAddress > 0)
                                selectedElevatorDevices.Remove(lastAddress);
                            int address = (int)cbiContents.Value;
                            if (address > 0)
                                selectedElevatorDevices.Add(address);
                            switch (id)
                            {
                                case 1: elevatorConfiguration.ElevatorController1To16Id = address; break;
                                case 2: elevatorConfiguration.ElevatorController17To32Id = address; break;
                                case 3: elevatorConfiguration.ElevatorController33To48Id = address; break;
                                case 4: elevatorConfiguration.ElevatorController49To64Id = address; break;
                                case 5: elevatorConfiguration.ElevatorController65To80Id = address; break;
                                case 6: elevatorConfiguration.ElevatorController81To96Id = address; break;
                                case 7: elevatorConfiguration.ElevatorController97To112Id = address; break;
                                case 8: elevatorConfiguration.ElevatorController113To128Id = address; break;
                            }

                            return true;
                        }
                    }
                }
            }
            return false;
        }

        protected void onFloorControllerAddressSelectionChange(ComboBox comboBox)
        {
            if (updateFloorControllerAddress(comboBox) == true)
            {
                updateFloorControllerAddressBoxes(findLogicalChildren<ComboBox>(comboBox.Parent));
            }
        }

        public static void RemoveSelectedFloorControllerAddress(Elevator8003Configuration config)
        {
            var addressess = new int[]
            {
                config.ElevatorController1To16Id,
                config.ElevatorController17To32Id,
                config.ElevatorController33To48Id,
                config.ElevatorController49To64Id,
                config.ElevatorController65To80Id,
                config.ElevatorController81To96Id,
                config.ElevatorController97To112Id,
                config.ElevatorController113To128Id,
            };
            foreach(var address in addressess)
            {
                if (address > 0)
                    selectedElevatorDevices.Remove(address);
            }
        }

        private static bool removeControllerAddress(Elevator8003Configuration elevator, int deviceAddress)
        {
            if (elevator.ElevatorController1To16Id == deviceAddress)
                elevator.ElevatorController1To16Id = 0;
            else if (elevator.ElevatorController17To32Id == deviceAddress)
                elevator.ElevatorController17To32Id = 0;
            else if (elevator.ElevatorController33To48Id == deviceAddress)
                elevator.ElevatorController33To48Id = 0;
            else if (elevator.ElevatorController49To64Id == deviceAddress)
                elevator.ElevatorController49To64Id = 0;
            else if (elevator.ElevatorController65To80Id == deviceAddress)
                elevator.ElevatorController65To80Id = 0;
            else if (elevator.ElevatorController81To96Id == deviceAddress)
                elevator.ElevatorController81To96Id = 0;
            else if (elevator.ElevatorController97To112Id == deviceAddress)
                elevator.ElevatorController97To112Id = 0;
            else if (elevator.ElevatorController113To128Id == deviceAddress)
                elevator.ElevatorController113To128Id = 0;
            else
                return false;
            return true;
        }
        public static void RemoveSelectedFloorControllerAddress(int deviceAddress)
        {
            if(ConfigurationManager.UnisonConfigurationPresent)
            {
                foreach (var elevator in ConfigurationManager.UnisonElevators.Values)
                {
                    if(removeControllerAddress(elevator, deviceAddress) == true)
                    {
                        selectedElevatorDevices.Remove(deviceAddress);
                        return;
                    }
                }

            }
            else if(ConfigurationManager.GmsConfigurationPresent)
            {
                foreach(var elevator in ConfigurationManager.LegacyElevators.Values)
                {
                    if (removeControllerAddress(elevator, deviceAddress) == true)
                    {
                        selectedElevatorDevices.Remove(deviceAddress);
                        return;
                    }
                }
            }

        }
        #endregion

        protected IEnumerable<T> findLogicalChildren<T>(DependencyObject dependencyObject) where T : DependencyObject
        {
            if (dependencyObject != null)
            {
                foreach (var rawChild in LogicalTreeHelper.GetChildren(dependencyObject))
                {
                    if (rawChild is DependencyObject)
                    {
                        DependencyObject child = (DependencyObject)rawChild;
                        if (child is T)
                        {
                            yield return (T)child;
                        }

                        foreach (T childOfChild in findLogicalChildren<T>(child))
                        {
                            yield return childOfChild;
                        }
                    }
                }
            }
        }

    }

    public class ConfigurationData
    {
        Elevator8003Configuration configuration;
        public ConfigurationData(Elevator8003Configuration configuration)
        {
            this.configuration = configuration;
            var readers = ControllerConfigurationManager.GetAvailableReaders(configuration.ReaderId);
            var schedules = ControllerConfigurationManager.GetAvailableSchedules();
            var elevatorDevices = ControllerConfigurationManager.GetAvailableElevatorDevices();
            FloorReportings = Translation.GetTranslatedEnum(typeof(ElevatorFloorSelectedReporting));
            Readers = from reader in readers select reader.DisplayName;
            Schedules = from schedule in schedules select schedule.DisplayName;
            ElevatorControllers = from controller in elevatorDevices select controller.DisplayName;
        }

        public IEnumerable<string> Readers { get; private set; }
        public IEnumerable<string> Schedules { get; private set; }
        public IEnumerable<string> ElevatorControllers { get; private set; }
        public List<string> FloorReportings { get; private set; }

        public int SelectedReaderId
        {
            get
            {
                var readers = ControllerConfigurationManager.GetAvailableReaders(configuration.ReaderId);
                for (int i = 0; i < readers.Count; i++)
                {
                    if (int.Parse(readers[i].Value.ToString()) == configuration.ReaderId)
                        return i;
                }
                return 0;
            }
            set
            {
                var readers = ControllerConfigurationManager.GetAvailableReaders(configuration.ReaderId);
                var selectedItem = readers[value];
                configuration.ReaderId = int.Parse(selectedItem.Value.ToString());
            }
        }
        public int SelectedReaderScheduleId
        {
            get
            {
                var schedules = ControllerConfigurationManager.GetAvailableSchedules();
                for (int i = 0; i < schedules.Count; i++)
                {
                    if (int.Parse(schedules[i].Value.ToString()) == configuration.ScheduleId)
                        return i;
                }
                return 0;
            }
            set
            {
                var schedules = ControllerConfigurationManager.GetAvailableSchedules();
                var selectedItem = schedules[value];
                configuration.ScheduleId = int.Parse(selectedItem.Value.ToString());
            }
        }
        public int SelectedFloorReportingId
        {
            get
            {
                return (int)configuration.FloorSelectedReporting;
            }
            set
            {
                configuration.FloorSelectedReporting = (ElevatorFloorSelectedReporting)value;
            }
        }

        public int SelectedFloorReportingScheduleId
        {
            get
            {
                var schedules = ControllerConfigurationManager.GetAvailableSchedules();
                for (int i = 0; i < schedules.Count; i++)
                {
                    if (int.Parse(schedules[i].Value.ToString()) == configuration.FloorSelectedReportingScheduleId)
                        return i;
                }
                return 0;
            }
            set
            {
                var schedules = ControllerConfigurationManager.GetAvailableSchedules();
                var selectedItem = schedules[value];
                configuration.FloorSelectedReportingScheduleId = int.Parse(selectedItem.Value.ToString());
            }
        }

        public int SelectedController1To16Id
        {
            get { return getSelectedElevatorIndex(configuration.ElevatorController1To16Id); }
            set { configuration.ElevatorController1To16Id = getElevatorControllerIdFromIndex(value); }
        }
        public int SelectedController17To32Id
        {
            get { return getSelectedElevatorIndex(configuration.ElevatorController17To32Id); }
            set { configuration.ElevatorController17To32Id = getElevatorControllerIdFromIndex(value); }
        }
        public int SelectedController33To48Id
        {
            get { return getSelectedElevatorIndex(configuration.ElevatorController33To48Id); }
            set { configuration.ElevatorController33To48Id = getElevatorControllerIdFromIndex(value); }
        }
        public int SelectedController49To64Id
        {
            get { return getSelectedElevatorIndex(configuration.ElevatorController49To64Id); }
            set { configuration.ElevatorController49To64Id = getElevatorControllerIdFromIndex(value); }
        }
        public int SelectedController65To80Id
        {
            get { return getSelectedElevatorIndex(configuration.ElevatorController65To80Id); }
            set { configuration.ElevatorController65To80Id = getElevatorControllerIdFromIndex(value); }
        }
        public int SelectedController81To96Id
        {
            get { return getSelectedElevatorIndex(configuration.ElevatorController81To96Id); }
            set { configuration.ElevatorController81To96Id = getElevatorControllerIdFromIndex(value); }
        }
        public int SelectedController97To112Id
        {
            get { return getSelectedElevatorIndex(configuration.ElevatorController97To112Id); }
            set { configuration.ElevatorController97To112Id = getElevatorControllerIdFromIndex(value); }
        }
        public int SelectedController113To128Id
        {
            get { return getSelectedElevatorIndex(configuration.ElevatorController113To128Id); }
            set { configuration.ElevatorController113To128Id = getElevatorControllerIdFromIndex(value); }
        }
        private int getSelectedElevatorIndex(int elevatorControllerId)
        {
            var elevatorControllers = ControllerConfigurationManager.GetAvailableElevatorDevices();
            for (int i = 0; i < elevatorControllers.Count; i++)
            {
                if (int.Parse(elevatorControllers[i].Value.ToString()) == elevatorControllerId)
                    return i;
            }
            return 0;
        }
        private int getElevatorControllerIdFromIndex(int selectedIndex)
        {
            var elevatorControllers = ControllerConfigurationManager.GetAvailableElevatorDevices();
            var selectedItem = elevatorControllers[selectedIndex];
            return int.Parse(selectedItem.Value.ToString());
        }

        public bool EnableApartmentMode
        {
            get { return configuration.EnableApartmentMode; }
            set { configuration.EnableApartmentMode = value; }
        }

        public TimeSpan FloorAccessTime
        {
            get { return configuration.FloorAccessTime; }
            set { configuration.FloorAccessTime = value; }
        }
    }

}
