﻿using System;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
#if DEBUG
using Pacom.Common.CompactFramework.Helpers;
using Pacom.ConfigurationEditor.WPF.DebugOnly;
using Pacom.Core.Attributes;
using Pacom.Core.Contracts;
using Pacom.Peripheral.ConfigurationEditorFor8003;
using Pacom.Peripheral.Protocol;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Xml.Linq;
#endif

namespace Pacom.ConfigurationEditor.WPF.View
{
    /// <summary>
    /// Interaction logic for MenuView.xaml
    /// </summary>
    public partial class MenuView
    {
        public static MenuView Instance { get; private set; }

        public string FileMenu { get; private set; }
        public string OpenMenuItem { get; private set; }
        public string SaveMenuItem { get; private set; }
        public string SaveAsMenuItem { get; private set; }
        public string NewMenuItem { get; private set; }
        public string ExitMenuItem { get; private set; }

        public string MessageConversionMenu { get; private set; }
        public string TemplateFoundItem { get; private set; }
        public string NoTemplateFoundItem { get; private set; }
        public string AddDefaultTemplateItem { get; private set; }
        public string RemoveTemplateItem { get; private set; }
        public string ImportFromFileItem { get; private set; }
        public string ExportToFileItem { get; private set; }

        public string LanguageMenuItem { get; private set; }
        public string LanguageAutoItem { get; private set; }

        public MenuView()
        {
            DataContext = this;
            Instance = this;

            loadMenuTranslations();

            InitializeComponent();

            // Dynamically add language options to the language menu
            foreach (Language language in Translation.Languages)
            {
                MenuItem item = new MenuItem() { Header = language.MenuName, Tag = language };
                item.Click += languageSelect_Click;
                languageMenu.Items.Add(item);
            }

            // Put a checkmark beside the currently selected language
            setSelectedLanguageCheckmark();

#if DEBUG
            MenuItem controllerMenu = new MenuItem() { Header = "_Controller" };
            MenuItem setControllerDetails = new MenuItem() { Header = "Set Controller _Details" };
            MenuItem getConfiguration = new MenuItem() { Header = "_Load Configuration from Controller" };
            MenuItem setConfiguration = new MenuItem() { Header = "_Save Configuration to Controller" };
            MenuItem queryCard = new MenuItem() { Header = "_Query Card" };
            MenuItem viewAllCards = new MenuItem() { Header = "_View All Cards" };
            MenuItem gmsElevatorFloorsAccess = new MenuItem() { Header = "GMS Elevator _Floors Access" };

            setControllerDetails.Click += SetControllerDetails_Click;
            getConfiguration.Click += GetConfiguration_Click;
            setConfiguration.Click += SetConfiguration_Click;
            viewAllCards.Click += ViewAllCards_Click;
            gmsElevatorFloorsAccess.Click += ElevatorFloorsAccess_Click;
            queryCard.Click += QueryCard_Click;

            controllerMenu.Items.Add(setControllerDetails);
            controllerMenu.Items.Add(new Separator());
            controllerMenu.Items.Add(getConfiguration);
            controllerMenu.Items.Add(setConfiguration);
            controllerMenu.Items.Add(new Separator());
            controllerMenu.Items.Add(queryCard);
            controllerMenu.Items.Add(viewAllCards);
            controllerMenu.Items.Add(gmsElevatorFloorsAccess);
            menuBar.Items.Add(controllerMenu);

            MenuItem debugMenu = new MenuItem() { Header = "_Debug" };
            MenuItem remove = new MenuItem() { Header = "_Remove colour" };
            MenuItem skipValidate = new MenuItem() { Header = "_Skip field range validation" };
            MenuItem verifyTranslations = new MenuItem() { Header = "_Verify Translations" };
            MenuItem verifyMessageConversions = new MenuItem() { Header = "Verify _Message Conversions" };
            MenuItem programSerialNumber = new MenuItem() { Header = "_Program Serial Number" };
            MenuItem firmwareUpdate = new MenuItem() { Header = "_Firmware Update" };
            MenuItem setControllerDateAndTime = new MenuItem() { Header = "Set Date and _Time" };
            MenuItem removeGmsItems = new MenuItem() { Header = "Remove _GMS Configuration Items" };
            MenuItem removeUnisonItems = new MenuItem() { Header = "Remove _Unison Configuration Items" };
            MenuItem commandSender = new MenuItem() { Header = "_Command Sender" };

            remove.Click += Remove_Click;
            skipValidate.Click += SkipValidate_Click;
            verifyTranslations.Click += VerifyTranslations_Click;
            verifyMessageConversions.Click += VerifyMessageConversions_Click;
            programSerialNumber.Click += ProgramSerialNumber_Click;
            firmwareUpdate.Click += FirmwareUpdate_Click;
            commandSender.Click += CommandSender_Click;
            setControllerDateAndTime.Click += SetControllerDateAndTime_Click;
            removeGmsItems.Click += RemoveGmsItems_Click;
            removeUnisonItems.Click += RemoveUnisonItems_Click;

            debugMenu.Items.Add(remove);
            debugMenu.Items.Add(skipValidate);
            debugMenu.Items.Add(verifyTranslations);
            debugMenu.Items.Add(verifyMessageConversions);
            debugMenu.Items.Add(programSerialNumber);
            debugMenu.Items.Add(firmwareUpdate);
            debugMenu.Items.Add(setControllerDateAndTime);
            debugMenu.Items.Add(removeGmsItems);
            debugMenu.Items.Add(removeUnisonItems);
            debugMenu.Items.Add(commandSender);
            menuBar.Items.Add(debugMenu);
#endif
        }

        private void loadMenuTranslations()
        {
            FileMenu = Translation.GetTranslatedMenu("FileMenu");
            OpenMenuItem = Translation.GetTranslatedMenu("FileMenu_Open");
            SaveMenuItem = Translation.GetTranslatedMenu("FileMenu_Save");
            SaveAsMenuItem = Translation.GetTranslatedMenu("FileMenu_SaveAs");
            NewMenuItem = Translation.GetTranslatedMenu("FileMenu_New");
            ExitMenuItem = Translation.GetTranslatedMenu("FileMenu_Exit");

            MessageConversionMenu = Translation.GetTranslatedMenu("MessageConversionMenu");
            TemplateFoundItem = Translation.GetTranslatedMenu("MessageConversionMenu_TemplateFound");
            NoTemplateFoundItem = Translation.GetTranslatedMenu("MessageConversionMenu_NoTemplateFound");
            AddDefaultTemplateItem = Translation.GetTranslatedMenu("MessageConversionMenu_AddDefaultTemplate");
            RemoveTemplateItem = Translation.GetTranslatedMenu("MessageConversionMenu_RemoveTemplate");
            ImportFromFileItem = Translation.GetTranslatedMenu("MessageConversionMenu_ImportFromFile");
            ExportToFileItem = Translation.GetTranslatedMenu("MessageConversionMenu_ExportToFile");

            LanguageMenuItem = Translation.GetTranslatedMenu("LanguageMenu");
            LanguageAutoItem = Translation.GetTranslatedMenu("LanguageMenu_Autotomatic");
        }

        /// <summary>
        /// Put a checkmark on the current language's menu item
        /// </summary>
        private void setSelectedLanguageCheckmark()
        {
            string selectedLanguage = Settings.Language;
            bool isAutoLanguage = string.IsNullOrEmpty(selectedLanguage);

            foreach (MenuItem item in languageMenu.Items)
            {
                if (item == languageMenuAutoItem)
                {
                    item.IsChecked = isAutoLanguage;
                }
                else
                {
                    Language lang = item.Tag as Language;
                    item.IsChecked = (isAutoLanguage == false) && (lang != null) && (lang.Code == selectedLanguage);
                }
            }
        }

        /// <summary>
        /// Set the appropriate text for the template status menu item
        /// </summary>
        /// <param name="found">Use the "has been found" text, otherwise "not found" text</param>
        public void SetTemplateStatusItem(bool found)
        {
            if (found)
            {
                MenuView.Instance.templateStatusItem.SetBinding(MenuItem.HeaderProperty, "TemplateFoundItem");
            }
            else
            {
                MenuView.Instance.templateStatusItem.SetBinding(MenuItem.HeaderProperty, "NoTemplateFoundItem");
            }
        }

        /// <summary>
        /// Recursively update the MenuItem text in the UI, from the variables they are bound to
        /// </summary>
        /// <param name="menu">Menu to rebind</param>
        private void rebindMenus(MenuItem menu)
        {
            System.Windows.Data.BindingExpression expression = System.Windows.Data.BindingOperations.GetBindingExpression(menu, MenuItem.HeaderProperty);
            if (expression != null)
            {
                // This item has a binding, update it
                expression.UpdateTarget();
            }

            // Process all subitems
            foreach (object item in menu.Items)
            {
                if (item is MenuItem)
                {
                    rebindMenus(item as MenuItem);
                }
            }
        }

        /// <summary>
        /// Set the language selection back to automatic
        /// </summary>
        private void languageAuto_Click(object sender, RoutedEventArgs e)
        {
            Translation.SetLanguage(Translation.RecommendedLanguage);
            Settings.Language = "";
            updateUILanguage();
        }

        /// <summary>
        /// The user has selected a particular language
        /// </summary>
        private void languageSelect_Click(object sender, RoutedEventArgs e)
        {
            if ((sender is MenuItem) == false)
            {
                return;
            }

            // Find the language in the MenuItem's Tag
            Language language = (sender as MenuItem).Tag as Language;
            if (language == null)
            {
                return;
            }

            //  Set the language and save the preference for future runs
            Translation.SetLanguage(language);
            Settings.Language = language.Code;

            // Update the UI
            updateUILanguage();
        }

        /// <summary>
        /// Update CCM's UI after a change of language
        /// </summary>
        private void updateUILanguage()
        {
            // Menus
            loadMenuTranslations();
            foreach (MenuItem item in menuBar.Items)
            {
                rebindMenus(item); // will recursively rebind any subitems
            }
            setSelectedLanguageCheckmark();

            // Tree
            NodeTreeElement selection = MainWindow.Instance.NodeTreeView.NodeTree.SelectedItem as NodeTreeElement;
            NodeTreeView.LoadTree();
            NodeTreeView.SetSelection(selection?.ConfigurationItem);
        }

#if DEBUG
        private const int configPortToUse = 8283;

        private Int32 configurationConfigPort;
        private IPAddress configurationConfigRemoteAddr;

        private TcpIPConnection configurationQueueConnection = null;
        private byte[] dataReceived = new byte[0];

        private enum ResponseType
        {
            Unknown,
            NoData,
            Error,
            ConfigurationData,
            GetAccessControlMode,
        }

        private void connectToController()
        {
            dataReceived = new byte[0];

            if (configurationConfigPort != configPortToUse || configurationConfigRemoteAddr != Settings.ControllerIPAddress)
            {
                disconnectConnection();
            }

            if (configurationQueueConnection == null)
            {
                configurationConfigPort = configPortToUse;
                configurationConfigRemoteAddr = Settings.ControllerIPAddress;

                configurationQueueConnection = new TcpIPConnection(new IPEndPoint(configurationConfigRemoteAddr, configurationConfigPort));
                configurationQueueConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(configurationQueueConnection_DataReceived);
                configurationQueueConnection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(configurationQueueConnection_ConnectionStateChanged);
                configurationQueueConnection.Connect();
            }
        }

        private void disconnectConnection()
        {
            if (configurationQueueConnection != null)
            {
                try
                {
                    configurationQueueConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(configurationQueueConnection_DataReceived);
                    configurationQueueConnection.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(configurationQueueConnection_ConnectionStateChanged);
                    configurationQueueConnection.Dispose();
                    configurationQueueConnection = null;
                }
                catch (Exception ex)
                {
                    Logger.LogMessage(LoggingLevel.Error, "Controller Configuration: Error while disconnecting. {0}", ex.Message);
                }
            }
        }

        private void configurationQueueConnection_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (e.NewConnectionState == ConnectionState.Disconnected)
                disconnectConnection();
        }

        private const string errorResponse = "<response type='error' />";
        private const string okResponse = "<response type='Ok' />";
        private const string noDataResponse = "<response type='nodata' />";

        private void configurationQueueConnection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            byte[] dataReceivedNew = new byte[dataReceived.Length + e.Data.Length];
            Array.Copy(dataReceived, 0, dataReceivedNew, 0, dataReceived.Length);
            Array.Copy(e.Data, 0, dataReceivedNew, dataReceived.Length, e.Data.Length);
            dataReceived = dataReceivedNew;
            // Discard data if too much
            if (dataReceived.Length > 500000)
                dataReceived = new byte[0];
            // Check if closing tag has been found
            if (closingResponseFound(dataReceived) == true)
            {
                // Parse response
                XDocument xdoc = processRawCommand(dataReceived);
                dataReceived = new byte[0];
                switch (getResponseType(xdoc))
                {
                    case ResponseType.ConfigurationData:
                        loadConfigurationFromController(xdoc);
                        disconnectConnection();
                        break;
                    case ResponseType.NoData:
                        break;
                    case ResponseType.Unknown:
                        break;
                }
            }
            else
            {
                try
                {
                    string receivedMessage = ASCIIEncoding.ASCII.GetString(dataReceived);
                    if (receivedMessage.Contains(errorResponse) || receivedMessage.Contains(okResponse))
                        disconnectConnection();
                }
                catch
                {
                }
            }
        }

        private void loadConfigurationFromController(XDocument xdoc)
        {
            var xResponse = xdoc.Element("response");
            string configAsString = xResponse.Value;
            if (string.IsNullOrEmpty(configAsString) == false)
            {
                byte[] configBeforeBase64 = Encoding.ASCII.GetBytes(configAsString);
                byte[] asnData = Base64.Decode(configBeforeBase64);

                try
                {
                    using (FileStream fStream = new FileStream("lastUpload.asn1", FileMode.Create, FileAccess.Write))
                    {
                        fStream.Write(asnData, 0, asnData.Length);
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogMessage(LoggingLevel.Debug, "Unable to create lastUpload.asn1. {0}", ex.Message);
                }

                Application.Current.Dispatcher.Invoke(new Action(() =>
                {
                    if (ControllerConfigurationManager.LoadFromFile("lastUpload.asn1") == false)
                        fileName = null;
                }));

                Logger.LogMessage(LoggingLevel.Debug, "-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=");
                Logger.LogMessage(LoggingLevel.Debug, "Configuration has been loaded from controller.");
                Logger.LogMessage(LoggingLevel.Debug, "-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=");
            }
        }


        private bool closingResponseFound(byte[] data)
        {
            byte[] responseEnd = Encoding.ASCII.GetBytes(@"</response>");
            if (data.Length < responseEnd.Length)
                return false;

            for (int i = 1; i <= responseEnd.Length; i++)
            {
                if (data[data.Length - i] != responseEnd[responseEnd.Length - i])
                {
                    return false;
                }
            }
            return true;
        }

        private XDocument processRawCommand(byte[] rawCommand)
        {
            try
            {
                string commandAsString = Encoding.ASCII.GetString(rawCommand, 0, rawCommand.Length);
                return XDocument.Parse(commandAsString);
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Error, "Controller Configuration: Error while processing incoming message. {0}", ex.Message);
                return null;
            }
        }

        private ResponseType getResponseType(XDocument xdoc)
        {

            /*
            * <response type='?????'>
            *    ....
            * </response>
            */

            if (xdoc == null)
                return ResponseType.Unknown;

            ResponseType result = ResponseType.Unknown;
            try
            {
                var xResponse = xdoc.Element("response");
                XAttribute xRequestType = xResponse.Attribute("type");

                if (xRequestType != null && xRequestType.Value != null)
                {
                    if (string.Compare(xRequestType.Value, "nodata", true) == 0)
                        result = ResponseType.NoData;
                    else if (string.Compare(xRequestType.Value, "error", true) == 0)
                        result = ResponseType.Error;
                    else if (string.Compare(xRequestType.Value, "configurationdata", true) == 0)
                        result = ResponseType.ConfigurationData;
                    else if (string.Compare(xRequestType.Value, "accesscontrolmode", true) == 0)
                        result = ResponseType.GetAccessControlMode;
                }
            }
            catch (Exception ex)
            {
                Logger.LogMessage(LoggingLevel.Error, "Controller Configuration: Error while parsing response type. {0}", ex.Message);
                result = ResponseType.Unknown;
            }
            return result;
        }

        private void SetConfiguration_Click(object sender, RoutedEventArgs e)
        {
            ControllerConfigurationManager.SaveToFile("lastDownload.asn1");
            connectToController();
            byte[] data = File.ReadAllBytes("lastDownload.asn1");

            byte[] data64 = Base64.Encode(data, 0, data.Length);
            var xml = new XElement("request",
                        new XAttribute("type", "setconfiguration"),
                        new XCData(Encoding.ASCII.GetString(data64, 0, data64.Length)));
            if (configurationQueueConnection != null)
                configurationQueueConnection.Send(Encoding.ASCII.GetBytes(xml.ToString()), null);

            Logger.LogMessage(LoggingLevel.Debug, "-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=");
            Logger.LogMessage(LoggingLevel.Debug, "Configuration has been sent to controller.");
            Logger.LogMessage(LoggingLevel.Debug, "-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=");
        }

        private void GetConfiguration_Click(object sender, RoutedEventArgs e)
        {
            connectToController();
            var xml = new XElement("request",
                        new XComment("Empty"),
                        new XAttribute("type", "getconfiguration"));
            if (configurationQueueConnection != null)
                configurationQueueConnection.Send(Encoding.ASCII.GetBytes(xml.ToString()), null);
        }

        private void SetControllerDetails_Click(object sender, RoutedEventArgs e)
        {
            FormApplicationConfiguration frmConfig = new FormApplicationConfiguration();
            frmConfig.InternetAddress = Settings.ControllerIPAddress;
            frmConfig.ShowInTaskbar = false;

            bool repeat = true;
            while (repeat == true)
            {
                repeat = false;
                if (frmConfig.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    try
                    {
                        Settings.ControllerIPAddress = frmConfig.InternetAddress;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(string.Format("Configuration error. {0}", ex.Message));
                        repeat = true;
                        continue;
                    }
                }
            }
        }

        private static bool isConfigurationBase(Type type)
        {
            if (type.BaseType == typeof(ConfigurationBase))
                return true;
            if (type.BaseType == null)
                return false;
            return isConfigurationBase(type.BaseType);
        }

        public class MissingTranslation
        {
            public string Language;
            public string Area;
            public string Key;
        }

        private static void addMissingTranslation(Dictionary<string, MissingTranslation> dict, string language, string area, string key)
        {
            dict[key] = new MissingTranslation() { Language = language, Area = area, Key = key };
        }

        /// <summary>
        /// Get a list of failing translations for a particular language
        /// </summary>
        /// <returns>List<> of failed keys, empty list if there are none</returns>
        public static Dictionary<string, MissingTranslation> GetFailedTranslations(Language language)
        {
            // Temporarily disable fallback, so we translate to just this language
            Language fallbackLanguage = Translation.FallbackLanguage;
            Language originalLanguage = Translation.CurrentLanguage;
            Translation.SetLanguage(language, false);

            Dictionary<string, MissingTranslation> failedTranslations = new Dictionary<string, MissingTranslation>();

            string translation;
            List<Type> typelist = new List<Type>(Assembly.GetAssembly(typeof(Area8003Configuration)).GetTypes());
            typelist.AddRange(Assembly.GetAssembly(typeof(Pacom.Core.Access.Calendar)).GetTypes());
            foreach (Type currentType in typelist)
            {
                if (currentType == typeof(DeviceInformation) || currentType.BaseType == typeof(DeviceInformation))
                    continue;

                if (currentType.Name.EndsWith("Base"))
                    continue;

                if (isConfigurationBase(currentType) == false &&
                    currentType.Name != "ControllerConnection8003Entry" &&
                    currentType.Name != "CalendarRecord")
                    continue;

                translation = Translation.GetTranslatedString(currentType);
                if (translation.StartsWith("ObjectExplorerGeneral_"))
                {
                    addMissingTranslation(failedTranslations, language.Code, "Node Type", translation);
                }

                foreach (PropertyInfo propertyInfo in currentType.GetProperties(BindingFlags.Instance | BindingFlags.Public))
                {
                    if (propertyInfo.CanRead == false || propertyInfo.CanWrite == false)
                        continue;

                    Type propertyType = propertyInfo.PropertyType;
                    ControllerAttribute controllerAttribute = ConfigurationViewBase<ConfigurationBase>.GetControllerAttribute(propertyInfo);
                    if (controllerAttribute != null)
                    {
                        if (controllerAttribute.Category == DisplayCategory.Hidden)
                            continue;

                        if (controllerAttribute.DisplayType != null)
                            propertyType = controllerAttribute.DisplayType;
                    }

                    translation = Translation.GetTranslatedString(propertyInfo);
                    if (translation.StartsWith("PacomObjectGeneric_Display_"))
                    {
                        addMissingTranslation(failedTranslations, language.Code, currentType.Name, translation);
                    }

                    if (propertyType.IsEnum)
                    {
                        Enum[] enumValues = EnumHelper.GetValues(propertyType);
                        foreach (Enum enumValue in enumValues)
                        {
                            translation = Translation.GetTranslatedString(enumValue, propertyInfo.PropertyType);
                            if (translation.StartsWith("PacomObjectGeneric_Enum_"))
                            {
                                addMissingTranslation(failedTranslations, language.Code, currentType.Name, translation);
                            }
                        }
                    }
                }
            }

            XDocument macroData = null;
            string readData;
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Pacom.ConfigurationEditor.WPF.EmbeddedResources.Expressions.txt"))
            {
                using (StreamReader streamReader = new StreamReader(stream))
                {
                    readData = streamReader.ReadToEnd();
                }
            }
            readData = readData.Replace("''", "'");
            macroData = XDocument.Parse(readData, LoadOptions.None);

            Dictionary<string, ExpressionCategory> availableConditions;
            Dictionary<string, ExpressionCategory> availableActions;

            availableConditions = macroData.Descendants("Trigger")
                .ToDictionary(t => t.Attribute("Type").Value,
                    t =>
                        new ExpressionCategory(t.Attribute("Type").Value,
                            t.Attribute("Text").Value,
                            t.Elements("State")
                                .Select(
                                    s =>
                                        new ExpressionState(
                                            s.Attribute("Id") != null ? s.Attribute("Id").Value : "",
                                            s.Attribute("Text") != null ? s.Attribute("Text").Value : "",
                                            s.Attribute("Data") != null ? s.Attribute("Data").Value : "",
                                            s.Attribute("DataType") != null ? s.Attribute("DataType").Value : "",
                                            s.Attribute("ExtraData") != null ? s.Attribute("ExtraData").Value : "",
                                            s.Attribute("DataType3") != null ? s.Attribute("DataType3").Value : "",
                                            s.Attribute("Format") != null ? s.Attribute("Format").Value : ""))
                                .ToList()));

            foreach (KeyValuePair<string, ExpressionCategory> trigger in availableConditions)
            {
                translation = Translation.GetTranslatedMacroString(trigger.Key);
                if (translation.StartsWith("SiteManager_Expression_"))
                {
                    addMissingTranslation(failedTranslations, language.Code, "Macro Trigger", translation);
                }
                foreach (ExpressionState state in trigger.Value.States)
                {
                    translation = Translation.GetTranslatedMacroString(state.Id);
                    if (translation.StartsWith("SiteManager_Expression_"))
                    {
                        addMissingTranslation(failedTranslations, language.Code, "Macro Trigger State", translation);
                    }
                }
            }

            availableActions = macroData.Descendants("Action")
                .ToDictionary(t => t.Attribute("Type").Value,
                    t =>
                        new ExpressionCategory(t.Attribute("Type").Value,
                        t.Attribute("Text").Value,
                            t.Elements("State")
                                .Select(
                                    s =>
                                        new ExpressionState(
                                            s.Attribute("Id") != null ? s.Attribute("Id").Value : "",
                                            s.Attribute("Text") != null ? s.Attribute("Text").Value : "",
                                            s.Attribute("Data") != null ? s.Attribute("Data").Value : "",
                                            s.Attribute("DataType") != null ? s.Attribute("DataType").Value : "",
                                            s.Attribute("ExtraData") != null ? s.Attribute("ExtraData").Value : "",
                                            s.Attribute("DataType3") != null ? s.Attribute("DataType3").Value : "",
                                            s.Attribute("Format") != null ? s.Attribute("Format").Value : ""))
                                .ToList()));

            foreach (KeyValuePair<string, ExpressionCategory> action in availableActions)
            {
                translation = Translation.GetTranslatedMacroString(action.Key);
                if (translation.StartsWith("SiteManager_Expression_"))
                {
                    addMissingTranslation(failedTranslations, language.Code, "Macro Action", translation);
                }
                foreach (ExpressionState state in action.Value.States)
                {
                    translation = Translation.GetTranslatedMacroString(state.Id);
                    if (translation.StartsWith("SiteManager_Expression_"))
                    {
                        addMissingTranslation(failedTranslations, language.Code, "Macro Action State", translation);
                    }
                }
            }

            foreach (ExpressionCategory expressionCategory in availableConditions.Values)
            {
                foreach (ExpressionState expressionState in expressionCategory.States)
                {
                    if (expressionState.DataType.Length > 0)
                    {
                        translation = Translation.GetTranslatedMacroDataTypeString(expressionState.DataType);
                        if (translation.StartsWith("Ccm_MacroDataType_"))
                        {
                            addMissingTranslation(failedTranslations, language.Code, "Macro Data Type", translation);
                        }
                    }
                    if (expressionState.ExtraDataType.Length > 0)
                    {
                        translation = Translation.GetTranslatedMacroDataTypeString(expressionState.ExtraDataType);
                        if (translation.StartsWith("Ccm_MacroDataType_"))
                        {
                            addMissingTranslation(failedTranslations, language.Code, "Macro Data Type", translation);
                        }
                    }
                }
            }

            foreach (ExpressionCategory expressionCategory in availableActions.Values)
            {
                foreach (ExpressionState expressionState in expressionCategory.States)
                {
                    if (expressionState.DataType.Length > 0)
                    {
                        translation = Translation.GetTranslatedMacroDataTypeString(expressionState.DataType);
                        if (translation.StartsWith("Ccm_MacroDataType_"))
                        {
                            addMissingTranslation(failedTranslations, language.Code, "Macro Data Type", translation);
                        }
                    }
                    if (expressionState.ExtraDataType.Length > 0)
                    {
                        translation = Translation.GetTranslatedMacroDataTypeString(expressionState.ExtraDataType);
                        if (translation.StartsWith("Ccm_MacroDataType_"))
                        {
                            addMissingTranslation(failedTranslations, language.Code, "Macro Data Type", translation);
                        }
                    }
                }
            }

            // Check keypad message translations
            foreach (PropertyInfo propertyInfo in typeof(Device8003Configuration).GetProperties(BindingFlags.Instance | BindingFlags.Public))
            {
                if (propertyInfo.CanRead == false || propertyInfo.CanWrite == false)
                    continue;

                CategoryAttribute attr = propertyInfo.GetCustomAttribute(typeof(CategoryAttribute)) as CategoryAttribute;
                if (attr == null || attr.CategoryName != "KeypadLanguage")
                    continue;

                string translated = Translation.GetTranslatedKeypadString(propertyInfo.Name, "NO_TRANSLATION");
                if (translated == "NO_TRANSLATION")
                {
                    addMissingTranslation(failedTranslations, language.Code, "KeypadLanguageStrings.csv", propertyInfo.Name);
                }
            }

            // Put the language back to its original setting
            Translation.SetLanguage(originalLanguage, fallbackLanguage);
            return failedTranslations;
        }

        // Make the string safe for CSV
        private static string toCsv(string text)
        {
            text = text.Replace("\"", "\"\"");
            if (text.Contains(',') || text.Contains('\r') || text.Contains('\n'))
            {
                return "\"" + text + "\"";
            }
            return text;
        }

        private void VerifyTranslations_Click(object sender, RoutedEventArgs e)
        {
            FileVersionInfo version = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);
            string versionText = "CCM V" + version.FileMajorPart + "." + version.FileMinorPart;
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("==== " + versionText + " ====");
            sb.AppendLine("==== " + DateTime.Now.ToLongDateString() + " " + DateTime.Now.ToLongTimeString() + " ====");
                sb.AppendLine();
            Language englishLanguage = Translation.GetLanguage("en");
            foreach (Language language in Translation.Languages)
            {
                Dictionary<string, MissingTranslation> failedTranslations = GetFailedTranslations(language);

                sb.AppendLine("==== Verify Translations for " + language.EnglishName + " ====");
                sb.AppendLine();
                if (failedTranslations.Count == 0)
                {
                    sb.AppendLine("No errors found");
                }
                else
                {
                    sb.AppendLine("Language,Key,Area,English Text");
                    MissingTranslation[] items = failedTranslations.Values.ToArray();
                    Array.Sort(items, (x, y) =>
                    {
                        int lang = x.Language.CompareTo(y.Language);
                        if (lang != 0)
                        {
                            return lang;
                        }
                        int area = x.Area.CompareTo(y.Area);
                        if (area != 0)
                        {
                            return area;
                        }
                        return x.Key.CompareTo(y.Key);
                    });

                    foreach (MissingTranslation entry in items)
                    {
                        string englishHint;
                        if (englishLanguage.Translations.TryGetValue(entry.Key, out englishHint) == false)
                        {
                            englishHint = "(none)";
                        }

                        sb.AppendLine(toCsv(entry.Language) + "," + toCsv(entry.Key) + "," + toCsv(entry.Area) + "," + toCsv(englishHint));
                    }
                }
                sb.AppendLine();

                if (language == Translation.CurrentLanguage)
                {
                    sb.AppendLine("==== Accumulated " + language.EnglishName + " Failures ====");
                    sb.AppendLine();

                    if (Translation.MissingCcmItems.Count == 0)
                    {
                        sb.AppendLine("None");
                    }
                    else
                    {
                        sb.AppendLine("Language,Key,Area,English Text");
                        string[] missing = Translation.MissingCcmItems.ToArray();
                        Array.Sort(missing);

                        foreach (string item in missing)
                        {
                            string englishHint;
                            if (englishLanguage.Translations.TryGetValue(item, out englishHint) == false)
                            {
                                englishHint = "(none)";
                            }
                            sb.AppendLine(toCsv(language.Code) + "," + toCsv(item) + "," + toCsv("") + "," + toCsv(englishHint));
                        }
                    }
                    sb.AppendLine();
                }
            }

            FormTranslationFailures formTranslationFailures = new FormTranslationFailures(sb.ToString());
            formTranslationFailures.ShowDialog();
        }

        public static bool VerifyMessageConversions()
        {
            string tempFileName = Path.GetTempFileName();
            bool success = false;
            using (Stream resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Pacom.ConfigurationEditor.WPF.EmbeddedResources.8003OPtoCIDSIA.xml"))
            {
                OpenPacomToDigitalReceiverTemplate template = new OpenPacomToDigitalReceiverTemplate();
                OpenPacomToDigitalReceiver8003Template templateBase = null;
                if (template.ImportFromXML(resourceStream, out templateBase) == true)
                {
                    template = new OpenPacomToDigitalReceiverTemplate(templateBase);
                    template.ExportToXML(tempFileName);

                    success = true;
                }
            }

            if (success)
            {
                success = false;
                byte[] data1;
                byte[] data2;

                using (Stream resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Pacom.ConfigurationEditor.WPF.EmbeddedResources.8003OPtoCIDSIA.xml"))
                {
                    data1 = new byte[resourceStream.Length];
                    resourceStream.Read(data1, 0, data1.Length);
                }
                using (Stream fileStream = new FileStream(tempFileName, FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    data2 = new byte[fileStream.Length];
                    fileStream.Read(data2, 0, data2.Length);
                }

                success = data1.SequenceEqual(data2);
            }
            if (File.Exists(tempFileName))
                File.Delete(tempFileName);
            return success;
        }

        private void FirmwareUpdate_Click(object sender, RoutedEventArgs e)
        {
            FirmwareUpdate firmwareUpdate = new FirmwareUpdate();
            firmwareUpdate.Owner = MainWindow.Instance;
            firmwareUpdate.ShowDialog();
        }

        private void RemoveGmsItems_Click(object sender, RoutedEventArgs e)
        {
            ControllerConfigurationManager.RemoveGmsConfigurationItems();
            NodeTreeView.LoadTree();
        }

        private void RemoveUnisonItems_Click(object sender, RoutedEventArgs e)
        {
            ControllerConfigurationManager.RemoveUnisonConfigurationItems();
            NodeTreeView.LoadTree();
        }

        private void SetControllerDateAndTime_Click(object sender, RoutedEventArgs e)
        {
            SetDateAndTime setDateAndTime = new SetDateAndTime();
            setDateAndTime.Owner = MainWindow.Instance;
            setDateAndTime.ShowDialog();
        }

        private void CommandSender_Click(object sender, RoutedEventArgs e)
        {
            CommandSender commandSender = new CommandSender();
            commandSender.Owner = MainWindow.Instance;
            commandSender.ShowDialog();
        }

        private void ProgramSerialNumber_Click(object sender, RoutedEventArgs e)
        {
            ProgramSerialNumber programSerialNumber = new ProgramSerialNumber();
            programSerialNumber.Owner = MainWindow.Instance;
            programSerialNumber.ShowDialog();
        }

        private void VerifyMessageConversions_Click(object sender, RoutedEventArgs e)
        {
            if (VerifyMessageConversions())
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance, "Success", "Success");
            else
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance, "Failed", "Error");
        }

        private void Remove_Click(object sender, RoutedEventArgs e)
        {
            if (MainWindow.Instance.NodeTreeView.Background == null)
            {
                MainWindow.Instance.NodeTreeView.Background = Brushes.Aqua;
                MainWindow.Instance.PropertiesView.Background = Brushes.Aqua;
                MainWindow.Instance.Background = new ImageBrush(new BitmapImage(new Uri(BaseUriHelper.GetBaseUri(this), "../EmbeddedResources/Images/icon-bg.jpg"))) { Stretch = Stretch.UniformToFill };
            }
            else
            {
                MainWindow.Instance.NodeTreeView.Background = null;
                MainWindow.Instance.PropertiesView.Background = null;
                MainWindow.Instance.Background = new ImageBrush(new BitmapImage(new Uri(BaseUriHelper.GetBaseUri(this), "../EmbeddedResources/Images/icon-bg-DEBUG.jpg"))) { Stretch = Stretch.UniformToFill };
            }

        }

        private void SkipValidate_Click(object sender, RoutedEventArgs e)
        {
            App.SkipValidate = true;
        }

        private void QueryCard_Click(object sender, RoutedEventArgs e)
        {
            FormQueryCardholder formQueryCardholder = new FormQueryCardholder();
            formQueryCardholder.ShowInTaskbar = false;
            formQueryCardholder.ShowDialog();
        }

        private void ViewAllCards_Click(object sender, RoutedEventArgs e)
        {
            FormViewCardholders formViewCardholders = new FormViewCardholders();
            formViewCardholders.ShowInTaskbar = false;
            formViewCardholders.ShowDialog();
        }

        private Window parentWindow = null;
        public void SetParentWindow(Window parent)
        {
            parentWindow = parent;
        }
        
        private void ElevatorFloorsAccess_Click(object sender, RoutedEventArgs e)
        {
            if(ConfigurationManager.ConfigurationType == ConfigurationType.Gms)
            {
                GmsElevatorFloorsAccess elevatorFloorsAccess = new GmsElevatorFloorsAccess();
                elevatorFloorsAccess.ShowInTaskbar = false;
                if (parentWindow != null)
                    elevatorFloorsAccess.Owner = parentWindow;
                elevatorFloorsAccess.ShowDialog();
            }
        }

#endif

        private string fileName = null;
        public void SetFileName(string fileName)
        {
            this.fileName = fileName;
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (App.ConfigurationModified)
                {
                    MessageBoxResult result = Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                        Translation.GetTranslatedError(ErrorMessage.UnsavedConfiguration),
                        Translation.GetTranslatedError(ErrorMessage.Warning), MessageBoxButton.OKCancel);

                    if (result == MessageBoxResult.Cancel)
                        return;
                }

                OpenFileDialog openForm = new OpenFileDialog
                {
                    Filter = "Controller files (*.asn1)|*.asn1|All files (*.*)|*.*",
                    FilterIndex = 1,
                    RestoreDirectory = true
                };
                if (openForm.ShowDialog() == true)
                {
                    fileName = openForm.FileName;
                    if (ControllerConfigurationManager.LoadFromFile(openForm.FileName) == false)
                        fileName = null;
                }
            }
            catch (Exception ex)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.LoadingConfiguration) + " " + ex.Message,
                    Translation.GetTranslatedError(ErrorMessage.Error));
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                SaveAs_Click(sender, e);
            }
            else
            {
                App.FileUpdated = true;
                ControllerConfigurationManager.SaveToFile(fileName);
            }
        }

        private void SaveAs_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SaveFileDialog saveForm = new SaveFileDialog
                {
                    Filter = "Controller files (*.asn1)|*.asn1|All files (*.*)|*.*",
                    FilterIndex = 1,
                    RestoreDirectory = true,
                };
                if (saveForm.ShowDialog() == true)
                {
                    if (ControllerConfigurationManager.SaveToFile(saveForm.FileName))
                        fileName = saveForm.FileName;
                    App.FileUpdated = true;
                }
            }
            catch (Exception ex)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.SavingConfiguration) + " " + ex.Message,
                    Translation.GetTranslatedError(ErrorMessage.Error));
            }
        }

        private void New_Click(object sender, RoutedEventArgs e)
        {
            if (App.ConfigurationModified)
            {
                MessageBoxResult result = Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.UnsavedConfiguration),
                    Translation.GetTranslatedError(ErrorMessage.Warning), MessageBoxButton.OKCancel);

                if (result == MessageBoxResult.Cancel)
                    return;
            }

            ControllerConfigurationManager.LoadDefaults();
            fileName = null;
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.Instance.Close();
        }

        private void RemoveTemplate_Click(object sender, RoutedEventArgs e)
        {
            if (ConfigurationManager.OpenPacomToDigitalReceiverTemplates.ContainsKey(1))
                App.ConfigurationModified = true;
            ConfigurationManager.OpenPacomToDigitalReceiverTemplates.Clear();
            SetTemplateStatusItem(false);
        }

        private void AddDefaultTemplate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (Stream resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Pacom.ConfigurationEditor.WPF.EmbeddedResources.8003OPtoCIDSIA.xml"))
                {
                    loadMessageConversionTemplateFromStream(resourceStream);
                }
            }
            catch (Exception ex)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.ImportingTemplate) + " " + ex.Message,
                    Translation.GetTranslatedError(ErrorMessage.Error));
            }
        }

        private void ImportTemplate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openForm = new OpenFileDialog
                {
                    Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*",
                    FilterIndex = 1,
                    RestoreDirectory = true
                };
                if (openForm.ShowDialog() == true)
                {
                    using (Stream fileStream = new FileStream(openForm.FileName, FileMode.Open, FileAccess.Read, FileShare.None))
                    {
                        loadMessageConversionTemplateFromStream(fileStream);
                    }
                }
            }
            catch (Exception ex)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.ImportingTemplate) + " " + ex.Message,
                    Translation.GetTranslatedError(ErrorMessage.Error));
            }
        }

        private void loadMessageConversionTemplateFromStream(Stream conversionTemplateStream)
        {
            App.ConfigurationModified = true;
            ConfigurationManager.OpenPacomToDigitalReceiverTemplates.Clear();

            OpenPacomToDigitalReceiverTemplate template = new OpenPacomToDigitalReceiverTemplate();
            OpenPacomToDigitalReceiver8003Template templateBase = null;
            if (template.ImportFromXML(conversionTemplateStream, out templateBase) == true)
            {
                ConfigurationManager.OpenPacomToDigitalReceiverTemplates[1] = templateBase;
                SetTemplateStatusItem(true);
            }
            else
            {
                SetTemplateStatusItem(false);
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.ImportingTemplate),
                    Translation.GetTranslatedError(ErrorMessage.Error));
            }
        }

        private void ExportTemplate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ConfigurationManager.OpenPacomToDigitalReceiverTemplates.ContainsKey(1))
                {
                    SaveFileDialog saveForm = new SaveFileDialog
                    {
                        Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*",
                        FilterIndex = 1,
                        RestoreDirectory = true,
                    };
                    if (saveForm.ShowDialog() == true)
                    {
                        OpenPacomToDigitalReceiverTemplate template = new OpenPacomToDigitalReceiverTemplate(ConfigurationManager.OpenPacomToDigitalReceiverTemplates[1]);
                        template.ExportToXML(saveForm.FileName);
                    }
                }
            }
            catch (Exception ex)
            {
                Xceed.Wpf.Toolkit.MessageBox.Show(MainWindow.Instance,
                    Translation.GetTranslatedError(ErrorMessage.ExportingTemplate) + " " + ex.Message,
                    Translation.GetTranslatedError(ErrorMessage.Error));
            }
        }
    }
}
