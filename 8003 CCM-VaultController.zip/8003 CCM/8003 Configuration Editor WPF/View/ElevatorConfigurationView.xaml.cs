﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.ConfigurationEditor.WPF.Commands;
using Pacom.Peripheral.Common.Configuration;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Pacom.ConfigurationEditor.WPF.View
{
    /// <summary>
    /// Interaction logic for ElevatorConfigurationView.xaml
    /// </summary>
    public partial class ElevatorConfigurationView : ElevatorConfigurationViewBase
    {
        private LegacyElevator8003Configuration legacyConfiguration;

        public ElevatorConfigurationView(LegacyElevator8003Configuration elevatorConfiguration) : base(elevatorConfiguration)
        {
            InitializeComponent();

            if (elevatorConfiguration == null)
                elevatorConfiguration = new LegacyElevator8003Configuration();
            if (elevatorConfiguration.FloorsServiced == null)
                elevatorConfiguration.FloorsServiced = new bool[128];
            this.legacyConfiguration = elevatorConfiguration;
            this.DataContext = this;
            floorsServiced.Data = elevatorConfiguration.FloorsServiced;
            setFloorControllerAddresses(findLogicalChildren<ComboBox>(floorRelaysControllerAddressPanel));
        }

        private void floorRelaysControllerAddressPanel_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            onFloorControllerAddressSelectionChange(e.OriginalSource as ComboBox);
        }

        private void floorsServiced_DataChanged(object sender, UserControls.CheckBoxesUserControl.DataChangedEventArgs e)
        {
            legacyConfiguration.FloorsServiced = e.Data;
        }
    }
}
