﻿using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Linq;
using Pacom.Core.Attributes;
using System.Reflection;

namespace Pacom.ConfigurationEditor.WPF.View
{
    /// <summary>
    /// Interaction logic for VaultDeviceView.xaml
    /// </summary>
    public partial class VaultDeviceView : Grid
    {
        public Device1076VCConfiguration Configuration { get; set; }

        public VaultDeviceView(Device1076VCConfiguration configuration)
        {
            InitializeComponent();
            Configuration = configuration;
            this.DataContext = Configuration;
            var vaultControllerRange = getVaultControllerNumberRange();
            //List<ComboBoxItemContents> vcNumberItems = new List<ComboBoxItemContents>();
            //for (int i = vaultControllerRange.Item1; i <= vaultControllerRange.Item2; i++)
            //{
            //    vcNumberItems.Add(new ComboBoxItemContents($"{i}", i));
            //}
            //vaultControllerNumberComboBox.ItemsSource = vcNumberItems;
            //vaultControllerNumberComboBox.SelectedIndex = Configuration.VaultControllerNumber - 1;
            //vaultControllerNumberComboBox.ItemContainerGenerator.StatusChanged += onVaultControllerNumberItemContainerGenerator_StatusChanged;

            List<ComboBoxItemContents> points = ControllerConfigurationManager.GetAvailableDevicePoints(configuration.ParentDeviceId, configuration.GetType(), configuration.DeviceLoopAddress);
            deviceAddressComboBox.ItemsSource = points;
            deviceAddressComboBox.SelectedIndex = configuration.DeviceLoopAddress - 1;
            deviceAddressComboBox.ItemContainerGenerator.StatusChanged += onDeviceAddressItemContainerGenerator_StatusChanged;

            vaultAccessDuration.IsEnabled = Configuration.VaultAccessPermanent == false;

            vaultNumberId.Minimum = vaultControllerRange.Item1;
            vaultNumberId.Maximum = vaultControllerRange.Item2;

        }

        //private Dictionary<ItemContainerGenerator, ComboBox> comboBoxes = new Dictionary<ItemContainerGenerator, ComboBox>();

        //private void onVaultControllerNumberItemContainerGenerator_StatusChanged(object sender, EventArgs e)
        //{
        //    ItemContainerGenerator generator = sender as ItemContainerGenerator;
        //    if (generator.Status == System.Windows.Controls.Primitives.GeneratorStatus.ContainersGenerated)
        //    {
        //        foreach (ComboBoxItemContents item in generator.Items)
        //        {
        //            if (item.Enabled == false)
        //            {
        //                ComboBoxItem container = (ComboBoxItem)generator.ContainerFromItem(item);
        //                container.IsEnabled = false;
        //            }
        //        }
        //        Dispatcher.InvokeAsync(() => vaultControllerNumberComboBox.IsDropDownOpen = false);
        //        Dispatcher.InvokeAsync(() => vaultControllerNumberComboBox.MaxDropDownHeight = 200);
        //        // Restore focus
        //        //Dispatcher.InvokeAsync(() => Keyboard.Focus(NodeTreeView.Instance.NodeTree));
        //    }
        //}

        private Tuple<int, int> getVaultControllerNumberRange()
        {
            int min = 1, max = 16;
            var cfgProps = Configuration.GetType().GetProperties(System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public);
            foreach (var prop in cfgProps)
            {
                if (prop.Name == "VaultControllerNumber")
                {
                    RangeAttribute ra = prop.GetCustomAttribute(typeof(RangeAttribute)) as RangeAttribute;
                    if (ra != null)
                    {
                        min = ra.Minimum;
                        max = ra.Maximum;
                    }
                    break;
                }
            }
            return new Tuple<int, int>(min, max);
        }
        private void permanentVaultAccessCheckBox_Click(object sender, RoutedEventArgs e)
        {
            vaultAccessDuration.IsEnabled = permanentVaultAccessCheckBox.IsChecked == false;
        }

        private void vaultControllerNumberComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Configuration.VaultControllerNumber = vaultControllerNumberComboBox.SelectedIndex + 1;
        }

        private void deviceAddressComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Configuration.DeviceLoopAddress = deviceAddressComboBox.SelectedIndex + 1;
        }

        /*
        private Dictionary<ItemContainerGenerator, ComboBox> comboBoxes = new Dictionary<ItemContainerGenerator, ComboBox>();
        private void createPointOnParentComboBox(List<ComboBoxItemContents> points, int currentPoint)
        {
            ComboBox comboBox = deviceAddressComboBox;
            comboBox.ItemsSource = points;
            comboBox.SelectedIndex = currentPoint - 1;
            // The following is to disable the unavailable points
            comboBox.ItemContainerGenerator.StatusChanged += ItemContainerGenerator_StatusChanged;
            comboBoxes[comboBox.ItemContainerGenerator] = comboBox;
        }

        private void ItemContainerGenerator_StatusChanged(object sender, EventArgs e)
        {
            ItemContainerGenerator generator = sender as ItemContainerGenerator;
            if (generator.Status == System.Windows.Controls.Primitives.GeneratorStatus.ContainersGenerated)
            {
                foreach (ComboBoxItemContents item in generator.Items)
                {
                    if (item.Enabled == false)
                    {
                        ComboBoxItem container = (ComboBoxItem)generator.ContainerFromItem(item);
                        container.IsEnabled = false;
                    }
                }
                Dispatcher.InvokeAsync(() => comboBoxes[generator].IsDropDownOpen = false);
                Dispatcher.InvokeAsync(() => comboBoxes[generator].MaxDropDownHeight = 200);
                // Restore focus
                Dispatcher.InvokeAsync(() => Keyboard.Focus(NodeTreeView.Instance.NodeTree));
            }
        }
        */


        private void onDeviceAddressItemContainerGenerator_StatusChanged(object sender, EventArgs e)
        {
            ItemContainerGenerator generator = sender as ItemContainerGenerator;
            if (generator.Status == System.Windows.Controls.Primitives.GeneratorStatus.ContainersGenerated)
            {
                foreach (ComboBoxItemContents item in generator.Items)
                {
                    if (item.Enabled == false)
                    {
                        ComboBoxItem container = (ComboBoxItem)generator.ContainerFromItem(item);
                        container.IsEnabled = false;
                    }
                }
                Dispatcher.InvokeAsync(() => deviceAddressComboBox.IsDropDownOpen = false);
                Dispatcher.InvokeAsync(() => deviceAddressComboBox.MaxDropDownHeight = 200);
                // Restore focus
                //Dispatcher.InvokeAsync(() => Keyboard.Focus(NodeTreeView.Instance.NodeTree));
            }
        }

        
    }
}
