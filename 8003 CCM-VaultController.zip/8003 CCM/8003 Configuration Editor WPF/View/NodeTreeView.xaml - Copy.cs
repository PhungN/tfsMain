﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Core.Access;
using Pacom.Core.Contracts;
using Pacom.Peripheral.Common.Configuration;
using System.Windows.Media.Imaging;

namespace Pacom.ConfigurationEditor.WPF.View
{
    /// <summary>
    /// Interaction logic for TreeView.xaml
    /// </summary>
    public partial class NodeTreeView
    {
        private static NodeTreeView instance;

        public List<NodeTreeElement> ParentNode { get; private set; }

        public NodeTreeView()
        {
            ParentNode = new List<NodeTreeElement>();
            instance = this;
            InitializeComponent();

            ControllerConfigurationManager.LoadDefaults();
        }

        public static NodeTreeView Instance
        {
            get
            {
                return instance;
            }
        }

        public void RefreshTree()
        {
            DataContext = null;
            DataContext = this;
            NodeTreeElement.ClearCache();
        }

        public void RefreshDataContext()
        {
            DataContext = null;
            DataContext = this;
        }

        public void RefreshConfigurationView()
        {
            NodeTreeElement.ClearCache();
            NodeTree_SelectedItemChanged(this.NodeTree, null);
        }

        private void NodeTree_SelectedItemChanged(object sender, System.Windows.RoutedPropertyChangedEventArgs<object> e)
        {
            NodeTreeElement nodeTreeElement = ((NodeTreeElement)((TreeView)sender).SelectedItem);
            if (nodeTreeElement != null)
            {
                Grid configurationGrid = MainWindow.ConfigurationGrid.Content as Grid;
                foreach (object child in configurationGrid.Children)
                {
                    IUnloadable configurationViewBase = child as IUnloadable;
                    if (configurationViewBase != null)
                        configurationViewBase.Unload();
                }
                configurationGrid.Children.Clear();

                Grid configurationView = nodeTreeElement.ConfigurationView;
                if (configurationView != null)
                    configurationGrid.Children.Add(configurationView);
            }
        }

        private void NodeTree_OnPreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            DependencyObject obj = e.OriginalSource as DependencyObject;
            TreeViewItem item = getDependencyObjectFromVisualTree(obj, typeof(TreeViewItem)) as TreeViewItem;
            NodeTreeElement nodeTreeElement = item.Header as NodeTreeElement;
            if (nodeTreeElement != null)
            {
                TreeViewItem tvi = sender as TreeViewItem;
                if (tvi != null)
                {
                    tvi.ContextMenu = null;
                    List<MenuItem> menuItems = createMenuItems(nodeTreeElement);
                    if (menuItems.Count > 0)
                    {
                        ContextMenu menu = new ContextMenu();
                        foreach (var menuItem in menuItems)
                            menu.Items.Add(menuItem);
                        tvi.ContextMenu = menu;
                        e.Handled = true;
                    }
                }
            }
        }

        private List<MenuItem> createMenuItems(NodeTreeElement nodeTreeElement)
        {
            List<MenuItem> menuItems = new List<MenuItem>();
            if (nodeTreeElement.ConfigurationItem != null)
            {
                //if (nodeTreeElement.ConfigurationItem is Device8003Configuration)// VaultController8003Configuration)
                //    return menuItems;
                MenuItem menuItem = new MenuItem();
                menuItem.Header = $"{nodeTreeElement.DisplayName}";
                Image ObjImage = new Image();
                ObjImage.Source = new BitmapImage(new Uri("/EmbeddedResources/Images/Delete.png", UriKind.RelativeOrAbsolute));
                menuItem.Icon = ObjImage;
                menuItem.Click += (sender, e) => { ConfigurationManager.Remove(nodeTreeElement.ConfigurationItem); };
                menuItems.Add(menuItem);
            }
            else
            {
                string name = nodeTreeElement.DisplayName;
                if (name == Translation.GetTranslatedNodeTreeItem("Devices_ExpansionCards") ||
                    name == Translation.GetTranslatedNodeTreeItem("Devices_Peripherals") ||
                    name == Translation.GetTranslatedNodeTreeItem("Keypads") ||
                    name == Translation.GetTranslatedNodeTreeItem("Devices_PowerSupplies") ||
                    name == Translation.GetTranslatedNodeTreeItem("Devices_Inovonics") ||
                    name == Translation.GetTranslatedNodeTreeItem("Doors") ||
                    name == Translation.GetTranslatedNodeTreeItem("Readers") ||
                    name == Translation.GetTranslatedNodeTreeItem("Inputs") ||
                    name == Translation.GetTranslatedNodeTreeItem("Outputs"))
                {
                    if (nodeTreeElement.ConfigurationView != null)
                    {
                        FolderViewBase fvb = nodeTreeElement.ConfigurationView as FolderViewBase;
                        if (fvb != null && fvb.TypeEntries != null)
                        {
                            foreach (var entry in fvb.TypeEntries)
                            {
                                MenuItem menuItem = new MenuItem() { Header = entry.Key };
                                Image ObjImage = new Image();
                                ObjImage.Source = new BitmapImage(new Uri("/EmbeddedResources/Images/Add.png", UriKind.RelativeOrAbsolute));
                                menuItem.Icon = ObjImage;
                                menuItem.Click += (sender, e) => { fvb.AddConfiguration(entry.Value); };
                                menuItems.Add(menuItem);
                            }
                        }
                    }
                }
                else if(name == Translation.GetTranslatedNodeTreeItem("AlarmUsers"))
                {
                    if (nodeTreeElement.ConfigurationView != null)
                    {
                        FolderViewBase fvb = nodeTreeElement.ConfigurationView as FolderViewBase;
                        if (fvb != null && fvb.TypeEntries != null)
                        {
                            foreach (var entry in fvb.TypeEntries)
                            {
                                menuItems.Add(createMenuItem(entry.Key, (UserConfigurationBase)Activator.CreateInstance(entry.Value)));
                            }
                        }
                    }
                }
                else if(name == Translation.GetTranslatedNodeTreeItem("Areas"))
                {
                    menuItems.Add(createMenuItem("Area", new Area8003Configuration()));
                }
                else if (name == Translation.GetTranslatedNodeTreeItem("UserGroups"))
                {
                    menuItems.Add(createMenuItem("UserGroup", new Group8003Configuration()));
                }
                else if (name == Translation.GetTranslatedNodeTreeItem("Expressions"))
                {
                    menuItems.Add(createMenuItem("Expression", new Macro8003Configuration()));
                }
                else if(name == Translation.GetTranslatedNodeTreeItem("AccessSchedules"))
                {
                    menuItems.Add(createMenuItem("Schedule", new Schedule()));
                }
                else if(name == Translation.GetTranslatedNodeTreeItem("CardProfiles"))
                {
                    menuItems.Add(createMenuItem("CardProfile", new LegacyCardFormat()));
                }
                else if (name == Translation.GetTranslatedNodeTreeItem("PresenceZones"))
                {
                    menuItems.Add(createMenuItem("UserArea", new PresenceZone8003Configuration()));
                }
                else if(name == Translation.GetTranslatedNodeTreeItem("InterlockGroups"))
                {
                    menuItems.Add(createMenuItem("InterlockGroup", new Interlock8003Configuration()));
                }
                else if (name == Translation.GetTranslatedNodeTreeItem("VaultController"))
                {
                    menuItems.Add(createMenuItem("VaultControllerInterlockGroup", new VaultControllerInterlock8003Configuration()));
                }
                else if(name == Translation.GetTranslatedNodeTreeItem("Elevators"))
                {
                    switch (ConfigurationManager.ConfigurationType)
                    {
                        case ConfigurationType.Gms:
                            menuItems.Add(createMenuItem("Elevator", new LegacyElevator8003Configuration()));
                            break;
                        case ConfigurationType.Unison:
                            menuItems.Add(createMenuItem("Elevator", new Elevator8003Configuration()));
                            break;
                        default:
                            menuItems.Add(createMenuItem("GmsElevator", new LegacyElevator8003Configuration()));
                            menuItems.Add(createMenuItem("UnisonElevator", new Elevator8003Configuration()));
                            break;
                    }
                }
                else if (name == Translation.GetTranslatedNodeTreeItem("ElevatorFloors"))
                {
                    if(ConfigurationManager.ElevatorFloors.Count < 128)
                        menuItems.Add(createMenuItem("ElevatorFloor", new ElevatorFloor8003Configuration()));
                    if(ConfigurationManager.ElevatorFloors.Count > 0)
                        menuItems.Add(createDeleteAllElevatorFloorsMenuItem());
                }
                else if (name == Translation.GetTranslatedNodeTreeItem("AccessGroups"))
                {
                    menuItems.Add(createMenuItem("AccessGroup", new AccessGroup()));
                }
            }
            return menuItems;
        }

        private MenuItem createMenuItem(string resourceIdString, ConfigurationBase configuration)
        {
            Image ObjImage = new Image();
            ObjImage.Source = new BitmapImage(new Uri("/EmbeddedResources/Images/Add.png", UriKind.RelativeOrAbsolute));
            MenuItem menuItem = new MenuItem();
            menuItem.Header = Translation.GetTranslatedText(resourceIdString);
            menuItem.Icon = ObjImage;
            menuItem.Click += (sender, e) => { ConfigurationManager.AddNewConfiguration(configuration); };
            return menuItem;
        }

        private MenuItem createDeleteAllElevatorFloorsMenuItem()
        {
            Image ObjImage = new Image();
            ObjImage.Source = new BitmapImage(new Uri("/EmbeddedResources/Images/Delete.png", UriKind.RelativeOrAbsolute));
            MenuItem menuItem = new MenuItem();
            menuItem.Header = Translation.GetTranslatedText("DeleteAll");
            menuItem.Icon = ObjImage;
            menuItem.Click += (sender, e) => 
            {
                if(MessageBox.Show(Translation.GetTranslatedText("ConfirmDeleteAll"), Translation.GetTranslatedText("DeleteAll"), MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    ConfigurationManager.DeleteAllElevatorFloors();
                }
            };
            return menuItem;
        }

        private static DependencyObject getDependencyObjectFromVisualTree(DependencyObject startObject, Type type)
        {
            var parent = startObject;
            while (parent != null)
            {
                if (type.IsInstanceOfType(parent))
                    break;
                parent = VisualTreeHelper.GetParent(parent);
            }
            return parent;
        }

        public static void SetSelection(ConfigurationBase newObject)
        {
            NodeTreeElement element;
            if (newObject == null || newObject is Device8003Configuration)
            {
                element = topLevelNode;

                // Focusing the TreeViewItem makes selecting the controller (root) node work 
                TreeViewItem tvi = instance.NodeTree.ItemContainerGenerator.ContainerFromItem(element) as TreeViewItem;
                if (tvi != null)
                {
                    tvi.Focus();
                }
            }
            else
            {
                element = instance.findElement(instance.ParentNode[0], newObject);
            }

            element.IsSelected = true;
        }

        private NodeTreeElement findElement(NodeTreeElement parentElement, ConfigurationBase elementToFind)
        {
            if (parentElement.ConfigurationItem == elementToFind
#if DEBUG
                || (elementToFind != null && parentElement.ConfigurationItem != null &&
                parentElement.ConfigurationItem.Id == elementToFind.Id && parentElement.ConfigurationItem.GetType() == elementToFind.GetType())
#endif
                )
                return parentElement;
            foreach (NodeTreeElement element in parentElement.Children)
            {
                NodeTreeElement result = findElement(element, elementToFind);
                if (result != null)
                    return result;
            }
            return null;
        }

        private static NodeTreeElement topLevelNode;
        private static NodeTreeElement ports;
        private static NodeTreeElement connectionTables;
        private static NodeTreeElement devices;
        private static NodeTreeElement expansionCards;
        private static NodeTreeElement peripherals;
        private static NodeTreeElement inovonicsNodes;
        private static NodeTreeElement powerSupplies;
        private static NodeTreeElement presenceZones;
        private static NodeTreeElement userGroups;
        private static NodeTreeElement readers;
        private static NodeTreeElement doors;
        private static NodeTreeElement interlockGroups;
        private static NodeTreeElement vaultControllerInterlockGroups;
        private static NodeTreeElement areas;
        private static NodeTreeElement keypads;
        private static NodeTreeElement users;
        private static NodeTreeElement cardFormats;
        private static NodeTreeElement accessGroups;
        private static NodeTreeElement schedulesAndHolidays;
        private static NodeTreeElement schedules;
        private static NodeTreeElement inputs;
        private static NodeTreeElement outputs;
        private static NodeTreeElement elevators;
        private static NodeTreeElement elevatorFloors;
        private static NodeTreeElement expressions;
        private static NodeTreeElement vaultController;

        public static void LoadTree()
        {
            bool showGmsOnlyConfiguration = true;
            bool showUnisonOnlyConfiguration = true;

            if (App.GmsConfigurationOnly || ConfigurationManager.GmsConfigurationPresent)
            {
                showUnisonOnlyConfiguration = false;
            }
            else if (ConfigurationManager.UnisonConfigurationPresent)
            {
                showGmsOnlyConfiguration = false;
            }

            topLevelNode = new NodeTreeElement(UntranslatedStrings.ControllerName, "/EmbeddedResources/Images/Controller8003.png", ConfigurationManager.ControllerConfiguration, typeof(ControllerView));
            ports = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Ports"), "/EmbeddedResources/Images/Folder.png");
            topLevelNode.Children.Add(ports);
            connectionTables = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("ConnectionTable"), "/EmbeddedResources/Images/Folder.png");
            topLevelNode.Children.Add(connectionTables);
            devices = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Devices"), "/EmbeddedResources/Images/Folder.png");
            topLevelNode.Children.Add(devices);
            expansionCards = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Devices_ExpansionCards"), "/EmbeddedResources/Images/Folder.png", null, typeof(ExpansionCardsFolderView));
            devices.Children.Add(expansionCards);
            peripherals = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Devices_Peripherals"), "/EmbeddedResources/Images/Folder.png", null, typeof(PeripheralsFolderView));
            devices.Children.Add(peripherals);
            keypads = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Keypads"), "/EmbeddedResources/Images/Folder.png", null, typeof(KeypadsFolderView));
            devices.Children.Add(keypads);
            powerSupplies = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Devices_PowerSupplies"), "/EmbeddedResources/Images/Folder.png", null, typeof(PowerSuppliesFolderView));
            devices.Children.Add(powerSupplies);
            inovonicsNodes = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Devices_Inovonics"), "/EmbeddedResources/Images/Folder.png", null, typeof(InovonicsFolderView));
            devices.Children.Add(inovonicsNodes);
            schedulesAndHolidays = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("SchedulesAndHolidays"), "/EmbeddedResources/Images/Folder.png");
            topLevelNode.Children.Add(schedulesAndHolidays);
            schedulesAndHolidays.Children.Add(new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Calendar"), "/EmbeddedResources/Images/Calanders.png", ConfigurationManager.Calendar, typeof(CalendarView)));
            schedules = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("AccessSchedules"), "/EmbeddedResources/Images/Folder.png", null, typeof(SchedulesFolderView));
            schedulesAndHolidays.Children.Add(schedules);
            expressions = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Expressions"), "/EmbeddedResources/Images/Folder.png", null, typeof(MacrosFolderView));
            topLevelNode.Children.Add(expressions);
            cardFormats = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("CardProfiles"), "/EmbeddedResources/Images/Folder.png", null, typeof(CardFormatsFolderView));
            if (showGmsOnlyConfiguration)
                topLevelNode.Children.Add(cardFormats);
            accessGroups = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("AccessGroups"), "/EmbeddedResources/Images/Folder.png", null, typeof(AccessGroupsFolderView));
            if (showUnisonOnlyConfiguration)
                topLevelNode.Children.Add(accessGroups);
            presenceZones = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("PresenceZones"), "/EmbeddedResources/Images/Folder.png", null, typeof(PresenceZonesFolderView));
            topLevelNode.Children.Add(presenceZones);
            readers = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Readers"), "/EmbeddedResources/Images/Folder.png", null, typeof(ReadersFolderView));
            topLevelNode.Children.Add(readers);
            doors = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Doors"), "/EmbeddedResources/Images/Folder.png", null, typeof(DoorsFolderView));
            topLevelNode.Children.Add(doors);
            interlockGroups = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("InterlockGroups"), "/EmbeddedResources/Images/Folder.png", null, typeof(InterlockGroupsFolderView));
            topLevelNode.Children.Add(interlockGroups);
            
            areas = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Areas"), "/EmbeddedResources/Images/Folder.png", null, typeof(AreasFolderView));
            topLevelNode.Children.Add(areas);
            users = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("AlarmUsers"), "/EmbeddedResources/Images/Folder.png", null, typeof(UsersFolderView));
            topLevelNode.Children.Add(users);
            userGroups = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("UserGroups"), "/EmbeddedResources/Images/Folder.png", null, typeof(UserGroupsFolderView));
            topLevelNode.Children.Add(userGroups);
            inputs = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Inputs"), "/EmbeddedResources/Images/Folder.png", null, typeof(InputsFolderView));
            topLevelNode.Children.Add(inputs);
            outputs = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Outputs"), "/EmbeddedResources/Images/Folder.png", null, typeof(OutputsFolderView));
            topLevelNode.Children.Add(outputs);
            elevators = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Elevators"), "/EmbeddedResources/Images/Folder.png", null, typeof(ElevatorsFolderView));
            topLevelNode.Children.Add(elevators);
            elevatorFloors = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("ElevatorFloors"), "/EmbeddedResources/Images/Folder.png", null, typeof(ElevatorFloorsFolderView));
            topLevelNode.Children.Add(elevatorFloors);

            //vaultController = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("VaultController"), "/EmbeddedResources/Images/Folder.png"); //, null, typeof(VaultControllerFolderView));
            //var vcItem = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("VaultController"), "/EmbeddedResources/Images/Calanders.png", ConfigurationManager.VaultConfiguration, typeof(VaultControllerView));
            //vaultController.Children.Add(vcItem);
            //topLevelNode.Children.Add(vaultController);

            string vaultControllerName = Translation.GetTranslatedNodeTreeItem("VaultController");
            //var vcItem = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("VaultController"), "/EmbeddedResources/Images/Calanders.png", ConfigurationManager.VaultConfiguration, typeof(VaultControllerView));
            //vaultController = new NodeTreeElement(vaultControllerName, "/EmbeddedResources/Images/Folder.png", ConfigurationManager.VaultConfiguration, typeof(VaultControllerFolderView));
            //vaultController = new NodeTreeElement(vaultControllerName, "/EmbeddedResources/Images/Folder.png", ConfigurationManager.ControllerConfiguration, typeof(VaultControllerFolderView));

            //vaultController = new NodeTreeElement(vaultControllerName, "/EmbeddedResources/Images/Folder.png", null, typeof(VaultControllerFolderView));
            //vaultController.DisplayName = vaultControllerName;
            //topLevelNode.Children.Add(vaultController);

            vaultControllerInterlockGroups = new NodeTreeElement(vaultControllerName, "/EmbeddedResources/Images/Folder.png", null, typeof(VaultControllerInterlockGroupsFolderView));
            topLevelNode.Children.Add(vaultControllerInterlockGroups);

            //keypads = new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Keypads"), "/EmbeddedResources/Images/Folder.png", null, typeof(KeypadsFolderView));
            //devices.Children.Add(keypads);

            foreach (Port8003ConfigurationBase port in ConfigurationManager.Ports.Values)
            {
                NodeTreeElement portNode = new NodeTreeElement(port.Name, "/EmbeddedResources/Images/Port.png", port, typeof(PortView));
                if (port.ParentDeviceId == ConfigurationManager.ControllerConfiguration.Id)
                {
                    portNode.DisplayName = Translation.GetTranslatedPortName(port.PortNumberOnParent);
                }
                ports.Children.Add(portNode);
            }

            foreach (ControllerConnection8003Table connectionTable in ConfigurationManager.ControllerConnectionTables.Values)
            {
                connectionTables.Children.Add(new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("ConnectionTable") + " " + connectionTable.Id,
                    "/EmbeddedResources/Images/Settings.png", connectionTable, typeof(ConnectionTableView)));
            }

            foreach (ExpansionCardDeviceConfigurationBase expansionCard in ConfigurationManager.ExpansionCards.Values)
            {
                string imageSource = "/EmbeddedResources/Images/820x.png";
                if (expansionCard.CardType == ExpansionCardType.Pacom8203OutputCard)
                    imageSource = "/EmbeddedResources/Images/8203.png";
                else if (expansionCard.CardType == ExpansionCardType.Pacom8204InputCard)
                    imageSource = "/EmbeddedResources/Images/8204.png";

                expansionCards.Children.Add(new NodeTreeElement(expansionCard.Name, imageSource, expansionCard, typeof(DeviceView)));
            }

            NodeTreeElement inovonicsReceiver = null;
            List<NodeTreeElement> inovonicsDevices = new List<NodeTreeElement>();
            foreach (DeviceConfigurationBase device in ConfigurationManager.Devices.Values)
            {
                if (device is Device8003KeypadConfiguration)
                {
                    keypads.Children.Add(new NodeTreeElement(device.Name, "/EmbeddedResources/Images/Keypad.png", device, typeof(DeviceView)));
                }
                else if (device is InovonicsReceiverDeviceConfiguration)
                {
                    inovonicsReceiver = new NodeTreeElement(device.Name, "/EmbeddedResources/Images/Inovonics.png", device, typeof(InovonicsReceiverFolderView));
                    inovonicsNodes.Children.Add(inovonicsReceiver);
                }
                else if (device is InovonicsRepeaterDeviceConfiguration ||
                         device is InovonicsSecurityDeviceConfiguration)
                {
                    string imageSource = "/EmbeddedResources/Images/16_Node.png";
                    if (device is InovonicsRepeaterDeviceConfiguration)
                        imageSource = "/EmbeddedResources/Images/AperioHub.png";
                    inovonicsDevices.Add(new NodeTreeElement(device.Name, imageSource, device, typeof(DeviceView)));
                }
                else if (device is Device8303PowerSupplyConfiguration ||
                         device is Device8308PowerSupplyConfiguration)
                {
                    powerSupplies.Children.Add(new NodeTreeElement(device.Name, "/EmbeddedResources/Images/PowerSupply.png", device, typeof(DeviceView)));
                }
                else if (device is AperioDriverConfiguration)
                {
                    // Hide from the tree
                }
                else
                {
                    peripherals.Children.Add(new NodeTreeElement(device.Name, "/EmbeddedResources/Images/Device.png", device, typeof(DeviceView)));
                }
            }
            if (inovonicsReceiver != null)
            {
                inovonicsReceiver.Children.AddRange(inovonicsDevices);
            }

            foreach (PresenceZone8003Configuration presenceZone in ConfigurationManager.PresenceZones.Values)
            {
                presenceZones.Children.Add(new NodeTreeElement(presenceZone.Name, "/EmbeddedResources/Images/UserAreas.png", presenceZone, typeof(PresenceZoneView)));
            }

            foreach (Group8003Configuration group in ConfigurationManager.Groups.Values)
            {
                userGroups.Children.Add(new NodeTreeElement(group.Name, "/EmbeddedResources/Images/UserGroups.png", group, typeof(UserGroupView)));
            }

            foreach (Reader8003LegacyWiegandConfiguration reader in ConfigurationManager.Readers.Values)
            {
                readers.Children.Add(new NodeTreeElement(reader.Name, "/EmbeddedResources/Images/Reader.png", reader, typeof(ReaderView)));
            }
            foreach (Reader8003Configuration reader in ConfigurationManager.UnisonReaders.Values)
            {
                readers.Children.Add(new NodeTreeElement(reader.Name, "/EmbeddedResources/Images/Reader.png", reader, typeof(UnisonReaderView)));
            }

            foreach (Door8003Configuration door in ConfigurationManager.Doors.Values)
            {
                doors.Children.Add(new NodeTreeElement(door.Name, "/EmbeddedResources/Images/Door.png", door, typeof(DoorView)));
            }

            foreach (Interlock8003Configuration interlockGroup in ConfigurationManager.InterlockGroups.Values)
            {
                interlockGroups.Children.Add(new NodeTreeElement(interlockGroup.Name, "/EmbeddedResources/Images/InterlockGroups.png", interlockGroup, typeof(InterlockGroupView)));
            }

            foreach (var interlockGroup in ConfigurationManager.VaultControllerInterlockGroups.Values)
            {
                vaultControllerInterlockGroups.Children.Add(new NodeTreeElement(interlockGroup.Name, "/EmbeddedResources/Images/InterlockGroups.png", interlockGroup, typeof(VaultControllerInterlockGroupView)));
            }

            foreach (Area8003Configuration area in ConfigurationManager.Areas.Values)
            {
                areas.Children.Add(new NodeTreeElement(area.Name, "/EmbeddedResources/Images/Area.png", area, typeof(AreaView)));
            }

            foreach (User8003Configuration user in ConfigurationManager.Users.Values)
            {
                users.Children.Add(new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("User") + " " + user.Id, "/EmbeddedResources/Images/User.png", user, typeof(UserView)));
            }
            foreach (User user in ConfigurationManager.UnisonUsers.Values)
            {
                users.Children.Add(new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("User") + " " + user.Id, "/EmbeddedResources/Images/User.png", user, typeof(UnisonUserView)));
            }

            foreach (LegacyCardFormat cardFormat in ConfigurationManager.CardFormats.Values)
            {
                cardFormats.Children.Add(new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("CardProfile") + ":" + cardFormat.Id, "/EmbeddedResources/Images/CardProfiles.png", cardFormat, typeof(LegacyCardFormatView)));
            }

            foreach (Schedule schedule in ConfigurationManager.Schedules.Values)
            {
                schedules.Children.Add(new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("Schedule") + ":" + schedule.Id, " /EmbeddedResources/Images/arrow_right_green.png", schedule, typeof(ScheduleView)));
            }

            foreach (Input8003Configuration input in ConfigurationManager.Inputs.Values)
            {
                inputs.Children.Add(new NodeTreeElement(input.Name, "/EmbeddedResources/Images/Input.png", input, typeof(InputView)));
            }

            foreach (Output8003Configuration output in ConfigurationManager.Outputs.Values)
            {
                outputs.Children.Add(new NodeTreeElement(output.Name, "/EmbeddedResources/Images/Output.png", output, typeof(OutputView)));
            }
            
            foreach (var elevator in ConfigurationManager.UnisonElevators.Values)
            {
                elevators.Children.Add(new NodeTreeElement(elevator.Name, "/EmbeddedResources/Images/Elevator.png", elevator, typeof(UnisonElevatorConfigurationView)));
            }

            foreach (var elevator in ConfigurationManager.LegacyElevators.Values)
            {
                elevators.Children.Add(new NodeTreeElement(elevator.Name, "/EmbeddedResources/Images/Elevator.png", elevator, typeof(ElevatorConfigurationView)));
            }

            foreach (var elevatorFloor in ConfigurationManager.ElevatorFloors.Values)
            {
                elevatorFloors.Children.Add(new NodeTreeElement(elevatorFloor.Name, "/EmbeddedResources/Images/ElevatorFloor.png", elevatorFloor, typeof(ElevatorFloorConfigurationView)));
            }

            foreach (Macro8003Configuration expression in ConfigurationManager.Macros.Values)
            {
                expressions.Children.Add(new NodeTreeElement(expression.Name, "/EmbeddedResources/Images/16_AND.png", expression, typeof(MacroView)));
            }

            foreach (AccessGroup accessGroup in ConfigurationManager.UnisonAccessGroups.Values)
            {
                accessGroups.Children.Add(new NodeTreeElement(Translation.GetTranslatedNodeTreeItem("AccessGroup") + ":" + accessGroup.Id, "/EmbeddedResources/Images/16_Accessgroup2.png", accessGroup, typeof(AccessGroupView)));
            }

            instance.ParentNode.Clear();
            instance.ParentNode.Add(topLevelNode);
            instance.RefreshTree();
            topLevelNode.IsSelected = true;
        }
    }
}
