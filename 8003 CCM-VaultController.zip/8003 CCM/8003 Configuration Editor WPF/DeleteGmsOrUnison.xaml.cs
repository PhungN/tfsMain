﻿using System.Globalization;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using Pacom.Peripheral.Common;

namespace Pacom.ConfigurationEditor.WPF
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class DeleteGmsOrUnison : Window
    {
        public bool DeleteGmsConfiguration
        {
            get;
            private set;
        }

        public bool DeleteUnisonConfiguration
        {
            get;
            private set;
        }

        public DeleteGmsOrUnison()
        {
            InitializeComponent();
            Owner = MainWindow.Instance;

            Title = Translation.GetTranslatedError(ErrorMessage.Error);
            lblMessage.Content = Translation.GetTranslatedError(ErrorMessage.SelectConfigurationToRemove);
            btnRemoveUnison.Content = Translation.GetTranslatedError(ErrorMessage.RemoveUnison);
            btnRemoveGms.Content = Translation.GetTranslatedError(ErrorMessage.RemoveGms);
            btnCancel.Content = Translation.GetTranslatedError(ErrorMessage.Cancel);

            centreTitle();
            centreMessage();

            btnCancel.Focus();
        }

        private void centreTitle()
        {
            double titleWidth = measureStringWidth(Title, this.FontFamily, this.FontStyle, this.FontWeight, this.FontStretch, this.FontSize);
            double spaceWidth = measureStringWidth(" A", this.FontFamily, this.FontStyle, this.FontWeight, this.FontStretch, this.FontSize) - measureStringWidth("A", this.FontFamily, this.FontStyle, this.FontWeight, this.FontStretch, this.FontSize);

            int spacesRequired = (int)(((Width / 2) - (titleWidth / 2) - 32) / spaceWidth);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < spacesRequired; i++)
            {
                sb.Append(" ");
            }
            sb.Append(Title);
            Title = sb.ToString();
        }

        private void centreMessage()
        {
            double messageWidth = measureStringWidth((string)lblMessage.Content, this.FontFamily, this.FontStyle, this.FontWeight, this.FontStretch, this.FontSize);
            double spaceWidth = measureStringWidth(" A", this.FontFamily, this.FontStyle, this.FontWeight, this.FontStretch, this.FontSize) - measureStringWidth("A", this.FontFamily, this.FontStyle, this.FontWeight, this.FontStretch, this.FontSize);

            int spacesRequired = (int)(((Width / 2) - (messageWidth / 2) - 10) / spaceWidth);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < spacesRequired; i++)
            {
                sb.Append(" ");
            }
            sb.Append((string)lblMessage.Content);
            lblMessage.Content = sb.ToString();
        }

        private double measureStringWidth(string text, FontFamily fontFamily, FontStyle fontStyle, FontWeight fontWeight, FontStretch fontStretch, double fontSize)
        {
            return new FormattedText(text, CultureInfo.CurrentCulture, FlowDirection.LeftToRight, new Typeface(fontFamily, fontStyle, fontWeight, fontStretch), fontSize, Brushes.Black).Width;
        }

        private void buttonCancel_Click(object sender, RoutedEventArgs e)
        {
            DeleteGmsConfiguration = false;
            DeleteUnisonConfiguration = false;
            Close();
        }
        private void buttonGms_Click(object sender, RoutedEventArgs e)
        {
            DeleteGmsConfiguration = true;
            DeleteUnisonConfiguration = false;
            Close();
        }
        private void buttonUnison_Click(object sender, RoutedEventArgs e)
        {
            DeleteGmsConfiguration = false;
            DeleteUnisonConfiguration = true;
            Close();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Close();
            }
        }
    }
}
