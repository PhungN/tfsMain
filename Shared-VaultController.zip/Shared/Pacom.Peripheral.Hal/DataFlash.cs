﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class provides read and write access to the Data Flash.
    /// </summary>
    public class DataFlash : IDataFlash
    {
        /// <summary>
        /// Singleton instatnce of DataFlash class
        /// </summary>
        private static IDataFlash instance = null;

        /// <summary>
        /// Instance method to get singleton
        /// </summary>
        /// <returns></returns>
        public static IDataFlash Instance
        {
            // Lock deliberately omitted
            get
            {
                // Lock deliberately omitted
                if (instance == null)
                {
                    instance = new DataFlash();
                }
                return instance;
            }
        }

        private DataFlash()
        {
            // No default constructor
        }

        private const byte statusRegisterReadCommand = 0xD7;
        private const byte continuousArrayReadCommand = 0xE8;
        private const byte mainMemoryPageToBuffer1TransferCommand = 0x53;
        private const byte buffer1WriteCommand = 0x84;
        private const byte buffer1ToMainMemoryPageTransferCommand = 0x83;
        private const byte mainMemoryPageProgramThroughBuffer1Command = 0x82;
        public const int PageSize = 264;

        public bool WriteAndVerifyData(int offset, byte[] data)
        {
            if (WriteData(offset, data) == false)
            {
                return false;
            }
            byte[] readBack = ReadData(offset, data.Length);
            return readBack != null && readBack.SequenceEqual(data);
        }

        /// <summary>
        /// Writes a byte array to the data flash at a specified offset.
        /// </summary>
        /// <param name="offset">The position within the data flash to write the data.</param>
        /// <param name="data">The content to write to the data flash.</param>
        /// <returns>True on success.</returns>
        public bool WriteData(int offset, byte[] data)
        {
            int dataOffset = 0;
            int remaining = data.Length;
            byte[] buffer;
            byte[] buffer4 = new byte[4];
            UInt32 address;
            if ((offset % PageSize) != 0)
            {
                // Write is not page aligned so we need to do a read first

                // Copy a page to the DataFlash internal buffer
                address = (UInt32)((offset / PageSize) << 9);
                buffer4[0] = mainMemoryPageToBuffer1TransferCommand;
                buffer4[1] = (byte)((address & 0x00FF0000) >> 16);
                buffer4[2] = (byte)((address & 0x0000FF00) >> 8);
                buffer4[3] = (byte)(address & 0x000000FF);
                if (Spi.CommunicateWithDevice(SpiDevice.DataFlash, buffer4, null) == false)
                    return false;
                if (waitOnReady() == false)
                    return false;

                // Overwrite the data in the DataFlash internal buffer
                int amountToWrite = PageSize - (offset % PageSize);
                if (remaining < amountToWrite)
                    amountToWrite = remaining;
                buffer = new byte[amountToWrite + 4];
                address = (UInt32)(offset % PageSize);
                buffer[0] = buffer1WriteCommand;
                buffer[1] = (byte)((address & 0x00FF0000) >> 16);
                buffer[2] = (byte)((address & 0x0000FF00) >> 8);
                buffer[3] = (byte)(address & 0x000000FF);
                Buffer.BlockCopy(data, 0, buffer, 4, amountToWrite);
                if (Spi.CommunicateWithDevice(SpiDevice.DataFlash, buffer, null) == false)
                    return false;
                if (waitOnReady() == false)
                    return false;

                // Copy the page back from the DataFlash internal buffer
                address = (UInt32)((offset / PageSize) << 9);
                buffer4[0] = buffer1ToMainMemoryPageTransferCommand;
                buffer4[1] = (byte)((address & 0x00FF0000) >> 16);
                buffer4[2] = (byte)((address & 0x0000FF00) >> 8);
                buffer4[3] = (byte)(address & 0x000000FF);
                if (Spi.CommunicateWithDevice(SpiDevice.DataFlash, buffer4, null) == false)
                    return false;
                if (waitOnReady() == false)
                    return false;

                remaining -= amountToWrite;
                dataOffset += amountToWrite;
            }

            if (remaining == 0)
                return true;

            buffer = new byte[PageSize + 4];
            while (remaining >= PageSize)
            {
                address = (UInt32)(((offset + dataOffset) / PageSize) << 9);
                buffer[0] = mainMemoryPageProgramThroughBuffer1Command;
                buffer[1] = (byte)((address & 0x00FF0000) >> 16);
                buffer[2] = (byte)((address & 0x0000FF00) >> 8);
                buffer[3] = (byte)(address & 0x000000FF);
                Buffer.BlockCopy(data, dataOffset, buffer, 4, PageSize);
                if (Spi.CommunicateWithDevice(SpiDevice.DataFlash, buffer, null) == false)
                    return false;
                if (waitOnReady() == false)
                    return false;

                remaining -= PageSize;
                dataOffset += PageSize;
            }

            if (remaining > 0)
            {
                // Write doesn't finish at the end of a page

                // Copy a page to the DataFlash internal buffer
                address = (UInt32)(((offset + dataOffset) / PageSize) << 9);
                buffer4[0] = mainMemoryPageToBuffer1TransferCommand;
                buffer4[1] = (byte)((address & 0x00FF0000) >> 16);
                buffer4[2] = (byte)((address & 0x0000FF00) >> 8);
                buffer4[3] = (byte)(address & 0x000000FF);
                if (Spi.CommunicateWithDevice(SpiDevice.DataFlash, buffer4, null) == false)
                    return false;
                if (waitOnReady() == false)
                    return false;

                // Overwrite the data in the DataFlash internal buffer
                buffer = new byte[remaining + 4];
                address = (UInt32)((offset + dataOffset) % PageSize);
                buffer[0] = buffer1WriteCommand;
                buffer[1] = (byte)((address & 0x00FF0000) >> 16);
                buffer[2] = (byte)((address & 0x0000FF00) >> 8);
                buffer[3] = (byte)(address & 0x000000FF);
                Buffer.BlockCopy(data, dataOffset, buffer, 4, remaining);
                if (Spi.CommunicateWithDevice(SpiDevice.DataFlash, buffer, null) == false)
                    return false;
                if (waitOnReady() == false)
                    return false;

                // Copy the page back from the DataFlash internal buffer
                address = (UInt32)(((offset + dataOffset) / PageSize) << 9);
                buffer4[0] = buffer1ToMainMemoryPageTransferCommand;
                buffer4[1] = (byte)((address & 0x00FF0000) >> 16);
                buffer4[2] = (byte)((address & 0x0000FF00) >> 8);
                buffer4[3] = (byte)(address & 0x000000FF);
                if (Spi.CommunicateWithDevice(SpiDevice.DataFlash, buffer4, null) == false)
                    return false;
                if (waitOnReady() == false)
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Reads a byte array from the data flash at a specified offset and length.
        /// </summary>
        /// <param name="offset">The position within the data flash to read data from.</param>
        /// <param name="length">The number of bytes to read.</param>
        /// <returns>byte array on success, null otherwise</returns>
        public byte[] ReadData(int offset, int length)
        {
            byte[] data = new byte[length];
            if (ReadData(offset, data))
            {
                return data;
            }
            return null;
        }

        /// <summary>
        /// Reads a byte array from the data flash at a specified offset.
        /// </summary>
        /// <param name="offset">The position within the data flash to read data from.</param>
        /// <param name="data">The content to read from the data flash.</param>
        /// <returns>True on success.</returns>
        public bool ReadData(int offset, byte[] data)
        {
            int dataOffset = 0;
            int remaining = data.Length;
            int amountToRead;
            byte[] buffer = null;

            while (remaining > 0)
            {
                amountToRead = remaining;
                if (amountToRead > 0x3F8)
                {
                    amountToRead = 0x3F8;
                    if (buffer == null)
                        buffer = new byte[0x400];
                }
                else
                {
                    if (buffer == null)
                        buffer = new byte[amountToRead + 8];
                }

                if (waitOnReady() == false)
                    return false;

                UInt32 address = (UInt32)((((offset + dataOffset) / PageSize) << 9) + ((offset + dataOffset) % PageSize));
                buffer = new byte[amountToRead + 8];

                buffer[0] = continuousArrayReadCommand;
                buffer[1] = (byte)((address & 0x00FF0000) >> 16);
                buffer[2] = (byte)((address & 0x0000FF00) >> 8);
                buffer[3] = (byte)(address & 0x000000FF);
		        buffer[4] = 0;
                buffer[5] = 0;
                buffer[6] = 0;
                buffer[7] = 0;

                if (Spi.CommunicateWithDevice(SpiDevice.DataFlash, buffer, buffer) == false)
                    return false;

                Buffer.BlockCopy(buffer, 8, data, dataOffset, amountToRead);
                dataOffset += amountToRead;
                remaining -= amountToRead;
            }

            return true;
        }

        private static bool waitOnReady()
        {
            byte[] data = new byte[2];

            // Check if the DataFlash is ready
            for (int i = 0; i < 2000; i++)
            {
                data[0] = statusRegisterReadCommand;
                if (Spi.CommunicateWithDevice(SpiDevice.DataFlash, data, data) == false)
                    return false;
                if ((data[1] & 0x80) == 0x80)
                    return true;
            }

            return false;
        }
    }
}
