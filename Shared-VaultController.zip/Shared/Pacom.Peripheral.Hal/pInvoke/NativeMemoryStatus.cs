﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// Platform invoke for WinCE memory status 
    /// </summary>
    public static class NativeMemoryStatus
    {
        private const string NewLine = "\r\n";

        [DllImport("coredll.dll")]
        public static extern
        void GlobalMemoryStatus(ref MemoryStatus lpBuffer);

        [DllImport("coredll.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern        
        bool GetSystemMemoryDivision(ref UInt32 lpdwStorePages, ref UInt32 lpdwRamPages, ref UInt32 lpdwPageSize);

        [DllImport("coredll.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern
        bool GetStoreInformation(ref StoreInformation lpsi);

        public struct StoreInformation
        {
            public int dwStoreSize;
            public int dwFreeSize;
        }

        public struct MemoryStatus
        {
            public int dwLength;
            public int dwMemoryLoad;
            public int dwTotalPhys;
            public int dwAvailPhys;
            public int dwTotalPageFile;
            public int dwAvailPageFile;
            public int dwTotalVirtual;
            public int dwAvailVirtual;
        }

        public const int OneKB = 1024;

        /// <summary>
        /// Returns memory status for the current system
        /// </summary>
        /// <returns>String with preformatted memory usage.</returns>
        public static string GetMemoryStatus()
        {
            string result = string.Empty;
            try
            {
                UInt32 totPages = 0;
                UInt32 storeUsed = 0;
                UInt32 ramUsed = 0;
                UInt32 storePages = 0;
                UInt32 ramPages = 0;
                UInt32 pageSize = 0;

                GetSystemMemoryDivision(ref storePages, ref ramPages, ref pageSize);

                StoreInformation storeInfo = new StoreInformation();
                GetStoreInformation(ref storeInfo);

                storeInfo.dwStoreSize /= (Int32)pageSize;
                storeInfo.dwFreeSize /= (Int32)pageSize;

                pageSize /= OneKB;
                totPages = storePages + ramPages;
                // use the 'free' number. Becuase dwStoreSize has some compression and it is in-accurate 
                storeUsed = (UInt32)(storePages - storeInfo.dwFreeSize);

                MemoryStatus memoryStatus = new MemoryStatus();
                memoryStatus.dwLength = Marshal.SizeOf(memoryStatus);
                GlobalMemoryStatus(ref memoryStatus);

                memoryStatus.dwTotalPhys /= ((Int32)pageSize * OneKB);
                memoryStatus.dwAvailPhys /= ((Int32)pageSize * OneKB);

                // '-1' because page #0 for system page ?
                ramUsed = (UInt32)(memoryStatus.dwTotalPhys - memoryStatus.dwAvailPhys + 1);

                result = String.Format(
                    "TotalMemory={0}KB, Store={1}KB, StoreUsed={2}KB, Program={3}KB ProgramUsed={4}KB ({5}%) Managed={6}KB",
                    pageSize * totPages,
                    pageSize * storePages,
                    pageSize * storeUsed,
                    pageSize * (totPages - storePages),
                    pageSize * ramUsed,
                    (100 * ramUsed) / (totPages - storePages),
                    GC.GetTotalMemory(true) / 1024);
            }
            catch
            {
                result = "Unable to get memory status for this device.";
            }
            return result;
        }

        /// <summary>
        /// Returns memory status for the current system
        /// </summary>
        public static void GetMemoryStatus(out uint totalMemoryOut, out uint storeOut, out uint storeUsedOut, 
            out uint programOut, out uint programUsedOut, out uint ProgramUsedPercentOut, out uint managedOut)
        {
            try
            {
                UInt32 totPages = 0;
                UInt32 storeUsed = 0;
                UInt32 ramUsed = 0;
                UInt32 storePages = 0;
                UInt32 ramPages = 0;
                UInt32 pageSize = 0;

                GetSystemMemoryDivision(ref storePages, ref ramPages, ref pageSize);

                StoreInformation storeInfo = new StoreInformation();
                GetStoreInformation(ref storeInfo);

                storeInfo.dwStoreSize /= (Int32)pageSize;
                storeInfo.dwFreeSize /= (Int32)pageSize;

                pageSize /= OneKB;
                totPages = storePages + ramPages;
                // use the 'free' number. Becuase dwStoreSize has some compression and it is in-accurate 
                storeUsed = (UInt32)(storePages - storeInfo.dwFreeSize);

                MemoryStatus memoryStatus = new MemoryStatus();
                memoryStatus.dwLength = Marshal.SizeOf(memoryStatus);
                GlobalMemoryStatus(ref memoryStatus);

                memoryStatus.dwTotalPhys /= ((Int32)pageSize * OneKB);
                memoryStatus.dwAvailPhys /= ((Int32)pageSize * OneKB);

                // '-1' because page #0 for system page ?
                ramUsed = (UInt32)(memoryStatus.dwTotalPhys - memoryStatus.dwAvailPhys + 1);

                totalMemoryOut = pageSize * totPages;
                storeOut = pageSize * storePages;
                storeUsedOut = pageSize * storeUsed;
                programOut = pageSize * (totPages - storePages);
                programUsedOut = pageSize * ramUsed;
                ProgramUsedPercentOut = (100 * ramUsed) / (totPages - storePages);
                managedOut = (uint)(GC.GetTotalMemory(true) / 1024);
            }
            catch
            {
                totalMemoryOut = 0;
                storeOut = 0;
                storeUsedOut = 0;
                programOut = 0;
                programUsedOut = 0;
                ProgramUsedPercentOut = 0;
                managedOut = 0;
            }
        }

        /// <summary>
        /// Returns memory usage in percent. 100% memory is full.
        /// </summary>
        public static int GetFreeMemoryPercentage()
        {
            uint totalMemoryOut;
            uint storeOut;
            uint storeUsedOut;
            uint programOut;
            uint programUsedOut;
            uint ProgramUsedPercentOut;
            uint managedOut;
            NativeMemoryStatus.GetMemoryStatus(
                out totalMemoryOut,
                out storeOut,
                out storeUsedOut,
                out programOut,
                out programUsedOut,
                out ProgramUsedPercentOut,
                out managedOut);
            return (int)ProgramUsedPercentOut;
        }
    }
}
