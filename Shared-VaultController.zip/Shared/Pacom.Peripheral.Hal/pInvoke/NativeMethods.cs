﻿using System;
using System.Runtime.InteropServices;
using HANDLE = System.IntPtr;

namespace Pacom.Peripheral.Hal
{
    public static class NativeMethods
    {
        // Control Code flags
        private const uint FILE_DEVICE_UNKNOWN = 0x00000022;
        private const uint FILE_DEVICE_HAL = 0x00000101;
        private const uint FILE_DEVICE_CONSOLE = 0x00000102;
        private const uint FILE_DEVICE_PSL = 0x00000103;
        private const uint METHOD_BUFFERED = 0;
        private const uint METHOD_IN_DIRECT = 1;
        private const uint METHOD_OUT_DIRECT = 2;
        private const uint METHOD_NEITHER = 3;
        private const uint FILE_ANY_ACCESS = 0;
        private const uint FILE_READ_ACCESS = 0x0001;
        private const uint FILE_WRITE_ACCESS = 0x0002;

        private const uint HAL_USART0_IS_RS485 = 2048;
        private const uint HAL_USART1_IS_RS485 = 2049;
        private const uint HAL_USART2_IS_RS485 = 2050;
        private const uint HAL_USART3_IS_RS232 = 2051;

        /// <summary>
        /// Defined IOCTLs for RS232 / RS485 Serial driver
        /// </summary>
        public const int IOCTL_SERIAL_GET_DCB = 0x1B0050;
        public const int IOCTL_SERIAL_SET_DCB = 0x1B0054;
        public const int IOCTL_SERIAL_PURGE = 0x1B0044;

        private static uint CTL_CODE(uint DeviceType, uint Function, uint Method, uint Access)
        {
            return ((DeviceType << 16) | (Access << 14) | (Function << 2) | Method);
        }

        [DllImport("Coredll.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private extern static bool KernelIoControl(uint dwIoControlCode, IntPtr lpInBuf, uint nInBufSize, IntPtr lpOutBuf, uint nOutBufSize, ref uint lpBytesReturned);

        [DllImport("Coredll.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool KernelIoControl(int dwIoControlCode, ref Int32 lpInBuffer, int nInBufferSize, ref Int32 lpOutBuffer, int nOutBufferSize, ref uint lpBytesReturned);

        public static void UartIsRS485(int portId, bool enabled)
        {
            switch (portId)
            {
                case 1:
                    {
                        uint bytesReturned = 0;
                        int ctrlValue = enabled == true ? 1 : 0;
                        int returnValue = 1;
                        int ctrlCode = (int)CTL_CODE(FILE_DEVICE_HAL, HAL_USART1_IS_RS485, METHOD_BUFFERED, FILE_ANY_ACCESS);
                        KernelIoControl(ctrlCode, ref ctrlValue, sizeof(int), ref returnValue, 0, ref bytesReturned);
                        break;
                    }
                case 2:
                    {
                        uint bytesReturned = 0;
                        int ctrlValue = enabled == true ? 1 : 0;
                        int returnValue = 1;
                        int ctrlCode = (int)CTL_CODE(FILE_DEVICE_HAL, HAL_USART0_IS_RS485, METHOD_BUFFERED, FILE_ANY_ACCESS);
                        KernelIoControl(ctrlCode, ref ctrlValue, sizeof(int), ref returnValue, 0, ref bytesReturned);
                        break;
                    }
                case 3:
                    {
                        uint bytesReturned = 0;
                        int ctrlValue = enabled == true ? 1 : 0;
                        int returnValue = 1;
                        int ctrlCode = (int)CTL_CODE(FILE_DEVICE_HAL, HAL_USART2_IS_RS485, METHOD_BUFFERED, FILE_ANY_ACCESS);
                        KernelIoControl(ctrlCode, ref ctrlValue, sizeof(int), ref returnValue, 0, ref bytesReturned);
                        break;
                    }
            }
        }

        public static void DebugUartIsRS232(bool enabled)
        {
            uint bytesReturned = 0;
            int ctrlValue = enabled == true ? 1 : 0;
            int returnValue = 1;
            int ctrlCode = (int)CTL_CODE(FILE_DEVICE_HAL, HAL_USART3_IS_RS232, METHOD_BUFFERED, FILE_ANY_ACCESS);
            KernelIoControl(ctrlCode, ref ctrlValue, sizeof(int), ref returnValue, 0, ref bytesReturned);
        } 

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern IntPtr CreateFile(String lpFileName, [MarshalAs(UnmanagedType.U4)] FileAccess dwDesiredAccess, [MarshalAs(UnmanagedType.U4)] FileShare dwShareMode, IntPtr lpSecurityAttributes, [MarshalAs(UnmanagedType.U4)] CreationDisposition dwCreationDisposition, [MarshalAs(UnmanagedType.U4)] FileAttribute dwFlagsAndAttributes, IntPtr hTemplateFile);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern IntPtr CreateEvent(IntPtr lpEventAttributes, [In, MarshalAs(UnmanagedType.Bool)] bool bManualReset, [In, MarshalAs(UnmanagedType.Bool)] bool bIntialState, [In, MarshalAs(UnmanagedType.BStr)] string lpName);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern IntPtr OpenEvent(int dwDesiredAccess, [In, MarshalAs(UnmanagedType.Bool)] bool bInheritHandle, [In, MarshalAs(UnmanagedType.BStr)] string lpName); 

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, byte[] lpInBuffer, int nInBufferSize, byte[] lpOutBuffer, int nOutBufferSize, out int lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref I2cReadStructure lpInBuffer, int nInBufferSize, byte[] lpOutBuffer, int nOutBufferSize, out int lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref I2cWriteStructure lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref SpiTransactionStructure lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref SramTransactionStructure lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref GpioPortStructure lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref GpioConfigureStructure lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);
        
        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref IntPtr lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, IntPtr lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, IntPtr lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, out int lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, IntPtr lpInBuffer, int nInBufferSize, ref NandFlashInfoStructure lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref NandFlashReadWriteStructure lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref Int32 lpInBuffer, int nInBufferSize, ref Int32 lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, IntPtr lpInBuffer, int nInBufferSize, ref DcbStructure lpOutBuffer, int nOutBufferSize, out int lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref DcbStructure lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref SerialPurgeStructure lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, IntPtr lpInBuffer, int nInBufferSize, ref ResetLevelStructure lpOutBuffer, int nOutBufferSize, out int lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, IntPtr lpInBuffer, int nInBufferSize, ref ResetTypeStructure lpOutBuffer, int nOutBufferSize, out int lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, IntPtr lpInBuffer, int nInBufferSize, ref SerialDevStatusStructure lpOutBuffer, int nOutBufferSize, out int lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, byte[] lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, out int lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref CriStructure lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int DeviceIoControl(IntPtr hDevice, int dwIoControlCode, ref MuxConfigurationStructure lpInBuffer, int nInBufferSize, IntPtr lpOutBuffer, int nOutBufferSize, IntPtr lpBytesReturned, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int WaitForSingleObject(IntPtr hHandle, UInt32 dwMilliseconds);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int WaitForMultipleObjects(UInt32 nCount, IntPtr[] lpHandles, int fWaitAll, UInt32 dwMilliseconds);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int CloseHandle(IntPtr hObject);

        [DllImport("coredll.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool EventModify(IntPtr hEvent, [In, MarshalAs(UnmanagedType.U4)] EventFlags dEvent);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int SetCommTimeouts(IntPtr hDevice, ref CommTimeoutsStructure lpCommTimeouts);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int SetCommMask(IntPtr hDevice, UInt32 dwEvtMask);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int WaitCommEvent(IntPtr hDevice, out int lpEvtMask, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int ReadFile(IntPtr hDevice, byte[] lpBuffer, UInt32 nNumberOfBytesToRead, out UInt32 lpNumberOfBytesRead, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int WriteFile(IntPtr hDevice, byte[] lpBuffer, UInt32 nNumberOfBytesToWrite, out UInt32 lpNumberOfBytesWritten, IntPtr lpOverlapped);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern int CeSetThreadPriority(IntPtr hThread, int nPriority);

        [DllImport("iphlpapi.dll")]
        public static extern UInt32 IcmpSendEcho2(IntPtr icmpHandle, IntPtr Event, IntPtr apcRoutine, IntPtr apcContext, UInt32 ipAddress, IntPtr data, UInt16 dataSize, IntPtr options, IntPtr replyBuffer, UInt32 replySize, UInt32 timeout);

        [DllImport("iphlpapi.dll")]
        public static extern IntPtr IcmpCreateFile();

        [DllImport("iphlpapi.dll")]
        public static extern UInt32 IcmpCloseHandle(IntPtr handle);

        public static bool SetEvent(IntPtr hEvent)
        {
            return EventModify(hEvent, EventFlags.Set);
        }

        [DllImport("coredll.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetSystemTime(ref SystemTimeStructure time);

        [DllImport("coredll.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetLocalTime(ref SystemTimeStructure time);

        [DllImport("coredll.dll", SetLastError = true)]
        public static extern IntPtr ActivateDeviceEx(string device, IntPtr regEnts, UInt32 cRegEnts, IntPtr devKey);
                
        [DllImport("coredll.dll", SetLastError = true)]
        public static extern IntPtr FindFirstDevice(DeviceSearchType searchType, IntPtr searchParam, ref DevMgrDeviceInformationStructure pdi);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "FindClose")]
        public static extern bool FindClose(HANDLE hFindFile);


        [DllImport("coredll.dll", CharSet = CharSet.Auto)]
        public static extern int GetTimeZoneInformation(out TimeZoneInformationStructure TimeZoneInformation);

        [DllImport("coredll.dll", CharSet = CharSet.Auto)]
        public static extern int SetTimeZoneInformation(ref TimeZoneInformationStructure TimeZoneInformation);

        [DllImport("iphlpapi.dll", CharSet = CharSet.Auto)]
        public static extern int GetAdaptersInfo(IntPtr pAdapterInfo, ref UInt32 pBufOutLen);

        [DllImport("iphlpapi.dll", CharSet = CharSet.Auto)]
        public static extern int GetNetworkParams(IntPtr pFixedInfo, ref UInt32 pBufOutLen);

        [DllImport("Iphlpapi.dll", SetLastError = true)]
        public static extern UInt32 NotifyAddrChange(ref IntPtr handle, IntPtr lpOverlapped);

        [DllImport("iphlpapi.dll", SetLastError = true)]
        public static extern int GetTcpTable(byte[] pTcpTable, out int pdwSize, bool bOrder);

        [DllImport("iphlpapi.dll", CharSet = CharSet.Auto)]
        public static extern int GetIpForwardTable(byte[] pIpForwardTable, ref int pBufOutLen, bool bOrder);

        [DllImport("iphlpapi.dll", CharSet = CharSet.Auto)]
        public static extern int SetIpForwardEntry(byte[] pRoute);

        [DllImport(@"coredll.dll")]
        internal static extern int CryptAcquireContext(ref int phProv, string pszContainer, string pszProvider, int dwProvType, int dwFlags);

        [DllImport(@"coredll.dll")]
        internal static extern int CryptReleaseContext(int hProv, int dwFlags);

        [DllImport(@"coredll.dll")]
        internal static extern int CryptImportKey(int hProv, IntPtr pbData, int dwDataLen, int hPubKey, int dwFlags, ref int phKey);

        [DllImport(@"coredll.dll")]
        internal static extern int CryptImportKey(int hProv, byte[] pbData, int dwDataLen, int hPubKey, int dwFlags, ref int phKey);

        [DllImport(@"coredll.dll")]
        internal static extern int CryptDestroyKey(int hKey);

        [DllImport(@"coredll.dll")]
        internal static extern int CryptEncrypt(int hKey, int hHash, int Final, int dwFlags, IntPtr pbData, ref int pdwDataLen, int dwBufLen);

        [DllImport(@"coredll.dll")]
        internal static extern int CryptDecrypt(int hKey, int hHash, int Final, int dwFlags, IntPtr pbData, ref int pdwDataLen);

        [DllImport(@"coredll.dll")]
        internal static extern int CryptSetKeyParam(int hKey, int dwParam, byte[] pbData, int dwFlags);

        [DllImport(@"coredll.dll")]
        internal static extern int CryptSetKeyParam(int hKey, int dwParam, ref int pbData, int dwFlags);

        [DllImport(@"coredll.dll")]
        internal static extern int CryptGenRandom(int hProv, int dwLen, byte[] pbBuffer);
    }
}
