﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    [StructLayout(LayoutKind.Sequential)]
    public struct ResetLevelStructure
    {
        public byte ResetLevel;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct ResetTypeStructure
    {
        public byte ResetType;
    }
}
