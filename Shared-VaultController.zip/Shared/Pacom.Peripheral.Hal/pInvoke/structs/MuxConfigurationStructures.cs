﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    [StructLayout(LayoutKind.Sequential)]
    public struct MuxConfigurationStructure
    {
        public UInt32 CommPortNumber;
        public UInt32 CommBaudRate;
    }
}
