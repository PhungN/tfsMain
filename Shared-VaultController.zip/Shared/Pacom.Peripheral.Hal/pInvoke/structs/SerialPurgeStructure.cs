﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    [StructLayout(LayoutKind.Sequential)]
    public struct SerialPurgeStructure
    {
        public uint Flags;
    }
}
