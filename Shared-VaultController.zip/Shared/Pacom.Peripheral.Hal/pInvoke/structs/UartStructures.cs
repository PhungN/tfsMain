﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    [StructLayout(LayoutKind.Sequential)]
    public struct DcbStructure
    {
        public UInt32 DCBlength;      /* sizeof(DCB)                     */
        public UInt32 BaudRate;       /* Baudrate at which running       */
        public UInt32 Flags;          /* Reserved                        */
        public UInt16 wReserved;      /* Not currently used              */
        public UInt16 XonLim;         /* Transmit X-ON threshold         */
        public UInt16 XoffLim;        /* Transmit X-OFF threshold        */
        public byte ByteSize;         /* Number of bits/public byte, 4-8 */
        public byte Parity;           /* 0-4=None,Odd,Even,Mark,Space    */
        public byte StopBits;         /* 0,1,2 = 1, 1.5, 2               */
        public byte XonChar;          /* Tx and Rx X-ON public byteacter */
        public byte XoffChar;         /* Tx and Rx X-OFF public byteacter*/
        public byte ErrorChar;        /* Error replacement public byte   */
        public byte EofChar;          /* End of Input public byteacter   */
        public byte EvtChar;          /* Received Event public byteacter */
        public UInt16 wReserved1;     /* Fill for now.                   */
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct CommTimeoutsStructure
    {
        public UInt32 ReadIntervalTimeout;          /* Maximum time between read chars. */
        public UInt32 ReadTotalTimeoutMultiplier;   /* Multiplier of characters.        */
        public UInt32 ReadTotalTimeoutConstant;     /* Constant in milliseconds.        */
        public UInt32 WriteTotalTimeoutMultiplier;  /* Multiplier of characters.        */
        public UInt32 WriteTotalTimeoutConstant;    /* Constant in milliseconds.        */
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct ComStatStructure
    {
        public UInt32 Flags;
        public UInt32 cbInQue;
        public UInt32 cbOutQue;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SerialDevStatusStructure
    {
        public UInt32 Errors;
        public ComStatStructure ComStat;
    }
}
