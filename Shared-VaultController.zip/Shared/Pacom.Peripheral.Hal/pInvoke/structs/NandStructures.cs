﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    [StructLayout(LayoutKind.Sequential)]
    public struct NandFlashInfoStructure
    {
        public int flashType;
        public UInt32 numberOfBlocks;
        public UInt32 bytesPerBlock;
        public UInt16 sectorsPerBlock;
        public UInt16 bytesPerSector;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct NandFlashReadWriteStructure
    {
        public UInt32 sectorNumber;
        public IntPtr bufferAddress;
    }
}
