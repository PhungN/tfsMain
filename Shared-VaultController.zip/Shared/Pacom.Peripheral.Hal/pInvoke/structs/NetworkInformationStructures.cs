﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    internal struct FIXED_INFO
    {
        const int MAX_HOSTNAME_LEN = 128;
        const int MAX_DOMAIN_NAME_LEN = 128;
        const int MAX_SCOPE_ID_LEN = 256;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_HOSTNAME_LEN + 4)]
        internal byte[] HostName;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_DOMAIN_NAME_LEN + 4)]
        internal byte[] DomainName;
        internal IntPtr CurrentDnsServer;
        internal IP_ADDR_STRING DnsServerList;
        internal UInt32 NodeType;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_SCOPE_ID_LEN + 4)]
        internal byte[] ScopeId;
        internal UInt32 EnableRouting;
        internal UInt32 EnableProxy;
        internal UInt32 EnableDns;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    internal struct IP_ADDRESS_STRING
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
        internal byte[] Address;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    internal struct IP_ADDR_STRING
    {
        internal IntPtr Next;
        internal IP_ADDRESS_STRING IpAddress;
        internal IP_ADDRESS_STRING IpMask;
        internal Int32 Context;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    internal struct IP_ADAPTER_INFO
    {
        const int MAX_ADAPTER_NAME_LENGTH = 256;
        const int MAX_ADAPTER_ADDRESS_LENGTH = 8;
        const int MAX_ADAPTER_DESCRIPTION_LENGTH = 128;

        internal IntPtr Next;
        internal Int32 ComboIndex;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_ADAPTER_NAME_LENGTH + 4)]
        internal byte[] AdapterName;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_ADAPTER_DESCRIPTION_LENGTH + 4)]
        internal byte[] AdapterDescription;
        internal UInt32 AddressLength;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_ADAPTER_ADDRESS_LENGTH)]
        internal byte[] Address;
        internal Int32 Index;
        internal UInt32 Type;
        internal UInt32 DhcpEnabled;
        internal IntPtr CurrentIpAddress;
        internal IP_ADDR_STRING IpAddressList;
        internal IP_ADDR_STRING GatewayList;
        internal IP_ADDR_STRING DhcpServer;
        internal bool HaveWins;
        internal IP_ADDR_STRING PrimaryWinsServer;
        internal IP_ADDR_STRING SecondaryWinsServer;
        internal Int32 LeaseObtained;
        internal Int32 LeaseExpires;
    }

#pragma warning disable 0649

    internal struct IpForwardRow
    {
        internal UInt32 dwForwardDest;
        internal UInt32 dwForwardMask;
        internal UInt32 dwForwardPolicy;
        internal UInt32 dwForwardNextHop;
        internal UInt32 dwForwardIfIndex;
        internal UInt32 dwForwardType;
        internal UInt32 dwForwardProto;
        internal UInt32 dwForwardAge;
        internal UInt32 dwForwardNextHopAS;
        internal UInt32 dwForwardMetric1;
        internal UInt32 dwForwardMetric2;
        internal UInt32 dwForwardMetric3;
        internal UInt32 dwForwardMetric4;
        internal UInt32 dwForwardMetric5;
    }

#pragma warning restore 0649
}
