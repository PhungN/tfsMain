﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    [StructLayout(LayoutKind.Sequential)]
    public struct SpiTransactionStructure
    {
        public IntPtr receiveBufferAddress;
        public IntPtr transmitBufferAddress;
        public UInt32 bufferSize;
        public UInt32 chipSelect;
    }
}
