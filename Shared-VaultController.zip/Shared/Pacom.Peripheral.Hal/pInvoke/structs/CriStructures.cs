﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    [StructLayout(LayoutKind.Sequential)]
    public struct CriStructure
    {
        [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 32)]
        public byte[] criBuffer;
        public UInt32 criBufferLength;
        public UInt32 readerNumber;
        public UInt32 collisionOccurred;
    }
}
