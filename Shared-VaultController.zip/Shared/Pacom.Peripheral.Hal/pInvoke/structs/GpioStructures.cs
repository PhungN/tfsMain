﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    [StructLayout(LayoutKind.Sequential)]
    public struct GpioPortStructure
    {
        public UInt32 port;
        public UInt32 value;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct GpioConfigureStructure
    {
        public UInt32 port;
        public UInt32 pin;
        public UInt32 pullUpEnable;
        public UInt32 outputEnable;
        public UInt32 multiDriveEnable;
        public UInt32 peripheralSelect;
        public UInt32 pioEnable;
    }
}
