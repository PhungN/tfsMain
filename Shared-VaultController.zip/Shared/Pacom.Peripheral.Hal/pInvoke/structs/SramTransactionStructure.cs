﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    [StructLayout(LayoutKind.Sequential)]
    public struct SramTransactionStructure
    {
        public IntPtr bufferAddress;
        public UInt32 bufferOffset;
        public UInt32 bufferSize;        
    }
}
