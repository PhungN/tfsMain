﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    [StructLayout(LayoutKind.Sequential)]
    public struct I2cReadStructure
    {
        public UInt32 deviceAddress;
        public UInt32 registerAddress;
        public UInt32 registerAddressLength;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct I2cWriteStructure
    {
        public UInt32 deviceAddress;
        public UInt32 registerAddress;
        public UInt32 registerAddressLength;
        public UInt32 bufferSize;
        public IntPtr bufferAddress;
    }
}
