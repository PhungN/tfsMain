﻿using System;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    [StructLayout(LayoutKind.Sequential)]
    public struct TimeZoneInformationStructure
    {
        public int bias;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string standardName;
        public SystemTimeStructure standardDate;
        public int standardBias;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string daylightName;
        public SystemTimeStructure daylightDate;
        public int daylightBias;
    }
}
