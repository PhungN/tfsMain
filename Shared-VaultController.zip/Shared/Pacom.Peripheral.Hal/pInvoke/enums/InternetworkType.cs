﻿
namespace Pacom.Peripheral.Hal
{
    public enum InternetworkType : ushort
    {
        AF_INET = 2,
        AF_INET6 = 23,
    }
}
