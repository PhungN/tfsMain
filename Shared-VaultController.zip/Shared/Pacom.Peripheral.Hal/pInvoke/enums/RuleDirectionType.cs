﻿
namespace Pacom.Peripheral.Hal
{
    public enum RuleDirectionType : int
    {
        FWF_INBOUND = 0x08,
        FWF_OUTBOUND = 0x10,
    }
}
