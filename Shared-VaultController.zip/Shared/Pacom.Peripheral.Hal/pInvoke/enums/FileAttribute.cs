﻿using System;

namespace Pacom.Peripheral.Hal
{
    [Flags]
    public enum FileAttribute : uint
    {
        ReadOnly = 0x00000001,
        Hidden = 0x00000002,
        System = 0x00000004,
        Directory = 0x00000010,
        Archive = 0x00000020,
        InRom = 0x00000040,
        Normal = 0x00000080,
        Temporary = 0x00000100,
        SpareFile = 0x00000200,
    }
}
