﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Hal
{
    public enum ScanPartitionType
    {
        FirstFatTable,
        SecondFatTable,
        BothFatTables
    }
}
