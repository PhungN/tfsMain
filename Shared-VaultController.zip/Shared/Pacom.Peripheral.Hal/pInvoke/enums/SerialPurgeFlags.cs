﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Hal
{
    [Flags]
    public enum SerialPurgeFlags : uint
    {
        /// <summary>
        /// Kill the pending/current writes to the comm port.
        /// </summary>
        PurgeTXAbort = 0x0001,
        /// <summary>
        /// Kill the pending/current reads to the comm port.
        /// </summary>
        PurgeRXAbort = 0x0002,
        /// <summary>
        /// Kill the pending/current reads to the comm port.
        /// </summary>
        PurgeTXClear = 0x0004,
        /// <summary>
        /// Kill the typeahead buffer if there.
        /// </summary>
        PurgeRXClear = 0x0008
    }
}
