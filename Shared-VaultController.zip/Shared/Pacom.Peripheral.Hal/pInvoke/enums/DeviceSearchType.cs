﻿
namespace Pacom.Peripheral.Hal
{
    public enum DeviceSearchType : int
    {
        DeviceSearchByLegacyName = 0,
        DeviceSearchByDeviceName = 1,
        DeviceSearchByBusName = 2,
        DeviceSearchByGuid = 3,
        DeviceSearchByParent = 4
    }
}
