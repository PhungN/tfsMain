﻿using System;

namespace Pacom.Peripheral.Hal
{
    [Flags]
    public enum FileAccess : uint
    {
        GenericRead = 0x80000000,
        GenericWrite = 0x40000000,
    }
}
