﻿using System;

namespace Pacom.Peripheral.Hal
{
    [Flags]
    public enum CommEvents : uint
    {
        /// <summary>
        /// No events
        /// </summary>
        EV_NONE = 0x0000,
        /// <summary>
        /// Any Character received
        /// </summary>
        EV_RXCHAR = 0x0001,
        /// <summary>
        /// Received certain character
        /// </summary>
        EV_RXFLAG = 0x0002,
        /// <summary>
        /// Transmit Queue Empty
        /// </summary>
        EV_TXEMPTY = 0x0004,
        /// <summary>
        /// CTS changed state
        /// </summary>
        EV_CTS = 0x0008,
        /// <summary>
        /// DSR changed state
        /// </summary>
        EV_DSR = 0x0010,
        /// <summary>
        /// RLSD changed state
        /// </summary>
        EV_RLSD = 0x0020,
        /// <summary>
        /// BREAK received
        /// </summary>
        EV_BREAK = 0x0040,
        /// <summary>
        /// Line status error occurred
        /// </summary>
        EV_ERR = 0x0080,
        /// <summary>
        /// Ring signal detected
        /// </summary>
        EV_RING = 0x0100,
        /// <summary>
        /// Printer error occurred
        /// </summary>
        EV_PERR = 0x0200,
        /// <summary>
        /// Receive buffer is 80 percent full
        /// </summary>
        EV_RX80FULL = 0x0400,
        /// <summary>
        /// Provider specific event 1
        /// </summary>
        EV_EVENT1 = 0x0800,
        /// <summary>
        /// Provider specific event 2
        /// </summary>
        EV_EVENT2 = 0x1000
    }
}
