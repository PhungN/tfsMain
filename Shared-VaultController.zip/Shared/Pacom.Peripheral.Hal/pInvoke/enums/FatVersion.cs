﻿
namespace Pacom.Peripheral.Hal
{
    public enum FatVersion 
    {
        exFAT = 64,
        FAT32 = 32,
        FAT16 = 16,
        FAT12 = 12
    }
}
