﻿using System;

namespace Pacom.Peripheral.Hal
{
    public enum EventFlags
    {
        Pulse = 1,
        Reset = 2,
        Set = 3
    }
}
