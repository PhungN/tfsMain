﻿using System;

namespace Pacom.Peripheral.Hal
{
    public enum FirewallResultType : uint
    {
        ERROR_SUCCESS = Constants.ERROR_SUCCESS,
        ERROR_ACCESS_DENIED = Constants.ERROR_ACCESS_DENIED,
        ERROR_GEN_FAILURE = Constants.ERROR_GEN_FAILURE,
        ERROR_INSUFFICIENT_BUFFER = Constants.ERROR_INSUFFICIENT_BUFFER,
        ERROR_BAD_ARGUMENTS = Constants.ERROR_BAD_ARGUMENTS,
        ERROR_UNKNOWN = UInt32.MaxValue,
    }
}
