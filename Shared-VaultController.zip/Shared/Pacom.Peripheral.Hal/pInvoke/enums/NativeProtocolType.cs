﻿
namespace Pacom.Peripheral.Hal
{
    public enum NativeProtocolType : int
    {
        TCP = 6,
        UDP = 17,
    }
}
