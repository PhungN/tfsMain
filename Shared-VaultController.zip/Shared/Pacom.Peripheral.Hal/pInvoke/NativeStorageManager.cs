using System;
using System.Runtime.InteropServices;

// Try to match the store manager functions exactly (all caps, exact type names, etc.).
using BOOL = System.Boolean;
using BYTE = System.Byte;
using DWORD = System.UInt32;
using TCHAR = System.String;
using HANDLE = System.IntPtr;
using LPCSTR = System.String;
using LPCTSTR = System.String;
using LPCWSTR = System.String;
using PPARTINFO = System.IntPtr;
using PSTOREINFO = System.IntPtr;
using SECTORNUM = System.UInt64;
using PSCANPARAMS = System.IntPtr;
using PSCANOPTIONS = System.IntPtr;

namespace Pacom.Peripheral.Hal
{
    // Sources:
    // storemgr.h
    // winbase.h
    // http://msdn.microsoft.com/en-us/library/ee490420(v=WinEmbedded.60).aspx    
    // http://stackoverflow.com/questions/7176539/how-do-you-format-an-sd-card-using-the-storage-manager-api-via-windows-mobile-6
    // http://geekswithblogs.net/BruceEitman/archive/2010/08/29/windows-ce-formatting-tfat.aspx

    /// <summary>
    /// Some store manager basic constants
    /// </summary>
    public class StorageBasicConsts
    {
        public const int DEVICENAMESIZE = 8;
        public const int STORENAMESIZE = 32;
        public const int FILESYSNAMESIZE = 32;
        public const int FORMATNAMESIZE = 32;
        public const int PARTITIONNAMESIZE = 32;
        public const int PROFILENAMESIZE = 32;
        public const int FOLDERNAMESIZE = 32;
        public const int VOLUMENAMESIZE = 64;
        public const int FSDDESCSIZE = 32;
    }

    /// <summary>
    /// Calls to native storage manager in Win CE.
    /// </summary>
    public static class NativeStorageManager
    {
        [DllImport("coredll.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "CreatePartition")]
        public static extern bool CreatePartition(HANDLE hStore, LPCTSTR szPartitionName, SECTORNUM snNumSectors);

        [DllImport("coredll.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "CreatePartitionEx")]
        public static extern bool CreatePartitionEx(HANDLE hStore, LPCTSTR szPartitionName, BYTE bPartType,
                                                    SECTORNUM snNumSectors);

        [DllImport("coredll.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "DeletePartition")]
        public static extern bool DeletePartition(HANDLE hStore, LPCTSTR szPartitionName);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "DismountStore")]
        public static extern bool DismountStore(HANDLE hStore);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "FindClosePartition")]
        public static extern bool FindClosePartition(HANDLE hSearch);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "FindCloseStore")]
        public static extern bool FindCloseStore(HANDLE hSearch);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "FindFirstPartition")]
        public static extern HANDLE FindFirstPartition(HANDLE hStore, PPARTINFO pPartInfo);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "FindFirstStore")]
        public static extern HANDLE FindFirstStore(PSTOREINFO pStoreInfo);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "FindNextPartition")]
        public static extern bool FindNextPartition(HANDLE hSearch, PPARTINFO pPartInfo);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "FindNextStore")]
        public static extern bool FindNextStore(HANDLE hSearch, PSTOREINFO pStoreInfo);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "FormatPartition")]
        public static extern bool FormatPartition(HANDLE hPartition);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "FormatPartitionEx")]
        public static extern bool FormatPartitionEx(HANDLE hPartition, BYTE bPartType, BOOL bAuto);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "FormatStore")]
        public static extern bool FormatStore(HANDLE hStore);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "GetPartitionInfo")]
        public static extern bool GetPartitionInfo(HANDLE hPartition, PPARTINFO pPartInfo);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "GetStoreInfo")]
        public static extern bool GetStoreInfo(HANDLE hStore, PSTOREINFO pStoreInfo);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "DismountPartition")]
        public static extern bool DismountPartition(HANDLE hPartition);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "MountPartition")]
        public static extern bool MountPartition(HANDLE hPartition);

        [DllImport("coredll.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "OpenPartition")]
        public static extern HANDLE OpenPartition(HANDLE hStore, LPCTSTR szPartitionName);

        [DllImport("coredll.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "OpenStore")]
        public static extern HANDLE OpenStore(LPCSTR szDeviceName);

        [DllImport("coredll.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "RenamePartition")]
        public static extern bool RenamePartition(HANDLE hPartition, LPCTSTR szNewName);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "SetPartitionAttributes")]
        public static extern bool SetPartitionAttributes(HANDLE hPartition, DWORD dwAttrs);

        [DllImport("coredll.dll", SetLastError = true, EntryPoint = "CloseHandle")]
        public static extern bool CloseHandle(HANDLE hObject);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pszRootPath"></param>
        /// <param name="InfoLevel">CEVolumeInfoLevel</param>
        /// <param name="psp">CEVolumeInfo</param>
        /// <returns></returns>
        [DllImport("coredll.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "CeGetVolumeInfo")]
        public static extern bool CeGetVolumeInfo(LPCWSTR pszRootPath, CEVolumeInfoLevel InfoLevel, System.IntPtr psp);
    }

    /// <summary>
    /// Platform invokes for Fat utilities.
    /// </summary>
    public static class NativeFatUtilities
    {
        [DllImport("fatutil.dll", SetLastError = true)]
        public static extern DWORD ScanVolumeEx(HANDLE hVolume, System.IntPtr psp);

        [DllImport("fatutil.dll", SetLastError = true)]
        public static extern DWORD FormatVolumeEx(HANDLE hVolume, System.IntPtr psp);
    }
    
    [Flags]
    public enum StoreAttributes : int
    {
        STORE_ATTRIBUTE_READONLY = 0x00000001,
        STORE_ATTRIBUTE_REMOVABLE = 0x00000002,
        STORE_ATTRIBUTE_UNFORMATTED = 0x00000004,
        STORE_ATTRIBUTE_AUTOFORMAT = 0x00000008,
        STORE_ATTRIBUTE_AUTOPART = 0x00000010,
        STORE_ATTRIBUTE_AUTOMOUNT = 0x00000020
    }

    [Flags]
    public enum PartitionAttributes : int
    {
        PARTITION_ATTRIBUTE_EXPENDABLE = 0x00000001,  // partition may be trashed 
        PARTITION_ATTRIBUTE_READONLY = 0x00000002,  // partition is read-only   
        PARTITION_ATTRIBUTE_AUTOFORMAT = 0x00000004,
        PARTITION_ATTRIBUTE_ACTIVE = 0x00000008,
        PARTITION_ATTRIBUTE_BOOT = 0x00000008,  // Active(DOS) == Boot(CE)
        PARTITION_ATTRIBUTE_MOUNTED = 0x00000010
    }

    /// <summary>
    /// Flags for dwFlags in FORMAT_OPTIONS, SCAN_OPTIONS, and DEFRAG_OPTIONS.
    /// </summary>
    [Flags]
    public enum FatUtilitiesFlags : int
    {
        FATUTIL_FULL_FORMAT = 0x01,   // perform a full format
        FATUTIL_FORMAT_TFAT = 0x02,   // format volume as TFAT
        FATUTIL_DISABLE_MOUNT_CHK = 0x04,   // disable checking to see if volume is mounted before doing operation
        FATUTIL_SECURE_WIPE = 0x08,   // secure wipe, which is full format that will continue through power loss
        FATUTIL_FORMAT_EXFAT = 0x10,   // format volume as exFAT
        FATUTIL_SCAN_VERIFY_FIX = 0x01,   // prompt user to perform a fix
    }

    public enum CEVolumeInfoLevel
    {
        CeVolumeInfoLevelStandard = 0
    }

    /// <summary>
    /// Attributes for dwAttributes in CEVolumeInfo used by CeGetVolumeInfoW
    /// </summary>
    public enum CEVolumeInfoAttributes : int
    {
        CE_VOLUME_ATTRIBUTE_READONLY = 0x1,
        CE_VOLUME_ATTRIBUTE_HIDDEN = 0x2,
        CE_VOLUME_ATTRIBUTE_REMOVABLE = 0x4,
        CE_VOLUME_ATTRIBUTE_SYSTEM = 0x8,
        CE_VOLUME_ATTRIBUTE_BOOT = 0x10
    }

    /// <summary>
    /// Flags for dwFlags in CEVolumeInfo used by CeGetVolumeInfoW
    /// </summary>
    public enum CEVolumeInfoFlags : int
    {
        CE_VOLUME_TRANSACTION_SAFE = 0x1,    // Performs transaction safe operations
        CE_VOLUME_FLAG_TRANSACT_WRITE = 0x2,
        CE_VOLUME_FLAG_WFSC_SUPPORTED = 0x4,
        CE_VOLUME_FLAG_LOCKFILE_SUPPORTED = 0x8,
        CE_VOLUME_FLAG_NETWORK = 0x10,
        CE_VOLUME_FLAG_STORE = 0x20,
        CE_VOLUME_FLAG_RAMFS = 0x40,
        CE_VOLUME_FLAG_FILE_SECURITY_SUPPORTED = 0x80,   // Persistent file and directory security descriptors
        CE_VOLUME_FLAG_64BIT_FILES_SUPPORTED = 0x100   // 64-bit file sizes and offsets
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct CEVolumeInfo
    {
        public DWORD cbSize;  // Set to sizeof(CE_VOLUME_INFO)
        public DWORD dwAttributes;  // Specifies attributes of a volume.
        public DWORD dwFlags;  // Specifies additional properties of a volume.
        public DWORD dwBlockSize;  // Size of the block, in bytes.
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = StorageBasicConsts.STORENAMESIZE)]
        public TCHAR szStoreName;   // Name of the store. Maximum length is 32.
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = StorageBasicConsts.PARTITIONNAMESIZE)]
        public TCHAR szPartitionName;  // Name of the partition. Maximum length is 32.
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct FileTime
    {
        public DWORD dwLowDateTime;
        public DWORD dwHighDateTime;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct StorageDeviceInfo
    {
        public DWORD cbSize;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = StorageBasicConsts.PROFILENAMESIZE)]
        public TCHAR szProfile;
        public DWORD dwDeviceClass;
        public DWORD dwDeviceType;
        public DWORD dwDeviceFlags;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct StoreInfo
    {
        public DWORD cbSize;                      // sizeof(PD_STOREINFO)
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = StorageBasicConsts.DEVICENAMESIZE)]
        public TCHAR szDeviceName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = StorageBasicConsts.STORENAMESIZE)]
        public TCHAR szStoreName;
        public DWORD dwDeviceClass;
        public DWORD dwDeviceType;
        public StorageDeviceInfo sdi;
        public DWORD dwDeviceFlags;
        public SECTORNUM snNumSectors;            // number of sectors on store             
        public DWORD dwBytesPerSector;            // number of bytes per sector             
        public SECTORNUM snFreeSectors;           // number of unallocated sectors          
        public SECTORNUM snBiggestPartCreatable;  // biggest partition currently creatable  
        public FileTime ftCreated;                // last time store was formatted          
        public FileTime ftLastModified;           // last time partition table was modified 
        public DWORD dwAttributes;                // store attributes, see below            
        public DWORD dwPartitionCount;            // Number of Partitions 
        public DWORD dwMountCount;                // Number of partitions that have been mounted
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct PartInfo
    {
        public DWORD cbSize;                               // sizeof(PD_PARTINFO)             
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = StorageBasicConsts.PARTITIONNAMESIZE)]
        public TCHAR szPartitionName;                      // name of partition
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = StorageBasicConsts.FILESYSNAMESIZE)]
        public TCHAR szFileSys;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = StorageBasicConsts.VOLUMENAMESIZE)]
        public TCHAR szVolumeName;
        public SECTORNUM snNumSectors;                     // number of sectors in partition    
        public FileTime ftCreated;                         // creation time of partition        
        public FileTime ftLastModified;                    // last time partition was modified  
        public DWORD dwAttributes;                         // partition attributes, see below   
        public BYTE bPartType;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct ScanOptions
    {
        public DWORD dwFlags;
        public DWORD dwFatToUse;         // Indicates which FAT to use for scanning (one-based indexing)
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct ScanResults
    {
        public DWORD dwLostClusters;     // Number of lost cluster found
        public DWORD dwInvalidClusters;  // Number of invalid cluster values in FAT
        public DWORD dwLostChains;       // Number of lost chains found
        public DWORD dwInvalidDirs;      // Number of directories with invalid cluster references
        public DWORD dwInvalidFiles;     // Number of files with invalid cluster references
        public DWORD dwTotalErrors;      // Total number of errors.  Sum of 5 fields above
        public DWORD dwPercentFrag;      // Percent fragmentation on disk
        public BOOL fConsistentFats;     // TRUE if FATs are consistent
        public BOOL fErrorNotFixed;      // TRUE if there are still errors on drive after scan
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct ScanParams
    {
        public DWORD cbSize;
        public ScanOptions so;
        public ScanResults sr;
        public System.IntPtr pfnProgress;
        public System.IntPtr pfnMessage;
        public HANDLE hevCancel;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct FormatOptions
    {
        public DWORD dwClusSize;        // desired cluster size in bytes (must be power of 2)
        public DWORD dwRootEntries;     // desired number of root directory entries
        public DWORD dwFatVersion;      // FAT Version.  Either 12, 16, or 32    
        public DWORD dwNumFats;         // Number of FATs to create
        public DWORD dwFlags;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct FormatResults
    {
        public DWORD dwSectorsPerFat;
        public DWORD dwReservedSectors;
        public DWORD dwSectorsPerCluster;
        public DWORD dwRootSectors;
        public DWORD dwTotalSectors;
        public DWORD dwNumFats;
        public DWORD dwFatVersion;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct FormatParams
    {
        public DWORD cbSize;
        public FormatOptions fo;
        public FormatResults fr;
        public System.IntPtr pfnProgress;
        public System.IntPtr pfnMessage;
    }
}
