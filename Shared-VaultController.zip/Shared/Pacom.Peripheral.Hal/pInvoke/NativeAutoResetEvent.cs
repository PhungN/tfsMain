﻿using System;

namespace Pacom.Peripheral.Hal
{
    public class NativeAutoResetEvent
    {
        private IntPtr handle;

        public NativeAutoResetEvent(bool initialState)
        {
            handle = NativeMethods.CreateEvent(IntPtr.Zero, false, initialState, null);
        }

        public void Close()
        {
            NativeMethods.CloseHandle(handle);
        }

        public void Reset()
        {
            NativeMethods.EventModify(handle, EventFlags.Reset);
        }

        public void Set()
        {
            NativeMethods.EventModify(handle, EventFlags.Set);
        }

        public bool WaitOne()
        {
            int result = NativeMethods.WaitForSingleObject(handle, Constants.Infinite);
            if (result == 0)
                return true;
            return false;
        }

        public bool WaitOne(int millisecondsTimeout, bool exitContext)
        {
            int result = NativeMethods.WaitForSingleObject(handle, (uint)millisecondsTimeout);
            if (result == 0)
                return true;
            return false;
        }

        public IntPtr Handle
        {
            get
            {
                return handle;
            }
        }
    }
}