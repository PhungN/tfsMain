﻿using System;

namespace Pacom.Peripheral.Hal
{
    public static class Constants
    {
        public const Int32 InvalidHandleValue = -1;
        public const UInt32 Infinite = 0xFFFFFFFF;

        // The operation completed successfully.
        public const UInt32 ERROR_SUCCESS = 0;
        public const UInt32 NO_ERROR = 0;

        // The data area passed to a system call is too small.
        public const UInt32 ERROR_ACCESS_DENIED = 5;
        // A device attached to the system is not functioning.
        public const UInt32 ERROR_GEN_FAILURE = 31;
        // The data area passed to a system call is too small.
        public const UInt32 ERROR_INSUFFICIENT_BUFFER = 122;
        // The argument string passed to DosExecPgm is not correct.
        public const UInt32 ERROR_BAD_ARGUMENTS = 160;
        // The local device name is already in use.
        public const UInt32 ERROR_ALREADY_ASSIGNED = 85;  

        public const int SH_CURTHREAD = 1;
        public const int SYS_HANDLE_BASE = 64;

        public const int EVENT_ALL_ACCESS = 0x001F0003;

        public const int MIB_TCP_STATE_ESTAB = 5;

        // PIO (Port A) input PA7 -> SD Card Present Status
        public const int SdCardPresent = 7;
    }
}
