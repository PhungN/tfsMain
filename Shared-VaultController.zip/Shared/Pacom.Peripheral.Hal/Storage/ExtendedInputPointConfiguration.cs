﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Hal
{
    public class ExtendedInputPointConfiguration : InputConfigurationBase
    {
        private int[] lowerLimits = new int[ranges];
        private int[] upperLimits = new int[ranges];

        private const int ranges = 11;
        private const int secureRange = 0;
        private const int alarmRange1 = 1;
        private const int alarmRange2 = 2;
        private const int openRange = 3;
        private const int shortRange = 4;
        private const int maskingRange = 5;
        private const int rangeReductionRange = 6;
        private const int maskingAndRangeReductionRange = 7;
        private const int alarmAndMaskingRange = 8;
        private const int alarmAndRangeReductionRange = 9;
        private const int alarmAndMaskingAndRangeReductionRange = 10;

        public const int AdcResolution = 10;
        public readonly int PullUpResistorValue = 10000;
        public readonly int CurrentLimitingResistorValue = 0;

        private int average(int smallerValue, int largerValue)
        {
            return ((largerValue - smallerValue) / 2) + smallerValue;
        }

        private void checkForOverlap(int idealValue1, ref int upperLimit1, ref int lowerLimit2, int idealValue2)
        {
            if (idealValue1 == idealValue2)
                return;

            if (upperLimit1 > lowerLimit2)
            {
                int midPoint = average(idealValue1, idealValue2);
                upperLimit1 = midPoint - 1;
                lowerLimit2 = midPoint;
            }
        }

        public ExtendedInputPointConfiguration(InputConfiguration inputConfiguration, bool onboardInput, bool supervisedInput)
            : base(inputConfiguration.LogicalId, inputConfiguration.ReportPoint, inputConfiguration.HitCount, inputConfiguration.Tolerance, inputConfiguration.AlarmResistance, inputConfiguration.SecureResistance, inputConfiguration.AnalogInputResolution, inputConfiguration.MaskingResistance, inputConfiguration.RangeReductionResistance)
        {
            int[] idealValues = new int[ranges];
            idealValues[shortRange] = 0;
            idealValues[openRange] = 1023;

            lowerLimits[shortRange] = 0;
            upperLimits[openRange] = 1023;

            int secureRangeResistance = 10000;
            int alarmRange1Resistance = 5000;
            int alarmRange2Resistance = 20000;
            int maskingResistance = 0;
            int rangeReductionResistance = 0;
            double tolerance = 0.0;

            MaskingRangeLowerLimit = int.MinValue;
            MaskingRangeUpperLimit = int.MinValue;
            RangeReductionRangeLowerLimit = int.MinValue;
            RangeReductionRangeUpperLimit = int.MinValue;
            MaskingAndRangeReductionRangeLowerLimit = int.MinValue;
            MaskingAndRangeReductionRangeUpperLimit = int.MinValue;
            AlarmAndMaskingRangeLowerLimit = int.MinValue;
            AlarmAndMaskingRangeUpperLimit = int.MinValue;
            AlarmAndRangeReductionRangeLowerLimit = int.MinValue;
            AlarmAndRangeReductionRangeUpperLimit = int.MinValue;
            AlarmAndMaskingAndRangeReductionRangeLowerLimit = int.MinValue;
            AlarmAndMaskingAndRangeReductionRangeUpperLimit = int.MinValue;
            SupervisedInput = supervisedInput;

            if (Tolerance == ResistorTolerance.TwelveAndAHalfPercent)
                tolerance = 0.125;
            else
                tolerance = 0.25;

            secureRangeResistance = inputConfiguration.SecureResistance;
            alarmRange1Resistance = inputConfiguration.SecureResistance / 2;
            alarmRange2Resistance = inputConfiguration.AlarmResistance;
            maskingResistance = inputConfiguration.MaskingResistance;
            rangeReductionResistance = inputConfiguration.RangeReductionResistance;

            if (onboardInput)
            {
                PullUpResistorValue = OnboardInputs.OnboardPullUpResistorValue;
                CurrentLimitingResistorValue = OnboardInputs.OnboardCurrentLimitingResistorValue;                
            }
            else
            {
                PullUpResistorValue = 10000;
                CurrentLimitingResistorValue = 0;
            }

            if (SecureResistance == 0)
            {
                SecureRangeLowerLimit = 0;
                SecureRangeUpperLimit = 1023;
            }
            else if (supervisedInput == false)
            {
                HitCount = 0;
                SecureRangeLowerLimit = (int)(Math.Pow(2, AdcResolution) * 0.5);
                SecureRangeUpperLimit = (int)(Math.Pow(2, AdcResolution));

                AlarmRange1LowerLimit = 0;
                AlarmRange1UpperLimit = SecureRangeLowerLimit - 1;
            }
            else
            {
                SecureRangeLowerLimit = (int)((Math.Pow(2, AdcResolution) * ((secureRangeResistance * (1 - tolerance)) + CurrentLimitingResistorValue)) / ((secureRangeResistance * (1 - tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                SecureRangeUpperLimit = (int)((Math.Pow(2, AdcResolution) * ((secureRangeResistance * (1 + tolerance)) + CurrentLimitingResistorValue)) / ((secureRangeResistance * (1 + tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                idealValues[secureRange] = (int)((Math.Pow(2, AdcResolution) * ((secureRangeResistance * (1 + 0)) + CurrentLimitingResistorValue)) / ((secureRangeResistance * (1 + 0)) + (PullUpResistorValue + CurrentLimitingResistorValue)));

                if (SecureResistance * 2 == AlarmResistance)
                {
                    alarmRange1Resistance = SecureResistance / 2;
                    alarmRange2Resistance = AlarmResistance;
                }
                else if (SecureResistance == AlarmResistance * 2)
                {
                    alarmRange1Resistance = AlarmResistance;
                    alarmRange2Resistance = SecureResistance * 2;
                }
                else
                {
                    alarmRange1Resistance = int.MinValue;
                    AlarmRange1LowerLimit = int.MinValue;
                    AlarmRange1UpperLimit = int.MinValue;
                    idealValues[alarmRange1] = int.MinValue;
                    alarmRange2Resistance = AlarmResistance;
                }

                if (alarmRange1Resistance != int.MinValue)
                {
                    AlarmRange1LowerLimit = (int)((Math.Pow(2, AdcResolution) * ((alarmRange1Resistance * (1 - tolerance)) + CurrentLimitingResistorValue)) / ((alarmRange1Resistance * (1 - tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    AlarmRange1UpperLimit = (int)((Math.Pow(2, AdcResolution) * ((alarmRange1Resistance * (1 + tolerance)) + CurrentLimitingResistorValue)) / ((alarmRange1Resistance * (1 + tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    idealValues[alarmRange1] = (int)((Math.Pow(2, AdcResolution) * ((alarmRange1Resistance * (1 + 0)) + CurrentLimitingResistorValue)) / ((alarmRange1Resistance * (1 + 0)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                }

                AlarmRange2LowerLimit = (int)((Math.Pow(2, AdcResolution) * ((alarmRange2Resistance * (1 - tolerance)) + CurrentLimitingResistorValue)) / ((alarmRange2Resistance * (1 - tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                AlarmRange2UpperLimit = (int)((Math.Pow(2, AdcResolution) * ((alarmRange2Resistance * (1 + tolerance)) + CurrentLimitingResistorValue)) / ((alarmRange2Resistance * (1 + tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                idealValues[alarmRange2] = (int)((Math.Pow(2, AdcResolution) * ((alarmRange2Resistance * (1 + 0)) + CurrentLimitingResistorValue)) / ((alarmRange2Resistance * (1 + 0)) + (PullUpResistorValue + CurrentLimitingResistorValue)));

                OpenRangeLowerLimit = (int)(Math.Pow(2, AdcResolution) * 0.95);
                ShortRangeUpperLimit = (int)(Math.Pow(2, AdcResolution) * 0.05);

                int idealResistance = 0;
                if (maskingResistance != 0)
                {
                    idealResistance = secureRangeResistance + maskingResistance;
                    MaskingRangeLowerLimit = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 - tolerance)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 - tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    MaskingRangeUpperLimit = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 + tolerance)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 + tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    idealValues[maskingRange] = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 + 0)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 + 0)) + (PullUpResistorValue + CurrentLimitingResistorValue)));

                    idealResistance = alarmRange2Resistance + maskingResistance;
                    AlarmAndMaskingRangeLowerLimit = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 - tolerance)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 - tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    AlarmAndMaskingRangeUpperLimit = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 + tolerance)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 + tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    idealValues[alarmAndMaskingRange] = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 + 0)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 + 0)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                }
                if (rangeReductionResistance != 0)
                {
                    idealResistance = secureRangeResistance + rangeReductionResistance;
                    RangeReductionRangeLowerLimit = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 - tolerance)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 - tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    RangeReductionRangeUpperLimit = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 + tolerance)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 + tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    idealValues[rangeReductionRange] = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 + 0)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 + 0)) + (PullUpResistorValue + CurrentLimitingResistorValue)));

                    idealResistance = alarmRange2Resistance + rangeReductionResistance;
                    AlarmAndRangeReductionRangeLowerLimit = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 - tolerance)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 - tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    AlarmAndRangeReductionRangeUpperLimit = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 + tolerance)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 + tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    idealValues[alarmAndRangeReductionRange] = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 + 0)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 + 0)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                }
                if (maskingResistance != 0 && rangeReductionResistance != 0)
                {
                    idealResistance = secureRangeResistance + maskingResistance + rangeReductionResistance;
                    MaskingAndRangeReductionRangeLowerLimit = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 - tolerance)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 - tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    MaskingAndRangeReductionRangeUpperLimit = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 + tolerance)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 + tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    idealValues[maskingAndRangeReductionRange] = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 + 0)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 + 0)) + (PullUpResistorValue + CurrentLimitingResistorValue)));

                    idealResistance = alarmRange2Resistance + maskingResistance + rangeReductionResistance;
                    AlarmAndMaskingAndRangeReductionRangeLowerLimit = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 - tolerance)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 - tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    AlarmAndMaskingAndRangeReductionRangeUpperLimit = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 + tolerance)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 + tolerance)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                    idealValues[alarmAndMaskingAndRangeReductionRange] = (int)((Math.Pow(2, AdcResolution) * ((idealResistance * (1 + 0)) + CurrentLimitingResistorValue)) / ((idealResistance * (1 + 0)) + (PullUpResistorValue + CurrentLimitingResistorValue)));
                }

                // Fix up any overlapping ranges the best that we can.

                // Start by sorting the ranges with a bubble sort
                int[] sortedRanges = new int[ranges];
                for (int i = 0; i < ranges; i++)
                {
                    sortedRanges[i] = i;
                }

                bool complete = false;
                while (complete == false)
                {
                    complete = true;
                    for (int i = 1; i < ranges; i++)
                    {
                        if (lowerLimits[sortedRanges[i]] < lowerLimits[sortedRanges[i - 1]])
                        {
                            int temp = sortedRanges[i];
                            sortedRanges[i] = sortedRanges[i - 1];
                            sortedRanges[i - 1] = temp;
                            complete = false;
                        }
                    }
                }

                // Split the difference if there is any overlap
                for (int i = 1; i < ranges; i++)
                {
                    checkForOverlap(idealValues[sortedRanges[i - 1]], ref upperLimits[sortedRanges[i - 1]], ref lowerLimits[sortedRanges[i]], idealValues[sortedRanges[i]]);
                }
            }
        }

        /// <summary>
        /// Is this input supervised?
        /// </summary>
        public bool SupervisedInput { get; private set; }

        public int AlarmRange1LowerLimit
        {
            get { return lowerLimits[alarmRange1]; }
            private set { lowerLimits[alarmRange1] = value; }
        }

        public int AlarmRange1UpperLimit
        {
            get { return upperLimits[alarmRange1]; }
            private set { upperLimits[alarmRange1] = value; }
        }

        public int AlarmRange2LowerLimit
        {
            get { return lowerLimits[alarmRange2]; }
            private set { lowerLimits[alarmRange2] = value; }
        }

        public int AlarmRange2UpperLimit
        {
            get { return upperLimits[alarmRange2]; }
            private set { upperLimits[alarmRange2] = value; }
        }

        public int SecureRangeLowerLimit
        {
            get { return lowerLimits[secureRange]; }
            private set { lowerLimits[secureRange] = value; }
        }

        public int SecureRangeUpperLimit
        {
            get { return upperLimits[secureRange]; }
            private set { upperLimits[secureRange] = value; }
        }

        public int OpenRangeLowerLimit
        {
            get { return lowerLimits[openRange]; }
            private set { lowerLimits[openRange] = value; }
        }

        public int ShortRangeUpperLimit
        {
            get { return upperLimits[shortRange]; }
            private set { upperLimits[shortRange] = value; }
        }

        public int MaskingRangeLowerLimit
        {
            get { return lowerLimits[maskingRange]; }
            private set { lowerLimits[maskingRange] = value; }
        }

        public int MaskingRangeUpperLimit
        {
            get { return upperLimits[maskingRange]; }
            private set { upperLimits[maskingRange] = value; }
        }

        public int RangeReductionRangeLowerLimit
        {
            get { return lowerLimits[rangeReductionRange]; }
            private set { lowerLimits[rangeReductionRange] = value; }
        }

        public int RangeReductionRangeUpperLimit
        {
            get { return upperLimits[rangeReductionRange]; }
            private set { upperLimits[rangeReductionRange] = value; }
        }

        public int MaskingAndRangeReductionRangeLowerLimit
        {
            get { return lowerLimits[maskingAndRangeReductionRange]; }
            private set { lowerLimits[maskingAndRangeReductionRange] = value; }
        }

        public int MaskingAndRangeReductionRangeUpperLimit
        {
            get { return upperLimits[maskingAndRangeReductionRange]; }
            private set { upperLimits[maskingAndRangeReductionRange] = value; }
        }

        public int AlarmAndMaskingRangeLowerLimit
        {
            get { return lowerLimits[alarmAndMaskingRange]; }
            private set { lowerLimits[alarmAndMaskingRange] = value; }
        }

        public int AlarmAndMaskingRangeUpperLimit
        {
            get { return upperLimits[alarmAndMaskingRange]; }
            private set { upperLimits[alarmAndMaskingRange] = value; }
        }

        public int AlarmAndRangeReductionRangeLowerLimit
        {
            get { return lowerLimits[alarmAndRangeReductionRange]; }
            private set { lowerLimits[alarmAndRangeReductionRange] = value; }
        }

        public int AlarmAndRangeReductionRangeUpperLimit
        {
            get { return upperLimits[alarmAndRangeReductionRange]; }
            private set { upperLimits[alarmAndRangeReductionRange] = value; }
        }

        public int AlarmAndMaskingAndRangeReductionRangeLowerLimit
        {
            get { return lowerLimits[alarmAndMaskingAndRangeReductionRange]; }
            private set { lowerLimits[alarmAndMaskingAndRangeReductionRange] = value; }
        }

        public int AlarmAndMaskingAndRangeReductionRangeUpperLimit
        {
            get { return upperLimits[alarmAndMaskingAndRangeReductionRange]; }
            private set { upperLimits[alarmAndMaskingAndRangeReductionRange] = value; }
        }
    }
}
