﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Hal
{
    public class ExpansionCardFirmware
    {
        private byte[] rawData;
        private ExpansionCardType cardType;

        public ExpansionCardFirmware(ExpansionCardType type, byte[] rawData)
        {
            this.cardType = type;
            this.rawData = rawData;
        }

        public ExpansionCardType CardType
        {
            get { return cardType; }
        }

        public FirmwareVersion Version
        {
            get { return new FirmwareVersion(rawData[rawData.Length - 1], rawData[rawData.Length - 2]); }
        }

        public int Checksum
        {
            get { return (rawData[rawData.Length - 3] << 8) + rawData[rawData.Length - 4]; }
        }

        public byte[] Image
        {
            get
            {
                byte[] image = new byte[rawData.Length - 6];
                Buffer.BlockCopy(rawData, 0, image, 0, image.Length);
                return image;
            }
        }
    }
}
