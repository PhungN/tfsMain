﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Net;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    public static class Ping
    {
        public static bool PingAddress(IPAddress address)
        {
            bool result = true;
            IntPtr icmpHandle = NativeMethods.IcmpCreateFile();
            if (icmpHandle != IntPtr.Zero)
            {
                byte[] buffer = new byte[64];
                Random rand = new Random();
                rand.NextBytes(buffer);

                IntPtr requestBuffer = Marshal.AllocHGlobal(buffer.Length);
                Marshal.Copy(buffer, 0, requestBuffer, buffer.Length);

                IntPtr replyBuffer = Marshal.AllocHGlobal(0xFFFF);

                if (NativeMethods.IcmpSendEcho2(icmpHandle, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, BitConverter.ToUInt32(address.GetAddressBytes(), 0), requestBuffer, (UInt16)buffer.Length, IntPtr.Zero, replyBuffer, 0xFFFF, 5000) == 0)
                    result = false;

                Marshal.FreeHGlobal(replyBuffer);
                Marshal.FreeHGlobal(requestBuffer);

                // We don't care if this fails.
                if (NativeMethods.IcmpCloseHandle(icmpHandle) == 0)
                    result = true; ;
            }
            return result;
        }
    }
}