﻿using System;
using System.Net;
using System.Runtime.InteropServices;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Utils;
using Microsoft.Win32;
using System.Threading;
using System.Diagnostics;
using System.Text;
using System.Collections.Generic;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class provides a method to monitor, bind, set, renew the IP address of the ethernet adapter on a configuration change. 
    /// </summary>
    public partial class NetworkAdapter : INetworkAdapter, IDisposable
    {
        private const int IOCTL_NDIS_REBIND_ADAPTER = 0x17002e;
        private const int IOCTL_NDIS_UNBIND_ADAPTER = 0x170036;
        private const int IOCTL_LAN_FORCE_MINIPORT_INIT = 0x22A004;
                
        /// <summary>
        /// Renews the IP address details of the onboard ethernet adapter on a configuration change. 
        /// </summary>
        public void RebindAdapter()
        {
            int numBytesReturned;
            IntPtr handle = NativeMethods.CreateFile("NDS0:", FileAccess.GenericRead | FileAccess.GenericWrite, FileShare.None, IntPtr.Zero, CreationDisposition.OpenExisting, FileAttribute.Normal, IntPtr.Zero);
            byte[] adapterName;

            // Check if we are running the KITL VMINI driver or the standard ethernet driver.
            RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("Comm\\EMACB1", true);
            if (registryKey.GetValue("Group").ToString() == "Disabled")
                adapterName = System.Text.Encoding.Unicode.GetBytes("VMINI1\0\0");
            else
                adapterName = System.Text.Encoding.Unicode.GetBytes("EMACB1\0\0");
            registryKey.Close();

            // IOCTL_NDIS_REBIND_ADAPTER
            if (NativeMethods.DeviceIoControl(handle, IOCTL_NDIS_REBIND_ADAPTER, adapterName, adapterName.Length, IntPtr.Zero, 0, out numBytesReturned, IntPtr.Zero) == 0)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                {
                    return "RebindAdapter failed!";
                });
            }

            if (NativeMethods.CloseHandle(handle) == 0)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                {
                    return "CloseHandle in RebindAdapter failed!";
                });
            }
        }

        public static void UnbindAdapter()
        {
            int numBytesReturned;
            IntPtr handle = NativeMethods.CreateFile("NDS0:", FileAccess.GenericRead | FileAccess.GenericWrite, FileShare.None, IntPtr.Zero, CreationDisposition.OpenExisting, FileAttribute.Normal, IntPtr.Zero);
            byte[] adapterName;

            // Check if we are running the KITL VMINI driver or the standard ethernet driver.
            RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("Comm\\EMACB1", true);
            if (registryKey.GetValue("Group").ToString() == "Disabled")
                adapterName = System.Text.Encoding.Unicode.GetBytes("VMINI1\0\0");
            else
                adapterName = System.Text.Encoding.Unicode.GetBytes("EMACB1\0\0");
            registryKey.Close();

            // Tell NDIS to unbind the adapter.
            if (NativeMethods.DeviceIoControl(handle, IOCTL_NDIS_UNBIND_ADAPTER, adapterName, adapterName.Length, IntPtr.Zero, 0, out numBytesReturned, IntPtr.Zero) == 0)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                {
                    return "UnbindAdapter failed!";
                });
            }

            if (NativeMethods.CloseHandle(handle) == 0)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                {
                    return "CloseHandle in RebindAdapter failed!";
                });
            }
            Thread.Sleep(100);
        }

        public static bool UnloadDriver()
        {
            try
            {
                string command = "ndisconfig";
                string workingDirectory = "\\Windows";
                ProcessStartInfo processStartInfo = new ProcessStartInfo(command, "");
                processStartInfo.WorkingDirectory = workingDirectory;
                processStartInfo.Arguments = " adapter del EMACB1 ";
                Process process = Process.Start(processStartInfo);
                if (process == null)
                {
                    Console.WriteLine("{0}Following command failed to launch 'ndisconfig'.", LoggerClassPrefixes.NetworkAdapter);
                    return false;
                }
                process.WaitForExit();
                if (forceMiniportInit() == false)
                    return false;
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}Error executing ndisconfig: {1}", LoggerClassPrefixes.NetworkAdapter, ex.Message);
                return false;
            }
        }

        public static bool LoadDriver()
        {
            try
            {
                string command = "ndisconfig";
                string workingDirectory = "\\Windows";
                ProcessStartInfo processStartInfo = new ProcessStartInfo(command, "");
                processStartInfo.WorkingDirectory = workingDirectory;
                processStartInfo.Arguments = " adapter add EMACB1 EMACB1 ";
                Process process = Process.Start(processStartInfo);
                if (process == null)
                {
                    Console.WriteLine("{0}Following command failed to launch 'ndisconfig'.", LoggerClassPrefixes.NetworkAdapter);
                    return false;
                }
                process.WaitForExit();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}Error executing ndisconfig: {1}", LoggerClassPrefixes.NetworkAdapter, ex.Message);
                return false;
            }
        }

        const int ERROR_BUFFER_OVERFLOW = 111;
        const int MIB_IF_TYPE_ETHERNET = 6;

        /// <summary>
        /// Get network adapter information from the kernel.
        /// </summary>
        /// <param name="includeDnsInformation">True to include DNS servers</param>
        /// <param name="networkInformation">Network information objects</param>
        /// <returns></returns>
        public bool GetNetworkInformation(bool includeDnsInformation, out NetworkInformation networkInformation)
        {
            UInt32 structureSize = 0;
            IntPtr adapterInfoList = IntPtr.Zero;
            networkInformation = null;
            List<NetworkAdapterInformation> networkAdapters = new List<NetworkAdapterInformation>();
            List<IPAddress> dnsServers = new List<IPAddress>();

            int ret = NativeMethods.GetAdaptersInfo(adapterInfoList, ref structureSize);
            if (ret != ERROR_BUFFER_OVERFLOW)
                return false;

            // Allocate the correct size for the buffer.
            adapterInfoList = Marshal.AllocHGlobal((int)structureSize);
            ret = NativeMethods.GetAdaptersInfo(adapterInfoList, ref structureSize);
            if (ret != 0)
                return false;

            IntPtr adapterInfo = adapterInfoList;
            do
            {
                IP_ADAPTER_INFO entry = (IP_ADAPTER_INFO)Marshal.PtrToStructure(adapterInfo, typeof(IP_ADAPTER_INFO));

                if (entry.Type == MIB_IF_TYPE_ETHERNET)
                {
                    NetworkAdapterInformation networkAdapter = new NetworkAdapterInformation();
                    networkAdapter.Name = ASCIIEncoding.ASCII.GetString(entry.AdapterName, 0, entry.AdapterName.Length).Replace("\0", "");
                    networkAdapter.Description = ASCIIEncoding.ASCII.GetString(entry.AdapterDescription, 0, entry.AdapterDescription.Length).Replace("\0", "");
                    if (entry.DhcpEnabled == 0)
                        networkAdapter.UsingDHCP = false;
                    else
                        networkAdapter.UsingDHCP = true;

                    List<IPAddressAndMask> ipAddresses = new List<IPAddressAndMask>();
                    IP_ADDR_STRING ipAddressEntry = entry.IpAddressList;
                    while (true)
                    {
                        IPAddressAndMask ipAddress = new IPAddressAndMask();
                        try
                        {
                            ipAddress.IPAddress = IPAddress.Parse(ASCIIEncoding.ASCII.GetString(ipAddressEntry.IpAddress.Address, 0, ipAddressEntry.IpAddress.Address.Length).Replace("\0", ""));
                            ipAddress.SubnetMask = IPAddress.Parse(ASCIIEncoding.ASCII.GetString(ipAddressEntry.IpMask.Address, 0, ipAddressEntry.IpMask.Address.Length).Replace("\0", ""));
                            ipAddresses.Add(ipAddress);
                        }
                        catch
                        {
                        }

                        if (ipAddressEntry.Next == IntPtr.Zero)
                            break;
                        ipAddressEntry = (IP_ADDR_STRING)Marshal.PtrToStructure(ipAddressEntry.Next, typeof(IP_ADDR_STRING));
                    }
                    networkAdapter.Addresses = ipAddresses.ToArray();
                    
                    try
                    {
                        if (entry.GatewayList.IpAddress.Address != null)
                        {
                            if (entry.GatewayList.IpAddress.Address.All(0))
                            {
                                networkAdapter.DefaultGateway = IPAddress.Parse("0.0.0.0");
                            }
                            else
                            {
                                networkAdapter.DefaultGateway = IPAddress.Parse(ASCIIEncoding.ASCII.GetString(entry.GatewayList.IpAddress.Address, 0, entry.GatewayList.IpAddress.Address.Length).Replace("\0", ""));
                            }
                        }
                        else
                        {
                            networkAdapter.DefaultGateway = IPAddress.Parse("0.0.0.0");
                        }
                    }
                    catch
                    {
                        networkAdapter.DefaultGateway = IPAddress.Parse("0.0.0.0");
                    }
                    networkAdapters.Add(networkAdapter);
                }
                // Get next adapter (if any)
                adapterInfo = entry.Next;
            }
            while (adapterInfo != IntPtr.Zero);
            Marshal.FreeHGlobal(adapterInfoList);

            if (includeDnsInformation)
            {
                structureSize = 0;
                IntPtr networkInfo = IntPtr.Zero;

                ret = NativeMethods.GetNetworkParams(networkInfo, ref structureSize);
                if (ret != ERROR_BUFFER_OVERFLOW)
                    return false;

                // Allocate the correct size for the buffer.
                networkInfo = Marshal.AllocHGlobal((int)structureSize);
                ret = NativeMethods.GetNetworkParams(networkInfo, ref structureSize);

                if (ret != 0)
                    return false;

                FIXED_INFO info = (FIXED_INFO)Marshal.PtrToStructure(networkInfo, typeof(FIXED_INFO));
                IP_ADDR_STRING dnsServer = info.DnsServerList;

                while (true)
                {
                    try
                    {
                        dnsServers.Add(IPAddress.Parse(ASCIIEncoding.ASCII.GetString(dnsServer.IpAddress.Address, 0, dnsServer.IpAddress.Address.Length).Replace("\0", "")));
                    }
                    catch
                    {
                    }

                    if (dnsServer.Next == IntPtr.Zero)
                        break;
                    dnsServer = (IP_ADDR_STRING)Marshal.PtrToStructure(dnsServer.Next, typeof(IP_ADDR_STRING));
                }
                Marshal.FreeHGlobal(networkInfo);
            }
            networkInformation = new NetworkInformation();
            networkInformation.Adapters = networkAdapters.ToArray();
            networkInformation.DnsServers = dnsServers.ToArray();
            return true;
        }

        public static IPEndPoint GetLocalAddress(int localPort, IPEndPoint remoteEndpoint)
        {
            IPAddress localIPAddress = IPAddress.Any;

            int pdwSize = 0;
            int res = NativeMethods.GetTcpTable(null, out pdwSize, false);
            if (res == Constants.ERROR_INSUFFICIENT_BUFFER)
            {

                byte[] buffer = new byte[pdwSize];
                res = NativeMethods.GetTcpTable(buffer, out pdwSize, true);
                if (res == Constants.NO_ERROR)
                {
                    int offset = 0;
                    int entries = Convert.ToInt32(buffer[offset]);
                    offset += 4;

                    for (int i = 0; i < entries; i++)
                    {
                        // state
                        int state = Convert.ToInt32(buffer[offset]);
                        offset += 4;
                        if (state != Constants.MIB_TCP_STATE_ESTAB)
                        {
                            offset += 16;
                            continue;
                        }

                        // local address
                        string localTcpAddress = buffer[offset].ToString() + "." + buffer[offset + 1].ToString() + "." + buffer[offset + 2].ToString() + "." + buffer[offset + 3].ToString();
                        offset += 4;
                        
                        //local port in decimal
                        int localTcpPort = (((int)buffer[offset]) << 8) + (((int)buffer[offset + 1])) + (((int)buffer[offset + 2]) << 24) + (((int)buffer[offset + 3]) << 16);
                        offset += 4;
                        if (localTcpPort != localPort)
                        {
                            offset += 8;
                            continue;
                        }

                        // remote address
                        string remoteTcpAddress = buffer[offset].ToString() + "." + buffer[offset + 1].ToString() + "." + buffer[offset + 2].ToString() + "." + buffer[offset + 3].ToString();
                        offset += 4;

                        int remoteTcpPort;
                        if (remoteTcpAddress == "0.0.0.0")
                            remoteTcpPort = 0;
                        else
                            remoteTcpPort = (((int)buffer[offset]) << 8) + (((int)buffer[offset + 1])) + (((int)buffer[offset + 2]) << 24) + (((int)buffer[offset + 3]) << 16);
                        offset += 4;

                        if (remoteTcpPort == remoteEndpoint.Port && remoteTcpAddress == remoteEndpoint.Address.ToString())
                        {
                            localIPAddress = IPAddress.Parse(localTcpAddress);
                            break;
                        }
                    }
                }
            }

            return new IPEndPoint(localIPAddress, localPort);
        }

        private const UInt32 gatewayMetric = 50;

        /// <summary>
        /// When the Ethernet port has a gateway specified and a GPRS card is present, the metric for the Ethernet port is lower and Windows CE
        /// will only try this gateway. This means GPRS is never tried even if the source IP address is on the GPRS card. To resolve this, 
        /// all gateway entries must have the same metric.
        /// </summary>
        public static void FixRoutingTable()
        {
            bool success = false;
            for (int i = 0; i < 50; i++)
            {
                try
                {
                    int pdwSize = 0;
                    int res = NativeMethods.GetIpForwardTable(null, ref pdwSize, true);
                    if (res == Constants.ERROR_INSUFFICIENT_BUFFER)
                    {
                        byte[] buffer = new byte[pdwSize];
                        res = NativeMethods.GetIpForwardTable(buffer, ref pdwSize, true);
                        if (res != Constants.NO_ERROR)
                            continue;

                        int offset = 0;
                        int entries = Convert.ToInt32(buffer[offset]);
                        offset += 4;

                        bool settingFailed = false;
                        for (int j = 0; j < entries; j++)
                        {
                            IpForwardRow ipForwardRow = new IpForwardRow();

                            ipForwardRow.dwForwardDest = Convert.ToUInt32(buffer[offset + 0]);
                            ipForwardRow.dwForwardMask = Convert.ToUInt32(buffer[offset + 4]);
                            ipForwardRow.dwForwardMetric1 = Convert.ToUInt32(buffer[offset + 36]);

                            // The remainder of the structure is not needed for this application but included in comments
                            // for completeness.
                            /*ipForwardRow.dwForwardPolicy = Convert.ToUInt32(buffer[offset + 8]);
                            ipForwardRow.dwForwardNextHop = Convert.ToUInt32(buffer[offset + 12]);
                            ipForwardRow.dwForwardIfIndex = Convert.ToUInt32(buffer[offset + 16]);
                            ipForwardRow.dwForwardType = Convert.ToUInt32(buffer[offset + 20]);
                            ipForwardRow.dwForwardProto = Convert.ToUInt32(buffer[offset + 24]);
                            ipForwardRow.dwForwardAge = Convert.ToUInt32(buffer[offset + 28]);
                            ipForwardRow.dwForwardNextHopAS = Convert.ToUInt32(buffer[offset + 32]);
                            ipForwardRow.dwForwardMetric2 = Convert.ToUInt32(buffer[offset + 40]);
                            ipForwardRow.dwForwardMetric3 = Convert.ToUInt32(buffer[offset + 44]);
                            ipForwardRow.dwForwardMetric4 = Convert.ToUInt32(buffer[offset + 48]);
                            ipForwardRow.dwForwardMetric5 = Convert.ToUInt32(buffer[offset + 52]);*/

                            if (ipForwardRow.dwForwardDest == 0 && ipForwardRow.dwForwardMask == 0 && ipForwardRow.dwForwardMetric1 != gatewayMetric)
                            {
                                // This row contains a gateway entry whose metric is not 50. Set it to 50 so all gateways have the same metric.
                                byte[] setBuffer = new byte[Marshal.SizeOf(typeof(IpForwardRow))];
                                Buffer.BlockCopy(buffer, offset, setBuffer, 0, setBuffer.Length);
                                byte[] gatewayMetricBytes = BitConverter.GetBytes(gatewayMetric);
                                Buffer.BlockCopy(gatewayMetricBytes, 0, setBuffer, 36, gatewayMetricBytes.Length);  // 36 is the offset of dwForwardMetric1 within the IpForwardRow structure.
                                res = NativeMethods.SetIpForwardEntry(setBuffer);
                                if (res != Constants.NO_ERROR)
                                {
                                    settingFailed = true;
                                    break;
                                }
                            }

                            offset += Marshal.SizeOf(typeof(IpForwardRow));
                        }

                        if (settingFailed)
                            continue;

                        success = true;
                        break;
                    }
                }
                catch
                {
                }
            }

            if (success == false)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                {
                    return "Failed to set IP gateway metrics! GPRS fallback may not work.";
                });
            }
        }

        #region IDisposable Members

        bool disposed = false;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
