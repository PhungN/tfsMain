﻿namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// Decode the UInt16 from the 8204 mezzanine, in the changeListResponseBuffer, that
    /// represents a changed input
    /// </summary>
    internal class Pacom8204InputState
    {
        private readonly byte[] buffer;
        private readonly int offset;

        /// <summary>
        /// Which input changed
        /// </summary>
        public int InputNumber
        {
            get { return (buffer[offset] >> 4) & 0x0f; }
        }

        /// <summary>
        /// Is injection detected for this input
        /// </summary>
        public bool Injection
        {
            get { return (buffer[offset] & 0x08) != 0; }
        }

        /// <summary>
        /// Current ADC reading
        /// </summary>
        /// <remarks>
        /// If Injection is true, then this reading is likely unusable</remarks>
        public int ADCReading
        {
            get
            {
                return ((buffer[offset] & 0x07) << 8) | buffer[offset + 1];
            }
        }

        /// <summary>
        /// Create a new inState, with a reference to the changes message, and the offset
        /// of a particular change's data
        /// </summary>
        /// <param name="msgBuffer">Message buffer</param>
        /// <param name="dataOffset">Offset of first of the two bytes for a change</param>
        public Pacom8204InputState(byte[] msgBuffer, int dataOffset)
        {
            buffer = msgBuffer;
            offset = dataOffset;
        }
    }
}