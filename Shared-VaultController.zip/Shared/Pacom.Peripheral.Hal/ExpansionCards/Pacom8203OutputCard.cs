﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class provides the functionality of the 8203 output expansion card.
    /// </summary>
    public class Pacom8203OutputCard : ExpansionCardBase, IOutputContainer
    {
        public const int OutputsCount = 4;

        private ExpansionCardOutputs currentlyActiveOutputs = ExpansionCardOutputs.None;
        private readonly object sync = new object();
        private byte[] getOutputsResponseBuffer = new byte[5];

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="slotNumber">0 if the expansion card is in Exp1, 1 if the expansion card is in Exp2.</param>
        /// <param name="identityResponse">The response from the expansion card to the identity query command.</param>
        public Pacom8203OutputCard(int slotNumber, byte[] identityResponse)
            : base(slotNumber, identityResponse, ExpansionCardType.Pacom8203OutputCard)
        {

        }

        protected override void initialise()
        {
        }

        /// <summary>
        /// Returns the period in ms as to how often the PollDevice method should be called by the ExpansionCardManager.
        /// </summary>
        /// <returns>The period in ms as to how often the PollDevice method should be called by the ExpansionCardManager.</returns>
        public override int RequiredPollTime()
        {
            return 500;
        }

        /// <summary>
        /// Returns true once the expansion card has been successfully initialized and is completely up and running.
        /// As the identity query command has already been responded to, the card is ready immediately.
        /// </summary>
        public override bool Initialized
        {
            get { return true; }
        }

        #region IOutputContainer Members

        /// <summary>
        /// Number of outputs that 8203 outputs card supports
        /// </summary>
        public int ContainerOutputCount
        {
            get { return OutputsCount; }
        }
                
        /// <summary>
        /// Activates an output on the expansion card.
        /// </summary>
        /// <param name="outputNumber">The zero based output to activate.</param>
        /// <returns>True on success.</returns>
        public bool SetOutput(int outputNumber)
        {
            bool result;
            Logger.LogDebugMessage(LoggerClassPrefixes.ExpansionManager, () =>
            {
                return string.Format("Setting output {0} on expansion card {1}.", outputNumber + 1, slotNumber + 1);
            });
            lock (sync)
            {
                currentlyActiveOutputs = currentlyActiveOutputs | (ExpansionCardOutputs)(1 << (outputNumber));

                byte[] setOutputCommand = new byte[] { 0x04, 0x01, 0x00, 0x00 };
                setOutputCommand[2] = (byte)currentlyActiveOutputs;
                SetChecksum(setOutputCommand);

                result = I2c.WriteToDevice(i2cAddress | 0x07, 0, 0, setOutputCommand);
            }
            return result;
        }

        /// <summary>
        /// Deactivates an output on the expansion card.
        /// </summary>
        /// <param name="outputNumber">The zero based output to deactivate.</param>
        /// <returns>True on success.</returns>
        public bool ClearOutput(int outputNumber)
        {
            bool result;
            Logger.LogDebugMessage(LoggerClassPrefixes.ExpansionManager, () =>
            {
                return string.Format("Clearing output {0} on expansion card {1}.", outputNumber + 1, slotNumber + 1);
            });
            lock (sync)
            {
                currentlyActiveOutputs = currentlyActiveOutputs & (ExpansionCardOutputs)~(1 << (outputNumber));

                byte[] setOutputCommand = new byte[] { 0x04, 0x01, 0x00, 0x00 };
                setOutputCommand[2] = (byte)currentlyActiveOutputs;
                SetChecksum(setOutputCommand);

                result = I2c.WriteToDevice(i2cAddress | 0x07, 0, 0, setOutputCommand);
            }
            return result;
        }
        
        /// <summary>
        /// Update outputs. Not implemented in 8203 cards. All outputs are written directly to the card.
        /// </summary>
        public bool WriteOutputs()
        {
            return true;
        }

        /// <summary>
        /// Clear all outputs at once.
        /// </summary>
        public bool ClearAllOutputs()
        {
            for (int output = 0; output < OutputsCount; output++)
            {
                this.ClearOutput(output);
            }
            return true;
        }

        /// <summary>
        /// First output number in all outputs collection.
        /// </summary>
        public override int FirstOutputPoint
        {
            get { return ConfigurationManager.OnboardOutputsCount + slotNumber * OutputsCount; }
        }

        #endregion

        /// <summary>
        /// The current state of each of the outputs on the expansion card.
        /// </summary>
        public ExpansionCardOutputs OutputState
        {
            get
            {
                return currentlyActiveOutputs;
            }
        }

        /// <summary>
        /// Polls the expansion card once a second to keep the card online and the status
        /// up-to-date.
        /// </summary>
        /// <returns>True on success. Returns of False are used to trigger an offline condition.</returns>
        public override bool PollDevice()
        {
            bool result;

            lock (sync)
            {
                byte status = 0;
                result = I2c.ReadFromDevice(i2cAddress | 0x07, 0, 0, getOutputsResponseBuffer);
                if (result && ValidChecksum(getOutputsResponseBuffer))
                {
                    status = getOutputsResponseBuffer[1];
                    base.ProcessStatus(status);
                    if (currentlyActiveOutputs != (ExpansionCardOutputs)getOutputsResponseBuffer[3])
                    {
                        byte[] setOutputCommand = new byte[] { 0x04, 0x01, 0x00, 0x00 };
                        setOutputCommand[2] = (byte)currentlyActiveOutputs;
                        SetChecksum(setOutputCommand);

                        I2c.WriteToDevice(i2cAddress | 0x07, 0, 0, setOutputCommand);
                    }
                }
            }
            return result;
        }
    }
}
