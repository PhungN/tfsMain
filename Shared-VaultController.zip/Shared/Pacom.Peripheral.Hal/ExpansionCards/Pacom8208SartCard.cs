﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class provides the functionality of the 8208 SART expansion card.
    /// </summary>
    public class Pacom8208SartCard : ExpansionCardBase, IOutputContainer
    {
        /// <summary>
        /// S-ART card outputs count: 248 -> 4 buses, each bus can have up to 31 addresses, each address can have 2 outputs: output 1 & output 0.
        /// Usually only output 1 is used
        /// </summary>
        public const int OutputsCount = 248;

        public const int BusCount = 4;
        public const int AddressCount = 31;
        public const int OutputCount = 2;

        /// <summary>
        /// S-ART card inputs count: 124 -> 4 buses, each bus can have up to 31 addresses
        /// </summary>
        public const int InputsCount = 124;
                
        public const int OutputBytesCount = 32;
        public const int MaxOutputCountPerBus = 32;
        public const int OutputBufferByteCount = 36;

        /// <summary>
        /// The number of inputs on the expansion card
        /// </summary>
        private readonly object sync = new object();

        /// <summary>
        /// The inputs response buffer length is 68 bytes: 64 bytes for inputs status (124 inputs / 2 = 62 aligned to 64) + 
        /// 4 bytes (message length, status, description and checksum)
        /// </summary>
        public const int InputsResponseBufferLength = 68;
        private byte[] inputsResponseBuffer = new byte[InputsResponseBufferLength];

        private byte[] outputsRequestBuffer = new byte[OutputBufferByteCount];
        public const int OutputsResponseBufferLength = 36;
        private byte[] outputsResponseBuffer = new byte[OutputsResponseBufferLength];

        private bool[, ,] sartOutputStatus = new bool[BusCount, AddressCount, OutputCount];
        private Common.InputStatus[,] sartInputStatus = new Common.InputStatus[BusCount, AddressCount];
        private int[,] inputPointHitCounts = new int[BusCount, AddressCount];
        private int[,] hitCounts = new int[BusCount, AddressCount];

        /// <summary>
        /// Only one card is supported in the system.
        /// </summary>
        private const OwnerType owner = OwnerType.Sart1;

#if DEBUG
        private const int debugTimeout = 10000;
        TimeLimit debugInputsBufferTimeout = new TimeLimit(debugTimeout, true);
#endif
        private const int readOutputsTimeout = 1000;
        TimeLimit readOutputsTimer = new TimeLimit(readOutputsTimeout, true);

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="slotNumber">0 if the expansion card is in Exp1, 1 if the expansion card is in Exp2.</param>
        /// <param name="identityResponse">The response from the expansion card to the identity query command.</param>
        public Pacom8208SartCard(int slotNumber, byte[] identityResponse)
            : base(slotNumber, identityResponse, ExpansionCardType.Pacom8208SartInputOutputCard)
        {
            ConfigurationManager.Instance.ConfigurationChanged += new EventHandler<EventArgs>(configurationManager_ConfigurationChanged);

            // Read the current configuration
            configurationManager_ConfigurationChanged(null, null);

            // Initialize the S-ART card outputs status
            for (int bus = 0; bus < BusCount; bus++)
            {
                for (int address = 0; address < AddressCount; address++)
                {
                    for (int outputnb = 0; outputnb < OutputCount; outputnb++)
                    {
                        sartOutputStatus[bus, address, outputnb] = false;
                    }
                    sartInputStatus[bus, address] = Common.InputStatus.Unknown;
                    hitCounts[bus, address] = 0;
                }
            }
        }

        /// <summary>
        /// Get the 1st input id for expansion card slot
        /// </summary>
        /// <returns>The 1st input id for expansion slot</returns>
        public override int FirstInputPoint
        {
            get { return ConfigurationManager.OnboardInputsCount + 4 * Pacom8204InputCard.InputsCount; }
        }

        private void configurationManager_ConfigurationChanged(object sender, EventArgs e)
        {
            lock (inputPointHitCounts)
            {
                int startingPoint = FirstInputPoint;
                for (int i = 0; i < InputsCount; i++)
                {
                    InputConfiguration inputConfiguration = ConfigurationManager.Instance.Inputs[startingPoint + i + 1];
                    if (inputConfiguration != null)
                    {
                        int bus = i / AddressCount;
                        int address = i % AddressCount;
                        inputPointHitCounts[bus, address] = inputConfiguration.HitCount;
                    }
                }
            }
        }

        /// <summary>
        /// Returns the period in ms as to how often the PollDevice method should be called by the ExpansionCardManager.
        /// </summary>
        /// <returns>The period in ms as to how often the PollDevice method should be called by the ExpansionCardManager.</returns>
        public override int RequiredPollTime()
        {
            return 100;
        }

        /// <summary>
        /// Returns true once the expansion card has been successfully initialized and is completely up and running.
        /// Waits until all inputs have stabilized before returning true.
        /// </summary>
        public override bool Initialized
        {
            get
            {
                for (int bus = 0; bus < BusCount; bus++)
                {
                    for (int address = 0; address < AddressCount; address++)
                    {
                        if (sartInputStatus[bus, address] == Common.InputStatus.Unknown)
                            return false;
                    }
                }
                return true;
            }
        }

        /// <summary>
        /// Returns the current state (Secure/Alarm/Short/Open/Trouble) of an input point.
        /// </summary>
        /// <param name="inputNumber">The zero based input point of interest.</param>
        /// <returns>The current state (Secure/Alarm/Short/Open/Trouble) of the input point.</returns>
        public override Common.InputStatus GetInputPointStatus(int inputNumber)
        {
            if (inputNumber < 0 || inputNumber >= InputsCount)
                return Common.InputStatus.Trouble;
            int bus = inputNumber / AddressCount;
            int address = inputNumber % AddressCount;
            if (bus < 0 || bus > BusCount - 1 || address < 0 || address > AddressCount - 1)
            {
                return Common.InputStatus.Trouble;
            }
            return sartInputStatus[bus, address];
        }

        #region IOutputContainer Members

        /// <summary>
        /// S-ART card outputs count: 248 -> 4 buses, each bus can have up to 31 addresses, each address can have 2 outputs: output 1 & output 0.
        /// Usually only output 1 is used
        /// </summary>
        public int ContainerOutputCount
        {
            get { return OutputsCount; }
        }

        /// <summary>
        /// Activates an output on the expansion card.
        /// </summary>
        /// <param name="outputNumber">The zero based output to activate.</param>
        /// <returns>True on success.</returns>
        public bool SetOutput(int outputNumber)
        {
            return toggleOutput(outputNumber, true);
        }
        
        public bool ClearOutput(int outputNumber)
        {
            return toggleOutput(outputNumber, false);
        }

        /// <summary>
        /// Clear all S-ART card outputs
        /// </summary>
        public bool ClearAllOutputs()
        {
            for (int bus = 0; bus < BusCount; bus++)
            {
                for (int address = 0; address < AddressCount; address++)
                {
                    for (int outputnb = 0; outputnb < OutputCount; outputnb++)
                    {
                        sartOutputStatus[bus, address, outputnb] = false;
                    }
                }
            }
            return WriteOutputs();
        }

        /// <summary>
        /// Write all S-ART card outputs in one go
        /// </summary>
        /// <returns>True if the I2C write was successfull</returns>
        public bool WriteOutputs()
        {
            bool result = false;
            Logger.LogDebugMessage(LoggerClassPrefixes.ExpansionManager, () =>
            {
                return "[SART-CARD]: Write all outputs.";
            });
            lock (sync)
            {
                outputsRequestBuffer[0] = OutputBufferByteCount;
                outputsRequestBuffer[1] = OutputBytesCount;

                int i = 0;
                for (int bus = 0; bus < BusCount; bus++)
                {
                    for (int address = 0; address < AddressCount; address++)
                    {
                        for (int outputnb = 0; outputnb < OutputCount; outputnb++)
                        {
                            i = ((bus * MaxOutputCountPerBus + address) / 8) + 2;
                            if (outputnb == 0)
                                i += (BusCount * MaxOutputCountPerBus) / 8;

                            byte mask = (byte)(1 << (address % 8));
                            if (sartOutputStatus[bus, address, outputnb])
                            {
                                // Set S-ART card output
                                outputsRequestBuffer[i] |= mask;
                            }
                            else
                            {
                                // Clear S-ART card output
                                outputsRequestBuffer[i] &= (byte)(~mask);
                            }
                        }
                    }
                }
                SetChecksum(outputsRequestBuffer);
                result = I2c.WriteToDevice(i2cAddress | 0x07, 0, 0, outputsRequestBuffer);
            }
            return result;
        }

        /// <summary>
        /// Get the 1st output id for expansion card slot
        /// </summary>
        /// <returns>The 1st output id for expansion slot</returns>
        public override int FirstOutputPoint
        {
            get { return ConfigurationManager.OnboardOutputsCount + 4 * Pacom8203OutputCard.OutputsCount; }
        }

        #endregion

        private bool toggleOutput(int outputNumber, bool value)
        {
            if (outputNumber < 0 || outputNumber >= OutputsCount)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.ExpansionManager, () =>
                {
                    return string.Format("[SART-CARD]: Invalid output number: {0}. [{1}] outputs supported.", outputNumber + 1, OutputsCount);
                });
                return false;
            }
            int bus = outputNumber / AddressCount;
            if (outputNumber > InputsCount - 1)
                bus /= 2;
            int address = outputNumber % AddressCount;
            int outputNum = 1;
            if (outputNumber > InputsCount - 1)
                outputNum = 0;

            Logger.LogDebugMessage(LoggerClassPrefixes.ExpansionManager, () =>
            {
                return string.Format("[SART-CARD]: {0} Output {1} [(Bus,Address,OutputNumber)=({2},{3},{4})].",
                                     value ? "Activate" : "Deactivate", outputNumber, bus, address, outputNum);
            });
            lock (sync)
            {
                sartOutputStatus[bus, address, outputNum] = value;
            }
            return true;
        }

        protected override void initialise()
        {
        }

        /// <summary>
        /// Polls the expansion card every 100ms for any input point state changes.
        /// </summary>
        /// <returns>True on success. Returns of False are used to trigger an offline condition.</returns>
        public override bool PollDevice()
        {
            bool result = true;

            lock (sync)
            {
                bool anyOutputOneChanged = checkReadInputsOutputs(ref result);
                if (readOutputsTimer.IsTimeUp(readOutputsTimeout) == true)
                {
                    bool anyOutputsChanged = checkReadOutputs(ref result);
                    if (anyOutputOneChanged == true || anyOutputsChanged == true)
                    {
                        WriteOutputs();
                    }
                    readOutputsTimer.Reset();
                }
            }
            return result;
        }

        /// <summary>
        /// Read S-ART card inputs and the output 1 values.
        /// </summary>
        /// <param name="result"></param>
        /// <returns></returns>
        private bool checkReadInputsOutputs(ref bool result)
        {
            bool anyOutputOneChanged = false;
            result = I2c.ReadFromDevice(i2cAddress | 0x08, 0, 0, inputsResponseBuffer);
            if (inputsResponseBuffer[0] != InputsResponseBufferLength)
            {
                // The length of the S-ART card inputs data must be 68
                return false;
            }
            if (result && ValidChecksum(inputsResponseBuffer))
            {
                byte status = inputsResponseBuffer[1];
                base.ProcessStatus(status);
                if ((status & (byte)ExpansionCardStatusByte.InvalidData) == 0)
                {
                    for (int bus = 0; bus < BusCount; bus++)
                    {
                        for (int address = 0; address < AddressCount; address++)
                        {
                            byte value;
                            int i = ((bus * 32 + address) / 2) + 3;

                            value = inputsResponseBuffer[i];

                            if ((address % 2) != 0)
                                value >>= 4;

                            bool outputChanged = readOneInputOutput(value, bus, address);
                            if (anyOutputOneChanged == false && outputChanged == true)
                            {
                                anyOutputOneChanged = true;
                            }
                        }
                    }
                }
            }
            return anyOutputOneChanged;
        }

        private bool readOneInputOutput(byte inputOutputState, int bus, int address)
        {
            // Read the input value and write into inputStatus array
            Common.InputStatus readInputStatus = classifyAlarmInputPointStatus(inputOutputState);
            checkUpdateInputStatus(readInputStatus, bus, address, bus * AddressCount + address);
            // Read output 1 value and mark if write outputs is required
            return (((byte)(inputOutputState & 0x08) != 0) != sartOutputStatus[bus, address, 1]);
        }

        /// <summary>
        /// Update input status if required. Update the hit count for this input if the new input value differs from the current one
        /// </summary>
        /// <param name="readInputStatus">Current input read status</param>
        /// <param name="bus">S-ART card Bus number: 0-3</param>
        /// <param name="address">S-ART card input address on S-ART bus: 0-30</param>
        /// <param name="inputNumber">Configured input number: 0-123, maximum 124 inputs per S-ART card</param>
        private void checkUpdateInputStatus(Common.InputStatus readInputStatus, int bus, int address, int inputNumber)
        {
            if (readInputStatus != sartInputStatus[bus, address])
            {
                hitCounts[bus, address]++;
                if (hitCounts[bus, address] >= inputPointHitCounts[bus, address])
                {
                    sartInputStatus[bus, address] = readInputStatus;
                    if (sartInputStatus[bus, address] != Common.InputStatus.Unknown)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.ExpansionManager, () =>
                        {
                            return string.Format("[SART-CARD]: Input {0} on S-ART Bus [{1}] and Address [{2}] has changed state to [{3}].",
                                                 inputNumber, bus, address, sartInputStatus[bus, address].ToString());
                        });
                        int logicalId = ConfigurationManager.Instance.Inputs.LogicalInputId(owner, inputNumber);
                        var inputStatus = StatusManager.Instance.Inputs[logicalId];
                        if (inputStatus != null)
                            inputStatus.Change(sartInputStatus[bus, address], 0);

                        hitCounts[bus, address] = 0;
                    }
                }
                return;
            }
            hitCounts[bus, address] = 0;
        }

        /// <summary>
        /// Get input status from read data
        /// </summary>
        /// <param name="inputValue">Input data, a nibble from which the 3 lower bits are used to determine the input state</param>
        /// <returns>Returns: Secure, Alarm, Short, Open or Trouble</returns>
        private Common.InputStatus classifyAlarmInputPointStatus(byte inputValue)
        {
            switch (inputValue & 0x07)
            {
                case 0: return Common.InputStatus.Secure;
                case 1: return Common.InputStatus.Alarm;
                case 2: return Common.InputStatus.Short;
                case 3: return Common.InputStatus.Open;
                default: return Common.InputStatus.Trouble;
            }
        }

        /// <summary>
        /// Check if we need to update the outputs when the S-ART card is polled, only if the device is not upto date 
        /// </summary>
        /// <param name="result"></param>
        /// <returns>True if any out put has changed and the S-ART card needs to be notified.</returns>
        private bool checkReadOutputs(ref bool result)
        {
            result = I2c.ReadFromDevice(i2cAddress | 0x07, 0, 0, outputsResponseBuffer);
            if (outputsResponseBuffer[0] < 4)
            {
                // At least 4 bytes must be read for the message to be valid
                return false;
            }
            if (result && ValidChecksum(outputsResponseBuffer))
            {
                byte numOutputBytes = outputsResponseBuffer[2];
                byte msgLen = outputsResponseBuffer[0];

                if (numOutputBytes != (msgLen - 4))
                    return false;

                byte status = outputsResponseBuffer[1];
                base.ProcessStatus(status);
                if ((status & (byte)ExpansionCardStatusByte.InvalidData) != 0)
                    return false;

                int i = 0;
                for (int bus = 0; bus < BusCount; bus++)
                {
                    for (int address = 0; address < AddressCount; address++)
                    {
                        for (int outputnb = 0; outputnb < OutputCount; outputnb++)
                        {
                            i = ((bus * MaxOutputCountPerBus + address) / 8) + 3;
                            if (outputnb == 0)
                                i += (BusCount * MaxOutputCountPerBus) / 8;

                            if (i < numOutputBytes)
                            {
                                byte value = outputsResponseBuffer[i];
                                byte mask = (byte)(1 << (address % 8));
                                bool readOutputStatus = (value & mask) != 0;
                                if (readOutputStatus != sartOutputStatus[bus, address, outputnb])
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
    }
}
