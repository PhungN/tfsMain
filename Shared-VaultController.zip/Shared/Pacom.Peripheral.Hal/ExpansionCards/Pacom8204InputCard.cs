﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utilities;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class provides the functionality of the 8204 input expansion card.
    /// </summary>
    public class Pacom8204InputCard : ExpansionCardBase
    {
        /// <summary>
        /// The number of inputs on the expansion card
        /// </summary>
        public const int InputsCount = 8;

        /// <summary>
        /// Are there any analog inputs enabled
        /// </summary>
        private bool anyAnalogInputs = false;

        /// <summary>
        /// Are there any resistive inputs enabled
        /// </summary>
        private bool anyResistiveInputs = false;

        /// <summary>
        /// Divider counter, for when to check resistive inputs (works with pollDivideByN)
        /// </summary>
        private static int pollDivide = 0;

        /// <summary>
        /// The value the divider (pollDivide) counts up to, before checking the resistive inputs.
        /// </summary>
        private static int pollDivideByN = 5;


        private readonly ExtendedInputPointConfiguration[] inputPointConfigurations = new ExtendedInputPointConfiguration[InputsCount];
        private readonly Common.InputStatus[] currentInputStatuses = new Common.InputStatus[InputsCount];


        /// <summary>
        /// Hit counter used only in analog input mode
        /// </summary>
        private readonly int[] hitCountAnalog = new int[InputsCount];
        private readonly int[] previousAnalogValues = new int[InputsCount];

        // Buffers for messages to and from the mezzanine card
        private readonly byte[] getInputsResponseBuffer = new byte[0x24];
        private readonly byte[] changeListResponseBuffer = new byte[64]; // variable length response
        private readonly byte[] requestFullUpdateCommand = { 0x02, 0xFE };
        private readonly Pacom8204SetParametersCommand setParametersCommand = new Pacom8204SetParametersCommand();

        // I2C command codes for the 8204 mezzanine card
        private const int cmdGetAnalogInputs = 0x06;
        private const int cmd8204SendAll = 0x02;
        private const int cmd8204GetChangeList = 0x03;
        private const int cmd8204SetParameters = 0x07;

        /// <summary>
        /// If we need to request a full update of resistive input readings from the mezzanine card
        /// </summary>
        private bool needFullUpdate = false;

        private readonly OwnerType owner = OwnerType.None;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="slotNumber">0 if the expansion card is in Exp1, 1 if the expansion card is in Exp2.</param>
        /// <param name="identityResponse">The response from the expansion card to the identity query command.</param>
        public Pacom8204InputCard(int slotNumber, byte[] identityResponse)
            : base(slotNumber, identityResponse, ExpansionCardType.Pacom8204InputCard)
        {
            owner = ConfigurationManager.Instance.Expansions.GetOwnerType(slotNumber);

			// Read the current configuration
            ConfigurationHasChanged();

            for (int i = 0; i < InputsCount; i++)
            {
                currentInputStatuses[i] = Common.InputStatus.Unknown;
                hitCountAnalog[i] = 0;
                previousAnalogValues[i] = Int32.MinValue;
            }
        }

        /// <summary>
        /// Get the 1st input id for expansion card slot
        /// </summary>
        /// <returns>The 1st input id for expansion slot</returns>
        public override int FirstInputPoint
        {
            get { return ConfigurationManager.OnboardInputsCount + slotNumber * InputsCount; }
        }

        /// <summary>
        /// Configuration has changed.  This is called directly by ExpansionCardManager, rather than as a
        /// event handler from ConfigurationManager, to guarantee it is called before RequiredPollTime is
		/// called.
        /// </summary>
        public void ConfigurationHasChanged()
        {
            try
            {
                lock (inputPointConfigurations)
                {
                    anyAnalogInputs = false;
                    anyResistiveInputs = false;
                    int startingPoint = FirstInputPoint;
                    for (int i = 0; i < InputsCount; i++)
                    {
                        InputConfiguration inputConfiguration = ConfigurationManager.Instance.Inputs[startingPoint + i + 1];
                        if (inputConfiguration == null)
                        {
                            continue;
                        }

                        inputPointConfigurations[i] = new ExtendedInputPointConfiguration(inputConfiguration, false, true);
                        bool isAnalog = inputPointConfigurations[i].AlarmResistance == 25500 && inputPointConfigurations[i].SecureResistance == 25500;
                        if (isAnalog) // Add analog configuration
                            currentInputStatuses[i] = Common.InputStatus.Analog;
                        else if (currentInputStatuses[i] == Common.InputStatus.Analog) // Remove the analog configuration
                            currentInputStatuses[i] = Common.InputStatus.Unknown;
                        
                        if (isAnalog)
                        {
                            anyAnalogInputs = true;
                        }
                        else
                        {
                            anyResistiveInputs = true;
                        }
                    }
                    initialise();
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.ExpansionManager, () => 
                    string.Format("Error while applying configuration change in 8204 : {0}", ex.ToString()));
            }
        }

        /// <summary>
        /// Called after firmware update is complete, as well on configuration changed
        /// </summary>
        protected override void initialise()
        {
            // A firmware update has been done, or this is our initial startup
            setMezzanineParameters();
            needFullUpdate = true;
        }

        /// <summary>
        /// Returns true once the expansion card has been successfully initialized and is completely up and running.
        /// Waits until all inputs have stabilized before returning true.
        /// </summary>
        public override bool Initialized
        {
            get
            {
                for (int i = 0; i < InputsCount; i++)
                {
                    if (currentInputStatuses[i] == Common.InputStatus.Unknown)
                        return false;
                }
                return true;
            }
        }

        /// <summary>
        /// Returns the current state (Secure/Alarm/Short/Open/Trouble/Analog) of an input point.
        /// </summary>
        /// <param name="inputNumber">The zero based input point of interest.</param>
        /// <returns>The current state (Secure/Alarm/Short/Open/Trouble/Analog) of the input point.</returns>
        public override Common.InputStatus GetInputPointStatus(int inputNumber)
        {
            return currentInputStatuses[inputNumber];
        }

        /// <summary>
        /// Returns the period in ms as to how often the PollDevice method should be called by the ExpansionCardManager.
        /// </summary>
        public override int RequiredPollTime()
        {
            // Analog and resisitive inputs are polled at different rates.  This function is called only once at startup,
            // so return the faster rate that we'll divide down later for checking the resistive inputs.
            const int resistiveInterval = 500;
            const int analogInterval = 100;

            if (anyResistiveInputs && anyAnalogInputs == false)
            {
                // Only resistive inputs, poll at slower rate and no dividing
                pollDivideByN = 1;
                pollDivide = 0;
                return resistiveInterval;
            }
            if (anyResistiveInputs == false && anyAnalogInputs)
            {
                // Only analog inputs, poll at faster rate and no dividing
                pollDivideByN = 1;
                pollDivide = 0;
                return analogInterval;
            }

            // Both types, poll at faster rate and divide for checking resisitive
            pollDivideByN = resistiveInterval / analogInterval;
            pollDivide = 0;
            return analogInterval;
        }

        /// <summary>
        /// Called every RequiredPollTime() to potentially poll the expansion card.  Analog inputs are checked every 
        /// time, while resistive inputs are checked less frequently.
        /// </summary>
        /// <returns>True on success. Returns of False are used to trigger an offline condition.</returns>
        public override bool PollDevice()
        {
            // We may do up to two I2C reads, each returning the mezzanine's state, but need to pass only one of 
            // them to the base class.
            bool statusDoneThisPoll = false;

            lock (inputPointConfigurations)
            {
                // This is called every 100ms, in case we're monitoring analogue inputs, but changes to resistive 
                // inputs don't need to be checked so frequently.  So, we have a divider that counts to 5.
                if (anyResistiveInputs && ++pollDivide >= pollDivideByN)
                {
                    // Time to check the resistive inputs
                    pollDivide = 0;

                    if (readAndProcessChangeList(ref statusDoneThisPoll) == false)
                    {
                        // Something went wrong, so we're likely out of sync and need to do a full update
                        needFullUpdate = true;
                        return false;
                    }

                    if (needFullUpdate)
                    {
                        if (requestFullUpdate() == false)
                        {
                            return false;
                        }

                        needFullUpdate = false;
                    }
                }

                if (anyAnalogInputs && readAndProcessAnalogInputs(ref statusDoneThisPoll) == false)
                {
                    return false;
                }

                return true;
            } // lock inputPointConfigurations
        }

        /// <summary>
        /// Send a command to the 8204 mezzanine to update its resistive input detection
        /// and monitoring parameters.
        /// </summary>
        private void setMezzanineParameters()
        {
            for (int i = 0; i < InputsCount; i++)
            {
                setParametersCommand.HitLimitSet(i, inputPointConfigurations[i].HitCount);
            }
            I2c.WriteToDevice(i2cAddress | cmd8204SetParameters, 0, 0, setParametersCommand.Command);
        }

        /// <summary>
        /// Send a command to the 8204 mezzanine to request that the full set of ADC readings 
        /// be sent to us.
        /// </summary>
        /// <returns>true, unless there is an error indicating that the card is offline</returns>
        private bool requestFullUpdate()
        {
            return I2c.WriteToDevice(i2cAddress | cmd8204SendAll, 0, 0, requestFullUpdateCommand);
        }

        /// <summary>
        /// Check the 8204 mezzanine to see if there are any input changes since the last check.
        /// </summary>
        /// <remarks>
        /// Due to the limited memory in the 8204, only a certain number of changes can be queued.
        /// If that queue overflows, we will get the most recent changes, and eventually the 8204 
        /// will automatically send us a full update of all inputs to get us back in sync with it.
        /// </remarks>
        /// <param name="statusDoneThisPoll">
        /// Passed as true if the status has been previously read and passed to the base class, 
        /// set by us to true if we do so.
        /// </param>
        /// <returns>true, unless there is an error indicating that the card is offline</returns>
        private bool readAndProcessChangeList(ref bool statusDoneThisPoll)
        {
            // Multiple reads may be required, as the queue on the device is longer than can be
            // sent in a single message.  Limit the number of times we read from the device so
            // we get everything it has to tell us, but we don't get stuck here forever.  As
            // of 2018-05-16, the total number of events buffered can be up to 32, delivered
            // to us 8 at a time.
            int loopCount = 4;
            do
            {
                if (I2c.ReadFromDevice(i2cAddress | cmd8204GetChangeList, 0, 0, changeListResponseBuffer) == false ||
                    ValidChecksum(changeListResponseBuffer) == false)
                {
                    return false;
                }

                if (statusDoneThisPoll == false)
                {
                    byte statusByte = changeListResponseBuffer[1];
                    base.ProcessStatus(statusByte);
                    statusDoneThisPoll = true;
                }

                // Two bytes are used per event, with 3 bytes of overhead (length, state, checksum)
                int nChanges = (changeListResponseBuffer[0] - 3) / 2;
                if (nChanges <= 0)
                {
                    return true;
                }

                for (int i = 0; i < nChanges; i++)
                {
                    Pacom8204InputState state = new Pacom8204InputState(changeListResponseBuffer, 2 + 2 * i);

                    if (currentInputStatuses[i] == Common.InputStatus.Analog)
                    {
                        // ignore changes and updates for inputs in analog mode
                        continue;
                    }

                    processResistiveInput(state.InputNumber, state.ADCReading, state.Injection);
                }
            } while (--loopCount != 0);

            return true;
        }

        /// <summary>
        /// Process a reported change to a resistive input on the 8204 mezzanine card
        /// </summary>
        /// <param name="inputNumber">Which input</param>
        /// <param name="adcReading">Current ADC reading</param>
        /// <param name="injection">Whether or not injection has been detected</param>
        private void processResistiveInput(int inputNumber, int adcReading, bool injection)
        {
            // The mezzanine card has already done hitcount work, so we can update the input
            // status in the controller immediately
            Common.InputStatus inputStatus;

            if (injection)
            {
                // If injection, the ADC reading is no use, so force the Trouble status
                inputStatus = Common.InputStatus.Trouble;
            }
            else
            {
                inputStatus = classifyAlarmInputPointStatus(inputNumber, adcReading);
            }

            if (currentInputStatuses[inputNumber] == inputStatus)
            {
                // No change from last time
                return;
            }

            Logger.LogDebugMessage(LoggerClassPrefixes.ExpansionManager,
                                   () => string.Format("Mezz {0} Input point {1} changed state to {2} ({3} ohms){4}",
                                                       (slotNumber + 1),
                                                       (inputNumber + 1),
                                                       inputStatus,
                                                       CommonUtilities.AdcReadingToResistanceValue(adcReading, ExtendedInputPointConfiguration.AdcResolution, 0, 10000),
                                                       injection ? " INJECTION" : ""));

            currentInputStatuses[inputNumber] = inputStatus;

            int logicalId = ConfigurationManager.Instance.Inputs.LogicalInputId(owner, inputNumber);
            Common.Status.InputStatus smInputStatus = StatusManager.Instance.Inputs[logicalId];
            if (smInputStatus != null)
            {
                smInputStatus.Change(currentInputStatuses[inputNumber], adcReading);
            }
        }
        
        /// <summary>
        /// Take an input and its ADC reading and determine the status that represents
        /// </summary>
        /// <param name="inputNumber">Which input</param>
        /// <param name="adcReading">ADC reading to decode</param>
        /// <returns>The input status</returns>
        private Common.InputStatus classifyAlarmInputPointStatus(int inputNumber, int adcReading)
        {
            if (adcReading >= inputPointConfigurations[inputNumber].SecureRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].SecureRangeUpperLimit)
                return Common.InputStatus.Secure;
            if (adcReading >= inputPointConfigurations[inputNumber].AlarmRange1LowerLimit && adcReading <= inputPointConfigurations[inputNumber].AlarmRange1UpperLimit)
                return Common.InputStatus.Alarm;
            if (adcReading >= inputPointConfigurations[inputNumber].AlarmRange2LowerLimit && adcReading <= inputPointConfigurations[inputNumber].AlarmRange2UpperLimit)
                return Common.InputStatus.Alarm;
            if (adcReading >= inputPointConfigurations[inputNumber].OpenRangeLowerLimit)
                return Common.InputStatus.Open;
            if (adcReading <= inputPointConfigurations[inputNumber].ShortRangeUpperLimit)
                return Common.InputStatus.Short;
            if (adcReading >= inputPointConfigurations[inputNumber].MaskingRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].MaskingRangeUpperLimit)
                return Common.InputStatus.Masking;
            if (adcReading >= inputPointConfigurations[inputNumber].RangeReductionRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].RangeReductionRangeUpperLimit)
                return Common.InputStatus.RangeReduction;
            if (adcReading >= inputPointConfigurations[inputNumber].MaskingAndRangeReductionRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].MaskingAndRangeReductionRangeUpperLimit)
                return Common.InputStatus.MaskingAndRangeReduction;
            if (adcReading >= inputPointConfigurations[inputNumber].AlarmAndMaskingRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].AlarmAndMaskingRangeUpperLimit)
                return Common.InputStatus.AlarmAndMasking;
            if (adcReading >= inputPointConfigurations[inputNumber].AlarmAndRangeReductionRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].AlarmAndRangeReductionRangeUpperLimit)
                return Common.InputStatus.AlarmAndRangeReduction;
            if (adcReading >= inputPointConfigurations[inputNumber].AlarmAndMaskingAndRangeReductionRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].AlarmAndMaskingAndRangeReductionRangeUpperLimit)
                return Common.InputStatus.AlarmAndMaskingAndRangeReduction;

            return Common.InputStatus.Trouble;
        }


        /// <summary>
        /// Retrieve the full set of high and low ADC readings, and process them for any inputs
        /// configured in analogue mode.
        /// </summary>
        /// <param name="statusDoneThisPoll">
        /// Passed as true if the status has been previously read and passed to the base class,
        /// set by us to true if we do so.
        /// </param>
        /// <returns>true, unless there is an error indicating that the card is offline</returns>
        private bool readAndProcessAnalogInputs(ref bool statusDoneThisPoll)
        {
            // WARNING: THIS IS UNTESTED.  Analog inputs are currently not supported in EMCS, so this is
            // written without being tested.

            if (I2c.ReadFromDevice(i2cAddress | cmdGetAnalogInputs, 0, 0, getInputsResponseBuffer) == false ||
                ValidChecksum(getInputsResponseBuffer) == false)
            {
                return false;
            }

            byte statusByte = getInputsResponseBuffer[1];
            if (statusDoneThisPoll == false)
            {
                base.ProcessStatus(statusByte);
                statusDoneThisPoll = true;
            }

            if ((statusByte & (byte)ExpansionCardStatusByte.InvalidData) != 0)
            {
                // There isn't a full set of valid ADC readings yet
                return true;
            }

            for (int i = 0; i < InputsCount; i++)
            {
                if (currentInputStatuses[i] != Common.InputStatus.Analog)
                {
                    // skip over resistive inputs
                    continue;
                }

                // Warning! The I2C spec document (5.2.1) is inaccurate.
                // It states that Low then high voltage reference data samples 10 bits wide should be seen
                // but infact it is High then low voltages.

                // Warning! A valid read from the 8204 does not mean each high and low reading has been updated.
                // The 8204 will provide the message buffer whenever it is requested regardless of which bytes
                // have been updated since the last read.  As of 2018-05-16, the entire set of readings (high and low)
                // is updated approximately every 140ms

                // Use the more accurate high ADC reading for analog inputs
                int adcReading = getUnsigned16(getInputsResponseBuffer, 3 + i * 2);
                processAnalogueInput(i, adcReading);
            }
            return true;
        }

        /// <summary>
        /// Get an unsigned 16 bit int from a buffer
        /// </summary>
        /// <param name="msg">Message data</param>
        /// <param name="offset">Offset to get value from</param>
        /// <returns>16-bit unsigned integer</returns>
        private static UInt16 getUnsigned16(byte[] msg, int offset)
        {
            return (UInt16)((msg[offset] << 8) | msg[offset + 1]);
        }

        /// <summary>
        /// Process an ADC reading for a analog input
        /// </summary>
        /// <param name="inputNumber">Which input</param>
        /// <param name="adcReading">Current ADC reading</param>
        private void processAnalogueInput(int inputNumber, int adcReading)
        {
            if (adcReading < (previousAnalogValues[inputNumber] - inputPointConfigurations[inputNumber].AnalogInputResolution) ||
                                    adcReading > (previousAnalogValues[inputNumber] + inputPointConfigurations[inputNumber].AnalogInputResolution))
            {
                hitCountAnalog[inputNumber]++;
                if (hitCountAnalog[inputNumber] >= inputPointConfigurations[inputNumber].HitCount)
                {
                    if (previousAnalogValues[inputNumber] == Int32.MinValue)
                    {
                        previousAnalogValues[inputNumber] = adcReading;
                    }
                    else
                    {
                        previousAnalogValues[inputNumber] = adcReading;

                        int logicalId = ConfigurationManager.Instance.Inputs.LogicalInputId(owner, inputNumber);
                        Common.Status.InputStatus smInputStatus = StatusManager.Instance.Inputs[logicalId];
                        if (smInputStatus != null)
                        {
                            smInputStatus.Change(Common.InputStatus.Analog, adcReading);
                        }
                        hitCountAnalog[inputNumber] = 0;
                    }
                }
            }
            else
            {
                hitCountAnalog[inputNumber] = 0;
            }
        }
    }
}
