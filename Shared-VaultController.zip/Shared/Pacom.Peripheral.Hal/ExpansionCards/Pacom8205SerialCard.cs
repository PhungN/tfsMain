﻿using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class provides the functionality of the 8205 RS232/RS485 expansion card.
    /// </summary>
    public class Pacom8205SerialCard : ExpansionCardBase
    {
        private byte[] getInputsResponseBuffer = new byte[0x24];
        private readonly PhysicalSerialPort portId;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="slotNumber">0 if the expansion card is in Exp1, 1 if the expansion card is in Exp2.</param>
        /// <param name="identityResponse">The response from the expansion card to the identity query command.</param>
        public Pacom8205SerialCard(int slotNumber, byte[] identityResponse)
            : base(slotNumber, identityResponse, ExpansionCardType.Pacom8205SerialCard)
        {
            switch (slotNumber)
            {
                case 0:
                    portId = PhysicalSerialPort.ExpansionCard1;
                    break;
                case 1:
                    portId = PhysicalSerialPort.ExpansionCard2;
                    break;
            }
        }

        public PhysicalSerialPort PortId
        {
            get
            {
                return this.portId;
            }
        }

        protected override void initialise()
        {
        }

        /// <summary>
        /// Returns the period in ms as to how often the PollDevice method should be called by the ExpansionCardManager.
        /// </summary>
        /// <returns>The period in ms as to how often the PollDevice method should be called by the ExpansionCardManager.</returns>
        public override int RequiredPollTime()
        {
            return 500;
        }

        /// <summary>
        /// Returns true once the expansion card has been successfully initialized and is completely up and running.
        /// Waits until all inputs have stabilized before returning true.
        /// </summary>
        public override bool Initialized
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Polls the expansion card every 100ms for any input point state changes.
        /// </summary>
        /// <returns>True on success. Returns of False are used to trigger an offline condition.</returns>
        public override bool PollDevice()
        {
            byte status = 0;
            bool result = I2c.ReadFromDevice(i2cAddress | 0x01, 0, 0, getInputsResponseBuffer);
            if (result && ValidChecksum(getInputsResponseBuffer))
            {
                status = getInputsResponseBuffer[1];
                base.ProcessStatus(status);                
            }
            return result;
        }
    }
}
