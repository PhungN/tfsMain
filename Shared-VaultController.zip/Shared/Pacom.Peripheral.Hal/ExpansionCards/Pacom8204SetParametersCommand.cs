﻿namespace Pacom.Peripheral.Hal
{
    public class Pacom8204SetParametersCommand
    {
        private readonly byte[] command = new byte[1 + 2 + 2 + 1 + 1 + 8 + 1];

        /// <summary>
        /// Set a 16-bit unsigned integer in a command going to the 8204 mezzanine
        /// </summary>
        /// <param name="msg">Command data array</param>
        /// <param name="offset">Offset of first byte to update</param>
        /// <param name="value">Unsigned 16-bit integer value to set</param>
        private static void setUnsigned16(byte[] msg, int offset, int value)
        {
            if (value < 0)
            {
                value = 0;
            }
            else if (value > 65535)
            {
                value = 65535;
            }
            msg[offset + 0] = (byte)(value >> 8 & 0xff);
            msg[offset + 1] = (byte)(value & 0xff);
        }

        /// <summary>
        /// Set a 8-bit unsigned integer in a command going to the 8204 mezzanine
        /// </summary>
        /// <param name="msg">Command data array</param>
        /// <param name="offset">Offset of first byte to update</param>
        /// <param name="value">Unsigned 8-bit integer value to set</param>
        private static void setUnsigned8(byte[] msg, int offset, int value)
        {
            if (value < 0)
            {
                value = 0;
            }
            else if (value > 255)
            {
                value = 255;
            }
            msg[offset] = (byte)value;
        }

        /// <summary>
        /// Calculate the checksum, and return the array of bytes to be sent to the mezzanine card
        /// </summary>
        public byte[] Command
        {
            get
            {
                ExpansionCardBase.SetChecksum(command);
                return command;
            }
        }

        /// <summary>
        /// Maximum difference allowed between high and low reads, before being an injection
        /// </summary>
        public int InjectionTolerance
        {
            set { setUnsigned16(Command, 1, value); }
        }

        /// <summary>
        /// Amount to add to the channel's instability counter when an input changes
        /// </summary>
        public int InstabilityAdd
        {
            set { setUnsigned8(Command, 3, value); }
        }

        /// <summary>
        /// The limit at which an instability is detected, triggering an ADC send, expressed as a multiplier of hitCount
        /// </summary>
        public int InstabilityLimitFactor
        {
            set { setUnsigned8(Command, 4, value); }
        }

        /// <summary>
        /// The hitcount limit (per channel) for instability and injection detection.
        /// </summary>
        /// <param name="n">Channel number</param>
        /// <param name="value">Hit limit</param>
        public void HitLimitSet(int n, int value)
        {
            setUnsigned8(Command, 5 + n, value);
        }

        /// <summary>
        /// Create a new command for setting detection parameters, with default values
        /// </summary>
        public Pacom8204SetParametersCommand()
        {
            Command[0] = (byte)Command.Length;
            InjectionTolerance = 30;
            InstabilityAdd = 6;
            InstabilityLimitFactor = 10;
            for (int i = 0; i < 8; i++)
            {
                HitLimitSet(i, 3);
            }
        }
    }
}