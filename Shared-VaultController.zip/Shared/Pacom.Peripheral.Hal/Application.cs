﻿using System;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// Provides events that threads may wait on to gracefully close down the application.
    /// This has been used as background threads waiting on unmanaged events remain alive after the main thread
    /// has exited. A graceful shutdown allows for multiple runs per boot when debugging.
    /// </summary>
    public static class Application
    {
        private static bool closing = false;
        private static IntPtr closingEvent = NativeMethods.CreateEvent(IntPtr.Zero, true, false, null);

        /// <summary>
        /// Returns a native event that threads may wait on.
        /// The event is signalled when the Closing property is set.
        /// </summary>
        public static IntPtr ClosingEvent
        {
            get
            {
                return closingEvent;
            }
        }

        /// <summary>
        /// Sets the native event.
        /// </summary>
        public static bool Closing
        {
            set
            {
                if (value == true)
                {
                    NativeMethods.SetEvent(closingEvent);
                    closing = true;
                }
            }
            get
            {
                return closing;
            }
        }

        /// <summary>
        /// Waits on the native event.
        /// The event is signalled when the Closing property is set.
        /// </summary>
        /// <returns>True.</returns>
        public static bool WaitOnClose()
        {
            while (NativeMethods.WaitForSingleObject(closingEvent, Constants.Infinite) != 0) ;
            return true;
        }
    }
}
