﻿using System;
using System.Runtime.InteropServices;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class allows general purpose input/output pins on the processor to be configured and
    /// their current values read / set.
    /// </summary>
    public static class Gpio
    {
        static IntPtr driverHandle = initialize();

        /// <summary>Defined IOCTLs for GPIO driver</summary>
        private static int IOCTL_GPIO_SET_OUTPUT    = 0x222000;
        private static int IOCTL_GPIO_CLEAR_OUTPUT  = 0x222004;
        private static int IOCTL_GPIO_GET_INPUT     = 0x222008;
        private static int IOCTL_GPIO_CONFIGURE_PIN = 0x22200C;

        private static IntPtr initialize()
        {
            IntPtr handle = NativeMethods.CreateFile("PIO1:", FileAccess.GenericRead | FileAccess.GenericWrite, FileShare.Read | FileShare.Write, IntPtr.Zero, CreationDisposition.OpenExisting, FileAttribute.Normal, IntPtr.Zero);
            if (handle.ToInt32() == Constants.InvalidHandleValue)
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.GeneralPurposeInputOutput, () =>
                {
                    return "PIO driver (PIO1:) failed to open!";
                });
                StatusLed.AddStatus(SystemStatus.HardwareError);
            }
            return handle;
        }

        /// <summary>
        /// Activates an output pin on the processor.
        /// </summary>
        /// <param name="port">The port on the processor that the pin belongs to.</param>
        /// <param name="outputNumber">The zero based pin number on the port to activate.</param>
        /// <returns>True on success.</returns>
        public static bool SetOutput(GpioPort port, int outputNumber)
        {
            GpioPortStructure gpioPortStructure = new GpioPortStructure();
            gpioPortStructure.port = (UInt32)port;
            gpioPortStructure.value = (UInt32)(1 << outputNumber);

            if (NativeMethods.DeviceIoControl(driverHandle, IOCTL_GPIO_SET_OUTPUT, ref gpioPortStructure, Marshal.SizeOf(typeof(GpioPortStructure)), IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                return false;

            return true;
        }

        /// <summary>
        /// Deactivates an output pin on the processor.
        /// </summary>
        /// <param name="port">The port on the processor that the pin belongs to.</param>
        /// <param name="outputNumber">The zero based pin number on the port to deactivate.</param>
        /// <returns>True on success.</returns>
        public static bool ClearOutput(GpioPort port, int outputNumber)
        {
            GpioPortStructure gpioPortStructure = new GpioPortStructure();
            gpioPortStructure.port = (UInt32)port;
            gpioPortStructure.value = (UInt32)(1 << outputNumber);

            if (NativeMethods.DeviceIoControl(driverHandle, IOCTL_GPIO_CLEAR_OUTPUT, ref gpioPortStructure, Marshal.SizeOf(typeof(GpioPortStructure)), IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                return false;

            return true;
        }

        /// <summary>
        /// Activates outputs on the processor.
        /// </summary>
        /// <param name="port">The port on the processor that the pins belongs to.</param>
        /// <param name="value">A bit mask of which pins on the port to activate. 0's in the bit mask don't deactivate pins.</param>
        /// <returns>True on success.</returns>
        public static bool SetPortOutputs(GpioPort port, int value)
        {
            GpioPortStructure gpioPortStructure = new GpioPortStructure();
            gpioPortStructure.port = (UInt32)port;
            gpioPortStructure.value = (UInt32)value;

            if (NativeMethods.DeviceIoControl(driverHandle, IOCTL_GPIO_SET_OUTPUT, ref gpioPortStructure, Marshal.SizeOf(typeof(GpioPortStructure)), IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                return false;

            return true;
        }

        /// <summary>
        /// Deactivates outputs on the processor.
        /// </summary>
        /// <param name="port">The port on the processor that the pins belongs to.</param>
        /// <param name="value">A bit mask of which pins on the port to deactivate. 0's in the bit mask don't activate pins.</param>
        /// <returns>True on success.</returns>
        public static bool ClearPortOutputs(GpioPort port, int value)
        {
            GpioPortStructure gpioPortStructure = new GpioPortStructure();
            gpioPortStructure.port = (UInt32)port;
            gpioPortStructure.value = (UInt32)value;

            if (NativeMethods.DeviceIoControl(driverHandle, IOCTL_GPIO_CLEAR_OUTPUT, ref gpioPortStructure, Marshal.SizeOf(typeof(GpioPortStructure)), IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                return false;

            return true;
        }

        /// <summary>
        /// Returns the status of an input on the processor.
        /// </summary>
        /// <param name="port">The port on the processor that the pin belongs to.</param>
        /// <param name="inputNumber">The zero based pin number on the port to query.</param>
        /// <param name="inputSet">Returns true if the pin is active.</param>
        /// <returns>True on success.</returns>
        public static bool GetInput(GpioPort port, int inputNumber, out bool inputSet)
        {
            inputSet = false;

            GpioPortStructure gpioPortStructure = new GpioPortStructure();
            gpioPortStructure.port = (UInt32)port;

            if (NativeMethods.DeviceIoControl(driverHandle, IOCTL_GPIO_GET_INPUT, ref gpioPortStructure, Marshal.SizeOf(typeof(GpioPortStructure)), IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                return false;

            if ((gpioPortStructure.value & (1 << inputNumber)) != 0)
                inputSet = true;

            return true;
        }

        /// <summary>
        /// Returns the status of an inputs on the processor.
        /// </summary>
        /// <param name="port">The port on the processor that the pins belongs to.</param>
        /// <param name="result">Returns a bit mask of the active pins on the port.</param>
        /// <returns>True on success.</returns>
        public static bool GetPortInputs(GpioPort port, out GpioPin result)
        {
            result = 0;
            GpioPortStructure gpioPortStructure = new GpioPortStructure();
            gpioPortStructure.port = (UInt32)port;

            if (NativeMethods.DeviceIoControl(driverHandle, IOCTL_GPIO_GET_INPUT, ref gpioPortStructure, Marshal.SizeOf(typeof(GpioPortStructure)), IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                return false;

            result = (GpioPin)gpioPortStructure.value;

            return true;
        }

        /// <summary>
        /// Configures a pin on the processor.
        /// </summary>
        /// <param name="port">The port on the processor that the pin belongs to.</param>
        /// <param name="pinNumber">The zero based pin number on the port.</param>
        /// <param name="output">True for an output, false for an input.</param>
        /// <param name="openCollector">True for an open collector output, false for a logic output or an input.</param>
        /// <param name="pullUpEnabled">True to enable the internal pull-up resistor.</param>
        /// <returns>True on success.</returns>
        public static bool ConfigurePin(GpioPort port, int pinNumber, bool output, bool openCollector, bool pullUpEnabled)
        {
            GpioConfigureStructure gpioConfigureStructure = new GpioConfigureStructure();
            gpioConfigureStructure.port = (UInt32)port;
            gpioConfigureStructure.pin = (UInt32)pinNumber;
            if (pullUpEnabled)
                gpioConfigureStructure.pullUpEnable = 1;
            else
                gpioConfigureStructure.pullUpEnable = 0;
            if (output)
                gpioConfigureStructure.outputEnable = 1;
            else
                gpioConfigureStructure.outputEnable = 0;
            if (openCollector)
                gpioConfigureStructure.multiDriveEnable = 1;
            else
                gpioConfigureStructure.multiDriveEnable = 0;
            gpioConfigureStructure.peripheralSelect = 0;
            gpioConfigureStructure.pioEnable = 1;

            if (NativeMethods.DeviceIoControl(driverHandle, IOCTL_GPIO_CONFIGURE_PIN, ref gpioConfigureStructure, Marshal.SizeOf(typeof(GpioConfigureStructure)), IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                return false;

            return true;
        }
    }
}
