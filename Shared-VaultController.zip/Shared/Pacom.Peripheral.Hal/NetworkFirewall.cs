﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// Network firewall agent.
    /// </summary>
    public class NetworkFirewall : IDisposable
    {
        private static NetworkFirewall instance = null;

        public static NetworkFirewall CreateInstance()
        {
            if (instance == null)
                instance = new NetworkFirewall();
            return instance;
        }

        public static NetworkFirewall Instance
        {
            get
            {
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                    {
                        return "NetworkFirewall instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
                return instance;
            }
        }

        private NetworkFirewall()
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.NetworkAdapter, () =>
            {
                return "Network firewall agent is started.";
            });
            try
            {
                firewallEnabled = NativeFirewallApi.IsFirewallEnabled(InternetworkType.AF_INET);
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                {
                    return string.Format("Error while checking firewall service. {0}", ex.Message);
                });
                firewallEnabled = false;
            }
            if (firewallEnabled == false)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                {
                    return "Network firewall is DISABLED.";
                });
            }

            Instance_ConfigurationChanged(this, new EventArgs());

            if (ConfigurationManager.Instance != null)
                ConfigurationManager.Instance.ConfigurationChanged += new EventHandler<EventArgs>(Instance_ConfigurationChanged);
        }

        private void Instance_ConfigurationChanged(object sender, EventArgs e)
        {
            if (firewallEnabled == false)
                return;

            string services = string.Empty;

            // Web server
            if (ConfigurationManager.Instance.WebServerEnabled)
            {
                int webServerPort = ConfigurationManager.Instance.WebServerPort;
                establishInboundRule(FirewallRuleSourceType.WebServer, webServerPort, true, false);
                services = (services == string.Empty) ? string.Format("Web Server({0})", webServerPort) : string.Format("{0}, Web Server({1})", services, webServerPort);
            }
            else
            {
                releaseRule(FirewallRuleSourceType.WebServer);
            }

            // Device loop
            if (ConfigurationManager.Instance.ConnectionTcp != null &&
                ConfigurationManager.Instance.ConnectionTcp.ConnectionRequired == true)
            {
                int deviceLoopPort = ConfigurationManager.Instance.ConnectionTcp.Port;
                establishInboundRule(FirewallRuleSourceType.DeviceLoop, deviceLoopPort, false, true); // UDP in
                services = (services == string.Empty) ? string.Format("Onboard Ethernet({0})", deviceLoopPort) : string.Format("{0}, Onboard Ethernet({1})", services, deviceLoopPort);
            }
            else
            {
                releaseRule(FirewallRuleSourceType.DeviceLoop);
            }

            if (services != string.Empty)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                {
                    return string.Format("Setting firewall rule for {0}.", services);
                });
            }
        }

        private readonly bool firewallEnabled = false;
        private SortedList<FirewallRuleSourceType, ushort> firewallRules = new SortedList<FirewallRuleSourceType, ushort>();
        private readonly object firewallLock = new object();

        /// <summary>
        /// Add firewall rule for specified port and source.
        /// </summary>
        private bool establishInboundRule(FirewallRuleSourceType source, int port, bool tcpIn, bool udpIn)
        {
            if (firewallEnabled == false)
                return true;
            try
            {
                if (port < ushort.MinValue || port > ushort.MaxValue)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                    {
                        return string.Format("Attempt to establish firewall rule for invalid port {0}.", port);
                    });
                    return false;
                }
                ushort shortPort = Convert.ToUInt16(port);
                ushort existingPort = 0;

                lock (firewallLock)
                {
                    if (firewallRules.TryGetValue(source, out existingPort) == true)
                        releaseRule(source);

                    bool finalResult = true;
                    string ruleTCPInboundDescription = string.Format("{0} TCP Inbound", source.ToString());
                    string ruleUDPInboundDescription = string.Format("{0} UDP Inbound", source.ToString());
                    try
                    {
                        try
                        {
                            do
                            {
                                if (tcpIn)
                                {
                                    FirewallResultType ruleAddResult = NativeFirewallApi.AddFirewallRule(ruleTCPInboundDescription, shortPort, NativeProtocolType.TCP, RuleDirectionType.FWF_INBOUND);
                                    if (ruleAddResult != FirewallResultType.ERROR_SUCCESS)
                                    {
                                        Logger.LogDebugMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                                                                                                   {
                                                                                                       return string.Format("Error while adding inbound TCP firewall rule for {0} and port {1}.", source.ToString(), port);
                                                                                                   });
                                        finalResult = false;
                                        break;
                                    }
                                }
                                if (udpIn)
                                {
                                    FirewallResultType ruleAddResult = NativeFirewallApi.AddFirewallRule(ruleUDPInboundDescription, shortPort, NativeProtocolType.UDP, RuleDirectionType.FWF_INBOUND);
                                    if (ruleAddResult != FirewallResultType.ERROR_SUCCESS)
                                    {
                                        Logger.LogDebugMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                                                                                                   {
                                                                                                       return string.Format("Error while adding inbound UDP firewall rule for {0} and port {1}.", source.ToString(), port);
                                                                                                   });
                                        finalResult = false;
                                        break;
                                    }
                                }
                            } while (false);
                        }
                        catch
                        {
                            finalResult = false;
                        }
                    }
                    finally
                    {
                        if (finalResult == true)
                        {
                            firewallRules.Add(source, shortPort);
                        }
                    }

                    if (finalResult == false)
                    {
                        try
                        {
                            NativeFirewallApi.DeleteFirewallRule(ruleTCPInboundDescription);
                        }
                        catch
                        {
                        }
                        try
                        {
                            NativeFirewallApi.DeleteFirewallRule(ruleUDPInboundDescription);
                        }
                        catch
                        {
                        }
                    }
                    return finalResult;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                {
                    return string.Format("Error while establishing firewall rule. {0}", ex.Message);
                });
                return false;
            }
        }

        /// <summary>
        /// Remove firewall rule for specified source.
        /// </summary>
        /// <param name="source"></param>
        private void releaseRule(FirewallRuleSourceType source)
        {
            if (firewallEnabled == false)
                return;
            try
            {
                ushort port = 0;
                lock (firewallLock)
                {
                    if (firewallRules.TryGetValue(source, out port) == true)
                    {
                        string ruleTCPInboundDescription = string.Format("{0} TCP Inbound", source.ToString());
                        string ruleUDPInboundDescription = string.Format("{0} UDP Inbound", source.ToString());

                        // Remove the port if not used by other source
                        try
                        {
                            NativeFirewallApi.DeleteFirewallRule(ruleTCPInboundDescription);
                        }
                        catch
                        {
                        }
                        try
                        {
                            NativeFirewallApi.DeleteFirewallRule(ruleUDPInboundDescription);
                        }
                        catch
                        {
                        }

                        // Remove the source
                        firewallRules.Remove(source);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                {
                    return string.Format("Error while releasing firewall rule. {0}", ex.Message);
                });
            }
        }

        private void releaseAll()
        {
            lock (firewallLock)
            {
                while (firewallRules.Count > 0)
                {
                    releaseRule(firewallRules.Keys[0]);
                }
            }
        }

        #region IDisposable Members

        bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.
                if (ConfigurationManager.Instance != null)
                    ConfigurationManager.Instance.ConfigurationChanged -= new EventHandler<EventArgs>(Instance_ConfigurationChanged);
                releaseAll();
                instance = null;
                Logger.LogDebugMessage(LoggerClassPrefixes.NetworkAdapter, () =>
                {
                    return string.Format("Network firewall agent is disposed.");
                });
            }

            // Free any unmanaged objects here.            
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
