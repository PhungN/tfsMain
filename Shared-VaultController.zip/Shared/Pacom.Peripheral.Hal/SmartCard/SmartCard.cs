﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Hal.SmartCard
{
    public class SmartCard
    {
        public SmartCardError Connect(IntPtr hContext, string szReader, SmartCardShareMode dwShareMode, SmartCardProtocol dwPreferredProtocols, out IntPtr phCard, out SmartCardProtocol pdwActiveProtocol)
        {
            int activeproto;
            var result = SmartCardApi.Connect(hContext, szReader, (int)dwShareMode, (int)dwPreferredProtocols, out phCard, out activeproto);
            pdwActiveProtocol = (SmartCardProtocol)activeproto;
            return (SmartCardError)result;
        }

        public SmartCardError Disconnect(IntPtr hCard, SmartCardReaderDisposition dwDisposition)
        {
            return (SmartCardError)SmartCardApi.Disconnect(hCard, (int)dwDisposition);
        }

        public SmartCardError EstablishContext(SmartCardScope dwScope, IntPtr pvReserved1, IntPtr pvReserved2, out IntPtr phContext)
        {
            var ctx = IntPtr.Zero;
            var rc = (SmartCardError)SmartCardApi.EstablishContext((int)dwScope, pvReserved1, pvReserved2, ref ctx);
            phContext = ctx;
            return rc;
        }

        public SmartCardError ReleaseContext(IntPtr hContext)
        {
            return (SmartCardError)SmartCardApi.ReleaseContext(hContext);
        }

        public SmartCardError GetReaderName(IntPtr hContext, ref string readerName)
        {
            int size = 0;
            var retVal = (SmartCardError)SmartCardApi.ListReaders(hContext, null, null, ref size);
            if (retVal == SmartCardError.Success)
            {
                string readerList = new string('\0', size);
                if ((retVal = (SmartCardError)SmartCardApi.ListReaders(hContext, null, readerList, ref size)) == SmartCardError.Success)
                    readerName = readerList.Trim('\0');
            }
            return retVal;
        }

        public SmartCardError Transmit(IntPtr hCard, IntPtr pioSendPci, byte[] pbSendBuffer, IntPtr pioRecvPci, byte[] pbRecvBuffer, out int pcbRecvLength)
        {
            pcbRecvLength = 0;
            if (pbRecvBuffer != null)
                pcbRecvLength = pbRecvBuffer.Length;
            var pcbSendLength = 0;
            if (pbSendBuffer != null)
                pcbSendLength = pbSendBuffer.Length;
            var recvlen = 0;
            if (pbRecvBuffer != null)
                recvlen = pcbRecvLength;
            var sendbuflen = 0;
            if (pbSendBuffer != null)
                sendbuflen = pcbSendLength;
            var rc = (SmartCardError)(SmartCardApi.Transmit(hCard, pioSendPci, pbSendBuffer, sendbuflen, pioRecvPci, pbRecvBuffer, ref recvlen));
            if (rc == SmartCardError.Success)
                pcbRecvLength = recvlen;
            else
                pcbRecvLength = 0;
            return rc;
        }
       
    }
}
