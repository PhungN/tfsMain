﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal.SmartCard
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct SCARD_READERSTATE
    {
        [MarshalAs(UnmanagedType.LPTStr)]
        public string szReader;
        public IntPtr pvUserData;
        public int dwCurrentState;
        public int dwEventState;
        public int cbAtr;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 36)]
        public byte[] rgbAtr;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct SCARD_IO_REQUEST
    {
        public int dwProtocol;      // SCARD_PROTOCOL_T0 or SCARD_PROTOCOL_T1
        public int cbPciLength;     // Length of this structure - not used
    }
}
