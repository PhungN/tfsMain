﻿using System.ComponentModel;

namespace Pacom.Peripheral.Hal.SmartCard
{
    public enum SmartCardShareMode
    {
        Exclusive = 0x0001, // SCARD_SHARE_EXCLUSIVE
        Shared = 0x0002,    // SCARD_SHARE_SHARED
        Direct = 0x0003     // SCARD_SHARE_DIRECT
    }
}
