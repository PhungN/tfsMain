﻿using System.ComponentModel;

namespace Pacom.Peripheral.Hal.SmartCard
{
    public enum SmartCardReaderDisposition
    {

        Leave = 0x0000,     // SCARD_LEAVE_CARD
        Reset = 0x0001,     // SCARD_RESET_CARD
        Unpower = 0x0002,   // SCARD_UNPOWER_CARD
        Eject = 0x0003      // SCARD_EJECT_CARD
    }
}
