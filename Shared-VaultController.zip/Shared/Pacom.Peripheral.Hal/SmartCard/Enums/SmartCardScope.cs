﻿using System.ComponentModel;

namespace Pacom.Peripheral.Hal.SmartCard
{
    public enum SmartCardScope
    {
        /// <summary>Scope in user space.</summary>
        User = 0x0000,      // Scope in user space
        /// <summary>Scope in terminal.</summary>
        Terminal = 0x0001, // 
        /// <summary>Scope in system. Service on the local machine.</summary>
        System = 0x0002,

        /** PC/SC Lite specific extensions */
        /// <summary>Scope is global. </summary>
        Global = 0x0003
    }
}
