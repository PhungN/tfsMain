﻿using System;

namespace Pacom.Peripheral.Hal.SmartCard
{
    [Flags]
    public enum SmartCardProtocol
    {
        Unset = 0x0000,     // Protocol not defined.
        T0 = 0x0001,        // T=0 active protocol
        T1 = 0x0002,        // T=1 active protocol
        Raw = 0x0004,       // Raw active protocol. Use with memory type cards
        T15 = 0x0008,       // T=15 protocol
        Any = (T0 | T1)     // IFD (Interface device) determines protocol
    }
}
