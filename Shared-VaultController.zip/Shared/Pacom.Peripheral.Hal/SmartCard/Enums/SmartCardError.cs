﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Pacom.Peripheral.Hal.SmartCard
{
    /// <summary>Error and return codes.</summary>
    [Flags]
    public enum SmartCardError
    {
        /// <summary>No error. (SCARD_S_SUCCESS)</summary>
        Success = 0x00000000,
        /// <summary>An internal consistency check failed. (SCARD_F_INTERNAL_ERROR)</summary>
        InternalError = unchecked((int)0x80100001),

        /// <summary>The action was cancelled by an <see cref="ISCardContext.Cancel()" /> request. (SCARD_E_CANCELLED)</summary>
        Cancelled = unchecked((int)0x80100002),
        /// <summary>The supplied handle was invalid. (SCARD_E_INVALID_HANDLE)</summary>
        InvalidHandle = unchecked((int)0x80100003),
        /// <summary>The supplied handle was invalid. (ERROR_INVALID_HANDLE)</summary>
        InvalidHandleWindows = 6,
        /// <summary>One or more of the supplied parameters could not be properly interpreted. (SCARD_E_INVALID_PARAMETER)</summary>
        InvalidParameter = unchecked((int)0x80100004),
        /// <summary>Registry startup information is missing or invalid. (SCARD_E_INVALID_TARGET)</summary>
        InvalidTarget = unchecked((int)0x80100005),
        /// <summary>Not enough memory available to complete this command. (SCARD_E_NO_MEMORY)</summary>
        NoMemory = unchecked((int)0x80100006),
        /// <summary>An internal consistency timer has expired. (SCARD_F_WAITED_TOO_LONG)</summary>
        WaitedTooLong = unchecked((int)0x80100007),
        /// <summary>The data buffer to receive returned data is too small for the returned data. (SCARD_E_INSUFFICIENT_BUFFER)</summary>
        InsufficientBuffer = unchecked((int)0x80100008),
        /// <summary>Windows error ERROR_INSUFFICIENT_BUFFER: The data area passed to a system call is too small.</summary>
        WinErrorInsufficientBuffer = 122,
        /// <summary>The specified reader name is not recognized. (SCARD_E_UNKNOWN_READER)</summary>
        UnknownReader = unchecked((int)0x80100009),
        /// <summary>The user-specified timeout value has expired. (SCARD_E_TIMEOUT)</summary>
        Timeout = unchecked((int)0x8010000A),
        /// <summary>The smart card cannot be accessed because of other connections outstanding. (SCARD_E_SHARING_VIOLATION)</summary>
        SharingViolation = unchecked((int)0x8010000B),
        /// <summary>The operation requires a Smart Card, but no Smart Card is currently in the device. (SCARD_E_NO_SMARTCARD)</summary>
        NoSmartcard = unchecked((int)0x8010000C),
        /// <summary>The specified smart card name is not recognized. (SCARD_E_UNKNOWN_CARD)</summary>
        UnknownCard = unchecked((int)0x8010000D),

        /// <summary>The system could not dispose of the media in the requested manner. (SCARD_E_CANT_DISPOSE)</summary>
        CannotDispose = unchecked((int)0x8010000E),
        /// <summary>The requested protocols are incompatible with the protocol currently in use with the smart card. (SCARD_E_PROTO_MISMATCH)</summary>
        ProtocolMismatch = unchecked((int)0x8010000F),
        /// <summary>The reader or smart card is not ready to accept commands. (SCARD_E_NOT_READY)</summary>
        NotReady = unchecked((int)0x80100010),
        /// <summary>One or more of the supplied parameters values could not be properly interpreted. (SCARD_E_INVALID_VALUE)</summary>
        InvalidValue = unchecked((int)0x80100011),
        /// <summary>The action was cancelled by the system, presumably to log off or shut down. (SCARD_E_SYSTEM_CANCELLED)</summary>
        SystemCancelled = unchecked((int)0x80100012),
        /// <summary>An internal communications error has been detected. (SCARD_F_COMM_ERROR)</summary>
        CommunicationError = unchecked((int)0x80100013),
        /// <summary>An internal error has been detected, but the source is unknown. (SCARD_F_UNKNOWN_ERROR)</summary>
        UnknownError = unchecked((int)0x80100014),
        /// <summary>An ATR obtained from the registry is not a valid ATR string. (SCARD_E_INVALID_ATR)</summary>
        InvalidAtr = unchecked((int)0x80100015),
        /// <summary>An attempt was made to end a non-existent transaction. (SCARD_E_NOT_TRANSACTED)</summary>
        NotTransacted = unchecked((int)0x80100016),
        /// <summary>The specified reader is not currently available for use. (SCARD_E_READER_UNAVAILABLE)</summary>
        ReaderUnavailable = unchecked((int)0x80100017),
        /// <summary>The operation has been aborted to allow the server application to exit. (SCARD_P_SHUTDOWN)</summary>
        Shutdown = unchecked((int)0x80100018),
        /// <summary>The reader cannot communicate with the card, due to ATR string configuration conflicts. (SCARD_W_UNSUPPORTED_CARD)</summary>
        UnsupportedCard = unchecked((int)0x80100065),
        /// <summary>The smart card is not responding to a reset. (SCARD_W_UNRESPONSIVE_CARD)</summary>
        UnresponsiveCard = unchecked((int)0x80100066),
        /// <summary>Power has been removed from the smart card, so that further communication is not possible. (SCARD_W_UNPOWERED_CARD)</summary>
        UnpoweredCard = unchecked((int)0x80100067),
        /// <summary>The smart card has been reset, so any shared state information is invalid. (SCARD_W_RESET_CARD)</summary>
        ResetCard = unchecked((int)0x80100068),
        /// <summary>The smart card has been removed, so further communication is not possible. (SCARD_W_REMOVED_CARD)</summary>
        RemovedCard = unchecked((int)0x80100069),
        /// <summary>The PCI Receive buffer was too small. (SCARD_E_PCI_TOO_SMALL)</summary>
        PciTooSmall = unchecked((int)0x80100019),
        /// <summary>The reader driver does not meet minimal requirements for support. (SCARD_E_READER_UNSUPPORTED)</summary>
        ReaderUnsupported = unchecked((int)0x8010001A),

        /// <summary>The reader driver did not produce a unique reader name. (SCARD_E_DUPLICATE_READER)</summary>
        DuplicateReader = unchecked((int)0x8010001B),
        /// <summary>The smart card does not meet minimal requirements for support. (SCARD_E_CARD_UNSUPPORTED)</summary>
        CardUnsupported = unchecked((int)0x8010001C),
        /// <summary>The Smart card resource manager is not running. (SCARD_E_NO_SERVICE)</summary>
        NoService = unchecked((int)0x8010001D),
        /// <summary>The Smart card resource manager has shut down. (SCARD_E_SERVICE_STOPPED)</summary>
        ServiceStopped = unchecked((int)0x8010001E),
        /// <summary>An unexpected card error has occurred. (SCARD_E_UNEXPECTED)</summary>
        Unexpected = unchecked((int)0x8010001F),
        /// <summary>Cannot find a smart card reader. (SCARD_E_NO_READERS_AVAILABLE)</summary>
        NoReadersAvailable = unchecked((int)0x8010002E),

        /** PC/SC Lite specific extensions */
        /// <summary>The smart card has been inserted. (Obsolete)</summary>
        [Obsolete("PC/SC Lite specific, value conflicts with SCardError.SecurityViolation")]
        InsertedCard = unchecked((int)0x8010006A),
        /// <summary>Feature not supported. (SCARD_E_UNSUPPORTED_FEATURE)</summary>
        UnsupportedFeature = unchecked((int)0x8010001F),

        /// <summary>No primary provider can be found for the smart card. (SCARD_E_ICC_INSTALLATION)</summary>
        ICCInstallation = unchecked((int)0x80100020),

        /// <summary>The requested order of object creation is not supported. (SCARD_E_ICC_CREATEORDER)</summary>
        ICCCreateOrder = unchecked((int)0x80100021),

        /// <summary>The identified directory does not exist in the smart card. (SCARD_E_DIR_NOT_FOUND)</summary>
        DirectoryNotFound = unchecked((int)0x80100023),

        /// <summary>The identified file does not exist in the smart card. (SCARD_E_FILE_NOT_FOUND)</summary>
        FileNotFound = unchecked((int)0x80100024),
        /// <summary>The supplied path does not represent a smart card directory. (SCARD_E_NO_DIR)</summary>
        NoDir = unchecked((int)0x80100025),
        /// <summary>The supplied path does not represent a smart card file. (SCARD_E_NO_FILE)</summary>
        NoFile = unchecked((int)0x80100026),
        /// <summary>Access is denied to this file. (SCARD_E_NO_ACCESS)</summary>
        NoAccess = unchecked((int)0x80100027),
        /// <summary>The smart card does not have enough memory to store the information. (SCARD_E_WRITE_TOO_MANY)</summary>
        WriteTooMany = unchecked((int)0x80100028),

        /// <summary>There was an error trying to set the smart card file object pointer. (SCARD_E_BAD_SEEK)</summary>
        BadSeek = unchecked((int)0x80100029),

        /// <summary>The supplied PIN is incorrect. (SCARD_E_INVALID_CHV)</summary>
        InvalidCHV = unchecked((int)0x8010002A),
        /// <summary>An unrecognized error code was returned from a layered component. (SCARD_E_UNKNOWN_RES_MNG)</summary>
        UnknownResMng = unchecked((int)0x8010002B),
        /// <summary>The requested certificate does not exist. (SCARD_E_NO_SUCH_CERTIFICATE)</summary>
        NoSuchCertificate = unchecked((int)0x8010002C),
        /// <summary>The requested certificate could not be obtained. (SCARD_E_CERTIFICATE_UNAVAILABLE)</summary>
        CertificateUnavailable = unchecked((int)0x8010002D),
        /// <summary>A communications error with the smart card has been detected. (SCARD_E_COMM_DATA_LOST)</summary>
        CommunicationDataLost = unchecked((int)0x8010002F),
        /// <summary>The requested key container does not exist on the smart card. (SCARD_E_NO_KEY_CONTAINER)</summary>
        NoKeyContainer = unchecked((int)0x80100030),
        /// <summary>The Smart Card Resource Manager is too busy to complete this operation. (SCARD_E_SERVER_TOO_BUSY)</summary>
        ServerTooBusy = unchecked((int)0x80100031),
        /// <summary>Access was denied because of a security violation. (SCARD_W_SECURITY_VIOLATION)</summary>
        SecurityViolation = unchecked((int)0x8010006A),
        /// <summary>The card cannot be accessed because the wrong PIN was presented. (SCARD_W_WRONG_CHV)</summary>
        WrongCHV = unchecked((int)0x8010006B),
        /// <summary>The card cannot be accessed because the maximum number of PIN entry attempts has been reached. (SCARD_W_CHV_BLOCKED)</summary>
        CHVBlocked = unchecked((int)0x8010006C),

        /// <summary>The end of the smart card file has been reached. (SCARD_W_EOF)</summary>
        Eof = unchecked((int)0x8010006D),

        /// <summary>The user pressed "Cancel" on a Smart Card Selection Dialog. (SCARD_W_CANCELLED_BY_USER)</summary>
        CancelledByUser = unchecked((int)0x8010006E),

        /// <summary>No PIN was presented to the smart card. (SCARD_W_CARD_NOT_AUTHENTICATED)</summary>
        CardNotAuthenticated = unchecked((int)0x8010006F),
    }
}
