﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal.SmartCard
{
    public static class SmartCardApi
    {
        private const string WINSCARD_DLL = "winscard.dll";

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardEstablishContext")]
        public static extern int EstablishContext(int dwScope, IntPtr pvReserved1, IntPtr pvReserved2, ref IntPtr phContext);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardReleaseContext")]
        public static extern int ReleaseContext(IntPtr hContext);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardIsValidContext")]
        public static extern int IsValidContext(IntPtr hContext);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardListReaders")]
        static internal extern uint ListReaders(IntPtr hContext, string groups, string readers, ref int size);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Unicode, EntryPoint = "SCardListReadersW")]
        public static extern int ListReadersW(IntPtr hContext, char[] mszGroups, char[] pmszReaders, ref int pcchReaders);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardListReaderGroups")]
        public static extern int ListReaderGroups(IntPtr hContext, byte[] mszGroups, ref int pcchGroups);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardConnect")]
        public static extern int Connect(IntPtr hContext, string szReaderName, int dwShareMode, int dwPreferredProtocols, out IntPtr phCard, out int pdwActiveProtocol);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardReconnect")]
        public static extern int Reconnect(IntPtr hCard, int dwShareMode, int dwPreferredProtocols, int dwInitialization, out int pdwActiveProtocol);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardDisconnect")]
        public static extern int Disconnect(IntPtr hCard, int dwDisposition);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardBeginTransaction")]
        public static extern int BeginTransaction(IntPtr hCard);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardEndTransaction")]
        public static extern int EndTransaction(IntPtr hCard, int dwDisposition);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardTransmit")]
        public static extern int Transmit(IntPtr hCard, IntPtr pioSendPci, byte[] pbSendBuffer, int cbSendLength, IntPtr pioRecvPci, byte[] pbRecvBuffer, ref int pcbRecvLength);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardControl")]
        public static extern int Control(IntPtr hCard, int dwControlCode, byte[] lpInBuffer, int nInBufferSize, byte[] lpOutBuffer, int nOutBufferSize, out int lpBytesReturned);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardStatus")]
        public static extern int Status(IntPtr hCard, byte[] szReaderName, ref int pcchReaderLen, out int pdwState, out int pdwProtocol, byte[] pbAtr, ref int pcbAtrLen);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardGetStatusChange")]
        public static extern int GetStatusChange(IntPtr hContext, int dwTimeout, [MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 3)] SCARD_READERSTATE[] rgReaderStates, int cReaders);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardCancel")]
        public static extern int Cancel(IntPtr hContext);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardGetAttrib")]
        public static extern int GetAttrib(IntPtr hCard, int dwAttrId, [MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 3)] byte[] pbAttr, ref int pcbAttrLen);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardSetAttrib")]
        public static extern int SetAttrib(IntPtr hCard, int dwAttrId, [MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 3)] byte[] pbAttr, int cbAttrLen);

        [DllImport(WINSCARD_DLL, CharSet = CharSet.Auto, EntryPoint = "SCardFreeMemory")]
        public static extern int FreeMemory(IntPtr hContext, IntPtr pvMem);
    }
}
