﻿using System;
using System.Runtime.InteropServices;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class provides access to the boards I2C bus.
    /// </summary>
    public static class I2c
    {
        static IntPtr driverHandle = initialize();

        private static IntPtr initialize()
        {
            IntPtr handle = NativeMethods.CreateFile("I2C1:", FileAccess.GenericRead | FileAccess.GenericWrite, FileShare.Read | FileShare.Write, IntPtr.Zero, CreationDisposition.OpenExisting, FileAttribute.Normal, IntPtr.Zero);
            if (handle.ToInt32() == Constants.InvalidHandleValue)
            {
                StatusLed.AddStatus(SystemStatus.HardwareError);
                Logger.LogCriticalMessage(LoggerClassPrefixes.I2cBus, () =>
                {
                    return "I2C driver (I2C1:) failed to open!";
                });
            }
            return handle;
        }

        /// <summary>
        /// Performs an I2C read operation.
        /// </summary>
        /// <param name="deviceAddress">The 7-bit I2C device address.</param>
        /// <param name="registerAddress">The register address if present.</param>
        /// <param name="registerAddressLength">The length of the register address in bytes.</param>
        /// <param name="dataOut">Returns the read data.</param>
        /// <returns>True on success.</returns>
        public static bool ReadFromDevice(UInt32 deviceAddress, UInt32 registerAddress, UInt32 registerAddressLength, byte[] dataOut)
        {
            int returnedSize;

            I2cReadStructure readStructure = new I2cReadStructure();
            readStructure.deviceAddress = deviceAddress;
            readStructure.registerAddress = registerAddress;
            readStructure.registerAddressLength = registerAddressLength;

            if (NativeMethods.DeviceIoControl(driverHandle, 0x56000, ref readStructure, Marshal.SizeOf(typeof(I2cReadStructure)), dataOut, dataOut.Length, out returnedSize, IntPtr.Zero) == 0)
                return false;

            Logger.LogTracedCommsMessage(LoggerClassPrefixes.I2cBus, DebugLoggingSubCategory.I2cData, () =>
            {
                if (registerAddressLength == 0)
                    return string.Format("Read on I2C device address:{0} data:{1}", deviceAddress, BitConverter.ToString(dataOut));
                else
                    return string.Format("Read on I2C device address:{0} register address:{1} data:{2}", deviceAddress, registerAddress, BitConverter.ToString(dataOut));
            });
            return true;
        }

        /// <summary>
        /// Performs an I2C write operation.
        /// </summary>
        /// <param name="deviceAddress">The 7-bit I2C device address.</param>
        /// <param name="registerAddress">The register address if present.</param>
        /// <param name="registerAddressLength">The length of the register address in bytes.</param>
        /// <param name="data">The data to write on the bus.</param>
        /// <returns>True on success.</returns>
        public static bool WriteToDevice(UInt32 deviceAddress, UInt32 registerAddress, UInt32 registerAddressLength, byte[] data)
        {
            GCHandle dataHandle = GCHandle.Alloc(data, GCHandleType.Pinned);
            try
            {
                I2cWriteStructure writeStructure = new I2cWriteStructure();
                writeStructure.deviceAddress = deviceAddress;
                writeStructure.registerAddress = registerAddress;
                writeStructure.registerAddressLength = registerAddressLength;
                writeStructure.bufferSize = (UInt32)data.Length;
                writeStructure.bufferAddress = dataHandle.AddrOfPinnedObject();

                Logger.LogTracedCommsMessage(LoggerClassPrefixes.I2cBus, DebugLoggingSubCategory.I2cData, () =>
                {
                    if (registerAddressLength == 0)
                        return string.Format("Wrote on I2C device address:{0} data:{1}", deviceAddress, BitConverter.ToString(data));
                    else
                        return string.Format("Wrote on I2C device address:{0} register address:{1} data:{2}", deviceAddress, registerAddress, BitConverter.ToString(data));
                });

                if (NativeMethods.DeviceIoControl(driverHandle, 0x5A004, ref writeStructure, Marshal.SizeOf(typeof(I2cWriteStructure)), IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                    return false;

                return true;
            }
            finally
            {
                dataHandle.Free();
            }
        }

        /// <summary>
        /// Sets the I2C bus speed to approximately 200KHz. This speed should be used once the expansion cards are initialized.
        /// </summary>
        /// <returns>True on success.</returns>
        public static bool EnableHighSpeedCommunications()
        {
            if (NativeMethods.DeviceIoControl(driverHandle, 0x5A008, IntPtr.Zero, 0, IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                return false;

            return true;
        }

        /// <summary>
        /// Sets the I2C bus speed to approximately 25KHz. This speed should only be used during initialization as the expansion cards
        /// do not support a higher speed during firmware updates.
        /// </summary>
        /// <returns>True on success.</returns>
        public static bool EnableLowSpeedCommunications()
        {
            if (NativeMethods.DeviceIoControl(driverHandle, 0x5A014, IntPtr.Zero, 0, IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                return false;

            return true;
        }
    }
}
