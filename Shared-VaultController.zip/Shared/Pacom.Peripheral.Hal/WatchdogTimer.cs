﻿using System;
using System.Runtime.InteropServices;
using System.Threading;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class provides access to the external watchdog timer.
    /// </summary>
    public class WatchdogTimer : IDisposable
    {
        /// <summary>Defined IOCTLs for WDT driver</summary>
        private const int IOCTL_WDT_SWITCH_TO_MANAGED_WATCHDOG = 0x222000;
        private const int IOCTL_WDT_READ_RST_LEVEL = 0x222008;
        private const int IOCTL_WDT_DISABLE_USER_RESET = 0x22200C;
        private const int IOCTL_WDT_ENABLE_USER_RESET = 0x222010;
        private const int IOCTL_WDT_READ_RST_TYPE = 0x222014;

        public delegate void ToggleActionDelegate();
                
        private ManualResetEvent watchdogThreadRunning = null;
        private ManualResetEvent applicationTakingControl = null;

        private Thread timerThread = null;
        private IntPtr driverHandle = IntPtr.Zero;

        /// <summary>
        /// Triggered every 500ms to indicate that it is time to kick the watchdog timer.
        /// </summary>
        private ToggleActionDelegate toggleAction;

#if DEBUG
        private static TimeLimit timeOfLastToggle = new TimeLimit();
#endif

        private static WatchdogTimer instance = null;
               
        public static WatchdogTimer CreateInstance(WatchdogType type)
        {
            if (instance == null)
                instance = new WatchdogTimer(type);
            return instance;
        }

        public static WatchdogTimer Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                    instanceMustBeCreated();
#endif
                return instance;
            }
        }
        
        private static void instanceMustBeCreated()
        {
            Logger.LogErrorMessage(LoggerClassPrefixes.WatchdogTimer, () =>
            {
                return "Instance must be created before usage. Call CreateInstance() method before using this property.";
            });
        }

        private readonly WatchdogType watchdogType;

        private WatchdogTimer(WatchdogType type)
        {
            watchdogType = type;

            watchdogThreadRunning = new ManualResetEvent(false);
            applicationTakingControl = new ManualResetEvent(false);
            
            driverHandle = initialize();

            if (type == WatchdogType.Managed)
            {
                timerThread = new Thread(new ThreadStart(timerThreadMethod));
                timerThread.Name = "WDT Timer Thread";
                timerThread.IsBackground = true;
                timerThread.Priority = ThreadPriority.Highest;
                timerThread.Start();

                Logger.LogDebugMessage(LoggerClassPrefixes.WatchdogTimer, () =>
                {
                    return "Waiting for Watchdog Timer Thread to start.";
                });
                watchdogThreadRunning.WaitOne();
            }           
        }

        private IntPtr initialize()
        {
            IntPtr result;
            result = NativeMethods.CreateFile("WDT1:", FileAccess.GenericRead | FileAccess.GenericWrite, FileShare.Read | FileShare.Write, IntPtr.Zero, CreationDisposition.OpenExisting, FileAttribute.Normal, IntPtr.Zero);
            if (result.ToInt32() == Constants.InvalidHandleValue)
            {
                StatusLed.AddStatus(SystemStatus.HardwareError);
                Logger.LogCriticalMessage(LoggerClassPrefixes.WatchdogTimer, () =>
                {
                    return "Driver (WDT1:) failed to open!";
                });
                return IntPtr.Zero;
            }
            return result;
        }
        
        // Generate square wave for WD.
        private bool watchdogHigh = true;

        /// <summary>
        /// Kicks the watchdog timer.
        /// </summary>
        /// <returns>True on success.</returns>
        public bool ToggleInput()
        {
            long memory = GC.GetTotalMemory(false);
            if (watchdogHigh)
            {
                Hal.Gpio.ClearOutput(GpioPort.PortC, 11);
                watchdogHigh = false;
            }
            else
            {
                Hal.Gpio.SetOutput(GpioPort.PortC, 11);
                watchdogHigh = true;
            }
            return true;
        }

        private void timerThreadMethod()
        {
            try
            {
                // Set the thread priority to very high as a reboot will occur if the watchdog is not serviced.
                if (NativeMethods.CeSetThreadPriority(new IntPtr(Constants.SH_CURTHREAD + Constants.SYS_HANDLE_BASE), 3) == 0)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.WatchdogTimer, () =>
                    {
                        return "Failed on CeSetThreadPriority in WatchdogTimer.timerThreadMethod";
                    });
                }                
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.WatchdogTimer, () =>
                {
                    return "Starting Watchdog Timer Thread.";
                });
#endif
                watchdogThreadRunning.Set();
                applicationTakingControl.WaitOne();
                if (toggleAction != null)
                    toggleAction();

#if DEBUG
                timeOfLastToggle.Reset();
#endif
                while (disposing == false)
                {
                    Thread.Sleep(500);
#if DEBUG
                    uint elapsedTime;
                    if (timeOfLastToggle.IsTimeUp(700, out elapsedTime))
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.WatchdogTimer, () =>
                        {
                            return string.Format("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! Application forgot to trip the WD timer ({0}/1600). !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", elapsedTime);
                        });
                    }

#endif
                    if (toggleAction != null)
                        toggleAction();
#if DEBUG
                    timeOfLastToggle.Reset();
#endif
                }
            }
            catch (ThreadAbortException)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.WatchdogTimer, () =>
                {
                    return "Watchdog Timer Thread Aborted.";
                });
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.WatchdogTimer, () =>
                {
                    return string.Format("Timer Toggle Thread Method Error. {0}", ex.Message);
                });
            }
        }

        /// <summary>
        /// Assign watchdog toggle action method.
        /// </summary>
        /// <param name="toggleAction"></param>
        public void ToggleAction(ToggleActionDelegate toggleAction)
        {
            this.toggleAction = toggleAction;
        }

        /// <summary>
        /// Enable watchdog timer for this application, and disable operating system toggling.
        /// </summary>
        public void EnableWatchdogTimer()
        {
            if (NativeMethods.DeviceIoControl(driverHandle, IOCTL_WDT_SWITCH_TO_MANAGED_WATCHDOG, IntPtr.Zero, 0, IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
            {
                StatusLed.AddStatus(SystemStatus.HardwareError);
                Logger.LogCriticalMessage(LoggerClassPrefixes.WatchdogTimer, () =>
                {
                    return "Failed switching to a managed WDT!";
                });
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.WatchdogTimer, () =>
            {
                return "Watchdog released.";
            });
            if (watchdogType == WatchdogType.Managed)
            {
                applicationTakingControl.Set();
            }
            else
            {
                if (NativeWdtAPI.WdtStart() != Constants.ERROR_SUCCESS)
                {
                    Logger.LogCriticalMessage(LoggerClassPrefixes.WatchdogTimer, () =>
                    {
                        return "Failed starting native watchdog feed!";
                    });
                }
            }
        }

        public bool ReadResetLevel(out bool value)
        {
            int bytesReturned = 0;
            ResetLevelStructure rst = new ResetLevelStructure();

            value = false;
            if (NativeMethods.DeviceIoControl(driverHandle, IOCTL_WDT_READ_RST_LEVEL, IntPtr.Zero, 0, ref rst, Marshal.SizeOf(typeof(ResetLevelStructure)), out bytesReturned, IntPtr.Zero) == 0)
                return false;

            if (rst.ResetLevel == 1)
                value = true;

            return true;
        }

        public bool ReadResetType(out ProcessorResetType resetType)
        {
            int bytesReturned = 0;
            ResetTypeStructure resetTypeStructure = new ResetTypeStructure();

            resetType = ProcessorResetType.Unknown;
            if (NativeMethods.DeviceIoControl(driverHandle, IOCTL_WDT_READ_RST_TYPE, IntPtr.Zero, 0, ref resetTypeStructure, Marshal.SizeOf(typeof(ResetTypeStructure)), out bytesReturned, IntPtr.Zero) == 0)
                return false;

            resetType = (ProcessorResetType)resetTypeStructure.ResetType;

            return true;
        }

        public bool DisableUserReset()
        {
            if (NativeMethods.DeviceIoControl(driverHandle, IOCTL_WDT_DISABLE_USER_RESET, IntPtr.Zero, 0, IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                return false;
            return true;
        }

        public bool EnableUserReset()
        {
            if (NativeMethods.DeviceIoControl(driverHandle, IOCTL_WDT_ENABLE_USER_RESET, IntPtr.Zero, 0, IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                return false;
            return true;
        }

        #region IDisposable Members

        private bool disposed = false;

        private bool disposing = false;

        protected virtual void Dispose(bool disposing)
        {
            try
            {
                if (disposed == false)
                {
                    if (disposing == true)
                    {
                        this.disposing = true;

                        // Stop toggling
                        toggleAction = null;

                        if (watchdogType == WatchdogType.Managed)
                        {
                            try
                            {
                                if (timerThread != null)
                                    timerThread.JoinOrRestart(2000);
                            }
                            catch
                            {
                                timerThread = null;
                            }
                        }
                        else
                        {
                            NativeWdtAPI.WdtStop();
                        }

                        if (applicationTakingControl != null)
                        {
                            applicationTakingControl.Close();
                            applicationTakingControl = null;
                        }

                        if (watchdogThreadRunning != null)
                        {
                            watchdogThreadRunning.Close();
                            watchdogThreadRunning = null;
                        }
           
                        Logger.LogDebugMessage(LoggerClassPrefixes.WatchdogTimer, () =>
                        {
                            return "Watchdog handling thread is stopped.";
                        });
                    }

                    instance = null;

                    disposed = true;
                }
            }
            catch (ThreadAbortException)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.WatchdogTimer, () =>
                {
                    return "Processing thread is aborted.";
                });
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.WatchdogTimer, () =>
                {
                    return ex.ToString();
                });
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
