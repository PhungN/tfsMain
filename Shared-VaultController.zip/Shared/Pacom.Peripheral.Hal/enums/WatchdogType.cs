﻿
namespace Pacom.Peripheral.Hal
{
    public enum WatchdogType
    {
        Managed,
        Native
    }
}
