﻿using System;

namespace Pacom.Peripheral.Hal
{
    [Flags]
    internal enum ExpansionCardStatusByte
    {
        Online = 0,
        StatusLedIsGood = 0x01,
        ConfigValid = 0x02,
        PowerOnSelfTestPass = 0x04,
        InvalidData = 0x08,
        TamperActive = 0x10,
        FuseBlown = 0x20,
        BootloaderReady = 0x40,
        DeviceRestarted = 0x80,
    }
}
