﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Hal
{
    public class PowerSupplyChangedStatusEventArgs : EventArgs
    {
        private readonly PowerSupplyStatus status;

        public PowerSupplyChangedStatusEventArgs(PowerSupplyStatus status)
        {
            this.status = status;
        }

        public PowerSupplyStatus Status
        {
            get { return status; }
        }
    }
}
