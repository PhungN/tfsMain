﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Hal
{
    public class CardReadEventArgs : EventArgs
    {
        private readonly byte[] readCardNumber;
        private readonly int cardLength;
        private readonly int cardReaderNumber;
        private readonly bool collisionOccurred;

        public CardReadEventArgs(byte[] readCardNumber, int cardLength, int cardReaderNumber, bool collisionOccurred)
        {
            this.readCardNumber = readCardNumber;
            this.cardLength = cardLength;
            this.cardReaderNumber = cardReaderNumber;
            this.collisionOccurred = collisionOccurred;
        }

        /// <summary>
        /// A 32 byte representation of the card number that was read by the card reader. The first bit of the card number is stored in the most significant position of byte 0.
        /// 
        /// 26 bit wiegand is stored as follows:
        /// PFFF FFFF  FNNN NNNN  NNNN NNNN  NP00 0000
        /// 7654 3210  7654 3210  7654 3210  7654 3210
        ///   Byte 0     Byte 1     Byte 2     Byte 3
        ///   
        /// Where P = Parity bit
        ///       F = 8-bit facility code
        ///       N = 16-bit card number
        /// </summary>
        public byte[] ReadCardNumber
        {
            get { return readCardNumber; }
        }

        /// <summary>
        /// The actual number of bits read and stored in the ReadCardNumber.
        /// </summary>
        public int CardLength
        {
            get { return cardLength; }
        }

        /// <summary>
        /// The card reader where the card was presented.
        /// </summary>
        public int CardReaderNumber
        {
            get { return cardReaderNumber; }
        }

        /// <summary>
        /// Indicates if 2 cards were presented at the same time on a pair of in / out readers.
        /// If this is true, all other properties should be ignored.
        /// </summary>
        public bool CollisionOccurred
        {
            get { return collisionOccurred; }
        }
    }
}
