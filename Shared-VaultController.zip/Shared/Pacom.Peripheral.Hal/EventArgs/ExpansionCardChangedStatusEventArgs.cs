﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Hal
{
    public class ExpansionCardChangedStatusEventArgs : EventArgs
    {
        private readonly int expansionCardNumber;
        private readonly ExpansionCardStatus status;

        public ExpansionCardChangedStatusEventArgs(int expansionCardNumber, ExpansionCardStatus status)
        {
            this.expansionCardNumber = expansionCardNumber;
            this.status = status;
        }

        public int ExpansionCardNumber
        {
            get { return expansionCardNumber; }
        }

        public ExpansionCardStatus Status
        {
            get { return status; }
        }
    }
}
