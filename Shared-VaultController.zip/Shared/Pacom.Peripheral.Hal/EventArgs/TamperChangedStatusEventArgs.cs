﻿using System;

namespace Pacom.Peripheral.Hal
{
    public class TamperChangedStatusEventArgs : EventArgs
    {
        private readonly bool tamper;

        public TamperChangedStatusEventArgs(bool tamper)
        {
            this.tamper = tamper;
        }

        /// <summary>
        /// Returns true if tamper is active.
        /// </summary>
        public bool Tamper
        {
            get { return tamper; }
        }
    }
}
