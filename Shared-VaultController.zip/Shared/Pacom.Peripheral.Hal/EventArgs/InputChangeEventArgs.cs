using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Hal
{
    public class InputChangeEventArgs : EventArgs
    {
        private readonly int highReading;
        private readonly int input;
        private readonly bool trouble;
        private readonly int duration;

        public InputChangeEventArgs(int highReading, int input, bool trouble, int duration)
        {
            this.highReading = highReading;
            this.input = input;
            this.trouble = trouble;
            this.duration = duration;
        }

        public int HighReading
        {
            get { return highReading; }
        }

        public int Input
        {
            get { return input; }
        }

        public bool Trouble
        {
            get { return trouble; }
        }

        public int Duration
        {
            get { return duration; }
        }
    }
}
