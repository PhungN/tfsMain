﻿using System;
using System.Text;
using System.Threading;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utils;
using StatusManager = Pacom.Peripheral.Common.Status.StatusManager;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class takes care of initialising and maintaining connections to the expansion cards.
    /// </summary>
    public class ExpansionCardManager : IExpansionCardManager
    {
        public const int ExpansionSlotCount = ConfigurationManager.ExpansionSlotCount;

        private ExpansionCardBase[] expansionCards = new ExpansionCardBase[ExpansionSlotCount];
        private ExpansionCardType[] expansionCardTypes = new ExpansionCardType[ExpansionSlotCount];

        private Thread expansionCardPollingThread;
        private bool exitPollingThread;

        private Pacom8203OutputCard[] outputExpansionCards = new Pacom8203OutputCard[ExpansionSlotCount];
        private Pacom8204InputCard[] inputExpansionCards = new Pacom8204InputCard[ExpansionSlotCount];
        private Pacom8208SartCard[] sartExpansionCards = new Pacom8208SartCard[ExpansionSlotCount];

        #region Instance management

        private static ExpansionCardManager instance = null;

        public static ExpansionCardManager CreateInstance()
        {
            if (instance == null)
                instance = new ExpansionCardManager();
            return instance;
        }

        public static ExpansionCardManager Instance
        {
            get
            {
                if (instance == null)
                    instanceMustBeCreated();
                return instance;
            }
        }

        private ExpansionCardManager()
        {
            Logger.LogCriticalMessage(LoggerClassPrefixes.ExpansionManager, () =>
            {
                return "Expansion handling is starting.";
            });

            I2c.EnableLowSpeedCommunications();

            for (int slotNumber = 0; slotNumber < ExpansionSlotCount; slotNumber++)
            {
                byte[] identityResponse = new byte[0x14];
                byte[] restartCommand = new byte[] { 0x03, 0x00, 0xFD };
                bool success = false;
                uint address = 0;

                switch (slotNumber)
                {
                    case 0: address = ExpansionCardBase.ExpansionSlot1Address; break;
                    case 1: address = ExpansionCardBase.ExpansionSlot2Address; break;
                    case 2: address = ExpansionCardBase.ExpansionSlot3Address; break;
                    case 3: address = ExpansionCardBase.ExpansionSlot4Address; break;
                }

                // Restart Device command
                I2c.WriteToDevice(address | 0x05, 0, 0, restartCommand);

                for (int i = 0; i < 15; i++)
                {
                    Thread.Sleep(100);

                    // Query Identity command
                    success = I2c.ReadFromDevice(address, 0, 0, identityResponse);
                    if (success)
                    {
                        break;
                    }
                }

                if (success)
                {
                    if (identityResponse[2] == 0x82)
                    {
                        FirmwareVersion expectedCardFirmwareVersion = null;
                        if (identityResponse[3] == 0x03)
                        {
                            expansionCards[slotNumber] = new Pacom8203OutputCard(slotNumber, identityResponse);
                            expansionCardTypes[slotNumber] = ExpansionCardType.Pacom8203OutputCard;
                            // Do not report fuse fail on startup
                            if ((identityResponse[1] & (byte)ExpansionCardStatusByte.FuseBlown) != 0)
                            {
                                expansionCards[slotNumber].Status = ExpansionCardStatus.FuseFail;
                            }
                            expansionCards[slotNumber].ExpansionCardChangedStatus += new EventHandler<ExpansionCardChangedStatusEventArgs>(expansionCardChangedStatus);

                            expectedCardFirmwareVersion = ExpansionCardFirmwareManager.ExpectedFirmwareVersion(ExpansionCardType.Pacom8203OutputCard);
                        }
                        else if (identityResponse[3] == 0x04)
                        {
                            expansionCards[slotNumber] = new Pacom8204InputCard(slotNumber, identityResponse);
                            expansionCardTypes[slotNumber] = ExpansionCardType.Pacom8204InputCard;
                            expansionCards[slotNumber].ExpansionCardChangedStatus += new EventHandler<ExpansionCardChangedStatusEventArgs>(expansionCardChangedStatus);

                            expectedCardFirmwareVersion = ExpansionCardFirmwareManager.ExpectedFirmwareVersion(ExpansionCardType.Pacom8204InputCard);
                        }
                        else if (identityResponse[3] == 0x05)
                        {
                            expansionCards[slotNumber] = new Pacom8205SerialCard(slotNumber, identityResponse);
                            expansionCardTypes[slotNumber] = ExpansionCardType.Pacom8205SerialCard;
                            expansionCards[slotNumber].ExpansionCardChangedStatus += new EventHandler<ExpansionCardChangedStatusEventArgs>(expansionCardChangedStatus);
                        }
                        else if (identityResponse[3] == 0x07)
                        {
                            expansionCards[slotNumber] = new Pacom8207StarCouplerCard(slotNumber, identityResponse);
                            expansionCardTypes[slotNumber] = ExpansionCardType.Pacom8207StarCouplerCard;
                            expansionCards[slotNumber].ExpansionCardChangedStatus += new EventHandler<ExpansionCardChangedStatusEventArgs>(expansionCardChangedStatus);
                        }
                        else if (identityResponse[3] == 0x08)
                        {
                            expansionCards[slotNumber] = new Pacom8208SartCard(slotNumber, identityResponse);
                            expansionCardTypes[slotNumber] = ExpansionCardType.Pacom8208SartInputOutputCard;
                            // Do not report fuse fail on startup
                            if ((identityResponse[1] & (byte)ExpansionCardStatusByte.FuseBlown) != 0)
                            {
                                expansionCards[slotNumber].Status = ExpansionCardStatus.FuseFail;
                            }
                            expansionCards[slotNumber].ExpansionCardChangedStatus += new EventHandler<ExpansionCardChangedStatusEventArgs>(expansionCardChangedStatus);
                            expectedCardFirmwareVersion = ExpansionCardFirmwareManager.ExpectedFirmwareVersion(ExpansionCardType.Pacom8208SartInputOutputCard);
                        }
                        else
                        {
                            continue;
                        }

                        FirmwareVersion expansionCardFirmwareVersion = expansionCards[slotNumber].Version;
                        if (expectedCardFirmwareVersion != null && expansionCardFirmwareVersion.Equals(expectedCardFirmwareVersion) == false)
                        {
                            Logger.LogWarnMessage(LoggerClassPrefixes.ExpansionManager, () => string.Format("Updating expansion card in slot {0} from version {1} to {2}",
                                                                                                            slotNumber + 1,
                                                                                                            expansionCardFirmwareVersion.ToString(),
                                                                                                            expectedCardFirmwareVersion.ToString()));
                            if (expansionCards[slotNumber].PerformFirmwareDownload() == false)
                            {
                                Logger.LogWarnMessage(LoggerClassPrefixes.ExpansionManager, () => string.Format("Update failed"));
                                expansionCards[slotNumber] = null;
                            }
                            else
                            {
                                FirmwareVersion ver = expansionCards[slotNumber].Version;
                                Logger.LogWarnMessage(LoggerClassPrefixes.ExpansionManager, () => string.Format("Update successful, version now {0}.",
                                                                                                                ver.ToString()));
                            }
                        }
                    }
                }
            }

            I2c.EnableHighSpeedCommunications();

            // Create expansion card status manager items
            StringBuilder foundCardsReport = new StringBuilder();
            for (int slotNumber = 0; slotNumber < ExpansionSlotCount; slotNumber++)
            {
                if (foundCardsReport.Length != 0)
                    foundCardsReport.Append(", ");
                foundCardsReport.Append("[");
                foundCardsReport.Append(string.Format("Slot {0}:", slotNumber + 1));
                foundCardsReport.Append(expansionCardTypes[slotNumber].ToString());
                foundCardsReport.Append("]");

                try
                {
                    // Set initial card status
                    Common.ExpansionCardStatus expansionStatus = expansionCards[slotNumber] == null ? ExpansionCardStatus.Offline : expansionCards[slotNumber].Status;
                    StatusManager.Instance.ExpansionCards[slotNumber + 1].Type = expansionCardTypes[slotNumber];
                    StatusManager.Instance.ExpansionCards[slotNumber + 1].SetStatus(expansionStatus);
                }
                catch
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.ExpansionManager, () =>
                    {
                        return string.Format("Unable to create expansion card status object for slot {0}.", slotNumber);
                    });
                }

                // Assemble reference array for output and input cards 
                ExpansionCardBase expansionCard = expansionCards[slotNumber];
                if (expansionCard != null)
                {
                    if (expansionCard.Type == ExpansionCardType.Pacom8203OutputCard)
                        outputExpansionCards[slotNumber] = expansionCard as Pacom8203OutputCard;
                    else if (expansionCard.Type == ExpansionCardType.Pacom8204InputCard)
                        inputExpansionCards[slotNumber] = expansionCard as Pacom8204InputCard;
                    else if (expansionCard.Type == ExpansionCardType.Pacom8208SartInputOutputCard)
                        sartExpansionCards[slotNumber] = expansionCard as Pacom8208SartCard;
                }
            }

            Logger.LogCriticalMessage(LoggerClassPrefixes.ExpansionManager, () =>
            {
                return string.Format("Found expansion cards ({0}).", foundCardsReport.ToString());
            });

            // Start processing thread when any cards are present
            if (anyExpansionCardValid == true)
            {
                ConfigurationManager.Instance.ConfigurationChanged += configurationChangedHandler;
                startPollingThread();
            }
        }

        private void configurationChangedHandler(object sender, EventArgs e)
        {
            stopPollingThread();

            // 8204 cards _must_ have their ConfigurationChanged called before we set up polling, so call
            // directly from here
            foreach (ExpansionCardBase card in expansionCards)
            {
                Pacom8204InputCard inputCard = card as Pacom8204InputCard;
                if (inputCard != null)
                {
                    // card is an 8204, call ConfigurationHasChanged directly
                    inputCard.ConfigurationHasChanged();
                }
            }
            startPollingThread();
        }

        private void startPollingThread()
        {
            exitPollingThread = false;
            expansionCardPollingThread = new Thread(new ThreadStart(expansionCardPollingThreadMethod));
            expansionCardPollingThread.Name = "Expansion Card Polling Thread";
            expansionCardPollingThread.IsBackground = true;
            expansionCardPollingThread.Priority = ThreadPriority.AboveNormal;
            expansionCardPollingThread.Start();
        }

        private void stopPollingThread()
        {
            if (expansionCardPollingThread == null)
            {
                return;
            }
            exitPollingThread = true; // signal to the thread that it is time to exit
            expansionCardPollingThread.JoinOrRestart(2000);
            expansionCardPollingThread = null;
        }

        private bool anyExpansionCardValid
        {
            get { return expansionCardTypes.FirstOrDefault(cardType => cardType != ExpansionCardType.None) != ExpansionCardType.None; }
        }

        private static void instanceMustBeCreated()
        {
            Logger.LogErrorMessage(LoggerClassPrefixes.ExpansionManager, () =>
            {
                return "Instance must be created before usage. Call CreateInstance() method before using this property.";
            });
        }

        #endregion

        private void expansionCardChangedStatus(object sender, ExpansionCardChangedStatusEventArgs e)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
            {
                return "Expansion card " + e.ExpansionCardNumber + " changed status to " + e.Status;
            });

            // Modify expansion card status
            Common.Status.ExpansionCardStatus expansionCardStatus = StatusManager.Instance.ExpansionCards[e.ExpansionCardNumber + 1];
            if (expansionCardStatus != null)
            {
                expansionCardStatus.SetStatus(e.Status);
            }
        }

        /// <summary>
        /// Returns the class responsible for handling the expansion card in the specified slot.
        /// </summary>
        /// <param name="slotNumber">0 if the expansion card is in Exp1, 1 if the expansion card is in Exp2. etc</param>
        /// <returns>The class responsible for handling the expansion card in the specified slot.</returns>
        public ExpansionCardBase GetExpansionCard(int slotNumber)
        {
            return expansionCards[slotNumber];
        }

        /// <summary>
        /// Returns the type of expansion card in the specified slot.
        /// </summary>
        /// <param name="slotNumber">0 if the expansion card is in Exp1, 1 if the expansion card is in Exp2. etc</param>
        /// <returns>The type of expansion card in the specified slot.</returns>
        public ExpansionCardType GetExpansionCardType(int slotNumber)
        {
            return expansionCardTypes[slotNumber];
        }

        /// <summary>
        /// Returns output expanion card if exists for given slot.
        /// </summary>
        /// <param name="slotNumber">0 if the expansion card is in Exp1, 1 if the expansion card is in Exp2. etc</param>
        /// <returns>The output expansion card or null if does not exist</returns>
        public IOutputContainer OutputExpansionCard(int slotNumber)
        {
            if (slotNumber < 0 || slotNumber > (ExpansionSlotCount - 1))
                return null;

            return outputExpansionCards[slotNumber];
        }

        /// <summary>
        /// Returns input expanion card if exists for given slot.
        /// </summary>
        /// <param name="slotNumber">0 if the expansion card is in Exp1, 1 if the expansion card is in Exp2. etc</param>
        /// <returns>The input expansion card or null if does not exist</returns>
        public Pacom8204InputCard InputExpansionCard(int slotNumber)
        {
            if (slotNumber < 0 || slotNumber > (ExpansionSlotCount - 1))
                return null;

            return inputExpansionCards[slotNumber];
        }

        /// <summary>
        /// Returns S-ART expanion card if exists for given slot.
        /// </summary>
        /// <param name="slotNumber">0 if the expansion card is in Exp1, 1 if the expansion card is in Exp2. etc</param>
        /// <returns>The S-ART expansion card or null if does not exist</returns>
        public Pacom8208SartCard SartExpansionCard(int slotNumber)
        {
            if (slotNumber < 0 || slotNumber > (ExpansionSlotCount - 1))
                return null;

            return sartExpansionCards[slotNumber];
        }

        /// <summary>
        /// Return first assigned SART card. Start from slot 0, 1, 2 than 3.
        /// </summary>
        public Pacom8208SartCard FirstSartExpansionCard
        {
            get
            {
                for (int i = 0; i < ExpansionSlotCount; i++)
                {
                    if (sartExpansionCards[i] != null)
                        return sartExpansionCards[i];
                }
                return null;
            }
        }

        /// <summary>
        /// Return first assigned SART card cas as an output container. Start from slot 0, 1, 2 than 3.
        /// </summary>
        public IOutputContainer FirstSartOutputExpansionCard
        {
            get
            {
                for (int i = 0; i < ExpansionSlotCount; i++)
                {
                    if (sartExpansionCards[i] != null)
                        return sartExpansionCards[i];
                }
                return null;
            }
        }

        /// <summary>
        /// Returns true once all expansion cards have been successfully initialized and are completely up and running.
        /// </summary>
        public bool Initialized
        {
            get
            {
                for (int i = 0; i < ExpansionSlotCount; i++)
                {
                    if (expansionCards[i] != null)
                    {
                        if (expansionCards[i].Initialized == false)
                            return false;
                    }
                }
                return true;
            }
        }

        /// <summary>
        /// This thread polls each expansion card at its desired rate and will
        /// flag the expansion care as offline if too many consecutive polls are missed.
        /// </summary>
        private void expansionCardPollingThreadMethod()
        {
            int[] pollTimes = new int[ExpansionSlotCount];
            int[] missedPollsBeforeOffline = new int[ExpansionSlotCount];
            int[] missedPolls = new int[ExpansionSlotCount];
            bool pollResult;

            for (int i = 0; i < ExpansionSlotCount; i++)
            {
                if (expansionCards[i] != null)
                {
                    pollTimes[i] = expansionCards[i].RequiredPollTime();
                    missedPollsBeforeOffline[i] = 2000 / pollTimes[i];
                    missedPolls[i] = 0;
                }
            }

            int sleepTime = int.MaxValue;
            int[] remainingTime = new int[ExpansionSlotCount];
            for (int i = 0; i < ExpansionSlotCount; i++)
            {
                if (expansionCards[i] != null)
                {
                    remainingTime[i] = pollTimes[i];
                    if (sleepTime > pollTimes[i])
                        sleepTime = pollTimes[i];
                }
            }

            if (sleepTime != int.MaxValue)
            {
                while (Application.Closing == false && exitPollingThread == false)
                {
                    for (int i = 0; i < ExpansionSlotCount; i++)
                    {
                        if (expansionCards[i] != null)
                        {
                            remainingTime[i] -= sleepTime;
                            if (remainingTime[i] == 0)
                            {
                                pollResult = expansionCards[i].PollDevice();
                                remainingTime[i] = pollTimes[i];
                                if (pollResult == false)
                                {
                                    missedPolls[i]++;
                                    if (missedPollsBeforeOffline[i] == missedPolls[i])
                                    {
                                        expansionCards[i].Status = ExpansionCardStatus.Offline;
                                        expansionCardChangedStatus(expansionCards[i], new ExpansionCardChangedStatusEventArgs(i, ExpansionCardStatus.Offline));
                                    }
                                }
                                else
                                {
                                    missedPolls[i] = 0;
                                }
                            }
                        }
                    }
                    Thread.Sleep(sleepTime);
                }
            }
        }
    }
}
