﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class is responsible for driving the I2C IO Expanders.
    /// </summary>
    public static class IOExpander
    {
        private const UInt32 IODirectionRegister = 0;
        private const UInt32 InputPolarityRegister = 1;
        private const UInt32 InterrupOnChangeControlRegister = 2;
        private const UInt32 DefaultCompareRegister = 3;
        private const UInt32 InterruptControlRegister = 4;
        private const UInt32 ConfigurationRegister = 5;
        private const UInt32 PullUpConfigurationRegister = 6;
        private const UInt32 InterruptFlagRegister = 7;
        private const UInt32 InterruptCaptureRegister = 8;
        private const UInt32 GpioRegister = 9;
        private const UInt32 OutputLatchRegister = 10;

        /// <summary>
        /// Each specified pin will have the output set. Unspecified pins are unchanged.
        /// </summary>
        /// <param name="ioExpander">The IO Expander to use.</param>
        /// <param name="pins">A list of pins to set.</param>
        /// <returns>True if successful otherwise False.</returns>
        public static bool ActivateOutputs(IOExpanderDevice ioExpander, IOExpanderPin pins)
        {
            byte[] data = new byte[1];
            if (I2c.ReadFromDevice((UInt32)ioExpander, OutputLatchRegister, 1, data) == false)
                return false;

            // If we already have the outputs active, just return
            byte desiredValue = (byte)(data[0] | (byte)pins);
            if (desiredValue == data[0])
                return true;
            // Otherwise activate the output
            data[0] = desiredValue;
            return I2c.WriteToDevice((UInt32)ioExpander, OutputLatchRegister, 1, data);
        }

        /// <summary>
        /// Each specified pin will have the output cleared. Unspecified pins are unchanged.
        /// </summary>
        /// <param name="ioExpander">The IO Expander to use.</param>
        /// <param name="pins">A list of pins to set.</param>
        /// <returns>True if successful otherwise False.</returns>
        public static bool DeactivateOutputs(IOExpanderDevice ioExpander, IOExpanderPin pins)
        {
            byte[] data = new byte[1];
            if (I2c.ReadFromDevice((UInt32)ioExpander, OutputLatchRegister, 1, data) == false)
                return false;

            // If the output is not currently active, just return
            byte desiredValue = (byte)(data[0] & (byte)~pins);
            if (desiredValue == data[0])
                return true;
            // Otherwise deactivate the output
            data[0] = desiredValue;
            return I2c.WriteToDevice((UInt32)ioExpander, OutputLatchRegister, 1, data);
        }

        /// <summary>
        /// Each specified pin will have the output set while unspecified pins are cleared.
        /// </summary>
        /// <param name="ioExpander">The IO Expander to use.</param>
        /// <param name="pins">A list of pins to set.</param>
        /// <returns>True if successful otherwise False.</returns>
        public static bool SetOutputValue(IOExpanderDevice ioExpander, IOExpanderPin pins)
        {
            return I2c.WriteToDevice((UInt32)ioExpander, OutputLatchRegister, 1, new byte[] { (byte)pins });
        }

        /// <summary>
        /// Each specified pin will be configured as an input while unspecified pins are configured as outputs.
        /// </summary>
        /// <param name="ioExpander">The IO Expander to use.</param>
        /// <param name="pins">A list of pins to configure as inputs.</param>
        /// <returns>True if successful otherwise False.</returns>
        public static bool ConfigureInputs(IOExpanderDevice ioExpander, IOExpanderPin pins)
        {
            return I2c.WriteToDevice((UInt32)ioExpander, IODirectionRegister, 1, new byte[] { (byte)pins });
        }

        /// <summary>
        /// Returns a list of active pins.
        /// </summary>
        /// <param name="ioExpander">The IO Expander to use.</param>
        /// <param name="pinNumber">A list of pins that are active.</param>
        /// <returns>True if successful otherwise False.</returns>
        public static bool GetPinStatus(IOExpanderDevice ioExpander, out IOExpanderPin pinNumber)
        {
            pinNumber = 0;
            byte[] data = new byte[1];
            if (I2c.ReadFromDevice((UInt32)ioExpander, GpioRegister, 1, data) == false)
                return false;

            pinNumber = (IOExpanderPin)data[0];

            return true;
        }
    }
}
