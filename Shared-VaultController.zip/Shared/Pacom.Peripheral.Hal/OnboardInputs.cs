﻿using System;
using System.Threading;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Status;
using CardReaderConsts = Pacom.Peripheral.AccessControl.CardReaderHardwareLocations;
using Pacom.Peripheral.Common.Utilities;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class provides notifications when the onboard inputs change state (Secure/Alarm/Short/Open/Trouble/Analog).
    /// </summary>
    public partial class OnboardInputs
    {
        private Common.InputStatus[] currentInputStatuses = new Common.InputStatus[OnboardInputsCount];
        private ExtendedInputPointConfiguration[] inputPointConfigurations = new ExtendedInputPointConfiguration[OnboardInputsCount];
        private Thread alarmScanningThread;

        /// <summary>
        /// This singleton is handling onboard inputs in the system.
        /// </summary>
        private const OwnerType owner = OwnerType.Onboard;

        #region Instance management

        /// <summary>
        /// Onboard inputs only instance
        /// </summary>
        private static OnboardInputs instance = null;

        /// <summary>
        /// StatusManager instance creation. This should only be called once in order to
        /// create the StatusManager. After that the Instance property should be used to 
        /// access the StatusManager.
        /// </summary>
        /// <returns></returns>
        public static OnboardInputs CreateInstance()
        {
            if (instance == null)
            {
                instance = new OnboardInputs();
            }
            return instance;
        }

        /// <summary>
        /// Onboard inputs instance accessor
        /// </summary>
        public static OnboardInputs Instance
        {
            get
            {
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.OnboardInputs, () =>
                    {
                        return "Instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
                return instance;
            }
        }

        private OnboardInputs()
        {
            // Read the current configuration
            configurationManager_ConfigurationChanged(null, null);

            ConfigurationManager.Instance.ConfigurationChanged += new EventHandler<EventArgs>(configurationManager_ConfigurationChanged);

            for (int i = 0; i < OnboardInputsCount; i++)
            {
                currentInputStatuses[i] = Common.InputStatus.Unknown;
            }

            Gpio.SetOutput(GpioPort.PortA, 30);
            Gpio.ConfigurePin(GpioPort.PortA, 30, true, false, false);

            alarmScanningThread = new Thread(new ThreadStart(alarmScanningThreadMethod));
            alarmScanningThread.Name = "Alarm Scanning Thread";
            alarmScanningThread.IsBackground = true;
            alarmScanningThread.Priority = ThreadPriority.AboveNormal;
            alarmScanningThread.Start();
        }

        #endregion

        /// <summary>
        /// Get the 1st input id for onboard inputs
        /// </summary>
        /// <returns>The 1st input id for onboard inputs</returns>
        public int FirstInputPoint
        {
            get { return 0; }
        }

        private void configurationManager_ConfigurationChanged(object sender, EventArgs e)
        {
            lock (inputPointConfigurations)
            {
                for (int i = 0; i < OnboardInputsCount; i++)
                {
                    InputConfiguration inputConfiguration = ConfigurationManager.Instance.Inputs[i + 1];
                    if (inputConfiguration != null)
                    {
                        // Check if door has supervised egress
                        bool supervisedInput = true;
                        int doorHardwareIndex;
                        if (CardReaderConsts.IsDoorEgressInput(i, out doorHardwareIndex) == true)
                        {
                            // Modify egress input to include configuration from the entry reader initialization record
                            supervisedInput = ConfigurationManager.Instance.Doors[doorHardwareIndex + 1].IsSupervisedEgress;
                        }
                        inputPointConfigurations[i] = new ExtendedInputPointConfiguration(inputConfiguration, true, supervisedInput);
                    }
                }
            }
        }

        /// <summary>
        /// Returns true once the onboard inputs have been successfully initialized and stabilized.
        /// </summary>
        public bool Initialized
        {
            get
            {
                for (int i = 0; i < OnboardInputsCount; i++)
                {
                    if (currentInputStatuses[i] == Common.InputStatus.Unknown)
                        return false;
                }
                return true;
            }
        }

        /// <summary>
        /// Returns the current state (Secure/Alarm/Short/Open/Trouble/Analog) of an input point.
        /// </summary>
        /// <param name="inputNumber">The zero based input point of interest.</param>
        /// <returns>The current state (Secure/Alarm/Short/Open/Trouble/Analog) of the input point.</returns>
        public Common.InputStatus GetInputPointStatus(int inputNumber)
        {
            return currentInputStatuses[inputNumber];
        }

        /// <summary>
        /// This thread polls each onboard input point for any input point state changes.
        /// This thread also polls for tamper and changes of state on the external power supply. 
        /// While it would make more sense for this functionality to be moved to the Pcb class, 
        /// placing it here reduces the need to create another thread.
        /// </summary>
        private void alarmScanningThreadMethod()
        {
            try
            {
                int[] highAdcReadings = new int[OnboardInputsCount];
                int[] lowAdcReadings = new int[OnboardInputsCount];

                Adc.Instance.ReadCurrentAdcValues(highAdcReadings);
                for (int i = 0; i < OnboardInputsCount; i++)
                {
                    processInputChange(i, highAdcReadings[i], false, 0);
                }
                Adc.Instance.InputChanged += new EventHandler<InputChangeEventArgs>(Spi_InputChanged);

                while (Application.Closing == false)
                {
                    Pcb.ScanForTamperAndPowerAlarms();
                    Thread.Sleep(70);
                }
            }
            catch (Exception ex)
            {
                // Handle the Error
                Logger.LogErrorMessage(LoggerClassPrefixes.OnboardInputs, () =>
                {
                    return string.Format("Alarm scanning thread terminated unexpectedly. {0}", ex.Message);
                });
            }
        }

        void Spi_InputChanged(object sender, InputChangeEventArgs e)
        {
            processInputChange(e.Input, e.HighReading, e.Trouble, e.Duration);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input">Zero based input.</param>
        /// <param name="highAdcReading"></param>
        /// <param name="lowAdcReading"></param>
        /// <param name="trouble"></param>
        private void processInputChange(int inputNumber, int highAdcReading, bool trouble, int duration)
        {
            if (trouble)
            {
                if (inputPointConfigurations[inputNumber].SupervisedInput)
                {
                    updateInputStatus(inputNumber, Common.InputStatus.Trouble, highAdcReading);

                    Logger.LogDebugMessage(LoggerClassPrefixes.OnboardInputs, () =>
											{
												return string.Format("Onboard Input {0} experienced a transient of duration {1}", (inputNumber + 1), duration);
											});
                }
                else
                {
                    // Unsupervised mode reports trouble as an alarm
                    updateInputStatus(inputNumber, Common.InputStatus.Alarm, highAdcReading);
                    Logger.LogDebugMessage(LoggerClassPrefixes.OnboardInputs, () => "Unsupervised trouble reported as alarm");
                }
            }
            else
            {
                double uncorrectedAdcReading = highAdcReading;
                highAdcReading = (int)(uncorrectedAdcReading * adcCorrectionFactor);

                Common.InputStatus highInputClassification;

                lock (inputPointConfigurations)
                {
                    highInputClassification = classifyAdcReading(inputNumber, highAdcReading);
                }

                updateInputStatus(inputNumber, highInputClassification, highAdcReading);
            }
        }

        private bool updateInputStatus(int inputNumber, Common.InputStatus inputState, int highAdcReading)
        {
            if (currentInputStatuses[inputNumber] != inputState)
            {
                currentInputStatuses[inputNumber] = inputState;
                var inputStatus = StatusManager.Instance.Inputs[inputNumber + 1];
                if (inputStatus != null)
                    inputStatus.Change(inputState, highAdcReading);

                Logger.LogDebugMessage(LoggerClassPrefixes.OnboardInputs, () =>
                {
                    return string.Format("Onboard Input {0} changed state to {1} (High-{2}) ({3} ohms)", (inputNumber + 1), currentInputStatuses[inputNumber], highAdcReading, CommonUtilities.AdcReadingToResistanceValue(highAdcReading, ExtendedInputPointConfiguration.AdcResolution, OnboardInputs.OnboardCurrentLimitingResistorValue, OnboardInputs.OnboardPullUpResistorValue));
                });
                return true;
            }
            return false;
        }

        private Common.InputStatus classifyAdcReading(int inputNumber, int adcReading)
        {
            if (adcReading >= inputPointConfigurations[inputNumber].SecureRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].SecureRangeUpperLimit)
                return Common.InputStatus.Secure;
            else if (adcReading >= inputPointConfigurations[inputNumber].AlarmRange1LowerLimit && adcReading <= inputPointConfigurations[inputNumber].AlarmRange1UpperLimit)
                return Common.InputStatus.Alarm;
            else if (adcReading >= inputPointConfigurations[inputNumber].AlarmRange2LowerLimit && adcReading <= inputPointConfigurations[inputNumber].AlarmRange2UpperLimit)
                return Common.InputStatus.Alarm;
            else if (adcReading >= inputPointConfigurations[inputNumber].OpenRangeLowerLimit)
                return Common.InputStatus.Open;
            else if (adcReading <= inputPointConfigurations[inputNumber].ShortRangeUpperLimit)
                return Common.InputStatus.Short;
            else if (adcReading >= inputPointConfigurations[inputNumber].MaskingRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].MaskingRangeUpperLimit)
                return Common.InputStatus.Masking;
            else if (adcReading >= inputPointConfigurations[inputNumber].RangeReductionRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].RangeReductionRangeUpperLimit)
                return Common.InputStatus.RangeReduction;
            else if (adcReading >= inputPointConfigurations[inputNumber].MaskingAndRangeReductionRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].MaskingAndRangeReductionRangeUpperLimit)
                return Common.InputStatus.MaskingAndRangeReduction;
            else if (adcReading >= inputPointConfigurations[inputNumber].AlarmAndMaskingRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].AlarmAndMaskingRangeUpperLimit)
                return Common.InputStatus.AlarmAndMasking;
            else if (adcReading >= inputPointConfigurations[inputNumber].AlarmAndRangeReductionRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].AlarmAndRangeReductionRangeUpperLimit)
                return Common.InputStatus.AlarmAndRangeReduction;
            else if (adcReading >= inputPointConfigurations[inputNumber].AlarmAndMaskingAndRangeReductionRangeLowerLimit && adcReading <= inputPointConfigurations[inputNumber].AlarmAndMaskingAndRangeReductionRangeUpperLimit)
                return Common.InputStatus.AlarmAndMaskingAndRangeReduction;
            return Common.InputStatus.Trouble;
        }
    }
}
