﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;
using System.Threading;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Hal
{
    /// <summary>
    /// This class reads a raw 10-bit value from one of the analogue-to-digital converters.
    /// </summary>
    public class Adc : IAdc
    {
        /// <summary>Defined IOCTLs for SPI driver</summary>
        private const int IOCTL_READ_ADC = 0x1B2008;
        private const int IOCTL_READ_ADC_CHANGES = 0x1B200C;
        private const int IOCTL_SET_HIT_COUNTS = 0x1B2010;

        private static Thread adcThread;

        public event EventHandler<InputChangeEventArgs> InputChanged;

        /// <summary>
        /// Singleton instance of Adc class
        /// </summary>
        private static Adc instance = null;

        private Adc()
        {
            adcThread = new Thread(new ThreadStart(spiThreadMethod));
            adcThread.Name = "ADC Thread";
            adcThread.IsBackground = true;
            adcThread.Priority = ThreadPriority.Normal;
            adcThread.Start();
        }

        public static Adc CreateInstance()
        {
            if (instance == null)
                instance = new Adc();
            return instance;
        }

        /// <summary>
        /// Instance method to get singleton
        /// </summary>
        /// <returns></returns>
        public static Adc Instance
        {
            get
            {
                if (instance == null)
                {
                    try
                    {
                        throw new Exception();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Here: " + ex);
                    }
                }
                // Lock deliberately omitted
                return instance;
            }
        }

        /// <summary>
        /// Reads a raw 10-bit value from one of the analogue-to-digital converters.
        /// </summary>
        /// <param name="adcConverter">The analogue-to-digital converter chip to use.</param>
        /// <param name="adcInput">The zero based input number on the analogue-to-digital converter chip to use.</param>
        /// <returns>The raw 10-bit value.</returns>
        public static int PerformAdcRead(AdcDevice adcConverter, int adcInput)
        {
            byte[] data = new byte[3];

#if DEBUG
            if (adcInput > 7)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return "ADC input out of range!";
                });
                return -1;
            }
#endif

            data[0] = 0x01;
            data[1] = (byte)((0x8 | adcInput) << 4);
            if (Spi.CommunicateWithDevice((SpiDevice)adcConverter, data, data) == false)
                return -1;

            return data[2] + ((data[1] & 0x03) << 8);
        }

        public bool ReadCurrentAdcValues(int[] highReadings)
        {
            byte[] receiveBuffer = new byte[64];
            GCHandle receiveBufferHandle;

            receiveBufferHandle = GCHandle.Alloc(receiveBuffer, GCHandleType.Pinned);
            try
            {
                if (NativeMethods.DeviceIoControl(Spi.DriverHandleAdc, IOCTL_READ_ADC, IntPtr.Zero, 0, receiveBufferHandle.AddrOfPinnedObject(), 64, IntPtr.Zero, IntPtr.Zero) == 0)
                    return false;

                for (int i = 0; i < OnboardInputs.OnboardInputsCount; i++)
                {
                    highReadings[i] = receiveBuffer[(i * 4) + 0] | ((receiveBuffer[(i * 4) + 1] & 0x03) << 8);
                }

                return true;
            }
            finally
            {
                receiveBufferHandle.Free();
            }
        }

        public void SetAdcHitCounts(int[] hitCounts)
        {
            byte[] sendBuffer = new byte[hitCounts.Length];
            int returnedBytes;

            try
            {
                for (int i = 0; i < hitCounts.Length; i++)
                {
                    sendBuffer[i] = (byte)hitCounts[i];
                }

                NativeMethods.DeviceIoControl(Spi.DriverHandleAdc, IOCTL_SET_HIT_COUNTS, sendBuffer, OnboardInputs.OnboardInputsCount, IntPtr.Zero, 0, out returnedBytes, IntPtr.Zero);
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.SpiBus, () =>
                {
                    return string.Format("Set Hit Count Error. {0}", ex);
                });
            }
        }

        private void spiThreadMethod()
        {
            try
            {
                IntPtr inputChangeEvent = NativeMethods.OpenEvent(Constants.EVENT_ALL_ACCESS, false, "IO8003_ADC_CHANGE_STATE");

                IntPtr[] events = new IntPtr[] { inputChangeEvent, Application.ClosingEvent };

                while (InputChanged == null)
                {
                    // wait for InputChanged to be set up
                    if (NativeMethods.WaitForSingleObject(Application.ClosingEvent, 50) == 0)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.SpiBus, () =>
                        {
                            return string.Format("ADC Thread Method - Exit before setup");
                        });
                        return;
                    }
                }

                byte[] receiveBuffer = new byte[256];
                GCHandle receiveBufferHandle;

                while (true)
                {
                    int triggeredEvent = NativeMethods.WaitForMultipleObjects(2, events, 0, Constants.Infinite);
                    if (triggeredEvent == 0)
                    {
                        receiveBufferHandle = GCHandle.Alloc(receiveBuffer, GCHandleType.Pinned);
                        try
                        {
                            int length;
                            if (NativeMethods.DeviceIoControl(Spi.DriverHandleAdc, IOCTL_READ_ADC_CHANGES, IntPtr.Zero, 0, receiveBufferHandle.AddrOfPinnedObject(), 256, out length, IntPtr.Zero) != 0)
                            {
                                for (int i = 0; i < length; i++)
                                {
                                    int highReadings = receiveBuffer[(i * 4) + 0] | ((receiveBuffer[(i * 4) + 1] & 0x03) << 8);
                                    int input = (receiveBuffer[(i * 4) + 2] >> 4) & 0x0F;
                                    bool trouble = (receiveBuffer[(i * 4) + 3] & 0x01) != 0;
                                    int duration = (receiveBuffer[(i * 4) + 3]) >> 1;
                                    InputChanged(null, new InputChangeEventArgs(highReadings, input, trouble, duration));
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.LogErrorMessage(LoggerClassPrefixes.SpiBus, () =>
                            {
                                return string.Format("ADC Thread Method Error. {0}", ex);
                            });
                        }
                        finally
                        {
                            receiveBufferHandle.Free();
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.SpiBus, () =>
                {
                    return string.Format("ADC Thread Method Error. {0}", ex);
                });
            }
            Logger.LogErrorMessage(LoggerClassPrefixes.SpiBus, () =>
            {
                return string.Format("ADC Thread Method - Exit");
            });
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}
