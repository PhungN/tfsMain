﻿using System;

namespace Pacom.Peripheral.Common.Configuration
{
    public class DoorConfiguration
    {
        public DoorConfiguration(int doorLogicalId, bool doorIsConfigured)
        {
            this.LogicalId = doorLogicalId;
            if (doorIsConfigured)
                this.IsConfigured = DoorConfiguredType.DoorConfigured;
            else
                this.IsConfigured = DoorConfiguredType.DoorNotConfigured;
        }

        public int LogicalId
        {
            get;
            private set;
        }

        private DoorConfiguredType isConfigured = DoorConfiguredType.DoorNotConfigured;

        /// <summary>
        /// Get \ Set flag that indicates if the door is configured. System can specify if any particular reader is configured.
        /// </summary>
        public DoorConfiguredType IsConfigured
        {
            get
            {
                return this.isConfigured;
            }
            set
            {
                if (this.isConfigured != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Doors, LogicalId);
                    this.isConfigured = value;
                }
            }
        }

        private CardReaderType entryReaderType = CardReaderType.NoReader;

        /// <summary>
        /// Get \ Set entry reader type
        /// </summary>
        public CardReaderType EntryReaderType
        {
            get
            {
                return entryReaderType;
            }
            set
            {
                if (this.entryReaderType != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Doors, LogicalId);
                    entryReaderType = value;
                }
            }
        }

        private CardReaderType exitReaderType = CardReaderType.NoReader;

        /// <summary>
        /// Get \ Set exit reader type
        /// </summary>
        public CardReaderType ExitReaderType
        {
            get
            {
                return exitReaderType;
            }
            set
            {
                if (this.exitReaderType != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Doors, LogicalId);
                    exitReaderType = value;
                }
            }
        }

        private bool isSupervisedEgress = true;

        /// <summary>
        /// Get \ Set flag that indicates if the door has supervised egress.
        /// </summary>
        public bool IsSupervisedEgress
        {
            get
            {
                return this.isSupervisedEgress;
            }
            set
            {
                if (this.isSupervisedEgress != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Doors, LogicalId);
                    this.isSupervisedEgress = value;
                }
            }
        }

        private bool degradedMemoryEnabled = true;

        /// <summary>
        /// Get \ Set flag that indicates if the door has degraded mode disabled.
        /// </summary>
        public bool DegradedMemoryEnabled
        {
            get
            {
                return this.degradedMemoryEnabled;
            }
            set
            {
                if (this.degradedMemoryEnabled != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Doors, LogicalId);
                    this.degradedMemoryEnabled = value;
                }
            }
        }

        public override string ToString()
        {
            return string.Format("IsConfigured : {0} IsSupervisedEgress : {1} Entry : {2} Exit : {3} DegradedModeAllowed : {4}",
                isConfigured.ToString(), isSupervisedEgress.ToString(), entryReaderType.ToString(), exitReaderType.ToString(),
                degradedMemoryEnabled ? "Yes" : "No");
        }
    }
}
