﻿using System.Collections.Generic;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    /// <summary>
    /// Expansion card configuration list
    /// </summary>
    public class ExpansionCardConfigurationList
    {
        private readonly object configurationListSync = new object();

        private SortedList<int, ExpansionCardConfiguration> configurationList = null;

        public ConfigurationManager Parent = null;

        internal ExpansionCardConfigurationList(ConfigurationManager parent)
        {
            configurationList = new SortedList<int, ExpansionCardConfiguration>();
            this.Parent = parent;
        }

        /// <summary>
        /// Return the expansion card configuration list elements as an array that can be iterated independently
        /// </summary>
        public ExpansionCardConfiguration[] Items
        {
            get
            {
                lock (configurationListSync)
                {
                    return configurationList.Values.ToArray();
                }
            }
        }

        /// <summary>
        /// Return expansion card configuration object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <returns>Node configuration instance or null if not found</returns>
        public virtual ExpansionCardConfiguration this[int logicalId]
        {
            get
            {
                lock (configurationListSync)
                {
                    if (logicalId < 1 || configurationList == null || configurationList.Count < 1)
                        return null;
                    ExpansionCardConfiguration outputItem = null;
                    configurationList.TryGetValue(logicalId, out outputItem);
                    return outputItem;
                }
            }
        }

        /// <summary>
        /// Add configuration item
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <param name="inputPointConfiguration"></param>
        internal void AddExpansion(int logicalId, ExpansionCardConfiguration cradConfiguration)
        {
            ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.ExpansionCards, logicalId);
            configurationList.Add(logicalId, cradConfiguration);
        }

        /// <summary>
        /// Get owner type base on slot number. Slot starting 0.
        /// </summary>
        /// <param name="slotNumber"></param>
        /// <returns></returns>
        public OwnerType GetOwnerType(int slotNumber)
        {
            return (OwnerType)(slotNumber + OwnerType.Expansion1);
        }

        /// <summary>
        /// Check if owner type is an expansion card
        /// </summary>
        /// <param name="owner">Owner to check</param>
        /// <returns>Returnes true if the owner is an expansion cards</returns>
        public bool IsOwnerExpansionCard(OwnerType owner)
        {
            return owner == OwnerType.Expansion1
                || owner == OwnerType.Expansion2
                || owner == OwnerType.Expansion3
                || owner == OwnerType.Expansion4;
        }

        public override string ToString()
        {
            return string.Format("{0} expansion slots found (8220 supported)", configurationList.Count);
        }
    }
}
