﻿using System;

namespace Pacom.Peripheral.Common.Configuration
{
    public class ExpansionCardConfiguration
    {
        public ExpansionCardConfiguration(int logicalId)
        {
            this.LogicalId = logicalId;
        }

        public int LogicalId
        {
            get;
            private set;
        }

        private ExpansionCardType type = ExpansionCardType.None;

        /// <summary>
        /// Get \ Set configured expansion card type
        /// </summary>
        public ExpansionCardType Type
        {
            get
            {
                return this.type;
            }
            set
            {
                if (this.type != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.ExpansionCards, LogicalId);
                    this.type = value;

                    if (value == ExpansionCardType.None)
                        portType = ExpansionCardConfigurationPortType.None;
                }
            }
        }

        private ExpansionCardConfigurationPortType portType = ExpansionCardConfigurationPortType.None;

        /// <summary>
        /// Get \ Set configured expansion port type
        /// </summary>
        public ExpansionCardConfigurationPortType PortType
        {
            get
            {
                return this.portType;
            }
            set
            {
                if (this.portType != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.ExpansionCards, LogicalId);
                    this.portType = value;
                }
            }
        }

        public override string ToString()
        {
            return string.Format("Type : {0} PortType: {1}", type.ToString(), portType.ToString());
        }
    }
}
