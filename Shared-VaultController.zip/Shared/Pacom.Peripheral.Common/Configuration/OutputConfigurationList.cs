﻿using System.Collections.Generic;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    /// <summary>
    /// Output configuration list
    /// </summary>
    public partial class OutputConfigurationList
    {
        private readonly object configurationListSync = new object();

        private SortedList<int, OutputConfiguration> configurationList = null;

        public ConfigurationManager Parent = null;

        private Dictionary<OwnerType, ConfigurationRange> outputRange = new Dictionary<OwnerType, ConfigurationRange>();
                
        /// <summary>
        /// Return the output configuration list elements as an array that can be iterated independently
        /// </summary>
        public OutputConfiguration[] Items
        {
            get
            {
                lock (configurationListSync)
                {
                    return configurationList.Values.ToArray();
                }
            }
        }

        /// <summary>
        /// Return output configuration object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <returns>Node configuration instance or null if not found</returns>
        public virtual OutputConfiguration this[int logicalId]
        {
            get
            {
                lock (configurationListSync)
                {
                    if (logicalId < 1 || configurationList == null || configurationList.Count < 1)
                        return null;
                    OutputConfiguration outputItem = null;
                    configurationList.TryGetValue(logicalId, out outputItem);
                    return outputItem;
                }
            }
        }

        /// <summary>
        /// Add configuration item
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <param name="outputPointConfiguration"></param>
        internal void AddOutput(int logicalId, OutputConfiguration outputConfiguration)
        {
            ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Outputs, logicalId);
            configurationList.Add(logicalId, outputConfiguration);
        }

        /// <summary>
        /// Get the number of outputs configured for each device areas: Onboard, Exp1, ..., Exp4, Sart1, etc.
        /// </summary>
        /// <param name="owner">Outputs owner: OnBoard, Exp1, ..., Exp4, Sart1, etc.</param>
        /// <returns>Outputs count</returns>
        public int OutputsCountForOwner(OwnerType owner)
        {
            switch (owner)
            {
                case OwnerType.Onboard: return ConfigurationManager.OnboardOutputsCount;
                case OwnerType.Expansion1:
                case OwnerType.Expansion2:
                case OwnerType.Expansion3:
                case OwnerType.Expansion4: return ConfigurationManager.Pacom8208OutputsCount;
                case OwnerType.Sart1: return ConfigurationManager.Pacom8208OutputsCount;
                default: return 0;
            }
        }

        /// <summary>
        /// Get logical output id for this output point when the owner and point on owner are known 
        /// </summary>
        /// <param name="owner">Output's owner (parent): On board, Exp1, ..., Exp4, Sart1, etc.</param>
        /// <param name="pointNumberOnParent">0 based point number on owner.</param>
        /// <returns>Logical point id</returns>
        public int LogicalOutputId(OwnerType owner, int pointNumberOnParent)
        {
            if (pointNumberOnParent >= OutputsCountForOwner(owner))
                return 0;
            return outputRange[owner].MinLogicalId + pointNumberOnParent;
        }

        /// <summary>
        /// Check if all points are configured for the specified owner.
        /// </summary>
        /// <param name="owner">Owner to scan</param>
        /// <returns>Returns true if all points are configured</returns>
        public bool AreAllConfigured(OwnerType owner)
        {
            for (int logicalId = outputRange[owner].MinLogicalId; logicalId <= outputRange[owner].MaxLogicalId; logicalId++)
            {
                if (this[logicalId].IsConfigured == false)
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Check if any point is configured for the specified owner.
        /// </summary>
        /// <param name="owner">Owner to scan</param>
        /// <returns>Returns true if any point is configured</returns>
        public bool AreAnyConfigured(OwnerType owner)
        {
            for (int logicalId = outputRange[owner].MinLogicalId; logicalId <= outputRange[owner].MaxLogicalId; logicalId++)
            {
                if (this[logicalId].IsConfigured == true)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Get an owner and point number of an output from provided logicalId.
        /// </summary>
        /// <param name="logicalId">Output logicalId</param>
        /// <param name="owner">Returned owner of the Output</param>
        /// <param name="pointNumberOnParent">Returned point number on the owner. Starts with 0.</param>
        public void GetOwnerAndPointNumber(int logicalId, out OwnerType owner, out int pointNumberOnParent)
        {
            owner = OwnerType.None;
            pointNumberOnParent = -1;

            if (logicalId < 0 || logicalId > ConfigurationManager.InputsCount)
                return;

            foreach (var o in outputRange.Keys)
            {
                if (logicalId >= outputRange[o].MinLogicalId && logicalId <= outputRange[o].MaxLogicalId)
                {
                    owner = o;
                    pointNumberOnParent = logicalId - outputRange[o].MinLogicalId;
                    return;
                }
            }
            return;
        }

        public override string ToString()
        {
            return string.Format("{0} outputs found", configurationList.Count);
        }
    }
}
