﻿
namespace Pacom.Peripheral.Common.Configuration
{
    /// <summary>
    /// This class must be used outside of configuration manager where there is a need for input configuration.
    /// </summary>
    public class InputConfigurationBase
    {
        public InputConfigurationBase(int logicalId, bool reportPoint, int hitCount, ResistorTolerance tolerance, int alarmResistance, int secureResistance, int analogInputResolution)
        {
            LogicalId = logicalId;
            ReportPoint = reportPoint;
            HitCount = hitCount;
            Tolerance = tolerance;
            AlarmResistance = alarmResistance;
            SecureResistance = secureResistance;
            AnalogInputResolution = analogInputResolution;
            MaskingResistance = 0;
            RangeReductionResistance = 0;
        }

        public InputConfigurationBase(int logicalId, bool reportPoint, int hitCount, ResistorTolerance tolerance, int alarmResistance, int secureResistance, int analogInputResolution, int maskingResistance, int rangeReductionResistance)
        {
            LogicalId = logicalId;
            ReportPoint = reportPoint;
            HitCount = hitCount;
            Tolerance = tolerance;
            AlarmResistance = alarmResistance;
            SecureResistance = secureResistance;
            AnalogInputResolution = analogInputResolution;
            MaskingResistance = maskingResistance;
            RangeReductionResistance = rangeReductionResistance;
        }

        public int LogicalId
        {
            get;
            private set;
        }
            
        private bool reportPoint;

        public bool ReportPoint
        {
            get { return reportPoint; }
            set { reportPoint = value; }
        }

        private int hitCount;

        public int HitCount
        {
            get { return hitCount; }
            set { hitCount = value; }
        }

        private ResistorTolerance tolerance;

        public ResistorTolerance Tolerance
        {
            get { return tolerance; }
            set { tolerance = value; }
        }

        private int alarmResistance;

        public int AlarmResistance
        {
            get { return alarmResistance; }
            set {  alarmResistance = value; }
        }

        private int secureResistance;

        public int SecureResistance
        {
            get { return secureResistance; }
            set { secureResistance = value; }
        }

        private int maskingResistance;

        public int MaskingResistance
        {
            get { return maskingResistance; }
            set { maskingResistance = value; }
        }

        private int rangeReductionResistance;

        public int RangeReductionResistance
        {
            get { return rangeReductionResistance; }
            set { rangeReductionResistance = value; }
        }

        private int analogInputResolution;

        public int AnalogInputResolution
        {
            get { return analogInputResolution; }
            set { analogInputResolution = value; }
        }

        public override string ToString()
        {
            return string.Format(
                "Report:{0}, HitCount:{1}, Tol:{2}, Alarm:{3}, Secure:{4}, Masking:{5}, RangeReduction:{6}, AnalogResolution:{7}",
                ReportPoint ? "Yes" : "No", HitCount, Tolerance == ResistorTolerance.TwelveAndAHalfPercent ? "12.5%" : "25%",
                AlarmResistance, SecureResistance, MaskingResistance, RangeReductionResistance, AnalogInputResolution);
        }   
    }
}
