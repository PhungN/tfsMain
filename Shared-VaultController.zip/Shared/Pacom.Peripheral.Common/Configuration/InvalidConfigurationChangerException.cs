﻿using System;

namespace Pacom.Peripheral.Common
{
    public class InvalidConfigurationChangerException : Exception
    {
        public InvalidConfigurationChangerException()
            : base("Unable to change configuration. Configuration changer has NOT been detected.")
        { 
        }
    }
}
