﻿
namespace Pacom.Peripheral.Common.Configuration
{
    public class InputConfiguration : InputConfigurationBase
    {
        public InputConfiguration(int logicalId, bool reportPoint, int hitCount, ResistorTolerance tolerance, int alarmResistance, int secureResistance, int analogInputResolution)
            : base(logicalId, reportPoint, hitCount, tolerance, alarmResistance, secureResistance, analogInputResolution)
        {           
        }

        public InputConfiguration(int logicalId, bool reportPoint, int hitCount, ResistorTolerance tolerance, int alarmResistance, int secureResistance, int analogInputResolution, int maskingResistance, int rangeReductionResistance)
            : base(logicalId, reportPoint, hitCount, tolerance, alarmResistance, secureResistance, analogInputResolution, maskingResistance, rangeReductionResistance)
        {           
        }
           
        new public bool ReportPoint
        {
            get { return base.ReportPoint; }
            set
            {
                if (base.ReportPoint != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Inputs, LogicalId);
                    base.ReportPoint = value;
                    ConfigurationManager.Instance.UpdateInputExpansionConfiguration(this.LogicalId);
                }
            }
        }

        new public int HitCount
        {
            get { return base.HitCount; }
            set
            {
                int tempHitCount = value;

                // Default the hit count if trying to set hit count to zero.
                if (tempHitCount == 0)
                    tempHitCount = DeviceDefaultConfiguration.Instance.Input.HitCount;

                if (base.HitCount != tempHitCount)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Inputs, LogicalId);
                    base.HitCount = tempHitCount;
                }
            }
        }

        new public ResistorTolerance Tolerance
        {
            get { return base.Tolerance; }
            set
            {
                if (base.Tolerance != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Inputs, LogicalId);
                    base.Tolerance = value;
                }
            }
        }

        new public int AlarmResistance
        {
            get { return base.AlarmResistance; }
            set
            {
                if (base.AlarmResistance != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Inputs, LogicalId);
                    base.AlarmResistance = value;
                }
            }
        }

        new public int SecureResistance
        {
            get { return base.SecureResistance; }
            set
            {
                if (base.SecureResistance != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Inputs, LogicalId);
                    base.SecureResistance = value;
                }
            }
        }

        new public int MaskingResistance
        {
            get { return base.MaskingResistance; }
            set
            {
                if (base.MaskingResistance != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Inputs, LogicalId);
                    base.MaskingResistance = value;
                }
            }
        }

        new public int RangeReductionResistance
        {
            get { return base.RangeReductionResistance; }
            set
            {
                if (base.RangeReductionResistance != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Inputs, LogicalId);
                    base.RangeReductionResistance = value;
                }
            }
        }

        new public int AnalogInputResolution
        {
            get { return base.AnalogInputResolution; }
            set
            {
                if (base.AnalogInputResolution != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Inputs, LogicalId);
                    base.AnalogInputResolution = value;
                }
            }
        }

        public void SetResistanceValue(ResistanceValueType resistanceValueType, int resistanceValue)
        {
            switch (resistanceValueType)
            {
                case ResistanceValueType.Secure:
                    SecureResistance = resistanceValue;
                    break;
                case ResistanceValueType.Alarm:
                    AlarmResistance = resistanceValue;
                    break;
                case ResistanceValueType.Masking:
                    MaskingResistance = resistanceValue;
                    break;
                case ResistanceValueType.RangeReduction:
                    RangeReductionResistance = resistanceValue;
                    break;
            }
        }
    }
}
