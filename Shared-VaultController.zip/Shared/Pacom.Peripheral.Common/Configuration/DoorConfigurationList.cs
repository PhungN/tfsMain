﻿using System.Collections.Generic;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    /// <summary>
    /// Door configuration list
    /// </summary>
    public class DoorConfigurationList
    {
        private readonly object configurationListSync = new object();

        private SortedList<int, DoorConfiguration> configurationList = null;

        public ConfigurationManager Parent = null;

        internal DoorConfigurationList(ConfigurationManager parent)
        {
            configurationList = new SortedList<int, DoorConfiguration>();
            this.Parent = parent;
        }

        /// <summary>
        /// Return the door configuration list elements as an array that can be iterated independently
        /// </summary>
        public DoorConfiguration[] Items
        {
            get
            {
                lock (configurationListSync)
                {
                    return configurationList.Values.ToArray();
                }
            }
        }

        /// <summary>
        /// Return door configuration object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <returns>Node configuration instance or null if not found</returns>
        public virtual DoorConfiguration this[int logicalId]
        {
            get
            {
                lock (configurationListSync)
                {
                    if (logicalId < 1 || configurationList == null || configurationList.Count < 1)
                        return null;
                    DoorConfiguration doorItem = null;
                    configurationList.TryGetValue(logicalId, out doorItem);
                    return doorItem;
                }
            }
        }

        /// <summary>
        /// Add configuration item
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <param name="doorConfiguration"></param>
        internal void AddDoor(int logicalId, DoorConfiguration doorConfiguration)
        {
            ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Doors, logicalId);
            configurationList.Add(logicalId, doorConfiguration);
        }

        /// <summary>
        /// Returnes true if any door is configured.
        /// </summary>
        public bool IsAnyDoorConfigured
        {
            get
            {
                foreach (var doorLogicalId in configurationList.Keys)
                {
                    if (configurationList[doorLogicalId].IsConfigured != DoorConfiguredType.DoorNotConfigured)
                        return true;
                }
                return false;
            }
        }

        public override string ToString()
        {
            return string.Format("{0} doors found", configurationList.Count);
        }
    }
}
