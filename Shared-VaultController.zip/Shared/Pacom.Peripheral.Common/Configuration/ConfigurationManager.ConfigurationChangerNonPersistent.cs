﻿
namespace Pacom.Peripheral.Common.Configuration
{
    public partial class ConfigurationManager
    {
        public class ConfigurationChangerNonPersistent : ConfigurationChanger
        {
            /// <summary>
            /// Constructor used to create instance allowing for non-persistent configuration changer.
            /// </summary>
            /// <param name="owner"></param>
            /// <param name="changes"></param>
            internal ConfigurationChangerNonPersistent(ConfigurationManager owner, ConfigurationLogging loggingOption)
                : base(owner, loggingOption)
            {
            }

            /// <summary>
            /// If True, indicates that the configuration changer is non-persistent.
            /// </summary>
            public override bool Persistent
            {
                get { return false; }
            }
        }
    }
}
