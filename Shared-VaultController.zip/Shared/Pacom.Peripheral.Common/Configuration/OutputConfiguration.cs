﻿using System;

namespace Pacom.Peripheral.Common.Configuration
{
    public class OutputConfiguration
    {
        public OutputConfiguration(int logicalId, bool isConfigured)
        {
            this.LogicalId = logicalId;
            this.isConfigured = IsConfigured;
        }

        public int LogicalId
        {
            get;
            private set;
        }

        private bool isConfigured = false;

        /// <summary>
        /// Get \ Set flag that indicates if the output is configured.
        /// </summary>
        public bool IsConfigured
        {
            get
            {
                return this.isConfigured;
            }
            set
            {
                if (this.isConfigured != value)
                {
                    ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Outputs, LogicalId);
                    this.isConfigured = value;
                    ConfigurationManager.Instance.UpdateOutputExpansionConfiguration(this.LogicalId);
                }                
            }
        }

        public override string ToString()
        {
            return string.Format("IsConfigured : {0}", isConfigured.ToString());
        }
    }
}
