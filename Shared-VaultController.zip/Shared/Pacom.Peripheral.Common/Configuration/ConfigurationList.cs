﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace Pacom.Peripheral.Common.Configuration
{
    internal class ConfigurationList
    {
        private Dictionary<ConfigurationItem, object> configuration = null;
        private ConfigurationItem[] allConfigurationItems = null;
        private object listLock = new object();

        public ConfigurationList()
        {
            configuration = new Dictionary<ConfigurationItem, object>();
            allConfigurationItems = getAllConfigurationItems();
        }

        private ConfigurationItem[] getAllConfigurationItems()
        {
            List<ConfigurationItem> result = new List<ConfigurationItem>();
            System.Reflection.FieldInfo[] fi = typeof(ConfigurationItem).GetFields(BindingFlags.Static | BindingFlags.Public);
            for (int iEnum = 0; iEnum < fi.Length; iEnum++)
            {
                result.Add((ConfigurationItem)fi[iEnum].GetValue(null));
            }
            return result.ToArray();
        }

        public T Get<T>(ConfigurationItem item)
        {
            lock (listLock)
            {
                if (configuration.ContainsKey(item) == false || configuration[item] == null)
                    return default(T);

                if (configuration[item] is T)
                {
                    return (T)configuration[item];
                }

                return default(T);
            }
        }

        public T Get<T>(ConfigurationItem item, T defaultValue)
        {
            lock (listLock)
            {
                if (configuration.ContainsKey(item) == false || configuration[item] == null)
                    return defaultValue;

                if (configuration[item] is T)
                {
                    return (T)configuration[item];
                }

                return defaultValue;
            }
        }

        public string GetAsString(ConfigurationItem item)
        {
            lock (listLock)
            {
                if (configuration.ContainsKey(item) == false || configuration[item] == null)
                    return string.Empty;

                return (configuration[item]).ToString();
            }
        }

        public object GetAsObject(ConfigurationItem item)
        {
            lock (listLock)
            {
                if (configuration.ContainsKey(item) == false || configuration[item] == null)
                    return null;

                return configuration[item];
            }
        }

        public void Set<T>(ConfigurationItem item, T value)
        {
            lock (listLock)
            {
                configuration[item] = value;
            }
        }

        public ConfigurationItem[] AllKeys
        {
            get
            {
                return allConfigurationItems;
            }
        }

        public bool KeyExist(ConfigurationItem item)
        {
            lock (listLock)
            {
                return configuration.ContainsKey(item);
            }
        }
    }
}
