﻿using System;
using System.Threading;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Configuration
{
    public partial class ConfigurationManager
    {
        public class ConfigurationChanger : IDisposable
        {
            private static object configLock = new object();

            /// <summary>
            /// Count the WRITE changers created. 
            /// </summary>
            private static int instanceCount = 0;

            private ConfigurationManager owner = null;
            private ConfigurationLogging loggingOption = ConfigurationLogging.ChangesOnly;            
            
            /// <summary>
            /// Note changed elements across nested change requests.
            /// </summary>
            private static List<ConfigurationItem> changedItems = null;
            private static Dictionary<ConfigurationItem, List<int>> changedDetailsItems = null;

            /// <summary>
            /// Constructor used to create instance allowing for configuration changer.
            /// </summary>
            /// <param name="owner"></param>
            /// <param name="changes"></param>
            internal ConfigurationChanger(ConfigurationManager owner, ConfigurationLogging loggingOption)
            {
                Monitor.Enter(configLock);
                this.LockAcquired = true;
                this.owner = owner;                
                this.loggingOption = loggingOption;
                // Prepare the list with changed items. If list already exists, we have nested changers - accumulate items.
                if (changedDetailsItems == null)
                    changedDetailsItems = new Dictionary<ConfigurationItem, List<int>>();
                if (changedItems == null)
                {
                    if (loggingOption == ConfigurationLogging.All)
                        changedItems = new List<ConfigurationItem>(owner.configuration.AllKeys);
                    else
                        changedItems = new List<ConfigurationItem>();
                }
                else
                {
                    if (loggingOption == ConfigurationLogging.All)
                    {
                        // Replace the list with all keys list.
                        changedItems = new List<ConfigurationItem>(owner.configuration.AllKeys);
                    }
                }
                instanceCount++;
                Logger.LogTracedCommsMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return string.Format("Configuration lock: READ-WRITE created. Instance: {0}", instanceCount);
                });
            }

            /// <summary>
            /// Get the changer configuration logging level.
            /// </summary>
            public ConfigurationLogging LoggingOption { get { return loggingOption; } }

            /// <summary>
            /// If True, indicates that the configuration changer is non-persistent.
            /// </summary>
            public virtual bool Persistent
            {
                get { return true; }
            }

            /// <summary>
            /// Returns true if lock has been acquired.
            /// </summary>
            public bool LockAcquired { private set; get; }

            /// <summary>
            /// Register item that has been changed.
            /// </summary>
            /// <param name="item">Configuration item to be registered as changed.</param>
            internal void RegisterChangedItem(ConfigurationItem item, int logicalId)
            {
                if (changedItems.Contains(item) == false)
                    changedItems.Add(item);
                
                if (this.loggingOption == ConfigurationLogging.ChangesOnly && logicalId > 0)
                {
                    // Register changed detail logical Id
                    List<int> detailList = null;
                    if (changedDetailsItems.ContainsKey(item) == true && changedDetailsItems[item] != null)
                    {
                        detailList = (List<int>)changedDetailsItems[item];
                        if (detailList.Contains(logicalId) == false)
                            detailList.Add(logicalId);
                    }
                    else
                    {
                        detailList = new List<int>();
                        detailList.Add(logicalId);
                        changedDetailsItems.Add(item, detailList);
                    }
                }
            }

            /// <summary>
            /// Return changed items as an array.
            /// </summary>
            public ConfigurationItem[] ChangedItems
            {
                get
                {
                    if (changedItems != null)
                        return changedItems.ToArray();
                    else
                        return new ConfigurationItem[0];
                }
            }

            /// <summary>
            /// Get True if the there are configuration changes.
            /// </summary>
            public bool ChangesExist
            {
                get
                {
                    var items = ChangedItems;
                    return items != null && items.Length != 0;
                }
            }

            /// <summary>
            /// Return logical Ids changed for the specified item
            /// </summary>
            /// <param name="item">Configuration item to query</param>
            /// <returns>List of logical id in an array. If the list is an empty one, the whole item category has been affeced by the change.</returns>
            public int[] GetChangedLogicalIds(ConfigurationItem item)
            {
                if (changedDetailsItems.ContainsKey(item) == true && changedDetailsItems[item] != null)
                {
                    var list = (List<int>)changedDetailsItems[item];
                    list.Sort();
                    return list.ToArray();
                }
                else
                {
                    return new int[0];
                }
            }

            #region IDisposable Members

            public void Dispose()
            {
                instanceCount--;
                if (instanceCount <= 0)
                {
                    this.owner.callConfigurationChangedEvent(this, ChangedItems);
                    if (this.ChangesExist)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                        {
                            return "Configuration lock disposed.";
                        });
                    }

                    changedItems = null;
                    changedDetailsItems = null;

                    // Reset the global changer instance counter
                    instanceCount = 0;

                    // Unregister configuration changer from configuration manager
                    this.owner.currentConfigurationChanger = null;
                }
                Logger.LogTracedCommsMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                {
                    return "Configuration lock: READ-WRITE disposed.";
                });
                // Release lock if it was acquired
                if (this.LockAcquired == true)
                {
                    Monitor.Exit(configLock);
                    this.LockAcquired = false;
                }
            }

            #endregion
        }
    }
}
