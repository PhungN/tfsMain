﻿using System.Collections.Generic;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Configuration
{
    /// <summary>
    /// Input configuration list
    /// </summary>
    public partial class InputConfigurationList
    {
        private readonly object configurationListSync = new object();

        private SortedList<int, InputConfiguration> configurationList = null;

        public ConfigurationManager Parent = null;

        private Dictionary<OwnerType, ConfigurationRange> inputRange = new Dictionary<OwnerType,ConfigurationRange>();
        
        /// <summary>
        /// Return the input configuration list elements as an array that can be iterated independently
        /// </summary>
        public InputConfiguration[] Items
        {
            get
            {
                lock (configurationListSync)
                {
                    return configurationList.Values.ToArray();
                }
            }
        }

        /// <summary>
        /// Return input configuration object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <returns>Node configuration instance or null if not found</returns>
        public virtual InputConfiguration this[int logicalId]
        {
            get
            {
                lock (configurationListSync)
                {
                    if (logicalId < 1 || configurationList == null || configurationList.Count < 1)
                        return null;
                    InputConfiguration inputItem = null;
                    configurationList.TryGetValue(logicalId, out inputItem);
                    return inputItem;
                }
            }
        }

        /// <summary>
        /// Add configuration item
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <param name="inputPointConfiguration"></param>
        internal void AddInput(int logicalId, InputConfiguration inputConfiguration)
        {
            ConfigurationManager.Instance.RegisterConfigurationChange(ConfigurationItem.Inputs, logicalId);
            configurationList.Add(logicalId, inputConfiguration);
        }

        /// <summary>
        /// Get the number of inputs configured for each device areas: Onboard, Exp1, ..., Exp4, Sart1, etc.
        /// </summary>
        /// <param name="owner">Inputs owner: OnBoard, Exp1, ..., Exp4, Sart1, etc.</param>
        /// <returns>Inputs count</returns>
        public int InputsCountForOwner(OwnerType owner)
        {
            switch (owner)
            {
                case OwnerType.Onboard: return ConfigurationManager.OnboardInputsCount;
                case OwnerType.Expansion1:
                case OwnerType.Expansion2:
                case OwnerType.Expansion3:
                case OwnerType.Expansion4: return ConfigurationManager.Pacom8204InputsCount;
                case OwnerType.Sart1: return ConfigurationManager.Pacom8208InputsCount;
                default: return 0;
            }
        }

        /// <summary>
        /// Get logical input id for this input point when the owner and point on owner are known 
        /// </summary>
        /// <param name="owner">Input's owner (parent): On board, Exp1, ..., Exp4, Sart1, etc.</param>
        /// <param name="pointNumberOnParent">0 based point number on owner.</param>
        /// <returns>Logical point id</returns>
        public int LogicalInputId(OwnerType owner, int pointNumberOnParent)
        {
            if (pointNumberOnParent >= InputsCountForOwner(owner))
                return 0;
            return inputRange[owner].MinLogicalId + pointNumberOnParent;
        }

        /// <summary>
        /// Check if all points are configured for the specified owner.
        /// </summary>
        /// <param name="owner">Owner to scan</param>
        /// <returns>Returns true if all points are configured</returns>
        public bool AreAllConfigured(OwnerType owner)
        {
            for (int logicalId = inputRange[owner].MinLogicalId; logicalId <= inputRange[owner].MaxLogicalId; logicalId++)
            {
                if (this[logicalId].ReportPoint == false)
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Check if any point is configured for the specified owner.
        /// </summary>
        /// <param name="owner">Owner to scan</param>
        /// <returns>Returns true if any point is configured</returns>
        public bool AreAnyConfigured(OwnerType owner)
        {
            for (int logicalId = inputRange[owner].MinLogicalId; logicalId <= inputRange[owner].MaxLogicalId; logicalId++)
            {
                if (this[logicalId].ReportPoint == true)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Get an owner and point number of an input from provided logicalId.
        /// </summary>
        /// <param name="logicalId">Input logicalId</param>
        /// <param name="owner">Returned owner of the input</param>
        /// <param name="pointNumberOnParent">Returned point number on the owner. Starts with 0.</param>
        public void GetOwnerAndPointNumber(int logicalId, out OwnerType owner, out int pointNumberOnParent)
        {
            owner = OwnerType.None;
            pointNumberOnParent = -1;

            if (logicalId < 0 || logicalId > ConfigurationManager.InputsCount)
                return;

            foreach (var o in inputRange.Keys)
            {
                if (logicalId >= inputRange[o].MinLogicalId && logicalId <= inputRange[o].MaxLogicalId)
                {
                    owner = o;
                    pointNumberOnParent = logicalId - inputRange[o].MinLogicalId;
                    return;
                }
            }
            return;
        }

        public override string ToString()
        {
            return string.Format("{0} inputs found", configurationList.Count);
        }
    }
}
