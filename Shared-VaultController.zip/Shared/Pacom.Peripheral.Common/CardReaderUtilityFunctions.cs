using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Degraded memory agent key parsing and constructing functions.
    /// For better testability they are extracted from the main class.
    /// </summary>
    public static class CardReaderUtilityFunctions
    {

        /// <summary>
        /// Calculate parity of provided data over specified mask.
        /// </summary>
        /// <param name="numberOfBits">Total number of bits to check in data array.</param>
        /// <param name="data">Data array.</param>
        /// <param name="mask"></param>
        /// <returns>Returns true when there is even number of bits set under specified mask.</returns>
        public static bool CalcParity(int numberOfBits, byte[] data, byte[] mask)
        {
            if (numberOfBits <= 0)
                return false;

            byte parityResult = 0;
            int numberOfBitsScanned = 0;
            for (int byteCount = 0; byteCount < mask.Length; byteCount++)
            {
                if (byteCount <= data.Length - 1)
                {
                    for (int bitCount = 7; bitCount >= 0; bitCount--)
                    {
                        byte bitMask = (byte)(1 << bitCount);
                        if ((mask[byteCount] & bitMask) != 0)
                        {
                            if ((data[byteCount] & bitMask) != 0)
                            {
                                parityResult ^= 1;
                            }
                        }
                        numberOfBitsScanned++;
                        if (numberOfBitsScanned >= numberOfBits)
                            break;
                    }
                }
                if (numberOfBitsScanned >= numberOfBits)
                    break;
            }
            return parityResult == 0;
        }

        /// <summary>
        /// Remove bits from data array.
        /// </summary>
        /// <param name="numberOfBits">Number of bits.</param>
        /// <param name="data">Array of bytes with bit data.</param>
        /// <param name="bitsToRemove">Zero based positions of bits to remove.</param>
        /// <returns></returns>
        public static byte[] StripBits(int numberOfBits, byte[] data, int[] bitsToRemove)
        {
            if (numberOfBits <= 0)
                return new byte[0];

            // Make new array for result and clear it.
            byte[] resultArray = new byte[data.Length];
            for (int idxClear = 0; idxClear < resultArray.Length; idxClear++)
            {
                resultArray[idxClear] = 0;
            }
            // Scan the data and remove parity bits from it.
            int lastBitInResultArray = 0;
            int numberOfBitsScanned = 0;
            for (int byteCount = 0; byteCount < data.Length; byteCount++)
            {
                for (int bitCount = 7; bitCount >= 0; bitCount--)
                {
                    // Check if required to skip this bit
                    bool skip = false;
                    for (int bitsCount = 0; bitsCount < bitsToRemove.Length; bitsCount++)
                    {
                        if (bitsToRemove[bitsCount] == numberOfBitsScanned)
                        {
                            skip = true;
                            break;
                        }
                    }
                    if (skip == false)
                    {
                        // Add next bit to the array here
                        if ((data[byteCount] & (1 << bitCount)) != 0)
                        {
                            resultArray[lastBitInResultArray / 8] |= (byte)(1 << (7 - (lastBitInResultArray % 8)));
                        }
                        lastBitInResultArray++;
                    }
                    // Only scan required number of bits
                    numberOfBitsScanned++;
                    if (numberOfBitsScanned == numberOfBits)
                        break;
                }
                if (numberOfBitsScanned == numberOfBits)
                    break;
            }
            return resultArray;
        }

        public static void InvertData(int numberOfBits, byte[] data)
        {
            if (numberOfBits <= 0)
                return;

            int numberOfBitsScanned = 0;
            for (int byteCount = 0; byteCount < data.Length; byteCount++)
            {
                for (int bitCount = 7; bitCount >= 0; bitCount--)
                {
                    // Invert here
                    byte bitMask = (byte)(1 << bitCount);
                    if ((data[byteCount] & bitMask) == 0)
                    {
                        data[byteCount] |= bitMask;
                    }
                    else
                    {
                        data[byteCount] &= (byte)~bitMask;
                    }
                    // Only scan required number of bits
                    numberOfBitsScanned++;
                    if (numberOfBitsScanned == numberOfBits)
                        break;
                }
                if (numberOfBitsScanned == numberOfBits)
                    break;
            }
            return;
        }

        public static void ReverseData(int numberOfBits, byte[] data)
        {
            if (numberOfBits <= 0)
                return;

            if (numberOfBits > (data.Length * 8))
                numberOfBits = (data.Length * 8);

            int numberOfBitsScanned = 0;
            for (int byteCount = 0; byteCount < data.Length; byteCount++)
            {
                for (int bitCount = 7; bitCount >= 0; bitCount--)
                {
                    int bitNumber = numberOfBits - (7 - bitCount) - (byteCount * 8);
                    int reverseByteCount = (bitNumber - 1) / 8;
                    int reverseBitCount = 8 - (bitNumber - (reverseByteCount * 8));
                    byte bitMask = (byte)(1 << bitCount);
                    byte reverseBitMask = (byte)(1 << reverseBitCount);
                    if ((data[byteCount] & bitMask) == 0)
                    {
                        if ((data[reverseByteCount] & reverseBitMask) != 0)
                        {
                            // Set the bit
                            data[byteCount] |= bitMask;
                            // Clear the reverse bit
                            data[reverseByteCount] &= (byte)~reverseBitMask;
                        }
                    }
                    else
                    {
                        if ((data[reverseByteCount] & reverseBitMask) == 0)
                        {
                            // Clear the bit
                            data[byteCount] &= (byte)~(bitMask);
                            // Set the reverse bit
                            data[reverseByteCount] |= reverseBitMask;
                        }
                    }
                    // Only scan required number of bits
                    numberOfBitsScanned++;
                    if (numberOfBitsScanned == (numberOfBits / 2))
                        break;
                }
                if (numberOfBitsScanned == (numberOfBits / 2))
                    break;
            }
            return;
        }

        /// <summary>
        /// Extract bits from data array. The output data is used during communication with legacy controller.
        /// </summary>
        /// <param name="data">Byte array of data bits.</param>
        /// <param name="length">Number of bits to extract.</param>
        /// <param name="offset">Number of bits to skip.</param>
        /// <returns></returns>
        public static byte[] ExtractData(byte[] data, int length, int zeroBasedOffset)
        {
            byte[] resultData = new byte[0];
            // Offset plus length must be covered by data byte array length.
            if ((data.Length * 8 < (zeroBasedOffset + length)) || length <= 0 || zeroBasedOffset < 0 || zeroBasedOffset > (data.Length * 8))
            {
                return new byte[0];
            }
            // Allocate new array for extracted data            
            resultData = new byte[(length / 8) + ((length % 8) > 0 ? 1 : 0)];
            // Calculate bit and byte positions for the input array.
            int dataBitPos = 7 - ((zeroBasedOffset + length - 1) % 8);
            // Calculate bit and byte positions for the output array.
            int dataBytePos = ((zeroBasedOffset + length - 1) / 8);
            int outputBitPos = 0;
            int outputBytePos = 0;
            // Start moving data.
            for (int iBit = 0; iBit < length; iBit++)
            {
                if ((data[dataBytePos] & (1 << dataBitPos)) > 0)
                {
                    resultData[outputBytePos] |= (byte)(1 << outputBitPos);
                }
                dataBitPos++;
                if (dataBitPos > 7)
                {
                    dataBitPos = 0;
                    dataBytePos--;
                }
                outputBitPos++;
                if (outputBitPos > 7)
                {
                    outputBitPos = 0;
                    outputBytePos++;
                }
            }
            Array.Reverse(resultData, 0, resultData.Length);
            return resultData;
        }

        /// <summary>
        /// Reverse one byte
        /// </summary>
        /// <param name="b"></param>
        /// <returns></returns>
        public static byte ReverseWithUnrolledLoop(byte value)
        {
            byte returnValue = value;
            value >>= 1;
            returnValue <<= 1;
            returnValue |= (byte)(value & 1);
            value >>= 1;

            returnValue <<= 1;
            returnValue |= (byte)(value & 1);
            value >>= 1;

            returnValue <<= 1;
            returnValue |= (byte)(value & 1);
            value >>= 1;

            returnValue <<= 1;
            returnValue |= (byte)(value & 1);
            value >>= 1;

            returnValue <<= 1;
            returnValue |= (byte)(value & 1);
            value >>= 1;

            returnValue <<= 1;
            returnValue |= (byte)(value & 1);
            value >>= 1;

            returnValue <<= 1;
            returnValue |= (byte)(value & 1);
            value >>= 1;

            return returnValue;
        }

        /// <summary>
        /// This function will clear bits after requested length
        /// </summary>
        /// <param name="cardData">Card data</param>
        /// <param name="cardLength">Card length</param>
        public static void ClearBits(byte[] cardData, int cardLength)
        {
            int byteOffset = (cardLength / 8);
            int bitCount = 0;
            int highBit = 7;
            if (cardLength % 8 == 0)
            {
                bitCount = (byteOffset + 1) * 8;
            }
            else
            {
                bitCount = (byteOffset * 8) + (cardLength % 8);
                highBit = 7 - (cardLength % 8);
            }            
            // Check max 32 bytes. If array is longer ignore
            for (int iByte = byteOffset; iByte < (cardData.Length > 32 ? 32 : cardData.Length); iByte++)
            {
                for (int iBit = highBit; iBit >= 0; iBit--)
                {
                    if (++bitCount > cardLength)
                    {
                        cardData[iByte] &= (byte)~(1 << iBit);
                    }
                }
                highBit = 7;
            }
        }

        /// <summary>
        /// This function will set bits after requested length
        /// </summary>
        /// <param name="cardData">Card data</param>
        /// <param name="cardLength">Card length</param>
        public static void SetBits(byte[] cardData, int cardLength)
        {
            int byteOffset = (cardLength / 8);
            int bitCount = 0;
            int highBit = 7;
            if (cardLength % 8 == 0)
            {
                bitCount = (byteOffset + 1) * 8;
            }
            else
            {
                bitCount = (byteOffset * 8) + (cardLength % 8);
                highBit = 7 - (cardLength % 8);
            }
            // Check max 32 bytes. If array is longer ignore
            for (int iByte = byteOffset; iByte < (cardData.Length > 32 ? 32 : cardData.Length); iByte++)
            {
                for (int iBit = highBit; iBit >= 0; iBit--)
                {
                    if (++bitCount > cardLength)
                    {
                        cardData[iByte] |= (byte)(1 << iBit);
                    }
                }
                highBit = 7;
            }
        }

        /// <summary>
        /// Create key used to index degarded memory list.
        /// The key may be shorter than 32 bytes; it needs to be padded with missing bits as ones.
        /// </summary>
        /// <param name="cardData"></param>
        /// <param name="cardLength"></param>
        /// <returns></returns>
        public static byte[] ConstructCardkey(byte[] cardData, int cardLength)
        {
            int totalCardLength = 0;
            if (cardLength > cardData.Length * 8)
            {
                totalCardLength = cardData.Length * 8;
            }
            else
            {
                totalCardLength = cardLength;
            }

            byte[] key = new byte[34];
            if (cardData.Length <= 32)
            {
                int bitsMoved = 0;
                for (int iByte = 0; iByte < 32; iByte++)
                {
                    for (int iBit = 7; iBit >= 0; iBit--)
                    {
                        if (bitsMoved < totalCardLength)
                        {
                            if ((cardData[iByte] & (1 << iBit)) > 0)
                            {
                                key[iByte] |= (byte)(1 << iBit);
                            }
                            else
                            {
                                key[iByte] &= (byte)~(1 << iBit);
                            }
                        }
                        else
                        {
                            key[iByte] |= (byte)(1 << iBit);
                        }
                        bitsMoved++;
                    }
                }
            }
            key[32] = (byte)(cardLength >> 8);
            key[33] = (byte)(cardLength);
            return key;
        }

        public static void ParseCardkey(byte[] key, out byte[] cardData, out int cardLength)
        {
            if (key == null || key.Length != 34)
            {
                cardData = null;
                cardLength = 0;
                return;
            }
            try
            {
                cardLength = (key[32] << 8) | key[33];
                cardData = new byte[32];
                int bitsMoved = 0;
                for (int iByte = 0; iByte < 32; iByte++)
                {
                    for (int iBit = 7; iBit >= 0; iBit--)
                    {
                        if (bitsMoved < cardLength)
                        {
                            if ((key[iByte] & (1 << iBit)) > 0)
                            {
                                cardData[iByte] |= (byte)(1 << iBit);
                            }
                            else
                            {
                                cardData[iByte] &= (byte)~(1 << iBit);
                            }
                        }
                        else
                        {
                            return;
                        }
                        bitsMoved++;
                    }
                }
            }
            catch
            {
                // In case something odd goes on during parsing.
                cardData = null;
                cardLength = 0;
                return;
            }
        }

        public static bool LengthInvariantCardCompare(byte[] array1, byte[] array2)
        {
            if (array1 == null && array2 == null)
                return true;
            if (array1 == null || array2 == null)
                return false;

            int array1StartIndex = 0;
            int array2StartIndex = 0;
            int array1NonZeroLength = array1.Length;
            int array2NonZeroLength = array2.Length;

            if (array1NonZeroLength != array2NonZeroLength)
            {
                array1NonZeroLength = 0;
                array2NonZeroLength = 0;
                for (int i = 0; i < array1.Length; i++)
                {
                    if (array1[i] != 0)
                    {
                        array1StartIndex = i;
                        array1NonZeroLength = array1.Length - i;
                        break;
                    }
                }
                for (int i = 0; i < array2.Length; i++)
                {
                    if (array2[i] != 0)
                    {
                        array2StartIndex = i;
                        array2NonZeroLength = array2.Length - i;
                        break;
                    }
                }

                if (array1NonZeroLength != array2NonZeroLength)
                    return false;
            }

            for (int i = 0; i < array1NonZeroLength; i++)
            {
                if (array1[array1StartIndex + i] != array2[array2StartIndex + i])
                    return false;
            }

            return true;
        }
    }
}