﻿using System;
using System.Net;

namespace Pacom.Peripheral.Common
{
    public interface INetworkAdapter
    {
        void RebindAdapter();
        bool GetNetworkInformation(bool includeDnsInformation, out NetworkInformation networkInformation);
        NetworkInformation CurrentNetworkInformation { get; }
        void UpdateOnboardAdapter(IPAddress newIPAddress, IPAddress newSubnetMask, IPAddress newDefaultGateway, IPAddress newDnsServer, bool newUseDhcpServer);
    }
}
