﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Interface for accessing USB driver.
    /// </summary>
    public interface IUsbDevice
    {
        bool IsCableAttached { get; }
        bool AllowNewUsbConnection();
        event EventHandler<EventArgs> DeviceConnected;
        event EventHandler<EventArgs> DeviceDisconnected;
    }
}
