﻿using System;

namespace Pacom.Peripheral.Common
{
    public interface INandFlash
    {
        bool ApplyFirmwareUpdate(string filePath, int length, int crc, FirmwareVersion version, int buildNumber);
    }
}
