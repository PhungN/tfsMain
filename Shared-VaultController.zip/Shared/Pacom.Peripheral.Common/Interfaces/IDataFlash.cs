﻿
namespace Pacom.Peripheral.Common
{
    public interface IDataFlash
    {
        bool WriteData(int offset, byte[] data);
        bool WriteAndVerifyData(int offset, byte[] data);
        bool ReadData(int offset, byte[] data);
        byte[] ReadData(int offset, int length);
    }
}
