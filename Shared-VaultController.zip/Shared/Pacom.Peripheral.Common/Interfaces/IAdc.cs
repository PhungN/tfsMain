﻿
namespace Pacom.Peripheral.Common
{
    public interface IAdc
    {
        void SetAdcHitCounts(int[] hitCounts);
    }
}
