﻿
namespace Pacom.Peripheral.Common
{
    public interface IExpansionCardBase
    {
        /// <summary>
        /// Returns the current state (Secure/Alarm/Short/Open/Trouble) of an input point.
        /// </summary>
        /// <param name="inputNumber">The zero based input point of interest.</param>
        /// <returns>The current state (Secure/Alarm/Short/Open/Trouble) of the input point.</returns>
        InputStatus GetInputPointStatus(int inputNumber);
    }
}
