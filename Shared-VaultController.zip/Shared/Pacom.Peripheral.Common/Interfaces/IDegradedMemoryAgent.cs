﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pacom.Peripheral.AccessControl
{
    public enum DegradedMemoryAgentCommand : int
    {
        None,
        SavingStop,
        SavingNormal,
        SavingRunOnce,
        SavingRunOnceImmediately,
        SavingImmediately,
        LoadCardsImmediately
    }

    public enum DegradedMemoryAgentResultCode : int
    {
        Success = 0,
        CardLoadingInProgress,
        UnableToStartCardLoadingThread,
        UnableToAddCard,
        CardAlreadyExists,
        UnableToFindCard,
        CardDataNotProvided,
        InvalidLengthOfCardDataArray,
        UnableToDeleteCard,
        DegradedMemoryIsOffline
    }

    public interface IDegradedMemoryAgent
    {
        DegradedMemoryAgentResultCode ProcessCommand(DegradedMemoryAgentCommand method);
        DegradedMemoryAgentResultCode CardExists(byte[] cardData, int cardLength, out int pageIndex);
        DegradedMemoryAgentResultCode AddCard(byte[] cardData, int cardLength);
        DegradedMemoryAgentResultCode DeleteCard(byte[] cardData, int cardLength);
        DegradedMemoryAgentResultCode DeleteAll();
    }
}
