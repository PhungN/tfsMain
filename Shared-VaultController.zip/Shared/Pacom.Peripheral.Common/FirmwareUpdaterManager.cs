﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Pacom.Peripheral.Common
{
    public static class FirmwareUpdaterManager
    {
        public static event EventHandler<EventArgs> OnUpdate;
        public static event EventHandler<EventArgs> OnDownloadLocationCleanup;

        public const string DownloadLocation = "\\RestrictedRegion\\Download";

        public static void BeginUpdate()
        {
            if (OnUpdate != null)
            {
                OnUpdate(null, new EventArgs());
            }
        }

        public static void CleanupDownloadLocation()
        {
            if (OnDownloadLocationCleanup != null)
            {
                OnDownloadLocationCleanup(null, new EventArgs());
            }
        }

        private static Timer timer = null;

        public static void RequestDeviceUpdate()
        {
            timer = new Timer(requestDeviceUpdate, null, 3000, Timeout.Infinite);
        }

        private static void requestDeviceUpdate(object state)
        {
            try
            {
                timer.Dispose();
                FirmwareUpdaterManager.BeginUpdate();
            }
            catch (Exception ex)
            {
                FirmwareUpdaterManager.PostFirmwareChangeMessage = "Unexpected termination of firmware change. " + ex.Message;
            }
        }

        private static string postFirmwareChangeMessage = string.Empty;

        public static string PostFirmwareChangeMessage
        {
            get
            {
                return postFirmwareChangeMessage;
            }
            set
            {
                postFirmwareChangeMessage = value;
            }
        }
    }
}
