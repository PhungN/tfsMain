﻿using System;
using System.IO;

namespace Pacom.Peripheral.Common
{
    public static class Crc32
    {
        public const UInt32 Polynomial = 0xedb88320;
        public const UInt32 Seed = 0xffffffff;
        private static readonly UInt32[] defaultTable;

        static Crc32()
        {
            defaultTable = new UInt32[256];
            for (int i = 0; i < 256; i++)
            {
                UInt32 entry = (UInt32)i;
                for (int j = 0; j < 8; j++)
                    if ((entry & 1) == 1)
                        entry = (entry >> 1) ^ Polynomial;
                    else
                        entry = entry >> 1;
                defaultTable[i] = entry;
            }
        }

        public static byte[] ComputeHash(byte[] input, int offset, int length)
        {
            UInt32 hash = calculateHash(defaultTable, Seed, input, offset, length);
            return BitConverter.GetBytes(~hash);
        }

        public static byte[] ComputeHash(Stream input)
        {
            UInt32 hash = calculateHash(defaultTable, Seed, input);
            return BitConverter.GetBytes(~hash);
        }

        private static UInt32 calculateHash(UInt32[] table, UInt32 seed, Stream input)
        {
            UInt32 crc = seed;
            while (true)
            {
                int buffer = input.ReadByte();
                if (buffer == -1)
                    break;
                unchecked
                {
                    crc = (crc >> 8) ^ table[((byte)buffer ^ crc) & 0xff];
                }
            }
            return crc;
        }

        private static UInt32 calculateHash(UInt32[] table, UInt32 seed, byte[] buffer, int start, int size)
        {
            UInt32 crc = seed;
            for (int i = start; i < (size + start); i++)
                unchecked
                {
                    crc = (crc >> 8) ^ table[(buffer[i] ^ crc) & 0xff];
                }
            return crc;
        }
    }
}
