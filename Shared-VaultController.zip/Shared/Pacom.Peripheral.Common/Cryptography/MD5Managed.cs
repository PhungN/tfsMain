using System;
using System.Security;
using System.Security.Cryptography;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Note this class won't handle inputs greater than 512MB. Increase the size of count if it is required.
    /// </summary>
    public static class MD5Managed
    {
        public static byte[] ComputeHash(byte[] input, int offset, int length)
        {
            uint[] state = new uint[4];
            byte[] buffer = new byte[64];

            /* Load magic initialization constants. */
            state[0] = 0x67452301;
            state[1] = 0xefcdab89;
            state[2] = 0x98badcfe;
            state[3] = 0x10325476;

            /* Transform as many times as possible. */
            if (length >= 64)
            {
                for (uint i = 0; i + 63 < length; i += 64)
                {
                    md5Transform(state, input, (uint)(i + offset));
                }
            }

            byte[] bits = new byte[8];
            uint[] count = new uint[2];

            /* Update number of bits */
            count[0] = ((uint)length << 3);

            /* Code to support input lengths > 512MB */
            // count[1] += ((uint)length >> 29);

            /* Save number of bits */
            encode(bits, count, 8);

            /* Buffer remaining input and padding and length in bits */
            int remainingLength = length & 0x3F;
            int padLen = (remainingLength < 56) ? (56 - remainingLength) : (120 - remainingLength);
            if (padLen > 56)
            {
                /* two rounds of MD5Transform required as 128 bytes remain */
                Buffer.BlockCopy(input, length - remainingLength + offset, buffer, 0, remainingLength);
                buffer[remainingLength] = 0x80;
                remainingLength++;
                int paddingRemaining = 64 - remainingLength;
                for (int i = 0; i < paddingRemaining; i++)
                {
                    buffer[remainingLength + i] = 0;
                }
                md5Transform(state, buffer, 0);

                for (int i = 0; i < 56; i++)
                {
                    buffer[i] = 0;
                }
                Buffer.BlockCopy(bits, 0, buffer, 56, 8);
                md5Transform(state, buffer, 0);
            }
            else
            {
                /* one rounds of MD5Transform required as 64 bytes remain */
                Buffer.BlockCopy(input, length - remainingLength + offset, buffer, 0, remainingLength);
                buffer[remainingLength] = 0x80;
                remainingLength++;
                int paddingRemaining = 56 - remainingLength;
                for (int i = 0; i < paddingRemaining; i++)
                {
                    buffer[remainingLength + i] = 0;
                }
                Buffer.BlockCopy(bits, 0, buffer, 56, 8);
                md5Transform(state, buffer, 0);
            }

            /* Store state in digest */
            byte[] digest = new byte[16];
            encode(digest, state, 16);
            return digest;
        }

        /* Constants for MD5Transform routine. */
        private const int s11 = 7;
        private const int s12 = 12;
        private const int s13 = 17;
        private const int s14 = 22;
        private const int s21 = 5;
        private const int s22 = 9;
        private const int s23 = 14;
        private const int s24 = 20;
        private const int s31 = 4;
        private const int s32 = 11;
        private const int s33 = 16;
        private const int s34 = 23;
        private const int s41 = 6;
        private const int s42 = 10;
        private const int s43 = 15;
        private const int s44 = 21;

        /* F, G, H and I are basic MD5 functions. */
        private static uint F(uint x, uint y, uint z) { return (((x) & (y)) | ((~x) & (z))); }
        private static uint G(uint x, uint y, uint z) { return (((x) & (z)) | ((y) & (~z))); }
        private static uint H(uint x, uint y, uint z) { return ((x) ^ (y) ^ (z)); }
        private static uint I(uint x, uint y, uint z) { return ((y) ^ ((x) | (~z))); }

        /* ROTATE_LEFT rotates x left n bits. */
        private static uint rotateLeft(uint x, int n) { return (((x) << (n)) | ((x) >> (32 - (n)))); }

        /* FF, GG, HH, and II transformations for rounds 1, 2, 3, and 4.
           Rotation is separate from addition to prevent recomputation. */
        private static void ff(ref uint a, uint b, uint c, uint d, uint x, int s, uint ac)
        {
            (a) += F((b), (c), (d)) + (x) + (uint)(ac);
            (a) = rotateLeft((a), (s));
            (a) += (b);
        }
        private static void gg(ref uint a, uint b, uint c, uint d, uint x, int s, uint ac)
        {
            (a) += G((b), (c), (d)) + (x) + (uint)(ac);
            (a) = rotateLeft((a), (s));
            (a) += (b);
        }
        private static void hh(ref uint a, uint b, uint c, uint d, uint x, int s, uint ac)
        {
            (a) += H((b), (c), (d)) + (x) + (uint)(ac);
            (a) = rotateLeft((a), (s));
            (a) += (b);
        }
        private static void ii(ref uint a, uint b, uint c, uint d, uint x, int s, uint ac)
        {
            (a) += I((b), (c), (d)) + (x) + (uint)(ac);
            (a) = rotateLeft((a), (s));
            (a) += (b);
        }

        /* MD5 basic transformation. Transforms state based on block. */
        private static void md5Transform(uint[] state,
                                         byte[] block,
                                         uint blockIndex)
        {
            uint a = state[0], b = state[1], c = state[2], d = state[3];
            uint[] x = new uint[16];

            decode(x, block, blockIndex, 64);

            /* Round 1 */
            ff(ref a, b, c, d, x[0], s11, 0xd76aa478); /* 1 */
            ff(ref d, a, b, c, x[1], s12, 0xe8c7b756); /* 2 */
            ff(ref c, d, a, b, x[2], s13, 0x242070db); /* 3 */
            ff(ref b, c, d, a, x[3], s14, 0xc1bdceee); /* 4 */
            ff(ref a, b, c, d, x[4], s11, 0xf57c0faf); /* 5 */
            ff(ref d, a, b, c, x[5], s12, 0x4787c62a); /* 6 */
            ff(ref c, d, a, b, x[6], s13, 0xa8304613); /* 7 */
            ff(ref b, c, d, a, x[7], s14, 0xfd469501); /* 8 */
            ff(ref a, b, c, d, x[8], s11, 0x698098d8); /* 9 */
            ff(ref d, a, b, c, x[9], s12, 0x8b44f7af); /* 10 */
            ff(ref c, d, a, b, x[10], s13, 0xffff5bb1); /* 11 */
            ff(ref b, c, d, a, x[11], s14, 0x895cd7be); /* 12 */
            ff(ref a, b, c, d, x[12], s11, 0x6b901122); /* 13 */
            ff(ref d, a, b, c, x[13], s12, 0xfd987193); /* 14 */
            ff(ref c, d, a, b, x[14], s13, 0xa679438e); /* 15 */
            ff(ref b, c, d, a, x[15], s14, 0x49b40821); /* 16 */

            /* Round 2 */
            gg(ref a, b, c, d, x[1], s21, 0xf61e2562); /* 17 */
            gg(ref d, a, b, c, x[6], s22, 0xc040b340); /* 18 */
            gg(ref c, d, a, b, x[11], s23, 0x265e5a51); /* 19 */
            gg(ref b, c, d, a, x[0], s24, 0xe9b6c7aa); /* 20 */
            gg(ref a, b, c, d, x[5], s21, 0xd62f105d); /* 21 */
            gg(ref d, a, b, c, x[10], s22, 0x02441453); /* 22 */
            gg(ref c, d, a, b, x[15], s23, 0xd8a1e681); /* 23 */
            gg(ref b, c, d, a, x[4], s24, 0xe7d3fbc8); /* 24 */
            gg(ref a, b, c, d, x[9], s21, 0x21e1cde6); /* 25 */
            gg(ref d, a, b, c, x[14], s22, 0xc33707d6); /* 26 */
            gg(ref c, d, a, b, x[3], s23, 0xf4d50d87); /* 27 */
            gg(ref b, c, d, a, x[8], s24, 0x455a14ed); /* 28 */
            gg(ref a, b, c, d, x[13], s21, 0xa9e3e905); /* 29 */
            gg(ref d, a, b, c, x[2], s22, 0xfcefa3f8); /* 30 */
            gg(ref c, d, a, b, x[7], s23, 0x676f02d9); /* 31 */
            gg(ref b, c, d, a, x[12], s24, 0x8d2a4c8a); /* 32 */

            /* Round 3 */
            hh(ref a, b, c, d, x[5], s31, 0xfffa3942); /* 33 */
            hh(ref d, a, b, c, x[8], s32, 0x8771f681); /* 34 */
            hh(ref c, d, a, b, x[11], s33, 0x6d9d6122); /* 35 */
            hh(ref b, c, d, a, x[14], s34, 0xfde5380c); /* 36 */
            hh(ref a, b, c, d, x[1], s31, 0xa4beea44); /* 37 */
            hh(ref d, a, b, c, x[4], s32, 0x4bdecfa9); /* 38 */
            hh(ref c, d, a, b, x[7], s33, 0xf6bb4b60); /* 39 */
            hh(ref b, c, d, a, x[10], s34, 0xbebfbc70); /* 40 */
            hh(ref a, b, c, d, x[13], s31, 0x289b7ec6); /* 41 */
            hh(ref d, a, b, c, x[0], s32, 0xeaa127fa); /* 42 */
            hh(ref c, d, a, b, x[3], s33, 0xd4ef3085); /* 43 */
            hh(ref b, c, d, a, x[6], s34, 0x04881d05); /* 44 */
            hh(ref a, b, c, d, x[9], s31, 0xd9d4d039); /* 45 */
            hh(ref d, a, b, c, x[12], s32, 0xe6db99e5); /* 46 */
            hh(ref c, d, a, b, x[15], s33, 0x1fa27cf8); /* 47 */
            hh(ref b, c, d, a, x[2], s34, 0xc4ac5665); /* 48 */

            /* Round 4 */
            ii(ref a, b, c, d, x[0], s41, 0xf4292244); /* 49 */
            ii(ref d, a, b, c, x[7], s42, 0x432aff97); /* 50 */
            ii(ref c, d, a, b, x[14], s43, 0xab9423a7); /* 51 */
            ii(ref b, c, d, a, x[5], s44, 0xfc93a039); /* 52 */
            ii(ref a, b, c, d, x[12], s41, 0x655b59c3); /* 53 */
            ii(ref d, a, b, c, x[3], s42, 0x8f0ccc92); /* 54 */
            ii(ref c, d, a, b, x[10], s43, 0xffeff47d); /* 55 */
            ii(ref b, c, d, a, x[1], s44, 0x85845dd1); /* 56 */
            ii(ref a, b, c, d, x[8], s41, 0x6fa87e4f); /* 57 */
            ii(ref d, a, b, c, x[15], s42, 0xfe2ce6e0); /* 58 */
            ii(ref c, d, a, b, x[6], s43, 0xa3014314); /* 59 */
            ii(ref b, c, d, a, x[13], s44, 0x4e0811a1); /* 60 */
            ii(ref a, b, c, d, x[4], s41, 0xf7537e82); /* 61 */
            ii(ref d, a, b, c, x[11], s42, 0xbd3af235); /* 62 */
            ii(ref c, d, a, b, x[2], s43, 0x2ad7d2bb); /* 63 */
            ii(ref b, c, d, a, x[9], s44, 0xeb86d391); /* 64 */

            state[0] += a;
            state[1] += b;
            state[2] += c;
            state[3] += d;

            /* Zeroize sensitive information. */
            Array.Clear(x, 0, x.Length);
        }

        /* Encodes input (UINT4) into output (unsigned char). Assumes len is
           a multiple of 4. */
        private static void encode(byte[] output,
                                   uint[] input,
                                   uint len)
        {
            for (uint i = 0, j = 0; j < len; i++, j += 4)
            {
                output[j] = (byte)(input[i] & 0xff);
                output[j + 1] = (byte)((input[i] >> 8) & 0xff);
                output[j + 2] = (byte)((input[i] >> 16) & 0xff);
                output[j + 3] = (byte)((input[i] >> 24) & 0xff);
            }
        }

        /* Decodes input (unsigned char) into output (UINT4). Assumes len is
           a multiple of 4. */
        private static void decode(uint[] output,
                                   byte[] input,
                                   uint inputIndex,
                                   uint len)
        {
            for (uint i = 0, j = 0; j < len; i++, j += 4)
            {
                output[i] = ((uint)input[inputIndex + j]) |
                    (((uint)input[inputIndex + j + 1]) << 8) |
                    (((uint)input[inputIndex + j + 2]) << 16) |
                    (((uint)input[inputIndex + j + 3]) << 24);
            }
        }
    }
}
