﻿using System;
using System.Security.Cryptography;

namespace Pacom.Peripheral.Common
{
    public abstract class KeyedHashAlgorithm : HashAlgorithm
    {
        protected byte[] KeyValue;

        protected KeyedHashAlgorithm()
        {
        }

        public virtual byte[] Key
        {
            get { return KeyValue; }
            set
            {
                if (State != 0)
                    throw new CryptographicException("Hash key cannot be changed after the first write to the stream.");
                KeyValue = value;
            }
        }

        private bool disposed;
        protected override void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                // For keyed hash algorithms, we always want to zero out the key value
                if (disposing)
                {
                    if (KeyValue != null)
                        Array.Clear(KeyValue, 0, KeyValue.Length);
                    KeyValue = null;
                }
                disposed = true;
            }
            base.Dispose(disposing);
        }

        new static public KeyedHashAlgorithm Create()
        {
            return Create("System.Security.Cryptography.KeyedHashAlgorithm");
        }

        new static public KeyedHashAlgorithm Create(String algName)
        {
            return (KeyedHashAlgorithm)CryptoConfig.CreateFromName(algName);
        }
    }
}
