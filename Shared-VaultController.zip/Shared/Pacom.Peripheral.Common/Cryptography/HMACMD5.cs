﻿using System;
using System.Security.Cryptography;

namespace Pacom.Peripheral.Common
{
    public class HMACMD5 : HMAC
    {
        public HMACMD5(byte[] key)
            : base(key)
        {
        }

        protected override byte[] performHash(byte[] input, int offset, int length)
        {
            return MD5Managed.ComputeHash(input, offset, length);
        }

        public override int HashSize 
        {
            get
            {
                return 128;
            }
        }
    }
}