﻿using System;
using System.Security.Cryptography;

namespace Pacom.Peripheral.Common
{
    public class HMACSHA256 : HMAC
    {
        public HMACSHA256(byte[] key)
            : base(key)
        {
        }

        protected override byte[] performHash(byte[] input, int offset, int length)
        {
            return SHA256Managed.ComputeHash(input, offset, length);
        }

        public override int HashSize
        {
            get
            {
                return 256;
            }
        }
    }
}