﻿using System;
using System.Security.Cryptography;

namespace Pacom.Peripheral.Common
{
    [System.Runtime.InteropServices.ComVisible(true)]
    public abstract class HMAC
    {
        private readonly byte[] rgbInner = new byte[64];
        private readonly byte[] rgbOuter = new byte[64];
        protected readonly byte[] keyValue;

        public HMAC(byte[] key)
        {
            if (key.Length > 64)
            {
                keyValue = performHash(key, 0, key.Length);
            }
            else
            {
                keyValue = key;
            }
            // Compute rgbInner and rgbOuter.
            int i = 0;
            for (i = 0; i < 64; i++)
            {
                rgbInner[i] = 0x36;
                rgbOuter[i] = 0x5C;
            }
            for (i = 0; i < keyValue.Length; i++)
            {
                rgbInner[i] ^= keyValue[i];
                rgbOuter[i] ^= keyValue[i];
            }
        }

        protected abstract byte[] performHash(byte[] input, int offset, int length);

        public abstract int HashSize { get; }

        public byte[] Key
        {
            get { return keyValue; }
        }

        public byte[] ComputeHash(byte[] input, int offset, int length)
        {
            byte[] round1 = new byte[length + rgbInner.Length];
            Buffer.BlockCopy(rgbInner, 0, round1, 0, rgbInner.Length);
            Buffer.BlockCopy(input, offset, round1, rgbInner.Length, length);
            byte[] round1Hash = performHash(round1, 0, round1.Length);

            byte[] round2 = new byte[round1Hash.Length + rgbOuter.Length];
            Buffer.BlockCopy(rgbOuter, 0, round2, 0, rgbOuter.Length);
            Buffer.BlockCopy(round1Hash, 0, round2, rgbOuter.Length, round1Hash.Length);
            return performHash(round2, 0, round2.Length);
        }
    }
}