﻿using System;

namespace Pacom.Peripheral.Common
{
    public class InvalidCrc32Exception : Exception
    {
        public InvalidCrc32Exception()
        {
        }

        public InvalidCrc32Exception(string message)
            : base(message)
        {
        }

        public InvalidCrc32Exception(string message, Exception innerException)
            : base(message, innerException)
        {
        }

    }
}
