﻿using System;
using System.Security;
using System.Security.Cryptography;

namespace Pacom.Peripheral.Common
{
    [System.Runtime.InteropServices.ComVisible(true)]
    public static class SHA256Managed
    {
        private unsafe static void dwordFromBigEndian(uint* x, int digits, byte* block)
        {
            int i;
            int j;

            for (i = 0, j = 0; i < digits; i++, j += 4)
                x[i] = (uint)((block[j] << 24) | (block[j + 1] << 16) | (block[j + 2] << 8) | block[j + 3]);
        }

        private static void dwordToBigEndian(byte[] block, uint[] x, int digits)
        {
            int i;
            int j;

            for (i = 0, j = 0; i < digits; i++, j += 4)
            {
                block[j] = (byte)((x[i] >> 24) & 0xff);
                block[j + 1] = (byte)((x[i] >> 16) & 0xff);
                block[j + 2] = (byte)((x[i] >> 8) & 0xff);
                block[j + 3] = (byte)(x[i] & 0xff);
            }
        }

        public unsafe static byte[] ComputeHash(byte[] input, int offset, int length)
        {
            int partInLen = length;
            int partInBase = offset;

            UInt32[] _stateSHA256 = new UInt32[8];
            _stateSHA256[0] = 0x6a09e667;
            _stateSHA256[1] = 0xbb67ae85;
            _stateSHA256[2] = 0x3c6ef372;
            _stateSHA256[3] = 0xa54ff53a;
            _stateSHA256[4] = 0x510e527f;
            _stateSHA256[5] = 0x9b05688c;
            _stateSHA256[6] = 0x1f83d9ab;
            _stateSHA256[7] = 0x5be0cd19;


            byte[] _buffer = new byte[64];
            UInt32[] _expandedBuffer = new UInt32[64];

            byte[] pad;
            int padLen;
            long bitCount;

            padLen = 64 - (int)(length & 0x3f);
            if (padLen <= 8)
                padLen += 64;

            pad = new byte[padLen];
            pad[0] = 0x80;

            //  Convert count to bit count
            bitCount = length * 8;

            pad[padLen - 8] = (byte)((bitCount >> 56) & 0xff);
            pad[padLen - 7] = (byte)((bitCount >> 48) & 0xff);
            pad[padLen - 6] = (byte)((bitCount >> 40) & 0xff);
            pad[padLen - 5] = (byte)((bitCount >> 32) & 0xff);
            pad[padLen - 4] = (byte)((bitCount >> 24) & 0xff);
            pad[padLen - 3] = (byte)((bitCount >> 16) & 0xff);
            pad[padLen - 2] = (byte)((bitCount >> 8) & 0xff);
            pad[padLen - 1] = (byte)((bitCount >> 0) & 0xff);

            fixed (uint* stateSHA256 = _stateSHA256)
            {
                fixed (byte* buffer = _buffer)
                {
                    fixed (uint* expandedBuffer = _expandedBuffer)
                    {
                        /* Copy input to temporary buffer and hash */
                        while (partInLen >= 64)
                        {
                            Buffer.BlockCopy(input, partInBase, _buffer, 0, 64);
                            partInBase += 64;
                            partInLen -= 64;
                            shaTransform(expandedBuffer, stateSHA256, buffer);
                        }

                        // padding is between 9 and 72 bytes, partInLen is between 0 and 63 bytes
                        // padding + partInLen = 64 or 128
                        Buffer.BlockCopy(input, partInBase, _buffer, 0, partInLen);
                        Buffer.BlockCopy(pad, 0, _buffer, partInLen, 64 - partInLen);
                        shaTransform(expandedBuffer, stateSHA256, buffer);

                        // remaining padding is either 0 or 64 bytes
                        if ((padLen + partInLen) == 128)
                        {
                            Buffer.BlockCopy(pad, 64 - partInLen, _buffer, 0, 64);
                            shaTransform(expandedBuffer, stateSHA256, buffer);
                        }
                    }
                }
            }

            byte[] hash = new byte[32];
            dwordToBigEndian(hash, _stateSHA256, 8);
            return hash;
        }

        private readonly static UInt32[] k = {
            0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
            0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
            0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
            0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
            0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
            0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
            0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
            0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
            0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
            0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
            0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
            0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
            0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
            0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
            0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
            0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
        };

        private static unsafe void shaTransform(uint* expandedBuffer, uint* state, byte* block)
        {
            UInt32 a, b, c, d, e, f, h, g;
            UInt32 aa, bb, cc, dd, ee, ff, hh, gg;
            UInt32 T1;

            a = state[0];
            b = state[1];
            c = state[2];
            d = state[3];
            e = state[4];
            f = state[5];
            g = state[6];
            h = state[7];

            // fill in the first 16 bytes of W.
            dwordFromBigEndian(expandedBuffer, 16, block);
            sha256Expand(expandedBuffer);

            /* Apply the SHA256 compression function */
            // We are trying to be smart here and avoid as many copies as we can
            // The perf gain with this method over the straightforward modify and shift 
            // forward is >= 20%, so it's worth the pain
            for (int j = 0; j < 64; )
            {
                T1 = h + Sigma_1(e) + ch(e, f, g) + k[j] + expandedBuffer[j];
                ee = d + T1;
                aa = T1 + Sigma_0(a) + maj(a, b, c);
                j++;

                T1 = g + Sigma_1(ee) + ch(ee, e, f) + k[j] + expandedBuffer[j];
                ff = c + T1;
                bb = T1 + Sigma_0(aa) + maj(aa, a, b);
                j++;

                T1 = f + Sigma_1(ff) + ch(ff, ee, e) + k[j] + expandedBuffer[j];
                gg = b + T1;
                cc = T1 + Sigma_0(bb) + maj(bb, aa, a);
                j++;

                T1 = e + Sigma_1(gg) + ch(gg, ff, ee) + k[j] + expandedBuffer[j];
                hh = a + T1;
                dd = T1 + Sigma_0(cc) + maj(cc, bb, aa);
                j++;

                T1 = ee + Sigma_1(hh) + ch(hh, gg, ff) + k[j] + expandedBuffer[j];
                h = aa + T1;
                d = T1 + Sigma_0(dd) + maj(dd, cc, bb);
                j++;

                T1 = ff + Sigma_1(h) + ch(h, hh, gg) + k[j] + expandedBuffer[j];
                g = bb + T1;
                c = T1 + Sigma_0(d) + maj(d, dd, cc);
                j++;

                T1 = gg + Sigma_1(g) + ch(g, h, hh) + k[j] + expandedBuffer[j];
                f = cc + T1;
                b = T1 + Sigma_0(c) + maj(c, d, dd);
                j++;

                T1 = hh + Sigma_1(f) + ch(f, g, h) + k[j] + expandedBuffer[j];
                e = dd + T1;
                a = T1 + Sigma_0(b) + maj(b, c, d);
                j++;
            }

            state[0] += a;
            state[1] += b;
            state[2] += c;
            state[3] += d;
            state[4] += e;
            state[5] += f;
            state[6] += g;
            state[7] += h;
        }

        private static UInt32 rotateRight(UInt32 x, int n)
        {
            return (((x) >> (n)) | ((x) << (32 - (n))));
        }

        private static UInt32 ch(UInt32 x, UInt32 y, UInt32 z)
        {
            return ((x & y) ^ ((x ^ 0xffffffff) & z));
        }

        private static UInt32 maj(UInt32 x, UInt32 y, UInt32 z)
        {
            return ((x & y) ^ (x & z) ^ (y & z));
        }

        private static UInt32 sigma_0(UInt32 x)
        {
            return (rotateRight(x, 7) ^ rotateRight(x, 18) ^ (x >> 3));
        }

        private static UInt32 sigma_1(UInt32 x)
        {
            return (rotateRight(x, 17) ^ rotateRight(x, 19) ^ (x >> 10));
        }

        private static UInt32 Sigma_0(UInt32 x)
        {
            return (rotateRight(x, 2) ^ rotateRight(x, 13) ^ rotateRight(x, 22));
        }

        private static UInt32 Sigma_1(UInt32 x)
        {
            return (rotateRight(x, 6) ^ rotateRight(x, 11) ^ rotateRight(x, 25));
        }

        /* This function creates W_16,...,W_63 according to the formula
           W_j <- sigma_1(W_{j-2}) + W_{j-7} + sigma_0(W_{j-15}) + W_{j-16};
        */

        private static unsafe void sha256Expand(uint* x)
        {
            for (int i = 16; i < 64; i++)
            {
                x[i] = sigma_1(x[i - 2]) + x[i - 7] + sigma_0(x[i - 15]) + x[i - 16];
            }
        }
    }
}