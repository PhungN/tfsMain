﻿using System;
using System.IO;

namespace Pacom.Peripheral.Common
{
    public static class Crc16Ccitt
    {
        const ushort poly = 0x1021;
        static readonly ushort[] table = new ushort[256];

        /// <summary>
        /// Return array with CRC table
        /// </summary>
        public static ushort[] Table
        {
            get
            {
                return table;
            }
        }

        public static ushort ComputeChecksum(byte[] bytes, int index, int count)
        {
            ushort crc = 0x1D0F; // !!! Initialize with this to not need the 16 bit zeroes at the end
            for (int i = index; i < index + count; i++)
            {
                byte tmp = (byte)((crc >> 8) ^ bytes[i]);
                crc = (ushort)((crc << 8) ^ table[tmp]);
            }
            return crc;
        }

        public static ushort ComputeChecksum(string fileName)
        {
            ushort crc = 0x1D0F; // !!! Initialize with this to not need the 16 bit zeroes at the end
            byte[] bytes = new byte[1024];
            using (FileStream fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                while (true)
                {
                    int readBytes = fileStream.Read(bytes, 0, bytes.Length);
                    if (readBytes == 0)
                        break;

                    for (int i = 0; i < readBytes; i++)
                    {
                        byte tmp = (byte)((crc >> 8) ^ bytes[i]);
                        crc = (ushort)((crc << 8) ^ table[tmp]);
                    }
                }
            }
            return crc;
        }

        public static byte[] ComputeChecksumBytes(byte[] bytes, int index, int count)
        {
            ushort crc = ComputeChecksum(bytes, index, count);
            return BitConverter.GetBytes(crc);
        }

        static Crc16Ccitt()
        {
            ushort crc, c;
            for (int i = 0; i < 256; i++)
            {
                crc = 0;
                c = (ushort)(i << 8);

                for (int j = 0; j < 8; j++)
                {
                    if (((crc ^ c) & 0x8000) != 0)
                        crc = (ushort)((crc << 1) ^ poly);
                    else
                        crc = (ushort)(crc << 1);
                    c = (ushort)(c << 1);
                }
                table[i] = crc;
            }
        }
    }
}