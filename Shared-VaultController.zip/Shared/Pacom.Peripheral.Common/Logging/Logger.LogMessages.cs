﻿using Pacom.Configuration.ConfigurationCommon;
#if CONTROLLER
using Pacom.Peripheral.Common.Configuration;
#endif

namespace Pacom.Peripheral.Common
{
    public static partial class Logger
    {
        /// <summary>
        /// Public delegate used to supply message string to logger.
        /// </summary>
        /// <returns></returns>
        public delegate string LoggerDelegate();

        /// <summary>
        /// Adds a generic critical message to the log file. Expect message string via callback. 
        /// </summary>
        /// <param name="prefix">Prefix for the message to appear with.</param>
        /// <param name="callback">Function with string callback.</param>
        public static void LogCriticalMessage(LoggerClassPrefixes prefix, LoggerDelegate callback)
        {
            if (Logger.LoggingLevel < LoggingLevel.Critical)
                return;

            try
            {
                logMessage(LoggingLevel.Critical, string.Format("{0}{1}", LoggerClassPrefixesDescriptions.GetString(prefix), callback()));
            }
            catch
            {
                logMessage(LoggingLevel.Critical, string.Format("{0}: Logging exception with critical level", LoggerClassPrefixesDescriptions.GetString(prefix)));
            }
        }
                
        /// <summary>
        /// Adds a generic error message to the log file. Expect message string via callback. 
        /// </summary>
        /// <param name="prefix">Prefix for the message to appear with.</param>
        /// <param name="callback">Function with string callback.</param>
        public static void LogErrorMessage(LoggerClassPrefixes prefix, LoggerDelegate callback)
        {
            if (Logger.LoggingLevel < LoggingLevel.Error)
                return;

            try
            {
                logMessage(LoggingLevel.Error, string.Format("{0}{1}", LoggerClassPrefixesDescriptions.GetString(prefix), callback()));
            }
            catch
            {
                logMessage(LoggingLevel.Error, string.Format("{0}: Logging exception with error level", LoggerClassPrefixesDescriptions.GetString(prefix)));
            }
        }

        /// <summary>
        /// Adds a generic warn message to the log file. Expect message string via callback. 
        /// </summary>
        /// <param name="prefix">Prefix for the message to appear with.</param>
        /// <param name="callback">Function with string callback.</param>
        public static void LogWarnMessage(LoggerClassPrefixes prefix, LoggerDelegate callback)
        {
            if (Logger.LoggingLevel < LoggingLevel.Warn)
                return;

            try
            {
                logMessage(LoggingLevel.Warn, string.Format("{0}{1}", LoggerClassPrefixesDescriptions.GetString(prefix), callback()));
            }
            catch
            {
                logMessage(LoggingLevel.Warn, string.Format("{0}: Logging exception with warning level.", LoggerClassPrefixesDescriptions.GetString(prefix)));
            }
        }

        /// <summary>
        /// Adds a generic debug message to the log file. Expect message string via callback. 
        /// This function will not check the debug level.
        /// </summary>
        /// <param name="prefix">Prefix for the message to appear with.</param>
        /// <param name="callback">Function with string callback.</param>
        public static void LogDebugMessage(LoggerClassPrefixes prefix, LoggerDelegate callback)
        {
            if (Logger.LoggingLevel < LoggingLevel.Debug)
                return;

            try
            {
                logMessage(LoggingLevel.Debug, string.Format("{0}{1}", LoggerClassPrefixesDescriptions.GetString(prefix), callback()));
            }
            catch
            {
                logMessage(LoggingLevel.Debug, string.Format("{0}: Logging exception with debug level.", LoggerClassPrefixesDescriptions.GetString(prefix)));
            }
        }

        /// <summary>
        /// Adds a generic debug message to the log file. Expect message string via callback. 
        /// This function will not check the debug level.
        /// </summary>
        /// <param name="prefix">Prefix for the message to appear with.</param>
        /// <param name="expectedDebugSubCategory">The debug subcategory for which the message should appear in the log.</param>
        /// <param name="callback">Function with string callback.</param>
        public static void LogDebugMessage(LoggerClassPrefixes prefix, DebugLoggingSubCategory expectedDebugSubCategory, LoggerDelegate callback)
        {
            if (Logger.LoggingLevel < LoggingLevel.Debug)
                return;
            try
            {
#if CONTROLLER
                if (ConfigurationManager.Instance.IsDebugLoggingSubCategoryEnabled(expectedDebugSubCategory) == false)
                    return;
#endif
                logMessage(LoggingLevel.Debug, string.Format("{0}{1}", LoggerClassPrefixesDescriptions.GetString(prefix), callback()));
            }
            catch
            {
                logMessage(LoggingLevel.Debug, string.Format("{0}: Logging exception with debug level", LoggerClassPrefixesDescriptions.GetString(prefix)));
            }
        }

        /// <summary>
        /// Adds a new trace comms message to the log file. Expect message string via callback. 
        /// This function will not check the debug level. Trace comms is extended debug level.
        /// </summary>
        /// <param name="prefix">Prefix for the message to appear with.</param>
        /// <param name="callback">Function with string callback.</param>
        public static void LogTracedCommsMessage(LoggerClassPrefixes prefix, LoggerDelegate callback)
        {
            if (Logger.LoggingLevel < LoggingLevel.TracedComms)
                return;

            try
            {
                logMessage(LoggingLevel.TracedComms, string.Format("{0}{1}", LoggerClassPrefixesDescriptions.GetString(prefix), callback()));
            }
            catch
            {
                logMessage(LoggingLevel.TracedComms, string.Format("{0}: Logging exception with trace comms level.", LoggerClassPrefixesDescriptions.GetString(prefix)));
            }
        }

        /// <summary>
        /// Adds a new trace comms message to the log file. Expect message string via callback. 
        /// </summary>
        /// <param name="prefix">Prefix for the message to appear with.</param>
        /// <param name="expectedDebugSubCategory">The debug subcategory for which the message should appear in the log.</param>
        /// <param name="callback">Function with string callback.</param>
        public static void LogTracedCommsMessage(LoggerClassPrefixes prefix, DebugLoggingSubCategory expectedDebugSubCategory, LoggerDelegate callback)
        {
            if (Logger.LoggingLevel < LoggingLevel.TracedComms)
                return;

            try
            {
#if CONTROLLER
            if (ConfigurationManager.Instance.IsDebugLoggingSubCategoryEnabled(expectedDebugSubCategory) == false)
                return;
#endif
                logMessage(LoggingLevel.TracedComms, string.Format("{0}{1}", LoggerClassPrefixesDescriptions.GetString(prefix), callback()));
            }
            catch
            {
                logMessage(LoggingLevel.TracedComms, string.Format("{0}: Logging exception with trace comms level.", LoggerClassPrefixesDescriptions.GetString(prefix)));
            }
        }
    }
}
