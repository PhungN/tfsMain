﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Input status list
    /// </summary>
    public partial class InputStatusList
    {
        private readonly object statusListSync = new object();

        private SortedList<int, InputStatus> statusList = null;

        public StatusManager Parent = null;

        /// <summary>
        /// Triggers when the state (Secure/Alarm/Short/Open/Trouble/Analog) of an input changes without hinding its state.
        /// </summary>
        public event EventHandler<InputChangedStatusEventArgs> UnmaskedInputChangedStatus;

        internal InputStatusList(StatusManager parent)
        {
            statusList = new SortedList<int, InputStatus>();
            this.Parent = parent;
        }

        /// <summary>
        /// Add new input to the list.
        /// </summary>
        /// <param name="logicalId">New input logical Id</param>
        internal void CreateInput(int logicalId)
        {
            InputStatus inputStatus = new InputStatus(logicalId);
            statusList.Add(logicalId, inputStatus);
        }

        /// <summary>
        /// Return theinput status list elements as an array that can be iterated independently
        /// </summary>
        public InputStatus[] Items
        {
            get
            {
                lock (statusListSync)
                {
                    return statusList.Values.ToArray();
                }
            }
        }

        /// <summary>
        /// Return input status object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <returns>Node status instance or null if not found</returns>
        public virtual InputStatus this[int logicalId]
        {
            get
            {
                lock (statusListSync)
                {
                    if (logicalId < 1 || statusList == null || statusList.Count < 1)
                        return null;
                    InputStatus inputItem = null;
                    statusList.TryGetValue(logicalId, out inputItem);
                    return inputItem;
                }
            }
        }

        /// <summary>
        /// Trigger input changed status event handler
        /// </summary>
        /// <param name="inputStatus">The Input Status that changed.</param>
        /// <param name="previousStatus">Previous input status.</param>
        /// <param name="owner">Owner of the input</param>
        /// <param name="pointNumberOnParent">Point number on the owner.</param>
        /// <returns>Returns True when the change has been handled successfully.</returns>
        internal bool TriggerChangedUnmaskedStatus(Status.InputStatus inputStatus, Common.InputStatus previousStatus, OwnerType owner, int pointNumberOnParent)
        {
			if (IsElevatorInput == true)
            {
				if (owner == OwnerType.Onboard)
                {
                    int legacyPointNumberOnParent = ConfigurationManager.Instance.Inputs.LogicalInputId(owner, pointNumberOnParent) - 1;
                    Parent.DeviceResponseProcessor.SendLegacyInputChangedStateAlarm(inputStatus, owner, pointNumberOnParent, legacyPointNumberOnParent);
                }
                return StatusManager.Instance.Outputs.TriggerElevatorOutput(pointNumberOnParent);
            }
			
            try
            {
                if (UnmaskedInputChangedStatus != null)
                    UnmaskedInputChangedStatus(this, new InputChangedStatusEventArgs(inputStatus, owner, pointNumberOnParent));
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while processing masked status change for input with logical Id {0}. {1}", inputStatus.LogicalId, ex.Message);
                });
            }

            InputConfiguration inputConfig = ConfigurationManager.Instance.Inputs[inputStatus.LogicalId];
            if (inputConfig.ReportPoint == false)
            {
                // Don't report this point if not configured
                return false;
            }

            try
            {
                if (ConfigurationManager.Instance.ControllerMessaging.Has(MessagingFlags.RestoreDefaultsAndSwitchAllReportingToExtendedFormat)
                    || ConfigurationManager.Instance.ControllerMessaging.Has(MessagingFlags.SwitchInputStatusReportingToExtendedFormat))
                {
                    Parent.DeviceResponseProcessor.SendInputChangedStateAlarm(inputStatus, owner, pointNumberOnParent);
                    return true;
                }
                else
                {
                    if (owner == OwnerType.Onboard ||
                        owner == OwnerType.Expansion1 || owner == OwnerType.Expansion2) // The message will not support more
                    {
                        int legacyPointNumberOnParent = ConfigurationManager.Instance.Inputs.LogicalInputId(owner, pointNumberOnParent) - 1;
                        Parent.DeviceResponseProcessor.SendLegacyInputChangedStateAlarm(inputStatus, owner, pointNumberOnParent, legacyPointNumberOnParent);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while sending status change for input with logical Id {0}. {1}", inputStatus.LogicalId, ex.Message);
                });
            }
            return false;
        }

        /// <summary>
        /// Trigger analog input changed status event handler
        /// </summary>
        /// <param name="inputStatus">The Input Status that changed.</param>
        /// <param name="previousValue">Previous input analog value.</param>
        /// <param name="owner">Owner of the input</param>
        /// <param name="pointNumberOnParent">Point number on the owner.</param>
        /// <returns>Returns True when the change has been handled successfully.</returns>
        internal bool TriggerChangedAnalogValue(Status.InputStatus inputStatus, int previousValue, OwnerType owner, int pointNumberOnParent)
        {
            try
            {
                if (ConfigurationManager.Instance.Expansions.IsOwnerExpansionCard(owner) == false)
                    return false;

                if (ConfigurationManager.Instance.ControllerMessaging.Has(MessagingFlags.RestoreDefaultsAndSwitchAllReportingToExtendedFormat))
                {
                    Status.InputStatus[] statuses = new InputStatus[1];
                    statuses[0] = inputStatus;
                    Parent.DeviceResponseProcessor.SendAnalogInputChangedAlarm(statuses);
                }
                else
                {
                    int legacyPointNumberOnParent = ConfigurationManager.Instance.Inputs.LogicalInputId(owner, pointNumberOnParent) - 1;
                    Parent.DeviceResponseProcessor.SendLegacyAnalogInputChangedAlarm(inputStatus, owner, pointNumberOnParent, legacyPointNumberOnParent);
                }
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while sending analog status change for input with logical Id {0}. {1}", inputStatus.LogicalId, ex.Message);
                });
            }
            return false;
        }
    }
}
