﻿using System;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;
using CardReaderConsts = Pacom.Peripheral.AccessControl.CardReaderHardwareLocations;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// This class provides a central repository for statuses storage during lifetime of the application.
    /// </summary>
    public class StatusManager
    {
        /// <summary>
        /// Public delegate used to supply input status to the status manager functions.
        /// </summary>
        /// <param name="inputNumber">Input number.</param>
        /// <returns>Returns input status.</returns>
        public delegate Common.InputStatus StatusManagerQueryInputDelegate(int inputNumber);

        /// <summary>
        /// Public delegate used to supply slot number to the status manager functions.
        /// </summary>
        /// <param name="slotNumber">Slot number.</param>
        /// <returns>Returns input status.</returns>
        public delegate IExpansionCardBase StatusManagerQuerySlotDelegate(int slotNumber);

        /// <summary>
        /// Public delegate used to supply expansion card input number to the status manager functions.
        /// </summary>
        /// <param name="card">Parent expansion card.</param>
        /// <param name="inputNumber">Input number.</param>
        /// <returns>Returns input status.</returns>
        public delegate Common.InputStatus StatusManagerQueryInputOnExpansionCardDelegate(IExpansionCardBase card, int inputNumber);

        #region Instance management

        /// <summary>
        /// Status Manager only instance
        /// </summary>
        private static StatusManager instance = null;

        /// <summary>
        /// StatusManager instance creation. This should only be called once in order to
        /// create the StatusManager. After that the Instance property should be used to 
        /// access the StatusManager.
        /// </summary>
        /// <returns></returns>
        public static StatusManager CreateInstance()
        {
            if (instance == null)
            {
                instance = new StatusManager();
            }
            return instance;
        }

        /// <summary>
        /// Status Manager instance accessor
        /// </summary>
        public static StatusManager Instance
        {
            get
            {
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                    {
                        return "Instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
                return instance;
            }
        }

        private StatusManager()
        {
            device = new DeviceStatus();
            doors = new DoorStatusList(this);
            readers = new ReaderStatusList(this);
            
#if DEBUG
            if (ConfigurationManager.DoorsCount != CardReaderConsts.HandledLogicalDoorIds.Length)
            {
                string message = "The door count between software and hardware configuration does not much. Developer please fix!!!";
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return message;
                });
                throw new Exception(message);
            }
#endif
            // Add doors
            int entryReader, exitReader;
            foreach (int doorLogicalId in CardReaderConsts.HandledLogicalDoorIds)
            {
                entryReader = CardReaderConsts.DoorReadersIds[doorLogicalId][CardReaderConsts.DoorEntryReaderIndex];
                exitReader = CardReaderConsts.DoorReadersIds[doorLogicalId][CardReaderConsts.DoorExitReaderIndex];
                doors.CreateDoor(doorLogicalId, entryReader, exitReader);
                readers.CreateReader(entryReader, doors[doorLogicalId]);
                readers.CreateReader(exitReader, doors[doorLogicalId]);
            }                        

            // Add expansion slots
            expansionCards = new ExpansionCardStatusList(this);
            for (int slotNumber = 0; slotNumber < ConfigurationManager.ExpansionSlotCount; slotNumber++)
            {
                // Create card status
                expansionCards.CreateExpansionCard(slotNumber + 1, ExpansionCardType.None);
            }

            // Add inputs
            inputs = new InputStatusList(this);
            for (int inputNumber = 0; inputNumber < ConfigurationManager.InputsCount; inputNumber++)
            {
                inputs.CreateInput(inputNumber + 1); 
            }
            
            // Add outputs
            outputs = new OutputStatusList(this);
            for (int outputNumber = 0; outputNumber < ConfigurationManager.OutputsCount; outputNumber++)
            {
                outputs.CreateOutput(outputNumber + 1); 
            }

            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return "Created.";
            });
        }
          
        #endregion
                
        public IDeviceResponseProcessor DeviceResponseProcessor = null;

        public void SetDeviceResponseProcessor(IDeviceResponseProcessor deviceResponseProcessor)
        {
            this.DeviceResponseProcessor = deviceResponseProcessor;

            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, DebugLoggingSubCategory.Status, () =>
            {
                return "Ready to respond.";
            });
        }

        private DeviceStatus device = null;

        private DoorStatusList doors = null;

        private ReaderStatusList readers = null;

        private ExpansionCardStatusList expansionCards = null;

        private InputStatusList inputs = null;

        private OutputStatusList outputs = null;

        #region Output containers

        private IOutputContainer onboardOutputs = null;

        internal IOutputContainer OnboardOutputs
        {
            get
            {
                return onboardOutputs;
            }
        }

        private IExpansionCardManager expansionManager = null;

        internal IExpansionCardManager ExpansionCardManager
        {
            get
            {
                return expansionManager;
            }
        }

        #endregion

         /// <summary>
        /// Get the device status
        /// </summary>
        public DeviceStatus Device
        {
            get { return device; }
        }
                
        /// <summary>
        /// Get doors list
        /// </summary>
        public DoorStatusList Doors
        {
            get { return doors; }
        }

        /// <summary>
        ///  Get readers list
        /// </summary>
        public ReaderStatusList Readers
        {
            get { return readers; }
        }

        /// <summary>
        ///  Get expansion card list
        /// </summary>
        public ExpansionCardStatusList ExpansionCards
        {
            get { return expansionCards; }
        }

        /// <summary>
        ///  Get input list
        /// </summary>
        public InputStatusList Inputs
        {
            get { return inputs; }
        }

        /// <summary>
        ///  Get output list
        /// </summary>
        public OutputStatusList Outputs
        {
            get { return outputs; }
        }

        /// <summary>
        /// Assign an onboard output container instance. It will be used to trigger outputs.
        /// </summary>
        /// <param name="onboardOutputs">An instance of the container.</param>
        public void SetOnboardOutputs(IOutputContainer onboardOutputs)
        {
            this.onboardOutputs = onboardOutputs;
        }

        /// <summary>
        /// Set initial inputs states for the specified owner.
        /// </summary>
        /// <param name="provideInputNumber">Delegate requesting input status.</param>
        public void SetOnboardInputs(StatusManagerQueryInputDelegate provideInputNumber)
        {
            if (provideInputNumber == null)
                return;
            try
            {
                int numberOfInputs = ConfigurationManager.Instance.Inputs.InputsCountForOwner(OwnerType.Onboard);
                for (int i = 0; i < numberOfInputs; i++)
                {   
                    int inputLogicalId = ConfigurationManager.Instance.Inputs.LogicalInputId(OwnerType.Onboard, i);
                    var inputState = provideInputNumber(i);
                    Inputs[inputLogicalId].Change(inputState, 0);
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while setting onboard inputs. {0}", ex.Message);
                });
            }
         }

        /// <summary>
        /// Set initial inputs states for the specified owner.
        /// </summary>
        /// <param name="owners"></param>
        /// <param name="provideInputNumber"></param>
        public void SetInputs<T>(OwnerType[] owners, 
            StatusManagerQuerySlotDelegate provideExpansionCard,
            StatusManagerQueryInputOnExpansionCardDelegate provideInputNumber)
        {
            if (provideExpansionCard == null || provideInputNumber == null || expansionManager == null)
                return;
            try
            {
                foreach (var owner in owners)
                {
                    IExpansionCardBase card = provideExpansionCard(((int)owner - (int)OwnerType.Expansion1));
                    if (card == null)
                        continue;
                    int numberOfInputs = ConfigurationManager.Instance.Inputs.InputsCountForOwner(owner);
                    for (int i = 0; i < numberOfInputs; i++)
                    {   
                        int inputLogicalId = ConfigurationManager.Instance.Inputs.LogicalInputId(owner, i);
                        var inputState = provideInputNumber(card, i);
                        Inputs[inputLogicalId].Change(inputState, 0);
                    }    
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while setting onboard inputs. {0}", ex.Message);
                });
            }
        }

        /// <summary>
        /// Assign an expansion manager instance.
        /// </summary>
        /// <param name="expansionManager"></param>
        public void SetExpansionManager(IExpansionCardManager expansionManager)
        {
            this.expansionManager = expansionManager;
        }
    }
}
