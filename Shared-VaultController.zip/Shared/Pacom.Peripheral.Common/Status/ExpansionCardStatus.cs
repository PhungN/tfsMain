﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    public class ExpansionCardStatus
    {
        internal ExpansionCardStatus(int logicalId, ExpansionCardType type)
        {
            this.logicalId = logicalId;
            this.type = type;
        }
        
        private readonly int logicalId;

        /// <summary>
        /// Get expansion card logical Id
        /// </summary>
        public int LogicalId
        {
            get { return logicalId; }
        }

        private ExpansionCardType type = ExpansionCardType.None;

        /// <summary>
        /// Get expansion card type
        /// </summary>
        public ExpansionCardType Type
        {
            get
            {
                return this.type;
            }
            set
            {
                this.type = value;
            }
        }
        
        /// <summary>
        /// Receive new expansion card status
        /// </summary>
        public void SetStatus(Common.ExpansionCardStatus expansionManagerStatus)
        {
            switch (expansionManagerStatus)
            {
                case Common.ExpansionCardStatus.Online:
                    Online = true;
                    FuseFailed = false;
                    break;
                case Common.ExpansionCardStatus.Offline:
                    Online = false;
                    break;
                case Common.ExpansionCardStatus.FuseFail:
                    if (Online == false)
                        Online = true;
                    FuseFailed = true;
                    break;
                case Common.ExpansionCardStatus.Unknown:
                    Online = false;
                    FuseFailed = false;
                    break;
            }
        }

        private bool online = false;

        /// <summary>
        /// Get / Set expansion card online / offline status
        /// </summary>
        public bool Online
        {
            get { return online; }
            private set
            {
                try
                {
                    if (online != value)
                    {
                        online = value;
                        StatusManager.Instance.ExpansionCards.TriggerExpansionCardStatusNotification();
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                    {
                        return string.Format("Error while setting expansion card status. {0}", ex.Message);
                    });
                }
            }
        }

        private bool fuseFailed = false;

        /// <summary>
        /// Get / Set expansion card fuse failed status
        /// </summary>
        public bool FuseFailed
        {
            get { return this.fuseFailed; }
            private set
            {
                try
                {
                    if (fuseFailed != value)
                    {
                        fuseFailed = value;
                        StatusManager.Instance.ExpansionCards.TriggerExpansionCardStatusNotification();
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                    {
                        return string.Format("Error while setting expansion card fuse status. {0}", ex.Message);
                    });
                }
            }
        }
    }
}
