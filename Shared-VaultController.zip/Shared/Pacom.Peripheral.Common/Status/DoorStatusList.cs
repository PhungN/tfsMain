﻿using System.Collections.Generic;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Door list
    /// </summary>
    public class DoorStatusList
    {
        private readonly object statusListSync = new object();

        private SortedList<int, DoorStatus> statusList = null;

        public StatusManager Parent = null;

        internal DoorStatusList(StatusManager parent)
        {
            statusList = new SortedList<int, DoorStatus>();        
            this.Parent = parent;
        }

        /// <summary>
        /// Add new reader to the list. Assign it to a door.
        /// </summary>
        /// <param name="logicalId">New reader logical Id</param>
        /// <param name="entryReaderLogicalId">Entry reader for the door</param>
        /// <param name="exitReaderLogicalId">Exit reader for the door</param>
        internal void CreateDoor(int logicalId, int entryReaderLogicalId, int exitReaderLogicalId)
        {
            DoorStatus doorStatus = new DoorStatus(logicalId, entryReaderLogicalId, exitReaderLogicalId);
            statusList.Add(logicalId, doorStatus);
        }

        /// <summary>
        /// Return the reader status list elements as an array that can be iterated independently
        /// </summary>
        public DoorStatus[] Items
        {
            get
            {
                lock (statusListSync)
                {
                    return statusList.Values.ToArray();
                }
            }
        }

        /// <summary>
        /// Return door status object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <returns>Node status instance or null if not found</returns>
        public virtual DoorStatus this[int logicalId]
        {
            get
            {
                lock (statusListSync)
                {
                    if (logicalId < 1 || statusList == null || statusList.Count < 1)
                        return null;
                    DoorStatus outputItem = null;
                    statusList.TryGetValue(logicalId, out outputItem);
                    return outputItem;
                }
            }
        }

        /// <summary>
        /// Return door status for the specified reader logical Id.
        /// </summary>
        /// <param name="readerLogicalId">Reader logical Id</param>
        /// <returns>Returns the door status object or null if not found door for the reader logical Id.</returns>
        public DoorStatus TryGetDoorStatus(int readerLogicalId)
        {
            foreach (var d in statusList.Values)
            {
                if (d.EntryReaderLogicalId == readerLogicalId || d.ExitReaderLogicalId == readerLogicalId)
                    return d;
            }
            return default(DoorStatus);
        }
    }
}
