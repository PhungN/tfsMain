﻿using System;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Door status
    /// </summary>
    public class DoorStatus
    {
        internal DoorStatus(int logicalId, int entryReaderLogicalId, int exitReaderLogicalId)
        {
            this.logicalId = logicalId;
            EntryReaderLogicalId = entryReaderLogicalId;
            ExitReaderLogicalId = exitReaderLogicalId;
        }

        /// <summary>
        /// Entry reader logical Id.
        /// </summary>
        public int EntryReaderLogicalId
        {
            get;
            private set;
        }

        /// <summary>
        /// Exit reader logical Id.
        /// </summary>
        public int ExitReaderLogicalId
        {
            get;
            private set;
        }

        private int logicalId = 1;

        /// <summary>
        /// Get door logical Id
        /// </summary>
        public int LogicalId
        {
            get { return logicalId; }
        }

        /// <summary>
        /// Triggered when access command is requested on the door.
        /// </summary>
        public event EventHandler<AccessControlCommandRequestEventArgs> AccessControlCommandRequested = null;
        public event EventHandler<DisplaySecurityLevelChangeEventArgs> AccessControlSecurityLevelDisplayCommandRequested = null;

        private void triggerAccessControlCommand(AccessControlCommandRequestEventArgs requestEntry)
        {
            if (AccessControlCommandRequested == null)
                return;
            AccessControlCommandRequested(this, requestEntry);
        }

        public void TriggerDisplaySecurityLevelCommand(DisplaySecurityLevelChangeEventArgs e)
        {
            if (AccessControlSecurityLevelDisplayCommandRequested == null)
                return;
            AccessControlSecurityLevelDisplayCommandRequested(this, e);
        }

        private CardReaderLedType deniedLedState = CardReaderLedType.LedOff;
        private CardReaderLedType requestedDeniedLedState = CardReaderLedType.LedOff;
        private readonly object ledSync = new object();

        public void UpdateDeniedLedState()
        {
            DeniedLedState = requestedDeniedLedState;
        }

        /// <summary>
        /// The state of the denied (red) led on the door peripheral
        /// </summary>
        public CardReaderLedType DeniedLedState
        {
            get
            {
                return deniedLedState;
            }
            set
            {
                lock (ledSync)
                {
                    requestedDeniedLedState = value;
                    if (ConfigurationManager.Instance.AllowReaderLedsToTurnOff == false &&
                        (requestedDeniedLedState & CardReaderLedType.LedOn) != CardReaderLedType.LedOn && (acceptLedState & CardReaderLedType.LedOn) != CardReaderLedType.LedOn)
                        value = CardReaderLedType.LedOn;
                    if (deniedLedState != value)
                    {
                        deniedLedState = value;
                        // Entry
                        var requestEntry = new AccessControlCommandRequestEventArgs(EntryReaderLogicalId);
                        requestEntry[AccessCommandType.DeniedLed] = new AccessCommandDeniedLedConfig(deniedLedState);
                        triggerAccessControlCommand(requestEntry);

                        // Exit
                        var requestExit = new AccessControlCommandRequestEventArgs(ExitReaderLogicalId);
                        requestExit[AccessCommandType.DeniedLed] = new AccessCommandDeniedLedConfig(deniedLedState);
                        triggerAccessControlCommand(requestExit);
                    }
                }
            }
        }

        private CardReaderLedType acceptLedState = CardReaderLedType.LedOff;

        /// <summary>
        /// The state of the accept (green) led on the door peripheral
        /// </summary>
        public CardReaderLedType AcceptLedState
        {
            get
            {
                return acceptLedState;
            }
            set
            {
                lock (ledSync)
                {
                    if (acceptLedState != value)
                    {
                        acceptLedState = value;
                        // Entry
                        var requestEntry = new AccessControlCommandRequestEventArgs(EntryReaderLogicalId);
                        requestEntry[AccessCommandType.AcceptLed] = new AccessCommandAcceptLedConfig(acceptLedState);
                        triggerAccessControlCommand(requestEntry);

                        // Exit
                        var requestExit = new AccessControlCommandRequestEventArgs(ExitReaderLogicalId);
                        requestExit[AccessCommandType.AcceptLed] = new AccessCommandAcceptLedConfig(acceptLedState);
                        triggerAccessControlCommand(requestExit);

                        if (ConfigurationManager.Instance.AllowReaderLedsToTurnOff == false)
                        {
                            if ((deniedLedState & CardReaderLedType.LedOn) != CardReaderLedType.LedOn && (acceptLedState & CardReaderLedType.LedOn) != CardReaderLedType.LedOn)
                            {
                                DeniedLedState = CardReaderLedType.LedOn;
                                requestedDeniedLedState = CardReaderLedType.LedOff;
                            }
                            else if ((requestedDeniedLedState & CardReaderLedType.LedOn) != CardReaderLedType.LedOn && 
                                (deniedLedState & CardReaderLedType.LedOn) == CardReaderLedType.LedOn && (acceptLedState & CardReaderLedType.LedOn) == CardReaderLedType.LedOn)
                            {
                                UpdateDeniedLedState();
                            }
                        }
                    }
                }
            }
        }

        private CardReaderBuzzerType buzzerState = CardReaderBuzzerType.BuzzerOff;

        /// <summary>
        /// The state of the buzzer on the door peripheral
        /// </summary>
        public CardReaderBuzzerType BuzzerState
        {
            get
            {
                return buzzerState;
            }
            set
            {
                if (buzzerState != value)
                {
                    buzzerState = value;
                    // Entry
                    var requestEntry = new AccessControlCommandRequestEventArgs(EntryReaderLogicalId);
                    requestEntry[AccessCommandType.Buzzer] = new AccessCommandBuzzerConfig(buzzerState);
                    triggerAccessControlCommand(requestEntry);

                    // Exit
                    var requestExit = new AccessControlCommandRequestEventArgs(ExitReaderLogicalId);
                    requestExit[AccessCommandType.Buzzer] = new AccessCommandBuzzerConfig(buzzerState);
                    triggerAccessControlCommand(requestExit);
                }
            }
        }

        /// <summary>
        /// Try to lock / unlock device door (refresh) when door is becoming online
        /// </summary>
        public void TryLockUnlockDoor()
        {
            // Entry
            var requestEntry = new AccessControlCommandRequestEventArgs(EntryReaderLogicalId);
            requestEntry[AccessCommandType.DeniedLed] = new AccessCommandDeniedLedConfig(deniedLedState);
            requestEntry[AccessCommandType.AcceptLed] = new AccessCommandAcceptLedConfig(acceptLedState);
            requestEntry[AccessCommandType.Buzzer] = new AccessCommandBuzzerConfig(buzzerState);
            triggerAccessControlCommand(requestEntry);

            // Exit
            var requestExit = new AccessControlCommandRequestEventArgs(ExitReaderLogicalId);
            requestExit[AccessCommandType.DeniedLed] = new AccessCommandDeniedLedConfig(deniedLedState);
            requestExit[AccessCommandType.AcceptLed] = new AccessCommandAcceptLedConfig(acceptLedState);
            requestExit[AccessCommandType.Buzzer] = new AccessCommandBuzzerConfig(buzzerState);
            triggerAccessControlCommand(requestExit);
        }
    }
}

