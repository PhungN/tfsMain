﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Utils;
using CardReaderConsts = Pacom.Peripheral.AccessControl.CardReaderHardwareLocations;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Output status list
    /// </summary>
    public partial class OutputStatusList
    {
        private readonly object statusListSync = new object();

        private SortedList<int, OutputStatus> statusList = null;

        public StatusManager Parent = null;

        internal OutputStatusList(StatusManager parent)
        {
            statusList = new SortedList<int, OutputStatus>();
            this.Parent = parent;
            initializeElevatorOutputsStatus();
        }

        /// <summary>
        /// Add new output to the list.
        /// </summary>
        /// <param name="logicalId">New output logical Id</param>
        internal void CreateOutput(int logicalId)
        {
            OutputStatus inputStatus = new OutputStatus(logicalId);
            statusList.Add(logicalId, inputStatus);
        }

        /// <summary>
        /// Return the output status list elements as an array that can be iterated independently
        /// </summary>
        public OutputStatus[] Items
        {
            get
            {
                lock (statusListSync)
                {
                    return statusList.Values.ToArray();
                }
            }
        }

        /// <summary>
        /// Return output status object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <returns>Node status instance or null if not found</returns>
        public virtual OutputStatus this[int logicalId]
        {
            get
            {
                lock (statusListSync)
                {
                    if (logicalId < 1 || statusList == null || statusList.Count < 1)
                        return null;
                    OutputStatus outputItem = null;
                    statusList.TryGetValue(logicalId, out outputItem);
                    return outputItem;
                }
            }
        }

        /// <summary>
        /// Update outputs based on owner and starting point.
        /// </summary>
        /// <param name="owner">Owner of the outputs</param>
        /// <param name="startingPoint">Starting point for the update</param>
        /// <param name="outputStates">States to update</param>
        /// <returns></returns>
        public bool Update(OwnerType owner, int startingPoint, bool[] outputStates)
        {
            try
            {
                int outputStatesCount = Math.Min(ConfigurationManager.Instance.Outputs.OutputsCountForOwner(owner), outputStates.Length);
                bool[] outputStatesToChange = outputStates.Take(outputStatesCount).ToArray();
                switch (owner)
                {
                    case OwnerType.Onboard:                        
                        IOutputContainer onboardOutputs = StatusManager.Instance.OnboardOutputs;
                        if (onboardOutputs != null)
                        {
                            for (int i = 0; i < Math.Min(onboardOutputs.ContainerOutputCount, outputStatesToChange.Length); i++)
                            {
                                int outputNumber = startingPoint + i;
                                if (ConfigurationManager.Instance.ControllerMessaging.Has(MessagingFlags.RestoreDefaultsAndSwitchAllReportingToExtendedFormat)
                                    && ConfigurationManager.Instance.Outputs[onboardOutputs.FirstOutputPoint + outputNumber + 1].IsConfigured == false)
                                {
                                    Logger.LogWarnMessage(LoggerClassPrefixes.StatusManager, () =>
                                    {
                                        return string.Format("Warning. Onboard output {0} could not be set, it is not configured as an output.", (outputNumber + 1).ToString());
                                    });
                                    continue;
                                }
                                // In card access mode onboard inputs must not be disrupted by this command
                                bool skipOutputChange = false;
                                foreach (int logicalDoorId in CardReaderConsts.HandledLogicalDoorIds)
                                {
                                    if (ConfigurationManager.Instance.Doors[logicalDoorId].IsConfigured != DoorConfiguredType.DoorNotConfigured 
                                        && CardReaderConsts.IsValidDoorOutput(logicalDoorId, outputNumber))
                                    {
                                        skipOutputChange = true;
                                        break;
                                    }
                                }
                                if (skipOutputChange == true)
                                {
                                    Logger.LogWarnMessage(LoggerClassPrefixes.StatusManager, () =>
                                    {
                                        return string.Format("Warning. Onboard output {0} could not be set, a door is configured.", (outputNumber + 1).ToString());
                                    });
                                    continue;
                                }
                                // Modify output
                                if (outputStatesToChange[i])
                                {
                                    StatusManager.Instance.Outputs[onboardOutputs.FirstOutputPoint + outputNumber + 1].RequestedState = OutputState.Active;
                                    StatusManager.Instance.OnboardOutputs.SetOutput(outputNumber);
                                }
                                else
                                {
                                    StatusManager.Instance.Outputs[onboardOutputs.FirstOutputPoint + outputNumber + 1].RequestedState = OutputState.Inactive;
                                    StatusManager.Instance.OnboardOutputs.ClearOutput(outputNumber);
                                }
                            }
                        }
                        return true;
                    case OwnerType.Expansion1:
                    case OwnerType.Expansion2:
                    case OwnerType.Expansion3:
                    case OwnerType.Expansion4:
                        IOutputContainer outputCard = StatusManager.Instance.ExpansionCardManager.OutputExpansionCard((int)(owner - OwnerType.Expansion1));
                        if (outputCard != null)
                        {
                            for (int i = 0; i < Math.Min(outputCard.ContainerOutputCount, outputStatesToChange.Length); i++)
                            {
                                int outputNumber = startingPoint + i;
                                if (ConfigurationManager.Instance.ControllerMessaging.Has(MessagingFlags.RestoreDefaultsAndSwitchAllReportingToExtendedFormat)
                                    && ConfigurationManager.Instance.Outputs[outputCard.FirstOutputPoint + outputNumber + 1].IsConfigured == false)
                                {
                                    Logger.LogWarnMessage(LoggerClassPrefixes.StatusManager, () =>
                                    {
                                        return string.Format("Warning. Expansion output {0} could not be set, it is not configured as an output.", (outputNumber + 1).ToString());
                                    });
                                    continue;
                                }
                                if (outputStatesToChange[i])
                                {
                                    StatusManager.Instance.Outputs[outputCard.FirstOutputPoint + outputNumber + 1].RequestedState = OutputState.Active;
                                    outputCard.SetOutput(outputNumber);
                                }
                                else
                                {
                                    StatusManager.Instance.Outputs[outputCard.FirstOutputPoint + outputNumber + 1].RequestedState = OutputState.Inactive;
                                    outputCard.ClearOutput(outputNumber);
                                }
                            }
                        }
                        return true;
                    case OwnerType.Sart1:
                        IOutputContainer sartCard = StatusManager.Instance.ExpansionCardManager.FirstSartOutputExpansionCard;
                        if (sartCard != null)
                        {
                            for (int i = 0; i < Math.Min(sartCard.ContainerOutputCount, outputStatesToChange.Length); i++)
                            {
                                int outputNumber = startingPoint + i;
                                if (ConfigurationManager.Instance.ControllerMessaging.Has(MessagingFlags.RestoreDefaultsAndSwitchAllReportingToExtendedFormat)
                                    && ConfigurationManager.Instance.Outputs[sartCard.FirstOutputPoint + outputNumber + 1].IsConfigured == false)
                                {
                                    continue;
                                }
                                if (outputStatesToChange[i])
                                {
                                    StatusManager.Instance.Outputs[sartCard.FirstOutputPoint + outputNumber + 1].RequestedState = OutputState.Active;
                                    sartCard.SetOutput(outputNumber);
                                }
                                else
                                {
                                    StatusManager.Instance.Outputs[sartCard.FirstOutputPoint + outputNumber + 1].RequestedState = OutputState.Inactive;
                                    sartCard.ClearOutput(outputNumber);
                                }
                            }
                            sartCard.WriteOutputs();
                        }
                        return true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while updating {0} outputs starting from {1}. {2}", owner.ToString(), startingPoint.ToString(), ex.Message);
                });
            }
            return false;
        }

        /// <summary>
        /// Clear all outputs in the system
        /// </summary>
        public void ClearAllOutputs()
        {
            try
            {
                if (StatusManager.Instance.OnboardOutputs != null)
                    StatusManager.Instance.OnboardOutputs.ClearAllOutputs();
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while clearing onboard outputs. {0}", ex.Message);
                });
            }

            try
            {
                for (int slotNumber = 0; slotNumber < ConfigurationManager.ExpansionSlotCount; slotNumber++)
                {
                    IOutputContainer outputCard = StatusManager.Instance.ExpansionCardManager.OutputExpansionCard(slotNumber);
                    if (outputCard != null)
                        outputCard.ClearAllOutputs();
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while clearing expansion card outputs. {0}", ex.Message);
                });
            }

            try
            {
                IOutputContainer sartCard = StatusManager.Instance.ExpansionCardManager.FirstSartOutputExpansionCard;
                if (sartCard != null)
                    sartCard.ClearAllOutputs();
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                {
                    return string.Format("Error while clearing SART card outputs. {0}", ex.Message);
                });
            }

        }
    }
}
