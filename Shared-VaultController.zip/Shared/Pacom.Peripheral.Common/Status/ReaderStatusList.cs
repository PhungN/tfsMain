﻿using System.Collections.Generic;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Device reader list
    /// </summary>
    public class ReaderStatusList
    {
        private readonly object statusListSync = new object();

        private SortedList<int, ReaderStatus> statusList = null;

        public StatusManager Parent = null;

        internal ReaderStatusList(StatusManager parent)
        {
            statusList = new SortedList<int, ReaderStatus>();        
            this.Parent = parent;
        }
                
        /// <summary>
        /// Add new reader to the list. Assign it to a door.
        /// </summary>
        /// <param name="logicalId">New reader logical Id</param>
        /// <param name="parentDoor">Parent door for the reader</param>
        internal void CreateReader(int logicalId, DoorStatus parentDoor)
        {
            ReaderStatus readerStatus = new ReaderStatus(logicalId, parentDoor);
            statusList.Add(logicalId, readerStatus);
        }

        /// <summary>
        /// Return the reader status list elements as an array that can be iterated independently
        /// </summary>
        public ReaderStatus[] Items
        {
            get
            {
                lock (statusListSync)
                {
                    return statusList.Values.ToArray();
                }
            }
        }

        /// <summary>
        /// Return reader status object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <returns>Node status instance or null if not found</returns>
        public virtual ReaderStatus this[int logicalId]
        {
            get
            {
                lock (statusListSync)
                {
                    if (logicalId < 1 || statusList == null || statusList.Count < 1)
                        return null;
                    ReaderStatus readerItem = null;
                    statusList.TryGetValue(logicalId, out readerItem);
                    return readerItem;
                }
            }
        }

        /// <summary>
        /// Create list of all reader statuses. It will include if reader is online\offline\tamper.
        /// The number of items on the list is restricted to readers handled by the device.
        /// </summary>
        public ReaderOnlineTamperStatus[] ReadersStatus
        {
            get
            {
                ReaderOnlineTamperStatus[] result = new ReaderOnlineTamperStatus[statusList.Count];
                int readerIndex = 0;
                foreach (var readerLogicalId in statusList.Keys)
                {
                    if (statusList[readerLogicalId].Online == false)
                        result[readerIndex] = result[readerIndex].SetFlags(ReaderOnlineTamperStatus.Offline);
                    if (statusList[readerLogicalId].TamperActive == true)
                        result[readerIndex] = result[readerIndex].SetFlags(ReaderOnlineTamperStatus.Tamper);
                    readerIndex++;
                }
                return result;
            }
        }
    }
}
