﻿using System;

namespace Pacom.Peripheral.Common.Status
{
    public class ReaderStatus
    {
        internal ReaderStatus(int logicalId, DoorStatus door)
        {
            this.logicalId = logicalId;
            ParentDoor = door;
            Interface = CardReaderInterface.Wiegand;
        }

        public DoorStatus ParentDoor { get; private set; }

        private readonly int logicalId;

        /// <summary>
        /// Get reader logical Id
        /// </summary>
        public int LogicalId
        {
            get { return logicalId; }
        }

        private CardReaderType readerType = CardReaderType.NoReader;

        /// <summary>
        /// Set reader type.
        /// </summary>
        /// <param name="readerType"></param>
        public void SetReaderType(CardReaderType readerType)
        {
            this.readerType = readerType;
        }

        /// <summary>
        /// Returns true if the reader is configured.
        /// </summary>
        public bool IsEnabled
        {
            get
            {
                return readerType != CardReaderType.NoReader;
            }
        }

        private bool tamperActive = false;

        /// <summary>
        /// Get / Set tamper active flag
        /// </summary>
        public bool TamperActive
        {
            get { return tamperActive; }
            set
            {
                try
                {
                    if (tamperActive != value)
                    {
                        tamperActive = value;

                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                        {
                            return string.Format("Reader {0} tamper changed state to {1}", LogicalId, tamperActive.ToString());
                        });
                        // Notify device that its reader has changed status
                        StatusManager.Instance.Device.TriggerTamperOrChangedPowerSupplyStatus();
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                    {
                        return string.Format("Error while setting reader tamper status. {0}", ex.Message);
                    });
                }
            }
        }

        private bool online = true;

        /// <summary>
        /// Get / Set reader status (online/offline)
        /// </summary>
        public bool Online
        {
            get { return this.online; }
            set
            {
                try
                {
                    // When the Wiegand reader is online once never switch it off again.
                    if (this.wiegandOnline == false && this.online != value)
                    {
                        this.online = value;

                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                        {
                            return string.Format("Reader {0} is {1}.", LogicalId, online ? "online" : "offline");
                        });
                        // Notify device that its reader has changed status
                        StatusManager.Instance.Device.TriggerTamperOrChangedPowerSupplyStatus();
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                    {
                        return string.Format("Error while setting reader online status. {0}", ex.Message);
                    });
                }
            }
        }

        private bool wiegandOnline = false;

        /// <summary>
        /// Set Wiegand online flag. It is set from the onboard CRI event.
        /// </summary>
        public void SetWiegandOnline()
        {
            if (this.wiegandOnline == true)
                return;

            this.Online = true;
            this.wiegandOnline = true;

            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
            {
                return string.Format("Reader {0} is permanently online (Wiegand scan).", LogicalId);
            });
        }

        public CardReaderInterface Interface { get; set; }
        public ReaderManufacturer Manufacturer { get; set; }
        public string Model { get; set; }
        public string HardwareRevision { get; set; }
        public string SerialNumber { get; set; }
        public string FirmwareVersion { get; set; }
    }
}
