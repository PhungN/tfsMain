﻿using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    public partial class InputStatus
    {
        internal InputStatus(int logicalId)
        {
            this.logicalId = logicalId;
        }

        private readonly int logicalId;

        /// <summary>
        /// Get input logical Id
        /// </summary>
        public int LogicalId
        {
            get { return logicalId; }
        }

        private Common.InputStatus unmaskedStatus = Common.InputStatus.Unknown;

        /// <summary>
        /// Get input unmasked status. Triggers Input Changed Status event if
        /// the input is not isolated or masked.
        /// </summary>
        public Common.InputStatus UnmaskedStatus
        {
            get { return unmaskedStatus; }
        }

        private int analogValue = 0;


        public int AnalogValue
        {
            get { return analogValue; }
        }

        /// <summary>
        /// Change input status along with its analog value.
        /// </summary>
        /// <param name="inputStatus">New input status.</param>
        /// <param name="inputAnalogValue">New input analog value.</param>
        public void Change(Common.InputStatus inputStatus, int inputAdcValue)
        {
            OwnerType owner;
            int pointNumberOnParent;
            ConfigurationManager.Instance.Inputs.GetOwnerAndPointNumber(LogicalId, out owner, out pointNumberOnParent);
            if (inputStatus == Common.InputStatus.Analog)
            {
                int previousValue = AnalogValue;
                if (AnalogValue != inputAdcValue)
                {
                    unmaskedStatus = Common.InputStatus.Analog;
                    analogValue = inputAdcValue;
                    if (owner != OwnerType.Onboard && owner != OwnerType.Sart1)
                    {
                        bool processingResult = StatusManager.Instance.Inputs.TriggerChangedAnalogValue(this, previousValue, owner, pointNumberOnParent);
                        if (processingResult == true)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                            {
                                return string.Format("{0} -> Analog Input point {1} changed status to {2}", owner.ToString(), pointNumberOnParent + 1, AnalogValue);
                            });
                        }                        
                    }                    
                }
            }
            else
            {
                Common.InputStatus previousInputStatus = UnmaskedStatus;
                if (previousInputStatus != inputStatus)
                {
                    unmaskedStatus = inputStatus;
                    analogValue = inputAdcValue;
                    bool processingResult = StatusManager.Instance.Inputs.TriggerChangedUnmaskedStatus(this, previousInputStatus, owner, pointNumberOnParent);
                    if (processingResult == true)
                    {
                        logAnalogValue(owner, pointNumberOnParent, analogValue);
                    }
                }
            }
        }
    }
}
