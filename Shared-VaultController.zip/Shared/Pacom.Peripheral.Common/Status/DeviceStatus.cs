﻿using System;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Device properties and methods
    /// </summary>
    public class DeviceStatus
    {
        internal DeviceStatus()
        {
        }
              
        private bool tamperActive = false;

        /// <summary>
        /// Get \ Set device tamper active.
        /// </summary>
        public bool TamperActive
        {
            get
            {
                return tamperActive;
            }
            set
            {
                if (tamperActive != value)
                {
                    try
                    {
                        tamperActive = value;
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                        {
                            return string.Format("Device tamper changed state to {0}", tamperActive.ToString());
                        });
                        TriggerTamperOrChangedPowerSupplyStatus();
                    }
                    catch (Exception ex)
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                        {
                            return string.Format("Error while setting device tamper. {0}", ex.Message);
                        });
                    }
                }
            }
        }

        private PowerSupplyStatus powerSupplyStatus = PowerSupplyStatus.Unknown;

        /// <summary>
        /// Get / Set power supply status
        /// </summary>
        public PowerSupplyStatus PowerSupplyStatus
        {
            get { return powerSupplyStatus; }
            set
            {
                try
                {
                    if (powerSupplyStatus != value)
                    {
                        powerSupplyStatus = value;
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                        {
                            return string.Format("Power supply changed state to {0}", powerSupplyStatus.ToString());
                        });
                        TriggerTamperOrChangedPowerSupplyStatus();
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                    {
                        return string.Format("Error while setting device power status. {0}", ex.Message);
                    });
                }
            }
        }

        /// <summary>
        /// Trigger power supply changed status event handler
        /// </summary>
        internal void TriggerTamperOrChangedPowerSupplyStatus()
        {
            StatusManager.Instance.DeviceResponseProcessor.SendTamperAndPowerSupplyStatus(tamperActive, PowerSupplyStatus, StatusManager.Instance.Readers.ReadersStatus);
        }

        private bool systemTimeReceivedFromController = false;

        /// <summary>
        /// Get /Set time received from controller flag
        /// </summary>
        public bool SystemTimeReceivedFromController
        {
            get { return systemTimeReceivedFromController; }
            set
            {
                if (systemTimeReceivedFromController != value)
                {
                    systemTimeReceivedFromController = value;
                }
            }
        }

        private DateTime systemTimeAfterControllerUpdate = DateTime.MinValue;

        /// <summary>
        /// Get /Set date/time after controller update
        /// </summary>
        public DateTime SystemTimeAfterControllerUpdate
        {
            get { return systemTimeAfterControllerUpdate; }
            set
            {
                if (systemTimeAfterControllerUpdate != value)
                {
                    systemTimeAfterControllerUpdate = value;
                }
            }
        }

        private DateTime systemTimeBeforeControllerUpdate = DateTime.MinValue;

        /// <summary>
        /// Get /Set date/time after controller update
        /// </summary>
        public DateTime SystemTimeBeforeControllerUpdate
        {
            get { return systemTimeBeforeControllerUpdate; }
            set
            {
                if (systemTimeBeforeControllerUpdate != value)
                {
                    systemTimeBeforeControllerUpdate = value;
                }
            }
        }

        private bool serialConnectionValid = false;

        /// <summary>
        /// Get / Set the status of the serial (RS485) connection to the controller
        /// </summary>
        public bool SerialConnectionValid
        {
            get { return serialConnectionValid; }
            set
            {
                if (serialConnectionValid != value)
                {
                    serialConnectionValid = value;
                    triggerReEvaluateConnectedToController(this.IsAnyConnectionValid);
                }
            }
        }

        private bool tcpIPConnectionValid = false;

        /// <summary>
        /// Get / Set the status of the TcpIp connection to the controller
        /// </summary>
        public bool TcpIPConnectionValid
        {
            get { return tcpIPConnectionValid; }
            set
            {
                if (tcpIPConnectionValid != value)
                {                    
                    tcpIPConnectionValid = value;
                    triggerReEvaluateConnectedToController(this.IsAnyConnectionValid);
                }
            }
        }

        private bool udpIPConnectionValid = false;

        /// <summary>
        /// Get / Set the status of the UdpIp connection to the controller
        /// </summary>
        public bool UdpIPConnectionValid
        {
            get { return udpIPConnectionValid; }
            set
            {
                if (udpIPConnectionValid != value)
                {
                    udpIPConnectionValid = value;
                    triggerReEvaluateConnectedToController(this.IsAnyConnectionValid);
                }
            }
        }

        /// <summary>
        /// returns True when the controller is connected on Serial or TcpIp.
        /// </summary>
        public bool IsAnyConnectionValid
        {
            get
            {
                return udpIPConnectionValid || tcpIPConnectionValid || serialConnectionValid;
            }
        }

        private IPConnectionConfiguration currentConnectionUdp = new IPConnectionConfiguration(true, false, NetworkAddress.CreateAddressAny(), 0, 0, 0);

        /// <summary>
        /// Get / Set current UDP\IP connection configuration
        /// </summary>
        public IPConnectionConfiguration CurrentConnectionUdp
        {
            get { return currentConnectionUdp; }
            set
            {
                if (value != null && (currentConnectionUdp.Equals(value) == false))
                {
                    currentConnectionUdp = value;
                }
            }
        }
        
        private IPConnectionConfiguration currentConnectionTcp = new IPConnectionConfiguration(true, false, NetworkAddress.CreateAddressAny(), 0, 0, 0);

        /// <summary>
        /// Get / Set current TCP\UDP connection configuration
        /// </summary>
        public IPConnectionConfiguration CurrentConnectionTcp
        {
            get { return currentConnectionTcp; }
            set
            {
                if (value != null && (currentConnectionTcp.Equals(value) == false))
                {
                    currentConnectionTcp = value;
                }
            }
        }
        
        /// <summary>
        /// Triggered when the communication manager changes online status. 
        /// </summary>
        public event EventHandler<ConnectedToControllerEventArgs> ConnectedToControllerChanged = null;

        private void triggerReEvaluateConnectedToController(bool connected)
        {
            if (ConnectedToControllerChanged != null)
                ConnectedToControllerChanged(this, new ConnectedToControllerEventArgs(connected));

            if(connected == true)
                StatusManager.Instance.ExpansionCards.TriggerExpansionCardStatusNotification();
        }

        private bool isOsdpEnabled = false;

        /// <summary>
        /// Set to true if the OSDP interface is enabled and handles the RS485 bus.
        /// </summary>
        public bool IsOsdpEnabled
        {
            get
            {
                return isOsdpEnabled;
            }
            set
            {
                try
                {
                    if (isOsdpEnabled != value)
                    {
                        isOsdpEnabled = value;

                        // The Wiegand code does not handle readers tamper and offline detection.
                        // Restore tamper and online status for all readers.
                        foreach (var door in StatusManager.Instance.Doors.Items)
                        {
                            StatusManager.Instance.Readers[door.EntryReaderLogicalId].TamperActive = false;
                            StatusManager.Instance.Readers[door.EntryReaderLogicalId].Online = true;
                            StatusManager.Instance.Readers[door.ExitReaderLogicalId].TamperActive = false;
                            StatusManager.Instance.Readers[door.ExitReaderLogicalId].Online = true;
                        }
                        StatusManager.Instance.Device.TriggerTamperOrChangedPowerSupplyStatus();
                        Logger.LogDebugMessage(LoggerClassPrefixes.StatusManager, () =>
                        {
                            return string.Format("OSDP is {0}.", isOsdpEnabled ? "enabled" : "disabled");
                        });
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.StatusManager, () =>
                    {
                        return string.Format("Error while setting OSDP status. {0}", ex.Message);
                    });
                }
            }
        }
    }
}
