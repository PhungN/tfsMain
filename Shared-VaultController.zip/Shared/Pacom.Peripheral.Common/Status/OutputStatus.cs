﻿
namespace Pacom.Peripheral.Common.Status
{
    public class OutputStatus
    {
        internal OutputStatus(int logicalId)
        {
            this.logicalId = logicalId;
        }
        
        private readonly int logicalId;

        /// <summary>
        /// Get output logical Id
        /// </summary>
        public int LogicalId
        {
            get { return logicalId; }
        }

        private OutputState requestedState = OutputState.Inactive;

        public OutputState RequestedState
        {
            get 
            { 
                return this.requestedState;
            }
            set
            {
                this.requestedState = value;
            }
        }
    }
}
