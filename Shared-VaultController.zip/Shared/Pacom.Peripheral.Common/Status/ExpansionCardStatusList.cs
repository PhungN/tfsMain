﻿using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common.Status
{
    /// <summary>
    /// Expansion card list
    /// </summary>
    public class ExpansionCardStatusList
    {
        public const int ExpansionSlotCount = ConfigurationManager.ExpansionSlotCount;

        private readonly object statusListSync = new object();

        private SortedList<int, ExpansionCardStatus> statusList = null;

        public StatusManager Parent = null;

        internal ExpansionCardStatusList(StatusManager parent)
        {
            statusList = new SortedList<int, ExpansionCardStatus>();        
            this.Parent = parent;
        }

        /// <summary>
        /// Add new expansion card to the list.
        /// </summary>
        /// <param name="logicalId">New expansion card logical Id</param>
        internal void CreateExpansionCard(int logicalId, ExpansionCardType type)
        {
            ExpansionCardStatus expansionCardStatus = new ExpansionCardStatus(logicalId, type);
            statusList.Add(logicalId, expansionCardStatus);
        }

        /// <summary>
        /// Return the expansion card status list elements as an array that can be iterated independently
        /// </summary>
        public ExpansionCardStatus[] Items
        {
            get
            {
                lock (statusListSync)
                {
                    return statusList.Values.ToArray();
                }
            }
        }

        /// <summary>
        /// Return expansion card status object referenced by logical id
        /// </summary>
        /// <param name="logicalId">Node id, 1 based</param>
        /// <returns>Node status instance or null if not found</returns>
        public virtual ExpansionCardStatus this[int logicalId]
        {
            get
            {
                lock (statusListSync)
                {
                    if (logicalId < 1 || statusList == null || statusList.Count < 1)
                        return null;
                    ExpansionCardStatus outputItem = null;
                    statusList.TryGetValue(logicalId, out outputItem);
                    return outputItem;
                }
            }
        }

        /// <summary>
        /// Determine if expansion slot is configured as type provided in argument and if it is online.
        /// </summary>
        /// <param name="slot">Slot starting with zero.</param>
        /// <param name="expansionCardType">The expected card type.</param>
        /// <returns>Returns True when the the cart type is configured and online.</returns>
        public bool IsConfiguredAndOnline(int slot, ExpansionCardType expansionCardType)
        {
            if (slot < 0 || slot > ExpansionSlotCount - 1)
                return false;

            ExpansionCardType type = ConfigurationManager.Instance.Expansions[slot + 1].Type;
            if (type != expansionCardType)
                return false;

            Common.Status.ExpansionCardStatus expansionCardStatus = this[slot + 1];
            if (expansionCardStatus == null || expansionCardStatus.Type != expansionCardType)
                return false;

            if (expansionCardStatus.Online == false)
                return false;

            return true;
        }

        /// <summary>
        /// Determine if expansion slot is online.
        /// </summary>
        /// <param name="slot">Slot starting with zero.</param>
        /// <param name="expansionCardType">The expected card type.</param>
        /// <returns>Returns True when the the cart type is configured and online.</returns>
        public bool IsOnline(int slot, ExpansionCardType expansionCardType)
        {
            if (slot < 0 || slot > ExpansionSlotCount - 1)
                return false;

            Common.Status.ExpansionCardStatus expansionCardStatus = this[slot + 1];
            if (expansionCardStatus == null || expansionCardStatus.Type != expansionCardType)
                return false;

            if (expansionCardStatus.Online == false)
                return false;

            return true;
        }

        internal void TriggerExpansionCardStatusNotification()
        {
            if (StatusManager.Instance.Device.IsAnyConnectionValid == false)
                return;
            
            if (ConfigurationManager.Instance.ControllerMessaging.DoesNotHave(MessagingFlags.RestoreDefaultsAndSwitchAllReportingToExtendedFormat))
            {
                SortedList<int, Common.Status.ExpansionCardStatus> reportingStatus = new SortedList<int, ExpansionCardStatus>();
                for (int slot = 0; slot < ConfigurationManager.LegacyExpansionSlotCount; slot++)
                {
                    ExpansionCardType configuredCardType = ConfigurationManager.Instance.Expansions[slot + 1].Type;
                    if (configuredCardType != ExpansionCardType.None)
                    {
                        Common.Status.ExpansionCardStatus expansionCardStatus = this[slot + 1];
                        if (expansionCardStatus != null && 
                            expansionCardStatus.Type == configuredCardType)
                        {
                            reportingStatus.Add(slot, expansionCardStatus);
                        }
                    }
                }

                if (reportingStatus.Count == 0)
                    return;

                Common.ExpansionCardStatus[] expansionCardStatusToSend = new Common.ExpansionCardStatus[ConfigurationManager.LegacyExpansionSlotCount];
                for (int slot = 0; slot < ConfigurationManager.LegacyExpansionSlotCount; slot++)
                {
                    if (reportingStatus.ContainsKey(slot))
                    {
                        if (reportingStatus[slot].Online == true)
                        {
                            if (reportingStatus[slot].FuseFailed == true)
                            {
                                expansionCardStatusToSend[slot] = Common.ExpansionCardStatus.FuseFail;
                            }
                            else
                            {
                                expansionCardStatusToSend[slot] = Common.ExpansionCardStatus.Online;
                            }
                        }
                        else
                        {
                            expansionCardStatusToSend[slot] = Common.ExpansionCardStatus.Offline;
                        }
                    }
                    else
                    {
                        expansionCardStatusToSend[slot] = Common.ExpansionCardStatus.Online;
                    }
                }
                Parent.DeviceResponseProcessor.SendCurrentLegacyExpansionCardStatuses(expansionCardStatusToSend);

                // Log response
                StringBuilder sb = new StringBuilder();
                for (int slot = 0; slot < ConfigurationManager.LegacyExpansionSlotCount; slot++)
                {
                    if (sb.Length != 0)
                        sb.Append(", ");
                    sb.Append(expansionCardStatusToSend[slot].ToString());
                }
                Logger.LogDebugMessage(LoggerClassPrefixes.CommandProcessor, () =>
                {
                    return string.Format("Expansion card status legacy response. Sent expansion card states ({0}).", sb.ToString());
                });
            }
            else
            {
                SortedList<int, Common.Status.ExpansionCardStatus> reportingStatus = new SortedList<int, ExpansionCardStatus>();
                for (int slot = 0; slot < ExpansionSlotCount; slot++)
                {
                    ExpansionCardType configuredCardType = ConfigurationManager.Instance.Expansions[slot + 1].Type;
                    if (configuredCardType != ExpansionCardType.None)
                    {
                        Common.Status.ExpansionCardStatus expansionCardStatus = this[slot + 1];
                        if (expansionCardStatus != null && 
                            expansionCardStatus.Type == configuredCardType)
                        {
                            reportingStatus.Add(slot, expansionCardStatus);
                        }
                    }
                }

                if (reportingStatus.Count == 0)
                    return;

                Common.ExpansionCardStatus[] expansionCardStatusToSend = new Common.ExpansionCardStatus[ExpansionSlotCount];
                for (int slot = 0; slot < ExpansionSlotCount; slot++)
                {
                    if (reportingStatus.ContainsKey(slot))
                    {
                        if (reportingStatus[slot].Online == true)
                        {
                            if (reportingStatus[slot].FuseFailed == true)
                            {
                                expansionCardStatusToSend[slot] = Common.ExpansionCardStatus.FuseFail;
                            }
                            else
                            {
                                expansionCardStatusToSend[slot] = Common.ExpansionCardStatus.Online;
                            }
                        }
                        else
                        {
                            expansionCardStatusToSend[slot] = Common.ExpansionCardStatus.Offline;
                        }
                    }
                    else
                    {
                        expansionCardStatusToSend[slot] = Common.ExpansionCardStatus.Online;
                    }
                }
                Parent.DeviceResponseProcessor.SendCurrentExpansionCardStatuses(expansionCardStatusToSend);

                // Log response
                StringBuilder sb = new StringBuilder();
                for (int slot = 0; slot < ExpansionSlotCount; slot++)
                {
                    if (sb.Length != 0)
                        sb.Append(", ");
                    sb.Append(expansionCardStatusToSend[slot].ToString());
                }
                Logger.LogDebugMessage(LoggerClassPrefixes.CommandProcessor, () =>
                {
                    return string.Format("Expansion card status response. Sent expansion card states ({0}).", sb.ToString());
                });
            }
        }

        internal void TriggerExpansionCardTypeNotification()
        {
            if (StatusManager.Instance.Device.IsAnyConnectionValid == false)
                return;

            if (ConfigurationManager.Instance.ControllerMessaging.DoesNotHave(MessagingFlags.RestoreDefaultsAndSwitchAllReportingToExtendedFormat))
            {
                ExpansionCardType[] expansionCardTypes = new ExpansionCardType[ExpansionSlotCount];
                for (int slot = 0; slot < ConfigurationManager.LegacyExpansionSlotCount; slot++) // The legacy firmware on controller supports only two slots.
                {
                    Common.Status.ExpansionCardStatus expansionCardStatus = this[slot + 1];
                    if (expansionCardStatus != null)
                        expansionCardTypes[slot] = expansionCardStatus.Type;
                    else
                        expansionCardTypes[slot] = ExpansionCardType.None;
                }
                Parent.DeviceResponseProcessor.SendCurrentExpansionCardTypes(expansionCardTypes);

                // Log response
                StringBuilder sb = new StringBuilder();
                for (int slot = 0; slot < ConfigurationManager.LegacyExpansionSlotCount; slot++) // The legacy firmware on controller supports only two slots.
                {
                    if (sb.Length != 0)
                        sb.Append(", ");
                    sb.Append(expansionCardTypes[slot].ToString());
                }
                Logger.LogDebugMessage(LoggerClassPrefixes.CommandProcessor, () =>
                {
                    return string.Format("Expansion card types response. Sent expansion card types ({0}).", sb.ToString());
                });
            }
            else
            {
                ExpansionCardType[] expansionCardTypes = new ExpansionCardType[ExpansionSlotCount];
                for (int slot = 0; slot < ExpansionSlotCount; slot++)
                {
                    Common.Status.ExpansionCardStatus expansionCardStatus = this[slot + 1];
                    if (expansionCardStatus != null)
                        expansionCardTypes[slot] = expansionCardStatus.Type;
                    else
                        expansionCardTypes[slot] = ExpansionCardType.None;
                }
                Parent.DeviceResponseProcessor.SendCurrentExpansionCardTypes(expansionCardTypes);

                // Log response
                StringBuilder sb = new StringBuilder();
                for (int slot = 0; slot < ExpansionSlotCount; slot++)
                {
                    if (sb.Length != 0)
                        sb.Append(", ");
                    sb.Append(expansionCardTypes[slot].ToString());
                }
                Logger.LogDebugMessage(LoggerClassPrefixes.CommandProcessor, () =>
                {
                    return string.Format("Expansion card types response. Sent expansion card types ({0}).", sb.ToString());
                });
            }            
        }

        /// <summary>
        /// Trigger expansion card type and status notification.
        /// </summary>
        public void TriggerExpansionCardsReport()
        {
            if (StatusManager.Instance.Device.IsAnyConnectionValid == false)
                return;
            
            TriggerExpansionCardTypeNotification();
            TriggerExpansionCardStatusNotification();
        }
    }
}
