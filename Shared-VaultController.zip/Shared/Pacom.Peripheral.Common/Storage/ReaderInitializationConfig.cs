﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{
    public class ReaderInitializationConfig
    {
        public ReaderInitializationConfig()
        {
            Facility = new CardConfigPart();
            Issue = new CardConfigPart();
            Code = new CardConfigPart();
            Designators = new CardFormatDesignatorConfig();
            ReaderType = CardReaderType.NoReader;
            SupervisedEgressInput = true;
            SupervisedEgressInputPresent = false;
        }

        /// <summary>
        /// Store card type. Byte 0.
        /// </summary>
        public CardReaderType ReaderType
        {
            get;
            set;
        }

        /// <summary>
        /// Store facility code. Byte 1 and 2.
        /// </summary>
        public CardConfigPart Facility
        {
            get;
            set;
        }

        /// <summary>
        /// Store issue. Byte 3 and 4.
        /// </summary>
        public CardConfigPart Issue
        {
            get;
            set;
        }

        /// <summary>
        /// Store code. Byte 5 and 6.
        /// </summary>
        public CardConfigPart Code
        {
            get;
            set;
        }

        /// <summary>
        /// Describes field designators for creating legacy card message. These values must be provided with accuracy of 4 bits to map back to nibbles.
        /// Valus which cannot be devided by 4 bits will generate exceptions when constructing messages back to device. Byte 7.
        /// </summary>
        public CardFormatDesignatorConfig Designators
        {
            get;
            set;
        }
        
        /// <summary>
        /// Strike on duration for degraded mode operation only. Byte 8.
        /// </summary>
        public int StrikeDuration
        {
            get;
            set;
        }

        /// <summary>
        /// Embarrassment timer (not supported in DC). Byte 9.
        /// </summary>
        public int EmbarrassmentTimer
        {
            get;
            set;
        }

        /// <summary>
        /// Led flash duration for accept. Byte 10 (Degraded mode only) 
        /// </summary>
        public byte AcceptLedFlashTime
        {
            get;
            set;
        }

        /// <summary>
        /// Led flash enabled for accept. Byte 10 (Degraded mode only)
        /// </summary>
        public bool AcceptLedFlashEnabled
        {
            get;
            set;
        }

        /// <summary>
        /// Led flash duration for denied. Byte 11 (Degraded mode only)
        /// </summary>
        public byte DeniedLedFlashTime
        {
            get;
            set;
        }

        /// <summary>
        /// Led flash enabled for accept. Byte 11 (Degraded mode only)
        /// </summary>
        public bool DeniedLedFlashEnabled
        {
            get;
            set;
        }

        /// <summary>
        /// Led flash duration for card read error. Byte 12 (Degraded mode only)
        /// </summary>
        public byte InvalidLedFlashTime
        {
            get;
            set;
        }

        /// <summary>
        /// Led flash enabled for card read error. Byte 12 (Degraded mode only)
        /// </summary>
        public bool InvalidLedFlashEnabled
        {
            get;
            set;
        }

        /// <summary>
        /// Type of buzzer for invalid mode. Byte 12.
        /// </summary>
        public CardReaderBuzzerType InvalidBuzzer
        {
            get;
            set;
        }

        /// <summary>
        /// Hit count for contact input. Byte 13.
        /// </summary>
        public byte ContactHitCount
        {
            get;
            set;
        }

        /// <summary>
        /// Hit count for egress input. Byte 13.
        /// </summary>
        public byte EgressHitCount
        {
            get;
            set;
        }

        /// <summary>
        /// Hit count for strike input. Byte 14.
        /// </summary>
        public byte StrikeHitCount
        {
            get;
            set;
        }



        /// <summary>
        /// Set to false for strike relay when off is N/O (normally open). Set to true for strike relay when off is N/C (normally close). Byte 14.
        /// </summary>
        public bool StrikeRelayNormallyClosed
        {
            get;
            set;
        }

        /// <summary>
        /// Set to false for process contact input as secure normally. Set to true for process contact input as alarm normally. Byte 14.
        /// </summary>
        public bool ContactNegative
        {
            get;
            set;
        }

        /// <summary>
        /// Set to false for process egress input as secure normally. Set to true for process egress input as alarm normally. Byte 14.
        /// </summary>
        public bool EgressNegative
        {
            get;
            set;
        }

        /// <summary>
        /// Set to false for process strike input as secure normally. Set to true for process strike input as alarm normally. Byte 14.
        /// </summary>
        public bool StrikeNegative
        {
            get;
            set;
        }
        
        /// <summary>
        /// Keypad inactivity timer in seconds. Byte 15.
        /// </summary>
        public byte KeypadInactivityTimer
        {
            get;
            set;
        }

        /// <summary>
        /// Number of digits to enter on the keypad. Byte 15.
        /// </summary>
        public byte KeypadNoDigitsToEnter
        {
            get;
            set;
        }

        /// <summary>
        /// Set to true in order to enable the "*" key to be sent with pin data (A hex). Byte 15.
        /// </summary>
        public bool KeypadSendKeyWithPin
        {
            get;
            set;
        }

        /// <summary>
        /// Beeper on time when pulsing (10 msec increments). Byte 16.
        /// </summary>
        public byte BeeperDuration
        {
            get;
            set;
        }

        /// <summary>
        /// Type of buzzer while in accept mode. Byte 17.
        /// </summary>
        public CardReaderBuzzerType AcceptBuzzer
        {
            get;
            set;
        }

        /// <summary>
        /// Type of buzzer while in denied mode. Byte 17.
        /// </summary>
        public CardReaderBuzzerType DeniedBuzzer
        {
            get;
            set;
        }

        /// <summary>
        /// Process egress locally flag. It is bit 0 of the flag byte. Byte 18.
        /// </summary>
        public bool ProcessEgressLocally
        {
            get;
            set;
        }

        /// <summary>
        /// Egress activate shunt timer only. It is bit 1 of the flag byte. Byte 18.
        /// </summary>
        public bool EgressShuntOnly
        {
            get;
            set;
        }

        /// <summary>
        /// Store code locally. It is bit 2 of the flag byte. Byte 18.
        /// </summary>
        public bool StoreCodeLocally
        {
            get;
            set;
        }

        /// <summary>
        /// Keep strike on during egress (Strike to follow egress). It is bit 3 of the flag byte. Byte 18.
        /// </summary>
        public bool KeepStrikeDuringEgress
        {
            get;
            set;
        }

        /// <summary>
        /// Allow pin only entry. It is bit 4 of the flag byte. Byte 18.
        /// </summary>
        public bool AllowPinOnly
        {
            get;
            set;
        }

        /// <summary>
        /// Interlock passback. It is bit 5 of the flag byte. Byte 18.
        /// </summary>
        public bool InterlockPassback
        {
            get;
            set;
        }

        /// <summary>
        /// Reset in/out status for all users in this area. It is bit 6 of the flag byte. Byte 18.
        /// </summary>
        public bool ResetUserInOut
        {
            get;
            set;
        }

        /// <summary>
        /// Enable Time In Attend for this area. It is bit 7 of the flag byte. Byte 18.
        /// </summary>
        public bool EnableTimeInAttend
        {
            get;
            set;
        }

        /// <summary>
        /// If true, Egress inputs on the door are supervised (Open, Alarm, Short, Secure, Trouble).  Byte 19.
        /// If false, Egress inputs on the door are not supervised (Open, Short) and respond much quicker.
        /// </summary>
        public bool SupervisedEgressInput
        {
            get;
            set;
        }

        /// <summary>
        /// If true, Egress input byte is present.  Byte 20.
        /// </summary>
        public bool SupervisedEgressInputPresent
        {
            get;
            set;
        }

        /// <summary>
        /// Calculate hash code for the reader configuration class. It should reflect the logic done by Equals.
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        /// <summary>
        /// Compare reader configuration settings
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            // The passed parameter is null
            if (obj == null)
            {
                return false;
            }
            // Attempt to cast reader configuration
            ReaderInitializationConfig config = obj as ReaderInitializationConfig;
            if (config == null)
            {
                return false;
            }

            // Compare settings here
            if (this.ReaderType != config.ReaderType)
                return false;

            if (this.Facility.IncludeInMask != config.Facility.IncludeInMask)
                return false;
            if (this.Facility.Length != config.Facility.Length)
                return false;
            if (this.Facility.ZeroBasedOffset != config.Facility.ZeroBasedOffset)
                return false;
            if (this.Facility.UnitType != config.Facility.UnitType)
                return false;

            if (this.Issue.IncludeInMask != config.Issue.IncludeInMask)
                return false;
            if (this.Issue.Length != config.Issue.Length)
                return false;
            if (this.Issue.ZeroBasedOffset != config.Issue.ZeroBasedOffset)
                return false;
            if (this.Issue.UnitType != config.Issue.UnitType)
                return false;

            if (this.Code.IncludeInMask != config.Code.IncludeInMask)
                return false;
            if (this.Code.Length != config.Code.Length)
                return false;
            if (this.Code.ZeroBasedOffset != config.Code.ZeroBasedOffset)
                return false;
            if (this.Code.UnitType != config.Code.UnitType)
                return false;

            if (this.Designators.Facility != config.Designators.Facility)
                return false;
            if (this.Designators.Issue != config.Designators.Issue)
                return false;

            if (this.StrikeDuration != config.StrikeDuration)
                return false;
            if (this.EmbarrassmentTimer != config.EmbarrassmentTimer)
                return false;

            if (this.AcceptLedFlashTime != config.AcceptLedFlashTime)
                return false;
            if (this.AcceptLedFlashEnabled != config.AcceptLedFlashEnabled)
                return false;

            if (this.DeniedLedFlashTime != config.DeniedLedFlashTime)
                return false;
            if (this.DeniedLedFlashEnabled != config.DeniedLedFlashEnabled)
                return false;

            if (this.InvalidLedFlashTime != config.InvalidLedFlashTime)
                return false;
            if (this.InvalidLedFlashEnabled != config.InvalidLedFlashEnabled)
                return false;

            if (this.InvalidBuzzer != config.InvalidBuzzer)
                return false;

            if (this.ContactHitCount != config.ContactHitCount)
                return false;
            if (this.EgressHitCount != config.EgressHitCount)
                return false;
            if (this.StrikeHitCount != config.StrikeHitCount)
                return false;

            if (this.StrikeRelayNormallyClosed != config.StrikeRelayNormallyClosed)
                return false;
            if (this.ContactNegative != config.ContactNegative)
                return false;
            if (this.EgressNegative != config.EgressNegative)
                return false;
            if (this.StrikeNegative != config.StrikeNegative)
                return false;

            if (this.KeypadInactivityTimer != config.KeypadInactivityTimer)
                return false;
            if (this.KeypadNoDigitsToEnter != config.KeypadNoDigitsToEnter)
                return false;
            if (this.KeypadSendKeyWithPin != config.KeypadSendKeyWithPin)
                return false;

            if (this.AcceptBuzzer != config.AcceptBuzzer)
                return false;
            if (this.DeniedBuzzer != config.DeniedBuzzer)
                return false;

            if (this.ProcessEgressLocally != config.ProcessEgressLocally)
                return false;
            if (this.EgressShuntOnly != config.EgressShuntOnly)
                return false;
            if (this.StoreCodeLocally != config.StoreCodeLocally)
                return false;
            if (this.KeepStrikeDuringEgress != config.KeepStrikeDuringEgress)
                return false;
            if (this.AllowPinOnly != config.AllowPinOnly)
                return false;
            if (this.InterlockPassback != config.InterlockPassback)
                return false;
            if (this.ResetUserInOut != config.ResetUserInOut)
                return false;
            if (this.EnableTimeInAttend != config.EnableTimeInAttend)
                return false;

            if (this.SupervisedEgressInput != config.SupervisedEgressInput)
                return false;

            return true;
        }

        public override string ToString()
        {
            return string.Format("Reader Type: {0}, Strike duration: {1}", ReaderType.ToString(), StrikeDuration.ToString());
        }
    }
}
