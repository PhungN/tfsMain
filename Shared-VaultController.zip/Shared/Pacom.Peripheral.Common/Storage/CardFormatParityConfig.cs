﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Parity configuration storage class.
    /// </summary>
    public class CardFormatParityConfig
    {
        private const int MaxParityConfig = 3;
        /// <summary>
        /// Parity configuration class constructor.
        /// </summary>
        public CardFormatParityConfig()
        {
            Mask = new CardParityConfigPart[MaxParityConfig];

            for (int i = 0; i < MaxParityConfig; i++)
            {
                Mask[i] = new CardParityConfigPart();
                Mask[i].Enabled = false;
            }

            Reverse = false;
            Invert = false;
        }

        /// <summary>
        /// Parity configuration class constructor.
        /// data[offset] = Option
        ///     [offset+[1-8]] = Mask 1
        ///     [offset+[9-16]] = Mask 2
        ///     [offset+[17-24]] = Mask 3
        ///     [offset+[25]] = Mask 1 Offset
        ///     [offset+[26]] = Mask 2 Offset
        ///     [offset+[27]] = Mask 3 Offset
        /// </summary>
        public CardFormatParityConfig(byte[] data, int offset) : this()
        {
            byte option = data[offset];
            int maskIndex = offset + 1;
            int maskOffsetIndex = offset + 25;
            for (int i = 0; i < MaxParityConfig; i++)
            {
                var mask = Mask[i];
                byte parityEnableBitMask = (byte)(1 << i);
                if ((option & parityEnableBitMask) == parityEnableBitMask)
                {
                    mask.Enabled = true;
                    byte oddParityBitMask = (byte)(1 << (i+4));
                    mask.OddParity = (option & oddParityBitMask) == oddParityBitMask;
                    mask.Offset = data[maskOffsetIndex++];
                    Array.Copy(data, maskIndex, mask.Mask, 0, 8);
                    maskIndex += 8;
                }
            }
            Invert = (option & 0x80) == 0x80;
            Reverse = (option & 0x08) == 0x08;
        }

        /// <summary>
        /// True for reverse bit processing.
        /// </summary>
        public bool Reverse;

        /// <summary>
        /// True for invert bit processing.
        /// </summary>
        public bool Invert;

        /// <summary>
        /// Parity mask. It will be preconfigured with 3 masks, all disabled.
        /// </summary>
        public CardParityConfigPart[] Mask;

        /// <summary>
        /// return 28 byte array:
        /// data[0] = Option
        ///     [1-8] = Mask 1
        ///     [9-16] = Mask 2
        ///     [17-24] = Mask 3
        ///     [25] = Mask 1 Offset
        ///     [26] = Mask 2 Offset
        ///     [27] = Mask 3 Offset
        /// </summary>
        public byte[] Data
        {
            get
            {
                byte option = 0;
                byte[] Data = new byte[28];
                int maskIndex = 1;
                int maskOffsetIndex = 25;
                for (int i = 0; i < MaxParityConfig; i++)
                {
                    var mask = Mask[i];
                    if (mask != null && mask.Enabled)
                    {
                        option |= (byte)(1 << i);
                        if (mask.OddParity)
                            option |= (byte)(1 << (i + 4));
                        Array.Copy(mask.Mask, 0, Data, maskIndex, Math.Min(8, mask.Mask.Length));
                    }
                    maskIndex += 8;
                    Data[maskOffsetIndex++] = (byte)mask.Offset;
                }
                if (Invert)
                    option |= 0x80;
                if (Reverse)
                    option |= 0x08;
                Data[0] = option;
                return Data;
            }
        }
    }
}
