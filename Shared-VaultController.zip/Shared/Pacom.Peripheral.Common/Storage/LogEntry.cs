﻿using System;

namespace Pacom.Peripheral.Common
{
    public class LogEntry
    {
        public LogEntry(DateTime time, string message)
        {
            Time = time;
            Message = message;
        }

        public DateTime Time
        {
            get;
            private set;
        }

        public string Message
        {
            get;
            private set;
        }

        public override string ToString()
        {
            return this.Time.ToString(Logger.DateTimeFormat) + ": " + this.Message;
        } 
    }
}
