﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{

    /// <summary>
    /// Holds format mask configuration
    /// </summary>
    public class CardFormatMaskConfig
    {
        public CardFormatMaskConfig()
        {
            this.NumberOfWiegandBits = 0;
            this.Facility = new CardConfigPart();
            this.Issue = new CardConfigPart();
            this.Code = new CardConfigPart();
            this.Designators = new CardFormatDesignatorConfig();
        }

        /// <summary>
        /// Holds number of Wiegand bits
        /// </summary>
        public int NumberOfWiegandBits
        {
            get;
            set;
        }

        /// <summary>
        /// Holds details about facility mask configuration
        /// </summary>
        public CardConfigPart Facility
        {
            get;
            set;
        }

        /// <summary>
        /// Format designators.
        /// </summary>
        public CardFormatDesignatorConfig Designators
        {
            get;
            set;
        }

        /// <summary>
        /// Holds details about issue mask configuration
        /// </summary>
        public CardConfigPart Issue
        {
            get;
            set;
        }

        /// <summary>
        /// Holds details about code mask configuration
        /// </summary>
        public CardConfigPart Code
        {
            get;
            set;
        }
    }
}