﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Class which holds event message data.
    /// The format is hardcoded in controller to 8 bytes. 
    /// 2 bytes for facility, 1 byte for issue and 5 bytes for code.
    /// If the field data is longer than the hardcoded designator data will be truncated.
    /// </summary>
    public class CardReaderEventDataConfig
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public CardReaderEventDataConfig()
        {
            this.ReaderNumber = CardReaderPortType.NoReader;
            this.Facility = new byte[0];
            this.Issue = new byte[0];
            this.Code = new byte[0];
            this.DayOfWeek = 0;
            this.Second = 0;
            this.Minute = 0;
            this.Hour = 0;
        }

        /// <summary>
        /// Reader from where the event took place.
        /// </summary>
        public CardReaderPortType ReaderNumber
        {
            get;
            set;
        }

        /// <summary>
        /// Card facility
        /// </summary>
        public byte[] Facility
        {
            get;
            set;
        }

        /// <summary>
        /// Card Issue
        /// </summary>
        public byte[] Issue
        {
            get;
            set;
        }

        /// <summary>
        /// Card Code
        /// </summary>
        public byte[] Code
        {
            get;
            set;
        }

        /// <summary>
        /// Event second
        /// </summary>
        public byte Second
        {
            get;
            set;
        }

        /// <summary>
        /// Event minute
        /// </summary>
        public byte Minute
        {
            get;
            set;
        }

        /// <summary>
        /// Event hour
        /// </summary>
        public byte Hour
        {
            get;
            set;
        }

        /// <summary>
        /// Event day of week
        /// </summary>
        public byte DayOfWeek
        {
            get;
            set;
        }
    }
}
