﻿using System;

namespace Pacom.Peripheral.Common
{
    public class OsdpReaderInfo
    {
        public bool Valid { get; set; }
        public byte[] VendorCode { get; set; }
        public int ModelNumber { get; set; }
        public int Version { get; set; }
        public byte[] SerialNumber { get; set; }
        public int FirmwareMajor { get; set; }
        public int FirmwareMinor { get; set; }
        public int FirmwareBuild { get; set; }

        public OsdpReaderInfo()
        {
            Valid = false;
        }
    }
}