﻿using System;

namespace Pacom.Peripheral.Common
{
    public class FirmwareVersion
    {
        public FirmwareVersion()
        {
        }

        public FirmwareVersion(int major, int minor)
        {
            Minor = minor;
            Major = major;
        }

        public FirmwareVersion(string version)
        {
            try
            {
                Minor = 0;
                Major = 1;
                if (version.Length == 5 && version[2] == '.')
                {
                    Major = int.Parse(version.Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
                    Minor = int.Parse(version.Substring(3, 2), System.Globalization.NumberStyles.HexNumber);
                }
                else if (version.Length == 4 && version[1] == '.')
                {
                    Major = int.Parse(version.Substring(0, 1), System.Globalization.NumberStyles.HexNumber);
                    Minor = int.Parse(version.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
                }
                else if (version.Length == 3 && version[1] == '.')
                {
                    Major = int.Parse(version.Substring(0, 1), System.Globalization.NumberStyles.HexNumber);
                    Minor = int.Parse(version.Substring(2, 1), System.Globalization.NumberStyles.HexNumber);
                }
            }
            catch
            {
            }
        }

        public int Minor
        {
            get;
            private set;
        }

        public int Major
        {
            get;
            private set;
        }

        public override string ToString()
        {
            if (Major == 0 && Minor == 0)
                return "--.--";

            return string.Format("{0}.{1}", Major.ToString("x2"), Minor.ToString("x2"));
        }

        public override bool Equals(object obj)
        {
            FirmwareVersion firmwareToCompare = obj as FirmwareVersion;
            if (firmwareToCompare != null && firmwareToCompare.Major == Major && firmwareToCompare.Minor == Minor)
                return true;
            return false;
        }

        public static bool operator <(FirmwareVersion x, FirmwareVersion y)
        {
            if (x == null || y == null)
                return false;
            if (x.Major < y.Major)
                return true;
            else if (x.Major > y.Major)
                return false;
            else if (x.Minor < y.Minor)
                return true;
            return false;
        }

        public static bool operator >(FirmwareVersion x, FirmwareVersion y)
        {
            if (x == null || y == null)
                return false;
            if (x.Major > y.Major)
                return true;
            else if (x.Major < y.Major)
                return false;
            else if (x.Minor > y.Minor)
                return true;
            return false;
        }

        public static bool operator <=(FirmwareVersion x, FirmwareVersion y)
        {
            if (x == null || y == null)
                return false;
            if (x.Major == y.Major && x.Minor == y.Minor)
                return true;
            if (x.Major < y.Major)
                return true;
            if (x.Major > y.Major)
                return false;
            if (x.Minor < y.Minor)
                return true;
            return false;
        }

        public static bool operator >=(FirmwareVersion x, FirmwareVersion y)
        {
            if (x == null || y == null)
                return false;
            if (x.Major == y.Major && x.Minor == y.Minor)
                return true;
            if (x.Major > y.Major)
                return true;
            if (x.Major < y.Major)
                return false;
            if (x.Minor > y.Minor)
                return true;
            return false;
        }

        public override int GetHashCode()
        {
            return (Major << 8) + Minor;
        }
    }
}
