﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{

    /// <summary>
    /// This class is storing card reader input change.
    /// Individual inputs will only accept the following states:
    /// 0 – reset
    /// 1 – alarm
    /// 2 – short
    /// 3 – open
    /// 4 – trouble
    /// </summary>
    public class ReaderInputStatusChangeConfig
    {
        /// <summary>
        /// Store card type. Byte 0.
        /// </summary>
        public CardReaderType ReaderType
        {
            get;
            set;
        }

        private InputStatus contactState = InputStatus.Secure;

        public InputStatus ContactState
        {
            get
            {
                return contactState;
            }
            set
            {
                if (value == InputStatus.Unknown || value == InputStatus.Analog)
                {
                    throw new ArgumentException("Invalid contact state.");
                }
                contactState = value;
            }
        }

        private InputStatus egressState = InputStatus.Secure;

        public InputStatus EgressState
        {
            get
            {
                return egressState;
            }
            set
            {
                if (value == InputStatus.Unknown || value == InputStatus.Analog)
                {
                    throw new ArgumentException("Invalid egress state.");
                }
                egressState = value;
            }
        }

        private InputStatus strikeState = InputStatus.Secure;

        public InputStatus StrikeState
        {
            get
            {
                return strikeState;
            }
            set
            {
                if (value == InputStatus.Unknown || value == InputStatus.Analog)
                {
                    throw new ArgumentException("Invalid strike state.");
                }
                strikeState = value;
            }
        }

        private InputStatus spareState = InputStatus.Secure;

        public InputStatus SpareState
        {
            get
            {
                return spareState;
            }
            set
            {
                if (value == InputStatus.Unknown || value == InputStatus.Analog)
                {
                    throw new ArgumentException("Invalid spare state.");
                }
                spareState = value;
            }
        }

        public override string ToString()
        {
            return string.Format("ReaderType: {0}, Door contact: {1}, Egress: {2}, Strike: {3}, Spare: {4}", ReaderTypeAsString, contactState.ToString(), 
                                                                                                                                 egressState.ToString(), 
                                                                                                                                 strikeState.ToString(),
                                                                                                                                 spareState.ToString());
        }

        private string ReaderTypeAsString
        {
            get { return ReaderType.ToString(); }
        }

    }
}
