﻿
namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Represents default values on the device attached to the Pacom device loop.
    /// </summary>
    public class DeviceDefaultConfiguration
    {
         #region Instance management

        private static DeviceDefaultConfiguration instance = null;
        private readonly static object instanceLock = new object();

        public static DeviceDefaultConfiguration Instance
        {
            get
            {
                lock (instanceLock)
                {
                    if (instance == null)
                    {
                        instance = new DeviceDefaultConfiguration();
                    }
                    return instance;
                }
            }
        }

        private DeviceDefaultConfiguration()
        {            
        }
          
        #endregion

        public readonly DeviceInputDefaultConfiguration Input = new DeviceInputDefaultConfiguration();
        public readonly DeviceOutputDefaultConfiguration Output = new DeviceOutputDefaultConfiguration();
        public readonly DeviceDoorDefaultConfiguration Door = new DeviceDoorDefaultConfiguration();
    }

    /// <summary>
    /// Default values for device inputs (Should be only Pacom device loop devices)
    /// </summary>
    public class DeviceInputDefaultConfiguration
    {
        /// <summary>
        /// Default input reporting = false
        /// </summary>
        public readonly bool ReportPoint = false;

        /// <summary>
        /// Default input hit count = 3
        /// </summary>
        public readonly int HitCount = 3;

        /// <summary>
        /// Default input tolerance = 25 %
        /// </summary>
        public readonly ResistorTolerance Tolerance = ResistorTolerance.TwentyFivePercent;

        /// <summary>
        /// Default alarm resistance = 20 KOhm
        /// </summary>
        public readonly int AlarmResistance = 20000;

        /// <summary>
        /// Default secure resistance = 10 KOhm
        /// </summary>
        public readonly int SecureResistance = 10000;

        /// <summary>
        /// Default masking resistance = 0
        /// </summary>
        public readonly int MaskingResistance = 0;

        /// <summary>
        /// Default range reduction resistance = 0
        /// </summary>
        public readonly int RangeReductionResistance = 0;

        /// <summary>
        /// Default input analog resolution = 5
        /// </summary>
        public readonly int AnalogInputResolution = 5;

        /// <summary>
        /// Return resistance value by its type enum.
        /// </summary>
        /// <param name="resistanceValueType"></param>
        /// <returns></returns>
        public int GetResistanceValue(ResistanceValueType resistanceValueType)
        {
            switch (resistanceValueType)
            {
                case ResistanceValueType.Secure: return SecureResistance;
                case ResistanceValueType.Alarm: return AlarmResistance;
                case ResistanceValueType.Masking: return MaskingResistance;
                case ResistanceValueType.RangeReduction: return RangeReductionResistance;
                default: return 0;
            }
        }
    }

    /// <summary>
    /// Default values for device outputs (Should be only Pacom device loop devices)
    /// </summary>
    public class DeviceOutputDefaultConfiguration
    {
        /// <summary>
        /// Default value for an output on the device.
        /// </summary>
        public readonly bool Active = false;
    }
    
    /// <summary>
    /// Default values for device doors on device with access control capabilities
    /// </summary>
    public class DeviceDoorDefaultConfiguration
    {
        /// <summary>
        /// Default value for a door on the device.
        /// </summary>
        public readonly bool Active = false;
    }

}
