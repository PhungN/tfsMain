﻿using System;

namespace Pacom.Peripheral.Common
{
    public class ExpansionCardConfiguration
    {
        public ExpansionCardConfigurationPhysicalPort PhysicalPort;
        public ExpansionCardConfigurationExpansionCardType CardType;
        public ExpansionCardConfigurationPortType PortType;
    }
}
