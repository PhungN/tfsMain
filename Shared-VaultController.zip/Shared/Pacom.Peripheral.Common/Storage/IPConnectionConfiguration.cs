﻿using System;
using System.Net;
using System.Text;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class holds configuration necessary to establish IP connection to the controller.
    /// </summary>
    public class IPConnectionConfiguration
    {
        public IPConnectionConfiguration(bool connectionRequired, bool autoDiscovery, NetworkAddress controllerAddress, 
            int port, int controllerNumber, int deviceAddress)
        {
            ConnectionRequired = connectionRequired;
            AutoDiscovery = autoDiscovery;
            ControllerAddress = controllerAddress;
            Port = port;
            ControllerNumber = controllerNumber;
            DeviceAddress = deviceAddress;
        }

        public bool ConnectionRequired
        {
            get;
            private set;
        }

        public bool AutoDiscovery
        {
            get;
            private set;
        }

        public NetworkAddress ControllerAddress
        {
            get;
            private set;
        }

        public int Port
        {
            get;
            private set;
        }

        public int ControllerNumber
        {
            get;
            private set;
        }

        public int DeviceAddress
        {
            get;
            private set;
        }

        public IPEndPoint EndPoint
        {
            get
            {
                try
                {
                    return new IPEndPoint(ControllerAddress.Address, Port);
                }
                catch (ArgumentOutOfRangeException e)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return "Error: " + e.Message + " while trying to create Network End Point.";
                    });
                }
                catch (Exception e)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.ConfigurationManager, () =>
                    {
                        return "Error: " + e.Message + " while trying to create Network End Point.";
                    });
                }
                return null;
            }
        }

        public override bool Equals(object obj)
        {
            IPConnectionConfiguration config = obj as IPConnectionConfiguration;
            if (config == null)
                return false;

            if (config.ConnectionRequired != this.ConnectionRequired)
                return false;
            if (config.AutoDiscovery != this.AutoDiscovery)
                return false;
            if (config.ControllerAddress.Equals(this.ControllerAddress) == false)
                return false;
            if (config.Port.Equals(Port) == false)
                return false;
            if (config.ControllerNumber != this.ControllerNumber)
                return false;
            if (config.DeviceAddress != this.DeviceAddress)
                return false;
            return true;
        }

        public override int GetHashCode()
        {
            return ConnectionRequired.GetHashCode() ^ AutoDiscovery.GetHashCode() ^ ControllerAddress.GetHashCode() ^ Port.GetHashCode() ^ 
                ControllerNumber.GetHashCode() ^ DeviceAddress.GetHashCode();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(20);
            sb.Append(string.Format("ConnectionRequired : {0}", ConnectionRequired));
            sb.Append(string.Format(", AutoDiscovery : {0}", AutoDiscovery ? "Enabled" : "Disabled"));
            sb.Append(string.Format(", DeviceAddress : {0}", DeviceAddress + 1));
            sb.Append(string.Format(", ControllerAddress : {0}", ControllerAddress.Address));
            sb.Append(string.Format(", ControllerNumber : {0}", ControllerNumber == ConfigFile.AnyController ? "Any" : (ControllerNumber + 1).ToString()));
            return sb.ToString();
        }
    }
}
