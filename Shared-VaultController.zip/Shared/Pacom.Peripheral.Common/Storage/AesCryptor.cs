﻿using System;
using System.Security.Cryptography;

namespace Pacom.Peripheral.Common
{
    public class AesCryptor
    {
        public AesCryptor(ICryptoTransform aesEncryptor, ICryptoTransform aesDecryptor)
        {
            AesEncryptor = aesEncryptor;
            AesDecryptor = aesDecryptor;
        }

        ~AesCryptor()
        {
            AesEncryptor.Dispose();
            AesDecryptor.Dispose();
        }

        public ICryptoTransform AesEncryptor
        {
            get;
            private set;
        }

        public ICryptoTransform AesDecryptor
        {
            get;
            private set;
        }
    }
}