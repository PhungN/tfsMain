﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Storage for sending CardDataSend message.
    /// </summary>
    public class CardReaderDataSendDataConfig
    {
        /// <summary>
        /// Constructor sets default values.
        /// </summary>
        public CardReaderDataSendDataConfig()
        {
            this.ReaderType = CardReaderType.NoReader;
            this.Facility = new byte[0];
            this.Issue = new byte[0];
            this.Code = new byte[0];
            this.Format = -1;
            this.designators = new CardFormatDesignatorConfig();
        }

        /// <summary>
        /// Card type.
        /// </summary>
        public CardReaderType ReaderType
        {
            get;
            set;
        }

        /// <summary>
        /// Byte array with card facility.
        /// </summary>
        public byte[] Facility
        {
            get;
            set;
        }

        /// <summary>
        /// Byte array with card issue.
        /// </summary>
        public byte[] Issue
        {
            get;
            set;
        }

        /// <summary>
        /// Byte array with card code.
        /// </summary>
        public byte[] Code
        {
            get;
            set;
        }

        /// <summary>
        /// Card format.
        /// Format 0 - reader initialization record
        /// Format 1..4 - reader multi configuration
        /// </summary>
        public int Format
        {
            get;
            set;
        }

        private CardFormatDesignatorConfig designators;

        /// <summary>
        /// Designators are required to format message back to GMS
        /// Format 0 - use designators from reader initialization record
        /// Format 1..4 - use designators from card format configuration
        /// </summary>
        public CardFormatDesignatorConfig Designators
        {
            get
            {
                return designators;
            }
            set
            {
                designators = value;
            }
        }
    }
}
