﻿using System.Text;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    ///  Handle device serial number
    /// </summary>
    public partial class SerialNumberAgent
    {
        /// <summary>
        /// Singleton instatnce of SerialNumberAgent class
        /// </summary>
        private static SerialNumberAgent instance = null;

        /// <summary>
        /// Instance method to get singleton
        /// </summary>
        /// <returns></returns>
        public static SerialNumberAgent Instance
        {
            // Lock deliberately omitted
            get
            {
                if (instance == null)
                    instanceMustBeCreated();
                return instance;
            }
        }

        private static void instanceMustBeCreated()
        {
            Logger.LogErrorMessage(LoggerClassPrefixes.HostingApplication, () =>
            {
                return "Serial number access class instance must be created before usage. Call CreateInstance() method before using this property.";
            });
        }

        /// <summary>
        /// Check if Pacom product serial number is in a valid format.
        /// </summary>
        /// <param name="serialNumber">Byte array with serial number information.</param>
        /// <returns>Return True if the serial number is valid.</returns>
        public static bool IsSerialNumberValid(byte[] serialNumber)
        {
            if (serialNumber == null || serialNumber.Length != 16)
                return false;

            return isSerialNumberValid(Encoding.ASCII.GetString(serialNumber, 0, serialNumber.Length));
        }

        /// <summary>
        /// Check if Pacom product serial number is in a valid format.
        /// </summary>
        /// <param name="serialNumber">String representing serial number information.</param>
        /// <returns>Return True if the serial number is valid.</returns>
        public static bool IsSerialNumberValid(string serialNumber)
        {            
            return isSerialNumberValid(serialNumber);
        }

        /// <summary>
        /// Load serial number into configuration manager.
        /// </summary>
        public void LoadSerialNumber()
        {
            using (ConfigurationManager.Instance.CreateConfigurationChanger())
            {
                byte[] serialNumber = new byte[16];
                if (SerialNumberAgent.Instance.Read(ref serialNumber) == true)
                {
                    string serialNumberString = ASCIIEncoding.ASCII.GetString(serialNumber, 0, serialNumber.Length);
                    ConfigurationManager.Instance.SerialNumber = serialNumberString;
                }
            }
        }
    }
}
