﻿using System.Text;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class holds configuration necessary to establish serial (RS485) connection to the controller.
    /// </summary>
    public class SerialConnectionConfiguration
    {
        public SerialConnectionConfiguration(bool connectionRequired, int baudRate, int deviceAddress)
        {
            ConnectionRequired = connectionRequired;
            BaudRate = baudRate;
            DeviceAddress = deviceAddress;
        }

        public bool ConnectionRequired
        {
            get;
            set;
        }

        public int BaudRate
        {
            get;
            set;
        }

        public int DeviceAddress
        {
            get;
            private set;
        }

        public override bool Equals(object obj)
        {
            SerialConnectionConfiguration config = obj as SerialConnectionConfiguration;
            if (config == null)
                return false;

            if (config.ConnectionRequired != this.ConnectionRequired)
                return false;
            if (config.BaudRate.Equals(this.BaudRate) == false)
                return false;
            if (config.DeviceAddress != this.DeviceAddress)
                return false;
            return true;
        }

        public override int GetHashCode()
        {
            return ConnectionRequired.GetHashCode() ^ BaudRate.GetHashCode() ^ DeviceAddress.GetHashCode();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(20);
            sb.Append(string.Format("ConnectionRequired : {0}", ConnectionRequired));
            sb.Append(string.Format(", DeviceAddress : {0}", DeviceAddress + 1));
            sb.Append(string.Format(", BaudRate : {0}", BaudRate));
            return sb.ToString();
        }
    }
}
