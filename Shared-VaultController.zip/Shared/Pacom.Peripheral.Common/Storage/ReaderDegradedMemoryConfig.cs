﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Configuration class used for degraded memory modification requests.
    /// </summary>
    public class ReaderDegradedMemoryConfig
    {

        public ReaderDegradedMemoryConfig()
        {
            this.CardType = CardReaderType.NoReader;
            this.FirstCard = new LegacyCardRecord();
            this.SecondCard = new LegacyCardRecord();
        }

        /// <summary>
        /// Store card type.
        /// </summary>
        public CardReaderType CardType
        {
            get;
            set;
        }

        /// <summary>
        /// Operation type. True for add and false for delete
        /// </summary>
        public bool AddCode
        {
            get;
            set;
        }

        /// <summary>
        /// True for modify Facility memory EEprom
        /// </summary>
        public bool ModifyFacility
        {
            get;
            set;
        }

        /// <summary>
        /// False for only one card number included and True for second card included to specify a range to and from.
        /// </summary>
        public bool CardRange
        {
            get;
            set;
        }

        /// <summary>
        /// False for master card store and True for Ram card store
        /// </summary>
        public bool MasterCardStore
        {
            get;
            set;
        }

        /// <summary>
        /// First card record. Usually one to be deleted from degraded memory.
        /// </summary>
        public LegacyCardRecord FirstCard;

        /// <summary>
        /// Second card number which will create range combining with first one.
        /// Only valid if CardRange flag is set to true.
        /// </summary>
        public LegacyCardRecord SecondCard;                
    }
}
