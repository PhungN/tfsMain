﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Storage for degraded mode card record.
    /// </summary>
    public class ReaderDegradedCardRecordRaw
    {
        public ReaderDegradedCardRecordRaw(byte[] cardData, int cardLength)
        {
            this.cardData = cardData;
            this.cardLength = cardLength;
        }
        
        private byte[] cardData;

        private int cardLength;

        public byte[] CardData
        {
            get
            {
                return this.cardData;
            }
        }

        public int CardLength
        {
            get
            {
                return this.cardLength;
            }
        }
    }
}
