﻿
namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class is storing card designators, in bits, for device loop messaging.
    /// </summary>
    public class CardFormatDesignatorConfig
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public CardFormatDesignatorConfig()
        {
            this.Facility = 0;
            this.Issue = 0;
            // Code recalculated to 64.
        }

        /// <summary>
        /// Max number of bits in the message to controller.
        /// </summary>
        public const int MaxDesignatorsBits = 64;

        private int facility = 0;
        private int issue = 0;
        private int code = 0;

        /// <summary>
        /// Facility field designator in bits.
        /// </summary>
        public int Facility
        {
            get
            {
                return this.facility;
            }
            set
            {
                if (value < 0)
                {
                    this.facility = 0;
                    this.code = MaxDesignatorsBits - this.issue;
                }
                else
                {
                    if (value > (MaxDesignatorsBits - this.issue))
                    {
                        this.facility = MaxDesignatorsBits - this.issue;
                    }
                    else
                    {
                        this.facility = value;
                    }
                    this.code = MaxDesignatorsBits - (this.issue + this.facility);
                }
            }
        }

        /// <summary>
        /// Issue field designator in bits.
        /// </summary>
        public int Issue
        {
            get
            {
                return this.issue;
            }
            set
            {
                if (value < 0)
                {
                    this.issue = 0;
                    this.code = MaxDesignatorsBits - this.facility;
                }
                else
                {
                    if (value > (MaxDesignatorsBits - this.facility))
                    {
                        this.issue = MaxDesignatorsBits - this.facility;
                    }
                    else
                    {
                        this.issue = value;
                    }
                    this.code = MaxDesignatorsBits - (this.issue + this.facility);
                }
            }
        }

        /// <summary>
        /// Code field designator in bits.
        /// </summary>
        public int Code
        {
            get
            {
                return this.code;
            }
        }

        /// <summary>
        /// Get/Set Facility and Issue designator
        /// </summary>
        public byte Designator
        {
            get
            {
                return (byte)(((Facility == 0 ? 0 : Facility / 4) & 0x0F) | (((Issue == 0 ? 0 : Issue / 4) << 4) & 0xF0));
            }
            set
            {
                Facility = (value & 0x0F) * 4;
                Issue = ((value & 0xF0) >> 4) * 4;
            }
        }
    }
}
