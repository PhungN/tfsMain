using System;
using System.Net;

namespace Pacom.Peripheral.Common
{
    public class NetworkAdapterInformation
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public bool UsingDHCP { get; set; }
        public IPAddressAndMask[] Addresses { get; set; }
        public IPAddress DefaultGateway { get; set; }
    }
}
