﻿using System;

namespace Pacom.Peripheral.Common
{
    public class CardMetadataRecord
    {
        public CardMetadataRecord()
        {
        }

        /// <summary>
        /// Page number where the card data 
        /// </summary>
        public int PageNumber = -1;

        /// <summary>
        /// Date time used to mark last use of the card.
        /// </summary>
        public DateTime LastUsed = DateTime.MinValue;
    }
}
