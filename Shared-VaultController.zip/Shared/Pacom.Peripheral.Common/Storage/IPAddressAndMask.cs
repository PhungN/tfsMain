﻿using System;
using System.Net;

namespace Pacom.Peripheral.Common
{
    public struct IPAddressAndMask
    {
        public IPAddress IPAddress;
        public IPAddress SubnetMask;
    }
}
