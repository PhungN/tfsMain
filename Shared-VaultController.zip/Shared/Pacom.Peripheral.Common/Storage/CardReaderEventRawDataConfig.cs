using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Class which holds event message with raw card data.
    /// If the field data is longer than 32 bytes or given length, the data bits will be truncated.
    /// </summary>
    public class CardReaderEventRawDataConfig
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public CardReaderEventRawDataConfig()
        {
            this.ReaderNumber = CardReaderPortType.NoReader;
            this.AccessDenied = false;
            this.CardData = new byte[0];
            this.CardLength = 0;            
            this.DayOfWeek = 0;
            this.Second = 0;
            this.Minute = 0;
            this.Hour = 0;
        }

        /// <summary>
        /// Reader from where the event took place.
        /// </summary>
        public CardReaderPortType ReaderNumber
        {
            get;
            set;
        }

        /// <summary>
        /// Set to true when access is denied.
        /// </summary>
        public bool AccessDenied
        {
            get;
            set;
        }

        /// <summary>
        /// Card data
        /// </summary>
        public byte[] CardData
        {
            get;
            set;
        }

        /// <summary>
        /// Card data length
        /// </summary>
        public int CardLength
        {
            get;
            set;
        }

        /// <summary>
        /// Event second
        /// </summary>
        public byte Second
        {
            get;
            set;
        }

        /// <summary>
        /// Event minute
        /// </summary>
        public byte Minute
        {
            get;
            set;
        }

        /// <summary>
        /// Event hour
        /// </summary>
        public byte Hour
        {
            get;
            set;
        }

        /// <summary>
        /// Event day of week
        /// </summary>
        public byte DayOfWeek
        {
            get;
            set;
        }
    }
}
