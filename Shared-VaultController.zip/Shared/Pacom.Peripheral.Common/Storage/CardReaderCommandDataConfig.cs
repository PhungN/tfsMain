﻿namespace Pacom.Peripheral.Common
{
    public class CardReaderCommandDataConfig
    {
        /// <summary>
        /// Default constructor.
        /// </summary>
        public CardReaderCommandDataConfig()
        {
        }

        /// <summary>
        /// Card reader type.
        /// </summary>
        public CardReaderType ReaderType
        {
            get;
            set;
        }

        #region Strike Section

        /// <summary>
        /// It is set to true if strike instruction is included in command message.
        /// </summary>
        public bool StrikeIncluded
        {
            get;
            set;
        }

        /// <summary>
        /// Instruction about strike state.
        /// </summary>
        public CardReaderStrikeType StrikeState
        {
            get;
            set;
        }

        /// <summary>
        /// Strike time in seconds or minutes as described in StrikeTimeInMinutes property.
        /// </summary>
        public int StrikeTime
        {
            get;
            set;
        }

        /// <summary>
        /// Indicates if strike time is in seconds (false) or minutes (true).
        /// </summary>
        public bool StrikeTimeInMinutes
        {
            get;
            set;
        }

        #endregion

        #region Buzzer Section

        /// <summary>
        /// It is set to true if buzzer instruction is included in command message.
        /// </summary>
        public bool BuzzerIncluded
        {
            get;
            set;
        }

        /// <summary>
        /// Instruction modifies normal state for Buzzer.
        /// </summary>
        public bool BuzzerModifyNormal
        {
            get;
            set;
        }

        /// <summary>
        /// Modify Buzzer normal state.
        /// </summary>
        public CardReaderBuzzerType BuzzerModifyNormalType
        {
            get;
            set;
        }

        /// <summary>
        /// Modify current Buzzer state.
        /// </summary>
        public CardReaderBuzzerType BuzzerCurrentType
        {
            get;
            set;
        }

        /// <summary>
        /// Modify current Buzzer time duration.
        /// If time is zero go back to normal state.
        /// </summary>
        public int BuzzerCurrentTime
        {
            get;
            set;
        }

        #endregion

        #region Accept LED Section

        /// <summary>
        /// It is set to true if Accept Led instruction is included in command message.
        /// </summary>
        public bool AcceptLedIncluded
        {
            get;
            set;
        }

        /// <summary>
        /// Instruction modifies normal state for Accept LED.
        /// </summary>
        public bool AcceptLedModifyNormal
        {
            set;
            get;
        }

        /// <summary>
        /// Modify Accept LED normal state.
        /// </summary>
        public CardReaderLedType AcceptLedModifyNormalType
        {
            set;
            get;
        }

        /// <summary>
        /// Modify current Accept LED state.
        /// </summary>
        public CardReaderLedType AcceptLedCurrentType
        {
            set;
            get;
        }

        /// <summary>
        /// Modify current Accept LED time duration.
        /// </summary>
        public int AcceptLedCurrentTime
        {
            set;
            get;
        }

        #endregion

        #region Denied LED Section

        /// <summary>
        /// It is set to true if Denied Led instruction is included in command message.
        /// </summary>
        public bool DeniedLedIncluded
        {
            get;
            set;
        }

        /// <summary>
        /// Instruction modifies normal state for Denied LED.
        /// </summary>
        public bool DeniedLedModifyNormal
        {
            set;
            get;
        }

        /// <summary>
        /// Modify Denied LED normal state.
        /// </summary>
        public CardReaderLedType DeniedLedModifyNormalType
        {
            set;
            get;
        }

        /// <summary>
        /// Modify current Denied LED state.
        /// </summary>
        public CardReaderLedType DeniedLedCurrentType
        {
            set;
            get;
        }

        /// <summary>
        /// Modify current Denied LED time duration.
        /// </summary>
        public int DeniedLedCurrentTime
        {
            set;
            get;
        }

        #endregion

        #region Output Section

        /// <summary>
        /// Trigger output is included in this message.
        /// </summary>
        public bool OutputIncluded
        {
            get;
            set;
        }

        /// <summary>
        /// Instruction about strike state.
        /// </summary>
        public CardReaderOutputType OutputState
        {
            get;
            set;
        }

        /// <summary>
        /// Indicates for how long the spare output will be triggered.
        /// </summary>
        public byte OutputTime
        {
            get;
            set;
        }

        /// <summary>
        /// Indicates if output time is in seconds (false) or minutes (true).
        /// </summary>
        public bool OutputTimeInMinutes
        {
            get;
            set;
        }

        #endregion

        #region Output4 Section

        /// <summary>
        /// Trigger output is included in this message.
        /// </summary>
        public bool Output4Included
        {
            get;
            set;
        }

        /// <summary>
        /// Instruction about strike state.
        /// </summary>
        public CardReaderOutputType Output4State
        {
            get;
            set;
        }

        /// <summary>
        /// Indicates for how long the spare output will be triggered.
        /// </summary>
        public byte Output4Time
        {
            get;
            set;
        }

        /// <summary>
        /// Indicates if output time is in seconds (false) or minutes (true).
        /// </summary>
        public bool Output4TimeInMinutes
        {
            get;
            set;
        }

        #endregion
        /// <summary>
        /// Add last transaction to the degraded memory.
        /// </summary>
        public bool StoreCardInDegradedMemory
        {
            get;
            set;
        }

        // Bit 7 - never used
    }
}
