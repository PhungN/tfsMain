﻿using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Holds format masks configuration
    /// </summary>
    public class CardFormatMasksConfig
    {
        public const int MaxCardProfiles = 4;
        /// <summary>
        /// Creates four format masks
        /// </summary>
        public CardFormatMasksConfig()
        {
            masks = new CardFormatMaskConfig[MaxCardProfiles];
            for (int i = 0; i < MaxCardProfiles; i++)
            {
                masks[i] = new CardFormatMaskConfig();
            }
        }

        public CardFormatMasksConfig(byte[] data, int offset)
        {
            masks = new CardFormatMaskConfig[MaxCardProfiles];
            for (int i = 0; i < MaxCardProfiles; i++)
            {
                CardFormatMaskConfig mask = new CardFormatMaskConfig();
                mask.NumberOfWiegandBits            = data[offset++];
                mask.Facility.LengthAndUnitType     = data[offset++];
                mask.Facility.ZeroBaseOffsetAndMask = data[offset++];
                mask.Issue.LengthAndUnitType        = data[offset++];
                mask.Issue.ZeroBaseOffsetAndMask    = data[offset++];
                mask.Code.LengthAndUnitType         = data[offset++];
                mask.Code.ZeroBaseOffsetAndMask     = data[offset++];
                mask.Designators.Designator         = data[offset++];
                masks[i] = mask;
            }
        }

        private CardFormatMaskConfig[] masks;

        public CardFormatMaskConfig[] Masks
        {
            get
            {
                return masks;
            }
        }

        public CardFormatMaskConfig this[int index]
        {
            get
            {
                if (index < masks.Length)
                    return masks[index];
                return null;
            }
            set
            {
                if (index < masks.Length)
                    masks[index] = value;
            }
        }

        public byte[] Data
        {
            get
            {
                byte[] data = new byte[Masks.Length * 8];
                int index = 0;
                foreach (var mask in Masks)
                {
                    if (mask != null)
                    {
                        data[index++] = (byte)mask.NumberOfWiegandBits;
                        data[index++] = mask.Facility.LengthAndUnitType;
                        data[index++] = mask.Facility.ZeroBaseOffsetAndMask;
                        data[index++] = mask.Issue.LengthAndUnitType;
                        data[index++] = mask.Issue.ZeroBaseOffsetAndMask;
                        data[index++] = mask.Code.LengthAndUnitType;
                        data[index++] = mask.Code.ZeroBaseOffsetAndMask;
                        data[index++] = mask.Designators.Designator;
                    }
                }

                return data;
            }
        }
    }
}
