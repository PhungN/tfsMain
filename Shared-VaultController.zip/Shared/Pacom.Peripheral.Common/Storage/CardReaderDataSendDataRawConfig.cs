﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Storage for sending and receiving raw card data message.
    /// </summary>
    public class CardReaderDataSendDataRawConfig
    {
        public CardReaderDataSendDataRawConfig()
        {
        }

        /// <summary>
        /// Card type.
        /// </summary>
        public CardReaderType ReaderType
        {
            get;
            set;
        }

        /// <summary>
        /// Card data in format read from card reader. It will be converted to legacy message format by message itself.
        /// </summary>
        public byte[] Data
        {
            get;
            set;
        }

        /// <summary>
        /// Number of bits in data. If number of bits is lower than data array zero bits will replace missing data.
        /// </summary>
        public int NumberOfBits
        {
            get;
            set;
        }
    }
}
