﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.InteropServices;

namespace Pacom.Peripheral.Common
{
    public class BootImageConfig
    {
        private byte[] data;
        private int offset;

        public BootImageConfig(byte[] data, int offset)
        {
            this.data = data;
            this.offset = offset;
        }

        public FirmwareVersion ImageVersion
        {
            get
            {
                return new FirmwareVersion(data[offset + 0], data[offset + 1]);
            }
            set
            {
                data[offset + 0] = (byte)value.Major;
                data[offset + 1] = (byte)value.Minor;
            }
        }

        public int BootCount
        {
            get
            {
                return data[offset + 2];
            }
            set
            {
                data[offset + 2] = (byte)value;
            }
        }

        public int BuildNumber
        {
            get
            {
                return BitConverter.ToInt32(data, offset + 4);
            }
            set
            {
                Buffer.BlockCopy(BitConverter.GetBytes(value), 0, data, offset + 4, 4);
            }
        }

        public uint OffsetInFlash
        {
            get
            {
                return BitConverter.ToUInt32(data, offset + 8);
            }
            set
            {
                Buffer.BlockCopy(BitConverter.GetBytes(value), 0, data, offset + 8, 4);
            }
        }

        public int Length
        {
            get
            {
                return BitConverter.ToInt32(data, offset + 12);
            }
            set
            {
                Buffer.BlockCopy(BitConverter.GetBytes(value), 0, data, offset + 12, 4);
            }
        }

        public uint DestinationAddress
        {
            get
            {
                return BitConverter.ToUInt32(data, offset + 16);
            }
        }

        public uint LaunchAddress
        {
            get
            {
                return BitConverter.ToUInt32(data, offset + 20);
            }
        }

        public uint Crc
        {
            get
            {
                return BitConverter.ToUInt32(data, offset + 24);
            }
            set
            {
                Buffer.BlockCopy(BitConverter.GetBytes(value), 0, data, offset + 24, 4);
            }
        }
    }
}