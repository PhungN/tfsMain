using System;
using System.Net;

namespace Pacom.Peripheral.Common
{
    public class NetworkInformation
    {
        public NetworkAdapterInformation[] Adapters { get; set; }
        public IPAddress[] DnsServers { get; set; }
    }
}
