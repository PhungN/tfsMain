﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class stores degraded memory card data in legacy format.
    /// </summary>
    public class LegacyCardRecord
    {
        public LegacyCardRecord()
        {
            this.facility = new byte[0];
            this.issue = new byte[0];
            this.code = new byte[0];
        }

        public LegacyCardRecord(byte[] facility, byte[] issue, byte[] code)
        {
            this.facility = facility;
            this.issue = issue;
            this.code = code;
        }

        private byte[] facility;

        /// <summary>
        /// Two bytes for facility.
        /// </summary>
        public byte[] Facility
        {
            get
            {
                return this.facility;
            }
            set
            {
                if (value == null)
                {
                    this.facility = new byte[0];
                }
                else
                {
                    this.facility = value;
                }
            }
        }

        private byte[] issue;

        /// <summary>
        /// One byte of issue.
        /// </summary>
        public byte[] Issue
        {
            get
            {
                return this.issue;
            }
            set
            {
                if (value == null)
                {
                    this.issue = new byte[0];
                }
                else
                {
                    this.issue = value;
                }
            }
        }

        private byte[] code;

        /// <summary>
        /// Five bytes of code.
        /// </summary>
        public byte[] Code
        {
            get
            {
                return this.code;
            }
            set
            {
                if (value == null)
                {
                    this.code = new byte[0];
                }
                else
                {
                    this.code = value;
                }
            }
        }

        public static LegacyCardRecord Clone(LegacyCardRecord source)
        {
            return Clone(source.facility, source.issue, source.code);
        }

        public static LegacyCardRecord Clone(byte[] sourceFacility, byte[] sourceIssue, byte[] sourceCode)
        {
            byte[] facility = new byte[sourceFacility.Length];
            Array.Copy(sourceFacility, facility, facility.Length);
            byte[] issue = new byte[sourceIssue.Length];
            Array.Copy(sourceIssue, issue, issue.Length);
            byte[] code = new byte[sourceCode.Length];
            Array.Copy(sourceCode, code, code.Length);
            return new LegacyCardRecord(facility, issue, code);
        }

        public void CloneFrom(LegacyCardRecord source)
        {
            CloneFrom(source.facility, source.issue, source.code);
        }

        public void CloneFrom(byte[] sourceFacility, byte[] sourceIssue, byte[] sourceCode)
        {
            if (sourceCode.Length <= 5)
            {
                code = new byte[sourceCode.Length];
                Array.Copy(sourceCode, code, code.Length);
            }
            else
            {
                code = new byte[5];
                Array.Copy(sourceCode, code, 5);
            }

            if (sourceFacility.Length <= 2)
            {
                facility = new byte[sourceFacility.Length];
                Array.Copy(sourceFacility, facility, facility.Length);
            }
            else
            {
                facility = new byte[2];
                Array.Copy(sourceFacility, facility, 2);
            }

            if (sourceIssue.Length <= 1)
            {
                issue = new byte[sourceIssue.Length];
                Array.Copy(sourceIssue, issue, sourceIssue.Length);
            }
            else
            {
                issue = new byte[1];
                Array.Copy(sourceIssue, issue, 1);
            }
        }

        public long AsLong()
        {
            long cardNumber = 0;

            int facilityAsInt = (int)getLongFromData(facility);
            int issueAsInt = (int)getLongFromData(issue);
            long codeAsLong = getLongFromData(code);

            cardNumber = (long)(facilityAsInt & 0xFFFF) << 48;
            cardNumber |= (long)(issueAsInt & 0xFF) << 40;
            cardNumber |= (long)(codeAsLong & 0xFFFFFFFFFF);
            return cardNumber;
        }

        private static long getLongFromData(byte[] data)
        {
            if (data == null || data.Length == 0)
                return 0;

            long result = 0;
            for (int i = 0; i < data.Length; i++)
            {
                result = result << 8;
                result += data[i];
            }
            return result;
        }
    }
}
