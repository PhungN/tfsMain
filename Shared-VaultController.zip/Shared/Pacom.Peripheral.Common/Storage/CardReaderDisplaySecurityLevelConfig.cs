﻿using System;

namespace Pacom.Peripheral.Common
{
    public class CardReaderDisplaySecurityLevelConfig
    {
        public CardReaderDisplaySecurityLevelConfig()
        {
            Readers = 0;
            Flags = 0;
            DisplayDuration = new TimeSpan(0);
            DisplayText = "";
        }

        public byte Readers { get; set; }
        public byte Flags { get; set; }
        public AlertCommand AlertCommand { get; set; }
        public TimeSpan DisplayDuration { get; set; }
        public string DisplayText { get; set; }

        public override string ToString()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendFormat("Readers: 0b{0}, FLAGS: 0x{1:x2}, Command: {2}, Time: {3}s", Convert.ToString(Readers, 2).PadLeft(8, '0'), Flags, AlertCommand, DisplayDuration);
            if (string.IsNullOrEmpty(DisplayText) == false)
                sb.AppendFormat(", Text: {0}", DisplayText);
            return sb.ToString();
        }
    }
}
