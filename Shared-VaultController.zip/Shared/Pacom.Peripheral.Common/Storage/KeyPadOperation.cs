﻿using System;
using System.Threading;

namespace Pacom.Peripheral.Common
{

    /// <summary>
    /// Handles the key pad operation.
    /// </summary>
    public class KeypadOperation : IDisposable
    {
        private IPacomTimer keypadInactivityTimer = null;
        private int keypadNoDigitsToEnter = 4;
        private int keyInactivityTimeout = 1000;
        private bool keypadSendKeyWithPin = false;

        public KeypadOperation()
        {
            KeyData = null;
            KeyCount = 0;
        }
                
        public void Clear()
        {
            StopTimer();
            KeyData = null;
            KeyCount = 0;
        }

        public IPacomTimer KeypadInactivityTimer     
        {
            get
            {
                return keypadInactivityTimer;
            }
        }

        public byte[] KeyData { get; private set; }

        public int KeyCount { get; private set; }

        public int MaxKeys
        {
            get
            {
                return (KeyData != null && KeyData[0] == 0x0A) ? keypadNoDigitsToEnter + 2 : keypadNoDigitsToEnter; 
            }
        }

        public void SetConfig(bool keypadSendKeyWithPin, int keypadNoDigitsToEnter, int keyInactivityTimeout)
        {
            this.keypadSendKeyWithPin = keypadSendKeyWithPin;
            this.keypadNoDigitsToEnter = keypadNoDigitsToEnter;
            this.keyInactivityTimeout = keyInactivityTimeout;
        }

        public void StopTimer()
        {
            if (keypadInactivityTimer != null)
            {
                keypadInactivityTimer.Stop();
                TimerManager.Instance.RemoveTimer(keypadInactivityTimer);
                keypadInactivityTimer = null;
            }
        }

        public void StartTimer(int timeout)
        {
            if (keypadInactivityTimer != null)
                keypadInactivityTimer.RunOnce(timeout);
        }

        public bool AddKeyPress(byte key)
        {
            if (KeyData == null)
            {
                KeyData = new byte[keypadSendKeyWithPin ? keypadNoDigitsToEnter + 2 : keypadNoDigitsToEnter];
                KeyCount = 0;
                keypadInactivityTimer = TimerManager.Instance.CreateTimer(_ => { Clear(); });
            }
            if (KeyCount < KeyData.Length)
            {
                KeyData[KeyCount++] = key;
                return true;
            }
            return false;
        }

        public int AddKey(byte key)
        {
            if (key == 0x0A) // Clear/Star Key
            {
                if (KeyCount > 0)  // clear the buffer
                {
                    Clear();
                }
                else if (keypadSendKeyWithPin == true && (AddKeyPress(key) == true))
                {
                    StartTimer(keyInactivityTimeout);
                }
            }
            else if (AddKeyPress(key) == true)
            {
                StartTimer(keyInactivityTimeout);
            }
            return KeyCount;
        }

        #region IDisposable Members

        private bool disposed = false;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                StopTimer();
                disposed = true;
            }
        }

        ~KeypadOperation()
        {
            Dispose(false);
        }

        #endregion

    }
}
