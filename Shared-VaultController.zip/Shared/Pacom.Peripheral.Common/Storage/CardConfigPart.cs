﻿namespace Pacom.Peripheral.Common
{
    public class CardConfigPart
    {

        /// <summary>
        /// Set default values.
        /// </summary>
        public CardConfigPart()
        {
            this.UnitType = CardConfigFieldType.NotUsed;
            this.IncludeInMask = false;
            this.Length = 0;
            this.ZeroBasedOffset = 0;
        }

        /// <summary>
        /// Indicator of configured unit type.
        /// </summary>
        public CardConfigFieldType UnitType
        {
            get;
            set;
        }

        /// <summary>
        /// Length in bits.
        /// </summary>
        public byte Length
        {
            get;
            set;
        }

        private int zeroBasedOffset;
        /// <summary>
        /// Offset in bits.
        /// </summary>
        public int ZeroBasedOffset
        {
            set
            {
                zeroBasedOffset = value;
                if (zeroBasedOffset < 0)
                    zeroBasedOffset = 0;
            }
            get
            {
                return zeroBasedOffset;
            }
        }

        /// <summary>
        /// Include in degraded mode mask.
        /// </summary>
        public bool IncludeInMask
        {
            set;
            get;
        }

        /// <summary>
        /// Get/Set length and unit type byte
        /// </summary>
        public byte LengthAndUnitType
        {
            get
            {
                return (UnitType == CardConfigFieldType.InBits) ? (byte)((Length & 0x3F) | 0x40) : (byte)(Length & 0x3F);
            }
            set
            {
                byte inBits = (byte)(value >> 6);
                if (inBits == 0)
                {
                    UnitType = CardConfigFieldType.NotUsed;
                    Length = 0;
                }
                else
                {
                    UnitType = CardConfigFieldType.InBits;
                    Length = (byte)((value & 0x3F) << (inBits - 1));
                }
            }
        }

        /// <summary>
        /// Get/Set Zero base offset and mask byte
        /// </summary>
        public byte ZeroBaseOffsetAndMask
        {
            get
            {
                return IncludeInMask ? (byte)(((ZeroBasedOffset & 0x7F) + 1) | 0x80) : (byte)((ZeroBasedOffset & 0x7F) + 1);
            }
            set
            {
                ZeroBasedOffset = ((value & 0x7F) - 1);
                IncludeInMask = ((value & 0x80) == 0x80);
            }
        }
    }
}
