﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// One part out of several of the parity mask which is configured.
    /// </summary>
    public class CardParityConfigPart
    {
        public CardParityConfigPart()
        {
            this.Enabled = false;
            this.Offset = 0;
            this.OddParity = false;
            this.Mask = new byte[8];
            for (int i = 0; i < 8; i++)
            {
                this.Mask[i] = 0;
            }
        }

        /// <summary>
        /// True for parity enabled
        /// </summary>
        public bool Enabled
        {
            set;
            get;
        }

        /// <summary>
        /// True for odd parity, false for even
        /// </summary>
        public bool OddParity
        {
            set;
            get;
        }

        /// <summary>
        /// Parity mask.
        /// </summary>
        public byte[] Mask
        {
            set;
            get;
        }

        /// <summary>
        /// Parity bit offset.
        /// 0 - for none specified
        /// 1..64 - bit position 0..63
        /// </summary>
        public int Offset
        {
            set;
            get;
        }
    }
}
