﻿namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Timer callback delegate
    /// </summary>
    /// <param name="state">An object containing information to be used by the callback method, or null.</param>
    public delegate void PacomTimerCallback(object state);

    public interface IPacomTimer
    {
        /// <summary>
        /// Check if timer is enabled.
        /// </summary>
        bool Enabled { get; }

        /// <summary>
        /// Change timer due time and period.
        /// </summary>
        /// <param name="dueTime">New timer due time in milliseconds.</param>
        /// <param name="period">New timer period in milliseconds.</param>
        void Change(int dueTime, int period);

        /// <summary>
        /// Change timer due time, period and timer callback.
        /// </summary>
        /// <param name="dueTime">New timer due time in milliseconds.</param>
        /// <param name="period">New timer period in milliseconds.</param>
        /// <param name="callback">New timer callback</param>
        void Change(int dueTime, int period, PacomTimerCallback callback);

        /// <summary>
        /// Run timer callback once after due time expires then stop.
        /// </summary>
        /// <param name="dueTime">New timer due time in milliseconds.</param>
        void RunOnce(int dueTime);

        /// <summary>
        /// Stop timer.
        /// </summary>
        void Stop();
    }
}
