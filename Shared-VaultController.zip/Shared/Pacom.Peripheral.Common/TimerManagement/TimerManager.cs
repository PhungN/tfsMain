﻿using System;
using System.Threading;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.Common
{
    public class TimerManager : IDisposable
    {
        private static TimerManager instance = null;

#if DEBUG
        private static int timeDilationFactor = 1;
        public static int TimeDilationFactor { get { return timeDilationFactor; } set { timeDilationFactor = value; } }
#endif

        public static TimerManager CreateInstance()
        {
            if (instance == null)
                instance = new TimerManager();
#if DEBUG
            TimeDilationFactor = 1;
#endif
            return instance;
        }

        public static TimerManager Instance
        {
            get
            {
#if DEBUG
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.PacomTimer, () =>
                    {
                        return "Instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
#endif
                return instance;
            }
        }

        /// <summary>
        /// Create PacomTimer instance and return a IPacomTimer interface to caller.
        /// </summary>
        /// <param name="callback">Callback to be used when the timer fires.</param>
        /// <returns>IPacomTimer interface or null if the timer can't be created.</returns>
        public IPacomTimer CreateTimer(PacomTimerCallback callback)
        {
            return new PacomTimer(this, callback);
        }

        /// <summary>
        /// Create PacomTimer instance using a user supplied callback, an optional state, a due time and recurring period 
        /// and return a IPacomTimer interface to caller.
        /// </summary>
        /// <param name="callback">Callback to be used when the timer fires.</param>
        /// <param name="state">Optional user supplied state object.</param>
        /// <param name="dueTime">Timer due time, in milliseconds.</param>
        /// <param name="period">Timer period in milliseconds.</param>
        /// <returns>IPacomTimer interface or null if the timer can't be created.</returns>
        public IPacomTimer CreateTimer(PacomTimerCallback callback, object state, int dueTime, int period)
        {
            return new PacomTimer(this, callback, state, dueTime, period);
        }

        /// <summary>
        /// Delete timer instance
        /// </summary>
        /// <param name="timer">Timer instance to be deleted.</param>
        public void RemoveTimer(IPacomTimer timer)
        {
            remove((PacomTimer)timer);
        }

        /// <summary>
        /// Timers list lock
        /// </summary>
        private readonly object timerSync = new object();

        /// <summary>
        /// List of timers that are managed by this TimerManager instance
        /// </summary>
        private List<PacomTimer> timers = new List<PacomTimer>();

        /// <summary>
        /// Timer Manager time scheduling thread
        /// </summary>
        private Thread timerManagerThread = null;
        private bool terminateThread = false;

        /// <summary>
        /// Next timer interval - wake-up timer manager thread.
        /// </summary>
        private AutoResetEvent timerUpdateEvent = new AutoResetEvent(false);

        private TimerManager()
        {
        }

        public void Start()
        {
            if (timerManagerThread == null)
            {
                timerManagerThread = new Thread(new ThreadStart(timerManagerThreadMethod));
                timerManagerThread.Name = "Timer Manager Thread";
                timerManagerThread.IsBackground = true;
                timerManagerThread.Priority = ThreadPriority.Normal;
                timerManagerThread.Start();
            }
        }

        /// <summary>
        /// Add new timer to timer manager list from processing
        /// </summary>
        /// <param name="timer">PacomTimer instance to be added to timers list.</param>
        private void add(PacomTimer timer)
        {
            if (timer == null)
                return;

            lock (timerSync)
            {
                timers.Add(timer);
            }
            if (timer.FiringTime.HasValue)
                timerUpdateEvent.Set();
        }

        /// <summary>
        /// Remove timer from timer manager's list.
        /// </summary>
        /// <param name="timer">PacomTimer instance to be removed from timers list.</param>
        private void remove(PacomTimer timer)
        {
            if (timer == null)
                return;

            lock (timerSync)
            {
                if (timers.Remove(timer) == true)
                {
                    timer.Dispose();
                }
            }
        }

        /// <summary>
        /// Wake up timer manager thread if any of the timers has changed so the next firing interval 
        /// can be updated.
        /// </summary>
        private void wakeUp()
        {
            timerUpdateEvent.Set();
        }

        /// <summary>
        /// Timer manager thread procedure. The event blocks timer manager thread until signaled
        /// </summary>
        private void timerManagerThreadMethod()
        {
            while (terminateThread == false)
            {
                try
                {
                    int timeOut = fireTimers();

                    if (terminateThread == true)
                        break;
                    timerUpdateEvent.WaitOne(timeOut, false);
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.PacomTimer, () =>
                    {
                        return string.Format("Exception in [TimerManager] thread method: {0}", ex.ToString());
                    });
                }
            }
            
            if (ConfigurationManager.Instance != null) // Configuration manager can be disposed of before reaching this point
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.PacomTimer, DebugLoggingSubCategory.PacomTimers, () =>
                                                                                                            {
                                                                                                                return "[TimerManager] thread method has been terminated !";
                                                                                                            });
            }
        }

        /// <summary>
        /// Executed by the TimerManager thread. Sweeps through the list of timers, readjusting the firing times, and executing 
        /// the timer callbacks for the timers that have expired, then returns the next firing time interval.
        /// </summary>
        /// <returns>Next firing time interval.</returns>
        private int fireTimers()
        {
            if (terminateThread == true)
                return 0;

            uint? nextFiringTime = null;
            try
            {
                PacomTimer[] timersCache = null;
                lock (timerSync)
                {
                    if (timers.Count == 0)
                        return Timeout.Infinite;
                    timersCache = timers.ToArray();
                }

                try
                {
                    uint currentTime = (uint)Environment.TickCount;
                    foreach (var timer in timersCache)
                    {
                        if (terminateThread == true)
                            return 0;

                        if (timer == null)
                            continue;

                        uint? firingTime = timer.FiringTime;
                        if (firingTime.HasValue)
                        {
                            if ((currentTime - firingTime) < 0x80000000)
                                firingTime = timer.run(currentTime);

                            if (firingTime.HasValue && (nextFiringTime == null || (nextFiringTime.Value - firingTime) < 0x80000000))
                                nextFiringTime = firingTime;
                        }
                    }
                }
                catch (ObjectDisposedException ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.PacomTimer, () =>
                    {
                        return string.Format("Exception in [TimerManager.fireTimers] method: {0}", ex.Message);
                    });
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.PacomTimer, () =>
                {
                    return string.Format("Exception thrown in [TimerManager.fireTimers] method: {0}", ex.ToString());
                });
            }

            if (nextFiringTime == null)
            {
                return Timeout.Infinite;
            }
            else
            {
                uint sleepTime = nextFiringTime.Value - (uint)Environment.TickCount;
                if (sleepTime > 0x80000000)
                    return 0;
                else
                    return (int)sleepTime;
            }
        }

        #region IDisposable Members

        bool disposed = false;
        public void Dispose(bool disposing)
        {
            try
            {
                if (disposed == false)
                {
                    if (disposing)
                    {
                        terminateThread = true;
                        if (timerUpdateEvent != null)
                        {
                            timerUpdateEvent.Set();
                            if (timerManagerThread != null)
                            {
                                try
                                {
                                    timerManagerThread.JoinOrRestart(500);
                                }
                                catch
                                {
                                }
                            }
                            timerUpdateEvent.Close();
                            timerUpdateEvent = null;
                        }
                        timerManagerThread = null;
                        timers = null;
                        instance = null;
                    }
                    disposed = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.PacomTimer, () =>
                {
                    return ex.ToString();
                });
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

        /// <summary>
        /// Timer class that will execute a task when a specified time interval has expired. It can execute
        /// its callback once or periodically. The timer update and execution will be triggered from the
        /// TimerManager class.
        /// </summary>
        private class PacomTimer : IPacomTimer, IDisposable
        {
#if DEBUG
            private static int instanceCount = 0;
#endif

            /// <summary>
            /// Create a new PacomTimer instance using only the user supplied callback and default values for
            /// state, dueTime and period. The timer will be created in the stopped state. 
            /// </summary>
            /// <param name="callback">Timer callback that will be executed when the timer fires.</param>
            protected internal PacomTimer(TimerManager owner, PacomTimerCallback callback) :
                this(owner, callback, null, Timeout.Infinite, Timeout.Infinite)
            {
            }

            /// <summary>
            /// Create new Pacom timer instance.
            /// </summary>
            /// <param name="callback">Timer callback that will be executed when the timer fires.</param>
            /// <param name="state">State object that will be passed to the timer callback.</param>
            /// <param name="dueTime">Timer due time, in milliseconds. Must be > 0 or -1 if the timer is disabled.</param>
            /// <param name="period">Timer period, in milliseconds. Must be > 0 or -1 if the timer will run at most once.</param>
            protected internal PacomTimer(TimerManager owner, PacomTimerCallback callback, object state, int dueTime, int period)
            {
                this.owner = owner;
                timerCallback = callback;
                this.state = state;

                if (dueTime < Timeout.Infinite)
                    throw new ArgumentOutOfRangeException("dueTime", "Invalid timer due time !");
                if (period < Timeout.Infinite)
                    throw new ArgumentOutOfRangeException("period", "Invalid timer period !");

                this.dueTime = dueTime;
                this.period = period;
#if DEBUG
                if (TimerManager.TimeDilationFactor != 1 && this.dueTime != Timeout.Infinite)
                    this.dueTime = dueTime / TimerManager.TimeDilationFactor;
                if (TimerManager.TimeDilationFactor != 1 && this.period != Timeout.Infinite)
                    this.period = period / TimerManager.TimeDilationFactor;
#endif

                if (this.dueTime != Timeout.Infinite)
                    firingTime = (uint)Environment.TickCount + (uint)this.dueTime;
                owner.add(this);
#if DEBUG
                instanceCount++;
                Logger.LogDebugMessage(LoggerClassPrefixes.PacomTimer, DebugLoggingSubCategory.PacomTimers, () =>
                {
                    return string.Format("[Constructor] Timer instance count is {0}", instanceCount);
                });
#endif
            }

            /// <summary>
            /// Check if the timer instance has already been disposed.
            /// </summary>
            /// <returns>True if the timer instance has already been disposed, False otherwise.</returns>
            private bool checkDisposed()
            {
                if (disposed)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.PacomTimer, DebugLoggingSubCategory.PacomTimers, () =>
                    {
                        return "Timer instance has already been [Destroyed] !";
                    });
                    return true;
                }
                return false;
            }

            private TimerManager owner = null;

            /// <summary>
            /// Next timer due time - if Infinite the timer will not execute at all.
            /// </summary>
            private int dueTime = Timeout.Infinite;

            /// <summary>
            /// Timer period - if Infinite the timer will not execute periodically.
            /// </summary>
            private int period = Timeout.Infinite;

            /// <summary>
            /// Timer callback that will be executed every time the timer due time expires
            /// </summary>
            private PacomTimerCallback timerCallback = null;

            /// <summary>
            /// An object containing information to be used by the timer callback method or null. 
            /// </summary>
            private object state = null;

            /// <summary>
            /// Timer synchronization lock.
            /// </summary>
            private readonly object syncObject = new object();

            /// <summary>
            /// Timer period in ticks
            /// </summary>
            protected internal int Period
            {
                get
                {
                    if (checkDisposed() == true)
                        return Timeout.Infinite;
                    return period;
                }
            }

            /// <summary>
            /// Timer firing absolute time in ticks
            /// </summary>
            private uint? firingTime = null;
            protected internal uint? FiringTime
            {
                get
                {
                    lock (syncObject)
                    {
                        if (checkDisposed() == true)
                            return null;
                        return firingTime;
                    }
                }
            }

            protected internal bool Recurring
            {
                get
                {
                    if (checkDisposed() == true)
                        return false;
                    return period != Timeout.Infinite;
                }
            }

            /// <summary>
            /// Check if timer is enabled
            /// </summary>
            public bool Enabled
            {
                get
                {
                    lock (syncObject)
                    {
                        if (checkDisposed() == true)
                            return false;

                        return firingTime != null;
                    }
                }
            }

            /// <summary>
            /// Change the timer start time and interval between callback invocations. 
            /// </summary>
            /// <param name="dueTime">Timer due time in milliseconds.</param>
            /// <param name="period">Timer period in milliseconds.</param>
            public void Change(int dueTime, int period)
            {
                lock (syncObject)
                {
                    if (checkDisposed() == true)
                        return;

                    this.dueTime = dueTime;
                    this.period = period;
#if DEBUG
                    if (TimerManager.TimeDilationFactor != 1 && this.dueTime != Timeout.Infinite)
                        this.dueTime = dueTime / TimerManager.TimeDilationFactor;
                    if (TimerManager.TimeDilationFactor != 1 && this.period != Timeout.Infinite)
                        this.period = period / TimerManager.TimeDilationFactor;
#endif

                    if (this.dueTime != Timeout.Infinite)
                        firingTime = (uint)Environment.TickCount + (uint)this.dueTime;
                    else
                        firingTime = null;

                    if (firingTime.HasValue)
                        owner.wakeUp();
                }
            }

            /// <summary>
            /// Change timer due time, period and timer callback.
            /// </summary>
            /// <param name="dueTime">New timer due time in milliseconds.</param>
            /// <param name="period">New timer period in milliseconds.</param>
            /// <param name="callback">New timer callback</param>
            public void Change(int dueTime, int period, PacomTimerCallback callback)
            {
                lock (syncObject)
                {
                    if (checkDisposed() == true)
                        return;

                    this.dueTime = dueTime;
                    this.period = period;
                    this.timerCallback = callback;
#if DEBUG
                    if (TimerManager.TimeDilationFactor != 1 && this.dueTime != Timeout.Infinite)
                        this.dueTime = dueTime / TimerManager.TimeDilationFactor;
                    if (TimerManager.TimeDilationFactor != 1 && this.period != Timeout.Infinite)
                        this.period = period / TimerManager.TimeDilationFactor;
#endif

                    if (this.dueTime != Timeout.Infinite)
                        firingTime = (uint)Environment.TickCount + (uint)this.dueTime;
                    else
                        firingTime = null;

                    if (firingTime.HasValue)
                        owner.wakeUp();
                }
            }

            /// <summary>
            /// Run once after dueTime has expired, then sleep.
            /// </summary>
            /// <param name="dueTime">Next time the timer will run</param>
            public void RunOnce(int dueTime)
            {
                Change(dueTime, Timeout.Infinite);
            }

            /// <summary>
            /// Stop timer indefinitely.
            /// </summary>
            public void Stop()
            {
                Change(Timeout.Infinite, Timeout.Infinite);
            }

            /// <summary>
            /// Run timer callback if the timer has expired, and update next firing time
            /// </summary>
            /// <param name="currentTime">The current Environment.TickCount.</param>
            protected internal uint? run(uint currentTime)
            {
                try
                {
                    lock (syncObject)
                    {
                        if (checkDisposed() == true)
                            return null;

                        dueTime = period;
                        if (this.dueTime != Timeout.Infinite)
                        {
                            firingTime += (uint)this.dueTime;
                            if ((currentTime - firingTime) < 0x80000000)
                                firingTime = currentTime;
                        }
                        else
                        {
                            firingTime = null;
                        }
                    }

                    if (timerCallback != null)
                        timerCallback(state);

                    if (checkDisposed() == true)
                        return null;
                    return firingTime;
                }
                catch (NullReferenceException ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.PacomTimer, () =>
                    {
                        return string.Format("NullReferenceException in [PacomTimer.run] method: {0}", ex.ToString());
                    });
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.PacomTimer, () =>
                    {
                        return string.Format("Unknown Exception in [PacomTimer.run] method: {0}", ex.ToString());
                    });
                }
                return null;
            }

            #region IDisposable Members

            bool disposed = false;
            public void Dispose(bool disposing)
            {
                if (disposed == false)
                {
                    if (disposing)
                    {
                        lock (syncObject)
                        {
                            timerCallback = null;
                            firingTime = null;
                            dueTime = Timeout.Infinite;
                            period = Timeout.Infinite;
#if DEBUG
                            instanceCount--;
                            Logger.LogDebugMessage(LoggerClassPrefixes.PacomTimer, DebugLoggingSubCategory.PacomTimers, () =>
                            {
                                return string.Format("[Destructor] Timer instance count is {0}", instanceCount);
                            });
#endif
                        }
                    }
                    disposed = true;
                }
            }

            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }

            #endregion
        }
    }
}
