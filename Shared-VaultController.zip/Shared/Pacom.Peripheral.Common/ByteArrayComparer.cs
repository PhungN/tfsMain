﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common
{
    public class ByteArrayComparer : IEqualityComparer<byte[]>
    {
        public bool Equals(byte[] x, byte[] y)
        {
            if (x == null || y == null)
            {
                return x == y;
            }
            return x.SequenceEqual(y);
        }
        public int GetHashCode(byte[] obj)
        {
            if (obj == null)
                throw new ArgumentNullException("obj");
            int sum = 0;
            for (int i = 0; i < obj.Length; i++)
                sum += obj[i];
            return sum;
        }
    }
}
