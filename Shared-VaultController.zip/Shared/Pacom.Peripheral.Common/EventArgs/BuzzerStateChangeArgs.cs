﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class represents argument for event triggering a buzzer
    /// </summary>
    public class BuzzerStateChangeArgs : EventArgs
    {
        private readonly CardReaderBuzzerType buzzerState;

        public BuzzerStateChangeArgs(CardReaderBuzzerType state)
        {
            this.buzzerState = state;
        }

        public CardReaderBuzzerType BuzzerState
        {
            get
            {
                return buzzerState;
            }
        }
    }
}
