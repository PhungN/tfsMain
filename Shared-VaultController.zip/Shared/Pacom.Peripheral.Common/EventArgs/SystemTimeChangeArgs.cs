﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class represents argument for system time event triggering
    /// </summary>
    public class SystemTimeChangeArgs : EventArgs
    {

        private double difference = 0;

        public SystemTimeChangeArgs(double difference)
        {
            this.difference = difference;
        }

        /// <summary>
        /// Diffrence in seconds between previous time and time send by controller.
        /// </summary>
        public double Difference
        {
            get
            {
                return difference;
            }
        }
    }
}
