﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class represents argument for output event triggering
    /// </summary>
    public class OutputStateChangeArgs : EventArgs
    {
        private readonly bool state;

        public OutputStateChangeArgs(bool state)
        {
            this.state = state;
        }

        public bool OutputState
        {
            get
            {
                return state;
            }
        }
    }
}
