﻿using System;

namespace Pacom.Peripheral.Common
{
    public class InputChangedStatusEventArgs : EventArgs
    {
        public InputChangedStatusEventArgs(Status.InputStatus status, OwnerType owner, int pointNumberOnParent)
        {
            Owner = owner;
            PointNumberOnParent = pointNumberOnParent;
            Status = status;
        }

        public int PointNumberOnParent
        {
            get;
            private set;
        }

        public OwnerType Owner
        {
            get;
            private set;
        }

        public Status.InputStatus Status
        {
            get;
            private set;
        }                       
    }
}
