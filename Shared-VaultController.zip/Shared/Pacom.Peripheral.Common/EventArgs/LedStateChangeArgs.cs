﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class represents argument for event triggering a led
    /// </summary>
    public class LedStateChangeArgs : EventArgs
    {
        private readonly CardReaderLedType ledState;

        public LedStateChangeArgs(CardReaderLedType state)
        {
            this.ledState = state;
        }

        public CardReaderLedType LedState
        {
            get
            {
                return ledState;
            }
        }
    }
}
