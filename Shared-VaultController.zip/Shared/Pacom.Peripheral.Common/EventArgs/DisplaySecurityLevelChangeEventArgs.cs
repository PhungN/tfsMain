﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class represents argument for event triggering an OSDP Display Security Level
    /// </summary>
    public class DisplaySecurityLevelChangeEventArgs : EventArgs
    {
        public int ReaderId { get; private set; }
        public CardReaderDisplaySecurityLevelConfig Config { get; private set; }
        public DisplaySecurityLevelChangeEventArgs(int readerId, CardReaderDisplaySecurityLevelConfig config)
        {
            ReaderId = readerId;
            Config = config;
        }
    }
}
