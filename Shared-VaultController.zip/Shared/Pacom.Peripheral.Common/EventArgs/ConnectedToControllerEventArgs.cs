﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class represents argument for event triggered by communication mnager connection changes.
    /// </summary>
    public class ConnectedToControllerEventArgs : EventArgs
    {
        public ConnectedToControllerEventArgs(bool connected)
        {
            Connected = connected;
        }

        public bool Connected
        {
            get;
            private set;
        }
    }
}
