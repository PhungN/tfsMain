﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Event argument used to communicate between status manager and doors / readers.
    /// </summary>
    public class AccessControlCommandRequestEventArgs : EventArgs
    {
        private Dictionary<AccessCommandType, AccessCommandConfigBase> requestedCommands = null;

        private int logicalReaderId;

        public AccessControlCommandRequestEventArgs(int logicalReaderId)
        {
            this.logicalReaderId = logicalReaderId;
            requestedCommands = new Dictionary<AccessCommandType, AccessCommandConfigBase>();
        }

        /// <summary>
        /// Gets logical reader Id.
        /// </summary>
        public int LogicalReaderId
        {
            get
            {
                return this.logicalReaderId;
            }
        }

        /// <summary>
        /// Accessor for adding or removing commands.
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public AccessCommandConfigBase this[AccessCommandType index]
        {
            get
            {
                return requestedCommands[index];
            }
            set
            {
                requestedCommands[index] = value;
            }
        }

        /// <summary>
        /// Returns True when specified command is included on the list for processing.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public bool IsIncluded(AccessCommandType value)
        {
            return requestedCommands.ContainsKey(value);
        }

        /// <summary>
        /// Number of commands available for processing.
        /// </summary>
        public int Count
        {
            get
            {
                return requestedCommands.Count;
            }
        }
    }
}
