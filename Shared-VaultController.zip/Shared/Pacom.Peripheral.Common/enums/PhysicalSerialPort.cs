﻿
namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Serial port number
    /// </summary>
    public enum PhysicalSerialPort : int
    {
        None = 0,
        OnboardRS485Port = 1,       // Com1
        ExpansionCard1 = 2,         // Com2
        ExpansionCard2 = 3,         // Com3
        OnboardRS232Port = 4,       // Com4
        CellularMonitoring1Port = 7, // Com7 - MUX monitoring AT command virtual port 
        CellularMonitoring2Port = 8, // Com8 - MUX monitoring AT command virtual port
    }
}
