﻿
namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Serial port standard
    /// </summary>
    public enum PhysicalSerialType : int
    {
        RS232,
        RS485
    }
}
