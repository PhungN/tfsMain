﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This enumerator is used for expansion card configuration. The expansion port type.
    /// </summary>
    public enum ExpansionCardConfigurationPortType : byte
    {
        None = 0,
        Dialup = 1,
        Gprs = 2,
        IP = 3,
        RS485DeviceLoop = 4,
        RS485OsdpDeviceLoop = 5
    }
}
