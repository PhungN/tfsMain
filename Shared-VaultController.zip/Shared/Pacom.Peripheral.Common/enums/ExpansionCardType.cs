﻿namespace Pacom.Peripheral.Common
{
    public enum ExpansionCardType
    {
        None = 0,
        Pacom8201GprsCard,
        Pacom8203OutputCard,
        Pacom8204InputCard,
        Pacom8205SerialCard,
        Pacom8207StarCouplerCard,
        Pacom8208SartInputOutputCard,
        Pacom8209PstnCard,
    }
}
