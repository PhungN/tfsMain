﻿
namespace Pacom.Peripheral.Common
{
    public enum CardReaderOutputType
    {
        Off = 0,
        On = 1,
        TimeDriven = 2
    }
}
