﻿
namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Definition of possible PCB types
    /// </summary>
    public enum PcbType
    {
        None,
        Pacom8003,
        Pacom8603,
        Pacom8501,
    }
}
