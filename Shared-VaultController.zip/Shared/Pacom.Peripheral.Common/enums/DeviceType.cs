﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// The one byte Device Type described in the 485 device loop specification.
    /// </summary>
    public enum DeviceType
    {
        PacomController = 0,    // Pacom Controller
        Pacom8003Controller = 1,// Pacom 8003 Controller
        Pacom8303 = 31,         // 8303 Power Supply
        Pacom8308 = 51,         // 8308 Power Supply and Battery Charger
        Pacom8501 = 38,         // 8501 16 Input 5 Output Door Controller (DC) and IO Device
        Pacom8501EC = 17,       // 8501 Elevator Controller
        Pacom8101 = 12,         // 8101 Keypad
        Pacom8105 = 33,         // 8105 Keypad
        Pacom1061 = 9,          // 1061 Main Keypad
        // Card Reader / IO Devices
        Pacom1064DC = 14,       // 1064 Door Controller Device
        Pacom1064IO = 15,       // 1064 IO Device
        Pacom1068 = 21,         // 1068 2-input / 1-output IO Device
        Pacom1076DC = 18,       // 1076 Door Controller Device 
        Pacom1076IO = 30,       // 1076 IO Device
        Pacom1076VC = 32,       // 1076 Vault Controller
        Pacom8603 = 46,         // 8603 Quad card reader interface device
        Pacom8502 = 50,         // 8502 IO Device (1068 IO replacement device)
        Pacom1065IO = 11,       // 1065 IO Device

#if COMMUNICATIONSANALYZER
        NotConfigured = Int32.MaxValue // No selection for a device in communication analyzer software
#endif
    }
}
