﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// </summary>
    [Flags]
    public enum DeviceFlags
    {
        None = 0,
        BeepReaderWhenCardPresent = 1 << 0, // Beep OSDP Reader when card present
    }
}
