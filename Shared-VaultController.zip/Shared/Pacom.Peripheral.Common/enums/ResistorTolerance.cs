﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum ResistorTolerance
    {
        TwelveAndAHalfPercent = 0,
        TwentyFivePercent,
    }
}
