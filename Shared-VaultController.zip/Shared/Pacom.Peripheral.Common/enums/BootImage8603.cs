﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum BootImage8603
    {
        /// <summary>8603 Image A</summary>
        ImageA,
        /// <summary>8603 Image B</summary>
        ImageB
    }
}
