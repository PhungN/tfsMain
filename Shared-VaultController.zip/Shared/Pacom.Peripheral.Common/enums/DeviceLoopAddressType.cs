﻿namespace Pacom.Peripheral.Common
{
    // Type of device address
    public enum DeviceLoopAddressType
    {
        Serial,
        IP,
    }
}
