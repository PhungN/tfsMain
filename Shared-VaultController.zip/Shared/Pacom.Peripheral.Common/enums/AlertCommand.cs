﻿namespace Pacom.Peripheral.Common
{
    public enum AlertCommand : byte
    {
        Text = 0,       // Some text to display else just clear previous alert
        Unlocked,       // Door is unlocked
        Locked,         // Door is locked
        Ajar,           // Door has been left  ajar
        Forced,         // Door has been forced open
        Denied,         // Access denied reason given with text
        Card,           // Waiting for a card to be presented
        PIN,            // Waiting for a PIN to be entered
        Reject,         // This would have text like “Point active”, “device tamper” or “communication fault”
        Accept,         // This would have text like “Area Armed” or “Disarmed”
    }

    [System.Flags]
    public enum AlertCommandFlags : byte
    {
        DisplayInformativeText = 0x01,  // Informative text that can be used to display additional information for the specified security level (a small font text display below the default big font text).
    }
}
