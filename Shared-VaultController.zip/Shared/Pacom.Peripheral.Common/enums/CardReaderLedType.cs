﻿using System;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum CardReaderLedType : byte
    {
        LedOff = 0,
        LedOn = 1,
        LedFlashing = 2
    }
}
