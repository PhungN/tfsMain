﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum ExpansionCardStatus
    {
        Online = 0,
        Offline = 0x01,
        FuseFail = 0x02,
        Unknown = 0xFF
    }
}
