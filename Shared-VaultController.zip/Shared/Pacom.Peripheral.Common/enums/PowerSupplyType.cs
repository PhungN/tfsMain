﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum PowerSupplyType
    {
        None = 0,
        Pacom8303 = 1,
        Pacom8305 = 2, 
        Pacom8309 = 3
    }
}
