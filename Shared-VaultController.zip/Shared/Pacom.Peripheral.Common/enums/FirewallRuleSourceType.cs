﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum FirewallRuleSourceType
    {
        WebServer = 1,
        DeviceLoop = 2,
    }
}
