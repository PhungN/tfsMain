﻿using System;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum CardReaderBuzzerType
    {
        BuzzerOff = 0,
        BuzzerOn = 1,
        BuzzerPulse = 2
    }
}
