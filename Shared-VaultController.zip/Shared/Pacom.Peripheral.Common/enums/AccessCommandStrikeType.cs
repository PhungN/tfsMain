﻿
namespace Pacom.Peripheral.Common
{
    public enum AccessCommandStrikeType
    {
        On,
        Off
    }
}
