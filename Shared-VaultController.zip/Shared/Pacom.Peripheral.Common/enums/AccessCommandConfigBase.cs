﻿#if CONTROLLER
using Pacom.Peripheral.Common.AccessControl;
#endif

namespace Pacom.Peripheral.Common
{
    public abstract class AccessCommandConfigBase
    {
    }

    public class AccessCommandBuzzerConfig : AccessCommandConfigBase
    {
        public AccessCommandBuzzerConfig(CardReaderBuzzerType buzzerType)
        {
            this.BuzzerType = buzzerType;
        }

        public CardReaderBuzzerType BuzzerType
        {
            get;
            private set;
        }
    }

    public class AccessCommandAcceptLedConfig : AccessCommandConfigBase
    {
        public AccessCommandAcceptLedConfig(CardReaderLedType acceptLedType)
        {
            this.AcceptLedType = acceptLedType;
        }

        public CardReaderLedType AcceptLedType
        {
            get;
            private set;
        }
    }

    public class AccessCommandDeniedLedConfig : AccessCommandConfigBase
    {
        public AccessCommandDeniedLedConfig(CardReaderLedType deniedLedType)
        {
            this.DeniedLedType = deniedLedType;
        }

        public CardReaderLedType DeniedLedType
        {
            get;
            private set;
        }
    }

#if CONTROLLER
    public class AccessCommandStoreCardInDegrededMemoryConfig : AccessCommandConfigBase
    {
        public AccessCommandStoreCardInDegrededMemoryConfig(CardNumberHolder cardNumber)
        {            
        }

        public CardNumberHolder CardNumber
        {
            get;
            private set;
        }
    }

    public class AccessCommandStrikeConfig : AccessCommandConfigBase
    {
        public AccessCommandStrikeConfig(AccessCommandStrikeType strikeType)
        {
            this.StrikeType = strikeType;
        }

        public AccessCommandStrikeType StrikeType
        {
            get;
            private set;
        }
    }
#endif
}
