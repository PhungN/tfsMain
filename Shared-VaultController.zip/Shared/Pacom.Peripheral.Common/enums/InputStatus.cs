﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum InputStatus
    {
        Unknown = -1,
        Secure = 0,
        Alarm = 1,
        Short = 2,
        Open = 3,
        Trouble = 4,
        Analog = 5,
        UnqualifiedAlarm = 6,
        Masking = 7,
        RangeReduction = 8,
        MaskingAndRangeReduction = 9,
        AlarmAndMasking = 10,
        AlarmAndRangeReduction = 11,
        AlarmAndMaskingAndRangeReduction = 12,
        /// <summary>Self Test Fail / EN-GRADE4 SelfTestFail Condition</summary>
        SelfTestFail = 13,
        UnqualifiedTroubleAlarm = 14,
        UnqualifiedOpenCircuit = 15,
        UnqualifiedShortCircuit = 16,
        UnqualifiedMasking = 17,
        UnqualifiedRangeReduction = 18,
        UnqualifiedMaskingAndRangeReduction = 19,
        UnqualifiedAlarmAndMasking = 20,
        UnqualifiedAlarmAndRangeReduction = 21,
        UnqualifiedAlarmAndMaskingAndRangeReduction = 22,
        
    }
}
