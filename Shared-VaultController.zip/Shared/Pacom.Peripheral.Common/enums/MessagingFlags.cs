﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Enumerator describing the way controller-device will talk between each other.
    /// Use this enumerator if enchantment to message exchange is required with regards to the legacy messaging set.
    /// </summary>
    [Flags]
    public enum MessagingFlags
    {
        None = 0, // Use controller legacy messaging
        RestoreDefaultsAndSwitchAllReportingToExtendedFormat = 1 << 1,
        SwitchInputStatusReportingToExtendedFormat = 1 << 2,
        EnableSupportForLargeCardNumbers = 1 << 3                       // When set, card numbers with > 64 bit length can be stored in degraded memory
                                                                        // This is disabled by default due to the 8002 not being able to send a delete command 
                                                                        // with sufficient detail of > 64 bit cards. (64 bits only with no length)
    }
}
