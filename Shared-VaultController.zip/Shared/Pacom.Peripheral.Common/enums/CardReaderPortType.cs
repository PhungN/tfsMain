﻿
namespace Pacom.Peripheral.Common
{
    public enum CardReaderPortType : byte
    {
        CardReader1 = 0,
        CardReader2 = 1,
        CardReader3 = 2,
        CardReader4 = 3,
        NoReader = 255
    }
}
