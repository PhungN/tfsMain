﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum OutputState
    {
        Active = 1,
        Inactive = 2,
    }
}
