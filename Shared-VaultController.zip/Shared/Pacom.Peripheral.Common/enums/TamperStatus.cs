﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum TamperStatus
    {
        Secure = 0x00,
        Active = 0x01,
        Unknown = 0xFF,
    }
}
