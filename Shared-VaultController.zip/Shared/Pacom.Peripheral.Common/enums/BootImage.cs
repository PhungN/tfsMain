﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum BootImage
    {
        /// <summary>8501 Rescue Image</summary>
        RescueImage,
        /// <summary>8501 Image A</summary>
        ImageA,
        /// <summary>8501 Image B</summary>
        ImageB,
        /// <summary>8003 Image 1</summary>
        Image1,
        /// <summary>8003 Image 2</summary>
        Image2
    }
}
