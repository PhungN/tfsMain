﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Defines the types of resistance values that will be sent to a 8501 device in a SetResistanceValuesCOmmand message
    /// </summary>
    public enum ResistanceValueType
    {
        Secure = 0,
        Alarm,
        Masking,
        RangeReduction,
    }
}
