﻿
namespace Pacom.Peripheral.Common
{
    public enum CardConfigFieldType : int
    {
        NotUsed = 0,
        InBits = 1
    }
}
