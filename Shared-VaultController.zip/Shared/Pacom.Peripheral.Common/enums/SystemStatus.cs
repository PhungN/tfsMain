﻿using System;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum SystemStatus
    {
        OnlineToController = 0,             // Solid green on the status LED
        FirmwareUpdateInProgress = 0x1,     // Blinking green on the status LED
        Booting = 0x2,                      // Solid orange on the status LED
        OfflineToController = 0x04,         // Blinking orange on the status LED
        HardwareError = 0x08,               // Solid red on the status LED
        Terminating = 0x10,                 // All LEDs off.
    }
}
