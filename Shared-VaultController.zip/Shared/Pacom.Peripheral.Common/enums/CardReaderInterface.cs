﻿using System;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum CardReaderInterface
    {
        Wiegand = 1,
        Osdp = 2,
    }
}
