﻿using System;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum GpioPin : uint
    {
        Pin0 =  0x00000001,
        Pin1 =  0x00000002,
        Pin2 =  0x00000004,
        Pin3 =  0x00000008,
        Pin4 =  0x00000010,
        Pin5 =  0x00000020,
        Pin6 =  0x00000040,
        Pin7 =  0x00000080,
        Pin8 =  0x00000100,
        Pin9 =  0x00000200,
        Pin10 = 0x00000400,
        Pin11 = 0x00000800,
        Pin12 = 0x00001000,
        Pin13 = 0x00002000,
        Pin14 = 0x00004000,
        Pin15 = 0x00008000,
        Pin16 = 0x00010000,
        Pin17 = 0x00020000,
        Pin18 = 0x00040000,
        Pin19 = 0x00080000,
        Pin20 = 0x00100000,
        Pin21 = 0x00200000,
        Pin22 = 0x00400000,
        Pin23 = 0x00800000,
        Pin24 = 0x01000000,
        Pin25 = 0x02000000,
        Pin26 = 0x04000000,
        Pin27 = 0x08000000,
        Pin28 = 0x10000000,
        Pin29 = 0x20000000,
        Pin30 = 0x40000000,
        Pin31 = 0x80000000,
    }
}
