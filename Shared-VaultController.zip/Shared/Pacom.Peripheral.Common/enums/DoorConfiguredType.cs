﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Enumerator describing the state of door configuration.
    /// </summary>
    [Flags]
    public enum DoorConfiguredType
    {
        DoorNotConfigured = 0x00,
        EntryReaderConfigured = 0x01,
        ExitReaderConfigured = 0x02,
        DoorConfigured = 0x03
    }

    public static class DoorConfiguredTypeExtensions
    {
        public static bool Has(this DoorConfiguredType type, DoorConfiguredType value)
        {
            if ((type & value) == value)
                return true;
            return false;
        }

        public static DoorConfiguredType SetFlags(this DoorConfiguredType type, DoorConfiguredType flags)
        {
            return type | flags;
        }

        public static bool HasNone(this DoorConfiguredType type)
        {
            return type == DoorConfiguredType.DoorNotConfigured;
        }
    }
}
