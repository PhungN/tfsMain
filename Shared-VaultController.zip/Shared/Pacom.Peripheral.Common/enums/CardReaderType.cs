﻿
namespace Pacom.Peripheral.Common
{
    public enum CardReaderType : byte
    {
        NoReader = 0,
        Wiegand26Bits = 4,
        Wiegand26BitsKeypad = 12,
        WiegandKeypad = 21,
        WiegandMultiFormat = 36,
        Generic255BitRawData = 38
    }
}
