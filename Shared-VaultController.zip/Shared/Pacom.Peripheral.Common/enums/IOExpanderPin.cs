﻿using System;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum IOExpanderPin
    {
        Pin0 = 1,
        Pin1 = 2,
        Pin2 = 4,
        Pin3 = 8,
        Pin4 = 16,
        Pin5 = 32,
        Pin6 = 64,
        Pin7 = 128,
    }
}
