﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum ProcessorResetType
    {
        Unknown = -1,
        GeneralReset = 0,       // Occurs after a power cycle or 555 timer based reset
        WakeUpReset = 1,
        WatchdogReset = 2,
        SoftwareReset = 3,
        UserReset = 4,          // Occurs after the external watchdog timer triggers
    }
}
