﻿
namespace Pacom.Peripheral.Common
{
    public enum AccessCommandType
    {
        Buzzer,
        AcceptLed,
        DeniedLed,
        StoreCardForDegradedMode,
        Strike
    }
}
