﻿using System;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum ReaderOnlineTamperStatus
    {
        Normal = 0,           // Reader is online and tamper is reset
        Offline = 0x01,       // Reader is offline
        Tamper = 0x02,        // Reader is in tamper state
    }

    public static class ReaderOnlineTamperStatusExtansions
    {
        public static bool Has(this ReaderOnlineTamperStatus type, ReaderOnlineTamperStatus value)
        {
            if ((type & value) == value)
                return true;
            return false;
        }

        public static bool DoesNotHave(this ReaderOnlineTamperStatus type, ReaderOnlineTamperStatus value)
        {
            if ((type & value) != value)
                return true;
            return false;
        }

        public static ReaderOnlineTamperStatus SetFlags(this ReaderOnlineTamperStatus type, ReaderOnlineTamperStatus flags)
        {
            return type | flags;
        }
    }
}
