﻿namespace Pacom.Peripheral.Common
{
    public enum SecurityLevelDisplayCommand
    {
        None = 0,
        Offline = 0x40,             // 0        No contact with Door Controller.
        DoorUnlocked = 0x41,        // 0        Door is unlocked.
        DoorLocked = 0x42,          // 0        Door is locked.
        WaitCard = 0x43,            // 0        Reader is waiting for card.
        WaitDoorCode = 0x44,        // 0,4-8    Reader is waiting for door code. Data determines the number of door code digits to expect, where a value of 0 means send each digit.
        WaitPinCode = 0x45,         // 0,4-8    Reader is waiting for PIN code. Data determines the number of PIN digits to expect, where a value of 0 means send each digit.
        RejectRequest = 0x46,       // 0        The requested operation was rejected.
        AcceptRequest = 0x47,       // 0        The requested operation was accepted.
        DoorOpen = 0x48,            // 0        Door is open.
        DoorLocking = 0x49,         // 0        Door is locking.
        DoorAjar = 0x4A,            // 0        Door is ajar.
        DoorForced = 0x4B,          // 0        Door is forced.
        AlarmIntrusion = 0x4C,      // 0        Intrusion alarm is present.
        AreaArming = 0x4F,          // 0        Area is arming.
        AreaDisarming = 0x50,       // 0        Area is disarming.
        AreaArmed = 0x51,           // 0        Area is armed.
        AreaDisarmed = 0x52,        // 0        Area is disarmed.
        AreaArm = 0x53,             // 0        Reader is asking for user confirmation to arm the area.
        AreaDisarm = 0x54,          // 0        Reader is asking for user confirmation to disarm the area.
        AreaArmFail = 0x55,         // 0        Area failed to arm.
        AreaPartialArmed = 0x56,    // 0        Area is partially armed.
        AckAlarms = 0x57,           // 0        Reader is asking for user confirmation to acknowledge alarms.
        AlarmAck = 0x58,            // 0        Alarms were acknowledged.
        RestoreAlarms = 0x59,       // 0        Reader is asking for user confirmation to restore alarms.
        AlarmsRestored = 0x5A,      // 0        Alarms were restored.
        AlarmRestoreFail = 0x5B,    // 0        Failed to restore alarms.
        ReadyToArm = 0x5C,          // 0        Area is ready to be armed.
        NotReadyToArm = 0x5D,       // 0        Area is not ready to be armed.
        Tamper = 0x5E,              // 0        Tamper condition is present.
        Fault = 0x5F,               // 0        Fault condition is present.
        Aborted = 0x60,             // 0        Current operation was aborted.
        Cancelled = 0x61,           // 0        Current operation was cancelled.
        Confirm = 0x62,             // 0        Reader is asking for user confirmation
        ExtendTime = 0x63,          // 0        Reader is asking for user confirmation to extend the time before the alarm area is automatically armed.
        TimeExtended = 0x64,        // 0        The area arming time has been extended.
        WaitNextCard = 0x65,        // 0        Reader is waiting for next card to be swiped if multiple cards are required for entry.
        WaitBookingCode = 0x66,     // 0-18     Reader is waiting for a booking number to be entered. Data determines the number of digits to expect. The entered booking number will be sent as a card number.
        Occupied = 0x67,            // 0        The room is occupied.
        Vacant = 0x68,              // 0        The room is vacant.
        AboutToExpire = 0x69,       // 0        The card is about to expire.
    }
}
