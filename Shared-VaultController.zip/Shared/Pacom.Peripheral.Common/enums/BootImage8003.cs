﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum BootImage8003
    {
        /// <summary>8003 Image 1</summary>
        Image1,
        /// <summary>8003 Image 2</summary>
        Image2
    }
}
