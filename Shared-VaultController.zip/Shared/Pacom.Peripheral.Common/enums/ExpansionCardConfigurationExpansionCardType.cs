﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This enumerator is used for expansion card configuration. The expansion card type.
    /// </summary>
    public enum ExpansionCardConfigurationExpansionCardType : byte
    {
        /// <summary>No expansion card type.</summary>
        None = 0,
        /// <summary>8201 GPRS expansion card.</summary>
        Pacom8201GprsCard = 1,
        /// <summary>8203 output expansion card.</summary>
        Pacom8203OutputCard = 2,
        /// <summary>8204 input expansion card.</summary>
        Pacom8204InputCard = 3,
        /// <summary>8205 serial expansion card.</summary>
        Pacom8205SerialCard = 4,
        /// <summary>8207 star coupler expansion card.</summary>
        Pacom8207StarCouplerCard = 5,
        /// <summary>8208 S-ART input/out expansion card.</summary>
        Pacom8208SartInputOutputCard = 6,
        /// <summary>8209 PSTN modem expansion card.</summary>
        Pacom8209PstnCard = 7,
    }
}
