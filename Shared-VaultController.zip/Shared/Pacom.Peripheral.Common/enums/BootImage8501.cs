﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum BootImage8501
    {
        /// <summary>8501 Rescue Image</summary>
        RescueImage,
        /// <summary>8501 Image A</summary>
        ImageA,
        /// <summary>8501 Image B</summary>
        ImageB
    }
}
