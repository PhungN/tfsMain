﻿using System;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum ExpansionCardOutputs
    {
        None = 0,
        Output1 = 1,
        Output2 = 2,
        Output3 = 4,
        Output4 = 8,
    }
}
