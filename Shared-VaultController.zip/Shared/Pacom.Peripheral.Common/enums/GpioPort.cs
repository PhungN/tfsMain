﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum GpioPort
    {
        PortA = 0,
        PortB = 1,
        PortC = 2
    }
}
