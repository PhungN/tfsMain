﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Defines owners of configuration elements in a message received from controller
    /// </summary>
    public enum OwnerType
    {
        None = 0,
        Tamper,
        Onboard,
        Expansion1,
        Expansion2,
        Expansion3,
        Expansion4,
        Sart1,
    }
}
