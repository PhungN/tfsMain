﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum LedColor
    {
        None = 0,
        Green = 1,
        Amber = 2,
        Red = 3,
        GreenAndAmber = 4,
    }
}
