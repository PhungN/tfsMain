﻿using System;

namespace Pacom.Peripheral.Common
{
    [Flags]
    public enum PowerSupplyStatus
    {
        Unknown = -1,
        Normal = 0,
        ACFail = 0x01,        // Power Supply Failed
        BatteryFail = 0x02,   // No Battery
        BatteryLow = 0x04,    // Low Battery Voltage
        BatteryHigh = 0x08,   // High Battery Voltage
        LowAcVoltage = 0x10,  // Low Supply Voltage
        HighAcVoltage = 0x20, // High Supply Voltage
        ChargerFail = 0x80,   // Battery Charger Failed
    }

    public static class PowerSupplyStatusExtansions
    {
        public static bool Has(this PowerSupplyStatus type, PowerSupplyStatus value)
        {
            if ((type & value) == value)
                return true;
            return false;
        }

        public static bool DoesNotHave(this PowerSupplyStatus type, PowerSupplyStatus value)
        {
            if ((type & value) != value)
                return true;
            return false;
        }

        public static PowerSupplyStatus SetFlags(this PowerSupplyStatus type, PowerSupplyStatus flags)
        {
            return type | flags;
        }
    }
}
