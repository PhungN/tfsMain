﻿using System;

namespace Pacom.Peripheral.Common
{
    public enum ReaderManufacturer
    {
        Unknown = 0,
        Pacom = 1,
        HidCorporation = 2,
        Contal = 3,
        Bqt = 4
    }
}
