﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon; 

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class provides logging functionality.
    /// Logging is cached in memory and is written to nonvolatile memory upon USB insertion.
    /// </summary>
    public static partial class Logger
    {
        public const string DateTimeFormat = "dd/MM/yy HH:mm:ss.fff";

        private static List<LogEntry> criticalLog = new List<LogEntry>(500);
        private static List<LogEntry> errorLog = new List<LogEntry>(500);
        private static List<LogEntry> warnLog = new List<LogEntry>(500);
        private static List<LogEntry> debugLog = new List<LogEntry>(500);
        private static List<LogEntry> tracedCommsLog = new List<LogEntry>(500);

        private static LoggingLevel loggingLevel = LoggingLevel.Debug;
        private static readonly object sync = new object();

        public static event EventHandler<LoggingEventArgs> MessageToLogAvailable;

        public static LoggingLevel LoggingLevel
        {
            get
            {
                return loggingLevel;
            }
        }

        public static List<string> CriticalLog
        {
            get
            {
                List<string> log;
                lock (sync)
                {
                    log = new List<string>(criticalLog.Count);
                    foreach (LogEntry logEntry in criticalLog)
                    {
                        // StringBuilder.Append has been used deliberately over StringBuilder.AppendFormat due to performance considerations.
                        // StringBuilder has been used over string concatenation to limit memory fragmentation.
                        StringBuilder sb = new StringBuilder(DateTimeFormat.Length + 2 + logEntry.Message.Length);
                        sb.Append(logEntry.Time.ToString(DateTimeFormat));
                        sb.Append(": ");
                        sb.Append(logEntry.Message);
                        log.Add(sb.ToString());
                    }
                }
                return log;
            }
        }

        public static List<string> ErrorLog
        {
            get
            {
                List<string> log;
                lock (sync)
                {
                    log = new List<string>(errorLog.Count);
                    foreach (LogEntry logEntry in errorLog)
                    {
                        // StringBuilder.Append has been used deliberately over StringBuilder.AppendFormat due to performance considerations.
                        // StringBuilder has been used over string concatenation to limit memory fragmentation.
                        StringBuilder sb = new StringBuilder(DateTimeFormat.Length + 2 + logEntry.Message.Length);
                        sb.Append(logEntry.Time.ToString(DateTimeFormat));
                        sb.Append(": ");
                        sb.Append(logEntry.Message);
                        log.Add(sb.ToString());
                    }
                }
                return log;
            }
        }

        public static List<string> WarnLog
        {
            get
            {
                List<string> log;
                lock (sync)
                {
                    log = new List<string>(warnLog.Count);
                    foreach (LogEntry logEntry in warnLog)
                    {
                        // StringBuilder.Append has been used deliberately over StringBuilder.AppendFormat due to performance considerations.
                        // StringBuilder has been used over string concatenation to limit memory fragmentation.
                        StringBuilder sb = new StringBuilder(DateTimeFormat.Length + 2 + logEntry.Message.Length);
                        sb.Append(logEntry.Time.ToString(DateTimeFormat));
                        sb.Append(": ");
                        sb.Append(logEntry.Message);
                        log.Add(sb.ToString());
                    }
                }
                return log;
            }
        }

        public static List<string> DebugLog
        {
            get
            {
                List<string> log;
                lock (sync)
                {
                    log = new List<string>(debugLog.Count);
                    foreach (LogEntry logEntry in debugLog)
                    {
                        // StringBuilder.Append has been used deliberately over StringBuilder.AppendFormat due to performance considerations.
                        // StringBuilder has been used over string concatenation to limit memory fragmentation.
                        StringBuilder sb = new StringBuilder(DateTimeFormat.Length + 2 + logEntry.Message.Length);
                        sb.Append(logEntry.Time.ToString(DateTimeFormat));
                        sb.Append(": ");
                        sb.Append(logEntry.Message);
                        log.Add(sb.ToString());
                    }
                }
                return log;
            }
        }

        public static List<string> TracedCommsLog
        {
            get
            {
                List<string> log;
                lock (sync)
                {
                    log = new List<string>(tracedCommsLog.Count);
                    foreach (LogEntry logEntry in tracedCommsLog)
                    {
                        // StringBuilder.Append has been used deliberately over StringBuilder.AppendFormat due to performance considerations.
                        // StringBuilder has been used over string concatenation to limit memory fragmentation.
                        StringBuilder sb = new StringBuilder(DateTimeFormat.Length + 2 + logEntry.Message.Length);
                        sb.Append(logEntry.Time.ToString(DateTimeFormat));
                        sb.Append(": ");
                        sb.Append(logEntry.Message);
                        log.Add(sb.ToString());
                    }
                }
                return log;
            }
        }

        /// <summary>
        /// Updates the logging level.
        /// </summary>
        /// <param name="newLoggingLevel">The new logging level to use.</param>
        public static void SetLoggingLevel(LoggingLevel newLoggingLevel)
        {
            loggingLevel = newLoggingLevel;
        }

        /// <summary>
        /// Adds a new message to the log file.
        /// </summary>
        /// <param name="level">The severity of the message.</param>
        /// <param name="message">The message to log.</param>
        private static void logMessage(LoggingLevel level, string message)
        {
            if ((int)level <= (int)loggingLevel)
            {
                List<LogEntry> log = null;
                switch (level)
                {
                    case LoggingLevel.Critical:
                        log = criticalLog;
                        break;
                    case LoggingLevel.Error:
                        log = errorLog;
                        break;
                    case LoggingLevel.Warn:
                        log = warnLog;
                        break;
                    case LoggingLevel.Debug:
                        log = debugLog;
                        break;
                    case LoggingLevel.TracedComms:
                        log = tracedCommsLog;
                        break;
                }

                lock (sync)
                {
                    DateTime messageTime = DateTime.UtcNow;
                    if (level != LoggingLevel.TracedComms)
                    {
#if DEBUG
                        string msg = String.Format("{0} : {1}", messageTime.ToString(Logger.DateTimeFormat), message);
                        Console.WriteLine(msg);
                        Debug.WriteLine(msg);
#else
                        Console.WriteLine(message);
#endif
                    }

                    if (log.Count == 500)
                        log.RemoveAt(0);
                    log.Add(new LogEntry(messageTime, message));
                }

                if (MessageToLogAvailable != null)
                    MessageToLogAvailable(null, new LoggingEventArgs(level, message));
            }
        }

        /// <summary>
        /// This method should be called upon USB insertion before the nonvolatile memory is unmounted.
        /// This method writes out all cached log files to the nonvolatile memory.
        /// </summary>
        public static void WriteLogsToDisk()
        {
            try
            {
                if (Directory.Exists("\\PublicRegion\\Logs") == false)
                    Directory.CreateDirectory("\\PublicRegion\\Logs");
                if (File.Exists("\\PublicRegion\\Logs\\critical.log"))
                    File.Delete("\\PublicRegion\\Logs\\critical.log");
                if (File.Exists("\\PublicRegion\\Logs\\error.log"))
                    File.Delete("\\PublicRegion\\Logs\\error.log");
                if (File.Exists("\\PublicRegion\\Logs\\warn.log"))
                    File.Delete("\\PublicRegion\\Logs\\warn.log");
                if (File.Exists("\\PublicRegion\\Logs\\debug.log"))
                    File.Delete("\\PublicRegion\\Logs\\debug.log");
                if (File.Exists("\\PublicRegion\\Logs\\tracedComms.log"))
                    File.Delete("\\PublicRegion\\Logs\\tracedComms.log");

                if (criticalLog.Count > 0)
                {
                    using (StreamWriter sw = new StreamWriter("\\PublicRegion\\Logs\\critical.log", false))
                    {
                        List<string> log = CriticalLog;
                        foreach (string logEntry in log)
                        {
                            sw.WriteLine(logEntry);
                        }
                        sw.Close();
                    }
                }
                if (errorLog.Count > 0)
                {
                    using (StreamWriter sw = new StreamWriter("\\PublicRegion\\Logs\\error.log", false))
                    {
                        List<string> log = ErrorLog;
                        foreach (string logEntry in log)
                        {
                            sw.WriteLine(logEntry);
                        }
                        sw.Close();
                    }
                }
                if (warnLog.Count > 0)
                {
                    using (StreamWriter sw = new StreamWriter("\\PublicRegion\\Logs\\warn.log", false))
                    {
                        List<string> log = WarnLog;
                        foreach (string logEntry in log)
                        {
                            sw.WriteLine(logEntry);
                        }
                        sw.Close();
                    }
                }
                if (debugLog.Count > 0)
                {
                    using (StreamWriter sw = new StreamWriter("\\PublicRegion\\Logs\\debug.log", false))
                    {
                        List<string> log = DebugLog;
                        foreach (string logEntry in log)
                        {
                            sw.WriteLine(logEntry);
                        }
                        sw.Close();
                    }
                }
                if (tracedCommsLog.Count > 0)
                {
                    using (StreamWriter sw = new StreamWriter("\\PublicRegion\\Logs\\tracedComms.log", false))
                    {
                        List<string> log = TracedCommsLog;
                        foreach (string logEntry in log)
                        {
                            sw.WriteLine(logEntry);
                        }
                        sw.Close();
                    }
                }
                // Device specific logs
                CreateDeviceSpecificLogs();
            }
            catch
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return "Unable to create log files.";
                });
            }

            try
            {
                if (File.Exists("\\PublicRegion\\Logs\\uptime.log"))
                    File.Delete("\\PublicRegion\\Logs\\uptime.log");
                using (StreamWriter sw = new StreamWriter("\\PublicRegion\\Logs\\uptime.log", false))
                {
                    WriteUptimeInfo(sw);
                    sw.Close();
                }
            }
            catch
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return "Unable to create uptime log file.";
                });
            }

            try
            {
                if (File.Exists("\\PublicRegion\\Logs\\system.log"))
                    File.Delete("\\PublicRegion\\Logs\\system.log");
                using (StreamWriter sw = new StreamWriter("\\PublicRegion\\Logs\\system.log", false))
                {
                    WriteSystemInfo(sw, false);
                    sw.Close();
                }
            }
            catch
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return "Unable to create system log file.";
                });
            }
        }

        public static void WriteShutDownReason(bool force)
        {
            string stackTrace = null;

            if (force)
            {
                try
                {
                    throw new Exception();
                }
                catch (Exception ex)
                {
                    stackTrace = ex.StackTrace;
                }
            }

            try
            {
                if (Directory.Exists(FileSystemPaths.ShutDownLogPath) == false)
                    Directory.CreateDirectory(FileSystemPaths.ShutDownLogPath);

                using (StreamWriter streamWriter = new StreamWriter(FileSystemPaths.ShutDownLogFilePath, true))
                {
                    if (force)
                    {
                        streamWriter.WriteLine(string.Format("{0} Forcefully shutting down:", DateTime.UtcNow.ToString("dd/MM/yy HH:mm:ss.fff")));
                        streamWriter.WriteLine(stackTrace);
                    }
                    else
                    {
                        streamWriter.WriteLine(string.Format("{0} Gracefully shutting down.", DateTime.UtcNow.ToString("dd/MM/yy HH:mm:ss.fff")));
                    }

                    streamWriter.Flush();
                    streamWriter.Close();
                }
            }
            catch
            {
            }
        }

        public static void WriteStartUpDetails(ProcessorResetType resetType)
        {
            try
            {
                if (Directory.Exists(FileSystemPaths.ShutDownLogPath) == false)
                    Directory.CreateDirectory(FileSystemPaths.ShutDownLogPath);

                DirectoryInfo directoryInfo = new DirectoryInfo(FileSystemPaths.ShutDownLogPath);
                FileInfo[] files = directoryInfo.GetFiles();

                bool filesDeleted = false;
                foreach (FileInfo file in files)
                {
                    if (file.Length > 2000000)
                    {
                        file.Delete();
                        filesDeleted = true;
                    }
                }

                if (filesDeleted)
                    Thread.Sleep(1000);


                using (StreamWriter streamWriter = new StreamWriter(FileSystemPaths.ShutDownLogFilePath, true))
                {
                    streamWriter.WriteLine(string.Format("{0} Starting up. Reset type {1}.", DateTime.UtcNow.ToString("dd/MM/yy HH:mm:ss.fff"), resetType.ToString()));
                    streamWriter.Flush();
                    streamWriter.Close();
                }
            }
            catch
            {
            }
        }
    }
}
