﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utilities;

namespace Pacom.Peripheral.Common.AccessControl
{
    public static class CardFormats
    {
        public static CardFormatMasksConfig CreateMasksConfig(LegacyCardFormat[] cardFormats)
        {
            CardFormatMasksConfig masks = new CardFormatMasksConfig();
            if (cardFormats != null)
            {
                for (int i = 0; i < Math.Min(cardFormats.Length, CardFormatMasksConfig.MaxCardProfiles); i++)
                {
                    LegacyCardFormat cardFormat = cardFormats[i];
                    if (cardFormat != null)
                    {
                        CardFormatMaskConfig mask = masks[i];
                        mask.NumberOfWiegandBits = cardFormat.NumberOfBits;
                        // Facility Definition
                        mask.Facility.Length = (byte)cardFormat.FacilityLength;
                        mask.Facility.ZeroBasedOffset = cardFormat.FacilityOffset - 1;
                        mask.Facility.UnitType = CardConfigFieldType.InBits;

                        // Issue Definition
                        mask.Issue.Length = (byte)cardFormat.IssueLength;
                        mask.Issue.ZeroBasedOffset = cardFormat.IssueOffset - 1;
                        mask.Issue.UnitType = cardFormat.IssueLength == 0 ? CardConfigFieldType.NotUsed : CardConfigFieldType.InBits;

                        // Code Definition
                        mask.Code.Length = (byte)cardFormat.CodeLength;
                        mask.Code.ZeroBasedOffset = cardFormat.CodeOffset - 1;
                        mask.Code.UnitType = CardConfigFieldType.InBits;

                        // Designators Format Facility = 2 / Issue = 1 / Code = 5
                        mask.Designators.Facility = 16;
                        mask.Designators.Issue = 8;
                    }
                }
            }
            return masks;
        }

        public static CardFormatParityConfig[] CreateParityConfig(ILegacyReaderConfiguration readerConfig)
        {
            if (readerConfig == null || readerConfig.CardFormats == null || readerConfig.CardFormats.Length == 0)
                return null;
            LegacyCardFormat[] cardFormats = readerConfig.CardFormats;
            CardFormatParityConfig[] cardFormatParityConfig = new CardFormatParityConfig[cardFormats.Length];
            for (int i = 0; i < cardFormats.Length; i++)
            {
                LegacyCardFormat cardFormat = cardFormats[i];
                if (cardFormat != null)
                {
                    CardFormatParityConfig parityFormat = new CardFormatParityConfig();
                    if (parityFormat != null)
                    {
                        parityFormat.Invert = cardFormat.InvertCardBits;
                        parityFormat.Reverse = cardFormat.ReverseCardBits;
                        if (cardFormat.ParityConfiguration != null)
                        {
                            for (int j = 0; j < cardFormat.ParityConfiguration.Length; j++)
                            {
                                parityFormat.Mask[j].Enabled = cardFormat.ParityConfiguration[j].ParityType != CardParity.None;
                                parityFormat.Mask[j].OddParity = cardFormat.ParityConfiguration[j].ParityType == CardParity.Odd;
                                parityFormat.Mask[j].Mask = CommonUtilities.GetParityMaskBytesFromLong(cardFormat.ParityConfiguration[j].Mask, cardFormat.NumberOfBits, cardFormat.ParityConfiguration[j].Offset);
                                parityFormat.Mask[j].Offset = cardFormat.ParityConfiguration[j].Offset;
                            }
                        }
                        cardFormatParityConfig[i] = parityFormat;
                    }
                }
            }

            return cardFormatParityConfig;
        }

        public static void ConstructLegacyCodeMaskCommand(CardFormatMasksConfig config, CardFormatParityConfig[] parityConfig, byte[] data, int offset)
        {
            for (int iPosition = 0; iPosition < 4; iPosition++)
            {
                // The 1076 removes the parity bits prior to processing the facility / issue / code
                // which is different to how the 8501 / 8603 / 8003 behave so we need to compensate for it here.
                int parirtyBitOffset1 = -1; // Zero based offsets
                int parirtyBitOffset2 = -1;
                int parirtyBitOffset3 = -1;
                if (parityConfig != null && parityConfig.Length > iPosition)
                {
                    if (parityConfig[iPosition].Mask[0] != null && parityConfig[iPosition].Mask[0].Enabled == true)
                        parirtyBitOffset1 = parityConfig[iPosition].Mask[0].Offset - 1;
                    if (parityConfig[iPosition].Mask[1] != null && parityConfig[iPosition].Mask[1].Enabled == true)
                        parirtyBitOffset2 = parityConfig[iPosition].Mask[1].Offset - 1;
                    if (parityConfig[iPosition].Mask[2] != null && parityConfig[iPosition].Mask[2].Enabled == true)
                        parirtyBitOffset3 = parityConfig[iPosition].Mask[2].Offset - 1;
                }

                CardFormatMaskConfig mask = config.Masks[iPosition];
                int facilityOffset = mask.Facility.ZeroBasedOffset;
                if (parirtyBitOffset1 != -1 && parirtyBitOffset1 < mask.Facility.ZeroBasedOffset)
                    facilityOffset--;
                if (parirtyBitOffset2 != -1 && parirtyBitOffset2 < mask.Facility.ZeroBasedOffset)
                    facilityOffset--;
                if (parirtyBitOffset3 != -1 && parirtyBitOffset3 < mask.Facility.ZeroBasedOffset)
                    facilityOffset--;

                int issueOffset = mask.Issue.ZeroBasedOffset;
                if (parirtyBitOffset1 != -1 && parirtyBitOffset1 < mask.Issue.ZeroBasedOffset)
                    issueOffset--;
                if (parirtyBitOffset2 != -1 && parirtyBitOffset2 < mask.Issue.ZeroBasedOffset)
                    issueOffset--;
                if (parirtyBitOffset3 != -1 && parirtyBitOffset3 < mask.Issue.ZeroBasedOffset)
                    issueOffset--;

                int codeOffset = mask.Code.ZeroBasedOffset;
                if (parirtyBitOffset1 != -1 && parirtyBitOffset1 < mask.Code.ZeroBasedOffset)
                    codeOffset--;
                if (parirtyBitOffset2 != -1 && parirtyBitOffset2 < mask.Code.ZeroBasedOffset)
                    codeOffset--;
                if (parirtyBitOffset3 != -1 && parirtyBitOffset3 < mask.Code.ZeroBasedOffset)
                    codeOffset--;

                int index = iPosition * 8 + offset;
                data[index] = (byte)mask.NumberOfWiegandBits;
                // Facility
                data[index+1] = (byte)(mask.Facility.Length & 0x3F);
                if (mask.Facility.UnitType == CardConfigFieldType.InBits)
                    data[index+1] |= 0x40;
                data[index+2] = (byte)((facilityOffset & 0x7F) + 1);
                if (mask.Facility.IncludeInMask)
                    data[index+2] |= 0x80;
                // Issue
                data[index+3] = (byte)(mask.Issue.Length & 0x3F);
                if (mask.Issue.UnitType == CardConfigFieldType.InBits)
                    data[index+3] |= 0x40;
                data[index+4] = (byte)((issueOffset & 0x7F) + 1);
                if (mask.Issue.IncludeInMask)
                    data[index+4] |= 0x80;
                // Code
                data[index+5] = (byte)(mask.Code.Length & 0x3F);
                if (mask.Code.UnitType == CardConfigFieldType.InBits)
                    data[index+5] |= 0x40;
                data[index+6] = (byte)((codeOffset & 0x7F) + 1);
                if (mask.Code.IncludeInMask)
                    data[index+6] |= 0x80;
                // Designators
                data[index+7] = (byte)((mask.Designators.Facility == 0 ? 0 : mask.Designators.Facility / 4) & 0x0F);
                data[index+7] |= (byte)(((mask.Designators.Issue == 0 ? 0 : mask.Designators.Issue / 4) << 4) & 0xF0);
            }
        }

        public static void UpdateReaderInitializationCardFormatConfig(ReaderInitializationConfig readerInitCfg, ILegacyReaderConfiguration legacyReaderCfg)
        {
            if (readerInitCfg != null && legacyReaderCfg != null && legacyReaderCfg.CardFormats.Length > 0)
            {
                foreach (var cardFormat in legacyReaderCfg.CardFormats)
                {
                    if (cardFormat != null && cardFormat.NumberOfBits == 26)
                    {
                        readerInitCfg.Facility.Length = (byte)cardFormat.FacilityLength;
                        readerInitCfg.Facility.ZeroBasedOffset = cardFormat.FacilityOffset;
                        readerInitCfg.Issue.Length = (byte)cardFormat.IssueLength;
                        readerInitCfg.Issue.ZeroBasedOffset = cardFormat.IssueOffset;
                        readerInitCfg.Code.Length = (byte)cardFormat.CodeLength;
                        readerInitCfg.Code.ZeroBasedOffset = cardFormat.CodeOffset;
                        break;
                    }
                }
            }
        }
    }
}
