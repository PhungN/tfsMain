﻿using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Net;
using System.Collections.Generic;
using Pacom.Peripheral.Common.Utils;
using System.Security.Cryptography;

#if CONTROLLER
using Pacom.Core.Contracts;
#endif

namespace Pacom.Peripheral.Common
{
    public static class ByteExtensions
    {
        public static int Contains(this byte[] buffer, byte[] toFind)
        {
            bool found = false;
            int currentBufferOffset;

            for (currentBufferOffset = 0; currentBufferOffset < (buffer.Length - (toFind.Length - 1)); currentBufferOffset++)
            {
                for (int toFindOffset = 0; toFindOffset < toFind.Length; toFindOffset++)
                {
                    if (buffer[currentBufferOffset + toFindOffset] != toFind[toFindOffset])
                    {
                        found = false;
                        break;
                    }
                    else
                    {
                        found = true;
                    }
                }
                if (found == true)
                    return currentBufferOffset;
            }
            if (found == true)
                return currentBufferOffset;
            return -1;
        }

        public static bool Compare(this byte[] buffer1, byte[] buffer2)
        {
            if (buffer1 == buffer2) return true;
            if (buffer1 == null || buffer2 == null || buffer1.Length != buffer2.Length)
                return false;

            int length = buffer1.Length;
            for (int i = 0; i < length; i++)
            {
                if (buffer1[i] != buffer2[i])
                    return false;
            }
            return true;
        }
    }

    public static class ListIntExtensions
    {
        /// <summary>
        /// Compare to list of integers and return true if they are the same.
        /// </summary>
        /// <param name="intList">Source list on which the comparison will be done.</param>
        /// <param name="obj">List to compare with. It will be sorted before comparison.</param>
        /// <returns>Returns true if the lists are the same</returns>
        public static bool IsSameList(this List<int> intList, List<int> obj)
        {
            if (obj == null)
                return false;
            List<int> list1 = new List<int>(intList);
            List<int> list2 = new List<int>(obj);
            list1.Sort();
            list2.Sort();
            return list1.SequenceEqual(list2);

        }
    }

    public static class IntExtensions
    {
        public static bool Contains(this int[] array, int toFind)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == toFind)
                    return true;
            }
            return false;
        }

        public static bool TryParseInt(this int numeric, string s, out int value)
        {
            try
            {
                value = int.Parse(s);
                return true;
            }
            catch
            {
                value = 0;
                return false;
            }
        }

        public static bool TryParseInt(this int numeric, string s, NumberStyles style, IFormatProvider provider, out int value)
        {
            try
            {
                value = int.Parse(s, style, provider);
                return true;
            }
            catch
            {
                value = 0;
                return false;
            }
        }

#if CONTROLLER
        /// <summary>
        /// Extension method for converting an integer number to an array of digits. E.g. 1234 -> digit[0]=1, digit[1]=2, digit[2]=3, digit[3]=4
        /// </summary>
        /// <param name="numeric">Integer number to be converted.</param>
        /// <returns>Array of integer digits</returns>
        public static int[] Digits(this int numeric, out int len)
        {
            len = numeric > 0 ? 1 + Convert.ToInt32(Math.Floor(Math.Log10(numeric))) : 1;
            int[] digits = new int[len];

            for (int i = len - 1; i >= 0; i--)
            {
                digits[i] = numeric % 10;
                numeric = numeric / 10;
            }
            return digits;
        }

        /// <summary>
        /// Check if duress pin was used by the user
        /// </summary>
        /// <param name="expectedUserPin">Configured User Pin</param>
        /// <param name="userPin">Entered Pin</param>
        /// <param name="duressType">Duress Type</param>
        /// <returns>True if duress pin / False otherwise.</returns>
        public static bool CheckDuressPin(this int expectedUserPin, int userPin, DuressType duressType)
        {
            if (duressType == DuressType.None)
                return false;

            int len = 0;
            int[] digits = expectedUserPin.Digits(out len);

            // Case 1: Check normal duress behaviour 1st - this should be the most common occurrance: 
            // E.g.: Pin = 2461 -> Duress Pin = 2462;
            //       Pin = 1299 -> Duress Pin = 1300;
            //       Pin = 9999 -> Duress Pin = 10000;
            int duressPin = expectedUserPin + (int)duressType;
            if (duressPin == userPin)
                return true;

            // Case 2: Check duress when the user pin ends in 9, e.g.: Pin = 1299 -> Duress Pin = 1290, 
            // Case 3: Check duress when the user pin is max pin: e.g.: Pin = 9999 -> Duress Pin = 9990(1) / 0000(2) / 1000(3)
            if (digits[len - 1] == 9)
            {
                // Check Case 2 / 3(1)
                if (expectedUserPin - 9 == userPin)
                    return true;

                if (digits.All(digit => digit == 9) == false)
                    return false;
                // Check Case 3(2) & 3(3)
                if (userPin == 0)
                    return true;
                return userPin == duressPin / 10;
            }
            return false;
        }

        /// <summary>
        /// If a duress pin was used, return a list of all possible valid PINs
        /// </summary>
        /// <param name="enteredUserPin">Entered Pin</param>
        /// <param name="duressType">Duress Type</param>
        /// <returns>An array of all valid PINs.</returns>
        public static int[] GetValidPins(this int enteredUserPin, DuressType duressType)
        {
            if (duressType == DuressType.None)
                return new int[0];

            List<int> possiblePins = new List<int>();
            int len = 0;
            int[] digits = enteredUserPin.Digits(out len);

            // Case 1: Check normal duress behaviour 1st - this should be the most common occurrance: 
            // E.g.: Pin = 2461 -> Duress Pin = 2462;
            //       Pin = 1299 -> Duress Pin = 1300;
            //       Pin = 9999 -> Duress Pin = 10000;
            if (enteredUserPin != 0)
                possiblePins.Add(enteredUserPin - (int)duressType);

            // Case 2: Check duress when the user pin ends in 9, e.g.: Pin = 1299 -> Duress Pin = 1290, 
            // Case 3: Check duress when the user pin is max pin: e.g.: Pin = 9999 -> Duress Pin = 9990(1) / 0000(2) / 1000(3)
            if (digits[len - 1] == 0)
            {
                // Check Case 2 / 3(1)
                possiblePins.Add(enteredUserPin + 9);

                int pinLength = Pacom.Peripheral.Common.Configuration.ConfigurationManager.Instance.ControllerConfiguration.AlarmUserPinLength;
                if (pinLength != 10 && (enteredUserPin == 0 || enteredUserPin == (int)Math.Pow(10, pinLength - 1)))
                {
                    // Check Case 3(2) & 3(3)
                    possiblePins.Add((int)Math.Pow(10, pinLength) - 1);
                }
            }
            return possiblePins.ToArray();
        }
#endif

    }

    public static class LongExtensions
    {
        public static bool TryParseLong(this long numeric, string s, out long value)
        {
            try
            {
                value = long.Parse(s);
                return true;
            }
            catch
            {
                value = 0;
                return false;
            }
        }

        public static bool TryParseLong(this long numeric, string s, NumberStyles style, IFormatProvider provider, out long value)
        {
            try
            {
                value = long.Parse(s, style, provider);
                return true;
            }
            catch
            {
                value = 0;
                return false;
            }
        }
    }

    public static class StringExtensions
    {
        public static string TruncateOrPadRight(this string message, int length)
        {
            return message.Length > length ? message.Substring(0, length) : 
                                             message.PadRight(length);
        }

        public static string SplitAtSeparatorAndOnMaxLength(this string message, int length)
        {
            if (message.Length > length) 
            {
                string[] chunks = message.Split();
                if (chunks.Length == 1)
                {
                    // Split the contiguous text into chunks that will fit on the keypad LCD display
                    return message.SplitMaxLength(length - 2);
                }

                int chunkCount = chunks.Length;
                for (int i = 0; i < chunkCount; i++)
                {
                    var chunk = chunks[i];
                    // Trimmed length takes into account the scroll left < / right > placeholders that will be present if
                    // at least 2 chunks of text are found
                    if (chunk.Length > length - 2)
                    {
                        chunks[i] = chunk.SplitMaxLength(length - 2);
                    }
                }
                message = string.Join(" ", chunks);
            }
            return message;
        }

        /// <summary>
        /// Split the string into multiple strings none of them being longer than the supplied maxLen length.
        /// First check if the string contains any of the separators
        /// </summary>
        /// <param name="message">Message to split.</param>
        /// <param name="maxLen">Maximum allowed chunk length.</param>
        /// <returns></returns>
        public static string SplitMaxLength(this string message, int maxLen)
        {
            char[] separators = new char[] { '/', '\\', '|', ':', ',', '.', '-' };
            int position = message.IndexOfAny(separators);
            if (position == -1)
            {
                // Split the string into chunks that are not longer than maxLen
                return splitString(message, maxLen);
            }
            else
            {
                List<string> fragments = new List<string>();
                StringBuilder fragment = new StringBuilder();
                // Split at separators and also enforce the allowed length (maxLen)
                int start = 0;
                int fragmentLen = 0;
                while (position >= 0)
                {
                    int len = position - start + 1;
                    fragmentLen += position - start + 1;
                    if (fragmentLen > maxLen)
                    {
                        // Add fragment to list of fragments
                        fragments.Add(fragment.ToString());
                        fragment.Remove(0, fragment.Length);
                    }
                    fragment.Append(message.Substring(start, len));
                    start = position + 1;
                    if (start == message.Length)
                    {
                        if (fragment.Length > 0)
                        {
                            fragments.Add(fragment.ToString());
                        }
                        break;
                    }
                    position = message.IndexOfAny(separators, start);
                    if (position == -1 && fragment.Length > 0)
                    {
                        fragments.Add(fragment.ToString());
                        // Copy all remaining chars
                        string remainingString = message.Substring(start);
                        fragments.Add(remainingString.Length > maxLen ? splitString(remainingString, maxLen) : remainingString);
                    }
                }
                return string.Join(" ", fragments.ToArray());
            }
        }

        private static string splitString(string message, int maxLen)
        {
            List<string> fragments = new List<string>();
            int start = 0;
            // Split the string using the allowed length (maxLen)
            int messageLen = message.Length;
            while (start < messageLen)
            {
                int fragmentLen = Math.Min(maxLen, messageLen - start);
                fragments.Add(message.Substring(start, fragmentLen));
                start += fragmentLen;
                if (start >= messageLen)
                    break;
            }
            return string.Join(" ", fragments.ToArray());
        }

        private static TextInfo textInfo = new CultureInfo("").TextInfo;

        /// <summary>
        /// Convert the [text] to title case.
        /// </summary>
        /// <param name="text">Text to convert to title case</param>
        /// <returns>Title cased text.</returns>
        public static string ToTitleCase(this string text)
        {
            string newText = text.ToLower();
            return textInfo.ToTitleCase(newText);
        }

        /// <summary>
        /// Replace any non ASCII characters with '?' (only lower ASCII chars are supported: 32 to 127)
        /// </summary>
        /// <param name="text">Text to encode</param>
        /// <returns>Encoded text</returns>
        public static string ReplaceAnyNonASCIICharacters(this string text)
        {
            if (string.IsNullOrEmpty(text))
                return string.Empty;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < text.Length; i++)
            {
                char ch = text[i];
                if ((ch >= 32 && ch < 128) &&
                    (ch != '&' && ch != '>' && ch != '<' && ch != '\''))
                {
                    sb.Append(ch);
                }
                else
                {
                    sb.Append('?');
                }
            }
            return sb.ToString();
        }

        /// <summary>
        /// Check if the string's length has the expected values
        /// </summary>
        /// <param name="toCheck"></param>
        /// <param name="lengthToCheck"></param>
        /// <returns></returns>
        public static bool IsValidLength(this string toCheck, int lengthToCheck)
        {
            return toCheck.Length > 0 && toCheck.Length == lengthToCheck;
        }

        /// <summary>
        /// Pad message at both ends with padding spaces so the message will be centered 
        /// </summary>
        /// <param name="message">Message to center</param>
        /// <param name="totalWidth">Buffer width</param>
        /// <returns></returns>
        public static string Center(this string message, int totalWidth)
        {
            int msgLen = message.Length;
            if (totalWidth <= msgLen || msgLen == 0)
                return message;
            int padding = (totalWidth - msgLen) / 2;
            message = message.PadLeft(msgLen + padding);
            return message.PadRight(message.Length + padding);
        }

        /// <summary>
        /// Pad message at fron end with padding spaces so the message will be centered
        /// </summary>
        /// <param name="source"></param>
        /// <param name="totalWidth"></param>
        /// <returns></returns>
        public static string CenterText(this string source, int totalWidth)
        {
            if (string.IsNullOrEmpty(source) == false && source.Length < totalWidth)
                return source.PadLeft(source.Length + (totalWidth - source.Length) / 2, ' ');
            return source;
        }

        /// <summary>
        /// Encrypting a string with key { 0xA5, 0x04, 0x09, 0x20, 0x18, 0x20, 0x80, 0x03, 0x20, 0x86, 0x03, 0x20, 0x85, 0x01, 0x20, 0x5A }
        /// </summary>
        /// <param name="source"></param>
        /// <returns>encrypted base 64 string</returns>
        public static string Encrypt(this string source)
        {
            byte[] encryptedData = null;
            using (Rijndael rijndael = Rijndael.Create())
            {
                rijndael.Padding = PaddingMode.Zeros;
                rijndael.Mode = CipherMode.CBC;
                var key = new byte[] { 0xA5, 0x04, 0x09, 0x20, 0x18, 0x20, 0x80, 0x03, 0x20, 0x86, 0x03, 0x20, 0x85, 0x01, 0x20, 0x5A };
                using (var cryptoTransform = rijndael.CreateEncryptor(key, new byte[16]))
                {
                    byte[] plainBytes = Encoding.ASCII.GetBytes(source);
                    encryptedData = cryptoTransform.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
                }
            }
            return encryptedData != null ? Convert.ToBase64String(encryptedData) : string.Empty;
        }

        /// <summary>
        /// Decrypt a base 64 string with key { 0xA5, 0x04, 0x09, 0x20, 0x18, 0x20, 0x80, 0x03, 0x20, 0x86, 0x03, 0x20, 0x85, 0x01, 0x20, 0x5A }
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static string Decrypt(this string source)
        {
            byte[] decryptedData = null;
            if (string.IsNullOrEmpty(source) == false)
            {
                using (Rijndael rijndael = Rijndael.Create())
                {
                    rijndael.Padding = PaddingMode.None;
                    rijndael.Mode = CipherMode.CBC;
                    var key = new byte[] { 0xA5, 0x04, 0x09, 0x20, 0x18, 0x20, 0x80, 0x03, 0x20, 0x86, 0x03, 0x20, 0x85, 0x01, 0x20, 0x5A };
                    using (var cryptoTransform = rijndael.CreateDecryptor(key, new byte[16]))
                    {
                        byte[] encryptedData = Convert.FromBase64String(source);
                        decryptedData = cryptoTransform.TransformFinalBlock(encryptedData, 0, encryptedData.Length);
                    }
                }
            }
            return decryptedData != null ? Encoding.UTF8.GetString(decryptedData, 0, decryptedData.Length).TrimEnd('\0') : string.Empty;
        }
    }

    public static class DirectoryExtensions
    {
        /// <summary>
        /// Because Directory.Delete will occasionally return without having yet completed, this is required.
        /// This function deletes a directory and creates an empty directory of the same name.
        /// </summary>
        /// <param name="path">The directory to recreate.</param>
        /// <returns>True on success.</returns>
        public static bool Recreate(string path)
        {
            int timeoutCounter = 0;
            while (true)
            {
                if (Directory.Exists(path) == false)
                    break;
                if ((timeoutCounter % 10) == 0)
                    Directory.Delete(path, true);
                if (timeoutCounter > 30)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return string.Format("Failed Deleting directory {0}", path);
                    });
                    return false;
                }
                if (Directory.Exists(path) == false)
                    break;
                System.Threading.Thread.Sleep(100);
                timeoutCounter++;
            }
            timeoutCounter = 0;
            while (true)
            {
                if ((timeoutCounter % 10) == 0)
                    Directory.CreateDirectory(path);
                if (timeoutCounter > 30)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return string.Format("Failed Creating directory {0}", path);
                    });
                    return false;
                }
                if (Directory.Exists(path))
                    break;
                System.Threading.Thread.Sleep(100);
                timeoutCounter++;
            }
            return true;
        }

        /// <summary>
        /// Because Directory.Delete will occasionally return without having yet completed, this is required.
        /// This function deletes a directory and blocks till it is removed.
        /// </summary>
        /// <param name="path">The directory to recreate.</param>
        /// <returns>True on success.</returns>
        public static bool Delete(string path)
        {
            int timeoutCounter = 0;
            while (true)
            {
                if (Directory.Exists(path) == false)
                    break;
                if ((timeoutCounter % 10) == 0)
                    Directory.Delete(path, true);
                if (timeoutCounter > 30)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return string.Format("Failed Deleting directory {0}", path);
                    });
                    return false;
                }
                if (Directory.Exists(path) == false)
                    break;
                System.Threading.Thread.Sleep(100);
                timeoutCounter++;
            }
            return true;
        }
    }

    public static class IPAddressExtensions
    {
        public static bool IsSameIPAddress(this IPAddress instanceAddress, IPAddress address)
        {
            if (instanceAddress == null)
                return true;

            if (address == null)
                return true;

            return instanceAddress.Equals(address);
        }
    }
}
