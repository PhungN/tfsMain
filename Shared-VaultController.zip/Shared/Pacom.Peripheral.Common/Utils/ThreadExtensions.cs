﻿using System;
using System.Diagnostics;
using System.Threading;

namespace Pacom.Peripheral.Common
{
    public static class ThreadExtensions
    {
        public static event EventHandler<EventArgs> ForcedResetRequired;

        public static void JoinOrRestart(this Thread thread, int timeout)
        {
            if (thread.Join(timeout) == true)
                return;
#if DEBUG
            if (Debugger.IsAttached)
            {
                // A critical issue has occured. DO NOT IGNORE THIS.
                Debugger.Break();
            }

            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            if (thread.Join(timeout * 10) == true)
            {
                stopwatch.Stop();
                Logger.LogErrorMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return string.Format("Thread '{0}' finish but took {1} ms longer than the expected {2} ms timeout.", thread.Name, stopwatch.ElapsedMilliseconds, timeout);
                });

                if (Debugger.IsAttached)
                {
                    // Please investigate why it took longer and if required extend the timeout.
                    Debugger.Break();
                }
                return;
            }

            if (Debugger.IsAttached)
            {
                // Even waiting 10x the timeout didn't help. DO NOT IGNORE THIS.
                Debugger.Break();
            }
#endif
            try
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return string.Format("Thread '{0}' failed to finish in a timely manner. The controller will restart to recover into a known good state.", thread.Name);
                });
            }
            catch
            {
            }

            try
            {
                // Abort the thread so that the a thread has an opportunity to print out its stack trace.
                thread.Abort();
                Thread.Sleep(100);
            }
            catch
            {
            }

            try
            {
                ForcedResetRequired(null, new EventArgs());
            }
            catch
            {
            }
        }
    }
}
