﻿using System;
using System.IO;

namespace Pacom.Peripheral.Common.Utilities
{
    public static class CommonUtilities
    {
        public static int AdcReadingToResistanceValue(int adcReading, int adcResolution, int currentLimitingResistorValue, int pullUpResistorValue)
        {
            return (int)(((Math.Pow(2, adcResolution) * currentLimitingResistorValue) - (adcReading * pullUpResistorValue) - (adcReading * currentLimitingResistorValue)) / (adcReading - Math.Pow(2, adcResolution)));
        }

        public static bool[] CreateBoolArray(int size, bool defaulValue)
        {
            bool[] array = new bool[size];
            for (int i = 0; i < size; i++)
                array[i] = defaulValue;
            return array;
        }

        public static FirmwareVersion ReadFirmwareVersion(string fileName)
        {
            FirmwareVersion version;
            if (File.Exists(fileName))
            {
                try
                {
                    using (StreamReader streamReader = new StreamReader(fileName))
                    {
                        version = new FirmwareVersion(streamReader.ReadLine());
                        streamReader.Close();
                    }
                }
                catch
                {
                    version = new FirmwareVersion(0, 0);
                }
            }
            else
            {
                version = new FirmwareVersion(0, 0);
            }
            return version;
        }
    }
}
