﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Common.Utils
{
    public static class ExtentionMethods
    {
        /// <summary>
        /// Determines whether two sequences are equal by comparing the elements by using the default equality comparer for their type.
        /// </summary>
        /// <param name="list1"></param>
        /// <param name="list2"></param>
        /// <returns>true if the two source sequences are of equal length and their corresponding elements are equal according to the default equality comparer for their type; otherwise, false. </returns>
        public static bool SequenceEqual(this List<int> list1, List<int> list2)
        {
            if (list1.Count != list2.Count)
                return false;
            for (int i = 0; i < list1.Count; i++)
            {
                if (list1[i] != list2[i])
                    return false;
            }
            return true;

        }

        public static bool SequenceEqual(this byte[] first, byte[] second, int offsetInSecond, int length)
        {
            try
            {
                int pos1 = length - 1;
                int pos2 = offsetInSecond + length - 1;
                while (pos1 > -1)
                {
                    if (first[pos1] != second[pos2])
                        return false;
                    pos1--;
                    pos2--;
                }
                return true;
            }
            catch
            {
            }

            return false;
        }

        /// <summary>
        /// Determines whether two sequences are equal by comparing the elements by using the default equality comparer for their type.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="array1"></param>
        /// <param name="array2"></param>
        /// <returns>true if the two source sequences are of equal length and their corresponding elements are equal according to the default equality comparer for their type; otherwise, false.</returns>
        public static bool SequenceEqual<T>(this T[] array1, T[] array2)
        {
            if (array1.Length != array2.Length)
                return false;
            for (int i = 0; i < array1.Length; i++)
            {
                if (!EqualityComparer<T>.Default.Equals(array1[i], array2[i]))
                    return false;
            }
            return true;
        }


        /// <summary>
        /// Determines whether all elements of a sequence equal a value.
        /// </summary>
        /// <param name="array"></param>
        /// <param name="compareValue"></param>
        /// <returns></returns>
        public static bool All(this byte[] array, byte compareValue)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] != compareValue)
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Determines whether all elements of a sequence satisfy a condition.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="predicate"></param>
        /// <returns>true if every element of the source sequence passes the test in the specified predicate, or if the sequence is empty; otherwise, false.</returns>
        public static bool All<T>(this T[] collection, Func<T, bool> predicate)
        {
            if (collection == null || collection.Length == 0)
                return true;
            for (int i = 0; i < collection.Length; i++)
            {
                if(!predicate(collection[i]))
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Determines whether any element of a sequence satisfies a condition.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="predicate"></param>
        /// <returns>true if any elements in the source sequence pass the test in the specified predicate; otherwise, false.</returns>
        public static bool Any<T>(this T[] collection, Func<T, bool> predicate)
        {
            for (int i = 0; i < collection.Length; i++)
            {
                if (predicate(collection[i]))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Determines whether any element of a sequence satisfies a condition.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="predicate"></param>
        /// <returns>true if any elements in the source sequence pass the test in the specified predicate; otherwise, false.</returns>
        public static bool Any<T>(this List<T> collection, Func<T, bool> predicate)
        {
            for (int i = 0; i < collection.Count; i++)
            {
                if (predicate(collection[i]))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Returns the first element of the sequence that satisfies a condition or a default value if no such element is found.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="predicate"></param>
        /// <returns>default(TSource) if source is empty or if no element passes the test specified by predicate; otherwise, the first element in source that passes the test specified by predicate.</returns>
        public static T FirstOrDefault<T>(this List<T> collection, Func<T, bool> predicate)
        {
            foreach (var item in collection)
            {
                if (predicate(item))
                    return item;
            }
            return default(T);
        }

        /// <summary>
        /// Returns the first element of a sequence, or a default value if the sequence contains no elements.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <returns>default(TSource) if source is empty; otherwise, the first element in source.</returns>
        public static T FirstOrDefault<T>(this T[] collection)
        {
            if (collection.Length > 0)
                return collection[0];
            return default(T);
        }

        /// <summary>
        /// Returns the first element of the sequence that satisfies a condition or a default value if no such element is found.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="predicate"></param>
        /// <returns>default(TSource) if source is empty or if no element passes the test specified by predicate; otherwise, the first element in source that passes the test specified by predicate.</returns>
        public static T FirstOrDefault<T>(this T[] collection, Func<T, bool> predicate)
        {
            foreach (var item in collection)
            {
                if (predicate(item))
                    return item;
            }
            return default(T);
        }

        /// <summary>
        /// Returns the first element of the sequence that satisfies a condition or a default value if no such element is found.
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="collection"></param>
        /// <param name="predicate"></param>
        /// <returns>default(TSource) if source is empty or if no element passes the test specified by predicate; otherwise, the first element in source that passes the test specified by predicate.</returns>
        public static KeyValuePair<TKey, TValue> FirstOrDefault<TKey, TValue>(this Dictionary<TKey, TValue> collection, Func<KeyValuePair<TKey, TValue>, bool> predicate)
        {
            foreach (var item in collection)
            {
                if (predicate(item))
                    return item;
            }
            return default(KeyValuePair<TKey, TValue>);
        }

        /// <summary>
        /// Returns a number that represents how many elements in the specified sequence satisfy a condition.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="predicate"></param>
        /// <returns>A number that represents how many elements in the sequence satisfy the condition in the predicate function.</returns>
        public static int Count<T>(this T[] collection, Func<T, bool> predicate)
        {
            int count = 0;
            for (int i = 0; i < collection.Length; i++)
            {
                if (predicate(collection[i]))
                    count++;
            }
            return count;
        }

        /// <summary>
        /// Returns a number that represents how many elements in the specified sequence satisfy a condition.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="predicate"></param>
        /// <returns>A number that represents how many elements in the sequence satisfy the condition in the predicate function.</returns>
        public static int Count<T>(this List<T> collection, Func<T, bool> predicate)
        {
            int count = 0;
            for (int i = 0; i < collection.Count; i++)
            {
                if (predicate(collection[i]))
                    count++;
            }
            return count;
        }

        /// <summary>
        /// Returns a number that represents how many elements in the specified sequence satisfy a condition.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="predicate"></param>
        /// <returns>A number that represents how many elements in the sequence satisfy the condition in the predicate function.</returns>
        public static int Count<TKey, TValue>(this SortedList<TKey, TValue> collection, Func<KeyValuePair<TKey, TValue>, bool> predicate)
        {
            int count = 0;
            foreach (var item in collection)
            {
                if (predicate(item))
                    count++;
            }
            return count;
        }

        /// <summary>
        /// Produces the set union of two sequences by using the default equality comparer.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns>A List<T> that contains the elements from both input sequences, excluding duplicates.</returns>
        public static List<T> Union<T>(this List<T> first, List<T> second)
        {
            List<T> result = new List<T>();
            foreach (var item in first)
            {
                if (!result.Contains(item))
                    result.Add(item);
            }
            foreach (var item in second)
            {
                if (!result.Contains(item))
                    result.Add(item);
            }
            return result;
        }

        /// <summary>
        /// Produces the set union of two sequences by using the default equality comparer.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns>An array T[] that contains the elements from both input sequences, excluding duplicates.</returns>
        public static T[] Union<T>(this T[] first, T[] second)
        {
            List<T> result = new List<T>();
            foreach (var item in first)
            {
                if (!result.Contains(item))
                    result.Add(item);
            }
            foreach (var item in second)
            {
                if (!result.Contains(item))
                    result.Add(item);
            }
            return result.ToArray();
        }

        /// <summary>
        /// Produces the set intersection of two sequences by using the default equality comparer to compare values.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns>A sequence that contains the elements that form the set intersection of two sequences.</returns>
        public static List<T> Intersect<T>(this List<T> first, List<T> second)
        {
            List<T> result = new List<T>();
            foreach (var item in first)
            {
                if (second.Contains(item) && !result.Contains(item))
                {
                    result.Add(item);
                }
            }
            return result;
        }

        /// <summary>
        /// Produces the set intersection of two sequences by using the default equality comparer to compare values.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns>A sequence that contains the elements that form the set intersection of two sequences.</returns>
        public static List<T> Intersect<T>(this List<T> first, T[] second)
        {
            List<T> result = new List<T>();
            foreach (var item in second)
            {
                if (first.Contains(item) && !result.Contains(item))
                {
                    result.Add(item);
                }
            }
            return result;
        }

        /// <summary>
        /// Produces the set intersection of two sequences by using the default equality comparer to compare values.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns>A sequence that contains the elements that form the set intersection of two sequences.</returns>
        public static List<T> Intersect<T>(this T[] first, List<T> second)
        {
            List<T> result = new List<T>();
            foreach (var item in first)
            {
                if (second.Contains(item) && !result.Contains(item))
                {
                    result.Add(item);
                }
            }
            return result;
        }

        /// <summary>
        /// Produces the set difference of two sequences by using the default equality comparer to compare values.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns>A sequence that contains the set difference of the elements of two sequences.</returns>
        public static List<T> Except<T>(this List<T> first, List<T> second)
        {
            List<T> result = new List<T>();
            foreach (var item in first)
            {
                if (!second.Contains(item) && !result.Contains(item))
                    result.Add(item);
            }
            return result;
        }

        /// <summary>
        /// Creates a List<T> from an array T[]
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <returns>A List<T> that contains elements from the input sequence.</returns>
        public static List<T> ToList<T>(this T[] collection)
        {
            return new List<T>(collection);
        }

        /// <summary>
        /// Creates an array from a List<T>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <returns>An array that contains the elements from the input sequence.</returns>
        public static T[] ToArray<T>(this IList<T> collection)
        {
            T[] result = new T[collection.Count];
            for (int i = 0; i < collection.Count; i++)
                result[i] = collection[i];
            return result;
        }

        /// <summary>
        /// Determines whether a sequence contains a specified element by using a specified IEqualityComparer<T>.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="value"></param>
        /// <returns>true if the source sequence contains an element that has the specified value; otherwise, false.</returns>
        public static bool Contains<T>(this T[] collection, T value)
        {
            for (int i = 0; i < collection.Length; i++)
            {
                if (EqualityComparer<T>.Default.Equals(collection[i], value))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Returns distinct elements from a sequence by using the default equality comparer to compare values.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <returns>A List<T> that contains distinct elements from the source sequence.</returns>
        public static List<T> Distinct<T>(this List<T> collection)
        {
            List<T> result = new List<T>();
            foreach (var item in collection)
            {
                if (!result.Contains(item))
                    result.Add(item);
            }
            return result;
        }

        /// <summary>
        /// Invokes a transform function on each element of a generic sequence and returns the maximum resulting value.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="source"></param>
        /// <param name="selector"></param>
        /// <returns>The maximum value in the sequence.</returns>
        public static TResult Max<T, TResult>(this T[] collection, Func<T, TResult> selector) where TResult : IComparable
        {
            TResult max = selector(collection[0]);
            for (int i = 1; i < collection.Length; i++)
            {
                TResult current = selector(collection[i]);
                if (current.CompareTo(max) > 0)
                    max = current;
            }
            return max;
        }

        /// <summary>
        /// Invokes a transform function on each element of a generic sequence and returns the maximum resulting value.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="source"></param>
        /// <param name="selector"></param>
        /// <returns>The maximum value in the sequence.</returns>
        public static TResult Max<T, TResult>(this List<T> collection, Func<T, TResult> selector) where TResult : IComparable
        {
            TResult max = selector(collection[0]);
            for (int i = 1; i < collection.Count; i++)
            {
                TResult current = selector(collection[i]);
                if (current.CompareTo(max) > 0)
                    max = current;
            }
            return max;
        }

        /// <summary>
        /// Invokes a transform function on each element of a generic sequence and returns the minimum resulting value.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="source"></param>
        /// <param name="selector"></param>
        /// <returns>The minimum value in the sequence.</returns>
        public static TResult Min<T, TResult>(this T[] collection, Func<T, TResult> selector) where TResult : IComparable
        {
            TResult min = selector(collection[0]);
            for (int i = 1; i < collection.Length; i++)
            {
                TResult current = selector(collection[i]);
                if (current.CompareTo(min) < 0)
                    min = current;
            }
            return min;
        }

        /// <summary>
        /// Invokes a transform function on each element of a generic sequence and returns the minimum resulting value.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="source"></param>
        /// <param name="selector"></param>
        /// <returns>The minimum value in the sequence.</returns>
        public static TResult Min<T, TResult>(this List<T> collection, Func<T, TResult> selector) where TResult : IComparable
        {
            TResult min = selector(collection[0]);
            for (int i = 1; i < collection.Count; i++)
            {
                TResult current = selector(collection[i]);
                if (current.CompareTo(min) < 0)
                    min = current;
            }
            return min;
        }

        /// <summary>
        /// Returns a specified number of contiguous elements from the start of a sequence.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="count"></param>
        /// <returns>An array T[] that contains the specified number of elements from the start of the input sequence.</returns>
        public static T[] Take<T>(this T[] collection, int count)
        {
            if (count > collection.Length)
                count = collection.Length;
            T[] copy = new T[count];
            for (int i = 0; i < count; i++)
                copy[i] = collection[i];
            return copy;
        }

        /// <summary>
        /// Returns a specified number of contiguous elements from the offset of a sequence.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="count"></param>
        /// <returns>An array T[] that contains the specified number of elements from the offset of the input sequence.</returns>
        public static T[] Take<T>(this T[] collection, int count, int offset)
        {
            if (count + offset > collection.Length)
                count = collection.Length - offset;
            if (count <= 0)
                return null;
            T[] copy = new T[count];
            for (int i = 0; i < count; i++)
                copy[i] = collection[i + offset];
            return copy;
        }

        /// <summary>
        /// Returns a specified number of contiguous elements from the start of a sequence.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="count"></param>
        /// <returns>An List<T> that contains the specified number of elements from the start of the input sequence.</returns>
        public static List<T> Take<T>(this List<T> collection, int count)
        {
            if (count > collection.Count)
                count = collection.Count;
            return count > 0 ? collection.GetRange(0, count) : null;
        }

        /// <summary>
        /// Returns a specified number of contiguous elements from the offset of a sequence.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="count"></param>
        /// <returns>A List<T> that contains the specified number of elements from the offset of the input sequence.</returns>
        public static List<T> Take<T>(this List<T> collection, int count, int offset)
        {
            if (count + offset > collection.Count)
                count = collection.Count - offset;
            return count > 0 ? collection.GetRange(offset, count) : null;
        }

        /// <summary>
        /// Returns all the keys from the dictionary
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="collection"></param>
        /// <returns>A List<Key> that contains all the keys in the dictionary </returns>
        public static List<TKey> GetKeys<TKey, TValue>(this Dictionary<TKey, TValue> collection)
        {
            return new List<TKey>(collection.Keys);
        }

        /// <summary>
        /// Returns all the values from the dictionary
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="collection"></param>
        /// <returns>A List<Key> that contains all the values in the dictionary </returns>
        public static List<TValue> GetValues<TKey, TValue>(this Dictionary<TKey, TValue> collection)
        {
            return new List<TValue>(collection.Values);
        }

        /// <summary>
        /// Returns all the keys from the collection
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="collection"></param>
        /// <returns>A List<Key> that contains all the keys in the collection </returns>
        public static List<TKey> GetKeys<TKey, TValue>(this SortedList<TKey, TValue> collection)
        {
            return new List<TKey>(collection.Keys);
        }

        /// <summary>
        /// Returns all the values from the collection
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="collection"></param>
        /// <returns>A List<Key> that contains all the values in the collection </returns>
        public static List<TValue> GetValues<TKey, TValue>(this SortedList<TKey, TValue> collection)
        {
            return new List<TValue>(collection.Values);
        }

        /// <summary>
        /// Returns all the items in the sequence satisfy a condition.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="predicate"></param>
        /// <returns>A List<T> that contains elements in the sequence satisfy the condition in the predicate function.</returns>
        public static List<T> Select<T>(this List<T> collection, Func<T, bool> predicate)
        {
            List<T> result = new List<T>();
            foreach (var item in collection)
            {
                if (predicate(item))
                    result.Add(item);
            }
            return result;
        }

        /// <summary>
        /// Returns all the items in the sequence satisfy a condition.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="predicate"></param>
        /// <returns>An array T[] that contains elements in the sequence satisfy the condition in the predicate function.</returns>
        public static T[] Select<T>(this T[] collection, Func<T, bool> predicate)
        {
            List<T> result = new List<T>();
            foreach (var item in collection)
            {
                if (predicate(item))
                    result.Add(item);
            }
            return result.ToArray();
        }

        public static byte[] ToByteArray(this bool[] bools)
        {
            int len = bools.Length;
            int bytesLength = len >> 3;
            if ((len & 0x07) != 0) ++bytesLength;
            byte[] bytes = new byte[bytesLength];
            for (int i = 0; i < bools.Length; i++)
            {
                if (bools[i])
                    bytes[i >> 3] |= (byte)(1 << (i & 0x07));
            }
            return bytes;
        }

        public static bool[] ToBooleanArray(this byte[] bytes)
        {
            return ToBooleanArray(bytes, 0, bytes.Length);
        }

        public static bool[] ToBooleanArray(this byte[] bytes, int offset, int count)
        {
            bool[] bools = new bool[count * 8];
            for (int i = 0; i < count; i++)
            {
                byte b = bytes[i+offset];
                for (int j = 0; j < 8; j++)
                {
                    if ((b & 1) == 1)
                        bools[(i << 3) + j] = true;
                    b >>= 1;
                }
            }
            return bools;
        }
    }
}
