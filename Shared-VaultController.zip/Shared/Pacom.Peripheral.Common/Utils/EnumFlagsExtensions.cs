﻿using System;
using System.Text;
using System.Reflection;
using System.Globalization;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Helper extensions for EnumFlags manipulation
    /// </summary>
    public static class EnumFlagsExtensions
    {
        public static bool Has<T>(this T source, T bitTest) where T : struct, IConvertible
        {
            EnumValue enumValue = get(source, bitTest);
            return (enumValue.Flags & enumValue.Bits) == enumValue.Bits;
        }

        public static bool DoesNotHave<T>(this T source, T bitTest) where T : struct, IConvertible
        {
            return source.Has<T>(bitTest) == false;
        }

        public static T SetFlags<T>(this T source, T bitsSet) where T : struct, IConvertible
        {
            EnumValue enumValue = get(source, bitsSet);
            return (T)Enum.Parse(typeof(T), (enumValue.Flags | enumValue.Bits).ToString(), true);
        }

        public static T ClearFlags<T>(this T source, T bitsClear) where T : struct, IConvertible
        {
            EnumValue enumValue = get(source, bitsClear);
            return (T)Enum.Parse(typeof(T), (enumValue.Flags & ~enumValue.Bits).ToString(), true);
        }

        public static void Serialize<T>(this T source, byte[] data, int offset) where T : struct, IConvertible
        {
            if (typeof(T).IsEnum == false)
                throw new ArgumentException("Input type must be an enum.");
            int flags = source.ToInt32(CultureInfo.InvariantCulture.NumberFormat);
            data[offset++] = (byte)((flags >> 24) & 0xFF);
            data[offset++] = (byte)((flags >> 16) & 0xFF);
            data[offset++] = (byte)((flags >> 8) & 0xFF);
            data[offset++] = (byte)((flags) & 0xFF);
        }

        public static T Deserialize<T>(byte[] data, int offset) where T : struct, IConvertible
        {
            if (typeof(T).IsEnum == false)
                throw new ArgumentException("Input type must be an enum.");
            int flags = (data[offset] << 24) + (data[offset + 1] << 16) + (data[offset + 2] << 8) + (data[offset + 3]);
            return (T)Enum.Parse(typeof(T), flags.ToString(), true);
        }

        public static string GetString<T>(this T source) where T : struct, IConvertible
        {
            StringBuilder sb = new StringBuilder(0);
            FieldInfo[] fi = typeof(T).GetFields(BindingFlags.Static | BindingFlags.Public);
            for (int i = 0; i < fi.Length; i++)
            {
                int flagValue = (int)fi[i].GetValue(null);
                if (flagValue == 0)
                    continue;
                T flagItemToCheck = (T)fi[i].GetValue(null);
                if (source.Has(flagItemToCheck) == true)
                {
#if DEBUG
                    sb.AppendFormat("{0},", flagItemToCheck.ToString());
#else
                    sb.AppendFormat("{0},",flagValue.ToString());
#endif
                }
            }
            return sb.ToString().TrimEnd(',');
        }

        private static EnumValue get<T>(T source, T bitTest) where T : struct, IConvertible
        {
            if (typeof(T).IsEnum == false)
                throw new ArgumentException("Input type must be an enum.");
            return new EnumValue(source.ToInt32(CultureInfo.InvariantCulture.NumberFormat), bitTest.ToInt32(CultureInfo.InvariantCulture.NumberFormat));
        }

        private struct EnumValue
        {
            public int Flags;
            public int Bits;
            public EnumValue(int flags, int bits)
            {
                Flags = flags;
                Bits = bits;
            }
        }
    }
}
