﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Reflection;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// List of created singletons
    /// </summary>
    public class SingletonList : IDisposable
    {
        public static event EventHandler<EventArgs> ForcedResetRequired;

        private IDictionary<Type, object> container = null;
        private Thread disposeMonitoringThread = null;
        private readonly AutoResetEvent releaseDisposeMonitoringThread = new AutoResetEvent(false);
        private string releasingType = string.Empty;

        public SingletonList()
        {
            container = new Dictionary<Type, object>();
        }

        /// <summary>
        /// Create and register singleton without parameters
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public T CreateInstanceAndRegister<T>()
        {
            return CreateInstanceAndRegister<T>(null);
        }

        /// <summary>
        /// Create and register singleton with parameters
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public T CreateInstanceAndRegister<T>(params object[] parameters)
        {
            if (Closing)
                throw new Exception("Reset Button Pressed");

            if (container.ContainsKey(typeof(T)) == false)
            {
                // Check class constrains
                PropertyInfo propertyInstance = typeof(T).GetProperty("Instance", BindingFlags.Public | BindingFlags.Static);
                if (propertyInstance == null)
                    throw new ArgumentException(string.Format("SINGLETON: Unable to find Instance property. [{0}]", typeof(T).Name), "type");
                MethodInfo methodCreateInstance = typeof(T).GetMethod("CreateInstance", BindingFlags.Public | BindingFlags.Static);
                if (methodCreateInstance == null)
                    throw new ArgumentException(string.Format("SINGLETON: Unable to find CreateInstance method. [{0}]", typeof(T).Name), "type");
                Type[] interfaces = typeof(T).GetInterfaces();
                if (interfaces.Contains(typeof(IDisposable)) == false)
                    throw new ArgumentException(string.Format("SINGLETON: Type must implement IDisposable interface [{0}]", typeof(T).Name), "type");

                Logger.LogErrorMessage(LoggerClassPrefixes.SingletonList, () =>
                {
                    return string.Format("Starting {0}", typeof(T));
                });
                // Create instance via CreateInstance method
                T value = (T)methodCreateInstance.Invoke(typeof(T), parameters);
                container.Add(typeof(T), value);
                return value;
            }
            else
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.SingletonList, () =>
                {
                    return "Attempt was made to create another instance of the same type!";
                });
                return Instance<T>();
            }
        }

        /// <summary>
        /// Get an instance of singleton by type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public T Instance<T>()
        {
            if (container.ContainsKey(typeof(T)) == true)
            {
                PropertyInfo propertyInstance = container[typeof(T)].GetType().GetProperty("Instance", BindingFlags.Public | BindingFlags.Static);
                return (T)propertyInstance.GetValue(container[typeof(T)], null);
            }
            else
                return default(T);
        }

        public static bool Closing
        {
            get;
            set;
        }

        private void freeInstances()
        {
            List<object> instances = new List<object>();
            foreach (var value in container.Values)
                instances.Add(value);
            for (int i = container.Count - 1; i >= 0; i--)
            {
                string instanceType = instances[i].GetType().ToString();
                try
                {
                    releasingType = instanceType;
                    Logger.LogErrorMessage(LoggerClassPrefixes.SingletonList, () =>
                    {
                        return string.Format("Disposing {0}", instanceType);
                    });
                    IDisposable instance = (IDisposable)instances[i];
                    instance.Dispose();
                    releasingType = string.Empty;
                    releaseDisposeMonitoringThread.Set();
                }
                catch (Exception ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.SingletonList, () =>
                    {
                        return string.Format("Error while disposing object of type {0}: {1}", instanceType, ex.Message);
                    });
                }
            }
            container.Clear();
            container = null;
        }
        
        private void startDisposeMonitoringThread()
        {
            if (disposeMonitoringThread != null)
                stopDisposeMonitoringThread();

            disposeMonitoringThread = new Thread(new ThreadStart(disposeMonitoringThreadMethod));
            disposeMonitoringThread.Name = "SingletonList Dispose Monitoring Thread";
            disposeMonitoringThread.IsBackground = true;
            disposeMonitoringThread.Priority = ThreadPriority.AboveNormal;
            disposeMonitoringThread.Start();
        }

        private void stopDisposeMonitoringThread()
        {
            releaseDisposeMonitoringThread.Set();
            try
            {
                if (disposeMonitoringThread != null)
                {
                    disposeMonitoringThread.JoinOrRestart(20000);
                }
                disposeMonitoringThread = null;
            }
            catch
            {
            }
        }

        private const int initialNumberOfSecondsToReboot = 6;

        private void disposeMonitoringThreadMethod()
        {
            try
            {
                int numberOfSecondsToReboot = initialNumberOfSecondsToReboot;
                while (disposed == false)
                {
                    if (releaseDisposeMonitoringThread.WaitOne(1000, false) == true)
                    {
                        if (disposed == true)
                            return;

                        numberOfSecondsToReboot = initialNumberOfSecondsToReboot;
                    }
                    else
                    {
                        if (disposed == true)
                            return;
                        if (numberOfSecondsToReboot <= 0)
                        {
                            if (string.IsNullOrEmpty(releasingType) == false)
                            {                                
                                Logger.LogErrorMessage(LoggerClassPrefixes.SingletonList, () =>
                                {
                                    return string.Format("*** Disposing {0} failed within {1} seconds. ***", releasingType, initialNumberOfSecondsToReboot);
                                });
                            }
                            if (ForcedResetRequired != null)
                                ForcedResetRequired(null, new EventArgs());
                            break;
                        }
                        numberOfSecondsToReboot--;
                    }
                }
            }
            catch
            {
            }
            finally
            {
                disposeMonitoringThread = null;
            }
        }
        
        #region IDisposable Members

        bool disposed = false;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposed == true)
                return;

            if (disposing == true)
            {
                startDisposeMonitoringThread();
                // Free any other managed objects here.
                freeInstances();
            }

            // Free any unmanaged objects here.            
            // Set large fields to null.
            disposed = true;
            stopDisposeMonitoringThread();
            releaseDisposeMonitoringThread.Close();
        }
        
        /// <summary>
        /// Use C# destructor syntax for finalization code.
        /// </summary>
        ~SingletonList()
        {
            Dispose(false);
        }

        #endregion

    }
}
