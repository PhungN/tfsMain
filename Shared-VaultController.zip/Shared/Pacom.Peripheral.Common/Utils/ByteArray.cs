﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common.Utils
{
    public static class ByteArray
    {
        public static byte[] Combine(params byte[][] arrays)
        {
            byte[] combinedArray = new byte[GetLength(arrays)];
            int offset = 0;
            foreach (byte[] array in arrays)
            {
                if (array != null)
                {
                    Buffer.BlockCopy(array, 0, combinedArray, offset, array.Length);
                    offset += array.Length;
                }
            }
            return combinedArray;
        }

        public static int GetLength(params byte[][] arrays)
        {
            int len = 0;
            foreach (byte[] array in arrays)
            {
                if (array != null)
                    len += array.Length;
            }
            return len;
        }

        public static UInt32 ToUInt32(this byte[] source, int offset)
        {
            if (source == null || offset > source.Length - 4)
                return 0;
            return (UInt32)((source[offset] << 24) | (source[offset + 1] << 16) | (source[offset + 2] << 8) | (source[offset + 3]));
        }
        
    }
}
