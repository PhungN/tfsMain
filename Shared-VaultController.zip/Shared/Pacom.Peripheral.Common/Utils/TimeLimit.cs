﻿using System;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// Time limit class used for measuring time differences.
    /// </summary>
    public class TimeLimit
    {
        private int startTicks;
                
        /// <summary>
        /// Start new time limit
        /// </summary>
        public TimeLimit()
        {
            startTicks = Environment.TickCount;
            ExpectedDuration = 0;
        }

        /// <summary>
        /// Start new time limit setting the expected duration and initial condition.
        /// </summary>
        /// <param name="expectedDuration">Time storage for convienience only.</param>
        /// <param name="expired">If true, IsTimeUp will return true immediately when the expectedDuration is passed in as a parameter.</param>
        public TimeLimit(int expectedDuration, bool expired)
        {
            ExpectedDuration = expectedDuration;
            if (expired == true)
                startTicks = Environment.TickCount - expectedDuration;
            else
                startTicks = Environment.TickCount;
        }

        /// <summary>
        /// Reset time limit
        /// </summary>
        public void Reset()
        {
            startTicks = Environment.TickCount;
        }

        /// <summary>
        /// Check if time provided in milliseconds has elapsed.
        /// </summary>
        /// <param name="time"></param>
        /// <returns>True if time has elapsed</returns>
        public bool IsTimeUp(int time)
        {
            uint elapsedTime;
            return IsTimeUp(time, out elapsedTime);
        }

        /// <summary>
        /// Check if time provided in "type" units has elapsed.
        /// </summary>
        /// <param name="time"></param>
        /// <param name="elapsedTime">Elapsed time in milliseconds</param>
        /// <returns>True if time has elapsed</returns>
        public bool IsTimeUp(int time, out uint elapsedTime)
        {
            // The Environment.TickCount property is derived from the system timer and is 
            // stored as a 32-bit signed integer. Consequently, if the system runs continuously, 
            // TickCount will increment from zero to Int32.MaxValue for approximately 24.9 days, 
            // then jump to Int32.MinValue, which is a negative number, then increment back to zero during the next 24.9 days.

            elapsedTime = (uint)Environment.TickCount - (uint)startTicks;
            return elapsedTime > time;
        }

        /// <summary>
        /// The amount of time that has elapsed since the constructor was called or Reset was called (whichever is more recent).
        /// </summary>
        public int ElapsedTime
        {
            get
            {
                return (int)((uint)Environment.TickCount - (uint)startTicks);
            }
        }

        /// <summary>
        /// Not used internally. Provided for convienient storage.
        /// </summary>
        public int ExpectedDuration
        {
            get;
            set;
        }
    }
}
