﻿using System;
using System.Collections.Generic;
using System.Net;
using System.IO;
using Microsoft.Win32;
using System.Text;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class provides a central repository for configuration.
    /// </summary>
    public static class ConfigurationManager
    {
        /// <summary>
        /// Triggered when the configuration changes.
        /// </summary>
        public static event EventHandler<EventArgs> ConfigurationChanged;

        private static Dictionary<string, object> configuration = new Dictionary<string, object>();
        private static DataFlashConfig dataFlashConfig = null;
        private static INetworkAdapter networkAdapter;

        /// <summary>
        /// Save time when the configuration manager started.
        /// Use only the Ticks property as the time is not set on the device.
        /// </summary>
        private readonly static DateTime managerStartDateTime = new DateTime(DateTime.Now.Ticks);

        /// <summary>
        /// Save time when the configuration manager started.
        /// Use only the Ticks property as the time is not set on the device.
        /// </summary>
        public static DateTime StartTime
        {
            get
            {
                return managerStartDateTime;
            }
        }

        /// <summary>
        /// Reads the config from all external sources and compiles a dictionary of all of the
        /// configuration.
        /// </summary>
        /// <param name="dataFlash">An instance of the DataFlash class to provide access to the configuration stored in the data flash.</param>
        /// <param name="localNetworkAdapter">An instance of the NetworkAdapter class to allow renewing of an IP address without a restart.</param>
        /// <returns>True on success.</returns>
        public static bool Initialize(IDataFlash dataFlash, INetworkAdapter localNetworkAdapter)
        {
            networkAdapter = localNetworkAdapter;

            // Put together a default configuration
            configuration.Add("PowerSupply.Type", (int)PowerSupplyType.None);
            configuration.Add("Connection.Tcp", new TcpIPConnectionConfiguration(true, new IPEndPoint(IPAddress.Parse("10.1.1.1"), 3435), 0));
            configuration.Add("CurrentConnection.Tcp", new TcpIPConnectionConfiguration(true, new IPEndPoint(IPAddress.Parse("0.0.0.0"), 0), 0));
            configuration.Add("Connection.Serial", new SerialConnectionConfiguration(true, 38400));
            configuration.Add("IPAddress", IPAddress.Parse("10.1.1.3"));
            configuration.Add("UseDHCPServer", false);
            configuration.Add("SerialNumber", "037G-1224-000000");
            configuration.Add("SerialConnectionValid", false);
            configuration.Add("TcpIPConnectionValid", false);
            configuration.Add("UseAutoDiscovery", false);
            dataFlashConfig = new DataFlashConfig(dataFlash);
            if (dataFlashConfig.MacAddress.Length == 6)
            {
                configuration.Add("MACAddress", 
                    String.Format("{0}:{1}:{2}:{3}:{4}:{5}",
                    dataFlashConfig.MacAddress[0].ToString("X").PadLeft(2, '0'),
                    dataFlashConfig.MacAddress[1].ToString("X").PadLeft(2, '0'),
                    dataFlashConfig.MacAddress[2].ToString("X").PadLeft(2, '0'),
                    dataFlashConfig.MacAddress[3].ToString("X").PadLeft(2, '0'),
                    dataFlashConfig.MacAddress[4].ToString("X").PadLeft(2, '0'),
                    dataFlashConfig.MacAddress[5].ToString("X").PadLeft(2, '0')));
            }            

            FirmwareVersion applicationVersion = new FirmwareVersion(1, 0);
            int buildNumber = 0;
            try
            {
                using (StreamReader streamReader = new StreamReader(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetCallingAssembly().GetName().CodeBase) + "\\Version.txt"))
                {
                    // Read application version
                    applicationVersion = new FirmwareVersion(streamReader.ReadLine());

                    // Read Build number - second line
                    if (streamReader.Peek() >= 0)
                    {
                        string buildString = streamReader.ReadLine();

                        Logger.LogMessage(LoggingLevel.Debug, "Build version: " + buildString);

                        if (buildString.Substring(0, 5).ToLower() == "build")
                        {
                            buildString = buildString.Substring(5);
                            try
                            {
                                buildNumber = int.Parse(buildString.Trim());
                            }
                            catch
                            {
                            }
                        }
                    }
                    streamReader.Close();
                }
            }
            catch
            {
            }
            configuration.Add("ApplicationVersion", applicationVersion.ToString());
            configuration.Add("BuildNumber", (int)buildNumber);
            configuration.Add("BootloaderVersion", "01.00");
            FirmwareVersion osVersion = new FirmwareVersion(Environment.OSVersion.Version.Major, Environment.OSVersion.Version.Minor);
            configuration.Add("OSVersion", osVersion.ToString());
            configuration.Add("DeviceLoopOffsetForIP", (int)0);
            configuration.Add("RunningImage", (int)BootImage.ImageA);
            configuration.Add("LoggingLevel", (int)LoggingLevel.Critical);

            configuration.Add("DeviceLoopID", (int)1);
            configuration.Add("Tamper.HitCount", (int)3);
            for (int i = 0; i < 16; i++)
            {
                configuration.Add("Input." + i + ".Configuration", new InputPointConfiguration(false, 3, ResistorTolerance.TwelveAndAHalfPercent, 5000, 10000, 5));
            }
            for (int i = 0; i < 8; i++)
            {
                configuration.Add("InputCard.0.Input." + i + ".Configuration", new InputPointConfiguration(false, 3, ResistorTolerance.TwelveAndAHalfPercent, 5000, 10000, 5));
                configuration.Add("InputCard.1.Input." + i + ".Configuration", new InputPointConfiguration(false, 3, ResistorTolerance.TwelveAndAHalfPercent, 5000, 10000, 5));
            }

            configuration.Add("ExpansionCard.0.Type", (int)ExpansionCardType.None);
            configuration.Add("ExpansionCard.1.Type", (int)ExpansionCardType.None);

            configuration.Add("WebServerEnabled", false);
            configuration.Add("WebServerPort", 80);
            configuration.Add("WebServerPassword", "!@#$%^&*()");

            // Read bootloader configuration values
            dataFlashConfig = new DataFlashConfig(dataFlash);

            // Read the configuration from the config files
            updateConfigFile(false);

            return true;
        }

        /// <summary>
        /// This method is called to update the configuration from the .ini files after an event
        /// such as USB disconnection has occurred, which may have updated the .ini files.
        /// </summary>
        public static void UpdateConfigFile()
        {
            updateConfigFile(true);
        }

        private static void updateConfigFile(bool externalCall)
        {
            bool changed = false;

            try
            {
                // We may have user config file.
                // Check config file integrity. Read all lines from the config file.
                if (File.Exists("\\PublicRegion\\Config.ini"))
                {
                    using (StreamReader sr = new StreamReader("\\PublicRegion\\Config.ini"))
                    {
                        while (sr.Peek() != -1)
                            sr.ReadLine();
                    }
                }

                // Check if the file is empty
                FileInfo fi = new FileInfo("\\PublicRegion\\Config.ini");                                
                              
                // If the Config.ini was deleted or empty, replace configuration files with their defaults
                if (File.Exists("\\PublicRegion\\Config.ini") == false || fi.Length == 0)
                {
                    changed = true;
                    File.Copy("\\RestrictedRegion\\DefaultConfig\\Config.ini", "\\PublicRegion\\Config.ini", true);
                    File.Copy("\\RestrictedRegion\\DefaultConfig\\Config.ini", "\\RestrictedRegion\\Config.ini", true);
                    File.Copy("\\RestrictedRegion\\DefaultConfig\\AdditionalConfig.ini", "\\RestrictedRegion\\AdditionalConfig.ini", true);
                }
                
                // If the user edited config file has changed, incorporate the changes
                if (File.GetLastWriteTime("\\PublicRegion\\Config.ini") != File.GetLastWriteTime("\\RestrictedRegion\\Config.ini"))
                {
                    changed = true;                
                    File.Copy("\\PublicRegion\\Config.ini", "\\RestrictedRegion\\Config.ini", true);                
                }
            }
            catch
            {
                Logger.LogMessage(LoggingLevel.Debug, "Public region is corrupted.");
            }

            // We only need to proceed if we are called from Initialize or if the config file has changed.
            if (changed || externalCall == false)
            {
                bool ipDetailsChanged = false;
                ConfigFile configFile = new ConfigFile();
                AdditionalConfigFile additionalConfigFile = new AdditionalConfigFile();

                // As the IP details and the logging level can be changed from the boot loader, 
                // need to check on boot who has the most recent change. The assumption is that if the 
                // config file hasn't changed since the last boot, the boot loader has the most 
                // up to date configuration, otherwise the config file does.
                if (changed)
                {
                    bool updateOfDataFlashRequired = false;
                    if (dataFlashConfig.IPAddress.Equals(configFile.IPAddress) == false)
                    {
                        dataFlashConfig.IPAddress = configFile.IPAddress;
                        updateOfDataFlashRequired = true;
                        ipDetailsChanged = true;
                    }
                    if (dataFlashConfig.SubnetMask.Equals(configFile.SubnetMask) == false)
                    {
                        dataFlashConfig.SubnetMask = configFile.SubnetMask;
                        updateOfDataFlashRequired = true;
                        ipDetailsChanged = true;
                    }
                    if (dataFlashConfig.DnsServer.Equals(configFile.DnsServer) == false)
                    {
                        dataFlashConfig.DnsServer = configFile.DnsServer;
                        updateOfDataFlashRequired = true;
                        ipDetailsChanged = true;
                    }
                    if (dataFlashConfig.Gateway.Equals(configFile.DefaultGateway) == false)
                    {
                        dataFlashConfig.Gateway = configFile.DefaultGateway;
                        updateOfDataFlashRequired = true;
                        ipDetailsChanged = true;
                    }
                    if (dataFlashConfig.DhcpEnabled != configFile.UseDhcpServer)
                    {
                        dataFlashConfig.DhcpEnabled = configFile.UseDhcpServer;
                        updateOfDataFlashRequired = true;
                        ipDetailsChanged = true;
                    }
                    if (dataFlashConfig.LoggingLevel != configFile.LoggingLevel)
                    {
                        dataFlashConfig.LoggingLevel = configFile.LoggingLevel;
                        updateOfDataFlashRequired = true;
                    }

                    if (updateOfDataFlashRequired)
                        dataFlashConfig.Update();
                }
                else if (externalCall == false)
                {
                    bool updateOfConfigFileRequired = false;
                    if (dataFlashConfig.IPAddress.Equals(configFile.IPAddress) == false)
                    {
                        configFile.IPAddress = dataFlashConfig.IPAddress;
                        updateOfConfigFileRequired = true;
                        ipDetailsChanged = true;
                    }
                    if (dataFlashConfig.SubnetMask.Equals(configFile.SubnetMask) == false)
                    {
                        configFile.SubnetMask = dataFlashConfig.SubnetMask;
                        updateOfConfigFileRequired = true;
                        ipDetailsChanged = true;
                    }
                    if (dataFlashConfig.DnsServer.Equals(configFile.DnsServer) == false)
                    {
                        configFile.DnsServer = dataFlashConfig.DnsServer;
                        updateOfConfigFileRequired = true;
                        ipDetailsChanged = true;
                    }
                    if (dataFlashConfig.Gateway.Equals(configFile.DefaultGateway) == false)
                    {
                        configFile.DefaultGateway = dataFlashConfig.Gateway;
                        updateOfConfigFileRequired = true;
                        ipDetailsChanged = true;
                    }
                    if (dataFlashConfig.DhcpEnabled != configFile.UseDhcpServer)
                    {
                        configFile.UseDhcpServer = dataFlashConfig.DhcpEnabled;
                        updateOfConfigFileRequired = true;
                        ipDetailsChanged = true;
                    }
                    if (dataFlashConfig.LoggingLevel != configFile.LoggingLevel)
                    {
                        configFile.LoggingLevel = dataFlashConfig.LoggingLevel;
                        updateOfConfigFileRequired = true;
                    }

                    if (updateOfConfigFileRequired)
                        configFile.Update();
                }

                if (ipDetailsChanged)
                    updateIPAddress();


                lock (configuration)
                {
                    configuration.Remove("PowerSupply.Type");
                    configuration.Add("PowerSupply.Type", (int)configFile.PowerSupplyType);

                    configuration.Remove("UseAutoDiscovery");
                    configuration.Remove("Connection.Tcp");
                    if (configFile.UseAutoDiscovery)
                    {
                        configuration.Add("Connection.Tcp", new TcpIPConnectionConfiguration(configFile.UseTcpIP, new IPEndPoint(IPAddress.Any, configFile.ControllerPortNumber), configFile.AutoDiscoveryControllerNumber));
                        configuration.Add("UseAutoDiscovery", true);
                    }
                    else
                    {
                        configuration.Add("Connection.Tcp", new TcpIPConnectionConfiguration(configFile.UseTcpIP, new IPEndPoint(configFile.ControllerIPAddress, configFile.ControllerPortNumber), configFile.AutoDiscoveryControllerNumber));
                        configuration.Add("UseAutoDiscovery", false);
                    }

                    configuration.Remove("Connection.Serial");
                    configuration.Add("Connection.Serial", new SerialConnectionConfiguration(configFile.UseDeviceLoop, additionalConfigFile.DefaultBaudRate));

                    configuration.Remove("IPAddress");
                    configuration.Add("IPAddress", configFile.IPAddress);

                    configuration.Remove("UseDHCPServer");
                    configuration.Add("UseDHCPServer", configFile.UseDhcpServer);

                    configuration.Remove("BootloaderVersion");
                    configuration.Add("BootloaderVersion", dataFlashConfig.BootloaderVersion.ToString());

                    configuration.Remove("DeviceLoopOffsetForIP");
                    configuration.Add("DeviceLoopOffsetForIP", configFile.DeviceAddressOffset);

                    configuration.Remove("RunningImage");
                    configuration.Add("RunningImage", (int)dataFlashConfig.BootImage);

                    configuration.Remove("LoggingLevel");
                    configuration.Add("LoggingLevel", (int)configFile.LoggingLevel);

                    configuration.Remove("WebServerEnabled");
                    configuration.Add("WebServerEnabled", (bool)configFile.WebServerEnabled);

                    configuration.Remove("WebServerPort");
                    configuration.Add("WebServerPort", (int)configFile.WebServerPort);

                    configuration.Remove("WebServerPassword");
                    configuration.Add("WebServerPassword", configFile.WebServerPassword);

                    logConfiguration();
                }
                MarkAsDirty();
            }
        }

        private static void logConfiguration()
        {
            Logger.LogMessage(LoggingLevel.Debug, "Updating Configuration:");
            foreach (KeyValuePair<string, object> kvp in configuration)
            {
                if (kvp.Key.ToLower().Contains("password"))
                {
                    Logger.LogMessage(LoggingLevel.Debug, "  " + kvp.Key + " - ***********");
                }
                else
                {
                    Logger.LogMessage(LoggingLevel.Debug, "  " + kvp.Key + " - " + kvp.Value.ToString());
                }                
            }
        }

        /// <summary>
        /// Update IP configuration in Win CE registry for the driver to read.
        /// </summary>
        private static void updateIPAddress()
        {
            RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("Comm\\VMINI1\\Parms\\TcpIp", true);
            if (registryKey != null)
            {
                // Only valid when KITL is used
                registryKey.SetValue("IpAddress", dataFlashConfig.IPAddress.ToString());
                registryKey.SetValue("Subnetmask", dataFlashConfig.SubnetMask.ToString());
                registryKey.SetValue("DefaultGateway", dataFlashConfig.Gateway.ToString());
                registryKey.SetValue("DNS", dataFlashConfig.DnsServer.ToString());
                if (dataFlashConfig.DhcpEnabled)
                    registryKey.SetValue("EnableDHCP", 1);
                else
                    registryKey.SetValue("EnableDHCP", 0);
                registryKey.Close();
            }

            registryKey = Registry.LocalMachine.OpenSubKey("Comm\\EMACB1\\Parms\\TcpIp", true);
            registryKey.SetValue("IpAddress", dataFlashConfig.IPAddress.ToString());
            registryKey.SetValue("Subnetmask", dataFlashConfig.SubnetMask.ToString());
            registryKey.SetValue("DefaultGateway", dataFlashConfig.Gateway.ToString());
            registryKey.SetValue("DNS", dataFlashConfig.DnsServer.ToString());
            if (dataFlashConfig.DhcpEnabled)
                registryKey.SetValue("EnableDHCP", 1);
            else
                registryKey.SetValue("EnableDHCP", 0);
            registryKey.Close();

            networkAdapter.RebindAdapter();
        }

        /// <summary>
        /// Retrieve the value of a configuration item.
        /// </summary>
        /// <param name="configurationItemName">The name of the configuration item to retrieve.</param>
        /// <param name="configurationItemValue">Returns the value of the configuration item in this parameter.</param>
        /// <returns>True on success.</returns>
        public static bool GetConfiguration(string configurationItemName, out bool configurationItemValue)
        {
            lock (configuration)
            {
                object configurationItem;
                bool success = configuration.TryGetValue(configurationItemName, out configurationItem);
                if (success)
                {
                    try
                    {
                        configurationItemValue = (bool)configurationItem;
                    }
                    catch
                    {
                        Logger.LogMessage(LoggingLevel.Error, "ConfigurationManager.GetConfiguration failed for '" + configurationItemName + "'.");
                        configurationItemValue = false;
                        return false;
                    }
                    return true;
                }

                configurationItemValue = false;
                Logger.LogMessage(LoggingLevel.Error, "ConfigurationManager.GetConfiguration failed for '" + configurationItemName + "'.");
                return false;
            }
        }

        /// <summary>
        /// Retrieve the value of a configuration item.
        /// </summary>
        /// <param name="configurationItemName">The name of the configuration item to retrieve.</param>
        /// <param name="configurationItemValue">Returns the value of the configuration item in this parameter.</param>
        /// <returns>True on success.</returns>
        public static bool GetConfiguration(string configurationItemName, out int configurationItemValue)
        {
            lock (configuration)
            {
                object configurationItem;
                bool success = configuration.TryGetValue(configurationItemName, out configurationItem);
                if (success)
                {
                    try
                    {
                        configurationItemValue = (int)configurationItem;
                    }
                    catch
                    {
                        Logger.LogMessage(LoggingLevel.Error, "ConfigurationManager.GetConfiguration failed for '" + configurationItemName + "'.");
                        configurationItemValue = 0;
                        return false;
                    }
                    return true;
                }

                configurationItemValue = 0;
                Logger.LogMessage(LoggingLevel.Error, "ConfigurationManager.GetConfiguration failed for '" + configurationItemName + "'.");
                return false;
            }
        }

        /// <summary>
        /// Retrieve the value of a configuration item.
        /// </summary>
        /// <param name="configurationItemName">The name of the configuration item to retrieve.</param>
        /// <param name="configurationItemValue">Returns the value of the configuration item in this parameter.</param>
        /// <returns>True on success.</returns>
        public static bool GetConfiguration(string configurationItemName, out string configurationItemValue)
        {
            lock (configuration)
            {
                object configurationItem;
                bool success = configuration.TryGetValue(configurationItemName, out configurationItem);
                if (success)
                {
                    configurationItemValue = configurationItem as string;
                    if (configurationItemValue == null)
                    {
                        Logger.LogMessage(LoggingLevel.Debug, "ConfigurationManager.GetConfiguration failed or is returning null for '" + configurationItemName + "'.");
                        return false;
                    }
                    return true;
                }

                configurationItemValue = null;
                Logger.LogMessage(LoggingLevel.Error, "ConfigurationManager.GetConfiguration failed for '" + configurationItemName + "'.");
            }
            return false;
        }

        /// <summary>
        /// Retrieve the value of a configuration item.
        /// </summary>
        /// <param name="configurationItemName">The name of the configuration item to retrieve.</param>
        /// <param name="configurationItemValue">Returns the value of the configuration item in this parameter.</param>
        /// <returns>True on success.</returns>
        public static bool GetConfiguration<T>(string configurationItemName, out T configurationItemValue) where T : class
        {
            lock (configuration)
            {
                object configurationItem;
                bool success = configuration.TryGetValue(configurationItemName, out configurationItem);
                if (success)
                {
                    configurationItemValue = configurationItem as T;
                    if (configurationItemValue == null)
                    {
                        Logger.LogMessage(LoggingLevel.Debug, "ConfigurationManager.GetConfiguration failed or is returning null for '" + configurationItemName + "'.");
                        return false;
                    }
                    return true;
                }

                configurationItemValue = null;
                Logger.LogMessage(LoggingLevel.Error, "ConfigurationManager.GetConfiguration failed for '" + configurationItemName + "'.");
            }
            return false;
        }

        /// <summary>
        /// Changed the value of a configuration item and writes it to file if required.
        /// </summary>
        /// <param name="configurationItemName">The name of the configuration item to set.</param>
        /// <param name="configurationItemValue">The value of the configuration item.</param>
        /// <returns>True on success.</returns>
        public static void SetConfiguration(string configurationItemName, object configurationItemValue)
        {
            lock (configuration)
            {
                configuration.Remove(configurationItemName);
                configuration.Add(configurationItemName, configurationItemValue);
            }
            Logger.LogMessage(LoggingLevel.Debug, "Updating Configuration:");
            Logger.LogMessage(LoggingLevel.Debug, "  " + configurationItemName + " - " + configurationItemValue.ToString());
            MarkAsDirty();

            if (configurationItemName == "Connection.Serial")
            {
                SerialConnectionConfiguration serialConnectionConfiguration = configurationItemValue as SerialConnectionConfiguration;
                if (serialConnectionConfiguration != null)
                {
                    AdditionalConfigFile additionalConfigFile = new AdditionalConfigFile();
                    additionalConfigFile.DefaultBaudRate = serialConnectionConfiguration.BaudRate;
                    additionalConfigFile.Update();
                }
            }
        }

        /// <summary>
        /// Changed the value of a configuration item and writes it to file if required.
        /// </summary>
        /// <param name="configurationItemName">The name of the configuration item to set.</param>
        /// <param name="configurationItemValue">The value of the configuration item.</param>
        /// <returns>True on success.</returns>
        public static void SetConfiguration(List<KeyValuePair<string, object>> configurationItems)
        {
            lock (configuration)
            {
                Logger.LogMessage(LoggingLevel.Debug, "Updating Configuration:");
                foreach (KeyValuePair<string, object> configurationItem in configurationItems)
                {
                    configuration.Remove(configurationItem.Key);
                    configuration.Add(configurationItem.Key, configurationItem.Value);
                    Logger.LogMessage(LoggingLevel.Debug, "  " + configurationItem.Key + " - " + configurationItem.Value.ToString());
                }
            }
            MarkAsDirty();
        }

        /// <summary>
        /// Causes the configuration changed event to occur and all subscribed classes to renew their configuration.
        /// </summary>
        public static void MarkAsDirty()
        {
            if (ConfigurationChanged != null)
                ConfigurationChanged(null, null);
        }

        /// <summary>
        /// Print quick system summary on console.
        /// </summary>
        public static void PrintSystemSummary()
        {
            Logger.WriteSystemInfo(Console.Out, true);
        }
    }
}
