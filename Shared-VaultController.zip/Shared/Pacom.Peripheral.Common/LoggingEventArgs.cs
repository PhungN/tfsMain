﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Common
{
    public class LoggingEventArgs : EventArgs
    {
        private readonly LoggingLevel level = 0;
        private readonly string message;

        public LoggingEventArgs(LoggingLevel level, string message)
        {
            this.level = level;
            this.message = message;
        }

        public LoggingLevel Level
        {
            get { return level; }
        }

        public string Message
        {
            get { return message; }
        }
    }
}
