﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Common
{
    /// <summary>
    /// This class provides a central repository for counters.
    /// </summary>
    public static class CounterManager
    {
        private static Dictionary<string, int> counters = initialize();

        private static Dictionary<string, int> initialize()
        {
            Dictionary<string, int> countersToManage = new Dictionary<string, int>();

            countersToManage.Add("ParityErrors", (int)0);
            countersToManage.Add("ChecksumErrors", (int)0);
            countersToManage.Add("DataErrors", (int)0);
            countersToManage.Add("ContentionTimeouts", (int)0);
            countersToManage.Add("RTUConnectedBySerial", (int)0);
            countersToManage.Add("RTUConnectedByTCPIP", (int)0);
            countersToManage.Add("RTUConnectedByUDPIP", (int)0);

            return countersToManage;
        }

        /// <summary>
        /// Returns the value of a counter.
        /// </summary>
        /// <param name="name">The name of the counter of interest.</param>
        /// <returns>The value of the counter.</returns>
        public static int GetCounter(string name)
        {
            int value;
            lock (counters)
            {
                if (counters.TryGetValue(name, out value))
                    return value;
                return 0;
            }
        }

        /// <summary>
        /// Updated the value of a counter.
        /// </summary>
        /// <param name="name">The name of the counter of interest.</param>
        /// <param name="value">The value of the counter.</param>
        public static void SetCounter(string name, int value)
        {
            lock (counters)
            {
                counters.Remove(name);
                counters.Add(name, value);
            }
        }

        /// <summary>
        /// Increment the value of a counter by 1.
        /// </summary>
        /// <param name="name">The name of the counter of interest.</param>
        public static void IncrementCounter(string name)
        {
            lock (counters)
            {
                if (counters.ContainsKey(name))
                    counters[name]++;
            }
        }

        /// <summary>
        /// Increment the value of a counter by a specified value.
        /// </summary>
        /// <param name="name">The name of the counter of interest.</param>
        /// <param name="incrementValue">The amount to increment the counter by.</param>
        public static void IncrementCounter(string name, int incrementValue)
        {
            lock (counters)
            {
                if (counters.ContainsKey(name))
                    counters[name] += incrementValue;
            }
        }

        /// <summary>
        /// Decrement the value of a counter by 1.
        /// </summary>
        /// <param name="name">The name of the counter of interest.</param>
        public static void DecrementCounter(string name)
        {
            lock (counters)
            {
                if (counters.ContainsKey(name))
                    counters[name]--;
            }
        }

        /// <summary>
        /// Decrement the value of a counter by a specified value.
        /// </summary>
        /// <param name="name">The name of the counter of interest.</param>
        /// <param name="incrementValue">The amount to decrement the counter by.</param>
        public static void DecrementCounter(string name, int decrementValue)
        {
            lock (counters)
            {
                if (counters.ContainsKey(name))
                    counters[name] -= decrementValue;
            }
        }
    }
}
