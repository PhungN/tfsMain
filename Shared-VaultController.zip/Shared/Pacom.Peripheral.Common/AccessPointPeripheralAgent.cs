﻿using System;
using System.Threading;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    public class AccessPointPeripheralAgent : IDisposable
    {
        public AccessPointPeripheralAgent()
        {
            // Set default states
            setBuzzer(normalBuzzer, 0, 0);
            setRedLed(normalRedLed, 0, 0);
            setGreenLed(normalGreenLed, 0, 0);
        }

        private Timer triggerBuzzerTimer = null;
        private Timer triggerBuzzerPulsingTimer = null;
        private Timer triggerRedLedTimer = null;
        private Timer triggerRedLedFlashingTimer = null;
        private Timer triggerGreenLedTimer = null;
        private Timer triggerGreenLedFlashingTimer = null;
        private Timer triggerStrikeTimer = null;
        private Timer triggerSpareOutputTimer = null;

        private bool strikeWithoutTimer = false;
        
		private static int spareInput = 11;
        private static int strikeSensorInput = 10;
        private static int egressSensorInput = 9;
        private static int doorContactInput = 8;

        /// <summary>
        /// Index of input used by strike.
        /// </summary>
        public static int StrikeSensorInput
        {
            get { return strikeSensorInput; }
            set { strikeSensorInput = value; }
        }

        /// <summary>
        /// Index of input used by egress.
        /// </summary>
        public static int EgressSensorInput
        {
            get { return egressSensorInput; }
            set { egressSensorInput = value; }
        }

        /// <summary>
        /// Index of input used by door contact.
        /// </summary>
        public static int DoorContactInput
        {
            get { return doorContactInput; }
            set { doorContactInput = value; }
        }

        /// <summary>
        /// Index of input used as spare.
        /// </summary>
        public static int SpareInput
        {
            get { return spareInput; }
            set { spareInput = value; }
        }

        public event EventHandler<BuzzerStateChangeArgs> OnBuzzerStateChange;
        public event EventHandler<LedStateChangeArgs> OnRedLedStateChange;
        public event EventHandler<LedStateChangeArgs> OnGreenLedStateChange;
        public event EventHandler<OutputStateChangeArgs> OnStrikeStateChange;
        public event EventHandler<OutputStateChangeArgs> OnSpareOutputStateChange;

        #region Normal State Section

        private CardReaderBuzzerType normalBuzzer = CardReaderBuzzerType.BuzzerOff;
        private int normalBuzzerDuration = 0;
        private int normalBuzzerFrequency = 0;

        public CardReaderBuzzerType NormalBuzzer
        {
            get
            {
                return normalBuzzer;
            }
        }

        public void SetNormalBuzzer(CardReaderBuzzerType type, int duration, int frequency)
        {
            normalBuzzer = type;
            normalBuzzerDuration = duration;
            normalBuzzerFrequency = frequency;

            // Copy normal settings over current state
            if (duration == 0)
            {
                triggerBuzzerState(null);
            }
        }

        private CardReaderLedType normalRedLed = CardReaderLedType.LedOff;
        private int normalRedLedDuration = 0;
        private int normalRedLedFrequency = 0;

        public CardReaderLedType NormalRedLed
        {
            get
            {
                return normalRedLed;
            }
        }

        public void SetNormalRedLed(CardReaderLedType type, int duration, int frequency)
        {
            normalRedLed = type;
            normalRedLedDuration = duration;
            normalRedLedFrequency = frequency;

            // Copy normal settings over current state
            if (duration == 0)
            {
                triggerRedLedState(null);
            }
        }

        private CardReaderLedType normalGreenLed = CardReaderLedType.LedOff;
        private int normalGreenLedDuration = 0;
        private int normalGreenLedFrequency = 0;

        public CardReaderLedType NormalGreenLed
        {
            get
            {
                return normalGreenLed;
            }
        }

        public void SetNormalGreenLed(CardReaderLedType type, int duration, int frequency)
        {
            normalGreenLed = type;
            normalGreenLedDuration = duration;
            normalGreenLedFrequency = frequency;

            // Copy normal settings over current state
            if (duration == 0)
            {
                triggerGreenLedState(null);
            }
        }

        #endregion

        #region Current State Section

        private bool currentBuzzerPulsingHigh = false;
        private CardReaderBuzzerType currentBuzzer = CardReaderBuzzerType.BuzzerOff;
        private int currentBuzzerDuration = 0;
        private int currentBuzzerFrequency = 0;

        public CardReaderBuzzerType CurrentBuzzer
        {
            get
            {
                return currentBuzzer;
            }
        }

        private bool currentRedLedFlashingHigh = false;
        private CardReaderLedType currentRedLed = CardReaderLedType.LedOff;
        private int currentRedLedDuration = 0;
        private int currentRedLedFrequency = 0;

        public CardReaderLedType CurrentRedLed
        {
            get
            {
                return currentRedLed;
            }
        }

        private bool currentGreenLedFlashingHigh = false;
        private CardReaderLedType currentGreenLed = CardReaderLedType.LedOff;
        private int currentGreenLedDuration = 0;
        private int currentGreenLedFrequency = 0;

        public CardReaderLedType CurrentGreenLed
        {
            get
            {
                return currentGreenLed;
            }
        }

        public void SetCurrentBuzzer(CardReaderBuzzerType type, int duration, int frequency)
        {
            if (duration <= 0)
            {
                return;
            }
            setBuzzer(type, duration, frequency);
        }

        public void SetCurrentRedLed(CardReaderLedType type, int duration, int frequency)
        {
            if (duration <= 0)
            {
                return;
            }
            setRedLed(type, duration, frequency);
        }

        public void SetCurrentGreenLed(CardReaderLedType type, int duration, int frequency)
        {
            if (duration <= 0)
            {
                return;
            }
            setGreenLed(type, duration, frequency);
        }

        #endregion

        #region Strike Secion

        public void SetStrike()
        {
            if (triggerStrikeTimer != null)
            {
                triggerStrikeTimer.Dispose();
                triggerStrikeTimer = null;
            }

            strikeWithoutTimer = true;

            if (OnStrikeStateChange != null)
            {
                OnStrikeStateChange(this, new OutputStateChangeArgs(true));
            }
        }

        public void SetStrike(int duration)
        {
            if (triggerStrikeTimer != null)
            {
                triggerStrikeTimer.Dispose();
                triggerStrikeTimer = null;
            }

            strikeWithoutTimer = false;

            if (duration == 0)
            {
                ClearStrike();
            }
            else
            {
                if (OnStrikeStateChange != null)
                {
                    OnStrikeStateChange(this, new OutputStateChangeArgs(true));
                }
                triggerStrikeTimer = new Timer(triggerStrikeState, null, duration, Timeout.Infinite);
            }
        }

        public void ClearStrike()
        {
            if (triggerStrikeTimer != null)
            {
                triggerStrikeTimer.Dispose();
                triggerStrikeTimer = null;
            }

            strikeWithoutTimer = false;

            if (OnStrikeStateChange != null)
            {
                OnStrikeStateChange(this, new OutputStateChangeArgs(false));
            }
        }
                
        private void triggerStrikeState(object state)
        {
            ClearStrike();
        }
        
        /// <summary>
        /// Indicates if strike was enabled without timer.
        /// </summary>
        public bool StrikeWithoutTimer
        {
            get
            {
                return strikeWithoutTimer;
            }
        }

        #endregion
        
        #region Spare Output Secion

        public void SetSpareOutput()
        {
            if (triggerSpareOutputTimer != null)
            {
                triggerSpareOutputTimer.Dispose();
                triggerSpareOutputTimer = null;
            }

            if (OnSpareOutputStateChange != null)
            {
                OnSpareOutputStateChange(this, new OutputStateChangeArgs(true));
            }
        }

        public void SetSpareOutput(int duration)
        {
            if (triggerSpareOutputTimer != null)
            {
                triggerSpareOutputTimer.Dispose();
                triggerSpareOutputTimer = null;
            }

            if (duration == 0)
            {
                ClearSpareOutput();
            }
            else
            {
                if (OnSpareOutputStateChange != null)
                {
                    OnSpareOutputStateChange(this, new OutputStateChangeArgs(true));
                }
                triggerSpareOutputTimer = new Timer(triggerSpareOutputState, null, duration, Timeout.Infinite);
            }
        }

        public void ClearSpareOutput()
        {
            if (triggerSpareOutputTimer != null)
            {
                triggerSpareOutputTimer.Dispose();
                triggerSpareOutputTimer = null;
            }

            if (OnSpareOutputStateChange != null)
            {
                OnSpareOutputStateChange(this, new OutputStateChangeArgs(false));
            }
        }

        private void triggerSpareOutputState(object state)
        {
            ClearSpareOutput();
        }

        #endregion
        
        #region State Change Timers
        
        private void triggerBuzzerState(object state)
        {
            if (triggerBuzzerTimer != null)
            {
                triggerBuzzerTimer.Dispose();
                triggerBuzzerTimer = null;
            }

            if (triggerBuzzerPulsingTimer != null)
            {
                triggerBuzzerPulsingTimer.Dispose();
                triggerBuzzerPulsingTimer = null;
            }

            // Current state finished, restore to normal
            currentBuzzer = normalBuzzer;
            currentBuzzerDuration = normalBuzzerDuration;
            currentBuzzerFrequency = normalBuzzerFrequency;


            if (currentBuzzer == CardReaderBuzzerType.BuzzerOn)
            {
                if (OnBuzzerStateChange != null)
                {
                    OnBuzzerStateChange(this, new BuzzerStateChangeArgs(true));
                }
            }
            else if (currentBuzzer == CardReaderBuzzerType.BuzzerOff)
            {
                if (OnBuzzerStateChange != null)
                {
                    OnBuzzerStateChange(this, new BuzzerStateChangeArgs(false));
                }
            }
            // For pulsing restore pulsing and state change timer 
            else if (currentBuzzer == CardReaderBuzzerType.BuzzerPulse)
            {
                // But only if pulsing frequency is provided
                if (currentBuzzerFrequency > 0)
                {
                    // Startup state change timer if duration is provided
                    if (currentBuzzerDuration > 0)
                    {
                        triggerBuzzerTimer = new Timer(triggerBuzzerState, null, currentBuzzerDuration, Timeout.Infinite);
                    }
                    triggerBuzzerPulsingTimer = new Timer(triggerPulsingBuzzerState, null, currentBuzzerFrequency, Timeout.Infinite);
                    currentBuzzer = CardReaderBuzzerType.BuzzerOn;
                }
                else
                {
                    currentBuzzer = CardReaderBuzzerType.BuzzerOff;
                }
            }
        }

        private void triggerRedLedState(object state)
        {
            if (triggerRedLedTimer != null)
            {
                triggerRedLedTimer.Dispose();
                triggerRedLedTimer = null;
            }

            if (triggerRedLedFlashingTimer != null)
            {
                triggerRedLedFlashingTimer.Dispose();
                triggerRedLedFlashingTimer = null;
            }

            // Current state finished, restore to normal
            currentRedLed = normalRedLed;
            currentRedLedDuration = normalRedLedDuration;
            currentRedLedFrequency = normalRedLedFrequency;

            if (currentRedLed == CardReaderLedType.LedOn)
            {
                if (OnRedLedStateChange != null)
                {
                    OnRedLedStateChange(this, new LedStateChangeArgs(true));
                }
            }
            else if (currentRedLed == CardReaderLedType.LedOff)
            {
                if (OnRedLedStateChange != null)
                {
                    OnRedLedStateChange(this, new LedStateChangeArgs(false));
                }
            }
            // For pulsing restore pulsing and state change timer 
            else if (currentRedLed == CardReaderLedType.LedFlashing)
            {
                // But only if pulsing frequency is provided
                if (currentRedLedFrequency > 0)
                {
                    // Startup state change timer if duration is provided
                    if (currentRedLedDuration > 0)
                    {
                        triggerRedLedTimer = new Timer(triggerRedLedState, null, currentRedLedDuration, Timeout.Infinite);
                    }
                    triggerRedLedFlashingTimer = new Timer(triggerFlashingRedLedState, null, currentRedLedFrequency, Timeout.Infinite);
                    currentRedLed = CardReaderLedType.LedOn;
                }
                else
                {
                    currentRedLed = CardReaderLedType.LedOff;
                }
            }
        }

        private void triggerGreenLedState(object state)
        {
            if (triggerGreenLedTimer != null)
            {
                triggerGreenLedTimer.Dispose();
                triggerGreenLedTimer = null;
            }

            if (triggerGreenLedFlashingTimer != null)
            {
                triggerGreenLedFlashingTimer.Dispose();
                triggerGreenLedFlashingTimer = null;
            }

            // Current state finished, restore to normal
            currentGreenLed = normalGreenLed;
            currentGreenLedDuration = normalGreenLedDuration;
            currentGreenLedFrequency = normalGreenLedFrequency;

            if (currentGreenLed == CardReaderLedType.LedOn)
            {
                if (OnGreenLedStateChange != null)
                {
                    OnGreenLedStateChange(this, new LedStateChangeArgs(true));
                }
            }
            else if (currentGreenLed == CardReaderLedType.LedOff)
            {
                if (OnGreenLedStateChange != null)
                {
                    OnGreenLedStateChange(this, new LedStateChangeArgs(false));
                }
            }
            // For pulsing restore pulsing and state change timer 
            else if (currentGreenLed == CardReaderLedType.LedFlashing)
            {
                // But only if pulsing frequency is provided
                if (currentGreenLedFrequency > 0)
                {
                    // Startup state change timer if duration is provided
                    if (currentGreenLedDuration > 0)
                    {
                        triggerGreenLedTimer = new Timer(triggerGreenLedState, null, currentGreenLedDuration, Timeout.Infinite);
                    }
                    triggerGreenLedFlashingTimer = new Timer(triggerFlashingGreenLedState, null, currentGreenLedFrequency, Timeout.Infinite);
                    currentGreenLed = CardReaderLedType.LedOn;
                }
                else
                {
                    currentGreenLed = CardReaderLedType.LedOff;
                }
            }
        }

        #endregion

        #region Pulsing and Flashing Timers

        private void triggerPulsingBuzzerState(object state)
        {
            currentBuzzerPulsingHigh = !currentBuzzerPulsingHigh;
            if (currentBuzzerPulsingHigh == true)
            {
                if (OnBuzzerStateChange != null)
                {
                    OnBuzzerStateChange(this, new BuzzerStateChangeArgs(false));
                }
            }
            else
            {
                if (OnBuzzerStateChange != null)
                {
                    OnBuzzerStateChange(this, new BuzzerStateChangeArgs(true));
                }
            }
            triggerBuzzerPulsingTimer = new Timer(triggerPulsingBuzzerState, null, currentBuzzerFrequency, Timeout.Infinite);
        }

        private void triggerFlashingRedLedState(object state)
        {
            currentRedLedFlashingHigh = !currentRedLedFlashingHigh;
            if (currentRedLedFlashingHigh == true)
            {
                if (OnRedLedStateChange != null)
                {
                    OnRedLedStateChange(this, new LedStateChangeArgs(false));
                }
            }
            else
            {
                if (OnRedLedStateChange != null)
                {
                    OnRedLedStateChange(this, new LedStateChangeArgs(true));
                }
            }
            triggerRedLedFlashingTimer = new Timer(triggerFlashingRedLedState, null, currentRedLedFrequency, Timeout.Infinite);
        }

        private void triggerFlashingGreenLedState(object state)
        {
            currentGreenLedFlashingHigh = !currentGreenLedFlashingHigh;
            if (currentGreenLedFlashingHigh == true)
            {
                if (OnGreenLedStateChange != null)
                {
                    OnGreenLedStateChange(this, new LedStateChangeArgs(false));
                }
            }
            else
            {
                if (OnGreenLedStateChange != null)
                {
                    OnGreenLedStateChange(this, new LedStateChangeArgs(true));
                }
            }
            triggerGreenLedFlashingTimer = new Timer(triggerFlashingGreenLedState, null, currentGreenLedFrequency, Timeout.Infinite);
        }

        #endregion

        #region Privite Current State Setters

        private void setBuzzer(CardReaderBuzzerType type, int duration, int frequency)
        {
            switch (type)
            {
                case CardReaderBuzzerType.BuzzerOff:
                    if (triggerBuzzerPulsingTimer != null)
                    {
                        triggerBuzzerPulsingTimer.Dispose();
                        triggerBuzzerPulsingTimer = null;
                    }
                    currentBuzzer = CardReaderBuzzerType.BuzzerOff;
                    currentBuzzerDuration = 0;
                    currentBuzzerFrequency = 0;
                    if (OnBuzzerStateChange != null)
                    {
                        OnBuzzerStateChange(this, new BuzzerStateChangeArgs(false));
                    }
                    break;
                case CardReaderBuzzerType.BuzzerOn:
                    if (triggerBuzzerPulsingTimer != null)
                    {
                        triggerBuzzerPulsingTimer.Dispose();
                        triggerBuzzerPulsingTimer = null;
                    }
                    currentBuzzer = CardReaderBuzzerType.BuzzerOn;
                    currentBuzzerDuration = duration;
                    currentBuzzerFrequency = frequency;
                    if (OnBuzzerStateChange != null)
                    {
                        OnBuzzerStateChange(this, new BuzzerStateChangeArgs(true));
                    }
                    triggerBuzzerTimer = new Timer(triggerBuzzerState, null, duration, Timeout.Infinite);
                    break;
                case CardReaderBuzzerType.BuzzerPulse:
                    if (triggerBuzzerPulsingTimer != null)
                    {
                        triggerBuzzerPulsingTimer.Dispose();
                        triggerBuzzerPulsingTimer = null;
                    }
                    currentBuzzer = CardReaderBuzzerType.BuzzerOn;
                    currentBuzzerDuration = duration;
                    currentBuzzerFrequency = frequency;
                    triggerBuzzerTimer = new Timer(triggerBuzzerState, null, duration, Timeout.Infinite);
                    triggerBuzzerPulsingTimer = new Timer(triggerPulsingBuzzerState, null, frequency, Timeout.Infinite);
                    break;
            }
        }

        private void setRedLed(CardReaderLedType type, int duration, int frequency)
        {
            switch (type)
            {
                case CardReaderLedType.LedOff:
                    if (triggerRedLedFlashingTimer != null)
                    {
                        triggerRedLedFlashingTimer.Dispose();
                        triggerRedLedFlashingTimer = null;
                    }
                    currentRedLed = CardReaderLedType.LedOff;
                    currentRedLedDuration = 0;
                    currentRedLedFrequency = 0;
                    if (OnRedLedStateChange != null)
                    {
                        OnRedLedStateChange(this, new LedStateChangeArgs(false));
                    }
                    break;
                case CardReaderLedType.LedOn:
                    if (triggerRedLedFlashingTimer != null)
                    {
                        triggerRedLedFlashingTimer.Dispose();
                        triggerRedLedFlashingTimer = null;
                    }
                    currentRedLed = CardReaderLedType.LedOn;
                    currentRedLedDuration = duration;
                    currentRedLedFrequency = frequency;
                    if (OnRedLedStateChange != null)
                    {
                        OnRedLedStateChange(this, new LedStateChangeArgs(true));
                    }
                    triggerRedLedTimer = new Timer(triggerRedLedState, null, duration, Timeout.Infinite);
                    break;
                case CardReaderLedType.LedFlashing:
                    if (triggerRedLedFlashingTimer != null)
                    {
                        triggerRedLedFlashingTimer.Dispose();
                        triggerRedLedFlashingTimer = null;
                    }
                    currentRedLed = CardReaderLedType.LedFlashing;
                    currentRedLedDuration = duration;
                    currentRedLedFrequency = frequency;
                    triggerRedLedTimer = new Timer(triggerRedLedState, null, duration, Timeout.Infinite);
                    triggerRedLedFlashingTimer = new Timer(triggerFlashingRedLedState, null, frequency, Timeout.Infinite);
                    break;
            }
        }

        private void setGreenLed(CardReaderLedType type, int duration, int frequency)
        {
            switch (type)
            {
                case CardReaderLedType.LedOff:
                    if (triggerGreenLedFlashingTimer != null)
                    {
                        triggerGreenLedFlashingTimer.Dispose();
                        triggerGreenLedFlashingTimer = null;
                    }
                    currentGreenLed = CardReaderLedType.LedOff;
                    currentGreenLedDuration = 0;
                    currentGreenLedFrequency = 0;
                    if (OnGreenLedStateChange != null)
                    {
                        OnGreenLedStateChange(this, new LedStateChangeArgs(false));
                    }
                    break;
                case CardReaderLedType.LedOn:
                    if (triggerGreenLedFlashingTimer != null)
                    {
                        triggerGreenLedFlashingTimer.Dispose();
                        triggerGreenLedFlashingTimer = null;
                    }
                    currentGreenLed = CardReaderLedType.LedOn;
                    currentGreenLedDuration = duration;
                    currentGreenLedFrequency = frequency;
                    if (OnGreenLedStateChange != null)
                    {
                        OnGreenLedStateChange(this, new LedStateChangeArgs(true));
                    }
                    triggerGreenLedTimer = new Timer(triggerGreenLedState, null, duration, Timeout.Infinite);
                    break;
                case CardReaderLedType.LedFlashing:
                    if (triggerGreenLedFlashingTimer != null)
                    {
                        triggerGreenLedFlashingTimer.Dispose();
                        triggerGreenLedFlashingTimer = null;
                    }
                    currentGreenLed = CardReaderLedType.LedFlashing;
                    currentGreenLedDuration = duration;
                    currentGreenLedFrequency = frequency;
                    triggerGreenLedTimer = new Timer(triggerGreenLedState, null, duration, Timeout.Infinite);
                    triggerGreenLedFlashingTimer = new Timer(triggerFlashingGreenLedState, null, frequency, Timeout.Infinite);
                    break;
            }
        }

        #endregion

        #region IDisposable Members

        private bool disposed = false;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    if (triggerBuzzerTimer != null)
                    {
                        triggerBuzzerTimer.Dispose();
                        triggerBuzzerTimer = null;
                    }
                    if (triggerBuzzerPulsingTimer != null)
                    {
                        triggerBuzzerPulsingTimer.Dispose();
                        triggerBuzzerPulsingTimer = null;
                    }
                    if (triggerRedLedTimer != null)
                    {
                        triggerRedLedTimer.Dispose();
                        triggerRedLedTimer = null;
                    }
                    if (triggerRedLedFlashingTimer != null)
                    {
                        triggerRedLedFlashingTimer.Dispose();
                        triggerRedLedFlashingTimer = null;
                    }
                    if (triggerGreenLedTimer != null)
                    {
                        triggerGreenLedTimer.Dispose();
                        triggerGreenLedTimer = null;
                    }
                    if (triggerGreenLedFlashingTimer != null)
                    {
                        triggerGreenLedFlashingTimer.Dispose();
                        triggerGreenLedFlashingTimer = null;
                    }
                    if (triggerStrikeTimer != null)
                    {
                        triggerStrikeTimer.Dispose();
                        triggerStrikeTimer = null;
                    }
                }
            }
            disposed = true;
        }

        ~AccessPointPeripheralAgent()
        {
            Dispose(false);
        }

        #endregion
    }
}
