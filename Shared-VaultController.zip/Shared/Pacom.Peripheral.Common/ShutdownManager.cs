﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Pacom.Peripheral.Common
{
    public static class ShutdownManager
    {
        public static event EventHandler<EventArgs> CloseApplication;

        public static void Close(object sender)
        {
            if (CloseApplication != null)
            {
                CloseApplication(sender, new EventArgs());
            }
        }

        private static Timer timer = null;

        public static void RequestDeviceReset(object sender)
        {
            timer = new Timer(requestResetDevice, sender, 3000, Timeout.Infinite);
        }

        private static void requestResetDevice(object state)
        {
            timer.Dispose();
            ShutdownManager.Close(state);  
        }
    }
}
