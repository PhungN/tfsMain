﻿using System;
using System.Text;
using System.Security.Cryptography;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public class DeviceLoopOverUdpIPMessageData : DeviceLoopOverUdpIPMessageBase
    {
        public DeviceLoopOverUdpIPMessageData(byte[] receivedData)
            : base(receivedData)
        {
        }

        public DeviceLoopOverUdpIPMessageData(int sourceUnitNumber, int destinationUnitNumber, byte sessionId, UInt32 deviceSequenceNumber, UInt32 controllerSequenceNumber,
            byte[] encryptedData, EncryptionType encryptionType)
            : base(4, sourceUnitNumber, destinationUnitNumber, sessionId, deviceSequenceNumber, controllerSequenceNumber, 14 + encryptedData.Length + (encryptionType == EncryptionType.Aes128 ? 16 : 32))
        {
            if (encryptedData == null || (encryptedData.Length % 16) != 0)
                throw new ArgumentException("encryptedData is null or is not of appropriate size", "encryptedData");

            Buffer.BlockCopy(encryptedData, 0, Data, 14, encryptedData.Length);
        }

        public byte[] GetEncryptedData(int masterKeyLength)
        {
            int length = Data.Length - 14 - masterKeyLength;
            if (length <= 0 || (length % 16) != 0)
                throw new ArgumentException("encryptedData is not of appropriate size");

            byte[] buffer = new byte[length];
            Buffer.BlockCopy(Data, 14, buffer, 0, buffer.Length);
            return buffer;
        }

        public byte[] GetHmacSessionKey(int masterKeyLength)
        {
            byte[] buffer = new byte[masterKeyLength];
            Buffer.BlockCopy(Data, Data.Length - masterKeyLength, buffer, 0, masterKeyLength);
            return buffer;
        }

        public void SetHmacSessionKey(byte[] value, int masterKeyLength)
        {
            Buffer.BlockCopy(value, 0, Data, Data.Length - masterKeyLength, masterKeyLength);
        }

        public int GetHmacSessionKeyOffset(int masterKeyLength)
        {
            return Data.Length - masterKeyLength;
        }

        public override int HmacSessionKeyOffset
        {
            get { return 0; }
        }
    }
}
