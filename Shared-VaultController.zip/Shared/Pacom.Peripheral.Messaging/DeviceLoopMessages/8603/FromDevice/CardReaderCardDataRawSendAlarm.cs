﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    /// <summary>
    /// Handles request and response with raw card data stream payload.
    /// </summary>
    public class CardReaderCardDataRawSendAlarm : CardReaderCardDataRawSendAlarmBase
    {
        public const byte Reader1FunctionCode = 31;
        public const byte Reader2FunctionCode = 32;
        public const byte Reader3FunctionCode = 41;
        public const byte Reader4FunctionCode = 42;

        public CardReaderCardDataRawSendAlarm(byte[] data, int offset, int length)
            : base(Reader1FunctionCode, Reader2FunctionCode, Reader3FunctionCode, Reader4FunctionCode, data, offset, length)
        {
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber">Card reader number</param>
        /// <param name="config">Request configuration</param>
        public CardReaderCardDataRawSendAlarm(CardReaderPortType readerNumber, CardReaderDataSendDataRawConfig config)
            : base (Reader1FunctionCode, Reader2FunctionCode, Reader3FunctionCode, Reader4FunctionCode, readerNumber, config)
        {
        }

#if COMMUNICATIONSANALYZER

        public CardReaderCardDataRawSendAlarm()
        {
        }

#endif

    }
}
