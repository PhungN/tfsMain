﻿using System;
using Pacom.Peripheral.Common;
using System.Text;
using Pacom.Peripheral.OsdpMessaging;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // 43, RDR_NUM, VEN_1, VEN_2, VEN_3, MODEL, VERSION, SER_LSB, SER_2, SER_3, SER_MSB, FW_MAJ, FW_MIN, FW_BUILD, BOOT_MAJ, BOOT_MIN, SERV_MAJ, SERV_MIN
    // Where:
    //  RDR_NUM is the attached card reader number from 1-4.
    //  VEN_1..VEN_3 are 3 bytes representing the IEEE assigned OUI for the card reader vendor.
    //  MODEL is the card reader manufacturers card reader model number.
    //  VERSION is the card reader manufacturers version of this card reader.
    //  SER_LSB...SER_MSB are 4 bytes representing the card reader’s serial number.
    //  FM_MAJ FM_MIN FW_BUILD are 3 bytes representing the major, minor and build version of the current reader firmware.
    //  BOOT_MAJ BOOT_MIN are 2 bytes representing the major and minor version of the current reader bootloader firmware.
    //  SERV_MAJ SERV_MIN are 2 bytes representing the major and minor version of the current reader service protocol version running in the bootloader.
    public class OsdpReaderInfoResponse : DeviceLoopMessageBase
    {
        public const int OsdpReaderInfoResponseFunctionCode = 43;

        public OsdpReaderInfoResponse(byte[] data, int offset, int length)
            : base(data, offset, length, 2)
        {
            if (Length != 2 && Length != 14 && Length != 18)
                throw new ArgumentException("data is of incorrect length", "data");

            if (ReaderId > 4)
                throw new ArgumentException("data contains invalid ReaderId", "data");
        }

        public OsdpReaderInfoResponse(int readerId)
        {
            Data = new byte[2];
            FunctionCode = OsdpReaderInfoResponseFunctionCode;
            Data[1] = (byte)readerId;
            Length = 2;
        }

        public OsdpReaderInfoResponse(int readerId, ReaderManufacturer vendor, int modelNumber, int version, int serialNumber, int firmwareMajor, int firmwareMinor, int firmwareBuild)
        {
            Data = new byte[14];
            FunctionCode = OsdpReaderInfoResponseFunctionCode;

            OsdpMessageBase.SetVendorBytes(vendor, Data, Offset + 2);

            Data[1] = (byte)readerId;
            Data[5] = (byte)modelNumber;
            Data[6] = (byte)version;
            Data[7] = (byte)(serialNumber & 0xFF);
            Data[8] = (byte)((serialNumber & 0xFF00) >> 8);
            Data[9] = (byte)((serialNumber & 0xFF0000) >> 16);
            Data[10] = (byte)((serialNumber & 0xFF000000) >> 24);
            Data[11] = (byte)firmwareMajor;
            Data[12] = (byte)firmwareMinor;
            Data[13] = (byte)firmwareBuild;

            Length = 14;
        }

        public bool ContainsOsdpReaderInfo
        {
            get
            {
                if (Length >= 14)
                    return true;
                return false;
            }
        }

        public int ReaderId
        {
            get
            {
                return Data[Offset + 1];
            }
        }

        public ReaderManufacturer Vendor
        {
            get
            {
                if (ContainsOsdpReaderInfo == false) return ReaderManufacturer.Unknown;
                return OsdpMessageBase.GetVendor(Data, Offset + 2);
            }
        }

        public int ModelNumber
        {
            get
            {
                if (ContainsOsdpReaderInfo == false) return 0;
                return Data[Offset + 5];
            }
        }

        public int Version
        {
            get
            {
                if (ContainsOsdpReaderInfo == false) return 0;
                return Data[Offset + 6];
            }
        }

        public int SerialNumber
        {
            get
            {
                if (ContainsOsdpReaderInfo == false) return 0;
                return (((((Data[Offset + 10] << 8) | Data[Offset + 9]) << 8) | Data[Offset + 8]) << 8) | Data[Offset + 7];
            }
        }

        public string FirmwareVersion
        {
            get
            {
                if (ContainsOsdpReaderInfo == false) return string.Empty;
                StringBuilder version = new StringBuilder().AppendFormat("{0}.{1}.{2}.0", Data[Offset + 11], Data[Offset + 12], Data[Offset + 13]);
                return version.ToString();
            }
        }

        public override string ToString()
        {
            if (ContainsOsdpReaderInfo)
                return string.Format("OSDP Reader Info Response - Reader {0}, Manufacturer {1}, Model {2}, Version {3}, SerialNumber {4}, FW Version {5}",
                    ReaderId.ToString(), Vendor.ToString(), ModelNumber.ToString(), Version.ToString(), SerialNumber.ToString(), FirmwareVersion);
            else
                return string.Format("OSDP Reader Info Response - Reader {0} - No OSDP reader attached", ReaderId.ToString());
        }

#if COMMUNICATIONSANALYZER

        public OsdpReaderInfoResponse()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { OsdpReaderInfoResponseFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
