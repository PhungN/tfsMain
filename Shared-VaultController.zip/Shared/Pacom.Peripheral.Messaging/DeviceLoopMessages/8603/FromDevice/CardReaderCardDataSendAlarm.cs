﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    public class CardReaderCardDataSendAlarm : CardReaderCardDataSendAlarmBase
    {
        public const byte Reader1FunctionCode = 7;
        public const byte Reader2FunctionCode = 16;
        public const byte Reader3FunctionCode = 33;
        public const byte Reader4FunctionCode = 37;

        /// <summary>
        /// Parse "CardDataSend" device loop message.
        /// </summary>
        /// <param name="data">Byte array with device loop message.</param>
        /// <param name="offset">Offset is used to indicate position of function code in the byte array.</param>
        /// <param name="length">Length of data from function code to the end of array or check code.</param>
        public CardReaderCardDataSendAlarm(byte[] data, int offset, int length)
            : base(Reader1FunctionCode, Reader2FunctionCode, Reader3FunctionCode, Reader4FunctionCode, data, offset, length)
        {
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public CardReaderCardDataSendAlarm(CardReaderPortType readerNumber, CardReaderDataSendDataConfig config)
            : base(Reader1FunctionCode, Reader2FunctionCode, Reader3FunctionCode, Reader4FunctionCode, readerNumber, config)
        {
        }

#if COMMUNICATIONSANALYZER

        public CardReaderCardDataSendAlarm() : base()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get
            {
                return new int[] { 
                Reader1FunctionCode, Reader2FunctionCode,
                Reader3FunctionCode, Reader4FunctionCode
            };
            }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            int reader;
            if (FunctionCode == Reader1FunctionCode)
                reader = 1;
            else if (FunctionCode == Reader2FunctionCode)
                reader = 2;
            else if (FunctionCode == Reader3FunctionCode)
                reader = 3;
            else
                reader = 4;
            
            CardFormatDesignatorConfig designators = new CardFormatDesignatorConfig();
            designators.Facility = 16;
            designators.Issue = 8;
            CardReaderPortType readerPort;
            CardReaderDataSendDataConfig config;

            GetConfiguration(designators, out readerPort, out config);

            int issue = config.Issue[0];
            int facility = (config.Facility[0] << 8) | config.Facility[1];
            double code = (config.Code[0] << 32) | (config.Code[1] << 24) | (config.Code[2] << 16) | (config.Code[3] << 8) | config.Code[4];

            string card = "(" + issue + "/" + facility + "/" + code + ")";


            return "Card Scan - Reader" + reader + " " + card ;
        }

        public override string MultilineDescriptionToString()
        {
            return ShortDescriptionToString();
        }
#endif

    }
}
