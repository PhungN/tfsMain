﻿using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    /// Send changes from a single analog inputs. 
    /// This message should be used instead of the LegacyAnalogInputChangedAlarm when sending alarms from 
    /// any input (on board, input expansion cards). 
    /// The message format is:
    /// 54, OWNERTYPE, STARTINGPOINT, [ADC_HIGH_0, ADC_LOW_0], [ADC_HIGH_1, ADC_LOW_1], ... [ADC_HIGH_N, ADC_LOW_N]
    /// OWNERTYPE = Onboard, Expansion1, Expansion2, ... as defined in Common.OwnerType enumerator
    /// STARTINGPOINT = 0, 1, 2, 3, ... N =  Starting point number on the owning device
    /// NUMBEROFINPUTS = number of inputs to look at in the message
    /// ADC_HIGH_N, ADC_LOW_N = Analog value 
    public class AnalogInputChangedAlarm : DeviceLoopMessageBase
    {

        public const int AnalogInputChangedAlarmFunctionCode = 54;

        /// <summary>
        /// Single byte for number of input analog values.
        /// </summary>
        public const int NumberOfAnalogValuesSize = 1;

        public AnalogInputChangedAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 4)
        {
        }

        /// <summary>
        /// Return maximum number of data parts (2 x bytes in an array) for this message.
        /// </summary>
        public const int MaximumDataLength = (MaximumDataBytesToController - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfAnalogValuesSize)) / 2;

        /// <summary>
        /// This constructor can be used for sending analog values alarms inputs
        /// </summary>
        /// <param name="ownerType">Input owner type.</param>
        /// <param name="startingPoint">The input point number on parent. Starting with 0.</param>
        /// <param name="analogValues">Input analog values.</param>
        public AnalogInputChangedAlarm(OwnerType ownerType, int startingPoint, int[] analogValues)
        {
            int bytesRequiredForData = analogValues.Length * 2;
            bytesRequiredForData = Math.Min(bytesRequiredForData, MaximumDataLength * 2);

            Data = new byte[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfAnalogValuesSize + bytesRequiredForData];
            FunctionCode = AnalogInputChangedAlarmFunctionCode;

            Length = Data.Length;

            Data[OwnerTypeSize] = (byte)ownerType;
            Data[OwnerTypeSize + StartingPointSize] = (byte)startingPoint;
            Data[OwnerTypeSize + StartingPointSize + NumberOfAnalogValuesSize] = (byte)(bytesRequiredForData / 2);

            for (int byteIndex = 0; byteIndex < (bytesRequiredForData / 2); byteIndex++)
            {
                int index = FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfAnalogValuesSize;
                Data[index + (byteIndex * 2)] = (byte)((analogValues[byteIndex] & 0x0300) >> 8);
                Data[index + (byteIndex * 2) + 1] = (byte)(analogValues[byteIndex] & 0xFF);
            }
        }

        public void GetAnalogValues(out OwnerType ownerType, out int startingPoint, out int[] analogValues)
        {
            ownerType = (OwnerType)Data[Offset + FunctionCodeSize];
            startingPoint = Data[Offset + FunctionCodeSize + OwnerTypeSize];
            int numberOfInputs = Data[Offset + FunctionCodeSize + OwnerTypeSize + NumberOfAnalogValuesSize];
            analogValues = new int[numberOfInputs];
            for (int byteIndex = 0; byteIndex < numberOfInputs; byteIndex++)
            {
                int index = Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfAnalogValuesSize + (byteIndex * 2);
                byte high = Data[index];
                byte low = Data[index + 1];
                analogValues[byteIndex] = (int)((high << 8) + low);
            }
        }

        public override string ToString()
        {
            OwnerType ownerType;
            int startingPoint;
            int[] analogValues;
            GetAnalogValues(out ownerType, out startingPoint, out analogValues);
            StringBuilder descString = new StringBuilder();
            descString.Append("Send Inputs Analog Values, Owner:");
            descString.Append(ownerType.ToString());
            descString.Append(", StartingPoint:");
            descString.Append(startingPoint.ToString());
            descString.Append(", NumberOfInputs:");
            descString.Append(analogValues.Length.ToString());
            descString.Append(" (");
            for (int i = 0; i < analogValues.Length; i++)
            {
                if (i > 0)
                    descString.Append("-");
                descString.Append(analogValues[i].ToString());
            }
            descString.Append(")");
            return descString.ToString();
        }

#if COMMUNICATIONSANALYZER

        public AnalogInputChangedAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { AnalogInputChangedAlarmFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return "Inputs Analog Values";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
