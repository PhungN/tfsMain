﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    /// <summary>
    /// Handles request and response with raw unauthorized card data stream payload.
    /// </summary>
    public class CardReaderUnauthorizedCardDataRawSendAlarm : CardReaderCardDataRawSendAlarmBase
    {
        public const byte Reader1FunctionCode = 74;
        public const byte Reader2FunctionCode = 75;
        public const byte Reader3FunctionCode = 76;
        public const byte Reader4FunctionCode = 77;

        public CardReaderUnauthorizedCardDataRawSendAlarm(byte[] data, int offset, int length)
            : base(Reader1FunctionCode, Reader2FunctionCode, Reader3FunctionCode, Reader4FunctionCode, data, offset, length)
        {
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber">Card reader number</param>
        /// <param name="config">Request configuration</param>
        public CardReaderUnauthorizedCardDataRawSendAlarm(CardReaderPortType readerNumber, CardReaderDataSendDataRawConfig config) :
            base(Reader1FunctionCode, Reader2FunctionCode, Reader3FunctionCode, Reader4FunctionCode, readerNumber, config)
        {
        }

#if COMMUNICATIONSANALYZER
        public CardReaderUnauthorizedCardDataRawSendAlarm() : base()
        {
        }
#endif

    }
}
