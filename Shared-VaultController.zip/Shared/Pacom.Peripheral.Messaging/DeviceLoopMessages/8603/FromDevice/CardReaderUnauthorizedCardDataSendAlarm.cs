﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    public class CardReaderUnauthorizedCardDataSendAlarm : CardReaderCardDataSendAlarmBase
    {
        public const byte Reader1FunctionCode = 70;
        public const byte Reader2FunctionCode = 71;
        public const byte Reader3FunctionCode = 72;
        public const byte Reader4FunctionCode = 73;

        /// <summary>
        /// Parse "CardDataSend" device loop message.
        /// </summary>
        /// <param name="data">Byte array with device loop message.</param>
        /// <param name="offset">Offset is used to indicate position of function code in the byte array.</param>
        /// <param name="length">Length of data from function code to the end of array or check code.</param>
        public CardReaderUnauthorizedCardDataSendAlarm(byte[] data, int offset, int length)
            : base(Reader1FunctionCode, Reader2FunctionCode, Reader3FunctionCode, Reader4FunctionCode, data, offset, length)
        {
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public CardReaderUnauthorizedCardDataSendAlarm(CardReaderPortType readerNumber, CardReaderDataSendDataConfig config)
            : base(Reader1FunctionCode, Reader2FunctionCode, Reader3FunctionCode, Reader4FunctionCode, readerNumber, config)
        {
        }

#if COMMUNICATIONSANALYZER

        public CardReaderUnauthorizedCardDataSendAlarm() : base()
        {
        }

#endif

    }
}
