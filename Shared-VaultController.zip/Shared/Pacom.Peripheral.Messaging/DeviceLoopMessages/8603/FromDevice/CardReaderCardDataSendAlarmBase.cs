﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    public class CardReaderCardDataSendAlarmBase : DeviceLoopMessageBase
    {
        private readonly byte Reader1FunctionCode;
        private readonly byte Reader2FunctionCode;
        private readonly byte Reader3FunctionCode;
        private readonly byte Reader4FunctionCode;

        /// <summary>
        /// Parse "CardDataSend" device loop message.
        /// </summary>
        /// <param name="data">Byte array with device loop message.</param>
        /// <param name="offset">Offset is used to indicate position of function code in the byte array.</param>
        /// <param name="length">Length of data from function code to the end of array or check code.</param>
        public CardReaderCardDataSendAlarmBase(byte reader1FunctionCode, byte reader2FunctionCode, byte reader3FunctionCode, byte reader4FunctionCode, byte[] data, int offset, int length)
            : base(data, offset, length, 9)
        {
            Reader1FunctionCode = reader1FunctionCode;
            Reader2FunctionCode = reader2FunctionCode;
            Reader3FunctionCode = reader3FunctionCode;
            Reader4FunctionCode = reader4FunctionCode;
        }

        /// <summary>
        /// Property that Returns the reader type for this device access control message
        /// </summary>
        public CardReaderType ReaderType
        {
            get { return (CardReaderType)Data[Offset + 1]; }
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public CardReaderCardDataSendAlarmBase(byte reader1FunctionCode, byte reader2FunctionCode, byte reader3FunctionCode, byte reader4FunctionCode, CardReaderPortType readerNumber, CardReaderDataSendDataConfig config)
        {
            Reader1FunctionCode = reader1FunctionCode;
            Reader2FunctionCode = reader2FunctionCode;
            Reader3FunctionCode = reader3FunctionCode;
            Reader4FunctionCode = reader4FunctionCode;
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            if (config.Format == 0)
            {
                // Function code + Card type + 8 bytes card data
                this.Data = new byte[10];
            }
            else
            {
                // Function code + Card type + 8 bytes card data + format index
                this.Data = new byte[11];
            }

            switch (readerNumber)
            {
                case CardReaderPortType.CardReader1:
                    this.FunctionCode = Reader1FunctionCode;
                    break;
                case CardReaderPortType.CardReader2:
                    this.FunctionCode = Reader2FunctionCode;
                    break;
                case CardReaderPortType.CardReader3:
                    this.FunctionCode = Reader3FunctionCode;
                    break;
                case CardReaderPortType.CardReader4:
                    this.FunctionCode = Reader4FunctionCode;
                    break;
                default:
                    throw new ArgumentException("Invalid reader number.");
            }

            constructCardDataSendCommand(config);
            this.Length = this.Data.Length;
        }

        private void constructCardDataSendCommand(CardReaderDataSendDataConfig config)
        {
            this.Data[this.Offset + 1] = (byte)(config.ReaderType);
            for (int bitNumber = 0; bitNumber < 64; bitNumber++)
            {
                int byteCount = (bitNumber / 8);
                int byteData = this.Offset + 2 + byteCount;
                int bitData = bitNumber - (byteCount * 8);
                if ((bitNumber >= 0) &&
                        (bitNumber < (config.Designators.Facility)))
                {
                    int byteFacility = bitNumber / 8;
                    int bitFacility = bitNumber - (byteFacility * 8);
                    if (((config.Facility != null) &&
                            config.Facility.Length > byteFacility) &&
                                ((config.Facility[config.Facility.Length - byteFacility - 1] & (1 << bitFacility)) != 0))
                    {
                        this.Data[byteData] |= (byte)(1 << bitData);
                    }
                }
                else if ((bitNumber >= (config.Designators.Facility)) &&
                           (bitNumber < ((config.Designators.Facility) + (config.Designators.Issue))))
                {
                    int byteIssue = (bitNumber - (config.Designators.Facility)) / 8;
                    int bitIssue = (bitNumber - (config.Designators.Facility)) - (byteIssue * 8);
                    if (((config.Issue != null) &&
                            config.Issue.Length > byteIssue) &&
                                ((config.Issue[config.Issue.Length - byteIssue - 1] & (1 << bitIssue)) != 0))
                    {
                        this.Data[byteData] |= (byte)(1 << bitData);
                    }
                }
                else if ((bitNumber >= ((config.Designators.Facility) + (config.Designators.Issue))) &&
                            (bitNumber < ((config.Designators.Facility) + (config.Designators.Issue) + (config.Designators.Code))))
                {
                    int byteCode = (bitNumber - (config.Designators.Issue) - (config.Designators.Facility)) / 8;
                    int bitCode = (bitNumber - (config.Designators.Issue) - (config.Designators.Facility)) - (byteCode * 8);
                    if (((config.Code != null) &&
                            config.Code.Length > byteCode) &&
                                ((config.Code[config.Code.Length - byteCode - 1] & (1 << bitCode)) != 0))
                    {
                        this.Data[byteData] |= (byte)(1 << bitData);
                    }
                }
            }

            if (config.Format != 0)
            {
                // array should be already setup above
                // Format 1..4 are these included in card data send message
                this.Data[this.Offset + 10] = (byte)(config.Format - 1);
            }
        }

        private CardReaderPortType getCardReader()
        {
            byte fc = this.Data[this.Offset];
            if (fc == Reader1FunctionCode)
                return CardReaderPortType.CardReader1;
            else if (fc == Reader2FunctionCode)
                return CardReaderPortType.CardReader2;
            else if (fc == Reader3FunctionCode)
                return CardReaderPortType.CardReader3;
            else if (fc == Reader4FunctionCode)
                return CardReaderPortType.CardReader4;
            else
                return CardReaderPortType.NoReader;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public bool GetConfiguration(CardFormatDesignatorConfig designator, out CardReaderPortType readerNumber, out CardReaderDataSendDataConfig config)
        {
            if (this.Data.Length < 10)
            {
                readerNumber = CardReaderPortType.NoReader;
                config = null;
                return false;
            }
            readerNumber = getCardReader();
            if (readerNumber == CardReaderPortType.NoReader)
            {
                config = null;
                return false;
            }
            config = parseCardDataSendCommand(designator);
            return true;
        }

        private CardReaderDataSendDataConfig parseCardDataSendCommand(CardFormatDesignatorConfig designator)
        {
            int cfgOffset = this.Offset + 1;

            CardReaderDataSendDataConfig config = new CardReaderDataSendDataConfig();
            // get type
            config.ReaderType = (CardReaderType)Enum.Parse(typeof(CardReaderType), this.Data[cfgOffset].ToString(), true);
            // Copy designator values
            config.Designators.Facility = designator.Facility;
            config.Designators.Issue = designator.Issue;
            // Allocate byte array for data
            if (config.Designators.Facility > 0)
            {
                config.Facility = new byte[(config.Designators.Facility / 8)];
            }
            if (config.Designators.Issue > 0)
            {
                config.Issue = new byte[(config.Designators.Issue / 8)];
            }
            if (config.Designators.Code > 0)
            {
                config.Code = new byte[(config.Designators.Code / 8)];
            }
            // Scan upcomming data and read card records
            for (int bitNumber = 0; bitNumber < 64; bitNumber++)
            {
                int byteCount = (bitNumber / 8);
                int byteData = this.Offset + 2 + byteCount;

                if ((bitNumber >= 0) &&
                        (bitNumber < (config.Designators.Facility)))
                {
                    int byteFacility = bitNumber / 8;
                    int bitFacility = bitNumber - (byteFacility * 8);
                    if ((this.Data[byteData] & (1 << bitFacility)) != 0)
                    {
                        config.Facility[config.Facility.Length - byteFacility - 1] |= (byte)(1 << bitFacility);
                    }
                }
                else if ((bitNumber >= (config.Designators.Facility)) &&
                           (bitNumber < ((config.Designators.Facility) + (config.Designators.Issue))))
                {
                    int byteIssue = (bitNumber - (config.Designators.Facility)) / 8;
                    int bitIssue = (bitNumber - (config.Designators.Facility)) - (byteIssue * 8);
                    if ((this.Data[byteData] & (1 << bitIssue)) != 0)
                    {
                        config.Issue[config.Issue.Length - byteIssue - 1] |= (byte)(1 << bitIssue);
                    }
                }
                else if ((bitNumber >= ((config.Designators.Facility) + (config.Designators.Issue))) &&
                            (bitNumber < ((config.Designators.Facility) + (config.Designators.Issue) + (config.Designators.Code))))
                {
                    int byteCode = (bitNumber - (config.Designators.Issue) - (config.Designators.Facility)) / 8;
                    int bitCode = (bitNumber - (config.Designators.Issue) - (config.Designators.Facility)) - (byteCode * 8);
                    if ((this.Data[byteData] & (1 << bitCode)) != 0)
                    {
                        config.Code[config.Code.Length - byteCode - 1] |= (byte)(1 << bitCode);
                    }
                }

            }
            // Extract card format
            if (this.Data.Length == 10)
            {
                config.Format = 0;
            }
            else if (this.Data.Length == 11)
            {
                // Format 0 is reserved for initialization record
                // Format 1..4 are these included in card data send message
                config.Format = this.Data[10] + 1;
            }
            return config;
        }

        public byte[] GetCardNumberData(out int cardFormat, out CardReaderPortType readerNumber)
        {
            readerNumber = getCardReader();
            const int CardNumberLengthInBytes = 8;
            byte[] dataBuffer = new byte[CardNumberLengthInBytes];
            Buffer.BlockCopy(Data, Offset + 2, dataBuffer, 0, CardNumberLengthInBytes);
            cardFormat = 0;
            if (Data.Length == 11)
            {
                // Format 0 is reserved for initialization record
                // Format 1..4 are these included in card data send message
                cardFormat = Data[10] + 1;
            }
            return dataBuffer;
        }

        public override string ToString()
        {
            return "Card Reader Card Data Send";
        }

#if COMMUNICATIONSANALYZER

        public CardReaderCardDataSendAlarmBase()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { 
                Reader1FunctionCode, Reader2FunctionCode,
                Reader3FunctionCode, Reader4FunctionCode
            }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
