﻿using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // Send changes from up to eight analog inputs.
    // The message format is:
    // 0C, INP, ALM, ..., INP_N, ALM_N
    // INP = input number to be reported
    // ALM = analog input status. 
    // Note that for the 8603 it is a 16 bit little endian value 
    // (as the on board ADC are 10 bits the values are adjusted to 16 bits).
    // The analog input value needs to be shifted by 6 bits to the x.
    public class LegacyAnalogInputChangedAlarm : DeviceLoopMessageBase
    {
        public const int LegacyAnalogInputChangedAlarmFunctionCode = 60;

        public LegacyAnalogInputChangedAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 4)
        {
        }

        public LegacyAnalogInputChangedAlarm(AnalogInputPoint[] inputs)
        {
            Data = new byte[1 + (inputs.Length * 3)];
            Length = Data.Length;
            FunctionCode = LegacyAnalogInputChangedAlarmFunctionCode;
            int adcReading;

            for (int i = 0; i < inputs.Length; i++)
            {
                Data[(i * 3) + 1] = (byte)inputs[i].InputPointNumber;
                // Left shifting by 6 is required by the controller
                adcReading = inputs[i].Value << 6;
                Data[(i * 3) + 2] = (byte)(adcReading & 0xFF);
                Data[(i * 3) + 3] = (byte)(adcReading >> 8);
            }
        }

        public AnalogInputPoint[] GetAnalogInputs()
        {
            AnalogInputPoint[] inputs = new AnalogInputPoint[(Length - 1) / 3];

            for (int i = 0; i < inputs.Length; i++)
            {
                inputs[i] = new AnalogInputPoint(Data[Offset + (i * 3) + 1], ((Data[Offset + (i * 3) + 3] << 8) + Data[Offset + (i * 3) + 2]) >> 6);
            }

            return inputs;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder("Analog Input Changed (");
            AnalogInputPoint[] inputs = GetAnalogInputs();
            int i = 0;
            string format = "Input {0} {1}, ";
            foreach (AnalogInputPoint input in inputs)
            {
                if (i == inputs.Length - 1)
                    format = "Input {0} {1})";
                sb.AppendFormat(format, input.InputPointNumber, input.Value);
                i++;
            }
            return sb.ToString();
        }

#if COMMUNICATIONSANALYZER

        public LegacyAnalogInputChangedAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { LegacyAnalogInputChangedAlarmFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return "Analog Input Changed";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
