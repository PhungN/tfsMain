using Pacom.Peripheral.Common;
using System;
using System.Text;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    /// Send changed state of onboard/expansion card inputs (S-ART included). This message should be used instead of the LegacyInputChangedStateAlarm
    // when sending alarms from any input (on board, input expansion cards or S-ART cards). This message also handles the masking and range reduction 
    // states required by on board and input expansion cards. This message only sends one input at a time.
    // The message format is:
    // 53, OWNERTYPE, STARTINGPOINT, NUMBEROFINPUTS, STATUS_1 , ... , STATUS_N
    //
    // Valid alarm states are:
    // 00 - Secure
    // 01 - Alarm
    // 02 - Short circuit
    // 03 - Open circuit
    // 04 - Trouble
    // 07 - Masking
    // 08 - RangeReduction
    // 09 - MaskingAndRangeReduction
    // 10 - AlarmAndMasking
    // 11 - AlarmAndRangeReduction
    // 12 - AlarmAndMaskingAndRangeReduction
    // N.B.: For S-ART card inputs any value >= 04 will be sent as Trouble.
    /// Each alarm state is reported using the higher nibble of the ALARM/ALARM_AND_ADC_HI_ULMODEL byte.
    public class InputsChangedStateAlarm : DeviceLoopMessageBase
    {

        public const int InputsChangedStateAlarmFunctionCode = 53;

        /// <summary>
        /// Single byte for number of inputs.
        /// </summary>
        public const int NumberOfInputsSize = 1;

        public InputsChangedStateAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 2)
        {
        }

        /// <summary>
        /// Return maximum number of data parts (int types in an array) for this message.
        /// </summary>
        public const int MaximumDataLength = (MaximumDataBytesToController - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize)) * 2;

        /// <summary>
        /// This constructor can be used for sending alarms for any S-ART card inputs
        /// </summary>
        /// <param name="ownerType">Input owner type.</param>
        /// <param name="startingPoint">The input point number on parent. Starting from 0.</param>
        /// <param name="inputsStatus">Input status.</param>
        public InputsChangedStateAlarm(OwnerType ownerType, int startingPoint, InputStatus[] inputsStatus)
        {
            int bytesRequiredForData = inputsStatus.Length / 2;
            if (inputsStatus.Length != 0 && (inputsStatus.Length % 2) > 0)
                bytesRequiredForData++;

            bytesRequiredForData = Math.Min(bytesRequiredForData, MaximumDataLength / 2);

            Data = new byte[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + bytesRequiredForData];
            FunctionCode = InputsChangedStateAlarmFunctionCode;

            Data[OwnerTypeSize] = (byte)ownerType;
            Data[OwnerTypeSize + StartingPointSize] = (byte)startingPoint;
            Data[OwnerTypeSize + StartingPointSize + NumberOfInputsSize] = (byte)inputsStatus.Length;

            for (int byteIndex = 0; byteIndex < bytesRequiredForData; byteIndex++)
            {
                byte inputStatusField = 0;
                for (int nibbleIndex = 0; nibbleIndex < 2; nibbleIndex++)
                {
                    int arrayIndex = (byteIndex * 2) + nibbleIndex;
                    if (inputsStatus.Length <= arrayIndex)
                        break;

                    byte nibble = (byte)inputsStatus[arrayIndex];
                    int shiftBy = nibbleIndex == 1 ? 4 : 0;
                    inputStatusField |= (byte)(nibble << shiftBy);
                }
                Data[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + byteIndex] = inputStatusField;
            }
            Length = Data.Length;
        }

        public void GetInputStates(out OwnerType ownerType, out int startingPoint, out InputStatus[] inputsStatus)
        {
            ownerType = (OwnerType)Data[Offset + FunctionCodeSize];
            startingPoint = Data[Offset + FunctionCodeSize + OwnerTypeSize];
            int numberOfInputs = Data[Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize];
            inputsStatus = new InputStatus[numberOfInputs];

            for (int byteIndex = 0; byteIndex < (Length - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize)); byteIndex++)
            {
                byte data = Data[Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + byteIndex];
                for (int nibbleIndex = 0; nibbleIndex < 2; nibbleIndex++)
                {
                    int arrayIndex = (byteIndex * 2) + nibbleIndex;
                    if (arrayIndex < numberOfInputs)
                    {
                        byte mask = (byte)(nibbleIndex == 0 ? 0x0F : 0xF0);
                        int shiftBy = nibbleIndex == 0 ? 0 : 4;
                        inputsStatus[arrayIndex] = (InputStatus)((data & mask) >> shiftBy);
                    }
                }
            }
        }

        public override string ToString()
        {
            OwnerType ownerType;
            int startingPoint;
            InputStatus[] inputsStatus;
            GetInputStates(out ownerType, out startingPoint, out inputsStatus);

            StringBuilder descString = new StringBuilder();
            descString.Append("Send Inputs Status for, Owner:");
            descString.Append(ownerType.ToString());
            descString.Append(", StartingPoint:");
            descString.Append(startingPoint.ToString());
            descString.Append(", NumberOfInputs:");
            descString.Append(inputsStatus.Length.ToString());
            descString.Append(" (");
            for (int i = 0; i < inputsStatus.Length; i++)
            {
                if (i > 0)
                    descString.Append("-");
                descString.Append(inputsStatus[i].ToString());
            }
            descString.Append(")");
            return descString.ToString();
        }

#if COMMUNICATIONSANALYZER

        public InputsChangedStateAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { InputsChangedStateAlarmFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return "Inputs Status";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
