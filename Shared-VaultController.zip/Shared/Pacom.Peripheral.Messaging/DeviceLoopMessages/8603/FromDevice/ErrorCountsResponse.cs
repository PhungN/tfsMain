﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // When the error counts have been requested the error counts are returned with this code. 
    // The message format is:
    // 03, ERRORS
    // ERRORS is a list of one byte error counts in the following order:
    // - Parity errors
    // - Checksum errors
    // - Invalid function code or data errors
    // - Contention mode timeouts
    public class ErrorCountsResponse : DeviceLoopMessageBase
    {
        public const int ErrorCountsResponseFunctionCode = 5;

        public ErrorCountsResponse(byte[] data, int offset, int length)
            : base(data, offset, length, 5)
        {
        }

        public ErrorCountsResponse(int parityErrors, int checksumErrors, int dataErrors, int contentionTimeouts)
        {
            Data = new byte[5];
            FunctionCode = ErrorCountsResponseFunctionCode;

            Data[1] = (byte)parityErrors;
            Data[2] = (byte)checksumErrors;
            Data[3] = (byte)dataErrors;
            Data[4] = (byte)contentionTimeouts;
            Length = 5;
        }

        public int ParityErrors
        {
            get
            {
                return Data[Offset + 1];
            }
        }

        public int ChecksumErrors
        {
            get
            {
                return Data[Offset + 2];
            }
        }

        public int DataErrors
        {
            get
            {
                return Data[Offset + 3];
            }
        }

        public int ContentionTimeouts
        {
            get
            {
                return Data[Offset + 4];
            }
        }

        public override string ToString()
        {
            return "Error Counts Response (Parity Errors : " + ParityErrors + ", Checksum Errors : " + ChecksumErrors + ", Data Errors : " + DataErrors + ", Contention Timeouts : " + ContentionTimeouts + ").";
        }

#if COMMUNICATIONSANALYZER

        public ErrorCountsResponse()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { ErrorCountsResponseFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return "Error Counts Response";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
