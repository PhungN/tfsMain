using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    /// <summary>
    /// Send event message to the controller with raw card information. Events are collected during degraded mode
    /// and send to the controller after going online.
    /// </summary>
    public class CardReaderEventMessageRawAlarm : DeviceLoopMessageBase
    {
        public const int CardReaderEventMessageRawAlarmFunctionCode = 52;

        /// <summary>
        /// Parse "EventMessage" device loop message.
        /// </summary>
        /// <param name="data">Byte array with device loop message.</param>
        /// <param name="offset">Offset is used to indicate position of function code in the byte array.</param>
        /// <param name="length">Length of data from function code to the end of array or check code.</param>
        public CardReaderEventMessageRawAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 7)
        {
        }

        /// <summary>
        /// Format device loop mesage from CardReaderEventRawData class
        /// </summary>
        /// <param name="eventData">CardData must not be byte[0]. CardLength must be > 0.</param>
        public CardReaderEventMessageRawAlarm(CardReaderEventRawDataConfig eventData)
        {
            if (eventData == null)
                throw new ArgumentNullException("eventData", "eventData must not be null.");
            if (eventData.CardData == null)
                throw new ArgumentNullException("eventData.CardData", "eventData.CardData must not be null.");
            if (eventData.CardLength <= 0)
                throw new ArgumentException("Card length must not be zero or negative.", "eventData.CardLength");
            if (eventData.CardData.Length <= 0)
                throw new ArgumentException("Card Data length must not be zero.", "eventData.CardData.Length");
            this.Data = new byte[6 + DeviceLoopUtils.GetByteArrayLengthFromBits(eventData.CardLength)];
            this.FunctionCode = CardReaderEventMessageRawAlarmFunctionCode;
            constructEventMessageCommand(eventData);
            this.Length = this.Data.Length;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public bool GetConfiguration(out CardReaderEventRawDataConfig eventData)
        {
            eventData = parseEventMessageCommand();
            if (eventData != null)
                return true;
            else
                return false;
        }

        /// <summary>
        /// Construct raw format degraded event message.
        /// </summary>
        /// <param name="eventData"></param>
        private void constructEventMessageCommand(CardReaderEventRawDataConfig eventData)
        {
            this.Data[this.Offset + 1] = eventData.Second;
            this.Data[this.Offset + 2] = eventData.Minute;
            this.Data[this.Offset + 3] = (byte)(eventData.DayOfWeek << 5);
            this.Data[this.Offset + 3] |= (byte)(eventData.Hour & 0x1F);
            if (eventData.ReaderNumber == CardReaderPortType.CardReader1)
                this.Data[this.Offset + 4] = 0;
            else if (eventData.ReaderNumber == CardReaderPortType.CardReader2)
                this.Data[this.Offset + 4] = 1;
            else if (eventData.ReaderNumber == CardReaderPortType.CardReader3)
                this.Data[this.Offset + 4] = 2;
            else if (eventData.ReaderNumber == CardReaderPortType.CardReader4)
                this.Data[this.Offset + 4] = 3;
            if (eventData.AccessDenied == true)
                this.Data[this.Offset + 4] |= 0x80;
            this.Data[this.Offset + 5] = (byte) (eventData.CardLength - 1);
            DeviceLoopUtils.ConstructRawCardData(ref eventData, (index, data) =>
            {
                this.Data[Offset + 6 + index] = data;
            });
        }

        /// <summary>
        /// Parse raw format degraded event message.
        /// </summary>
        /// <returns></returns>
        private CardReaderEventRawDataConfig parseEventMessageCommand()
        {
            if (this.Data.Length < 7)
                return null;
            CardReaderEventRawDataConfig eventData = new CardReaderEventRawDataConfig();
            eventData.Second = this.Data[this.Offset + 1];
            eventData.Minute = this.Data[this.Offset + 2];
            eventData.Hour = (byte)(this.Data[this.Offset + 3] & 0x1F);
            eventData.DayOfWeek = (byte)(this.Data[this.Offset + 3] >> 5);
            if ((this.Data[this.Offset + 4] & 0x7F) == 0)
                eventData.ReaderNumber = CardReaderPortType.CardReader1;
            else if ((this.Data[this.Offset + 4] & 0x7F) == 1)
                eventData.ReaderNumber = CardReaderPortType.CardReader2;
            else if ((this.Data[this.Offset + 4] & 0x7F) == 2)
                eventData.ReaderNumber = CardReaderPortType.CardReader3;
            else if ((this.Data[this.Offset + 4] & 0x7F) == 3)
                eventData.ReaderNumber = CardReaderPortType.CardReader4;
            if ((this.Data[this.Offset + 4] & 0x80) == 0x80)
                eventData.AccessDenied = true;
            else
                eventData.AccessDenied = false;
            eventData.CardLength = this.Data[this.Offset + 5] + 1;
            if (eventData.CardLength <= 0)
                eventData.CardData = new byte[0];
            else
                DeviceLoopUtils.ParseRawCardData(ref eventData, Offset + 6, Data);
            return eventData;
        }

        public override string ToString()
        {
            return "Card Reader Raw Event Message";
        }

#if COMMUNICATIONSANALYZER

        public CardReaderEventMessageRawAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { CardReaderEventMessageRawAlarmFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            CardReaderEventRawDataConfig eventData;
            StringBuilder sb = new StringBuilder();
            sb.Append(this.ToString());
            sb.Append(System.Environment.NewLine);
            if (GetConfiguration(out eventData))
            {
                sb.Append(System.Environment.NewLine);
                sb.Append(string.Format("Card Reader: {0}{1}", eventData.ReaderNumber.ToString(), System.Environment.NewLine));
                sb.Append(string.Format("Event week day: {0}{1}", eventData.DayOfWeek.ToString(), System.Environment.NewLine));
                sb.Append(string.Format("Event time: {0}:{1}:{2}{3}",
                    eventData.Hour.ToString(), eventData.Minute.ToString(), eventData.Second.ToString(), System.Environment.NewLine));
                sb.Append(string.Format("Access is {0}{1}", eventData.AccessDenied ? "Denied" : "Granted", System.Environment.NewLine));
                sb.Append(string.Format("Card length: {0}{1}", eventData.CardLength, System.Environment.NewLine));
                sb.Append(string.Format("Card data: {0}{1}", BitConverter.ToString(eventData.CardData), System.Environment.NewLine));
            }
            else
            {
                sb.Append("Unable to parse command.");
            }
            return sb.ToString();
        }

#endif
    }
}
