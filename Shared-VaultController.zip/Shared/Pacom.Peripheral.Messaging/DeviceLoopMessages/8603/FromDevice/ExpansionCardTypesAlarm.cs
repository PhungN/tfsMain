﻿using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // Expansion types from currently detected expansion cards.
    // The message format is:
    // 50, STS_1, ..., STS_N
    // STS_X = Type of the expansion card X.
    // 0x04 = ALARM_CARD_TYPE
	// 0x05 = SART_CARD_TYPE
	// 0x06 = OUTPUT_CARD_TYPE
	// 0x09 = STAR_COUPLER_CARD_TYPE
	// 0x0C = GPRS_CARD_TYPE
	// 0x0D = MODEM_CARD_TYPE
	// 0x0E = RS232_RS485_CARD_TYPE
    // 0xFF = EMPTY_CARD_TYPE
    //
    public class ExpansionCardTypesAlarm : DeviceLoopMessageBase
    {
        public const int ExpansionCardTypesAlarmFunctionCode = 50;

        public ExpansionCardTypesAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 2)
        {
        }

        public ExpansionCardTypesAlarm(ExpansionCardType[] expansionCardTypes)
        {
            Data = new byte[1 + expansionCardTypes.Length];
            Length = Data.Length;
            FunctionCode = ExpansionCardTypesAlarmFunctionCode;

            for (int i = 0; i < expansionCardTypes.Length; i++)
            {
                switch (expansionCardTypes[i])
                {
                    case ExpansionCardType.Pacom8204InputCard:
                        Data[i + 1] = 0x04;
                        break;
                    case ExpansionCardType.Pacom8208SartInputOutputCard:
                        Data[i + 1] = 0x05;
                        break;
                    case ExpansionCardType.Pacom8203OutputCard:
                        Data[i + 1] = 0x06;
                        break;
                    case ExpansionCardType.Pacom8201GprsCard:
                        Data[i + 1] = 0x0C;
                        break;
                    case ExpansionCardType.Pacom8205SerialCard:
                        Data[i + 1] = 0x0E;
                        break;
                    case ExpansionCardType.Pacom8207StarCouplerCard:
                        Data[i + 1] = 0x09;
                        break;
                    case ExpansionCardType.Pacom8209PstnCard:
                        Data[i + 1] = 0x0D;
                        break;
                    default:
                        Data[i + 1] = 0xFF;
                        break;
                }
            }
        }

        public ExpansionCardType[] GetExpansionCardTypes()
        {
            ExpansionCardType[] expansionCardTypes = new ExpansionCardType[Length - 1];
            for (int i = 0; i < expansionCardTypes.Length; i++)
            {
                switch (Data[Offset + 1 + i])
                {
                    case 0x04:
                        expansionCardTypes[i] = ExpansionCardType.Pacom8204InputCard;
                        break;
                    case 0x05:
                        expansionCardTypes[i] = ExpansionCardType.Pacom8208SartInputOutputCard;
                        break;
                    case 0x06:
                        expansionCardTypes[i] = ExpansionCardType.Pacom8203OutputCard;
                        break;
                    case 0x0C:
                        expansionCardTypes[i] = ExpansionCardType.Pacom8201GprsCard;
                        break;
                    case 0x0E:
                        expansionCardTypes[i] = ExpansionCardType.Pacom8205SerialCard;
                        break;
                    case 0x09:
                        expansionCardTypes[i] = ExpansionCardType.Pacom8207StarCouplerCard;
                        break;
                    case 0x0D:
                        expansionCardTypes[i] = ExpansionCardType.Pacom8209PstnCard; 
                        break;
                    default:
                        expansionCardTypes[i] = ExpansionCardType.None;
                        break;
                }
            }
            return expansionCardTypes;
        }

        public override string ToString()
        {
            string message = "Expansion Card Types (";
            ExpansionCardType[] expansionCardTypes = GetExpansionCardTypes();
            foreach (ExpansionCardType expansionCardType in expansionCardTypes)
            {
                message += expansionCardType.ToString() + ", ";
            }
            message = message.Remove(message.Length - 2, 2);
            message += ")";
            return message;
        }

#if COMMUNICATIONSANALYZER

        public ExpansionCardTypesAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { ExpansionCardTypesAlarmFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
