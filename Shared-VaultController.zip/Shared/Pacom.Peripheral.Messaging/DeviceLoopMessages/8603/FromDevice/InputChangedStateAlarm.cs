using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Utilities;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    /// Send changed state of onboard/expansion card inputs (S-ART included). This message should be used instead of the LegacyInputChangedStateAlarm
    // when sending alarms from any input (on board, input expansion cards or S-ART cards). This message also handles the masking and range reduction 
    // states required by on board and input expansion cards. This message only sends one input at a time.
    // The message format is:
    // 51, OWNERTYPE, INPUT_NO, ALARM_AND_ADC_HI_ULMODEL, ADC_LOW
    //
    // Valid alarm states are:
    // 00 - Secure
    // 01 - Alarm
    // 02 - Short circuit
    // 03 - Open circuit
    // 04 - Trouble
    // 07 - Masking
    // 08 - RangeReduction
    // 09 - MaskingAndRangeReduction
    // 10 - AlarmAndMasking
    // 11 - AlarmAndRangeReduction
    // 12 - AlarmAndMaskingAndRangeReduction
    // N.B.: For S-ART card inputs any value >= 04 will be Trouble and the ADC_LOW and ADC_HI_ULMODEL will be 0.
    //
    // INPUT_NO - a byte that stores the id of the input point, for S-ART card this field is between 0 and 123.
    /// Each alarm state is reported using the higher nibble of the ALARM/ALARM_AND_ADC_HI_ULMODEL byte.
    public class InputChangedStateAlarm : DeviceLoopMessageBase
    {
        public const int InputChangedStateAlarmFunctionCode = 51;

        public InputChangedStateAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 2)
        {
        }

        /// <summary>
        /// This constructor can be used for sending alarms for any inputs on board or on any of the 8204 input expansion cards
        /// </summary>
        /// <param name="owner">Input's owner: Onboard, Expansion1,..,Expansion4.</param>
        /// <param name="inputId">The input point number on parent, e.g.: for on baord inputs is 0 - 15.</param>
        /// <param name="inputState">Input status</param>
        /// <param name="adcReading">Input resistance ADC reading in Ohm</param>
        /// <param name="ulModel">True if this device is UL model</param>
        public InputChangedStateAlarm(OwnerType owner, int inputId, InputStatus inputState, int adcReading, bool ulModel)
        {
            Data = new byte[5];
            Length = Data.Length;
            FunctionCode = InputChangedStateAlarmFunctionCode;
            Data[1] = (byte)owner;
            Data[2] = (byte)inputId;
            // Assign Input Status (Hi nibble), ADC Hi reading (Low nibble)
            Data[3] = (byte)(((int)inputState << 4) | ((adcReading & 0x0F00) >> 8));
            // Assign ADC Low reading
            Data[4] = (byte)(adcReading & 0xFF);
            if (ulModel)
            {
                // Assign UL model bit 3 of the ADC Hi nibble
                Data[3] |= 0x08;
            }
        }

        public OwnerType Owner
        {
            get { return (OwnerType)Data[Offset + 1]; }
        }

        public int InputId
        {
            get { return Data[Offset + 2]; }
        }

        public InputStatus InputState
        {
            get
            {
                return (InputStatus)((Data[Offset + 3] & 0xF0) >> 4);
            }
        }

        public int AdcReading
        {
            get
            {
                return (((Data[Offset + 3] & 0x07) << 8) | Data[Offset + 4]);
            }
        }

        public bool ULModel
        {
            get
            {
                if ((Data[Offset + 3] & 0x08) == 0)
                    return false;
                return true;
            }
        }

        private int inputResistance
        {
            get
            {
                int pullUpResistorValue = 10000;
                int currentLimitingResistorValue = 0;
                return CommonUtilities.AdcReadingToResistanceValue(AdcReading, 10, currentLimitingResistorValue, pullUpResistorValue);
            }
        }

        public override string ToString()
        {
            string message = string.Empty;
            message = string.Format("8603 {0} Input number {1} changed state to {2}", Owner.ToString(), InputId, InputState);
            if (Owner != OwnerType.Sart1)
                message = string.Format("{0} ({1} ohms)", message, inputResistance);
            return message;
        }

#if COMMUNICATIONSANALYZER

        public InputChangedStateAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { InputChangedStateAlarmFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
