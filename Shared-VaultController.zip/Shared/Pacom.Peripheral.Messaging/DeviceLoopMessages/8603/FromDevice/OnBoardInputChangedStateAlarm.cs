﻿using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    /// <summary>
    /// The current state of all 8 alarm inputs on the main board is returned. 
    /// The message format is:
    /// 01, ALM_1, ... , ALM_N
    /// Each alarm state for the inputs on the main board, is reported using four bits with inputs one and two reported in ALM_1, 
    ///     inputs three and four reported in ALM_2, up to inputs fifteen and sixteen reported in ALM_8.  
    ///     The lower numbered input of each pair is reported in the low nibble.  
    /// Valid alarm states for main board inputs are:
    ///     00 - Secure
    ///     01 - Alarm
    ///     02 - Short circuit
    ///     03 - Open circuit
    ///     04 - Trouble
    /// </summary>
    public class OnboardInputChangedStateAlarm : DeviceLoopMessageBase
    {

        public const int OnboardInputChangedStateAlarmFunctionCode = 1;

        public OnboardInputChangedStateAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 9)
        {
        }

        public OnboardInputChangedStateAlarm(InputStatus[] onboardInputs)
        {
            Data = new byte[9];
            Length = 9;
            FunctionCode = OnboardInputChangedStateAlarmFunctionCode;

            for (int i = 0; i < 8; i += 2)
            {
                Data[(i / 2) + 1] = (byte)((((byte)onboardInputs[i + 1]) << 4) + (byte)onboardInputs[i]);
            } 
        }

        public InputStatus[] GetInputStates()
        {
            InputStatus[] onboardInputs = new InputStatus[8];

            for (int i = 0; i < 4; i++)
            {
                onboardInputs[i * 2] = (InputStatus)(Data[Offset + 1 + i] & 0x0F);
                onboardInputs[(i * 2) + 1] = (InputStatus)((Data[Offset + 1 + i] & 0xF0) >> 4);
            }

            return onboardInputs;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder("On-Board Input Changed State (");
            InputStatus[] onboardInputs = GetInputStates();
            string format = "{0}-";
            for (int i = 0; i < 8; i++)
            {
                if (i == 7)
                    format = "{0})";
                sb.AppendFormat(format, onboardInputs[i].ToString());
            }
            return sb.ToString();
        }

#if COMMUNICATIONSANALYZER

        public OnboardInputChangedStateAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { OnboardInputChangedStateAlarmFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return "On-Board Input Changed State";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
