﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // The state of the unit's tamper switch is returned.  The message format is:
    // 02, TAMPER, READERSSTATUS
    // Bit zero of TAMPER gives the state of the switch. If it is one the switch is closed.
    // Bit one gives the state of the battery to the board. If it is one the supply is normal.
    // Bit two shows the state of the AC fail input. If it is one it is good.
    // Bit three shows no battery detected when one.
    // Bit four is set when the charger has failed, cleared when OK
    // 
    // 0000000X	Battery low     AC Fail
    // 0000001X	Battery normal  AC Fail
    // 0000010X	Battery low     AC Good
    // 0000011X	Battery normal  AC Good
    // 0000100X	Battery missing AC Fail
    // 0000101X	Battery missing AC Fail
    // 0000110X	Battery missing AC Good
    // 0000111X	Battery missing AC Good
    // 0001XXXX Charger failed
    // 001XXXXX AC Low
    //
    // READERSSTATUS: 
    //  
    // Bit 0 = Card reader 1 status, 0 = online, 1 = offline*
    // Bit 1 = Card reader 1 tamper status, 0 = reset, 1 = alarm*
    // Bit 2 = Card reader 2 status, 0 = online, 1 = offline*
    // Bit 3 = Card reader 2 tamper status, 0 = reset, 1 = alarm*
    // Bit 4 = Card reader 3 status, 0 = online, 1 = offline*
    // Bit 5 = Card reader 3 tamper status, 0 = reset, 1 = alarm*
    // Bit 6 = Card reader 4 status, 0 = online, 1 = offline*
    // Bit 7 = Card reader 4 tamper status, 0 = reset, 1 = alarm*
    //
    // * if status bit is not supported, it will report as 0 (zero).
    //
    public class TamperOrPowerChangedStateAlarm : DeviceLoopMessageBase
    {
        public const int TamperOrPowerChangedStateAlarmFunctionCode = 2;

        private const int tamperSecure = 1;
        private const int batteryOk = 2;
        private const int acPowerOk = 4;
        private const int batteryMissing = 8;
        private const int chargerFail = 16;
        private const int acPowerLow = 32;

        public TamperOrPowerChangedStateAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 2)
        {
        }

        /// <summary>
        /// Construct response to controller about device\reader tamper and power status.
        /// </summary>
        /// <param name="tamperActive">Device tamper status. True if tamper is active</param>
        /// <param name="powerSupplyStatus">Status of power supply attached to the device</param>
        /// <param name="readerStatus">Array of 4 elements representing reader status. Index 0 is for reader 1, 1 is for reader 2, etc.</param>
        public TamperOrPowerChangedStateAlarm(bool tamperActive, PowerSupplyStatus powerSupplyStatus, ReaderOnlineTamperStatus[] readerStatus)
        {
            Data = new byte[3];
            Length = 3;
            FunctionCode = TamperOrPowerChangedStateAlarmFunctionCode;

            if (tamperActive == false)
            {
                Data[1] = tamperSecure;
            }

            if (powerSupplyStatus.Has(PowerSupplyStatus.ChargerFail))
            {
                Data[1] |= chargerFail | acPowerOk | batteryMissing; // send batteryMissing so that we at least get some warning on old controller firmware
            }
            else
            {
                 if (powerSupplyStatus.Has(PowerSupplyStatus.LowAcVoltage))
                {
                    Data[1] |= acPowerLow;
                }

                if (powerSupplyStatus.DoesNotHave(PowerSupplyStatus.ACFail))
                {
                    Data[1] |= acPowerOk;
                }

                if (powerSupplyStatus.DoesNotHave(PowerSupplyStatus.BatteryLow))
                {
                    Data[1] |= batteryOk; // Voltage is not Low (could be missing, though!)
                }

                if (powerSupplyStatus.Has(PowerSupplyStatus.BatteryFail))
                {
                    Data[1] |= batteryMissing;
                }
            }

            Data[2] = 0;
            if (readerStatus != null && readerStatus.Length == 4)
            {
                byte value = 1;
                for (int i = 0; i < 4; i++)
                {
                    if (readerStatus[i].Has(ReaderOnlineTamperStatus.Offline))
                        Data[2] |= value;
                    value <<= 1;
                    if (readerStatus[i].Has(ReaderOnlineTamperStatus.Tamper))
                        Data[2] |= value;
                    value <<= 1;
                }
            }
        }

        /// <summary>
        /// Get device tamper status.
        /// </summary>
        public bool TamperActive
        {
            get
            {
                if ((Data[Offset + 1] & 0x01) == 0)
                    return true;
                return false;
            }
        }

		/// <summary>
        /// Get device power status
        /// </summary>
        public PowerSupplyStatus PowerSupplyStatus
        {
            get
            {
                byte state = Data[Offset + 1];
                PowerSupplyStatus ret = 0;
                if ((state & chargerFail) != 0) 
                {
                    ret |= PowerSupplyStatus.ChargerFail;
                }
                else
                {
                    // charger hasn't failed, so other states are valid
                    if ((state & acPowerOk) == 0x00)
                    {
                        ret |= PowerSupplyStatus.ACFail;
                    }

                    if ((state & acPowerLow) != 0x00)
                    {
                        ret |= PowerSupplyStatus.LowAcVoltage;
                    }

                    if ((state & batteryMissing) != 0x00)
                    {
                        ret |= PowerSupplyStatus.BatteryFail;
                    }
                    else if ((state & batteryOk) == 0x00)
                    {
                        // only report battery low if it hasn't failed
                        ret |= PowerSupplyStatus.BatteryLow;
                    }
                }

                return ret;
            }
        }

        /// <summary>
        /// Get device reader status
        /// </summary>
        public ReaderOnlineTamperStatus[] ReaderStatuses
        {
            get
            {
                ReaderOnlineTamperStatus[] result = new ReaderOnlineTamperStatus[4];
                if (Length >= 3)
                {
                    byte value = 1;
                    for (int i = 0; i < 4; i++)
                    {
                        if ((Data[Offset + 2] & value) != 0)
                            result[i] = result[i].SetFlags(ReaderOnlineTamperStatus.Offline);
                        value <<= 1;
                        if ((Data[Offset + 2] & value) != 0)
                            result[i] = result[i].SetFlags(ReaderOnlineTamperStatus.Tamper);
                        value <<= 1;
                    }
                }
                else
                {
                    for (int i = 0; i < 4; i++)
                    {
                        result[i] = ReaderOnlineTamperStatus.Normal;
                    }
                }
                return result;
            }
        }

        public override string ToString()
        {
            PowerSupplyStatus powerSupplyStatus = this.PowerSupplyStatus;
            List<string> states = new List<string>();
            if (powerSupplyStatus.Has(PowerSupplyStatus.ChargerFail))
            {
                states.Add("Charger Fail");
            }
            else
            {
                if (powerSupplyStatus.Has(PowerSupplyStatus.LowAcVoltage))
                {
                    states.Add("AC Low");
                }

                if (powerSupplyStatus.Has(PowerSupplyStatus.ACFail))
                {
                    states.Add("AC Fail");
                }
                
                if (powerSupplyStatus.Has(PowerSupplyStatus.BatteryFail))
                {
                    states.Add("Battery Fail");
                }
                else if (powerSupplyStatus.Has(PowerSupplyStatus.BatteryLow))
                {
                    states.Add("Battery Low");
                }
            }
            string messagePowerStatus;
            if (states.Count == 0)
            {
                messagePowerStatus = "Normal";
            }
            else
            {
                messagePowerStatus = string.Join(" & ", states.ToArray());
            }

            string messageTamper;
            if (TamperActive)
                messageTamper = "Active";
            else
                messageTamper = "Secure";
            System.Text.StringBuilder messageReader = new System.Text.StringBuilder();
            for (int i = 0; i < 4; i++)
            {
                messageReader.Append((i + 1).ToString());
                if (ReaderStatuses[i].Has(ReaderOnlineTamperStatus.Offline))
                    messageReader.Append('O');
                else
                    messageReader.Append('-');
                if (ReaderStatuses[i].Has(ReaderOnlineTamperStatus.Tamper))
                    messageReader.Append('T');
                else
                    messageReader.Append('-');                
            }
            return string.Format("Tamper({0}) Reader State({1}) Power State({2})", messageTamper, messageReader.ToString(), messagePowerStatus);
        }

#if COMMUNICATIONSANALYZER

        public TamperOrPowerChangedStateAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { TamperOrPowerChangedStateAlarmFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("Device and Reader Tamper and Power Changed State Alarm");
            return sb.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            bool appended = false;
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("Device and Reader Tamper and Power Changed State Alarm");
            sb.Append(Environment.NewLine);
            sb.Append(Environment.NewLine);
            if (TamperActive)
                sb.Append("Device tamper is Active");
            else
                sb.Append("Device tamper is Secure");
            sb.Append(Environment.NewLine);
            sb.Append(Environment.NewLine);
            sb.Append("Device power status has: ");
            sb.Append(Environment.NewLine);
            sb.Append(new string(' ', 5));
            PowerSupplyStatus powerSupplyStatus = this.PowerSupplyStatus;
            appended = false;
            if (powerSupplyStatus.Has(PowerSupplyStatus.ChargerFail))
            {
                sb.Append("Charger Fail");
                appended = true;
            }
            if (powerSupplyStatus.Has(PowerSupplyStatus.BatteryFail))
            {
                if (appended)
                    sb.Append(", ");
                sb.Append("Battery Fail");
                appended = true;
            }
            if (powerSupplyStatus.Has(PowerSupplyStatus.BatteryLow))
            {
                if (appended)
                    sb.Append(", ");
                sb.Append("Battery Low");
                appended = true;
            }
            if (powerSupplyStatus.Has(PowerSupplyStatus.ACFail))
            {
                if (appended)
                    sb.Append(", ");
                sb.Append("AC Fail");
                appended = true;
            }
            if (powerSupplyStatus == PowerSupplyStatus.Normal)
            {
                if (appended)
                    sb.Append(", ");
                sb.Append("Power Normal");
            }
            sb.Append(Environment.NewLine);
            sb.Append(Environment.NewLine);
            sb.Append("Reader statuses: ");
            sb.Append(Environment.NewLine);
            for (int i = 0; i < 4; i++)
            {
                appended = false;
                sb.Append(string.Format("Reader {0}: ", i + 1).PadLeft(15, ' '));
                if (ReaderStatuses[i].Has(ReaderOnlineTamperStatus.Offline))
                {
                    sb.Append("Offline");
                    appended = true;
                }
                if (ReaderStatuses[i].Has(ReaderOnlineTamperStatus.Tamper))
                {
                    if (appended)
                        sb.Append(", ");
                    sb.Append("Tamper");
                    appended = true;
                }
                if (ReaderStatuses[i] == ReaderOnlineTamperStatus.Normal)
                {
                    if (appended)
                        sb.Append(", ");
                    sb.Append("Normal");
                    appended = true;
                }
                sb.Append(Environment.NewLine);
            }
            return sb.ToString();
        }
#endif
    }
}
