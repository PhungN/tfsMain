﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    /// <summary>
    /// Handles request and response with raw card data stream payload.
    /// </summary>
    public class CardReaderCardDataRawSendAlarmBase : DeviceLoopMessageBase
    {
        private readonly byte Reader1FunctionCode;
        private readonly byte Reader2FunctionCode;
        private readonly byte Reader3FunctionCode;
        private readonly byte Reader4FunctionCode;

        public CardReaderCardDataRawSendAlarmBase(byte reader1FunctionCode, byte reader2FunctionCode, byte reader3FunctionCode, byte reader4FunctionCode, byte[] data, int offset, int length)
            : base(data, offset, length, 4)
        {
            Reader1FunctionCode = reader1FunctionCode;
            Reader2FunctionCode = reader2FunctionCode;
            Reader3FunctionCode = reader3FunctionCode;
            Reader4FunctionCode = reader4FunctionCode;
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber">Card reader number</param>
        /// <param name="config">Request configuration</param>
        public CardReaderCardDataRawSendAlarmBase(byte reader1FunctionCode, byte reader2FunctionCode, byte reader3FunctionCode, byte reader4FunctionCode, CardReaderPortType readerNumber, CardReaderDataSendDataRawConfig config)
        {
            Reader1FunctionCode = reader1FunctionCode;
            Reader2FunctionCode = reader2FunctionCode;
            Reader3FunctionCode = reader3FunctionCode;
            Reader4FunctionCode = reader4FunctionCode;
            if (config == null)
                throw new ArgumentNullException("config");
            if (config.NumberOfBits <= 0 || config.NumberOfBits > 255)
                throw new ArgumentException("Invalid number of bits for card.");

            int numberOfBytes = DeviceLoopUtils.GetByteArrayLengthFromBits(config.NumberOfBits);
            this.Data = new byte[3 + numberOfBytes];

            switch (readerNumber)
            {
                case CardReaderPortType.CardReader1:
                    this.FunctionCode = Reader1FunctionCode;
                    break;
                case CardReaderPortType.CardReader2:
                    this.FunctionCode = Reader2FunctionCode;
                    break;
                case CardReaderPortType.CardReader3:
                    this.FunctionCode = Reader3FunctionCode;
                    break;
                case CardReaderPortType.CardReader4:
                    this.FunctionCode = Reader4FunctionCode;
                    break;
                default:
                    throw new ArgumentException("Invalid reader number.");
            }

            constructCardReaderCardDataRawSendCommand(config);
            this.Length = this.Data.Length;
        }

        private CardReaderPortType getCardReader()
        {
            byte fc = this.Data[this.Offset];
            if (fc == Reader1FunctionCode)
                return CardReaderPortType.CardReader1;
            else if(fc == Reader2FunctionCode)
                return CardReaderPortType.CardReader2;
            else if( fc == Reader3FunctionCode)
                return CardReaderPortType.CardReader3;
            else if(fc == Reader4FunctionCode)
                return CardReaderPortType.CardReader4;
            else
                return CardReaderPortType.NoReader;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber">Output reader number.</param>
        /// <param name="config">Response configuration</param>
        public bool GetConfiguration(out CardReaderPortType readerNumber, out CardReaderDataSendDataRawConfig config)
        {
            config = null;
            readerNumber = CardReaderPortType.NoReader;
            if (this.Data.Length < 4)
                return false;
            readerNumber = getCardReader();
            if (readerNumber == CardReaderPortType.NoReader)
                return false;
            config = parseCardReaderCardDataRawSendCommand();
            return true;
        }

        private void constructCardReaderCardDataRawSendCommand(CardReaderDataSendDataRawConfig config)
        {
            this.Data[Offset + 1] = (byte)config.ReaderType;
            if (config.NumberOfBits <= 0)
                return;
            this.Data[Offset + 2] = (byte)config.NumberOfBits;
            DeviceLoopUtils.ConstructRawCardData(ref config, (index, data) =>
            {
                this.Data[Offset + 3 + index] = data;
            });
        }

        private CardReaderDataSendDataRawConfig parseCardReaderCardDataRawSendCommand()
        {
            CardReaderDataSendDataRawConfig config = new CardReaderDataSendDataRawConfig();
            config.ReaderType = (CardReaderType)Data[Offset + 1];
            config.NumberOfBits = Data[Offset + 2];
            if (config.NumberOfBits <= 0)
                config.Data = new byte[0];
            else
                DeviceLoopUtils.ParseRawCardData(ref config, Offset + 3, Data);
            return config;
        }

        public override string ToString()
        {
            return string.Format("{0} Card Data Raw Send", getCardReader().ToString());
        }
#if COMMUNICATIONSANALYZER

        public CardReaderCardDataRawSendAlarmBase()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get
            {
                return new int[] { 
                    Reader1FunctionCode, Reader2FunctionCode,
                    Reader3FunctionCode, Reader4FunctionCode
                };
            }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(this.ToString());
            sb.Append(Environment.NewLine);
            CardReaderPortType readerNumber;
            CardReaderDataSendDataRawConfig config;
            if (GetConfiguration(out readerNumber, out config))
            {
                sb.Append(string.Format("Number of bits: {0}, Data: {1}", config.NumberOfBits, BitConverter.ToString(config.Data)));
                sb.Append(Environment.NewLine);
                byte[] rawDeviceLoopData = new byte[DeviceLoopUtils.GetByteArrayLengthFromBits(config.NumberOfBits)];
                Array.Copy(this.Data, Offset + 3, rawDeviceLoopData, 0, rawDeviceLoopData.Length);
                sb.Append(string.Format("Unprocessed device loop data: {0}", BitConverter.ToString(rawDeviceLoopData)));
                sb.Append(Environment.NewLine);
            }
            else
            {
                sb.Append("Unbale to parse.");
                sb.Append(Environment.NewLine);
            }            
            return sb.ToString();
        }

#endif

    }
}
