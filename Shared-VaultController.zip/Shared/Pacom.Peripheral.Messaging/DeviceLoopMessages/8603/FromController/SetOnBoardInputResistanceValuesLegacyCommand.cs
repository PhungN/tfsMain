﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // The 8 input expansion alarm unit allows different termination resistor values (between 0 ohm and 25K4 in steps of 100) 
    // for ALARM and SECURE conditions. These values can be downloaded to 16 input expansion alarm unit:
    // 06 , ALM_1 , SEC_1 , ... , ALM_16 , SEC_16
    // ALM_1...ALM_16 = termination resistor value (in * 100 ohm) for ALARM condition
    // SEC_1...SEC_16 = termination resistor value (in * 100 ohm) for SECURE condition
    public class SetOnboardInputResistanceValuesLegacyCommand : DeviceLoopMessageBase
    {

        public const int SetOnboardInputResistanceValuesLegacyCommandFunctionCode = 6;

        public SetOnboardInputResistanceValuesLegacyCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public SetOnboardInputResistanceValuesLegacyCommand(int[] alarmResistanceValues, int[] secureResistanceValues)
        {
            Data = new byte[1 + (alarmResistanceValues.Length * 2)];
            FunctionCode = SetOnboardInputResistanceValuesLegacyCommandFunctionCode;

            for (int i = 0; i < alarmResistanceValues.Length; i++)
            {
                Data[1 + (i * 2)] = (byte)(alarmResistanceValues[i] / 100);
                Data[2 + (i * 2)] = (byte)(secureResistanceValues[i] / 100);
            }

            Length = Data.Length;
        }

        public void GetResistanceValues(out int[] alarmResistanceValues, out int[] secureResistanceValues)
        {
            alarmResistanceValues = new int[(Length - 1) / 2];
            secureResistanceValues = new int[alarmResistanceValues.Length];

            for (int i = 0; i < alarmResistanceValues.Length; i++)
            {
                alarmResistanceValues[i] = Data[Offset + 1 + (i * 2)] * 100;
                secureResistanceValues[i] = Data[Offset + 2 + (i * 2)] * 100;
            }
        }

        public override string ToString()
        {
            string temp = "";
            int[] alarmResistanceValues;
            int[] secureResistanceValues;
            GetResistanceValues(out alarmResistanceValues, out secureResistanceValues);

            for (int i = 0; i < alarmResistanceValues.Length; i++)
            {
                string alarmResistanceString = "";
                string secureResistanceString = "";

                if (alarmResistanceValues[i] > 1000)
                    alarmResistanceString = ((int)(alarmResistanceValues[i] / 1000)).ToString() + "K" + ((int)(alarmResistanceValues[i] % 1000)).ToString();
                else
                    alarmResistanceString = alarmResistanceValues[i].ToString() + " Ohm";
                if (secureResistanceValues[i] > 1000)
                    secureResistanceString = ((int)(secureResistanceValues[i] / 1000)).ToString() + "K" + ((int)(secureResistanceValues[i] % 1000)).ToString();
                else
                    secureResistanceString = secureResistanceValues[i].ToString() + " Ohm";

                if (i != 0)
                    temp += ", ";
                temp += "Alarm = " + alarmResistanceString + " Secure = " + secureResistanceString;
            }

            return "Set On-Board Resistance Values (" + temp + ")";
        }

#if COMMUNICATIONSANALYZER

        public SetOnboardInputResistanceValuesLegacyCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetOnboardInputResistanceValuesLegacyCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return "Set On-Board Resistance Values";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
