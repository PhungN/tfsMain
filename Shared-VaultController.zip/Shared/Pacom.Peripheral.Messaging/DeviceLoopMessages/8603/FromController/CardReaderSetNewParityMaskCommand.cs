﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    public class CardReaderSetNewParityMaskCommand : DeviceLoopMessageBase
    {
        public const int CardReaderSetNewParityMaskCommandReader1FunctionCode = 38;
        public const int CardReaderSetNewParityMaskCommandReader2FunctionCode = 39;
        public const int CardReaderSetNewParityMaskCommandReader3FunctionCode = 68;
        public const int CardReaderSetNewParityMaskCommandReader4FunctionCode = 69;

        public CardReaderSetNewParityMaskCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 30)
        {
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public CardReaderSetNewParityMaskCommand(CardReaderPortType readerNumber, CardFormatParityConfig config, int formatNumber)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            this.Data = new byte[30];
            switch (readerNumber)
            {
                case CardReaderPortType.CardReader1:
                    this.FunctionCode = CardReaderSetNewParityMaskCommandReader1FunctionCode;
                    break;
                case CardReaderPortType.CardReader2:
                    this.FunctionCode = CardReaderSetNewParityMaskCommandReader2FunctionCode;
                    break;
                case CardReaderPortType.CardReader3:
                    this.FunctionCode = CardReaderSetNewParityMaskCommandReader3FunctionCode;
                    break;
                case CardReaderPortType.CardReader4:
                    this.FunctionCode = CardReaderSetNewParityMaskCommandReader4FunctionCode;
                    break;
                default:
                    throw new ArgumentException("Invalid reader number.");
            }
            // Validate formt index
            if (formatNumber < 0 || formatNumber > 4)
            {
                throw new ArgumentException("Invalid format number.");
            }
            Data[1] = (byte)formatNumber;
            byte[] paritiyConfig = config.Data;
            if (paritiyConfig != null)
                Array.Copy(paritiyConfig, 0, Data, 2, Math.Min(paritiyConfig.Length, Data.Length - 2));
            this.Length = this.Data.Length;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        /// <param name="formatNumber">Format number from 0 to 3.</param>
        public bool GetConfiguration(out CardReaderPortType readerNumber, out CardFormatParityConfig config, out int formatNumber)
        {
            if (this.Data.Length < 30)
            {
                readerNumber = CardReaderPortType.NoReader;
                config = null;
                formatNumber = -1;
                return false;
            }
            switch (this.Data[this.Offset])
            {
                case CardReaderSetNewParityMaskCommandReader1FunctionCode:
                    readerNumber = CardReaderPortType.CardReader1;
                    break;
                case CardReaderSetNewParityMaskCommandReader2FunctionCode:
                    readerNumber = CardReaderPortType.CardReader2;
                    break;
                case CardReaderSetNewParityMaskCommandReader3FunctionCode:
                    readerNumber = CardReaderPortType.CardReader3;
                    break;                
                case CardReaderSetNewParityMaskCommandReader4FunctionCode:
                    readerNumber = CardReaderPortType.CardReader4;
                    break;
                default:
                    readerNumber = CardReaderPortType.NoReader;
                    config = null;
                    formatNumber = -1;
                    return false;
            }

            formatNumber = Data[Offset + 1];
            config = new CardFormatParityConfig(Data, Offset + 2);
            return config != null;
        }

        public override string ToString()
        {
            return "Set Card Reader Format Parity Configuration";
        }

#if COMMUNICATIONSANALYZER

        public CardReaderSetNewParityMaskCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] 
            { 
                CardReaderSetNewParityMaskCommandReader1FunctionCode, CardReaderSetNewParityMaskCommandReader2FunctionCode,
                CardReaderSetNewParityMaskCommandReader3FunctionCode, CardReaderSetNewParityMaskCommandReader4FunctionCode
            }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
