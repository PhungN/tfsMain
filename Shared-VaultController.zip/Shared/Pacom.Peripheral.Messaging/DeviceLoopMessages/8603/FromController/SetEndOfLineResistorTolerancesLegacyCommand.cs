﻿using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // The message format is:
    // 15 , TOL_1 , TOL_2
    // TOL_1 = 8 bit tolerance mask for alarm points 1 to 8, bit0 for alarm point 1.
    // TOL_2 = 8 bit tolerance mask for alarm points 9 to 16, bit0 for alarm point 9.
    // A bit = 0 for 12.5 % tolerance and bit = 1 for 25% tolerance.
    public class SetEndOfLineResistorTolerancesLegacyCommand : DeviceLoopMessageBase
    {

        public const int SetEndOfLineResistorTolerancesLegacyCommandFunctionCode = 15;

        public SetEndOfLineResistorTolerancesLegacyCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public SetEndOfLineResistorTolerancesLegacyCommand(ResistorTolerance[] resistorTolerances)
        {
            int bytesRequired = resistorTolerances.Length / 8;
            if ((resistorTolerances.Length % 8) > 0)
                bytesRequired++;

            Data = new byte[1 + bytesRequired];
            FunctionCode = SetEndOfLineResistorTolerancesLegacyCommandFunctionCode;

            for (int byteIndex = 0; byteIndex < bytesRequired; byteIndex++)
            {
                byte toleranceBitField = 0;
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    if (resistorTolerances[(byteIndex * 8) + bitIndex] == ResistorTolerance.TwentyFivePercent)
                        toleranceBitField |= (byte)(1 << bitIndex);
                }
                Data[byteIndex + 1] = toleranceBitField;
            }

            Length = Data.Length;
        }

        public void GetEndOfLineResistorTolerances(out ResistorTolerance[] resistorTolerances)
        {
            resistorTolerances = new ResistorTolerance[(Length - 1) * 8];

            for (int byteIndex = 0; byteIndex < (Length - 1); byteIndex++)
            {
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    int arrayIndex = (byteIndex * 8) + bitIndex;
                    if ((Data[Offset + byteIndex + 1] & (byte)(1 << bitIndex)) == 0)
                        resistorTolerances[arrayIndex] = ResistorTolerance.TwelveAndAHalfPercent;
                    else
                        resistorTolerances[arrayIndex] = ResistorTolerance.TwentyFivePercent;
                }
            }
        }

        public override string ToString()
        {
            ResistorTolerance[] resistorTolerances;
            GetEndOfLineResistorTolerances(out resistorTolerances);

            StringBuilder sb = new StringBuilder(8);
            for (int i = 0; i < resistorTolerances.Length; i++)
            {
                if (i > 0)
                    sb.Append("-");
                if (resistorTolerances[i] == ResistorTolerance.TwelveAndAHalfPercent)
                    sb.Append("12.5%");
                else
                    sb.Append("25%");
            }

            return "Set End Of Line Resistor Tolerances (" + sb.ToString() + ")";
        }

#if COMMUNICATIONSANALYZER

        public SetEndOfLineResistorTolerancesLegacyCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetEndOfLineResistorTolerancesLegacyCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return "Set End Of Line Resistor Tolerances";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
