﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    /// <summary>
    /// Process command received from controller after card data was scanned.
    /// </summary>
    public class CardReaderControllerAccessResponseCommand : DeviceLoopMessageBase
    {
        public const int CardReaderControllerAccessResponseCommandReader1FunctionCode = 28;
        public const int CardReaderControllerAccessResponseCommandReader2FunctionCode = 33;
        public const int CardReaderControllerAccessResponseCommandReader3FunctionCode = 60;
        public const int CardReaderControllerAccessResponseCommandReader4FunctionCode = 63;

        /// <summary>
        /// Parse "SendCardReaderCommand" device loop message.
        /// </summary>
        /// <param name="data">Byte array with device loop message.</param>
        /// <param name="offset">Offset is used to indicate position of function code in the byte array.</param>
        /// <param name="length">Length of data from function code to the end of array or check code.</param>
        public CardReaderControllerAccessResponseCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 7)
        {
        }

        /// <summary>
        /// Format device loop mesage from CardReaderCommandData class
        /// </summary>
        /// <param name="eventData"></param>
        public CardReaderControllerAccessResponseCommand(CardReaderPortType readerNumber, CardReaderCommandDataConfig command)
        {
            if (command == null)
            {
                throw new ArgumentNullException("command");
            }

            if (command.OutputIncluded == true)
            {
                this.Data = new byte[10];
            }
            else
            {
                this.Data = new byte[8];
            }
            switch (readerNumber)
            {
                case CardReaderPortType.CardReader1:
                    this.FunctionCode = CardReaderControllerAccessResponseCommandReader1FunctionCode;
                    break;
                case CardReaderPortType.CardReader2:
                    this.FunctionCode = CardReaderControllerAccessResponseCommandReader2FunctionCode;
                    break;
                case CardReaderPortType.CardReader3:
                    this.FunctionCode = CardReaderControllerAccessResponseCommandReader3FunctionCode;
                    break;
                case CardReaderPortType.CardReader4:
                    this.FunctionCode = CardReaderControllerAccessResponseCommandReader4FunctionCode;
                    break;
                default:
                    throw new ArgumentException("Invalid reader number.");
            }
            constructSendCardReaderCommand(command);
            this.Length = this.Data.Length;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public bool GetConfiguration(out CardReaderPortType readerNumber, out CardReaderCommandDataConfig command)
        {
            if (this.Data.Length < 7)
            {
                readerNumber = CardReaderPortType.NoReader;
                command = null;
                return false;
            }
            switch (this.Data[this.Offset])
            {
                case CardReaderControllerAccessResponseCommandReader1FunctionCode:
                    readerNumber = CardReaderPortType.CardReader1;
                    break;
                case CardReaderControllerAccessResponseCommandReader2FunctionCode:
                    readerNumber = CardReaderPortType.CardReader2;
                    break;
                case CardReaderControllerAccessResponseCommandReader3FunctionCode:
                    readerNumber = CardReaderPortType.CardReader3;
                    break;
                case CardReaderControllerAccessResponseCommandReader4FunctionCode:
                    readerNumber = CardReaderPortType.CardReader4;
                    break;
                default:
                    readerNumber = CardReaderPortType.NoReader;
                    command = null;
                    return false;
            }

            command = parseSendCardReaderCommand();
            if (command != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void constructSendCardReaderCommand(CardReaderCommandDataConfig command)
        {
            // Reader type
            this.Data[this.Offset + 1] = (byte)command.ReaderType;

            // Flags
            if (command.StrikeIncluded)
            {
                this.Data[this.Offset + 2] = 0x01;
            }
            if (command.BuzzerIncluded)
            {
                this.Data[this.Offset + 2] |= 0x02;
            }
            if (command.AcceptLedIncluded)
            {
                this.Data[this.Offset + 2] |= 0x04;
            }
            if (command.DeniedLedIncluded)
            {
                this.Data[this.Offset + 2] |= 0x08;
            }
            if (command.OutputIncluded)
            {
                this.Data[this.Offset + 2] |= 0x20;
            }
            if (command.StoreCardInDegradedMemory)
            {
                this.Data[this.Offset + 2] |= 0x40;
            }

            // Strike byte
            if (command.StrikeState == CardReaderStrikeType.On)
            {
                this.Data[this.Offset + 3] = 0xFF;
            }
            else if (command.StrikeState == CardReaderStrikeType.TimeDriven)
            {
                if (command.StrikeTime > 127)
                    Data[Offset + 3] = 127;
                else if (command.StrikeTime < 0)
                    Data[Offset + 3] = 0;
                else
                {
                    Data[Offset + 3] = (byte)command.StrikeTime;
                    // Strike in minutes
                    if (command.StrikeTimeInMinutes == true)
                    {
                        this.Data[this.Offset + 3] |= 0x80;
                    }
                }
            }

            // Buzzer byte
            if (command.BuzzerCurrentTime > 7 && command.BuzzerCurrentTime < 255)
            {
                command.BuzzerModifyNormal = true;
                command.BuzzerModifyNormalType = command.BuzzerCurrentType;
            }
            this.Data[this.Offset + 4] = 0;
            if (command.BuzzerModifyNormal == true)
            {
                this.Data[this.Offset + 4] |= 0x80;
                if (command.BuzzerModifyNormalType == CardReaderBuzzerType.BuzzerOn)
                {
                    this.Data[this.Offset + 4] |= 0x10;
                }
                else if (command.BuzzerModifyNormalType == CardReaderBuzzerType.BuzzerPulse)
                {
                    this.Data[this.Offset + 4] |= 0x20;
                }
            }
            if (command.BuzzerCurrentTime != 0)
            {
                this.Data[this.Offset + 4] |= (byte)(command.BuzzerCurrentTime & 0x07);
                if (command.BuzzerCurrentType == CardReaderBuzzerType.BuzzerPulse)
                {
                    this.Data[this.Offset + 4] |= 0x08;
                }
            }

            // Accept Led byte
            if (command.AcceptLedCurrentTime > 7 && command.AcceptLedCurrentTime < 255)
            {
                command.AcceptLedModifyNormal = true;
                command.AcceptLedModifyNormalType = command.AcceptLedCurrentType;
            }
            this.Data[this.Offset + 5] = 0;
            if (command.AcceptLedModifyNormal == true)
            {
                this.Data[this.Offset + 5] |= 0x80;
                if (command.AcceptLedModifyNormalType == CardReaderLedType.LedOn)
                {
                    this.Data[this.Offset + 5] |= 0x10;
                }
                else if (command.AcceptLedModifyNormalType == CardReaderLedType.LedFlashing)
                {
                    this.Data[this.Offset + 5] |= 0x20;
                }
            }
            if (command.AcceptLedCurrentTime != 0)
            {
                this.Data[this.Offset + 5] |= (byte)(command.AcceptLedCurrentTime & 0x07);
                if (command.AcceptLedCurrentType == CardReaderLedType.LedFlashing)
                {
                    this.Data[this.Offset + 5] |= 0x08;
                }
            }

            // Denied Led byte
            if (command.DeniedLedCurrentTime > 7 && command.DeniedLedCurrentTime < 255)
            {
                command.DeniedLedModifyNormal = true;
                command.DeniedLedModifyNormalType = command.DeniedLedCurrentType;
            }
            this.Data[this.Offset + 6] = 0;
            if (command.DeniedLedModifyNormal)
            {
                this.Data[this.Offset + 6] |= 0x80;

                if (command.DeniedLedModifyNormalType == CardReaderLedType.LedOn)
                {
                    this.Data[this.Offset + 6] |= 0x10;
                }
                else if (command.DeniedLedModifyNormalType == CardReaderLedType.LedFlashing)
                {
                    this.Data[this.Offset + 6] |= 0x20;
                }
            }
            if (command.DeniedLedCurrentTime != 0)
            {
                this.Data[this.Offset + 6] |= (byte)(command.DeniedLedCurrentTime & 0x07);
                if (command.DeniedLedCurrentType == CardReaderLedType.LedFlashing)
                {
                    this.Data[this.Offset + 6] |= 0x08;
                }
            }

            // Spare output byte
            if (command.OutputIncluded)
            {
                if (command.OutputState == CardReaderOutputType.On)
                {
                    this.Data[this.Offset + 8] = 0xFF;
                }
                else if (command.OutputState == CardReaderOutputType.TimeDriven)
                {
                    this.Data[this.Offset + 8] = (byte)(command.OutputTime & 0x7F);
                }
                // Is spare output in minutes
                if (command.OutputTimeInMinutes == true)
                {
                    this.Data[this.Offset + 8] |= 0x80;
                }
            }
        }

        private CardReaderCommandDataConfig parseSendCardReaderCommand()
        {
            CardReaderCommandDataConfig command = new CardReaderCommandDataConfig();

            // Reader type
            command.ReaderType = (CardReaderType)Enum.Parse(typeof(CardReaderType), this.Data[this.Offset + 1].ToString(), true);
            command.StrikeIncluded = (this.Data[this.Offset + 2] & 0x01) == 0x01;
            command.BuzzerIncluded = (this.Data[this.Offset + 2] & 0x02) == 0x02;
            command.AcceptLedIncluded = (this.Data[this.Offset + 2] & 0x04) == 0x04;
            command.DeniedLedIncluded = (this.Data[this.Offset + 2] & 0x08) == 0x08;
            command.OutputIncluded = (this.Data[this.Offset + 2] & 0x20) == 0x20;
            command.StoreCardInDegradedMemory = (this.Data[this.Offset + 2] & 0x40) == 0x40;

            // Strike
            if (this.Data[this.Offset + 3] == 0xFF)
            {
                command.StrikeState = CardReaderStrikeType.On;                
                command.StrikeTime = 0;
                command.StrikeTimeInMinutes = false;
            }
            else if (this.Data[this.Offset + 3] == 0)
            {
                command.StrikeState = CardReaderStrikeType.Off;                
                command.StrikeTime = 0;
                command.StrikeTimeInMinutes = false;
            }
            else
            {
                command.StrikeState = CardReaderStrikeType.TimeDriven;
                command.StrikeTime = (byte)(this.Data[this.Offset + 3] & 0x7F);
                if ((this.Data[this.Offset + 3] & 0x80) == 0x80)
                {
                    command.StrikeTimeInMinutes = true;
                }
            }

            // Buzzzer
            if ((this.Data[this.Offset + 4] & 0x80) == 0x80)
            {
                command.BuzzerModifyNormal = true;
                if ((this.Data[this.Offset + 4] & 0x10) == 0x10)
                {
                    command.BuzzerModifyNormalType = CardReaderBuzzerType.BuzzerOn;
                }
                else if ((this.Data[this.Offset + 4] & 0x20) == 0x20)
                {
                    command.BuzzerModifyNormalType = CardReaderBuzzerType.BuzzerPulse;
                }
                else
                {
                    command.BuzzerModifyNormalType = CardReaderBuzzerType.BuzzerOff;
                }
            }
            else
            {
                command.BuzzerModifyNormal = false;
                command.BuzzerModifyNormalType = CardReaderBuzzerType.BuzzerOff;
            }
            if ((this.Data[this.Offset + 4] & 0x07) != 0)
            {
                command.BuzzerCurrentTime = (this.Data[this.Offset + 4] & 0x07);
                if ((this.Data[this.Offset + 4] & 0x08) == 0x08)
                {
                    command.BuzzerCurrentType = CardReaderBuzzerType.BuzzerPulse;
                }
                else
                {
                    command.BuzzerCurrentType = CardReaderBuzzerType.BuzzerOn;
                }
            }

            // Accept Led
            if ((this.Data[this.Offset + 5] & 0x80) == 0x80)
            {
                command.AcceptLedModifyNormal = true;
                if ((this.Data[this.Offset + 5] & 0x10) == 0x10)
                {
                    command.AcceptLedModifyNormalType = CardReaderLedType.LedOn;
                }
                else if ((this.Data[this.Offset + 5] & 0x20) == 0x20)
                {
                    command.AcceptLedModifyNormalType = CardReaderLedType.LedFlashing;
                }
                else
                {
                    command.AcceptLedModifyNormalType = CardReaderLedType.LedOff;
                }
            }
            else
            {
                command.AcceptLedModifyNormal = false;
                command.AcceptLedModifyNormalType = CardReaderLedType.LedOff;
            }
            if ((this.Data[this.Offset + 5] & 0x07) != 0)
            {
                command.AcceptLedCurrentTime = this.Data[this.Offset + 5] & 0x07;
                if ((this.Data[this.Offset + 5] & 0x08) == 0x08)
                {
                    command.AcceptLedCurrentType = CardReaderLedType.LedFlashing;
                }
                else
                {
                    command.AcceptLedCurrentType = CardReaderLedType.LedOn;
                }
            }
            else
            {
                command.AcceptLedCurrentTime = 0;
                command.AcceptLedCurrentType = CardReaderLedType.LedOff;
            }

            // Denied Led
            if ((this.Data[this.Offset + 6] & 0x80) == 0x80)
            {
                command.DeniedLedModifyNormal = true;
                if ((this.Data[this.Offset + 6] & 0x10) == 0x10)
                {
                    command.DeniedLedModifyNormalType = CardReaderLedType.LedOn;
                }
                else if ((this.Data[this.Offset + 6] & 0x20) == 0x20)
                {
                    command.DeniedLedModifyNormalType = CardReaderLedType.LedFlashing;
                }
                else
                {
                    command.DeniedLedModifyNormalType = CardReaderLedType.LedOff;
                }
            }
            else
            {
                command.DeniedLedModifyNormal = false;
                command.DeniedLedModifyNormalType = CardReaderLedType.LedOff;
            }

            if ((this.Data[this.Offset + 6] & 0x07) != 0)
            {
                command.DeniedLedCurrentTime = this.Data[this.Offset + 6] & 0x07;
                if ((this.Data[this.Offset + 6] & 0x08) == 0x08)
                {
                    command.DeniedLedCurrentType = CardReaderLedType.LedFlashing;
                }
                else
                {
                    command.DeniedLedCurrentType = CardReaderLedType.LedOn;
                }
            }
            else
            {
                command.DeniedLedCurrentTime = 0;
                command.DeniedLedCurrentType = CardReaderLedType.LedOff;
            }

            // Spare output
            // Check for extended data when output is transmitted
            if (command.OutputIncluded && (this.Data.Length >= 10))
            {
                command.OutputTimeInMinutes = (this.Data[this.Offset + 8] & 0x80) == 0x80;
                if ((this.Data[this.Offset + 8] & 0x7F) == 0x7F)
                {
                    command.OutputState = CardReaderOutputType.On;
                    command.OutputTime = 0;
                    command.OutputTimeInMinutes = false;
                }
                else if ((this.Data[this.Offset + 8] & 0x7F) == 0)
                {
                    command.OutputState = CardReaderOutputType.Off;
                    command.OutputTime = 0;
                    command.OutputTimeInMinutes = false;
                }
                else
                {
                    command.OutputState = CardReaderOutputType.TimeDriven;
                    command.OutputTime = (byte)(this.Data[this.Offset + 8] & 0x7F);
                    command.OutputTimeInMinutes = (this.Data[this.Offset + 8] & 0x80) == 0x80;
                }
            }
            return command;
        }

        public override string ToString()
        {
            string temp = string.Empty;
            CardReaderPortType readerNumber;
            CardReaderCommandDataConfig command;
            if (this.GetConfiguration(out readerNumber, out command) == true)
            {
                if (readerNumber == CardReaderPortType.NoReader)
                {
                    temp += "No reader command found";
                }
                else if (readerNumber == CardReaderPortType.CardReader1)
                {
                    temp += "Reader 1 command";
                }
                else if (readerNumber == CardReaderPortType.CardReader2)
                {
                    temp += "Reader 2 command";
                }
                else if (readerNumber == CardReaderPortType.CardReader3)
                {
                    temp += "Reader 3 command";
                }
                else if (readerNumber == CardReaderPortType.CardReader4)
                {
                    temp += "Reader 4 command";
                }
                if (readerNumber != CardReaderPortType.NoReader)
                {
                    if (command.StoreCardInDegradedMemory)
                    {
                        temp += ", StoreCardInDegradedMemory";                        
                    }
                    if (command.StrikeIncluded)
                    {
                        temp += ", StrikeInc(";
                        switch (command.StrikeState)
                        {
                            case CardReaderStrikeType.Off:
                                temp += "Off";
                                break;
                            case CardReaderStrikeType.On:
                                temp += "On";
                                break;
                            case CardReaderStrikeType.TimeDriven:
                                temp += "TimeDriven";
                                break;
                        }
                        temp += " " + command.StrikeTime.ToString();
                        if (command.StrikeTimeInMinutes)
                        {
                            temp += " min";
                        }
                        else
                        {
                            temp += " sec";
                        }
                        temp += ")";
                    }
                    if (command.BuzzerIncluded)
                    {
                        temp += ", BuzzInc(";
                        if (command.BuzzerModifyNormal)
                        {
                            temp += "ModNormal(";
                            switch (command.BuzzerModifyNormalType)
                            {
                                case CardReaderBuzzerType.BuzzerOn:
                                    temp += "On";
                                    break;
                                case CardReaderBuzzerType.BuzzerPulse:
                                    temp += "Pulse";
                                    break;
                                case CardReaderBuzzerType.BuzzerOff:
                                    temp += "Off";
                                    break;
                            }
                            temp += "), ";
                        }
                        temp += "Curr=";
                        switch (command.BuzzerCurrentType)
                        {
                            case CardReaderBuzzerType.BuzzerOn:
                                temp += "On";
                                break;
                            case CardReaderBuzzerType.BuzzerPulse:
                                temp += "Pulse";
                                break;
                            case CardReaderBuzzerType.BuzzerOff:
                                temp += "Off";
                                break;
                        }
                        temp += ", Time=" + command.BuzzerCurrentTime.ToString();                        
                        temp += ")";
                    }
                    if (command.AcceptLedIncluded)
                    {
                        temp += ", AccLedInc(";
                        if (command.AcceptLedModifyNormal)
                        {
                            temp += "ModNormal(";
                            switch (command.AcceptLedModifyNormalType)
                            {
                                case CardReaderLedType.LedOn:
                                    temp += "On";
                                    break;
                                case CardReaderLedType.LedFlashing:
                                    temp += "Pulse";
                                    break;
                                case CardReaderLedType.LedOff:
                                    temp += "Off";
                                    break;
                            }
                            temp += "), ";
                        }
                        temp += "Curr=";
                        switch (command.AcceptLedCurrentType)
                        {
                            case CardReaderLedType.LedOn:
                                temp += "On";
                                break;
                            case CardReaderLedType.LedFlashing:
                                temp += "Pulse";
                                break;
                            case CardReaderLedType.LedOff:
                                temp += "Off";
                                break;
                        }
                        temp += ", Time=" + command.AcceptLedCurrentTime.ToString();
                        temp += ")";

                    }
                    if (command.DeniedLedIncluded)
                    {
                        temp += ", DenLedInc(";
                        if (command.DeniedLedModifyNormal)
                        {
                            temp += "ModNormal(";
                            switch (command.DeniedLedModifyNormalType)
                            {
                                case CardReaderLedType.LedOn:
                                    temp += "On";
                                    break;
                                case CardReaderLedType.LedFlashing:
                                    temp += "Pulse";
                                    break;
                                case CardReaderLedType.LedOff:
                                    temp += "Off";
                                    break;
                            }
                            temp += "), ";
                        }
                        temp += "Curr=";
                        switch (command.DeniedLedCurrentType)
                        {
                            case CardReaderLedType.LedOn:
                                temp += "On";
                                break;
                            case CardReaderLedType.LedFlashing:
                                temp += "Pulse";
                                break;
                            case CardReaderLedType.LedOff:
                                temp += "Off";
                                break;
                        }
                        temp += ", Time=" + command.DeniedLedCurrentTime.ToString();
                        temp += ")";
                    }
                    if (command.OutputIncluded)
                    {
                        temp += ", OutInc(";
                        switch (command.OutputState)
                        {
                            case CardReaderOutputType.On:
                                temp += "On";
                                break;
                            case CardReaderOutputType.TimeDriven:
                                temp += "TimeDriven";
                                break;
                            case CardReaderOutputType.Off:
                                temp += "Off";
                                break;
                        }
                        temp += " Time=" + command.OutputTime;
                        if (command.OutputTimeInMinutes)
                        {
                            temp += " min";
                        }
                        else
                        {
                            temp += " sec";
                        }
                        temp += ")";
                    }
                }
            }
            else
            {
                temp = "no valid command has been found";
            }            
            return "Card Reader Send Card Reader Command (" + temp + ").";
        }

#if COMMUNICATIONSANALYZER

        public CardReaderControllerAccessResponseCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] {
                CardReaderControllerAccessResponseCommandReader1FunctionCode, CardReaderControllerAccessResponseCommandReader2FunctionCode,
                CardReaderControllerAccessResponseCommandReader3FunctionCode, CardReaderControllerAccessResponseCommandReader4FunctionCode
            }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            CardReaderPortType readerNumber;
            CardReaderCommandDataConfig command;
            if (GetConfiguration(out readerNumber, out command) == true)
                return string.Format("Card Reader Send Card Reader Command {0}", readerNumber.ToString());
            else
                return "Card Reader Send Card Reader Command";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
