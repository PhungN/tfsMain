﻿using System;
using System.Reflection;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    /// <summary>
    /// 1 byte for flags
    /// </summary>
    public class SetDeviceFlags : DeviceLoopMessageBase
    {
        private const int DeviceFlagsLength = 1;
        private const int messageLength = FunctionCodeSize + DeviceFlagsLength;
        public const int SetDeviceFlagsFunctionCode = 77;

        public SetDeviceFlags(byte[] data, int offset, int length)
            : base(data, offset, length, messageLength)
        {
        }

        public SetDeviceFlags(DeviceFlags value)
        {
            Data = new byte[messageLength];
            FunctionCode = SetDeviceFlagsFunctionCode;
            Data[1] = (byte)value;
            Length = Data.Length;
        }

        public bool GetConfiguration(out DeviceFlags value)
        {
            value = DeviceFlags.None;
            int index = Offset + FunctionCodeSize;
            if (this.Length == messageLength && Data.Length >= index + DeviceFlagsLength)
            {
                value = (DeviceFlags)Data[index];
                return true;
            }
            return false;
        }

        public override string ToString()
        {
            DeviceFlags flags = DeviceFlags.None;
            if (GetConfiguration(out flags) == true)
                return string.Format("Set Device Flags ({0})", flags.GetString());
            else
                return "Set Device Flags (Unable to parse DeviceFlags)";
        }

#if COMMUNICATIONSANALYZER

        public SetDeviceFlags()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetDeviceFlagsFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return "Set Device Flags";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
