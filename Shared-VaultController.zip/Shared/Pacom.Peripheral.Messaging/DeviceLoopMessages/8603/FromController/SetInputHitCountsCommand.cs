﻿using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // This message defines the hit counts for all inputs for an IO device:
    // 48, OWNERTYPE, STARTINGPOINT, NUMBEROFINPUTS, HITCNT_1 , ... , HITCNT_N
    // OWNERTYPE = Tamper, Onboard, Expansion1, Expansion2, ... as defined in Common.OwnerType enumerator
    // STARTINGPOINT = 0, 1, 2, 3, ... N =  Starting point number on the owning device
    // NUMBEROFINPUTS = number of inputs to look at in the message
    // HITCNT_1...HITCNT_N = hit-counts for all defined inputs. Each HITCNT_n byte will contain the hit counts for 2 inputs, one nibble per input. The hit count can be up to 16
    public class SetInputHitCountsCommand : DeviceLoopMessageBase
    {
        public const int SetInputHitCountsCommandFunctionCode = 48;

        /// <summary>
        /// Single byte for number of inputs.
        /// </summary>
        public const int NumberOfInputsSize = 1;

        public SetInputHitCountsCommand(byte[] data, int offset, int length)
            : base(data, offset, length, FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + 1 /* Min one byte with one nibble */)
        {
            if (Enum.IsDefined(typeof(OwnerType), (int)Data[Offset + FunctionCodeSize]) == false)
                throw new ArgumentException("Data is invalid.", "data");
        }

        /// <summary>
        /// Return maximum number of data parts (int types in an array) for this message.
        /// </summary>
        public const int MaximumDataLength = (MaximumDataBytesFromController - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize)) * 2;

        public SetInputHitCountsCommand(OwnerType ownerType, int startingPoint, int[] inputHitCounts)
        {
            int bytesRequiredForData = inputHitCounts.Length / 2;
            if (inputHitCounts.Length != 0 && (inputHitCounts.Length % 2) > 0)
                bytesRequiredForData++;

            bytesRequiredForData = Math.Min(bytesRequiredForData, MaximumDataLength / 2);

            Data = new byte[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + bytesRequiredForData];
            FunctionCode = SetInputHitCountsCommandFunctionCode;

            Data[OwnerTypeSize] = (byte)ownerType;
            Data[OwnerTypeSize + StartingPointSize] = (byte)startingPoint;
            Data[OwnerTypeSize + StartingPointSize + NumberOfInputsSize] = (byte)inputHitCounts.Length;

            for (int byteIndex = 0; byteIndex < bytesRequiredForData; byteIndex++)
            {
                byte HitCountsField = 0;
                for (int nibbleIndex = 0; nibbleIndex < 2; nibbleIndex++)
                {
                    int arrayIndex = (byteIndex * 2) + nibbleIndex;
                    if (inputHitCounts.Length <= arrayIndex)
                        break;

                    byte nibble = (byte)Math.Min(15, inputHitCounts[arrayIndex]);
                    int shiftBy = nibbleIndex == 1 ? 4 : 0;
                    HitCountsField |= (byte)(nibble << shiftBy);
                }
                Data[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + byteIndex] = HitCountsField;
            }
            Length = Data.Length;
        }

        public void GetInputHitCounts(out OwnerType ownerType, out int startingPoint, out int[] inputHitCounts)
        {
            ownerType = (OwnerType)Data[Offset + FunctionCodeSize];
            startingPoint = Data[Offset + FunctionCodeSize + OwnerTypeSize];
            int numberOfInputs = Data[Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize];
            inputHitCounts = new int[numberOfInputs];

            for (int byteIndex = 0; byteIndex < (Length - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize)); byteIndex++)
            {
                byte data = Data[Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + byteIndex];
                for (int nibbleIndex = 0; nibbleIndex < 2; nibbleIndex++)
                {
                    int arrayIndex = (byteIndex * 2) + nibbleIndex;
                    if (arrayIndex < numberOfInputs)
                    {
                        byte mask = (byte)(nibbleIndex == 0 ? 0x0F : 0xF0);
                        int shiftBy = nibbleIndex == 0 ? 0 : 4;
                        inputHitCounts[arrayIndex] = (data & mask) >> shiftBy;
                    }
                }
            }
        }

        public override string ToString()
        {
            OwnerType ownerType;
            int startingPoint;
            int[] inputHitCounts;
            GetInputHitCounts(out ownerType, out startingPoint, out inputHitCounts);

            StringBuilder descString = new StringBuilder();
            descString.Append("Set Input Hit Counts, Owner:");
            descString.Append(ownerType.ToString());
            descString.Append(", StartingPoint:");
            descString.Append(startingPoint.ToString());
            descString.Append(", NumberOfInputs:");
            descString.Append(inputHitCounts.Length.ToString());
            descString.Append(" (");
            for (int i = 0; i < inputHitCounts.Length; i++)
            {
                if (i > 0)
                    descString.Append("-");
                descString.Append(inputHitCounts[i]);
            }
            descString.Append(")");
            return descString.ToString();
        }

#if COMMUNICATIONSANALYZER

        public SetInputHitCountsCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetInputHitCountsCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return "Set Input Hit Counts";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
