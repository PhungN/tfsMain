﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // The state of the input expansion alarm units tamper switch and power supply can be obtained. 
    // The message format is:
    // 03
    public class RequestTamperAndPowerSupplyStateCommand : DeviceLoopMessageBase
    {
        public const int RequestTamperAndPowerSupplyStateCommandFunctionCode = 3;

        public RequestTamperAndPowerSupplyStateCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public RequestTamperAndPowerSupplyStateCommand()
        {
            Data = new byte[1];
            FunctionCode = RequestTamperAndPowerSupplyStateCommandFunctionCode;

            Length = 1;
        }

        public override string ToString()
        {
            return "Request Tamper And Power Supply State";
        }

#if COMMUNICATIONSANALYZER

        // Default constructor already defined

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { RequestTamperAndPowerSupplyStateCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return "Controller requests tamper and power supply state from device";
        }

#endif
    }
}
