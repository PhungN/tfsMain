﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // The software in the 16 input expansion alarm unit has a version number embedded in the code. 
    // To obtain this number the following message can be sent:
    // 05
    public class RequestVersionNumberCommand : DeviceLoopMessageBase
    {
        public const int RequestVersionNumberCommandFunctionCode = 5;

        public RequestVersionNumberCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public RequestVersionNumberCommand()
        {
            Data = new byte[1];
            FunctionCode = RequestVersionNumberCommandFunctionCode;

            Length = 1;
        }

        public override string ToString()
        {
            return "Request Version Number";
        }

#if COMMUNICATIONSANALYZER

        // Default constructor already defined

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { RequestVersionNumberCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
