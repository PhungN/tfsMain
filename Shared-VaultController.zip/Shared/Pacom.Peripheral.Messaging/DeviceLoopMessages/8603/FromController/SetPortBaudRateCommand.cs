﻿using System;
using System.Text;
using Pacom.Peripheral.Common;
using System.IO.Ports;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // This sets the port parameters for communication to OSDP card readers.
    // 73, 0, BAUD, BITS, PARITY, STOPS
    // BAUD = This is a four byte long value in big endian format. For 9600 baud this would be 0x00 0x00 0x25 0x80. 
    // BITS = The number of bits for the serial port.
    // PARITY = This is 0 for none, 1 for odd and 2 for even.
    // STOPS = Stop bits. This can be 1 or 2.
    public class SetPortBaudRateCommand : DeviceLoopMessageBase
    {
        public const int SetPortBaudRateCommandFunctionCode = 73;

        public SetPortBaudRateCommand(byte[] data, int offset, int length)
            : base(data, offset, length, FunctionCodeSize + 8)
        {
            if (length != (FunctionCodeSize + 8))
                throw new ArgumentException("Data is of incorrect length.", "data");

            if (BaudRate != 4800 && BaudRate != 9600 && BaudRate != 19200 && BaudRate != 38400 && BaudRate != 57600 && BaudRate != 115200)
                throw new ArgumentException("Data is invalid. (Unknown baud bate)", "data");

            if (DataBits < 5 || DataBits > 8)
                throw new ArgumentException("Data is invalid. (Unknown data bits)", "data");

            if (Enum.IsDefined(typeof(Parity), (int)Data[offset + FunctionCodeSize + 6]) == false)
                throw new ArgumentException("Data is invalid. (Unknown parity type)", "data");

            if (Enum.IsDefined(typeof(StopBits), (int)Data[offset + FunctionCodeSize + 7]) == false)
                throw new ArgumentException("Data is invalid. (Unknown stop bits)", "data");
        }

        public SetPortBaudRateCommand(int baudRate, int dataBits, Parity parity, StopBits stopBits)
        {
            Data = new byte[FunctionCodeSize + 8];
            FunctionCode = SetPortBaudRateCommandFunctionCode;

            if (baudRate != 4800 && baudRate != 9600 && baudRate != 19200 && baudRate != 38400 && baudRate != 57600 && baudRate != 115200)
                throw new ArgumentException("baudRate is invalid.", "baudRate");

            if (dataBits < 5 || dataBits > 8)
                throw new ArgumentException("dataBits is invalid.", "dataBits");

            Data[1] = (byte)6;
            Data[2] = (byte)((baudRate & 0xFF000000) >> 24);
            Data[3] = (byte)((baudRate & 0xFF0000) >> 16);
            Data[4] = (byte)((baudRate & 0xFF00) >> 8);
            Data[5] = (byte)((baudRate & 0xFF));
            Data[6] = (byte)dataBits;
            Data[7] = (byte)parity;
            Data[8] = (byte)stopBits;

            Length = Data.Length;
        }

        public int BaudRate
        {
            get
            {
                return (Data[Offset + FunctionCodeSize + 1] << 24) | (Data[Offset + FunctionCodeSize + 2] << 16) | (Data[Offset + FunctionCodeSize + 3] << 8) | Data[Offset + FunctionCodeSize + 4];
            }
        }

        public int DataBits
        {
            get
            {
                return Data[Offset + FunctionCodeSize + 5];
            }
        }

        public Parity Parity
        {
            get
            {
                return (Parity)Data[Offset + FunctionCodeSize + 6];
            }
        }

        public StopBits StopBits
        {
            get
            {
                return (StopBits)Data[Offset + FunctionCodeSize + 7];
            }
        }
        
        public override string ToString()
        {
            StringBuilder descString = new StringBuilder();
            descString.Append("Set Port Baud Rate, Baud Rate:");
            descString.Append(BaudRate.ToString());
            descString.Append(", Data Bits:");
            descString.Append(DataBits.ToString());
            descString.Append(", Parity:");
            descString.Append(Parity.ToString());
            descString.Append(", Stop Bits:");
            descString.Append(StopBits.ToString());
            return descString.ToString();
        }

#if COMMUNICATIONSANALYZER

        public SetPortBaudRateCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetPortBaudRateCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
