﻿using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // This sets the encryption key for communication to card reader. This is the key used for OSDP encryption (secure channel):
    // 74, 0, ENCRYPTION_KEY
    // ENCRYPTION_KEY = 128bit (16 byte) encryption key used for encrypted OSDP communication.
    public class SetOsdpEncryptionKeyCommand : DeviceLoopMessageBase
    {
        public const int SetOsdpEncryptionKeyCommandFunctionCode = 74;

        public SetOsdpEncryptionKeyCommand(byte[] data, int offset, int length)
            : base(data, offset, length, FunctionCodeSize + 1)
        {
            if (Data[Offset + FunctionCodeSize] != 0)
                throw new ArgumentException("Data is invalid.", "data");

            if (length != (FunctionCodeSize + 17) && length != (FunctionCodeSize + 1))
                throw new ArgumentException("Data is of incorrect length.", "data");
        }

        public SetOsdpEncryptionKeyCommand(byte[] encryptionKey)
        {
            if (encryptionKey == null || encryptionKey.Length == 0)
            {
                Data = new byte[FunctionCodeSize + 1];

            }
            else if (encryptionKey.Length == 16)
            {
                Data = new byte[FunctionCodeSize + 17];
                Buffer.BlockCopy(encryptionKey, 0, Data, 2, 16);
            }
            else
            {
                throw new ArgumentException("encryptionKey is of incorrect length", "encryptionKey");
            }
            FunctionCode = SetOsdpEncryptionKeyCommandFunctionCode;
            Data[1] = (byte)0;
            Length = Data.Length;
        }

        public byte[] EncryptionKey
        {
            get
            {
                if ((Length - 1 - FunctionCodeSize) == 16)
                {
                    byte[] encryptionKey = new byte[16];
                    Buffer.BlockCopy(Data, Offset + 2, encryptionKey, 0, encryptionKey.Length);
                    return encryptionKey;
                }
                return null;
            }
        }

        public string EncryptionKeyAsString
        {
            get
            {
                if (EncryptionKey != null)
                    return BitConverter.ToString(EncryptionKey).Replace("-", "");
                return string.Empty;
            }
        }
             
        public override string ToString()
        {
            StringBuilder descString = new StringBuilder();
            descString.Append("Set OSDP Encryption Key, Key:");
#if DEBUG
            descString.Append(EncryptionKeyAsString);
#else
            descString.Append("****");
#endif
            return descString.ToString();
        }

#if COMMUNICATIONSANALYZER

        public SetOsdpEncryptionKeyCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetOsdpEncryptionKeyCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
