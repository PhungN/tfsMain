﻿using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // This is a bit mask for the EOL resistor tolerances for all device inputs:
    // 51, OWNERTYPE, STARTINGPOINT, NUMBEROFINPUTS, TOL_1 , ... , TOL_N
    // OWNERTYPE = Onboard, Expansion1, Expansion2, ... as defined in Common.OwnerType enumerator
    // STARTINGPOINT = 0, 1, 2, 3, ... N =  Starting point number on the owning device
    // NUMBEROFINPUTS = number of bits to look at in the message
    // TOL_1...TOL_N = 8 bit tolerance mask for 8 alarm input points.
    // Tolerance bit = 0 for 12.5% and bit = 1 for 25% tolerance.
    public class SetEndOfLineResistorTolerancesCommand : DeviceLoopMessageBase
    {
        public const int SetEndOfLineResistorTolerancesCommandFunctionCode = 51;

        /// <summary>
        /// Single byte for number of inputs.
        /// </summary>
        public const int NumberOfInputsSize = 1;

        /// <summary>
        /// Return maximum number of data parts (bool types in an array) for this message.
        /// </summary>
        public const int MaximumDataLength = (MaximumDataBytesFromController - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize)) * 8;

        public SetEndOfLineResistorTolerancesCommand(byte[] data, int offset, int length)
            : base(data, offset, length, FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + 1 /* Min one byte with one bit */)
        {
            if (Enum.IsDefined(typeof(OwnerType), (int)Data[Offset + FunctionCodeSize]) == false)
                throw new ArgumentException("Data is invalid.", "data");
        }

        public void GetEndOfLineResistorTolerances(out OwnerType ownerType, out int startingPoint, out ResistorTolerance[] resistorTolerances)
        {
            FunctionCode = SetEndOfLineResistorTolerancesCommandFunctionCode;
            ownerType = (OwnerType)Data[Offset + FunctionCodeSize];
            startingPoint = Data[Offset + FunctionCodeSize + OwnerTypeSize];
            int numberOfInputs = Data[Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize];
            resistorTolerances = new ResistorTolerance[numberOfInputs];

            for (int byteIndex = 0; byteIndex < (Length - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize)); byteIndex++)
            {
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    int arrayIndex = (byteIndex * 8) + bitIndex;
                    if (arrayIndex < numberOfInputs)
                    {
                        if ((Data[Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + byteIndex] & (byte)(1 << bitIndex)) == 0)
                            resistorTolerances[arrayIndex] = ResistorTolerance.TwelveAndAHalfPercent;
                        else
                            resistorTolerances[arrayIndex] = ResistorTolerance.TwentyFivePercent;
                    }
                }
            }
        }

        public SetEndOfLineResistorTolerancesCommand(OwnerType ownerType, int startingPoint, ResistorTolerance[] resistorTolerances)
        {
            int bytesRequiredForData = resistorTolerances.Length / 8;
            if (resistorTolerances.Length != 0 && (resistorTolerances.Length % 8) > 0)
                bytesRequiredForData++;

            bytesRequiredForData = Math.Min(bytesRequiredForData, MaximumDataLength / 8);

            Data = new byte[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + bytesRequiredForData];
            FunctionCode = SetEndOfLineResistorTolerancesCommandFunctionCode;

            Data[OwnerTypeSize] = (byte)ownerType;
            Data[OwnerTypeSize + StartingPointSize] = (byte)startingPoint;
            Data[OwnerTypeSize + StartingPointSize + NumberOfInputsSize] = (byte)resistorTolerances.Length;

            for (int byteIndex = 0; byteIndex < bytesRequiredForData; byteIndex++)
            {
                byte configuredBitField = 0;
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    int arrayIndex = (byteIndex * 8) + bitIndex;
                    if (resistorTolerances.Length <= arrayIndex)
                        break;

                    if (resistorTolerances[arrayIndex] == ResistorTolerance.TwentyFivePercent)
                        configuredBitField |= (byte)(1 << bitIndex);
                }
                Data[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + byteIndex] = configuredBitField;
            }
            Length = Data.Length;
        }

        public override string ToString()
        {
            ResistorTolerance[] resistorTolerances;
            OwnerType ownerType;
            int startingPoint;
            GetEndOfLineResistorTolerances(out ownerType, out startingPoint, out resistorTolerances);

            StringBuilder descString = new StringBuilder();
            descString.Append("Set EOL Resistor Tolerances for Inputs, Owner:");
            descString.Append(ownerType.ToString());
            descString.Append(", StartingPoint:");
            descString.Append(startingPoint.ToString());
            descString.Append(", NumberOfInputs:");
            descString.Append(resistorTolerances.Length.ToString());
            descString.Append(" (");
            for (int i = 0; i < resistorTolerances.Length; i++)
            {
                if (i > 0)
                    descString.Append("-");
                if (resistorTolerances[i] == ResistorTolerance.TwelveAndAHalfPercent)
                    descString.Append("12.5%");
                else
                    descString.Append("25%");
            }
            descString.Append(")");
            return descString.ToString();
        }

#if COMMUNICATIONSANALYZER

        public SetEndOfLineResistorTolerancesCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetEndOfLineResistorTolerancesCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
