﻿using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // This is a bit mask of the outputs that are defined for an IO device:
    // 49, OWNERTYPE, STARTINGPOINT, NUMBEROFOUTPUTS, BITS_1 , ... , BITS_N
    // OWNERTYPE = Tamper, Onboard, Expansion1, Expansion2, ... as defined in Common.OwnerType enumerator
    // STARTINGPOINT = 0, 1, 2, 3, ... N =  Starting point number on the owning device
    // NUMBEROFOUTPUTS = number of bits to look at in the message
    // BITS_1...BITS_N = A value of 1 is set for each defined input
    public class SetConfiguredOutputsCommand : DeviceLoopMessageBase
    {
        public const int SetConfiguredOutputsCommandFunctionCode = 49;

        /// <summary>
        /// Single byte for number of outputs.
        /// </summary>
        public const int NumberOfOutputsSize = 1;

        public SetConfiguredOutputsCommand(byte[] data, int offset, int length)
            : base(data, offset, length, FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfOutputsSize + 1 /* Min one byte with one bit */)
        {
            if (Enum.IsDefined(typeof(OwnerType), (int)Data[Offset + FunctionCodeSize]) == false)
                throw new ArgumentException("Data is invalid.", "data");
        }

        /// <summary>
        /// Return maximum number of data parts (bool types in an array) for this message.
        /// </summary>
        public const int MaximumDataLength = (MaximumDataBytesFromController - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfOutputsSize)) * 8;

        public SetConfiguredOutputsCommand(OwnerType ownerType, int startingPoint, bool[] configuredOutputs)
        {
            int bytesRequiredForData = configuredOutputs.Length / 8;
            if (configuredOutputs.Length != 0 && (configuredOutputs.Length % 8) > 0)
                bytesRequiredForData++;

            bytesRequiredForData = Math.Min(bytesRequiredForData, MaximumDataLength / 8);

            Data = new byte[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfOutputsSize + bytesRequiredForData];
            FunctionCode = SetConfiguredOutputsCommandFunctionCode;

            Data[OwnerTypeSize] = (byte)ownerType;
            Data[OwnerTypeSize + StartingPointSize] = (byte)startingPoint;
            Data[OwnerTypeSize + StartingPointSize + NumberOfOutputsSize] = (byte)configuredOutputs.Length;

            for (int byteIndex = 0; byteIndex < bytesRequiredForData; byteIndex++)
            {
                byte configuredBitField = 0;
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    int arrayIndex = (byteIndex * 8) + bitIndex;
                    if (configuredOutputs.Length <= arrayIndex)
                        break;

                    if (configuredOutputs[arrayIndex])
                        configuredBitField |= (byte)(1 << bitIndex);
                }
                Data[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfOutputsSize + byteIndex] = configuredBitField;
            }
            Length = Data.Length;
        }

        public void GetConfiguredOutputs(out OwnerType ownerType, out int startingPoint, out bool[] configuredOutputs)
        {
            ownerType = (OwnerType)Data[Offset + FunctionCodeSize];
            startingPoint = Data[Offset + FunctionCodeSize + OwnerTypeSize];
            int numberOfOutputs = Data[Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize];
            configuredOutputs = new bool[numberOfOutputs];

            for (int byteIndex = 0; byteIndex < (Length - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfOutputsSize)); byteIndex++)
            {
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    int arrayIndex = (byteIndex * 8) + bitIndex;
                    if (arrayIndex < numberOfOutputs)
                    {
                        if ((Data[Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfOutputsSize + byteIndex] & (byte)(1 << bitIndex)) == 0)
                            configuredOutputs[arrayIndex] = false;
                        else
                            configuredOutputs[arrayIndex] = true;
                    }
                }
            }
        }

        public override string ToString()
        {
            OwnerType ownerType;
            int startingPoint;
            bool[] configuredOutputs;
            GetConfiguredOutputs(out ownerType, out startingPoint, out configuredOutputs);

            StringBuilder descString = new StringBuilder();
            descString.Append("Set Configured Outputs, Owner:");
            descString.Append(ownerType.ToString());
            descString.Append(", StartingPoint:");
            descString.Append(startingPoint.ToString());
            descString.Append(", NumberOfOutputs:");
            descString.Append(configuredOutputs.Length.ToString());
            descString.Append(" (");
            for (int i = 0; i < configuredOutputs.Length; i++)
            {
                if (i > 0)
                    descString.Append("-");
                if (configuredOutputs[i])
                    descString.Append("1");
                else
                    descString.Append("0");
            }
            descString.Append(")");
            return descString.ToString();
        }

#if COMMUNICATIONSANALYZER

        public SetConfiguredOutputsCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetConfiguredOutputsCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return "Set Configured Outputs";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
