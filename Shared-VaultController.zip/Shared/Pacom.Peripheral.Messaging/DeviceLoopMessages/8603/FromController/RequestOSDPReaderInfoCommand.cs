﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    // The device information for all OSDP readers on the 8603.  
    // The message format is:
    // 71 0
    public class RequestOsdpReaderInfoCommand : DeviceLoopMessageBase
    {

        public const int RequestOsdpReaderInfoCommandFunctionCode = 71;

        public RequestOsdpReaderInfoCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 2)
        {
        }

        public RequestOsdpReaderInfoCommand()
        {
            Data = new byte[2];
            FunctionCode = RequestOsdpReaderInfoCommandFunctionCode;

            Length = 2;
        }

        public override string ToString()
        {
            return "Request OSDP Reader Info";
        }

#if COMMUNICATIONSANALYZER

        // Default constructor already defined

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { RequestOsdpReaderInfoCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
