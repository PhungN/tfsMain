﻿using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8603
{
    /// <summary>
    /// Process command received from controller after card data was scanned.
    /// </summary>
    public class CardReaderDisplaySecurityLevelCommand : DeviceLoopMessageBase
    {
        private const int MinMessageLength = 5;
        public const byte SecurityLevelFunctionCode = 25;

        /// <summary>
        /// Parse "CardReaderDisplaySecurityLevelCommand" device loop message.
        /// </summary>
        /// <param name="data">Byte array with device loop message.</param>
        /// <param name="offset">Offset is used to indicate position of function code in the byte array.</param>
        /// <param name="length">Length of data from function code to the end of array or check code.</param>
        public CardReaderDisplaySecurityLevelCommand(byte[] data, int offset, int length)
            : base(data, offset, length, MinMessageLength)
        {
        }

        /// <summary>
        /// Format device loop mesage from CardReaderDisplaySecurityLevelConfig class
        /// </summary>
        /// <param name="readerId"></param>
        /// <param name="config"></param>
        public CardReaderDisplaySecurityLevelCommand(CardReaderDisplaySecurityLevelConfig config)
        {
            if (string.IsNullOrEmpty(config.DisplayText) == false)
                this.Data = new byte[MinMessageLength + config.DisplayText.Length];
            else
                this.Data = new byte[MinMessageLength];
            this.FunctionCode = SecurityLevelFunctionCode;
            Data[1] = (byte)config.Readers;
            Data[2] = config.Flags;
            Data[3] = (byte)config.AlertCommand;

            int durationInSeconds = (int)config.DisplayDuration.TotalSeconds; 
            if (durationInSeconds > 127)                // Display duration
                Data[4] = (byte)((byte)config.DisplayDuration.TotalMinutes | 0x80);
            else
                Data[4] = (byte)durationInSeconds;   

            if (string.IsNullOrEmpty(config.DisplayText) == false)
                Array.Copy(Encoding.ASCII.GetBytes(config.DisplayText), 0, Data, 5, config.DisplayText.Length);
            this.Length = this.Data.Length;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        public CardReaderDisplaySecurityLevelConfig GetConfiguration()
        {
            if (Data.Length >= MinMessageLength)
            {
                byte functionCode = Data[Offset];
                if (functionCode == SecurityLevelFunctionCode)
                {
                    var config = new CardReaderDisplaySecurityLevelConfig();
                    config.Readers = Data[Offset + 1];
                    config.Flags = Data[Offset + 2];
                    config.AlertCommand = (AlertCommand)Data[Offset + 3];

                    if (Data[Offset + 4] > 127)
                        config.DisplayDuration = new TimeSpan(0, (Data[Offset + 4] & 0x7F), 0);
                    else
                        config.DisplayDuration = new TimeSpan(0, 0, Data[Offset + 4]);
                    if (Length > MinMessageLength)
                        config.DisplayText = System.Text.Encoding.ASCII.GetString(Data, Offset + 5, Length - MinMessageLength);
                    return config;
                }
            }
            return null;
        }

        public override string ToString()
        {
            CardReaderDisplaySecurityLevelConfig config = GetConfiguration();
            if (config != null)
                return string.Format("Security Level Command ({0})", config.ToString());
            return string.Format("Invalid Security Level Command");
        }

#if COMMUNICATIONSANALYZER

        public CardReaderDisplaySecurityLevelCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] {
                Reader1FunctionCode, Reader2FunctionCode,
                Reader3FunctionCode, Reader4FunctionCode
            }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8603 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            CardReaderDisplaySecurityLevelConfig config = GetConfiguration();
            if (config != null)
                return string.Format("Card Reader Notify Reader Command {0}", config.CardReaderId.ToString());
            else
                return "Card Reader CardReaderNotifyReaderConfig Reader Command";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
