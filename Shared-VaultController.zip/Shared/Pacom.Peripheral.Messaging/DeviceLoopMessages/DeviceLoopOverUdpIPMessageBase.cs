﻿using System;
using System.Text;
using System.Security.Cryptography;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public abstract class DeviceLoopOverUdpIPMessageBase
    {
        public const int ControllerUnitNumber = 0xFF;

        public DeviceLoopOverUdpIPMessageBase(byte[] receivedData)
        {
            if (receivedData == null)
                throw new ArgumentException("receivedData is null", "receivedData");
            this.Data = receivedData;
        }

        public DeviceLoopOverUdpIPMessageBase(int messageType, int sourceUnitNumber, int destinationUnitNumber, byte sessionId, UInt32 deviceSequenceNumber, UInt32 controllerSequenceNumber, int dataLength)
        {
            Data = new byte[dataLength];

            // Header - 2 byte big endian header ID number ( 5002 for device, 5003 for RTU)
            Data[0] = 0x50;

            if (sourceUnitNumber == ControllerUnitNumber)
                Data[1] = 0x03;
            else
                Data[1] = 0x02;

            // Message Type
            Data[2] = (byte)messageType;

            // Source Unit Number - The zero based device address (0 - 127) or 0xFF for the controller
            Data[3] = (byte)sourceUnitNumber;

            // Destination Unit Number - The zero based device address (0 - 127) or 0xFF for the controller
            Data[4] = (byte)destinationUnitNumber;

            // Session Id - 1 byte
            Data[5] = sessionId;

            // Device Sequence Number - 4 bytes
            Buffer.BlockCopy(BitConverter.GetBytes(deviceSequenceNumber), 0, Data, 6, 4);

            // Controller Sequence Number - 4 bytes
            Buffer.BlockCopy(BitConverter.GetBytes(controllerSequenceNumber), 0, Data, 10, 4);
        }

        public bool FromController
        {
            get
            {
                if (Data[1] == 3)
                    return true;
                return false;
            }
        }

        public DeviceLoopOverUdpIPMessageType MessageType
        {
            get
            {
                return (DeviceLoopOverUdpIPMessageType)Data[2];
            }
        }

        /// <summary>
        /// The zero based device address (0 - 127) or 0xFF for the controller
        /// </summary>
        public int SourceUnitNumber
        {
            get
            {
                return Data[3];
            }
        }

        /// <summary>
        /// The zero based device address (0 - 127) or 0xFF for the controller
        /// </summary>
        public int DestinationUnitNumber
        {
            get
            {
                return Data[4];
            }
        }

        public byte SessionId
        {
            get
            {
                return Data[5];
            }
        }

        public uint DeviceSequenceNumber
        {
            get
            {
                return BitConverter.ToUInt32(Data, 6);
            }
        }

        public uint PollSequenceNumber
        {
            get
            {
                return DeviceSequenceNumber;
            }
        }

        public uint ControllerSequenceNumber
        {
            get
            {
                return BitConverter.ToUInt32(Data, 10);
            }
        }

        public abstract int HmacSessionKeyOffset
        {
            get;
        }

        public byte[] Data
        {
            get;
            private set;
        }

        public static DeviceLoopOverUdpIPMessageBase Create(byte[] receivedData)
        {
            if (receivedData == null || receivedData.Length < 30)
                return null;

            if (receivedData[0] == 0x50 && (receivedData[1] == 0x02 || receivedData[1] == 0x03))
            {
                try
                {
                    switch (receivedData[2])
                    {
                        case 1: return new DeviceLoopOverUdpIPMessageLogOn(receivedData);
                        case 2: return new DeviceLoopOverUdpIPMessageLogOnResponseSuccess(receivedData);
                        case 3: return new DeviceLoopOverUdpIPMessageLogOnResponseSetMasterKey(receivedData);
                        case 4: return new DeviceLoopOverUdpIPMessageData(receivedData);
                        case 5: return new DeviceLoopOverUdpIPMessageAck(receivedData);
                        case 6: return new DeviceLoopOverUdpIPMessagePoll(receivedData);
                        case 7: return new DeviceLoopOverUdpIPMessageLogOff(receivedData);
                    }
                }
                catch
                {
                }
            }
            return null;
        }
    }
}
