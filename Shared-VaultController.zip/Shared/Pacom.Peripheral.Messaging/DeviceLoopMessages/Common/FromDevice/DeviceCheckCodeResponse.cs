﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    // When the BAU sends the device check message the device must reply with a code byte 
    // obtained by transforming the string sent to it.  The message format is:
    // 0, CHECK
    // CHECK is the returned check code byte.
    public class DeviceCheckCodeResponse : DeviceLoopMessageBase
    {
        public const int DeviceCheckCodeResponseFunctionCode = 0;

        public DeviceCheckCodeResponse(byte[] data, int offset, int length)
            : base(data, offset, length, 2)
        {
        }

        public DeviceCheckCodeResponse(byte deviceCheckCode)
        {
            Data = new byte[2];
            FunctionCode = DeviceCheckCodeResponseFunctionCode;

            Data[1] = deviceCheckCode;
            Length = 2;
        }

        public byte CheckCode
        {
            get
            {
                return Data[Offset + 1];
            }
        }

        public override string ToString()
        {
            return string.Format("Device Check Code Response ({0})", CheckCode);
        }

#if COMMUNICATIONSANALYZER

        public DeviceCheckCodeResponse()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { DeviceCheckCodeResponseFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
