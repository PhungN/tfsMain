﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    // 15h, BANK
    //
    // BANK – bank number to download. Length of this field is set by device’s version reply
    public class BankDownloadRequest : DeviceLoopMessageBase
    {

        public const int BankDownloadRequestFunctionCode = 21;

        public BankDownloadRequest(byte[] data, int offset, int length, int bankFieldLength)
            : base(data, offset, length, 1 + bankFieldLength)
        {
        }

        public BankDownloadRequest(int bankFieldLength, int bank)
        {
            Data = new byte[1 + bankFieldLength];
            FunctionCode = BankDownloadRequestFunctionCode;

            switch (bankFieldLength)
            {
                case 1:
                    Data[1] = (byte)(bank & 0xFF);
                    break;
                case 2:
                    Data[1] = (byte)((bank >> 8) & 0xFF);
                    Data[2] = (byte)((bank) & 0xFF);
                    break;
                case 3:
                    Data[1] = (byte)((bank >> 16) & 0xFF);
                    Data[2] = (byte)((bank >> 8) & 0xFF);
                    Data[3] = (byte)((bank) & 0xFF);
                    break;
                case 4:
                    Data[1] = (byte)((bank >> 24) & 0xFF);
                    Data[2] = (byte)((bank >> 16) & 0xFF);
                    Data[3] = (byte)((bank >> 8) & 0xFF);
                    Data[4] = (byte)((bank) & 0xFF);
                    break;
            }

            Length = Data.Length;
        }

        public int Bank
        {
            get
            {
                switch (Length)
                {
                    case 2:
                        return Data[Offset + 1];
                    case 3:
                        return (Data[Offset + 1] << 8) + Data[Offset + 2];
                    case 4:
                        return (((Data[Offset + 1] << 8) + Data[Offset + 2]) << 8) + Data[Offset + 3];
                    case 5:
                        return (((((Data[Offset + 1] << 8) + Data[Offset + 2]) << 8) + Data[Offset + 3]) << 8) + Data[Offset + 4];
                }
                return 0;
            }
        }

        public override string ToString()
        {
            return "Bank Download (Bank = " + Bank.ToString() + ")";
        }

#if COMMUNICATIONSANALYZER

        public BankDownloadRequest()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { BankDownloadRequestFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
