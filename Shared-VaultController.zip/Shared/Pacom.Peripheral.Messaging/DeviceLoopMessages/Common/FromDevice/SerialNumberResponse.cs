﻿using System.Text;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    // This function code is used to allow the device to send it's serial number to the BAU. 
    // It sent in response to receiving a get device serial number command.
    // The message format is:
    // 254, DATA ...
    // where DATA is a 16 byte serial number.

    public class SerialNumberResponse : DeviceLoopMessageBase
    {
        public const int SerialNumberResponseFunctionCode = 254;

        public SerialNumberResponse(byte[] data, int offset, int length)
            : base(data, offset, length, 17)
        {
        }

        public SerialNumberResponse(string serialNumber)
        {
            Data = new byte[17];
            FunctionCode = SerialNumberResponseFunctionCode;
            Length = Data.Length;

            for (int i = 0; i < 16; i++)
            {
                Data[i + 1] = (byte)serialNumber[i];
            }
        }

        public string SerialNumber
        {
            get { return Encoding.ASCII.GetString(Data, Offset + 1, 16); }
        }

        public override string ToString()
        {
            string serialNumber = SerialNumber.Trim(new char[] { '\0' });
            if (string.IsNullOrEmpty(serialNumber) == false)
                return string.Format("Serial Number Response ({0})", serialNumber);
            else
                return "No Serial Number";
        }

#if COMMUNICATIONSANALYZER

        public SerialNumberResponse()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SerialNumberResponseFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
