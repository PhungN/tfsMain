﻿using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    // The BAU can send a random string to a device to check that it is a valid device.
    // The device will transform the string and return a byte that the BAU can test.  
    // The message format is:
    // 00 , RB_1 , ... , RB_8
    // RB_1 to RB_8 are random numbers.
    public class CheckDeviceCommand : DeviceLoopMessageBase
    {
        public const int CheckDeviceCommandFunctionCode = 0;

        static Random random = new Random();
        
        public CheckDeviceCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 9)
        {
        }

        public CheckDeviceCommand()
        {
            Data = new byte[9];
            random.NextBytes(Data);
            FunctionCode = CheckDeviceCommandFunctionCode;

            Length = 9;
        }

        public byte[] GetRandomBytes()
        {
            byte[] randomBytes = new byte[8];
            Buffer.BlockCopy(Data, Offset + 1, randomBytes, 0, 8);
            return randomBytes;
        }

        public void SetRandomBytes(byte[] randomBytes)
        {
            Buffer.BlockCopy(randomBytes, 0, Data, Offset + 1, 8);
        }

        public override string ToString()
        {
            return "Check Device (" + BitConverter.ToString(Data, Offset + 1, 8) + ")";
        }

#if COMMUNICATIONSANALYZER

        // Default constructor already defined

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { CheckDeviceCommandFunctionCode };  }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
