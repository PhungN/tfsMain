﻿using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    /// <summary>
    /// Message setting time on a device.
    /// </summary>
    public class SetSystemTimeBroadcastCommand : DeviceLoopMessageBase
    {

        public const int SetSystemTimeBroadcastCommandFunctionCode = 252;

        public SetSystemTimeBroadcastCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 8)
        {
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public SetSystemTimeBroadcastCommand(DateTime timeData)
        {
            this.Data = new byte[8];
            this.FunctionCode = SetSystemTimeBroadcastCommandFunctionCode;
            constructSetSystemTimeCommand(timeData);
            this.Length = this.Data.Length;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public bool GetConfiguration(out DateTime timeData)
        {
            if (this.Data.Length < 8)
            {
                timeData = DateTime.MinValue;
                return false;
            }
            timeData = parseSetSystemTimeCommand();
            if (timeData == DateTime.MinValue)
            {
                return false;
            }
            return true;
        }

        private void constructSetSystemTimeCommand(DateTime timeData)
        {
            this.Data[this.Offset + 1] = (byte)timeData.Second;
            this.Data[this.Offset + 2] = (byte)timeData.Minute;
            this.Data[this.Offset + 3] = (byte)timeData.Hour;
            this.Data[this.Offset + 4] = (byte)timeData.Day;
            this.Data[this.Offset + 5] = (byte)timeData.Month;
            this.Data[this.Offset + 6] = (byte)(timeData.Year - 2000);
            this.Data[this.Offset + 7] = (byte)timeData.DayOfWeek;
        }

        private DateTime parseSetSystemTimeCommand()
        {
            try
            {
                int second = this.Data[this.Offset + 1];
                int minute = this.Data[this.Offset + 2];
                int hour = this.Data[this.Offset + 3];
                int day = this.Data[this.Offset + 4];
                int month = this.Data[this.Offset + 5];
                int year = (short)(2000 + this.Data[this.Offset + 6]);
                return new DateTime(year, month, day, hour, minute, second);
            }
            catch
            {
                return DateTime.MinValue;
            }
        }

        public override string ToString()
        {
            return "Set System Time Broadcast";
        }

#if COMMUNICATIONSANALYZER

        public SetSystemTimeBroadcastCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetSystemTimeBroadcastCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override bool FromControllerBroadcast
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
