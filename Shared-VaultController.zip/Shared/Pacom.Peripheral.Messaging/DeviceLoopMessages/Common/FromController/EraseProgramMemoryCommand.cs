﻿using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    // 2A, VERL, VERH
	// VERL, VERH – Two-byte version number of new software to be sent
    //              00.00 also accepted for version number
    public class EraseProgramMemoryCommand : DeviceLoopMessageBase
    {
        public const int EraseProgramMemoryCommandFunctionCode = 42;

        public EraseProgramMemoryCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 3)
        {
        }

        public EraseProgramMemoryCommand(FirmwareVersion version)
        {
            Data = new byte[3];
            FunctionCode = EraseProgramMemoryCommandFunctionCode;
            Data[1] = (byte)version.Minor;
            Data[2] = (byte)version.Major;

            Length = 3;
        }

        public FirmwareVersion FirmwareVersion
        {
            get
            {
                return new FirmwareVersion(Data[Offset + 2], Data[Offset + 1]);
            }
        }

        public override string ToString()
        {
            return "Erase Program Memory (" + FirmwareVersion.ToString() + ")";
        }

#if COMMUNICATIONSANALYZER

        public EraseProgramMemoryCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { EraseProgramMemoryCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
