﻿using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    // ADDR, CTRL, BC, 2C, BANK, OFFSET, DATA, FLAGS, CHECKSUM, CS
    // BANK = current bank number being downloaded, 256 bytes in each bank. 	   
    // Length of this field is set by device’s version reply 
    // OFFSET = Offset into the current bank where the first data byte is to be stored. (The first byte of the bank is at offset zero.)
    // DATA = 8 bit data to fill the memory locations, up to 28 bytes
	// 	   All 16 bit numbers are sent high order byte first
    // FLAGS =  Bit 0 – last bytes in current bank, 1=yes
    //          Bit 1 – last bank to write, 1=yes
    //          Bit 2 – 
    //          Bit 3 – 
    //          Bit 4 – 1, segment placement (0-9)
    //          Bit 5 – 2, “                                    “
    //          Bit 6 – 4, “                                    “
    //          Bit 7 – 8, “                                    “
    // CHECKSUM – One byte checksum of the entire current bank, valid when FLAGS  bit 0 = 1. 
    //          This byte is a 2’s compliment of the 8 bit sum on the entire bank including 
    //          unused bytes (unused bytes are set to a value of 0xFF). If this field is unused, 
    //          then a value of 0xFF is sent and is ignored by the receiving device.
    public class SoftwareDownloadCommand : DeviceLoopMessageBase
    {
        public const int SoftwareDownloadCommandFunctionCode = 44;

        private int bankFieldLength;

        public SoftwareDownloadCommand(byte[] data, int offset, int length, int bankFieldLength)
            : base(data, offset, length, bankFieldLength + 4)
        {
            this.bankFieldLength = bankFieldLength;
        }

        public SoftwareDownloadCommand(int bankFieldLength, int bank, int bankOffset, byte[] data, int dataOffset, int dataLength, SoftwareDownloadFlags softwareDownloadFlags, int bankChecksum)
        {
            this.bankFieldLength = bankFieldLength;
            Data = new byte[bankFieldLength + 4 + dataLength];

            FunctionCode = SoftwareDownloadCommandFunctionCode;
            switch (bankFieldLength)
            {
                case 1:
                    Data[1] = (byte)(bank & 0xFF);
                    break;
                case 2:
                    Data[1] = (byte)((bank >> 8) & 0xFF);
                    Data[2] = (byte)((bank) & 0xFF);
                    break;
                case 3:
                    Data[1] = (byte)((bank >> 16) & 0xFF);
                    Data[2] = (byte)((bank >> 8) & 0xFF);
                    Data[3] = (byte)((bank) & 0xFF);
                    break;
                case 4:
                    Data[1] = (byte)((bank >> 24) & 0xFF);
                    Data[2] = (byte)((bank >> 16) & 0xFF);
                    Data[3] = (byte)((bank >> 8) & 0xFF);
                    Data[4] = (byte)((bank) & 0xFF);
                    break;
            }
            Data[1 + bankFieldLength] = (byte)bankOffset;
            Buffer.BlockCopy(data, dataOffset, Data, bankFieldLength + 2, dataLength);
            Data[2 + bankFieldLength + dataLength] = (byte)softwareDownloadFlags;
            if ((softwareDownloadFlags & SoftwareDownloadFlags.LastBytesInBank) != 0)
                Data[3 + bankFieldLength + dataLength] = (byte)bankChecksum;
            else
                Data[3 + bankFieldLength + dataLength] = 0xFF;

            Length = Data.Length;
        }

        public int Bank
        {
            get
            {
                switch (bankFieldLength)
                {
                    case 1:
                        return Data[Offset + 1];
                    case 2:
                        return (Data[Offset + 1] << 8) + Data[Offset + 2];
                    case 3:
                        return (((Data[Offset + 1] << 8) + Data[Offset + 2]) << 8) + Data[Offset + 3];
                    case 4:
                        return (((((Data[Offset + 1] << 8) + Data[Offset + 2]) << 8) + Data[Offset + 3]) << 8) + Data[Offset + 4];
                }
                return 0;
            }
        }

        public int BankOffset
        {
            get
            {
                return Data[Offset + 1 + bankFieldLength];
            }
        }

        public SoftwareDownloadFlags SoftwareDownloadFlags
        {
            get
            {
                return (SoftwareDownloadFlags)Data[Offset + Length - 2];
            }
        }

        public bool LastBytesInBank
        {
            get { return (SoftwareDownloadFlags & SoftwareDownloadFlags.LastBytesInBank) == SoftwareDownloadFlags.LastBytesInBank; }
        }

        public bool LastBankToWrite
        {
            get { return (SoftwareDownloadFlags & SoftwareDownloadFlags.LastBankToWrite) == SoftwareDownloadFlags.LastBankToWrite; }
        }

        public int BankChecksum
        {
            get
            {
                return Data[Offset + Length - 1];
            }
        }

        public void GetPayload(out byte[] payload, out int offset, out int length)
        {
            payload = Data;
            offset = Offset + bankFieldLength + 2;
            length = Length - bankFieldLength - 4;
        }

        public override string ToString()
        {
            return "Software Download Command (Bank: " + Bank + " Offset: " + BankOffset + " Length: " + (Length - 4) + " Flags: " + SoftwareDownloadFlags + ")";
        }

#if COMMUNICATIONSANALYZER

        public SoftwareDownloadCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SoftwareDownloadCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
