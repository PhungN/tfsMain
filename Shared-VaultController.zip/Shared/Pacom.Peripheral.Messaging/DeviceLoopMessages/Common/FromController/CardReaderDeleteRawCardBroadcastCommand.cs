﻿using System;
#if CONTROLLER
using Pacom.Peripheral.Common.AccessControl;
#endif

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    /// <summary>
    /// Delete card from all readers degraded memory command via a controller broadcast (unicast over IP)
    /// The message format is:
    /// 4, FLAGS, BITS, DATA
    /// where FLAGS is currently unused, set to 0
    ///       BITS is the card number length in bits
    ///       DATA is the card number as it is natively stored in the 8003/8501/8603.
    ///       
    /// A delete command for a 26 bit wiegand card with FC = 67 and CN = 03991 is as follows
    /// 04 00 1A A1 87 CB 80 
    /// 
    /// This command will work fine for card numbers up to 240 bits but over this, some legacy devices sharing the device loop may require
    /// attention as this message will be longer than they can support.
    /// </summary>
    public class CardReaderDeleteRawCardBroadcastCommand : DeviceLoopMessageBase
    {
        public const int CardReaderDeleteRawCardBroadcastCommandSerialFunctionCode = 4;
        public const int CardReaderDeleteRawCardBroadcastCommandIPFunctionCode = 250;

        public CardReaderDeleteRawCardBroadcastCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 4)
        {
        }

#if CONTROLLER
        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        public CardReaderDeleteRawCardBroadcastCommand(CardNumberHolder cardNumber, bool overTcpIP)
        {
            // Delete a single card
            int requiredBytes;
            int cardBitLength = cardNumber.Raw.CardBitLength;

            if (cardBitLength % 8 == 0)
                requiredBytes = cardBitLength / 8;
            else
                requiredBytes = (cardBitLength / 8) + 1;

            Data = new byte[requiredBytes + 3];
            FunctionCode = (byte)(overTcpIP ? CardReaderDeleteRawCardBroadcastCommandIPFunctionCode : CardReaderDeleteRawCardBroadcastCommandSerialFunctionCode);
            CardBitLength = cardBitLength;
            Buffer.BlockCopy(cardNumber.Raw.CardNumber, 0, Data, 3, requiredBytes);
            Length = Data.Length;
        }
#endif

        public int CardBitLength
        {
            get
            {
                return Data[Offset + 2];
            }
            private set
            {
                Data[Offset + 2] = (byte)value;
            }
        }

        public byte[] CardNumber
        {
            get
            {
                int requiredBytes;
                if (CardBitLength % 8 == 0)
                    requiredBytes = CardBitLength / 8;
                else
                    requiredBytes = (CardBitLength / 8) + 1;

                byte[] cardNumber = new byte[32];
                Buffer.BlockCopy(Data, Offset + 3, cardNumber, 0, requiredBytes);
                return cardNumber;
            }
        }

        public override string ToString()
        {
            return "Delete Raw Card Broadcast";
        }

#if COMMUNICATIONSANALYZER

        public CardReaderDeleteRawCardBroadcastCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { CardReaderDeleteRawCardBroadcastCommandSerialFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override bool FromControllerBroadcast
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {            
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(this.ToString());
            sb.Append(Environment.NewLine);
            sb.Append(Environment.NewLine);
            sb.Append(string.Format("Card Length: {0}", CardBitLength));
            sb.Append(Environment.NewLine);
            sb.Append(string.Format("Card Number: {0}", BitConverter.ToString(CardNumber)));
            sb.Append(Environment.NewLine);
            return sb.ToString();
        }
#endif
    }
}
