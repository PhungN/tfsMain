﻿
namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    // 2B
    // Message will force a processor restart
    public class RestartDeviceCommand : DeviceLoopMessageBase
    {
        public const int RestartDeviceCommandFunctionCode = 43;

        public RestartDeviceCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public RestartDeviceCommand()
        {
            Data = new byte[1];
            FunctionCode = RestartDeviceCommandFunctionCode;

            Length = 1;
        }

        public override string ToString()
        {
            return "Restart Device";
        }

#if COMMUNICATIONSANALYZER

        // Default constructor already defined

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { RestartDeviceCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
