﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Utils;
#if CONTROLLER
using Pacom.Peripheral.Common.AccessControl;
#endif

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    /// <summary>
    /// Modify card reader degraded (master) memory command via controller broadcast
    /// </summary>
    public class CardReaderModifyDegradedMemoryBroadcastCommand : DeviceLoopMessageBase
    {
        public const int CardReaderModifyDegradedMemoryBroadcastCommandSerialFunctionCode = 3;
        public const int CardReaderModifyDegradedMemoryBroadcastCommandIPFunctionCode = 251;

        public CardReaderModifyDegradedMemoryBroadcastCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 10)
        {
        }

#if CONTROLLER
        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        public CardReaderModifyDegradedMemoryBroadcastCommand(CardNumberHolder cardNumber, bool overTcpIP)
        {
            if (cardNumber == null)
            {
                // Delete all cards
                Data = new byte[18];
                DeleteCard = true;
                ModifyFacility = false;
                CardRange = true;
                MasterCardStore = false;        // Applies to RAM and not the Master Card

                // 0000000000000000 - FFFFFFFFFFFFFFFF indicate all cards
                FirstCardLegacy = new CardNumberLegacy(0); 
                SecondCardLegacy = new CardNumberLegacy(-1);
            }
            else
            {
                // Delete a single card
                Data = new byte[10];
                DeleteCard = true;
                ModifyFacility = false;
                CardRange = false;
                MasterCardStore = false;        // Applies to RAM and not the Master Card

                if (cardNumber.IsRawCardFormat)
                {
                    byte[] rawCardNumber;
                    if (translate8003CardNumberToPeripheralCardNumber(cardNumber.Raw.CardNumber, cardNumber.Raw.CardBitLength, out rawCardNumber))
                    {
                        Array.Reverse(rawCardNumber);
                        Buffer.BlockCopy(rawCardNumber, 0, Data, 2, Math.Min(rawCardNumber.Length, 8));
                    }

                }
                else
                {
                    FirstCardLegacy = cardNumber.Legacy;
                }
            }

            FunctionCode = (byte)(overTcpIP == true ?
                CardReaderModifyDegradedMemoryBroadcastCommandIPFunctionCode :
                CardReaderModifyDegradedMemoryBroadcastCommandSerialFunctionCode);
            Length = Data.Length;
        }
#endif

        private static bool translate8003CardNumberToPeripheralCardNumber(byte[] cardNumber, int cardBitLength, out byte[] peripheralCardNumber)
        {
            peripheralCardNumber = null;
            if (cardBitLength < 4 || cardBitLength > 256 || cardNumber == null)
                return false;

            int requiredBytes;
            int totalBytes;
            if (cardBitLength % 8 == 0)
            {
                requiredBytes = cardBitLength / 8;
                if (cardNumber.Length < requiredBytes)
                    return false;
                if ((requiredBytes % 8) == 0)
                    totalBytes = requiredBytes;
                else
                    totalBytes = ((requiredBytes / 8) + 1) * 8;
                peripheralCardNumber = new byte[totalBytes];
                Buffer.BlockCopy(cardNumber, 0, peripheralCardNumber, (peripheralCardNumber.Length - requiredBytes), requiredBytes);
            }
            else
            {
                requiredBytes = (cardBitLength / 8) + 1;
                if (cardNumber.Length < requiredBytes)
                    return false;
                if ((requiredBytes % 8) == 0)
                    totalBytes = requiredBytes;
                else
                    totalBytes = ((requiredBytes / 8) + 1) * 8;
                peripheralCardNumber = new byte[totalBytes];
                Buffer.BlockCopy(cardNumber, 0, peripheralCardNumber, (peripheralCardNumber.Length - requiredBytes), requiredBytes);
                int shiftBy = (requiredBytes * 8) - cardBitLength;
                for (int i = (peripheralCardNumber.Length - 1); i >= (peripheralCardNumber.Length - requiredBytes); i--)
                {
                    if (i == (peripheralCardNumber.Length - 1))
                    {
                        peripheralCardNumber[i] = (byte)(peripheralCardNumber[i] >> shiftBy);
                    }
                    else
                    {
                        peripheralCardNumber[i + 1] = (byte)(peripheralCardNumber[i + 1] | (byte)(peripheralCardNumber[i] << (8 - shiftBy)));
                        peripheralCardNumber[i] = (byte)(peripheralCardNumber[i] >> shiftBy);
                    }
                }
            }

            return true;
        }

#if CONTROLLER
        public CardNumberLegacy getLegacyCardNumber(int offset)
        {
            CardNumberLegacy cardNumber = new CardNumberLegacy(0);
            cardNumber.Facility = (Data[Offset + offset + 1] << 8) | Data[Offset + offset + 0];
            cardNumber.Issue = Data[Offset + offset + 2];
            cardNumber.Code = (Data[Offset + offset + 7] << 32) | 
                              (Data[Offset + offset + 6] << 24) | 
                              (Data[Offset + offset + 5] << 16) | 
                              (Data[Offset + offset + 4] << 8) | 
                               Data[Offset + offset + 3];
            return cardNumber;
        }

        public void setLegacyCardNumber(int offset, CardNumberLegacy value)
        {
            Data[Offset + offset + 0] = (byte)(value.Facility & 0xFF);             // Facility LSB
            Data[Offset + offset + 1] = (byte)((value.Facility & 0xFF00) >> 8);    // Facility MSB
            Data[Offset + offset + 2] = (byte)(value.Issue);                       // Issue
            Data[Offset + offset + 3] = (byte)(value.Code & 0xFF);                 // Code LSB
            Data[Offset + offset + 4] = (byte)((value.Code & 0xFF00) >> 8);        // Code
            Data[Offset + offset + 5] = (byte)((value.Code & 0xFF0000) >> 16);     // Code
            Data[Offset + offset + 6] = (byte)((value.Code & 0xFF000000) >> 24);   // Code
            Data[Offset + offset + 7] = (byte)((value.Code & 0xFF00000000) >> 32); // Code MSB
        }
#endif

        public bool DeleteCard
        {
            get
            {
                if ((Data[Offset + 1] & 1) != 0)
                    return true;
                return false;
            }
            set
            {
                if (value)
                    Data[Offset + 1] |= 1;
                else
                    Data[Offset + 1] &= 0xFE;
            }
        }

        public bool ModifyFacility
        {
            get
            {
                if ((Data[Offset + 1] & 0x20) != 0)
                    return true;
                return false;
            }
            set
            {
                if (value)
                    Data[Offset + 1] |= 0x20;
                else
                    Data[Offset + 1] &= 0xDF;
            }
        }

        public bool CardRange
        {
            get
            {
                if ((Data[Offset + 1] & 0x40) != 0)
                    return true;
                return false;
            }
            set
            {
                if (value)
                    Data[Offset + 1] |= 0x40;
                else
                    Data[Offset + 1] &= 0xBF;
            }
        }

        public bool MasterCardStore
        {
            get
            {
                if ((Data[Offset + 1] & 0x80) == 0)
                    return true;
                return false;
            }
            set
            {
                if (value == false)
                    Data[Offset + 1] |= 0x80;
                else
                    Data[Offset + 1] &= 0x7F;
            }
        }

#if CONTROLLER
        public CardNumberLegacy FirstCardLegacy
        {
            get
            {
                return getLegacyCardNumber(2);
            }
            set
            {
                setLegacyCardNumber(2, value);
            }
        }

        public CardNumberLegacy SecondCardLegacy
        {
            get
            {
                return getLegacyCardNumber(10);
            }
            set
            {
                setLegacyCardNumber(10, value);
            }

        }
#endif

        public byte[] FirstCardRaw
        {
            get
            {
                byte[] card = new byte[8];
                Buffer.BlockCopy(Data, Offset + 2, card, 0, card.Length);
                return card;
            }
        }

        /// <summary>
        /// Construct message to device from controller. Same configuration as for reader dedicated message.
        /// </summary>
        /// <param name="config"></param>
        public CardReaderModifyDegradedMemoryBroadcastCommand(ReaderDegradedMemoryConfig config, bool overTcpIP)
        {
            if (config == null)
                throw new ArgumentNullException("config");

            Data = (config.CardRange == false) ? new byte[10] : 
                                                 new byte[18];
            FunctionCode = (byte)(overTcpIP == true ?
                CardReaderModifyDegradedMemoryBroadcastCommandIPFunctionCode :
                CardReaderModifyDegradedMemoryBroadcastCommandSerialFunctionCode);

            constructModifyDegradedMemoryCommand(config);
            Length = Data.Length;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="config"></param>
        public bool GetConfiguration(out ReaderDegradedMemoryConfig config)
        {
            config = null;
            if (this.Data.Length < 10)
                return false;
            if (!(this.Data[this.Offset] == CardReaderModifyDegradedMemoryBroadcastCommandSerialFunctionCode ||
                this.Data[this.Offset] == CardReaderModifyDegradedMemoryBroadcastCommandIPFunctionCode))
                return false;
            config = parseDegradedMemoryCommand();
            return config != null;
        }

        private void constructModifyDegradedMemoryCommand(ReaderDegradedMemoryConfig config)
        {
            if (config.AddCode == false)
            {
                this.Data[this.Offset + 1] = 1;
            }
            else
            {
                this.Data[this.Offset + 1] = 0;
            }
            // Add rest of flags
            if (config.ModifyFacility == true)
            {
                this.Data[this.Offset + 1] |= 32;
            }
            if (config.MasterCardStore == false)
            {
                this.Data[this.Offset + 1] |= 128;
            }

            for (int iFacility = 0; iFacility < 2; iFacility++)
            {
                if (config.FirstCard.Facility.Length - 1 >= iFacility)
                {
                    this.Data[this.Offset + 2 + iFacility] = config.FirstCard.Facility[config.FirstCard.Facility.Length - 1 - iFacility];
                }
            }

            if (config.FirstCard.Issue.Length > 0)
            {
                this.Data[this.Offset + 4] = config.FirstCard.Issue[0];
            }

            for (int iCode = 0; iCode < 5; iCode++)
            {
                if (config.FirstCard.Code.Length - 1 >= iCode)
                {
                    this.Data[this.Offset + 5 + iCode] = config.FirstCard.Code[config.FirstCard.Code.Length - 1 - iCode];
                }
            }
            if (config.CardRange)
            {
                this.Data[this.Offset + 1] |= 64;

                for (int iFacility = 0; iFacility < 2; iFacility++)
                {
                    if (config.SecondCard.Facility.Length - 1 >= iFacility)
                    {
                        this.Data[this.Offset + 10 + iFacility] = config.SecondCard.Facility[config.SecondCard.Facility.Length - 1 - iFacility];
                    }
                }

                if (config.SecondCard.Issue.Length > 0)
                {
                    this.Data[this.Offset + 12] = config.SecondCard.Issue[0];
                }

                for (int iCode = 0; iCode < 5; iCode++)
                {
                    if (config.SecondCard.Code.Length - 1 >= iCode)
                    {
                        this.Data[this.Offset + 13 + iCode] = config.SecondCard.Code[config.SecondCard.Code.Length - 1 - iCode];
                    }
                }
            }
        }

        private ReaderDegradedMemoryConfig parseDegradedMemoryCommand()
        {
            if (this.Data.Length < 10)
                return null;

            ReaderDegradedMemoryConfig config = new ReaderDegradedMemoryConfig();

            // Bit 0 - 0 for add and 1 for delete
            config.AddCode = (this.Data[this.Offset + 1] & 1) == 0;
            // Bit 5 – 1 for modify Facility memory EEprom
            config.ModifyFacility = (this.Data[this.Offset + 1] & 32) != 0;
            // Bit 6 – 0 for only one card number included  and 1 for second card included to specify a range to and from
            config.CardRange = (this.Data[this.Offset + 1] & 64) != 0;
            // Bit 7 – 0 for master card store and 1 for RAM card store
            config.MasterCardStore = (this.Data[this.Offset + 1] & 128) == 0;

            // We need to remove zero bytes from the front of the facility
            bool copyFacility = false;
            for (int iFacility = 1; iFacility >= 0; iFacility--)
            {
                if (this.Data[this.Offset + 2 + iFacility] != 0 && copyFacility == false)
                {
                    copyFacility = true;
                    config.FirstCard.Facility = new byte[iFacility + 1];
                }
                if (copyFacility == true)
                {
                    config.FirstCard.Facility[config.FirstCard.Facility.Length - iFacility - 1] = this.Data[this.Offset + 2 + iFacility];
                }
            }
            if (copyFacility == false)
            {
                config.FirstCard.Facility = new byte[0];
            }

            if (this.Data[this.Offset + 4] == 0)
            {
                config.FirstCard.Issue = new byte[0];
            }
            else
            {
                config.FirstCard.Issue = new byte[1] { this.Data[this.Offset + 4] };
            }

            // We need to remove zero bytes from the front of the facility
            bool copyCode = false;
            for (int iCode = 4; iCode >= 0; iCode--)
            {
                if (this.Data[this.Offset + 5 + iCode] != 0 && copyCode == false)
                {
                    copyCode = true;
                    config.FirstCard.Code = new byte[iCode + 1];
                }
                if (copyCode == true)
                {
                    config.FirstCard.Code[config.FirstCard.Code.Length - iCode - 1] = this.Data[this.Offset + 5 + iCode];
                }
            }
            if (copyCode == false)
            {
                config.FirstCard.Code = new byte[0];
            }
            
            if (config.CardRange)
            {
                if (this.Data.Length < 18)
                    return null;

                // We need to remove zero bytes from the front of the facility
                bool copyFacilitySecond = false;
                for (int iFacility = 1; iFacility >= 0; iFacility--)
                {
                    if (this.Data[this.Offset + 10 + iFacility] != 0 && copyFacilitySecond == false)
                    {
                        copyFacilitySecond = true;
                        config.SecondCard.Facility = new byte[iFacility + 1];
                    }
                    if (copyFacilitySecond == true)
                    {
                        config.SecondCard.Facility[config.SecondCard.Facility.Length - iFacility - 1] = this.Data[this.Offset + 10 + iFacility];
                    }
                }
                if (copyFacilitySecond == false)
                {
                    config.SecondCard.Facility = new byte[0];
                }

                if (this.Data[this.Offset + 12] == 0)
                {
                    config.SecondCard.Issue = new byte[0];
                }
                else
                {
                    config.SecondCard.Issue = new byte[1] { this.Data[this.Offset + 12] };
                }

                // We need to remove zero bytes from the front of the facility
                bool copyCodeSecond = false;
                for (int iCode = 4; iCode >= 0; iCode--)
                {
                    if (this.Data[this.Offset + 13 + iCode] != 0 && copyCodeSecond == false)
                    {
                        copyCodeSecond = true;
                        config.SecondCard.Code = new byte[iCode + 1];
                    }
                    if (copyCodeSecond == true)
                    {
                        config.SecondCard.Code[config.SecondCard.Code.Length - iCode - 1] = this.Data[this.Offset + 13 + iCode];
                    }
                }
                if (copyCodeSecond == false)
                {
                    config.SecondCard.Code = new byte[0];
                }
            }

            if (config.FirstCard.Facility.SequenceEqual(new byte[0]) && 
                    config.FirstCard.Issue.SequenceEqual(new byte[0]) &&
                        config.FirstCard.Code.SequenceEqual(new byte[0]))
            {
                config.FirstCard.Facility = new byte[] { 0x0, 0x0 };
                config.FirstCard.Issue = new byte[] { 0x0 };
                config.FirstCard.Code = new byte[] { 0x0, 0x0, 0x0, 0x0, 0x0 };
            }

            return config;
        }

        public override string ToString()
        {
            return "Modify Card Reader Degraded Memory Broadcast";
        }

#if COMMUNICATIONSANALYZER

        public CardReaderModifyDegradedMemoryBroadcastCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { CardReaderModifyDegradedMemoryBroadcastCommandSerialFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override bool FromControllerBroadcast
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {            
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(this.ToString());
            sb.Append(Environment.NewLine);
            sb.Append(Environment.NewLine);
            ReaderDegradedMemoryConfig config;
            if (GetConfiguration(out config))
            {
                sb.Append(string.Format("Add Code: {0}", config.AddCode ? "Yes" : "No"));
                sb.Append(Environment.NewLine);
                sb.Append(string.Format("Modify Facility: {0}", config.ModifyFacility ? "Yes" : "No"));
                sb.Append(Environment.NewLine);
                sb.Append(string.Format("Master Card Store: {0}", config.MasterCardStore ? "Yes" : "No"));
                sb.Append(Environment.NewLine);
                sb.Append(string.Format("Card Range: {0}", config.CardRange ? "Yes" : "No"));
                sb.Append(Environment.NewLine);
                sb.Append(Environment.NewLine);

                sb.Append("First Card");
                sb.Append(Environment.NewLine);
                if (config.FirstCard != null)
                {
                    sb.Append("    Facility: ");
                    if (config.FirstCard.Facility != null && config.FirstCard.Facility.Length > 0)
                        sb.Append(BitConverter.ToString(config.FirstCard.Facility));
                    else if (config.FirstCard.Facility != null)
                        sb.Append(@"""");
                    else
                        sb.Append("N/A");
                    sb.Append(Environment.NewLine);
                    sb.Append("    Issue: ");
                    if (config.FirstCard.Issue != null && config.FirstCard.Issue.Length > 0)
                        sb.Append(BitConverter.ToString(config.FirstCard.Issue));
                    else if (config.FirstCard.Issue != null)
                        sb.Append(@"""");
                    else
                        sb.Append("N/A");
                    sb.Append(Environment.NewLine);
                    sb.Append("    Code: ");
                    if (config.FirstCard.Code != null && config.FirstCard.Code.Length > 0)
                        sb.Append(BitConverter.ToString(config.FirstCard.Code));
                    else if (config.FirstCard.Code != null)
                        sb.Append(@"""");
                    else
                        sb.Append("N/A");
                    sb.Append(Environment.NewLine);
                }
                else
                {
                    sb.Append("    N/A");
                    sb.Append(Environment.NewLine);
                }
                sb.Append(Environment.NewLine);

                sb.Append("Second Card");
                sb.Append(Environment.NewLine);
                if (config.SecondCard != null)
                {
                    sb.Append("    Facility: ");
                    if (config.SecondCard.Facility != null && config.SecondCard.Facility.Length > 0)
                        sb.Append(BitConverter.ToString(config.SecondCard.Facility));
                    else if (config.SecondCard.Facility != null)
                        sb.Append(@"""");
                    else
                        sb.Append("N/A");
                    sb.Append(Environment.NewLine);
                    sb.Append("    Issue: ");
                    if (config.SecondCard.Issue != null && config.SecondCard.Issue.Length > 0)
                        sb.Append(BitConverter.ToString(config.SecondCard.Issue));
                    else if (config.SecondCard.Issue != null)
                        sb.Append(@"""");
                    else
                        sb.Append("N/A");
                    sb.Append(Environment.NewLine);
                    sb.Append("    Code: ");
                    if (config.SecondCard.Code != null && config.SecondCard.Code.Length > 0)
                        sb.Append(BitConverter.ToString(config.SecondCard.Code));
                    else if (config.SecondCard.Code != null)
                        sb.Append(@"""");
                    else
                        sb.Append("N/A");
                    sb.Append(Environment.NewLine);
                }
                else
                {
                    sb.Append("    N/A");
                    sb.Append(Environment.NewLine);
                }
                sb.Append(Environment.NewLine);                
            }
            return sb.ToString();
        }

#endif

    }
}
