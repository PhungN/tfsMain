﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    // This function code is used to allow the BAU to request the devices serial number.
    // The message format is:
    // 253
    public class RequestSerialNumberCommand : DeviceLoopMessageBase
    {
        public const int RequestSerialNumberCommandFunctionCode = 253;

        public RequestSerialNumberCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public RequestSerialNumberCommand()
        {
            Data = new byte[1];
            FunctionCode = RequestSerialNumberCommandFunctionCode;

            Length = 1;
        }

        public override string ToString()
        {
            return "Request Serial Number Command";
        }

#if COMMUNICATIONSANALYZER

        // Default constructor already defined

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { RequestSerialNumberCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
