﻿using System.Text;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    // This function code is used to allow the BAU to send a new serial number to a device.
    // The message format is:
    // 254, DATA ...
    // where DATA is a 16 byte serial number.

    public class SetSerialNumberCommand : DeviceLoopMessageBase
    {
        public const int SetSerialNumberCommandFunctionCode = 254;

        public SetSerialNumberCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 17)     
        {
        }

        public SetSerialNumberCommand(string serialNumber)
        {
            Data = new byte[17];
            FunctionCode = SetSerialNumberCommandFunctionCode;

            for (int i = 0; i < 16; i++)
            {
                Data[i + 1] = (byte)serialNumber[i];
            }
            Length = 17;
        }

        public string SerialNumber
        {
            get
            {
                return ASCIIEncoding.ASCII.GetString(Data, Offset + 1, 16);
            }
        }

        public override string ToString()
        {
            return "Set Serial Number Command (" + SerialNumber + ")";
        }

#if COMMUNICATIONSANALYZER

        public SetSerialNumberCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetSerialNumberCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
