using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    // This command sets a new encryption password. It is should only be sent once, the device needs to store this even without power. 
    // If encryptions is currently enabled it will take effect immediately for all new messages.
    // The message format is:
    // <248><ENCODING><PASSWORD>
    // ENCODING 0 = Plain text or byte array
    // PASSWORD is the text or byte array up to 16 characters / bytes.
    public class SetEncryptionKeyCommand : DeviceLoopMessageBase
    {
        public const int SetEncryptionKeyCommandFunctionCode = 248;

        static Random random = new Random();
        
        public SetEncryptionKeyCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 18)
        {
        }

        public SetEncryptionKeyCommand()
        {
            Data = new byte[18];
            random.NextBytes(Data);
            Data[1] = 0; // Encoding
            FunctionCode = SetEncryptionKeyCommandFunctionCode;

            Length = 18;
        }

        public byte[] GetEncryptionKey()
        {
            byte[] encryptionKey = new byte[16];
            Buffer.BlockCopy(Data, Offset + 2, encryptionKey, 0, 16);
            return encryptionKey;
        }

        public override string ToString()
        {
#if DEBUG
            return "Set Encryption Key (" + BitConverter.ToString(Data, Offset + 2, Length - 2) + ")";
#else
            return "Set Encryption Key (" + (Length - 2).ToString() + ")";
#endif
        }
    }
}
