﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public class InputPoint
    {
        private int inputPointNumber;
        private InputStatus inputStatus;

        public InputPoint(int inputPointNumber, InputStatus inputStatus)
        {
            this.inputPointNumber = inputPointNumber;
            this.inputStatus = inputStatus;
        }

        public int InputPointNumber
        {
            get { return inputPointNumber; }
        }

        public InputStatus InputStatus
        {
            get { return inputStatus; }
        }
    }
}
