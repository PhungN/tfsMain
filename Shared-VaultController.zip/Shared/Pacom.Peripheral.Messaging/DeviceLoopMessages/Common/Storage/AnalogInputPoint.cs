﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public class AnalogInputPoint
    {
        private int inputPointNumber;
        private int value;

        public AnalogInputPoint(int inputPointNumber, int value)
        {
            this.inputPointNumber = inputPointNumber;
            this.value = value;
        }

        public int InputPointNumber
        {
            get { return inputPointNumber; }
        }

        public int Value
        {
            get { return value; }
        }
    }
}
