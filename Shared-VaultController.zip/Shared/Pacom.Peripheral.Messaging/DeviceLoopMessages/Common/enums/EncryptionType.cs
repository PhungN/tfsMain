﻿using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public enum EncryptionType
    {
        None = 0,
        Aes128 = 1,
        Aes256 = 2,
    };
}
