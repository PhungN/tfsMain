﻿using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    [Flags]
    public enum SoftwareDownloadFlags
    {
        NoBytesInBank = 0,
        LastBytesInBank = 1,
        LastBankToWrite = 2,
    }
}
