﻿using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    /// <summary>
    /// The one byte Device Type described in the 485 device loop specification.
    /// </summary>
    public enum DeviceType
    {
        PacomController = 0,
        Pacom8501EC = 17,
        Pacom8501 = 38,        
        Pacom8603 = 46
    }
}
