﻿using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    [Flags]
    public enum ControlFlags
    {
        None = 0,
        ResponseRequired = 0x01,
        ResponseReply = 0x02,
        PortReconnected = 0x40,
        DeviceRestarted = 0x80,
    }
}
