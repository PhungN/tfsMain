﻿using System;
using System.Text;
using System.Security.Cryptography;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public class DeviceLoopOverUdpIPMessageLogOn : DeviceLoopOverUdpIPMessageBase
    {
        public DeviceLoopOverUdpIPMessageLogOn(byte[] receivedData)
            : base(receivedData)
        {
            if (receivedData.Length != 130 && receivedData.Length != 162)
                throw new ArgumentException("receivedData is not of appropriate size", "receivedData");
        }

        public DeviceLoopOverUdpIPMessageLogOn(int sourceUnitNumber, byte sessionId, UInt32 deviceSequenceNumber, byte[] serialNumber, DeviceType device, 
            FirmwareVersion version, bool deviceRestarted, byte[] sessionKey1EncryptedWithMasterKey, byte[] sessionKey2EncryptedWithSerialNumber)
            : base(1, sourceUnitNumber, DeviceLoopOverUdpIPMessageBase.ControllerUnitNumber, sessionId, deviceSequenceNumber, 0, sessionKey1EncryptedWithMasterKey.Length == 16 ? 130 : 162)
        {
            if (serialNumber == null || serialNumber.Length != 16)
                throw new ArgumentException("serialNumber is null or not of appropriate size", "serialNumber");

            if (sessionKey1EncryptedWithMasterKey == null)
                throw new ArgumentException("sessionKey1EncryptedWithMasterKey is null", "sessionKey1EncryptedWithMasterKey");

            if (sessionKey1EncryptedWithMasterKey.Length != 16 && sessionKey1EncryptedWithMasterKey.Length != 32)
                throw new ArgumentException("sessionKey1EncryptedWithMasterKey is not of appropriate size", "sessionKey1EncryptedWithMasterKey");

            if (sessionKey2EncryptedWithSerialNumber == null || sessionKey2EncryptedWithSerialNumber.Length != 32)
                throw new ArgumentException("sessionKey2EncryptedWithSerialNumber is null or not of appropriate size", "sessionKey2EncryptedWithSerialNumber");

            // Serial Number - 16 byte serial number 
            Buffer.BlockCopy(serialNumber, 0, Data, 14, 16);

            // Device Type - 1 byte Pacom device type number or the RTU device type number (0).
            Data[30] = (byte)device;

            // Version - 2 byte version number
            Data[31] = (byte)version.Major;
            Data[32] = (byte)version.Minor;

            // Device Restarted - 1 byte, 1 for true
            Data[33] = deviceRestarted ? (byte)0x01 : (byte)0x00;

            // Device Sequence Session Key 1 M - 16 / 32 bytes
            Buffer.BlockCopy(sessionKey1EncryptedWithMasterKey, 0, Data, 34, MasterKeyLength);

            // Device Sequence Session Key 2 SN - 32 bytes
            Buffer.BlockCopy(sessionKey2EncryptedWithSerialNumber, 0, Data, 34 + MasterKeyLength, 32);
        }

        public int MasterKeyLength
        {
            get
            {
                if (Data.Length == 130)
                    return 16;
                else if (Data.Length == 162)
                    return 32;
                return 0;
            }
        }

        public string SerialNumber
        {
            get
            {
                return ASCIIEncoding.ASCII.GetString(Data, 14, 16);
            }
        }

        public byte[] SerialNumberRaw
        {
            get
            {
                byte[] serialNumber = new byte[16];
                Buffer.BlockCopy(Data, 14, serialNumber, 0, serialNumber.Length);
                return serialNumber;
            }
        }

        public DeviceType DeviceType
        {
            get
            {
                return (DeviceType)Data[30];
            }
        }

        public FirmwareVersion FirmwareVersion
        {
            get
            {
                // Version - 2 byte version number
                return new FirmwareVersion(Data[31], Data[32]);
            }
        }

        public bool DeviceRestarted
        {
            get
            {
                return (Data[33] != 0);
            }
        }

        public byte[] sessionKey1EncryptedWithMasterKey
        {
            get
            {
                byte[] buffer = new byte[MasterKeyLength];
                Buffer.BlockCopy(Data, 34, buffer, 0, MasterKeyLength);
                return buffer;
            }
        }

        public byte[] sessionKey2EncryptedWithSerialNumber
        {
            get
            {
                byte[] buffer = new byte[32];
                Buffer.BlockCopy(Data, 34 + MasterKeyLength, buffer, 0, 32);
                return buffer;
            }
        }

        public byte[] HmacSessionKey1
        {
            set
            {
                Buffer.BlockCopy(value, 0, Data, 66 + MasterKeyLength, MasterKeyLength);
            }
        }

        public byte[] HmacSessionKey2
        {
            set
            {
                Buffer.BlockCopy(value, 0, Data, 66 + (MasterKeyLength * 2), 32);
            }
        }

        public override int HmacSessionKeyOffset
        {
            get
            {
                return 66 + MasterKeyLength;
            }
        }

        public int HmacSessionKey2Offset
        {
            get
            {
                return 66 + (MasterKeyLength * 2);
            }
        }
    }
}
