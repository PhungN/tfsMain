﻿using System;
using System.Text;
using System.Security.Cryptography;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public class DeviceLoopOverUdpIPMessagePoll : DeviceLoopOverUdpIPMessageBase
    {
        public DeviceLoopOverUdpIPMessagePoll(byte[] receivedData)
            : base(receivedData)
        {
            if (receivedData.Length != 30 && receivedData.Length != 46)
                throw new ArgumentException("receivedData is not of appropriate size", "receivedData");
        }


        public DeviceLoopOverUdpIPMessagePoll(int sourceUnitNumber, int destinationUnitNumber, byte sessionId, UInt32 pollSequenceNumber, EncryptionType encryptionType)
            : base(6, sourceUnitNumber, destinationUnitNumber, sessionId, pollSequenceNumber, 0, encryptionType == EncryptionType.Aes128 ? 30 : 46)
        {
            if (masterKeyLength != 16 && masterKeyLength != 32)
                throw new ArgumentException("masterKeyLength is not of appropriate size", "masterKeyLength");
        }

        private int masterKeyLength
        {
            get
            {
                if (Data.Length == 30)
                    return 16;
                else if (Data.Length == 46)
                    return 32;
                return 0;
            }
        }

        public byte[] HmacSessionKey
        {
            get
            {
                byte[] buffer = new byte[masterKeyLength];
                Buffer.BlockCopy(Data, 14, buffer, 0, masterKeyLength);
                return buffer;
            }
            set
            {
                Buffer.BlockCopy(value, 0, Data, 14, masterKeyLength);
            }
        }

        public override int HmacSessionKeyOffset
        {
            get
            {
                return 14;
            }
        }
    }
}
