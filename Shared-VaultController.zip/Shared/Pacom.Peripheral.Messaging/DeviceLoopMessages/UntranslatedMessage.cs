﻿using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    /// <summary>
    /// This class represents any message that couldn't be translated to a more appropriate messaging
    /// class.
    /// </summary>
    public class UntranslatedMessage : DeviceLoopMessageBase
    {
        public UntranslatedMessage(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public override string ToString()
        {
            return "UntranslatedMessage (Function Code = " + Data[Offset].ToString() + ")";
        }

#if COMMUNICATIONSANALYZER

        public UntranslatedMessage()
        { }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[0]; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { }; }
        }

        public override bool? FromController
        {
            get { return null; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif

    }
}
