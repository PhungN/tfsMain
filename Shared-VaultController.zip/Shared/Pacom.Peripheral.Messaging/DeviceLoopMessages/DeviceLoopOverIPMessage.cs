﻿using System;
using System.Text;
using System.Security.Cryptography;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public class DeviceLoopOverIPMessage
    {
        static Random random = new Random();
        private readonly byte[] encryptionInitializationVector = Encoding.UTF8.GetBytes("Pacom Systems...");
        private static ICryptoTransform aesEncryptor = null;

        public DeviceLoopOverIPMessage(byte[] decryptedData)
        {
            if (decryptedData == null || decryptedData.Length < 44)
                throw new ArgumentException("Data is null or not sufficiently long", "decryptedData");

            this.Data = decryptedData;
        }

        public DeviceLoopOverIPMessage(DeviceType device, byte[] serialNumber, int unitNumber, FirmwareVersion version, ControlFlags controlFlags, DeviceLoopMessageBase[] deviceLoopMessages)
        {
            if (serialNumber == null || serialNumber.Length != 16)
                throw new ArgumentException("serialNumber is null or not of appropriate size", "serialNumber");

            if (deviceLoopMessages != null && deviceLoopMessages.Length > 0xFF)
                throw new ArgumentException("too many deviceLoopMessages to fit", "deviceLoopMessages");

            int packagedMessageSize = 0;
            int dataPortionSize = 0;
            if (deviceLoopMessages != null)
            {
                foreach (DeviceLoopMessageBase deviceLoopMessage in deviceLoopMessages)
                {
                    // Add the individual message sizes + the Type and Size fields
                    dataPortionSize += deviceLoopMessage.Length + 3;
                }
            }
            if (dataPortionSize > 0xFFFF)
                throw new ArgumentException("deviceLoopMessages to long to fit", "deviceLoopMessages");
            packagedMessageSize = dataPortionSize;

            // Add the Salt and Message count bytes
            packagedMessageSize += 2;

            // Accomodate for the encryption padding 
            int paddingLength = 0;
            if ((packagedMessageSize % 16) != 0)
                paddingLength = (16 - (packagedMessageSize % 16));
            packagedMessageSize += paddingLength;

            // Add the unencrypted header portion
            packagedMessageSize += 30;

            Data = new byte[packagedMessageSize];

            // Length - 2 byte big endian length of the rest of the header message
            Data[0] = 0x00;
            Data[1] = 0x1C;

            // Header - 2 byte big endian header ID number ( 5002 for device, 5003 for RTU)
            Data[2] = 0x50;
            if (device == DeviceType.PacomController)
                Data[3] = 0x03;
            else
                Data[3] = 0x02;

            // Serial Number - 16 byte serial number 
            Buffer.BlockCopy(serialNumber, 0, Data, 4, 16);

            // Device Type - 1 byte Pacom device type number or the RTU device type number (0).
            Data[20] = (byte)device;

            // Unit Number - This is a 2 byte little endian number. From the RTU it is the site number. From the Pacom device it is the device address if known.
            Data[21] = (byte)(unitNumber & 0xFF);
            Data[22] = (byte)((unitNumber & 0xFF00) >> 8);

            // Version - 2 byte version number
            Data[23] = (byte)version.Major;
            Data[24] = (byte)version.Minor;

            // Control - 1 byte control flags
            Data[25] = (byte)controlFlags;

            // Tx sequence and Rx sequence - 1 byte, left blank. The link layer will complete these before sending the message
            Data[26] = 0;
            Data[27] = 0;

            // Data size - 2 byte little endian length of the message data size.
            Data[28] = (byte)(dataPortionSize & 0xFF);
            Data[29] = (byte)((dataPortionSize & 0xFF00) >> 8);

            // Salt - 1 random byte
            Data[30] = (byte)random.Next(0x00, 0xFF);

            // Message count - 1 byte, the total number of messages included in the data.
            if (deviceLoopMessages != null)
                Data[31] = (byte)deviceLoopMessages.Length;
            else
                Data[31] = 0;

#if DEBUG_ZERO_LENGTH_MESSAGES
            // Inspect messages before sending
            // Some messages return array with data of zero length, this will be checked here.
            if (deviceLoopMessages == null)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                {
                    return "Message list to send is null. (KeepAlive)";
                });
            }
            else if (deviceLoopMessages.Length > 0)
            {
                foreach (DeviceLoopMessageBase deviceLoopMessage in deviceLoopMessages)
                {
                    if (deviceLoopMessage == null)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return "Message to send is null.";
                        });
                        continue;
                    }
                    if (deviceLoopMessage.Length <= 0)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return "Message to send has incorrect length.";
                        });
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return "Message Offset: " + deviceLoopMessage.Offset + ", Length" + deviceLoopMessage.Length + ". Number of messages in send request: " + deviceLoopMessages.Length + ".";
                        });
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return "Message body: " + BitConverter.ToString(deviceLoopMessage.Data) + ".";
                        });
                        continue;
                    }
                }
            }
#endif

            int dataPointer = 32;
            if (deviceLoopMessages != null)
            {
                foreach (DeviceLoopMessageBase deviceLoopMessage in deviceLoopMessages)
                {
                    // Message Type - 1 byte, 0 is the legacy Pacom Device Loop protocol.
                    Data[dataPointer] = 0;
                    dataPointer++;

                    // Size - a 2 byte little endian of the message data
                    Data[dataPointer] = (byte)(deviceLoopMessage.Length & 0xFF);
                    dataPointer++;
                    Data[dataPointer] = (byte)((deviceLoopMessage.Length & 0xFF00) >> 8);
                    dataPointer++;

                    // Data
                    Buffer.BlockCopy(deviceLoopMessage.Data, deviceLoopMessage.Offset, Data, dataPointer, deviceLoopMessage.Length);
                    dataPointer += deviceLoopMessage.Length;
                }
            }

            byte[] randomData = new byte[paddingLength];
            random.NextBytes(randomData);
            Buffer.BlockCopy(randomData, 0, Data, dataPointer, paddingLength);
        }

        public int HeaderLength
        {
            get
            {
                // Length - 2 byte big endian length of the rest of the header message
                return (Data[0] << 8) + Data[1];
            }
        }

        public string SerialNumber
        {
            get
            {
                // Length - 2 byte big endian length of the rest of the header message
                return ASCIIEncoding.ASCII.GetString(Data, 4, 16);
            }
        }

        public DeviceType DeviceType
        {
            get
            {
                // Device Type - 1 byte Pacom device type number for the message source (0 for the RTU).
                return (DeviceType)Data[20];
            }
        }

        public int UnitNumber
        {
            get
            {
                // Unit Number - This is a 2 byte little endian number. From the RTU it is the site number. From the Pacom device it is the device address if known.
                return (Data[22] << 8) + Data[21];
            }
        }

        public FirmwareVersion FirmwareVersion
        {
            get
            {
                // Version - 2 byte version number
                return new FirmwareVersion(Data[24], Data[23]);
            }
        }

        public ControlFlags ControlFlags
        {
            get
            {
                // Control - 1 byte control flags
                return (ControlFlags)Data[25];
            }
        }

        public int TransmitSequenceNumber
        {
            get
            {
                return Data[26];
            }
            set
            {
                Data[26] = (byte)value;
            }
        }

        public int ReceiveSequenceNumber
        {
            get
            {
                return Data[27];
            }
            set
            {
                Data[27] = (byte)value;
            }
        }

        public DeviceLoopMessageBase[] GetMessages()
        {
            try
            {
                int messageCount = Data[31];
                DeviceLoopMessageBase[] messages = new DeviceLoopMessageBase[messageCount];
                DeviceType deviceType = this.DeviceType;

                int dataPointer = 32;
                for (int i = 0; i < messageCount; i++)
                {
                    dataPointer++;

                    int size = (Data[dataPointer + 1] << 8) + Data[dataPointer];
                    dataPointer += 2;
                    try
                    {
                        messages[i] = DeviceLoopMessageBase.Parse(Data, dataPointer, size, deviceType);
                    }
                    catch
                    {
                        Logger.LogWarnMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return "Failed to parse message " + BitConverter.ToString(Data, dataPointer, size);
                        });
                        messages[i] = new UntranslatedMessage(Data, dataPointer, size);
                    }
                    dataPointer += size;
                }
                return messages;
            }
            catch
            {
            }
            return new DeviceLoopMessageBase[0];
        }

        public byte[] GetEncryptedData()
        {
            byte[] encryptedData = new byte[Data.Length];
            Buffer.BlockCopy(Data, 0, encryptedData, 0, 30);

            ICryptoTransform encryptor = createEncryptor();

            byte[] encryptedDataPortion = encryptor.TransformFinalBlock(Data, 30, Data.Length - 30);
            Buffer.BlockCopy(encryptedDataPortion, 0, encryptedData, 30, encryptedDataPortion.Length);

            return encryptedData;
        }

        private ICryptoTransform createEncryptor()
        {
            // It is assumed that the device will not change its serial number for the life of the application.
            if (aesEncryptor == null)
            {
                byte[] aesKey = new byte[16];
                Buffer.BlockCopy(Data, 4, aesKey, 0, aesKey.Length);
                aesKey = MD5.Create().ComputeHash(aesKey);

                RijndaelManaged aesAlgorithm = new RijndaelManaged();
                aesAlgorithm.KeySize = 128;
                aesAlgorithm.Key = aesKey;
                aesAlgorithm.Mode = CipherMode.CBC;
                aesAlgorithm.Padding = PaddingMode.None;
                aesAlgorithm.IV = encryptionInitializationVector;
                aesEncryptor = aesAlgorithm.CreateEncryptor();
            }
            return aesEncryptor;
        }

        public byte[] Data
        {
            get;
            private set;
        }
    }
}
