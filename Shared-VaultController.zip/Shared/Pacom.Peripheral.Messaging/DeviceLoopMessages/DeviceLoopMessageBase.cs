﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public abstract partial class DeviceLoopMessageBase : IDeviceLoopMessageBase
    {
        /// <summary>
        /// Single byte for owner type.
        /// </summary>
        public const int OwnerTypeSize = 1;
        
        /// <summary>
        /// Single byte for starting point.
        /// </summary>
        public const int StartingPointSize = 1;
        
        /// <summary>
        /// Single byte for function code.
        /// </summary>
        public const int FunctionCodeSize = 1;
                
        /// <summary>
        /// From RS485 specification byte count (BC) can be only 5 bits long, which will allow for 31 bytes of message length.
        /// This includes checksum which must be subtracted from the total length.
        /// </summary>
        public const int MaximumDataBytesFromController = 30;

        /// <summary>
        /// From RS485 specification byte count (BC) can be only 5 bits long, which will allow for 31 bytes of message length.
        /// This includes device type and checksum which must be subtracted from the total length.
        /// </summary>
        public const int MaximumDataBytesToController = 29;

        /// <summary>
        /// Bytes selected to distinguish the message.
        /// </summary>
        public static readonly byte[] MessageSignature = new byte[] { 0xAA, 0x55, 0xA5 };

        /// <summary>
        /// Number of bytes used for signature to distinguish the message from garbage.
        /// </summary>
        public const int MessageSignatureSize = 3;

        protected DeviceLoopMessageBase()
        {
            this.Offset = 0;
        }

        protected DeviceLoopMessageBase(byte[] data, int offset, int length, int minimumMessageLength)
        {
            if (data == null || data.Length < (offset + length))
                throw new ArgumentException("Data is null or data is incomplete", "data");

            if (length < minimumMessageLength)
                throw new ArgumentException("Data isn't sufficiently long", "data");

            this.Data = data;
            this.Offset = offset;
            this.Length = length;
        }

        public byte FunctionCode
        {
            get
            {
                return Data[Offset];
            }
            protected set
            {
                Data[Offset] = value;
            }
        }

        public byte[] Data
        {
            get;
            protected set;
        }

        /// <summary>
        /// Index to the byte starting the data frame. This is excluding all framing of the protocol.
        /// </summary>
        public int Offset
        {
            get;
            protected set;
        }

        /// <summary>
        /// Length of the device loop data. This is excluding all framing of the protocol.
        /// </summary>
        public int Length
        {
            get;
            protected set;
        }

        public override string ToString()
        {
            return string.Format("[DeviceLoopMessageBase] instance, Data: {0}", BitConverter.ToString(Data));
        }

#if COMMUNICATIONSANALYZER

        // NOTE: When using DeviceLoopMessages in analyzer, assure the default constructor is implemented.
        //       It is required to query the class instance for information below.

        /// <summary>
        /// Number of serial function codes the message instance can handle.
        /// </summary>
        public abstract int[] HandledSerialFuntionCodes
        {
            get;
        }

        /// <summary>
        /// If the message owners array is empty the message belongs to all devices.
        /// </summary>
        public abstract DeviceType[] MessageOwners
        {
            get;
        }

        /// <summary>
        /// Mark the message as a controller response. If returns null both device and controller can send it.
        /// </summary>
        public abstract bool? FromController
        {
            get;
        }

        /// <summary>
        /// Mark the message as a controller response. If returns null both device and controller can send it.
        /// </summary>
        public virtual bool FromControllerBroadcast
        {
            get { return false; }
        }

        /// <summary>
        /// A short text representation of the message.
        /// </summary>
        /// <returns>Returns text representation.</returns>
        public virtual string ShortDescriptionToString()
        {
            return "[DeviceLoopMessageBase] instance";
        }

        /// <summary>
        /// A long multiline text representation of the message.
        /// </summary>
        /// <returns>Returns text representation.</returns>
        public virtual string MultilineDescriptionToString()
        {
            return string.Format("[DeviceLoopMessageBase] instance, Data: {0}", BitConverter.ToString(Data));
        }

#endif

    }
}
