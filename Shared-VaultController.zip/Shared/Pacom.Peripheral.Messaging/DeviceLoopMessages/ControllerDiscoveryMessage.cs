﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    // Pacom devices broadcast the following message on UDP port 3435. 
    // RTU that are permitted to respond, will reply directly back to 
    // the Pacom device with the following UDP response packet.
    public class ControllerDiscoveryMessage
    {
        public ControllerDiscoveryMessage(byte[] data)
        {
            Data = data;
        }

        public ControllerDiscoveryMessage(DeviceType device, byte[] serialNumber, int controllerNumber, FirmwareVersion version)
        {
            Data = new byte[26];

            // Header - 2 byte big endian header ID number ( 5000 for device, 5001 for RTU response)
            Data[0] = 0x50;
            if (device == DeviceType.PacomController)
                Data[1] = 0x01;
            else
                Data[1] = 0x00;

            // Length - This is a 2 byte little endian length of the rest of the header message. This is up to the check sum. 
            // As the header may be extended in the future this allows for backwards compatibility. 
            // If the length is bigger than the RTU or Pacom Device understands then it will just ignore the extra header information. 
            // This currently is a value of 21
            Data[2] = 21;
            Data[3] = 0;

            // Serial Number - This is either the Pacom device serial number or the RTU serial number.
            for (int i = 0; i < 16; i++)
            {
                Data[i + 4] = (byte)serialNumber[i];
            }

            // Device Type - This is the Pacom device type number or the RTU device type number (0).
            Data[20] = (byte)device;

            // Controller Number - This is a 2 byte little endian number. From the Pacom device it is the RTU site number it wants to connect to.
            // If this value is set to 0xffff then all RTU can respond. From the RTU it is its own site number.
            Data[21] = (byte)(controllerNumber & 0xFF);
            Data[22] = (byte)((controllerNumber & 0xFF00) >> 8);

            // Version - 2 byte version number
            Data[23] = (byte)version.Minor;
            Data[24] = (byte)version.Major;

            // Checksum - 1 byte 2’s complement check sum of the whole preceding message. 
            // Note for future proofing the check sum is always at the end of the message.
            int checksum = 0;
            for (int i = 0; i < (Data.Length - 1); i++)
            {
                checksum += Data[i];
            }
            Data[25] = (byte)(checksum * -1);
        }

        public byte[] Data
        {
            get;
            private set;
        }

        public bool IsValid
        {
            get
            {
                if (Data == null || Data.Length != 26)
                    return false;

                int checksum = 0;
                for (int i = 0; i < Data.Length; i++)
                {
                    checksum += Data[i];
                }
                if ((checksum & 0xFF) == 0)
                    return true;

                return false;
            }
        }

        /// <summary>
        /// Device Type - This is the Pacom device type number or the RTU device type number (0).
        /// </summary>
        public DeviceType Device
        {
            get
            {
                return (DeviceType)Data[20];
            }
        }

        /// <summary>
        /// Controller Number - This is a 2 byte little endian number. From the Pacom device it is the RTU site number it wants to connect to. 
        /// If this value is set to 0xffff then all RTU can respond. From the RTU it is its own site number.
        /// The value is zero based. So site number 1 will be represented as 0.
        /// </summary>
        public int ControllerNumber
        {
            get
            {
                return (Data[22] << 8)  + Data[21];
            }
        }
    }
}
