﻿using System;
using System.Text;
using System.Security.Cryptography;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public class DeviceLoopOverUdpIPMessageLogOnResponseSuccess : DeviceLoopOverUdpIPMessageBase
    {
        public DeviceLoopOverUdpIPMessageLogOnResponseSuccess(byte[] receivedData)
            : base(receivedData)
        {
            if (receivedData.Length != 66 && receivedData.Length != 98)
                throw new ArgumentException("receivedData is not of appropriate size", "receivedData");
        }


        public DeviceLoopOverUdpIPMessageLogOnResponseSuccess(int destinationUnitNumber, byte sessionId, UInt32 deviceSequenceNumber, UInt32 controllerSequenceNumber, 
            byte[] serialNumber, DeviceType device, FirmwareVersion version, EncryptionType encryptionType, byte[] sessionKeyEncryptedWithSessionKey1)
            : base(2, DeviceLoopOverUdpIPMessageBase.ControllerUnitNumber, destinationUnitNumber, sessionId, deviceSequenceNumber, controllerSequenceNumber, sessionKeyEncryptedWithSessionKey1.Length == 16 ? 66 : 98)
        {
            if (serialNumber == null || serialNumber.Length != 16)
                throw new ArgumentException("serialNumber is null or not of appropriate size", "serialNumber");

            if (sessionKeyEncryptedWithSessionKey1 == null)
                throw new ArgumentException("sessionKeyEncryptedWithSessionKey1 is null", "sessionKeyEncryptedWithSessionKey1");

            if (sessionKeyEncryptedWithSessionKey1.Length != 16 && sessionKeyEncryptedWithSessionKey1.Length != 32)
                throw new ArgumentException("sessionKeyEncryptedWithSessionKey1 is not of appropriate size", "sessionKeyEncryptedWithSessionKey1");

            // Serial Number - 16 byte serial number 
            Buffer.BlockCopy(serialNumber, 0, Data, 14, 16);

            // Device Type - 1 byte Pacom device type number or the RTU device type number (0).
            Data[30] = (byte)device;

            // Version - 2 byte version number
            Data[31] = (byte)version.Major;
            Data[32] = (byte)version.Minor;

            // Encryption Type - 1 byte (1 = AES-128 with HMAC-MD5, 2 = AES-256 with HMAC-SHA256)
            Data[33] = (byte)encryptionType;

            // Device Sequence Session Key 1 M - 16 / 32 bytes
            Buffer.BlockCopy(sessionKeyEncryptedWithSessionKey1, 0, Data, 34, masterKeyLength);
        }

        private int masterKeyLength
        {
            get
            {
                if (Data.Length == 66)
                    return 16;
                else if (Data.Length == 98)
                    return 32;
                return 0;
            }
        }

        public string SerialNumber
        {
            get
            {
                return ASCIIEncoding.ASCII.GetString(Data, 14, 16);
            }
        }

        public byte[] SerialNumberRaw
        {
            get
            {
                byte[] serialNumber = new byte[16];
                Buffer.BlockCopy(Data, 14, serialNumber, 0, serialNumber.Length);
                return serialNumber;
            }
        }

        public DeviceType DeviceType
        {
            get
            {
                return (DeviceType)Data[30];
            }
        }


        public FirmwareVersion FirmwareVersion
        {
            get
            {
                // Version - 2 byte version number
                return new FirmwareVersion(Data[31], Data[32]);
            }
        }

        public EncryptionType EncryptionType
        {
            get
            {
                return (EncryptionType)Data[33];
            }
        }

        public byte[] SessionKeyEncryptedWithSessionKey1
        {
            get
            {
                byte[] buffer = new byte[masterKeyLength];
                Buffer.BlockCopy(Data, 34, buffer, 0, masterKeyLength);
                return buffer;
            }
        }

        public byte[] HmacSessionKey
        {
            get
            {
                byte[] buffer = new byte[masterKeyLength];
                Buffer.BlockCopy(Data, 34 + masterKeyLength, buffer, 0, masterKeyLength);
                return buffer;
            }
            set
            {
                Buffer.BlockCopy(value, 0, Data, 34 + masterKeyLength, masterKeyLength);
            }
        }

        public override int HmacSessionKeyOffset
        {
            get
            {
                return 34 + masterKeyLength;
            }
        }
    }
}
