﻿using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public class DeviceLoopCommand : DeviceLoopMessageBase
    {
        public DeviceLoopCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 2)
        {
        }

        public DeviceLoopCommand(byte functionCode)
        {
            Data = new byte[1];
            FunctionCode = functionCode;
            Length = Data.Length;
        }

        public DeviceLoopCommand(byte functionCode, byte[] data) : 
            this(functionCode, data, 0, data.Length)
        {
        }

        public DeviceLoopCommand(byte functionCode, byte[] data, int offset, int count)
        {
            Data = new byte[count + 1];
            FunctionCode = functionCode;
            Array.Copy(data, offset, Data, 1, count);
            Length = Data.Length;
        }

        public override string ToString()
        {
            return string.Format("FunctionCode:{0}, Data: {1}", FunctionCode, BitConverter.ToString(Data));
        }

#if COMMUNICATIONSANALYZER

        public DeviceLoopCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { FunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501EC }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
    
}
