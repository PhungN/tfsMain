using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public enum DeviceLoopOverUdpIPMessageType
    {
        None = 0,
        LogOn = 1,
        LogOnResponseSuccess = 2,
        LogOnResponseSetMasterKey = 3,
        Data = 4,
        Ack = 5,
        Poll = 6,
        LogOff = 7,
    }
}