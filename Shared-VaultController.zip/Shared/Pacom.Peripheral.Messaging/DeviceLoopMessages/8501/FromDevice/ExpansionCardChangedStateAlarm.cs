﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // State changes from expansion cards.
    // The message format is:
    // 0x13, STS_1, ..., STS_N
    // STS_X = Status of the expansion card X.
    // Bit 0 - Offline
    // Bit 1 – Fuse fail
    public class ExpansionCardChangedStateAlarm : DeviceLoopMessageBase
    {
        public const int ExpansionCardChangedStateAlarmFunctionCode = 19;

        public ExpansionCardChangedStateAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 2)
        {
        }

        public ExpansionCardChangedStateAlarm(ExpansionCardStatus[] expansionCardStates)
        {
            Data = new byte[1 + expansionCardStates.Length];
            Length = Data.Length;
            FunctionCode = ExpansionCardChangedStateAlarmFunctionCode;

            for (int i = 0; i < expansionCardStates.Length; i++)
            {
                Data[i + 1] = (byte)expansionCardStates[i];
            }
        }

        public ExpansionCardStatus[] GetExpansionCardChangedStates()
        {
            ExpansionCardStatus[] expansionCardStates = new ExpansionCardStatus[Length - 1];

            for (int i = 0; i < expansionCardStates.Length; i++)
            {
                expansionCardStates[i] = (ExpansionCardStatus)Data[Offset + 1 + i];
            }

            return expansionCardStates;
        }

        public override string ToString()
        {
            string message = "Expansion Card Status Changed (";
            ExpansionCardStatus[] expansionCardStates = GetExpansionCardChangedStates();
            foreach (ExpansionCardStatus expansionCardState in expansionCardStates)
            {
                message += expansionCardState.ToString() + ", ";
            }
            message = message.Remove(message.Length - 2, 2);
            message += ")";
            return message;
        }

#if COMMUNICATIONSANALYZER

        public ExpansionCardChangedStateAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { ExpansionCardChangedStateAlarmFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
