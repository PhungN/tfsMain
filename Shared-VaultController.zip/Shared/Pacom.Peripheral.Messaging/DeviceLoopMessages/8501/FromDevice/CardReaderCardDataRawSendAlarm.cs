﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    public class CardReaderCardDataRawSendAlarm : DeviceLoopMessageBase
    {
        public const int CardReaderCardDataRawSendAlarmReader1FunctionCode = 31;
        public const int CardReaderCardDataRawSendAlarmReader2FunctionCode = 32;

        public CardReaderCardDataRawSendAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 4)
        {
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public CardReaderCardDataRawSendAlarm(CardReaderPortType readerNumber, CardReaderDataSendDataRawConfig config)
        {
            if (config == null)
                throw new ArgumentNullException("config");
            if (config.NumberOfBits <= 0 || config.NumberOfBits > 255)
                throw new ArgumentException("Invalid number of bits for card.");

            int numberOfBytes = DeviceLoopUtils.GetByteArrayLengthFromBits(config.NumberOfBits);
            this.Data = new byte[3 + numberOfBytes];

            switch (readerNumber)
            {
                case CardReaderPortType.CardReader1:
                    this.FunctionCode = CardReaderCardDataRawSendAlarmReader1FunctionCode;
                    break;
                case CardReaderPortType.CardReader2:
                    this.FunctionCode = CardReaderCardDataRawSendAlarmReader2FunctionCode;
                    break;
                default:
                    throw new ArgumentException("Invalid reader number.");
            }

            constructCardReaderCardDataRawSendCommand(config, numberOfBytes);
            this.Length = this.Data.Length;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public bool GetConfiguration(out CardReaderPortType readerNumber, out CardReaderDataSendDataRawConfig config)
        {
            config = null;
            readerNumber = CardReaderPortType.NoReader;
            if (this.Data.Length < 4)
                return false;
            readerNumber = getCardReader();
            if (readerNumber == CardReaderPortType.NoReader)
                return false;
            config = parseCardReaderCardDataRawSendCommand();
            return true;
        }

        private CardReaderPortType getCardReader()
        {
            switch (this.Data[this.Offset])
            {
                case CardReaderCardDataRawSendAlarmReader1FunctionCode:
                    return CardReaderPortType.CardReader1;
                case CardReaderCardDataRawSendAlarmReader2FunctionCode:
                    return CardReaderPortType.CardReader2;
                default:
                    return CardReaderPortType.NoReader;
            }
        }

        private void constructCardReaderCardDataRawSendCommand(CardReaderDataSendDataRawConfig config, int numberOfBytes)
        {
            this.Data[Offset + 1] = (byte)config.ReaderType;
            if (config.NumberOfBits <= 0)
                return;
            this.Data[Offset + 2] = (byte)config.NumberOfBits;
            DeviceLoopUtils.ConstructRawCardData(ref config, (index, data) =>
            {
                this.Data[Offset + 3 + index] = data;
            });
        }

        private CardReaderDataSendDataRawConfig parseCardReaderCardDataRawSendCommand()
        {
            CardReaderDataSendDataRawConfig config = new CardReaderDataSendDataRawConfig();
            config.ReaderType = (CardReaderType)Data[Offset + 1];
            config.NumberOfBits = Data[Offset + 2];
            if (config.NumberOfBits <= 0)
                config.Data = new byte[0];
            else
                DeviceLoopUtils.ParseRawCardData(ref config, Offset + 3, Data);
            return config;
        }

        public override string ToString()
        {
            return string.Format("{0} Card Data Raw Send", getCardReader().ToString());
        }

#if COMMUNICATIONSANALYZER

        public CardReaderCardDataRawSendAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] {
                CardReaderCardDataRawSendAlarmReader1FunctionCode,
                CardReaderCardDataRawSendAlarmReader2FunctionCode
            }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(this.ToString());
            sb.Append(Environment.NewLine);
            CardReaderPortType readerNumber;
            CardReaderDataSendDataRawConfig config;
            if (GetConfiguration(out readerNumber, out config))
            {
                sb.Append(string.Format("Number of bits: {0}, Data: {1}", config.NumberOfBits, BitConverter.ToString(config.Data)));
                sb.Append(Environment.NewLine);
                byte[] rawDeviceLoopData = new byte[DeviceLoopUtils.GetByteArrayLengthFromBits(config.NumberOfBits)];
                Array.Copy(this.Data, Offset + 3, rawDeviceLoopData, 0, rawDeviceLoopData.Length);
                sb.Append(string.Format("Unprocessed device loop data: {0}", BitConverter.ToString(rawDeviceLoopData)));
                sb.Append(Environment.NewLine);
            }
            else
            {
                sb.Append("Unbale to parse.");
                sb.Append(Environment.NewLine);
            }            
            return sb.ToString();
        }

#endif
    }
}
