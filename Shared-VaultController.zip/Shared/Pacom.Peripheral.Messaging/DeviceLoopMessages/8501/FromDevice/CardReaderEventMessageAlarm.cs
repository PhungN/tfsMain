﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    /// <summary>
    /// Send event message to the controller. Events are collected during degraded mode
    /// and send to the controller after going online.
    /// </summary>
    public class CardReaderEventMessageAlarm : DeviceLoopMessageBase
    {
        public const int CardReaderEventMessageAlarmFunctionCode = 30;

        /// <summary>
        /// Parse "EventMessage" device loop message.
        /// </summary>
        /// <param name="data">Byte array with device loop message.</param>
        /// <param name="offset">Offset is used to indicate position of function code in the byte array.</param>
        /// <param name="length">Length of data from function code to the end of array or check code.</param>
        public CardReaderEventMessageAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 13)
        {
        }

        /// <summary>
        /// Format device loop mesage from CardReaderEventData class
        /// </summary>
        /// <param name="eventData"></param>
        public CardReaderEventMessageAlarm(CardReaderEventDataConfig eventData)
        {
            if (eventData == null)
            {
                throw new ArgumentNullException("eventData", "Cannot be null.");
            }

            this.Data = new byte[13];
            this.FunctionCode = CardReaderEventMessageAlarmFunctionCode;
            constructEventMessageCommand(eventData);
            this.Length = this.Data.Length;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public bool GetConfiguration(out CardReaderEventDataConfig eventData)
        {
            eventData = parseEventMessageCommand();
            if (eventData != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// The designator for format is FFICCCCC. 16 bits facility, 8 bits issue, 40 bits code.
        /// </summary>
        /// <param name="eventData"></param>
        private void constructEventMessageCommand(CardReaderEventDataConfig eventData)
        {
            if (eventData.Facility != null)
            {
                int facilityLength = Math.Min(2, eventData.Facility.Length);
                for (int i = 0; i < 2; i++)
                {
                    if (eventData.Facility.Length > i)
                    {
                        this.Data[this.Offset + (i + 1)] = eventData.Facility[(facilityLength - 1) - i];
                    }
                    else
                    {
                        this.Data[this.Offset + (i + 1)] = 0;
                    }
                }
            }
            if (eventData.Issue != null)
            {
                if (eventData.Issue.Length > 0)
                {
                    this.Data[this.Offset + 3] = eventData.Issue[0];
                }
                else
                {
                    this.Data[this.Offset + 3] = 0;
                }
            }
            if (eventData.Code != null)
            {
                int codeLength = Math.Min(5, eventData.Code.Length);
                for (int i = 0; i < 5; i++)
                {
                    if (eventData.Code.Length > i)
                    {
                        this.Data[this.Offset + (i + 4)] = eventData.Code[(codeLength - 1) - i];
                    }
                    else
                    {
                        this.Data[this.Offset + (i + 4)] = 0;
                    }
                }
            }

            this.Data[this.Offset + 9] = eventData.Second;
            this.Data[this.Offset + 10] = eventData.Minute;
            this.Data[this.Offset + 11] = (byte)(eventData.DayOfWeek << 5);
            this.Data[this.Offset + 11] |= (byte)(eventData.Hour & 0x1F);
            if (eventData.ReaderNumber == CardReaderPortType.CardReader1)
            {
                this.Data[this.Offset + 12] = 0;
            }
            else if (eventData.ReaderNumber == CardReaderPortType.CardReader2)
            {
                this.Data[this.Offset + 12] = 0x80;
            }
        }

        /// <summary>
        /// The designator for format is FFICCCCC. 16 bits facility, 8 bits issue, 40 bits code.
        /// </summary>
        /// <returns></returns>
        private CardReaderEventDataConfig parseEventMessageCommand()
        {
            if (this.Data.Length < 13)
                return null;

            CardReaderEventDataConfig eventData = new CardReaderEventDataConfig();
            if (this.Data[this.Offset + 1] == 0 && this.Data[this.Offset + 2] == 0)
            {
                eventData.Facility = new byte[0];
            }
            else if (this.Data[this.Offset + 2] == 0)
            {
                eventData.Facility = new byte[1];
                eventData.Facility[0] = this.Data[this.Offset + 1];
            }
            else
            {
                eventData.Facility = new byte[2];
                eventData.Facility[0] = this.Data[this.Offset + 2];
                eventData.Facility[1] = this.Data[this.Offset + 1];
            }

            if (this.Data[this.Offset + 3] == 0)
            {
                eventData.Issue = new byte[0];
            }
            else
            {
                eventData.Issue = new byte[1];
                eventData.Issue[0] = this.Data[this.Offset + 3];
            }
            int countNonZero = 1;
            for (int i = 4; i >= 0; i--)
            {
                if (this.Data[this.Offset + 3 + i] == 0)
                {
                    countNonZero++;
                }
                else
                {
                    break;
                }
            }
            eventData.Code = new byte[5 - countNonZero];
            for (int i = 0; i < 5 - countNonZero; i++)
            {
                eventData.Code[(eventData.Code.Length - 1) - i] = this.Data[this.Offset + 4 + i];
            }
            eventData.Second = this.Data[this.Offset + 9];
            eventData.Minute = this.Data[this.Offset + 10];
            eventData.Hour = (byte)(this.Data[this.Offset + 11] & 0x1F);
            eventData.DayOfWeek = (byte)(this.Data[this.Offset + 11] >> 5);
            if (this.Data[this.Offset + 12] == 0)
            {
                eventData.ReaderNumber = CardReaderPortType.CardReader1;
            }
            else if (this.Data[this.Offset + 12] == 0x80)
            {
                eventData.ReaderNumber = CardReaderPortType.CardReader2;
            }
            return eventData;
        }

        public override string ToString()
        {
            return "Card Reader Event Message";
        }

#if COMMUNICATIONSANALYZER

        public CardReaderEventMessageAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { CardReaderEventMessageAlarmFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
