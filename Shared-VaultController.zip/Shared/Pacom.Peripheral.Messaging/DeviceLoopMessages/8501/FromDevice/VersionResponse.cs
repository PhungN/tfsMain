﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // 04, AppVerHigh, AppVerLow, BootloaderVerHigh, BootloaderVerLow, Flags, OsVerHigh, OsVerLow
    //
    // Flags  Bit 0   : Running in Image A
    //        Bit 1   : Running in Image B
    //        Bit 6-7 : Number of bytes to use in the Bank Field of the Software Download command
    //                  bankFieldLength = (bits 6-7) + 1 
    public class VersionResponse : DeviceLoopMessageBase
    {
        public const int VersionResponseFunctionCode = 4;

        public VersionResponse(byte[] data, int offset, int length)
            : base(data, offset, length, 8)
        {
        }

        public VersionResponse(FirmwareVersion applicationVersion, FirmwareVersion bootloaderVersion, FirmwareVersion osVersion, BootImage8501 runningImage)
        {
            Data = new byte[8];
            FunctionCode = VersionResponseFunctionCode;

            Data[1] = (byte)applicationVersion.Major;
            Data[2] = (byte)applicationVersion.Minor;
            Data[3] = (byte)bootloaderVersion.Major;
            Data[4] = (byte)bootloaderVersion.Minor;
            Data[6] = (byte)osVersion.Major;
            Data[7] = (byte)osVersion.Minor;

            // The 8501 expects a 2 byte bankFieldLength.
            if (runningImage == BootImage8501.ImageA)
                Data[5] = 0x41;
            else
                Data[5] = 0x42;

            Length = 8;
        }

        public FirmwareVersion ApplicationVersion
        {
            get
            {
                return new FirmwareVersion(Data[Offset + 1], Data[Offset + 2]);
            }
        }

        public FirmwareVersion BootloaderVersion
        {
            get
            {
                return new FirmwareVersion(Data[Offset + 3], Data[Offset + 4]);
            }
        }

        public FirmwareVersion OSVersion
        {
            get
            {
                return new FirmwareVersion(Data[Offset + 6], Data[Offset + 7]);
            }
        }

        public override string ToString()
        {
            return "Version (ApplicationVersion = " + ApplicationVersion.ToString() + " BootloaderVersion = " + BootloaderVersion.ToString() + " OsVersion = " + OSVersion.ToString() + ")";
        }

#if COMMUNICATIONSANALYZER

        public VersionResponse()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { VersionResponseFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
