﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    /// <summary>
    /// Send key press to the controller
    /// </summary>
    public class CardReaderNumberInputAlarm : DeviceLoopMessageBase
    {
        public const int CardReaderNumberInputAlarmReader1FunctionCode = 34;
        public const int CardReaderNumberInputAlarmReader2FunctionCode = 37;

        /// <summary>
        /// Parse "NumberInput" device loop message.
        /// </summary>
        /// <param name="data">Byte array with device loop message.</param>
        /// <param name="offset">Offset is used to indicate position of function code in the byte array.</param>
        /// <param name="length">Length of data from function code to the end of array or check code.</param>
        public CardReaderNumberInputAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 3)
        {
        }

        /// <summary>
        /// Format pin data input as message to the controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="readerType"></param>
        /// <param name="keys"></param>
        public CardReaderNumberInputAlarm(CardReaderPortType readerNumber, CardReaderType readerType, byte[] keys)
        {
            if (keys == null)
            {
                throw new ArgumentNullException("keys");
            }
            
            int keysNumber = 0;
            if (keys.Length > 9)
                keysNumber = 9;
            else
                keysNumber = keys.Length;

            this.Length = 2 + ((keysNumber / 2) + ((keysNumber % 2) > 0 ? 1 : 0));
            this.Data = new byte[Length];

            switch (readerNumber)
            {
                case CardReaderPortType.CardReader1:
                    this.FunctionCode = CardReaderNumberInputAlarmReader1FunctionCode;
                    break;
                case CardReaderPortType.CardReader2:
                    this.FunctionCode = CardReaderNumberInputAlarmReader2FunctionCode;
                    break;
                default:
                    throw new ArgumentException("Invalid reader number.");
            }

            constructNumberInputCommand(readerType, keys);
            this.Length = this.Data.Length;
        }

        private void constructNumberInputCommand(CardReaderType readerType, byte[] keys)
        {
            this.Data[this.Offset + 1] = (byte)readerType;

            // Reset values to default 255s.
            for (int i = 2; i < Length; i++)
            {
                this.Data[this.Offset + i] = 0xFF;
            }

            // Overlay card scan.
            int skipHalfByte = (keys.Length % 2) != 0 ? 1 : 0;
            for (int i = 0; i < keys.Length + skipHalfByte; i++)
            {
                if (skipHalfByte != 0 & i == 0)
                {
                    // Skip first half of the first byte
                }
                else
                {
                    if ((i & 1) == 1)
                    {
                        this.Data[this.Offset + 2 + (i / 2)] &= (byte)(keys[i - skipHalfByte] | 0xF0);
                    }
                    else
                    {
                        this.Data[this.Offset + 2 + (i / 2)] &= (byte)((keys[i - skipHalfByte] << 4) | 0x0F);
                    }
                }
            }
        }

        public bool GetConfiguration(out CardReaderPortType readerNumber, out CardReaderType readerType, out byte[] keys)
        {
            if (this.Data.Length < 8)
            {
                readerNumber = CardReaderPortType.NoReader;
                readerType = CardReaderType.NoReader;
                keys = new byte[0];
                return false;
            }

            switch (this.Data[this.Offset])
            {
                case CardReaderNumberInputAlarmReader1FunctionCode:
                    readerNumber = CardReaderPortType.CardReader1;
                    break;
                case CardReaderNumberInputAlarmReader2FunctionCode:
                    readerNumber = CardReaderPortType.CardReader2;
                    break;
                default:
                    readerNumber = CardReaderPortType.NoReader;
                    readerType = CardReaderType.NoReader;
                    keys = new byte[0];
                    return false;
            }

            if (parseNumberInputCommand(out readerType, out keys) == true)
            {
                return true;
            }
            else
            {
                readerNumber = CardReaderPortType.NoReader;
                readerType = CardReaderType.NoReader;
                keys = new byte[0];
                return false;
            }
        }

        private bool parseNumberInputCommand(out CardReaderType readerType, out byte[] keys)
        {
            int numberOfKeys = (this.Length - 2) * 2;

            if (numberOfKeys <= 0)
            {
                readerType = CardReaderType.NoReader;
                keys = new byte[0];
                return false;
            }

            // If the high part of the highest byte is 0xF0, it means it is not used.
            // Check if this is this case and substract one from the total.
            bool skipHalfByte = false;
            if ((this.Data[this.Offset + 2] & 0xF0) == 0xF0)
            {
                numberOfKeys -= 1;
                skipHalfByte = true;
            }

            // Reader type            
            readerType = (CardReaderType)Enum.Parse(typeof(CardReaderType), this.Data[this.Offset + 1].ToString(), true);

            // Extract keys. First half of first code byte can be 0xF0.
            keys = new byte[numberOfKeys];
            for (int keyCount = 0; keyCount < numberOfKeys; keyCount++)
            {
                if (skipHalfByte)
                {
                    int byteCount = (keyCount + 1) / 2;
                    if ((keyCount & 1) == 0)
                    {
                        keys[keyCount] = (byte)(this.Data[this.Offset + 2 + byteCount] & 0x0F);
                    }
                    else
                    {
                        keys[keyCount] = (byte)(this.Data[this.Offset + 2 + byteCount] >> 4); //0xF0
                    }
                }
                else
                {
                    int byteCount = keyCount / 2;
                    if ((keyCount & 1) == 1)
                    {
                        keys[keyCount] = (byte)(this.Data[this.Offset + 2 + byteCount] & 0x0F);
                    }
                    else
                    {
                        keys[keyCount] = (byte)(this.Data[this.Offset + 2 + byteCount] >> 4); //0xF0          
                    }
                }
            }
            return true;
        }

        public override string ToString()
        {
            return "Card Reader Input Number";
        }

#if COMMUNICATIONSANALYZER

        public CardReaderNumberInputAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] {
                CardReaderNumberInputAlarmReader1FunctionCode,
                CardReaderNumberInputAlarmReader2FunctionCode
            }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
