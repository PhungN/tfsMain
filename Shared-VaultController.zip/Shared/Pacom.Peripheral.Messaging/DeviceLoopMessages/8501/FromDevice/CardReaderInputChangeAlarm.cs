﻿using System;
using Pacom.Peripheral.Common;
using System.Text;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{   
    /// <summary>
    /// Message sent when reader input states are changing.
    /// </summary>
    public class CardReaderInputChangeAlarm : DeviceLoopMessageBase
    {        
        public const int CardReaderInputChangeAlarmReader1FunctionCode = 39;
        public const int CardReaderInputChangeAlarmReader2FunctionCode = 40;
        
        public CardReaderInputChangeAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 4)
        {  
        }

        public CardReaderInputChangeAlarm(CardReaderPortType readerNumber, ReaderInputStatusChangeConfig config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            this.Data = new byte[4];
            
            switch (readerNumber)
            {
                case CardReaderPortType.CardReader1:
                    this.FunctionCode = CardReaderInputChangeAlarmReader1FunctionCode;
                    break;
                case CardReaderPortType.CardReader2:
                    this.FunctionCode = CardReaderInputChangeAlarmReader2FunctionCode;
                    break;
                default:
                    throw new ArgumentException("Invalid reader number.");
            }
            constructInputChangeCommand(config);
            this.Length = this.Data.Length;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public bool GetConfiguration(out CardReaderPortType readerNumber, out ReaderInputStatusChangeConfig config)
        {            
            if (this.Data.Length < 4)
            {
                readerNumber = CardReaderPortType.NoReader;
                config = null;
                return false;
            }

            switch (this.Data[this.Offset])
            {
                case CardReaderInputChangeAlarmReader1FunctionCode:
                    readerNumber = CardReaderPortType.CardReader1;
                    break;
                case CardReaderInputChangeAlarmReader2FunctionCode:
                    readerNumber = CardReaderPortType.CardReader2;
                    break;
                default:
                    readerNumber = CardReaderPortType.NoReader;
                    config = null;
                    return false;
            }

            config = parseInputChangeCommand();
            return true;

        }

        private void constructInputChangeCommand(ReaderInputStatusChangeConfig config)
        {
            this.Data[this.Offset + 1] = (byte)(config.ReaderType);
            this.Data[this.Offset + 2] = (byte)((((byte)config.EgressState) & 0x0F) << 4);
            this.Data[this.Offset + 2] |= (byte)(((byte)config.ContactState) & 0x0F);
            this.Data[this.Offset + 3] = (byte)((((byte)config.SpareState) & 0x0F) << 4);
            this.Data[this.Offset + 3] |= (byte)(((byte)config.StrikeState) & 0x0F);
        }

        private ReaderInputStatusChangeConfig parseInputChangeCommand()
        {
            if (this.Data.Length < 4)
                return null;

            ReaderInputStatusChangeConfig config = new ReaderInputStatusChangeConfig();
            // get type
            config.ReaderType = (CardReaderType)Data[this.Offset + 1];
            config.ContactState = (InputStatus)(Data[Offset + 2] & 0x0F);
            config.EgressState = (InputStatus)(Data[this.Offset + 2] >> 4);
            config.StrikeState = (InputStatus)(Data[Offset + 3] & 0x0F);
            config.SpareState = (InputStatus)(Data[Offset + 3] >> 4);

            return config;
        }
        
        public override string ToString()
        {
            return "Card Reader Input State Change";
        }

#if COMMUNICATIONSANALYZER

        public CardReaderInputChangeAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] {
                CardReaderInputChangeAlarmReader1FunctionCode,
                CardReaderInputChangeAlarmReader2FunctionCode
            }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(this.ToString());
            CardReaderPortType readerNumber;
            ReaderInputStatusChangeConfig config;
            if (GetConfiguration(out readerNumber, out config))
            {
                sb.Append(System.Environment.NewLine);
                sb.Append(System.Environment.NewLine);
                sb.Append(string.Format("Card Reader: {0}{1}", readerNumber.ToString(), System.Environment.NewLine));
                sb.Append(string.Format("Card Reader Type: {0}{1}", config.ReaderType.ToString(), System.Environment.NewLine));
                sb.Append(string.Format("Contact State: {0}{1}", config.ContactState.ToString(), System.Environment.NewLine));
                sb.Append(string.Format("Egress State: {0}{1}", config.EgressState.ToString(), System.Environment.NewLine));
                sb.Append(string.Format("Strike State: {0}{1}", config.StrikeState.ToString(), System.Environment.NewLine));
                sb.Append(string.Format("Spare State: {0}{1}", config.SpareState.ToString(), System.Environment.NewLine));
            }
            else
            {
                sb.Append("Unable to parse command.");
            }
            return sb.ToString();
        }

#endif
    }
}
