﻿using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // State changes from up to eight alarm inputs on the main and mezzanine boards can be 
    // reported in one message.  The message format is:
    // 06, RPT_1, ..., RPT_N
    // Each alarm is reported in one byte.  Valid alarm states are:
    // 00 - Secure
    // 01 - Alarm
    // 02 - Short circuit
    // 03 - Open circuit
    // 04 - Trouble
    // If more than eight inputs need to be reported, return code one should be used. 
    // Main board input alarm report format has bit 7 always zero, bits 3 to 6 specify input 
    // number, and bits 0 to 2 specify input alarm state:
    // 0 000  0 XXX   to   0 111  1 XXX
    // Mezzanine board input alarm report format has bit 7 always one, bits 2 to 6 
    // specify input number (1 to 32), and bits 0 to 1 specify input alarm state:
    // 1 000  00 XX   to   1 111  11 XX
    public class LegacyInputChangedStateAlarm : DeviceLoopMessageBase
    {
        public const int LegacyInputChangedStateAlarmFunctionCode = 6;

        public LegacyInputChangedStateAlarm(byte[] data, int offset, int length)
            : base(data, offset, length, 2)
        {
        }

        public LegacyInputChangedStateAlarm(InputPoint[] inputs)
        {
            Data = new byte[1 + inputs.Length];
            Length = Data.Length;
            FunctionCode = LegacyInputChangedStateAlarmFunctionCode;

            for (int i = 0; i < inputs.Length; i++)
            {
                Data[i + 1] = (byte)(inputs[i].InputPointNumber << 3);
                Data[i + 1] |= (byte)inputs[i].InputStatus;
            }
        }

        public LegacyInputChangedStateAlarm(int inputPointNumber, InputStatus inputStatus)
        {
            Data = new byte[2];
            Length = Data.Length;
            FunctionCode = LegacyInputChangedStateAlarmFunctionCode;

            Data[1] = (byte)((inputPointNumber << 3) + (byte)inputStatus);
        }

        public InputPoint[] GetInputStates()
        {
            InputPoint[] inputs = new InputPoint[Length - 1];

            for (int i = 0; i < inputs.Length; i++)
            {
                inputs[i] = new InputPoint((Data[Offset + i + 1] >> 3), (InputStatus)(Data[Offset + i + 1] & 7));
            }

            return inputs;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder("Input Changed State (");
            InputPoint[] inputs = GetInputStates();
            int i = 0;
            string format = "Input {0} {1}, ";
            foreach (InputPoint input in inputs)
            {
                if (i == inputs.Length - 1)
                    format = "Input {0} {1})";
                sb.AppendFormat(format, input.InputPointNumber, input.InputStatus);
                i++;
            }
            return sb.ToString();
        }

#if COMMUNICATIONSANALYZER

        public LegacyInputChangedStateAlarm()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { LegacyInputChangedStateAlarmFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return false; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
