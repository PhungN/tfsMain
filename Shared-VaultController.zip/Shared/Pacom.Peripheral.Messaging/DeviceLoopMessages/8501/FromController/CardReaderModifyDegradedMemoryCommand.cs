﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    /// <summary>
    /// Modify card reader degraded (master) memory command
    /// </summary>
    public class CardReaderModifyDegradedMemoryCommand : DeviceLoopMessageBase
    {
        public const int CardReaderModifyDegradedMemoryCommandReader1FunctionCode = 30;
        public const int CardReaderModifyDegradedMemoryCommandReader2FunctionCode = 35;

        public CardReaderModifyDegradedMemoryCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 11)
        {
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public CardReaderModifyDegradedMemoryCommand(CardReaderPortType readerNumber, ReaderDegradedMemoryConfig config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            if (config.CardRange == false)
            {
                this.Data = new byte[11];
            }
            else
            {
                this.Data = new byte[19];
            }
            switch (readerNumber)
            {
                case CardReaderPortType.CardReader1:
                    this.FunctionCode = CardReaderModifyDegradedMemoryCommandReader1FunctionCode;
                    break;
                case CardReaderPortType.CardReader2:
                    this.FunctionCode = CardReaderModifyDegradedMemoryCommandReader2FunctionCode;
                    break;
                default:
                    throw new ArgumentException("Invalid reader number.");
            }

            constructModifyDegradedMemoryCommand(config);
            this.Length = this.Data.Length;
        }

        public byte[] FirstCardRaw
        {
            get
            {
                byte[] card = new byte[8];
                Buffer.BlockCopy(Data, Offset + 2, card, 0, card.Length);
                return card;
            }
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public bool GetConfiguration(out CardReaderPortType readerNumber, out ReaderDegradedMemoryConfig config)
        {
            if (this.Data.Length < 11)
            {
                readerNumber = CardReaderPortType.NoReader;
                config = null;
                return false;
            }
            switch (this.Data[this.Offset])
            {
                case CardReaderModifyDegradedMemoryCommandReader1FunctionCode:
                    readerNumber = CardReaderPortType.CardReader1;
                    break;
                case CardReaderModifyDegradedMemoryCommandReader2FunctionCode:
                    readerNumber = CardReaderPortType.CardReader2;
                    break;
                default:
                    readerNumber = CardReaderPortType.NoReader;
                    config = null;
                    return false;
            }
            config = parseDegradedMemoryCommand();
            if (config == null)
            {
                return false;
            }
            return true;
        }

        private void constructModifyDegradedMemoryCommand(ReaderDegradedMemoryConfig config)
        {

            this.Data[this.Offset + 1] = (byte)config.CardType;

            if (config.AddCode == false)
            {
                this.Data[this.Offset + 2] = 1;
            }
            else
            {
                this.Data[this.Offset + 2] = 0;
            }
            // Add rest of flags
            if (config.ModifyFacility == true)
            {
                this.Data[this.Offset + 2] |= 32;
            }
            if (config.MasterCardStore == false)
            {
                this.Data[this.Offset + 2] |= 128;
            }

            for (int iFacility = 0; iFacility < 2; iFacility++)
            {
                if (config.FirstCard.Facility.Length - 1 >= iFacility) 
                {
                    this.Data[this.Offset + 3 + iFacility] = config.FirstCard.Facility[config.FirstCard.Facility.Length - 1 - iFacility];
                }
            }

            if (config.FirstCard.Issue.Length > 0)
            {
                this.Data[this.Offset + 5] = config.FirstCard.Issue[0];
            }

            for (int iCode = 0; iCode < 5; iCode++)
            {
                if (config.FirstCard.Code.Length - 1 >= iCode)
                {
                    this.Data[this.Offset + 6 + iCode] = config.FirstCard.Code[config.FirstCard.Code.Length - 1 - iCode];
                }
            }            

            if (config.CardRange)
            {
                this.Data[this.Offset + 2] |= 64;

                for (int iFacility = 0; iFacility < 2; iFacility++)
                {
                    if (config.SecondCard.Facility.Length - 1 >= iFacility)
                    {
                        this.Data[this.Offset + 11 + iFacility] = config.SecondCard.Facility[config.SecondCard.Facility.Length - 1 - iFacility];
                    }
                }

                if (config.SecondCard.Issue.Length > 0)
                {
                    this.Data[this.Offset + 13] = config.SecondCard.Issue[0];
                }

                for (int iCode = 0; iCode < 5; iCode++)
                {
                    if (config.SecondCard.Code.Length - 1 >= iCode)
                    {
                        this.Data[this.Offset + 14 + iCode] = config.SecondCard.Code[config.SecondCard.Code.Length - 1 - iCode];
                    }
                }
            }
        }

        private ReaderDegradedMemoryConfig parseDegradedMemoryCommand()
        {
            if (this.Data.Length < 11)
                return null;

            ReaderDegradedMemoryConfig config = new ReaderDegradedMemoryConfig();

            // Reader type
            config.CardType = (CardReaderType)Enum.Parse(typeof(CardReaderType), this.Data[this.Offset + 1].ToString(), true);

            // Bit 0 - 0 for add and 1 for delete
            config.AddCode = (this.Data[this.Offset + 2] & 1) == 0;
            // Bit 5 – 1 for modify Facility memory EEprom
            config.ModifyFacility = (this.Data[this.Offset + 2] & 32) != 0;
            // Bit 6 – 0 for only one card number included  and 1 for second card included to specify a range to and from
            config.CardRange = (this.Data[this.Offset + 2] & 64) != 0;
            // Bit 7 – 0 for master card store and 1 for RAM card store
            config.MasterCardStore = (this.Data[this.Offset + 2] & 128) == 0;

            // We need to remove zero bytes from the front of the facility
            bool copyFacility = false;
            for (int iFacility = 1; iFacility >= 0; iFacility--)
            {
                if (this.Data[this.Offset + 3 + iFacility] != 0 && copyFacility == false)
                {
                    copyFacility = true;
                    config.FirstCard.Facility = new byte[iFacility + 1];
                }
                if (copyFacility == true)
                {
                    config.FirstCard.Facility[config.FirstCard.Facility.Length - iFacility - 1] = this.Data[this.Offset + 3 + iFacility];
                }
            }
            if (copyFacility == false)
            {
                config.FirstCard.Facility = new byte[0];
            }

            if (this.Data[this.Offset + 5] == 0)
            {
                config.FirstCard.Issue = new byte[0];
            }
            else
            {
                config.FirstCard.Issue = new byte[1] { this.Data[this.Offset + 5] };
            }

            // We need to remove zero bytes from the front of the facility
            bool copyCode = false;
            for (int iCode = 4; iCode >= 0; iCode--)
            {
                if (this.Data[this.Offset + 6 + iCode] != 0 && copyCode == false)
                {
                    copyCode = true;
                    config.FirstCard.Code = new byte[iCode + 1];
                }
                if (copyCode == true)
                {
                    config.FirstCard.Code[config.FirstCard.Code.Length - iCode - 1] = this.Data[this.Offset + 6 + iCode];
                }
            }
            if (copyCode == false)
            {
                config.FirstCard.Code = new byte[0];
            }

            if (config.CardRange)
            {
                if (this.Data.Length < 19)
                    return null;

                // We need to remove zero bytes from the front of the facility
                bool copyFacilitySecond = false;
                for (int iFacility = 1; iFacility >= 0; iFacility--)
                {
                    if (this.Data[this.Offset + 11 + iFacility] != 0 && copyFacilitySecond == false)
                    {
                        copyFacilitySecond = true;
                        config.SecondCard.Facility = new byte[iFacility + 1];
                    }
                    if (copyFacilitySecond == true)
                    {
                        config.SecondCard.Facility[config.SecondCard.Facility.Length - iFacility - 1] = this.Data[this.Offset + 11 + iFacility];
                    }
                }
                if (copyFacilitySecond == false)
                {
                    config.SecondCard.Facility = new byte[0];
                }

                if (this.Data[this.Offset + 13] == 0)
                {
                    config.SecondCard.Issue = new byte[0];
                }
                else
                {
                    config.SecondCard.Issue = new byte[1] { this.Data[this.Offset + 13] };
                }
                                
                // We need to remove zero bytes from the front of the facility
                bool copyCodeSecond = false;
                for (int iCode = 4; iCode >= 0; iCode--)
                {
                    if (this.Data[this.Offset + 14 + iCode] != 0 && copyCodeSecond == false)
                    {
                        copyCodeSecond = true;
                        config.SecondCard.Code = new byte[iCode + 1];
                    }
                    if (copyCodeSecond == true)
                    {
                        config.SecondCard.Code[config.SecondCard.Code.Length - iCode - 1] = this.Data[this.Offset + 14 + iCode];
                    }
                }
                if (copyCodeSecond == false)
                {
                    config.SecondCard.Code = new byte[0];
                }
            }

            if (config.FirstCard.Facility.SequenceEqual(new byte[0]) &&
                   config.FirstCard.Issue.SequenceEqual(new byte[0]) &&
                       config.FirstCard.Code.SequenceEqual(new byte[0]))
            {
                config.FirstCard.Facility = new byte[] { 0x0, 0x0 };
                config.FirstCard.Issue = new byte[] { 0x0 };
                config.FirstCard.Code = new byte[] { 0x0, 0x0, 0x0, 0x0, 0x0 };
            }

            return config;
        }

        public override string ToString()
        {
            return "Modify Card Reader Degraded Memory";
        }

#if COMMUNICATIONSANALYZER

        public CardReaderModifyDegradedMemoryCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { 
                CardReaderModifyDegradedMemoryCommandReader1FunctionCode,
                CardReaderModifyDegradedMemoryCommandReader2FunctionCode
            }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
