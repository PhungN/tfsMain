﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    /// <summary>
    /// Card reader initialise command
    /// </summary>
    public class CardReaderInitializeCommand : DeviceLoopMessageBase
    {
        public const int CardReaderInitializeCommandReader1FunctionCode = 29;
        public const int CardReaderInitializeCommandReader2FunctionCode = 34;

        /// <summary>
        /// Processing data recieved from controller.
        /// </summary>
        /// <param name="data"></param>
        /// <param name="offset"></param>
        /// <param name="length"></param>
        public CardReaderInitializeCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 20)
        {
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public CardReaderInitializeCommand(CardReaderPortType readerNumber, ReaderInitializationConfig config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            this.Data = new byte[21];
            switch (readerNumber)
            {
                case CardReaderPortType.CardReader1:
                    this.FunctionCode = CardReaderInitializeCommandReader1FunctionCode;
                    break;
                case CardReaderPortType.CardReader2:
                    this.FunctionCode = CardReaderInitializeCommandReader2FunctionCode;
                    break;
                default:
                    throw new ArgumentException("Invalid reader number.");
            }

            constructInitializationCommand(config);
            this.Length = this.Data.Length;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public bool GetConfiguration(out CardReaderPortType readerNumber, out ReaderInitializationConfig config)
        {
            if (this.Data.Length < 20)
            {
                readerNumber = CardReaderPortType.NoReader;
                config = null;
                return false;
            }

            switch (this.Data[this.Offset])
            {
                case CardReaderInitializeCommandReader1FunctionCode:
                    readerNumber = CardReaderPortType.CardReader1;
                    break;
                case CardReaderInitializeCommandReader2FunctionCode:
                    readerNumber = CardReaderPortType.CardReader2;
                    break;
                default:
                    readerNumber = CardReaderPortType.NoReader;
                    config = null;
                    return false;
            }

            config = parseInitializationCommand();
            return true;
        }

        /// <summary>
        /// Extract card reader port from data. The function code is used.
        /// </summary>
        public CardReaderPortType ReaderNumber
        {
            get
            {
                // Offset position points to function code, from where the card reader port is derived.
                if (this.Data[this.Offset] == CardReaderInitializeCommandReader1FunctionCode)
                {
                    return CardReaderPortType.CardReader1;
                }
                else if (this.Data[this.Offset] == CardReaderInitializeCommandReader2FunctionCode)
                {
                    return CardReaderPortType.CardReader2;
                }
                else
                {
                    return CardReaderPortType.NoReader;
                }
            }
        }

        private void constructInitializationCommand(ReaderInitializationConfig config)
        {
            int cfgOffset = this.Offset;

            this.Data[cfgOffset + 1] = (byte)config.ReaderType;

            // Facility
            if (config.Facility.UnitType == CardConfigFieldType.InBits)
            {
                this.Data[cfgOffset + 2] = (byte)((config.Facility.Length & 0x3F) | 0x40); // Length always in bits
                this.Data[cfgOffset + 3] = (byte)((config.Facility.ZeroBasedOffset & 0x7F) + 1);
                if (config.Facility.IncludeInMask == true)
                {
                    this.Data[cfgOffset + 3] |= (byte)0x80;
                }
            }
            else
            {
                this.Data[cfgOffset + 2] = 0;
                this.Data[cfgOffset + 3] = 0;
            }

            // Issue
            if (config.Issue.UnitType == CardConfigFieldType.InBits)
            {
                this.Data[cfgOffset + 4] = (byte)((config.Issue.Length & 0x3F) | 0x40); // Length always in bits
                this.Data[cfgOffset + 5] = (byte)((config.Issue.ZeroBasedOffset & 0x7F) + 1);
                if (config.Issue.IncludeInMask == true)
                {
                    this.Data[cfgOffset + 5] |= (byte)0x80;
                }
            }
            else
            {
                this.Data[cfgOffset + 4] = 0;
                this.Data[cfgOffset + 5] = 0;
            }

            // Code
            if (config.Code.UnitType == CardConfigFieldType.InBits)
            {
                this.Data[cfgOffset + 6] = (byte)((config.Code.Length & 0x3F) | 0x40); // Length always in bits
                this.Data[cfgOffset + 7] = (byte)((config.Code.ZeroBasedOffset & 0x7F) + 1);
                if (config.Code.IncludeInMask == true)
                {
                    this.Data[cfgOffset + 7] |= (byte)0x80;
                }
            }
            else
            {
                this.Data[cfgOffset + 6] = 0;
                this.Data[cfgOffset + 7] = 0;
            }

            // Provide facility and issue designators in nibbles as expectd by legacy systems.
            // Check if facility designator can be converted into nibbles.
            if ((config.Designators.Facility % 4) != 0)
            {
                throw new ArgumentException("Configuration facility designator cannot be converted into nibbles.");
            }
            this.Data[cfgOffset + 8] = (byte)((config.Designators.Facility / 4) & 0x0F);
            // Check if issue designator can be converted into nibbles.
            if ((config.Designators.Issue % 4) != 0)
            {
                throw new ArgumentException("Configuration issue designator cannot be converted into nibbles.");
            }
            this.Data[cfgOffset + 8] |= (byte)(((config.Designators.Issue / 4) << 4) & 0xF0);

            this.Data[cfgOffset + 9] = (byte)(config.StrikeDuration);

            this.Data[cfgOffset + 10] = (byte)(config.EmbarrassmentTimer);

            this.Data[cfgOffset + 11] = (byte)(config.AcceptLedFlashTime & 0x07);
            if (config.AcceptLedFlashEnabled == true)
            {
                this.Data[cfgOffset + 11] |= 0x08;
            }

            this.Data[cfgOffset + 12] = (byte)(config.DeniedLedFlashTime & 0x07);
            if (config.DeniedLedFlashEnabled == true)
            {
                this.Data[cfgOffset + 12] |= 0x08;
            }

            this.Data[cfgOffset + 13] = (byte)(config.InvalidLedFlashTime & 0x07);
            if (config.InvalidLedFlashEnabled == true)
            {
                this.Data[cfgOffset + 13] |= 0x08;
            }
            switch (config.InvalidBuzzer)
            {
                case CardReaderBuzzerType.BuzzerOff:
                    break;
                case CardReaderBuzzerType.BuzzerOn:
                    this.Data[cfgOffset + 13] |= 0x10;
                    break;
                case CardReaderBuzzerType.BuzzerPulse:
                    this.Data[cfgOffset + 13] |= 0x20;
                    break;
            }

            this.Data[cfgOffset + 14] = (byte)(config.ContactHitCount & 0x0F);
            this.Data[cfgOffset + 14] |= (byte)((config.EgressHitCount & 0x0F) << 4);

            this.Data[cfgOffset + 15] = (byte)(config.StrikeHitCount & 0x0F);
            if (config.StrikeRelayNormallyClosed == true)
            {
                this.Data[cfgOffset + 15] |= 0x10;
            }
            if (config.ContactNegative == true)
            {
                this.Data[cfgOffset + 15] |= 0x20;
            }
            if (config.EgressNegative == true)
            {
                this.Data[cfgOffset + 15] |= 0x40;
            }
            if (config.StrikeNegative == true)
            {
                this.Data[cfgOffset + 15] |= 0x80;
            }

            this.Data[cfgOffset + 16] = 0;
            this.Data[cfgOffset + 16] |= (byte)(config.KeypadInactivityTimer & 0x0F);
            this.Data[cfgOffset + 16] |= (byte)((config.KeypadNoDigitsToEnter & 0x07) << 4);
            if (config.KeypadSendKeyWithPin == true)
            {
                this.Data[cfgOffset + 16] |= 0x80;
            }
  
            this.Data[cfgOffset + 17] = config.BeeperDuration;


            this.Data[cfgOffset + 18] = 0;
            switch (config.AcceptBuzzer)
            {
                case CardReaderBuzzerType.BuzzerOff:
                    break;
                case CardReaderBuzzerType.BuzzerOn:
                    this.Data[cfgOffset + 18] |= 0x01;
                    break;
                case CardReaderBuzzerType.BuzzerPulse:
                    this.Data[cfgOffset + 18] |= 0x02;
                    break;
            }
            switch (config.DeniedBuzzer)
            {
                case CardReaderBuzzerType.BuzzerOff:
                    break;
                case CardReaderBuzzerType.BuzzerOn:
                    this.Data[cfgOffset + 18] |= 0x10;
                    break;
                case CardReaderBuzzerType.BuzzerPulse:
                    this.Data[cfgOffset + 18] |= 0x20;
                    break;
            }

            this.Data[cfgOffset + 19] = 0;
            if (config.ProcessEgressLocally == true)
            {
                this.Data[cfgOffset + 19] |= 0x01;
            }
            if (config.EgressShuntOnly == true)
            {
                this.Data[cfgOffset + 19] |= 0x02;
            }
            if (config.StoreCodeLocally == true)
            {
                this.Data[cfgOffset + 19] |= 0x04;
            }
            if (config.KeepStrikeDuringEgress == true)
            {
                this.Data[cfgOffset + 19] |= 0x08;
            }
            if (config.AllowPinOnly == true)
            {
                this.Data[cfgOffset + 19] |= 0x10;
            }
            if (config.InterlockPassback == true)
            {
                this.Data[cfgOffset + 19] |= 0x20;
            }
            if (config.ResetUserInOut == true)
            {
                this.Data[cfgOffset + 19] |= 0x40;
            }
            if (config.EnableTimeInAttend == true)
            {
                this.Data[cfgOffset + 19] |= 0x80;
            }
            this.Data[cfgOffset + 20] = 0;
            if (config.SupervisedEgressInput == true)
            {
                this.Data[cfgOffset + 20] |= 0x01;
            }
        }

        private ReaderInitializationConfig parseInitializationCommand()
        {
            int cfgOffset = this.Offset + 1;

            // Card reader type
            ReaderInitializationConfig config = new ReaderInitializationConfig();
            config.ReaderType = (CardReaderType)Enum.Parse(typeof(CardReaderType), this.Data[cfgOffset].ToString(), true);

            // Facility
            switch ((this.Data[cfgOffset + 1] & 0xC0) >> 6)
            {
                case 0:
                    config.Facility.UnitType = CardConfigFieldType.NotUsed;
                    config.Facility.Length = 0;
                    config.Facility.ZeroBasedOffset = 0;
                    config.Facility.IncludeInMask = false;
                    break;
                case 1: // InBits
                    config.Facility.UnitType = CardConfigFieldType.InBits;
                    config.Facility.Length = (byte)(this.Data[cfgOffset + 1] & 0x3F);
                    config.Facility.ZeroBasedOffset = ((this.Data[cfgOffset + 2] & 0x7F) - 1);
                    config.Facility.IncludeInMask = ((this.Data[cfgOffset + 2] & 128) == 128);
                    break;
                case 2: // InNibbles
                    config.Facility.UnitType = CardConfigFieldType.InBits;
                    config.Facility.Length = (byte)((this.Data[cfgOffset + 1] & 0x3F) * 4);
                    config.Facility.ZeroBasedOffset = (((this.Data[cfgOffset + 2] & 0x7F) - 1) * 4);
                    config.Facility.IncludeInMask = ((this.Data[cfgOffset + 2] & 128) == 128);
                    break;
                case 3: // InBytes
                    config.Facility.UnitType = CardConfigFieldType.InBits;
                    config.Facility.Length = (byte)((this.Data[cfgOffset + 1] & 0x3F) * 8);
                    config.Facility.ZeroBasedOffset = (((this.Data[cfgOffset + 2] & 0x7F) - 1) * 8);
                    config.Facility.IncludeInMask = ((this.Data[cfgOffset + 2] & 128) == 128);
                    break;
            }
            // Issue
            switch ((this.Data[cfgOffset + 3] & 0xC0) >> 6)
            {
                case 0:
                    config.Issue.UnitType = CardConfigFieldType.NotUsed;
                    config.Issue.Length = 0;
                    config.Issue.ZeroBasedOffset = 0;
                    config.Issue.IncludeInMask = false;
                    break;
                case 1: // InBits
                    config.Issue.UnitType = CardConfigFieldType.InBits;
                    config.Issue.Length = (byte)(this.Data[cfgOffset + 3] & 0x3F);
                    config.Issue.ZeroBasedOffset = ((this.Data[cfgOffset + 4] & 0x7F) - 1);
                    config.Issue.IncludeInMask = ((this.Data[cfgOffset + 4] & 128) == 128);
                    break;
                case 2: // InNibbles
                    config.Issue.UnitType = CardConfigFieldType.InBits;
                    config.Issue.Length = (byte)((this.Data[cfgOffset + 3] & 0x3F) * 4);
                    config.Issue.ZeroBasedOffset = (((this.Data[cfgOffset + 4] & 0x7F) - 1) * 4);
                    config.Issue.IncludeInMask = ((this.Data[cfgOffset + 4] & 128) == 128);
                    break;
                case 3: // InBytes
                    config.Issue.UnitType = CardConfigFieldType.InBits;
                    config.Issue.Length = (byte)((this.Data[cfgOffset + 3] & 0x3F) * 8);
                    config.Issue.ZeroBasedOffset = (((this.Data[cfgOffset + 4] & 0x7F) - 1) * 8);
                    config.Issue.IncludeInMask = ((this.Data[cfgOffset + 4] & 128) == 128);
                    break;
            }
            // Code
            switch ((this.Data[cfgOffset + 5] & 0xC0) >> 6)
            {
                case 0:
                    config.Code.UnitType = CardConfigFieldType.NotUsed;
                    config.Code.Length = 0;
                    config.Code.ZeroBasedOffset = 0;
                    config.Code.IncludeInMask = false;
                    break;
                case 1: // InBits
                    config.Code.UnitType = CardConfigFieldType.InBits;
                    config.Code.Length = (byte)(this.Data[cfgOffset + 5] & 0x3F);
                    config.Code.ZeroBasedOffset = ((this.Data[cfgOffset + 6] & 0x7F) - 1);
                    config.Code.IncludeInMask = ((this.Data[cfgOffset + 6] & 128) == 128);
                    break;
                case 2: // InNibbles
                    config.Code.UnitType = CardConfigFieldType.InBits;
                    config.Code.Length = (byte)((this.Data[cfgOffset + 5] & 0x3F) * 4);
                    config.Code.ZeroBasedOffset = (((this.Data[cfgOffset + 6] & 0x7F) - 1) * 4);
                    config.Code.IncludeInMask = ((this.Data[cfgOffset + 6] & 128) == 128);
                    break;
                case 3: // InBytes
                    config.Code.UnitType = CardConfigFieldType.InBits;
                    config.Code.Length = (byte)((this.Data[cfgOffset + 5] & 0x3F) * 8);
                    config.Code.ZeroBasedOffset = (((this.Data[cfgOffset + 6] & 0x7F) - 1) * 8);
                    config.Code.IncludeInMask = ((this.Data[cfgOffset + 6] & 128) == 128);
                    break;
            }

            // SPEC485 byte 7            
            // Unit type for facility designator is in nibbles, it will be converted to bits here;
            config.Designators.Facility = (byte)(this.Data[cfgOffset + 7] & 0x0F) * 4;
            // Unit type for issue designator is in nibbles, it will be converted to bits here.
            config.Designators.Issue = (byte)((this.Data[cfgOffset + 7] & 0xF0) >> 4) * 4;

            // SPEC485 byte 8
            config.StrikeDuration = (byte)this.Data[cfgOffset + 8];

            // SPEC485 byte 9
            config.EmbarrassmentTimer = this.Data[cfgOffset + 9];

            // SPEC485 byte 10
            config.AcceptLedFlashTime = (byte)(this.Data[cfgOffset + 10] & 0x07);
            config.AcceptLedFlashEnabled = ((this.Data[cfgOffset + 10] & 0x08) == 0x08);

            // SPEC485 byte 11
            config.DeniedLedFlashTime = (byte)(this.Data[cfgOffset + 11] & 0x07);
            config.DeniedLedFlashEnabled = ((this.Data[cfgOffset + 11] & 0x08) == 0x08);

            // SPEC485 byte 12            
            config.InvalidLedFlashTime = (byte)(this.Data[cfgOffset + 12] & 0x07);
            config.InvalidLedFlashEnabled = ((this.Data[cfgOffset + 12] & 0x08) == 0x08);
            switch ((this.Data[cfgOffset + 12] & 0x30) >> 4)
            {
                case 0: config.InvalidBuzzer = CardReaderBuzzerType.BuzzerOff; break;
                case 1: config.InvalidBuzzer = CardReaderBuzzerType.BuzzerOn; break;
                case 2: config.InvalidBuzzer = CardReaderBuzzerType.BuzzerPulse; break;
            }

            // SPEC485 byte 13
            config.ContactHitCount = (byte)(this.Data[cfgOffset + 13] & 0x0F);
            config.EgressHitCount = (byte)((this.Data[cfgOffset + 13] & 0xF0) >> 4);

            // SPEC485 byte 14
            config.StrikeHitCount = (byte)(this.Data[cfgOffset + 14] & 0x0F);
            config.StrikeRelayNormallyClosed = ((this.Data[cfgOffset + 14] & 0x10) == 0x10);
            config.ContactNegative = ((this.Data[cfgOffset + 14] & 0x20) == 0x20);
            config.EgressNegative = ((this.Data[cfgOffset + 14] & 0x40) == 0x40);
            config.StrikeNegative = ((this.Data[cfgOffset + 14] & 0x80) == 0x80);

            // SPEC485 byte 15
            config.KeypadInactivityTimer = (byte)(this.Data[cfgOffset + 15] & 0x0F);
            config.KeypadNoDigitsToEnter = (byte)((this.Data[cfgOffset + 15] & 0x70) >> 4);
            config.KeypadSendKeyWithPin = (this.Data[cfgOffset + 15] & 0x80) == 0x80;

            // SPEC485 byte 16 - Beeper duration. Skipped from implementation.
            config.BeeperDuration = this.Data[cfgOffset + 16];

            // SPEC485 byte 17
            switch (this.Data[cfgOffset + 17] & 0x03)
            {
                case 0: config.AcceptBuzzer = CardReaderBuzzerType.BuzzerOff; break;
                case 1: config.AcceptBuzzer = CardReaderBuzzerType.BuzzerOn; break;
                case 2: config.AcceptBuzzer = CardReaderBuzzerType.BuzzerPulse; break;
            }
            switch ((this.Data[cfgOffset + 17] & 0x0C) >> 2)
            {
                case 0: config.DeniedBuzzer = CardReaderBuzzerType.BuzzerOff; break;
                case 1: config.DeniedBuzzer = CardReaderBuzzerType.BuzzerOn; break;
                case 2: config.DeniedBuzzer = CardReaderBuzzerType.BuzzerPulse; break;
            }

            // Flags SPEC485 byte 18.
            config.ProcessEgressLocally = (this.Data[cfgOffset + 18] & 0x01) == 0x01;
            config.EgressShuntOnly = (this.Data[cfgOffset + 18] & 0x02) == 0x02;
            config.StoreCodeLocally = (this.Data[cfgOffset + 18] & 0x04) == 0x04;
            config.KeepStrikeDuringEgress = (this.Data[cfgOffset + 18] & 0x08) == 0x08;
            config.AllowPinOnly = (this.Data[cfgOffset + 18] & 0x10) == 0x10;
            config.InterlockPassback = (this.Data[cfgOffset + 18] & 0x20) == 0x20;
            config.ResetUserInOut = (this.Data[cfgOffset + 18] & 0x40) == 0x40;
            config.EnableTimeInAttend = (this.Data[cfgOffset + 18] & 0x80) == 0x80;

            // Make sure command extansion does not break existing systems. 
            // There is 20 bytes of the legacy initialization. Includes function number.
            if (this.Length > 20)
            {
                // Flags byte 19 - none legacy
                config.SupervisedEgressInput = (this.Data[cfgOffset + 19] & 0x01) == 0x01;
            }

            return config;
        }

        public override string ToString()
        {
            CardReaderPortType readerNumber;
            ReaderInitializationConfig config;
            GetConfiguration(out readerNumber, out config);
            if (config == null)
                return string.Format("Initialize Card Reader. Interface: {0}, ReaderType: {1}", "N/A");
            else
                return string.Format("Initialize Card Reader. Interface: {0}, ReaderType: {1}, StrikeDuration: {2}, ProcessEgressLocally: {3}",
                    readerNumber.ToString(), config.ReaderType.ToString(), config.StrikeDuration, config.ProcessEgressLocally);
        }

#if COMMUNICATIONSANALYZER

        public CardReaderInitializeCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { 
                CardReaderInitializeCommandReader1FunctionCode,
                CardReaderInitializeCommandReader2FunctionCode
            }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
