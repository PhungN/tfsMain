﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    public class CardReaderSetNewCodeMaskCommand : DeviceLoopMessageBase
    {
        public const int CardReaderSetNewCodeMaskCommandReader1FunctionCode = 36;
        public const int CardReaderSetNewCodeMaskCommandReader2FunctionCode = 37;

        public CardReaderSetNewCodeMaskCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 33)
        {
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public CardReaderSetNewCodeMaskCommand(CardReaderPortType readerNumber, CardFormatMasksConfig config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            this.Data = new byte[33];
            switch (readerNumber)
            {
                case CardReaderPortType.CardReader1:
                    this.FunctionCode = CardReaderSetNewCodeMaskCommandReader1FunctionCode;
                    break;
                case CardReaderPortType.CardReader2:
                    this.FunctionCode = CardReaderSetNewCodeMaskCommandReader2FunctionCode;
                    break;
                default:
                    throw new ArgumentException("Invalid reader number.");
            }

            byte[] configData = config.Data;
            if(configData != null)
                Array.Copy(configData, 0, this.Data, 1, Math.Min(configData.Length, 32));
            this.Length = this.Data.Length;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public bool GetConfiguration(out CardReaderPortType readerNumber, out CardFormatMasksConfig config)
        {
            if (this.Data.Length < 33)
            {
                readerNumber = CardReaderPortType.NoReader;
                config = null;
                return false;
            }
            switch (this.Data[this.Offset])
            {
                case CardReaderSetNewCodeMaskCommandReader1FunctionCode:
                    readerNumber = CardReaderPortType.CardReader1;
                    break;
                case CardReaderSetNewCodeMaskCommandReader2FunctionCode:
                    readerNumber = CardReaderPortType.CardReader2;
                    break;
                default:
                    readerNumber = CardReaderPortType.NoReader;
                    config = null;
                    return false;
            }

            config = new CardFormatMasksConfig(Data, Offset + 1);
            return config != null;
        }

        public override string ToString()
        {
            return "Set Card Reader Format Code Masks Configuration";
        }

#if COMMUNICATIONSANALYZER

        public CardReaderSetNewCodeMaskCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] {
                CardReaderSetNewCodeMaskCommandReader1FunctionCode,
                CardReaderSetNewCodeMaskCommandReader2FunctionCode
            }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
