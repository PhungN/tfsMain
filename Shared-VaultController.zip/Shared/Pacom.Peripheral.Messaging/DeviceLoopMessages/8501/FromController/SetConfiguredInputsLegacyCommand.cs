﻿
namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{

    // This is a bit mask of the inputs that are defined for an IO device:
    // 21 , BITS_1 , ... ,BITS_N
    // BITS_1...BITS_N = A value of 1 is set for each defined input
    public class SetConfiguredInputsLegacyCommand : DeviceLoopMessageBase
    {
        public const int SetConfiguredInputsLegacyCommandFunctionCode = 21;

        public SetConfiguredInputsLegacyCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public SetConfiguredInputsLegacyCommand(bool[] configuredInputs)
        {
            int bytesRequired = configuredInputs.Length / 8;
            if (configuredInputs.Length != 0 && (configuredInputs.Length % 8) > 0)
                bytesRequired++;

            Data = new byte[1 + bytesRequired];
            FunctionCode = SetConfiguredInputsLegacyCommandFunctionCode;

            for (int byteIndex = 0; byteIndex < bytesRequired; byteIndex++)
            {
                byte configuredBitField = 0;
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    int arrayIndex = (byteIndex * 8) + bitIndex;
                    if (configuredInputs.Length <= arrayIndex)
                        break;

                    if (configuredInputs[arrayIndex])
                        configuredBitField |= (byte)(1 << bitIndex);
                }
                Data[byteIndex + 1] = configuredBitField;
            }

            Length = Data.Length;
        }

        public void GetConfiguredInputs(out bool[] configuredInputs)
        {
            configuredInputs = new bool[(Length - 1) * 8];

            for (int byteIndex = 0; byteIndex < (Length - 1); byteIndex++)
            {
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    int arrayIndex = (byteIndex * 8) + bitIndex;
                    if ((Data[Offset + byteIndex + 1] & (byte)(1 << bitIndex)) == 0)
                        configuredInputs[arrayIndex] = false;
                    else
                        configuredInputs[arrayIndex] = true;
                }
            }
        }

        public override string ToString()
        {
            bool[] configuredInputs;
            GetConfiguredInputs(out configuredInputs);

            string configuredInputsString = "";
            for (int i = 0; i < configuredInputs.Length; i++)
            {
                if (i > 0)
                    configuredInputsString += "-";
                if (configuredInputs[i])
                    configuredInputsString += "1";
                else
                    configuredInputsString += "0";
            }

            return "Set Configured Inputs (" + configuredInputsString + ")";
        }

#if COMMUNICATIONSANALYZER

        public SetConfiguredInputsLegacyCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetConfiguredInputsLegacyCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
