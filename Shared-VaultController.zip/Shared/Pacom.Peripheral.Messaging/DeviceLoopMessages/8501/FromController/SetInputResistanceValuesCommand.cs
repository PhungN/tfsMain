﻿using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // This message defines the value for one of the input resistance values for all inputs for an IO device.
    // The currently defined resistance values are: Secure, Alarm, Masking and Range Reduction
    // 50, OWNERTYPE, RESISTANCEVALUETYPE, STARTINGPOINT, NUMBEROFINPUTS, RES_1 , ... , RES_N
    // OWNERTYPE = Onboard, Expansion1, Expansion2, ... as defined in Common.OwnerType enumerator
    // STARTINGPOINT = 0, 1, 2, 3, ... N =  Starting point number on the owning device
    // NUMBEROFINPUTS = number of inputs to look at in the message
    // RES_1...RES_N = resistance values for all defined inputs. One byte per resistance value (0 - 25K4 Ohm, in 100 Ohm increments, 255 means analog input)
    public class SetInputResistanceValuesCommand : DeviceLoopMessageBase
    {
        public const int SetInputResistanceValuesCommandFunctionCode = 50;

        /// <summary>
        /// Single byte for number of inputs.
        /// </summary>
        public const int NumberOfInputsSize = 1;

        /// <summary>
        /// Single byte for number of inputs.
        /// </summary>
        public const int ResistanceValueTypeSize = 1;

        public SetInputResistanceValuesCommand(byte[] data, int offset, int length)
            : base(data, offset, length, FunctionCodeSize + OwnerTypeSize + ResistanceValueTypeSize + StartingPointSize + NumberOfInputsSize + 1 /* Min one byte */)
        {
            if (Enum.IsDefined(typeof(OwnerType), (int)Data[Offset + FunctionCodeSize]) == false)
                throw new ArgumentException("Data is invalid.", "data");
        }

        /// <summary>
        /// Return maximum number of data parts (int types in an array) for this message.
        /// </summary>
        public const int MaximumDataLength = (MaximumDataBytesFromController - (FunctionCodeSize + OwnerTypeSize + ResistanceValueTypeSize + 
                                                                                StartingPointSize + NumberOfInputsSize));

        public SetInputResistanceValuesCommand(OwnerType ownerType, ResistanceValueType resistanceType, int startingPoint, int[] resistanceValues)
        {
            int bytesRequiredForData = resistanceValues.Length;
            bytesRequiredForData = Math.Min(bytesRequiredForData, MaximumDataLength);

            Data = new byte[FunctionCodeSize + OwnerTypeSize + ResistanceValueTypeSize + StartingPointSize + NumberOfInputsSize + bytesRequiredForData];
            FunctionCode = SetInputResistanceValuesCommandFunctionCode;

            Data[OwnerTypeSize] = (byte)ownerType;
            Data[OwnerTypeSize + ResistanceValueTypeSize] = (byte)resistanceType;
            Data[OwnerTypeSize + ResistanceValueTypeSize + StartingPointSize] = (byte)startingPoint;
            Data[OwnerTypeSize + ResistanceValueTypeSize + StartingPointSize + NumberOfInputsSize] = (byte)resistanceValues.Length;

            for (int byteIndex = 0; byteIndex < bytesRequiredForData; byteIndex++)
            {
                Data[FunctionCodeSize + OwnerTypeSize + ResistanceValueTypeSize + StartingPointSize + NumberOfInputsSize + byteIndex] = (byte)(resistanceValues[byteIndex] / 100);
            }
            Length = Data.Length;
        }

        public void GetResistanceValues(out OwnerType ownerType, out ResistanceValueType resistanceType, out int startingPoint, out int[] resistanceValues)
        {
            ownerType = (OwnerType)Data[Offset + FunctionCodeSize];
            resistanceType = (ResistanceValueType)Data[Offset + FunctionCodeSize + OwnerTypeSize];
            startingPoint = Data[Offset + FunctionCodeSize + OwnerTypeSize + ResistanceValueTypeSize];
            int numberOfInputs = Data[Offset + FunctionCodeSize + OwnerTypeSize + ResistanceValueTypeSize + StartingPointSize];
            resistanceValues = new int[numberOfInputs];

            for (int byteIndex = 0; byteIndex < (Length - (FunctionCodeSize + OwnerTypeSize + ResistanceValueTypeSize + StartingPointSize + NumberOfInputsSize)); byteIndex++)
            {
                resistanceValues[byteIndex] = Data[Offset + FunctionCodeSize + OwnerTypeSize + ResistanceValueTypeSize + StartingPointSize + NumberOfInputsSize + byteIndex] * 100;
            }
        }

        public override string ToString()
        {
            OwnerType ownerType;
            ResistanceValueType resistanceType;
            int startingPoint;
            int[] resistanceValues;
            GetResistanceValues(out ownerType, out resistanceType, out startingPoint, out resistanceValues);

            StringBuilder descString = new StringBuilder();
            descString.Append("Set Inputs Resistance Values, Owner:");
            descString.Append(ownerType.ToString());
            descString.Append(", ResistanceType:");
            descString.Append(resistanceType.ToString());
            descString.Append(", StartingPoint:");
            descString.Append(startingPoint.ToString());
            descString.Append(", NumberOfInputs:");
            descString.Append(resistanceValues.Length.ToString());
            descString.Append(" (");
            for (int i = 0; i < resistanceValues.Length; i++)
            {
                if (i > 0)
                    descString.Append("-");
                if (resistanceValues[i] > 1000)
                    descString.Append(((int)(resistanceValues[i] / 1000)).ToString() + "K" + ((int)(resistanceValues[i] % 1000)).ToString());
                else
                    descString.Append(resistanceValues[i].ToString() + " Ohm");
            }
            descString.Append(")");
            return descString.ToString();
        }

#if COMMUNICATIONSANALYZER

        public SetInputResistanceValuesCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetInputResistanceValuesCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return "Set Inputs Resistance Values";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
