﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // The 16 input expansion alarm unit will maintain a log of errors that it detects.
    // These can be accessed with this command.  The command format is:
    // 4
    public class RequestErrorCountsCommand : DeviceLoopMessageBase
    {
        public const int RequestErrorCountsCommandFunctionCode = 4;

        public RequestErrorCountsCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public RequestErrorCountsCommand()
        {
            Data = new byte[1];
            FunctionCode = RequestErrorCountsCommandFunctionCode;

            Length = 1;
        }

        public override string ToString()
        {
            return "Request Error Counts";
        }

#if COMMUNICATIONSANALYZER

        // Default constructor already defined

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { RequestErrorCountsCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
