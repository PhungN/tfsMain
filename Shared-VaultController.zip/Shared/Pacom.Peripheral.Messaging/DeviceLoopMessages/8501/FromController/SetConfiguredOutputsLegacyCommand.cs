﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // This is a bit mask of the outputs that are defined for an output device:
    // 22 , BITS_1 , ... ,BITS_N
    // BITS_1...BITS_N = A value of 1 is set for each defined output
    public class SetConfiguredOutputsLegacyCommand : DeviceLoopMessageBase
    {
        public const int SetConfiguredOutputsLegacyCommandFunctionCode = 22;

        public SetConfiguredOutputsLegacyCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public SetConfiguredOutputsLegacyCommand(bool[] configuredOutputs)
        {
            int bytesRequired = configuredOutputs.Length / 8;
            if (configuredOutputs.Length != 0 && (configuredOutputs.Length % 8) > 0)
                bytesRequired++;

            Data = new byte[1 + bytesRequired];
            FunctionCode = SetConfiguredOutputsLegacyCommandFunctionCode;

            for (int byteIndex = 0; byteIndex < bytesRequired; byteIndex++)
            {
                byte configuredBitField = 0;
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    int arrayIndex = (byteIndex * 8) + bitIndex;
                    if (configuredOutputs.Length <= arrayIndex)
                        break;

                    if (configuredOutputs[arrayIndex])
                        configuredBitField |= (byte)(1 << bitIndex);
                }
                Data[byteIndex + 1] = configuredBitField;
            }

            Length = Data.Length;
        }

        public void GetConfiguredOutputs(out bool[] configuredOutputs)
        {
            configuredOutputs = new bool[(Length - 1) * 8];

            for (int byteIndex = 0; byteIndex < (Length - 1); byteIndex++)
            {
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    int arrayIndex = (byteIndex * 8) + bitIndex;
                    if ((Data[Offset + byteIndex + 1] & (byte)(1 << bitIndex)) == 0)
                        configuredOutputs[arrayIndex] = false;
                    else
                        configuredOutputs[arrayIndex] = true;
                }
            }
        }

        public override string ToString()
        {
            bool[] configuredOutputs;
            GetConfiguredOutputs(out configuredOutputs);

            string configuredOutputsString = "";
            for (int i = 0; i < configuredOutputs.Length; i++)
            {
                if (i > 0)
                    configuredOutputsString += "-";
                if (configuredOutputs[i])
                    configuredOutputsString += "1";
                else
                    configuredOutputsString += "0";
            }

            return "Set Configured Outputs (" + configuredOutputsString + ")";
        }

#if COMMUNICATIONSANALYZER

        public SetConfiguredOutputsLegacyCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetConfiguredOutputsLegacyCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
