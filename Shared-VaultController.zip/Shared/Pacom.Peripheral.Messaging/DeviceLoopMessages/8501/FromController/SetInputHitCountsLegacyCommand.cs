﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // The 16 input expansion alarm unit allows different hit-counts for different inputs. These values can be downloaded to 16 input expansion alarm unit:
    // 07 , TAMP_HIT_CNT , HIT_CNT1 , ... , HIT_CNTN
    // TAMP_HIT_CNT = hit-count for trouble condition of the inputs, which is a global parameter for all the inputs on the device. 
    // HIT_CNT1...HIT_CNTN = hit-counts for inputs. A nibble for each input allows the hit-counts of upto 16.  N will be a multiple of 8, allowing for 16, 32 or 48 inputs.
    public class SetInputHitCountsLegacyCommand : DeviceLoopMessageBase
    {
        public const int SetInputHitCountsLegacyCommandFunctionCode = 7;

        public SetInputHitCountsLegacyCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 2)
        {
        }

        public SetInputHitCountsLegacyCommand(int tamperHitCount, int[] inputHitCounts)
        {
            Data = new byte[2 + (inputHitCounts.Length / 2)];
            Length = Data.Length;
            FunctionCode = SetInputHitCountsLegacyCommandFunctionCode;

            Data[1] = (byte)tamperHitCount;
            for (int i = 2; i < Length; i++)
            {
                int arrayIndex = (i - 2) * 2;
                if (inputHitCounts[arrayIndex] > 15)
                    inputHitCounts[arrayIndex] = 15;
                if (inputHitCounts[arrayIndex + 1] > 15)
                    inputHitCounts[arrayIndex + 1] = 15;
                Data[i] = (byte)((inputHitCounts[arrayIndex + 1] << 4) + inputHitCounts[arrayIndex]);
            }
        }

        public void GetInputHitCounts(out int[] inputHitCounts)
        {
            inputHitCounts = new int[(Length - 2) * 2];

            for (int i = 2; i < Length; i++)
            {
                int arrayIndex = (i - 2) * 2;
                inputHitCounts[arrayIndex] = Data[Offset + i] & 0x0F;
                inputHitCounts[arrayIndex + 1] = (Data[Offset + i] & 0xF0) >> 4;
            }
        }

        public int TamperHitCount
        {
            get
            {
                return Data[Offset + 1] & 0x0F;
            }
        }

        public override string ToString()
        {
            int tamperHitCount = TamperHitCount;
            int[] inputHitCounts;
            GetInputHitCounts(out inputHitCounts);

            string inputHitCountString = "";
            for (int i = 0; i < inputHitCounts.Length; i++)
            {
                if (i > 0)
                    inputHitCountString += "-";
                inputHitCountString += inputHitCounts[i].ToString();
            }

            return "Set Input Hit Count (Tamper: " + tamperHitCount + " Alarm:" + inputHitCountString + ")";
        }

#if COMMUNICATIONSANALYZER

        public SetInputHitCountsLegacyCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetInputHitCountsLegacyCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
