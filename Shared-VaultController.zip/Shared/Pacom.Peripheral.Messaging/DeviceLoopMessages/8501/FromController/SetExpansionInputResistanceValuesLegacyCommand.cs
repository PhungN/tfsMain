﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // The input expansion alarm unit allows different termination resistor values (between 0 ohm and 25K4 in steps of 100) for ALARM and SECURE conditions. These values can be downloaded to 16 input expansion alarm unit:
    // 20, PNT, ALM_1, SEC_1, ... , ALM_15, SEC_15
    // PNT = Point number to start from. It is 16 bit little endian.
    // ALM_1...ALM_16 = termination resistor value (in * 100 ohm) for ALARM condition
    // SEC_1...SEC_16 = termination resistor value (in * 100 ohm) for SECURE condition.
    public class SetExpansionInputResistanceValuesLegacyCommand : DeviceLoopMessageBase
    {
        public const int SetExpansionInputResistanceValuesLegacyCommandFunctionCode = 20;

        public SetExpansionInputResistanceValuesLegacyCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 5)
        {
        }

        public SetExpansionInputResistanceValuesLegacyCommand(int startingPointNumber, int[] alarmResistanceValues, int[] secureResistanceValues)
        {
            Data = new byte[3 + (alarmResistanceValues.Length * 2)];
            FunctionCode = SetExpansionInputResistanceValuesLegacyCommandFunctionCode;

            Data[1] = (byte)startingPointNumber;
            Data[2] = 0;
            for (int i = 0; i < alarmResistanceValues.Length; i++)
            {
                Data[3 + (i * 2)] = (byte)(alarmResistanceValues[i] / 100);
                Data[4 + (i * 2)] = (byte)(secureResistanceValues[i] / 100);
            }

            Length = Data.Length;
        }

        public int StartingPointNumber
        {
            get
            {
                return Data[Offset + 1];
            }
        }

        public void GetResistanceValues(out int[] alarmResistanceValues, out int[] secureResistanceValues)
        {
            alarmResistanceValues = new int[(Length - 3) / 2];
            secureResistanceValues = new int[alarmResistanceValues.Length];

            for (int i = 0; i < alarmResistanceValues.Length; i++)
            {
                alarmResistanceValues[i] = Data[Offset + 3 + (i * 2)] * 100;
                secureResistanceValues[i] = Data[Offset + 4 + (i * 2)] * 100;
            }
        }

        public override string ToString()
        {
            string temp = "";
            int[] alarmResistanceValues;
            int[] secureResistanceValues;
            GetResistanceValues(out alarmResistanceValues, out secureResistanceValues);

            for (int i = 0; i < alarmResistanceValues.Length; i++)
            {
                string alarmResistanceString = "";
                string secureResistanceString = "";

                if (alarmResistanceValues[i] > 1000)
                    alarmResistanceString = ((int)(alarmResistanceValues[i] / 1000)).ToString() + "K" + ((int)(alarmResistanceValues[i] % 1000)).ToString();
                else
                    alarmResistanceString = alarmResistanceValues[i].ToString() + " Ohm";
                if (secureResistanceValues[i] > 1000)
                    secureResistanceString = ((int)(secureResistanceValues[i] / 1000)).ToString() + "K" + ((int)(secureResistanceValues[i] % 1000)).ToString();
                else
                    secureResistanceString = secureResistanceValues[i].ToString() + " Ohm";

                if (i != 0)
                    temp += ", ";
                temp += "Alarm = " + alarmResistanceString + " Secure = " + secureResistanceString;
            }

            return "Set On-Board Resistance Values (Starting point number = " + StartingPointNumber.ToString() + " - " + temp + ")";
        }

#if COMMUNICATIONSANALYZER

        public SetExpansionInputResistanceValuesLegacyCommand()
        { 
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetExpansionInputResistanceValuesLegacyCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return "Set On-Board Resistance Values";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
