﻿using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // This message defines the resolution for analog inputs for an IO device.
    // The currently defined resistance values are: Secure, Alarm, Masking and Range Reduction
    // 52, OWNERTYPE, STARTINGPOINT, NUMBEROFINPUTS, RES_1 , ... , RES_N
    // OWNERTYPE = Onboard, Expansion1, Expansion2, ... as defined in Common.OwnerType enumerator
    // STARTINGPOINT = 0, 1, 2, 3, ... N =  Starting point number on the owning device
    // NUMBEROFINPUTS = number of inputs to look at in the message
    // RES_1...RES_N = resolutions for anolog input.
    public class SetResolutionForAnalogInputsCommand : DeviceLoopMessageBase
    {
        public const int SetResolutionForAnalogInputsCommandFunctionCode = 52;

        /// <summary>
        /// Single byte for number of inputs.
        /// </summary>
        public const int NumberOfInputsSize = 1;

        public SetResolutionForAnalogInputsCommand(byte[] data, int offset, int length)
            : base(data, offset, length, FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + 1 /* Min one byte */)
        {
            if (Enum.IsDefined(typeof(OwnerType), (int)Data[Offset + FunctionCodeSize]) == false)
                throw new ArgumentException("Data is invalid.", "data");
        }

        /// <summary>
        /// Return maximum number of data parts (int types in an array) for this message.
        /// </summary>
        public const int MaximumDataLength = (MaximumDataBytesFromController - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize));

        public SetResolutionForAnalogInputsCommand(OwnerType ownerType, int startingPoint, int[] analogInputResolutions)
        {
            int bytesRequiredForData = analogInputResolutions.Length;
            bytesRequiredForData = Math.Min(bytesRequiredForData, MaximumDataLength);

            Data = new byte[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + bytesRequiredForData];
            FunctionCode = SetResolutionForAnalogInputsCommandFunctionCode;

            Data[OwnerTypeSize] = (byte)ownerType;
            Data[OwnerTypeSize + StartingPointSize] = (byte)startingPoint;
            Data[OwnerTypeSize + StartingPointSize + NumberOfInputsSize] = (byte)analogInputResolutions.Length;

            for (int byteIndex = 0; byteIndex < bytesRequiredForData; byteIndex++)
            {
                Data[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + byteIndex] = (byte)analogInputResolutions[byteIndex];
            }
            Length = Data.Length;
        }

        public void GetAnalogInputsResolutionValue(out OwnerType ownerType, out int startingPoint, out int[] analogInputResolutions)
        {
            ownerType = (OwnerType)Data[Offset + FunctionCodeSize];
            startingPoint = Data[Offset + FunctionCodeSize + OwnerTypeSize];
            int numberOfInputs = Data[Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize];
            analogInputResolutions = new int[numberOfInputs];

            for (int byteIndex = 0; byteIndex < (Length - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize)); byteIndex++)
            {
                byte data = Data[Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfInputsSize + byteIndex];
                analogInputResolutions[byteIndex] = data;
            }
        }

        public override string ToString()
        {
            OwnerType ownerType;
            int startingPoint;
            int[] analogInputResolutions;
            GetAnalogInputsResolutionValue(out ownerType, out startingPoint, out analogInputResolutions);

            StringBuilder descString = new StringBuilder();
            descString.Append("Set Analog Input Resolution, Owner:");
            descString.Append(ownerType.ToString());
            descString.Append(", StartingPoint:");
            descString.Append(startingPoint.ToString());
            descString.Append(", NumberOfInputs:");
            descString.Append(analogInputResolutions.Length.ToString());
            descString.Append(" (");
            for (int i = 0; i < analogInputResolutions.Length; i++)
            {
                if (i > 0)
                    descString.Append("-");
                descString.Append(analogInputResolutions[i]);
            }
            descString.Append(")");
            return descString.ToString();
        }

#if COMMUNICATIONSANALYZER

        public SetResolutionForAnalogInputsCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetResolutionForAnalogInputsCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return "Set Analog Input Resolution";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
