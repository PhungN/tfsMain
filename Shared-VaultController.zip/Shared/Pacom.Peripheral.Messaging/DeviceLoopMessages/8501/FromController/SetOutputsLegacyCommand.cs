﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // The output relays, upto 21 in the case of the 16 input expansion alarm unit, can be turned on or off.  
    // The message format is:
    // 02 , RLYS_1 , ... , RLYS_N
    // The bytes RLYS_1 to RLYS_N are bit maps, each byte controlling eight relays.
    // If a bit is set the relay is turned on. If it is clear the relay is turned off. 
    // RLYS_1: bit 0 to 4 controlling relays one to five on main board.
    // RLYS_2 and RLYS_3 controlling remaining relays on the mezzanine boards.
    public class SetOutputsLegacyCommand : DeviceLoopMessageBase
    {
        public const int SetOutputsLegacyCommandFunctionCode = 2;

        public SetOutputsLegacyCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 2)
        {
        }

        public SetOutputsLegacyCommand(bool[] onboardOutputs, bool[] expansionOutputs)
        {
            int numberOfOnboardBytes = 1;
            int numberOfExpansionBytes = 0;

            if (expansionOutputs != null)
            {
                numberOfExpansionBytes = expansionOutputs.Length / 8;
                if (expansionOutputs.Length != 0 && (expansionOutputs.Length % 8) > 0)
                    numberOfExpansionBytes++;
            }

            Data = new byte[numberOfOnboardBytes + numberOfExpansionBytes + 1];
            FunctionCode = SetOutputsLegacyCommandFunctionCode;

            if (onboardOutputs != null)
            {
                byte temp = 0;
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    if (onboardOutputs.Length <= bitIndex)
                        break;
                    if (onboardOutputs[bitIndex] == true)
                        temp |= (byte)(1 << bitIndex);
                }
                Data[1] = temp;
            }
            if (expansionOutputs != null)
            {
                for (int byteIndex = 0; byteIndex < numberOfExpansionBytes; byteIndex++)
                {
                    byte temp = 0;
                    for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                    {
                        int arrayIndex = bitIndex + (byteIndex * 8);
                        if (expansionOutputs.Length <= arrayIndex)
                            break;
                        if (expansionOutputs[arrayIndex] == true)
                            temp |= (byte)(1 << bitIndex);
                    }
                    Data[byteIndex + 1 + numberOfOnboardBytes] = temp;
                }
            }

            Length = Data.Length;
        }

        public void GetOutputStates(out bool[] onboardOutputs, out bool[] expansionOutputs)
        {
            onboardOutputs = new bool[8];
            expansionOutputs = new bool[(Length - 2) * 8];

            for (int bitIndex = 0; bitIndex < 8; bitIndex++)
            {
                if ((Data[Offset + 1] & (byte)(1 << bitIndex)) == 0)
                    onboardOutputs[bitIndex] = false;
                else
                    onboardOutputs[bitIndex] = true;
            }
            for (int byteIndex = 0; byteIndex < Length - 2; byteIndex++)
            {
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    int arrayIndex = bitIndex + (byteIndex * 8);
                    if ((Data[Offset + byteIndex + 2] & (byte)(1 << bitIndex)) == 0)
                        expansionOutputs[arrayIndex] = false;
                    else
                        expansionOutputs[arrayIndex] = true;
                }
            }
        }

        public override string ToString()
        {
            bool[] onboardOutputs;
            bool[] expansionOutputs;
            GetOutputStates(out onboardOutputs, out expansionOutputs);

            string onboardString = "";
            for (int i = 0; i < onboardOutputs.Length; i++)
            {
                if (i > 0)
                    onboardString += "-";
                if (onboardOutputs[i])
                    onboardString += "On";
                else
                    onboardString += "Off";
            }

            string expansionString = "";
            for (int i = 0; i < expansionOutputs.Length; i++)
            {
                if (i > 0)
                    expansionString += "-";
                if (expansionOutputs[i])
                    expansionString += "On";
                else
                    expansionString += "Off";
            }

            return "Set Outputs (Onboard: " + onboardString + " Expansion:" + expansionString + ")";
        }

#if COMMUNICATIONSANALYZER

        public SetOutputsLegacyCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetOutputsLegacyCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
