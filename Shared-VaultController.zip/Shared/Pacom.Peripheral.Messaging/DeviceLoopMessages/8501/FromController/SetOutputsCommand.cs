﻿using Pacom.Peripheral.Common;
using System;
using System.Text;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // This is a bit mask for turning ON/OFF 8501 outputs on board and on any of the configured expansion cards:
    // 53, OWNERTYPE, STARTINGPOINT, NUMBEROFOUTPUTS, BITS_1 , ... , BITS_N
    // OWNERTYPE = Tamper, Onboard, Expansion1, Expansion2, ... as defined in Common.OwnerType enumerator
    // STARTINGPOINT = 0, 1, 2, 3, ... N =  Starting point number on the owning device
    // NUMBEROFINPUTS = number of bits to look at in the message
    // BITS_1...BITS_N = A value of 1 is set for each defined input
    public class SetOutputsCommand : DeviceLoopMessageBase
    {
        public const int SetOutputsCommandFunctionCode = 53;

        /// <summary>
        /// Single byte for number of outputs.
        /// </summary>
        public const int NumberOfOutputsSize = 1;

        public SetOutputsCommand(byte[] data, int offset, int length)
            : base(data, offset, length, FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfOutputsSize + 1 /* Min one byte with one bit */)
        {
            if (Enum.IsDefined(typeof(OwnerType), (int)Data[Offset + FunctionCodeSize]) == false)
                throw new ArgumentException("Data is invalid.", "data");
        }

        /// <summary>
        /// Return maximum number of data parts (bool types in an array) for this message.
        /// </summary>
        public const int MaximumDataLength = (MaximumDataBytesFromController - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfOutputsSize)) * 8;

        public SetOutputsCommand(OwnerType owner, int startingPoint, bool[] outputsOnOff)
        {
            int bytesRequiredForData = outputsOnOff.Length / 8;
            if (outputsOnOff.Length != 0 && (outputsOnOff.Length % 8) > 0)
                bytesRequiredForData++;

            bytesRequiredForData = Math.Min(bytesRequiredForData, MaximumDataLength / 8);

            Data = new byte[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfOutputsSize + bytesRequiredForData];
            FunctionCode = SetOutputsCommandFunctionCode;

            Data[OwnerTypeSize] = (byte)owner;
            Data[OwnerTypeSize + StartingPointSize] = (byte)startingPoint;
            Data[OwnerTypeSize + StartingPointSize + NumberOfOutputsSize] = (byte)outputsOnOff.Length;

            for (int byteIndex = 0; byteIndex < bytesRequiredForData; byteIndex++)
            {
                byte configuredBitField = 0;
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    int arrayIndex = (byteIndex * 8) + bitIndex;
                    if (outputsOnOff.Length <= arrayIndex)
                        break;

                    if (outputsOnOff[arrayIndex])
                        configuredBitField |= (byte)(1 << bitIndex);
                }
                Data[FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfOutputsSize + byteIndex] = configuredBitField;
            }
            Length = Data.Length;
        }

        public void GetOutputStates(out OwnerType ownerType, out int startingPoint, out bool[] outputStates)
        {
            ownerType = (OwnerType)Data[Offset + FunctionCodeSize];
            startingPoint = Data[Offset + FunctionCodeSize + OwnerTypeSize];
            int numberOfOutputs = Data[Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize];
            outputStates = new bool[numberOfOutputs];

            for (int byteIndex = 0; byteIndex < (Length - (FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfOutputsSize)); byteIndex++)
            {
                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
                {
                    int arrayIndex = (byteIndex * 8) + bitIndex;
                    if (arrayIndex < numberOfOutputs)
                    {
                        if ((Data[Offset + FunctionCodeSize + OwnerTypeSize + StartingPointSize + NumberOfOutputsSize + byteIndex] & (byte)(1 << bitIndex)) == 0)
                            outputStates[arrayIndex] = false;
                        else
                            outputStates[arrayIndex] = true;
                    }
                }
            }
        }

        public override string ToString()
        {
            OwnerType ownerType;
            int startingPoint;
            bool[] outputStates;
            GetOutputStates(out ownerType, out startingPoint, out outputStates);

            StringBuilder descString = new StringBuilder();
            descString.Append("Set Outputs, Owner:");
            descString.Append(ownerType.ToString());
            descString.Append(", StartingPoint:");
            descString.Append(startingPoint.ToString());
            descString.Append(", NumberOfOutputs:");
            descString.Append(outputStates.Length.ToString());
            descString.Append(" (");
            for (int i = 0; i < outputStates.Length; i++)
            {
                if (i > 0)
                    descString.Append("-");
                if (outputStates[i])
                    descString.Append("On");
                else
                    descString.Append("Off");
            }
            descString.Append(")");
            return descString.ToString();
        }

#if COMMUNICATIONSANALYZER

        public SetOutputsCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetOutputsCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return "Set Outputs";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
