﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    public class CardReaderSetNewParityMaskCommand : DeviceLoopMessageBase
    {
        public const int CardReaderSetNewParityMaskCommandReader1FunctionCode = 38;
        public const int CardReaderSetNewParityMaskCommandReader2FunctionCode = 39;

        public CardReaderSetNewParityMaskCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 30)
        {
        }

        /// <summary>
        /// Construct message to device from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public CardReaderSetNewParityMaskCommand(CardReaderPortType readerNumber, CardFormatParityConfig config, int formatNumber)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            this.Data = new byte[30];
            switch (readerNumber)
            {
                case CardReaderPortType.CardReader1:
                    this.FunctionCode = CardReaderSetNewParityMaskCommandReader1FunctionCode;
                    break;
                case CardReaderPortType.CardReader2:
                    this.FunctionCode = CardReaderSetNewParityMaskCommandReader2FunctionCode;
                    break;
                default:
                    throw new ArgumentException("Invalid reader number.");
            }
            // Validate formt index
            if (formatNumber < 0 || formatNumber > 4)
            {
                throw new ArgumentException("Invalid format number.");
            }
            Data[1] = (byte)formatNumber;
            byte[] paritiyConfig = config.Data;
            if (paritiyConfig != null)
                Array.Copy(paritiyConfig, 0, Data, 2, Math.Min(paritiyConfig.Length, Data.Length - 2));
            this.Length = this.Data.Length;
        }

        /// <summary>
        /// Get processed configuration received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        /// <param name="formatNumber">Format number from 0 to 3.</param>
        public bool GetConfiguration(out CardReaderPortType readerNumber, out CardFormatParityConfig config, out int formatNumber)
        {
            if (this.Data.Length < 30)
            {
                readerNumber = CardReaderPortType.NoReader;
                config = null;
                formatNumber = -1;
                return false;
            }
            switch (this.Data[this.Offset])
            {
                case CardReaderSetNewParityMaskCommandReader1FunctionCode:
                    readerNumber = CardReaderPortType.CardReader1;
                    break;
                case CardReaderSetNewParityMaskCommandReader2FunctionCode:
                    readerNumber = CardReaderPortType.CardReader2;
                    break;
                default:
                    readerNumber = CardReaderPortType.NoReader;
                    config = null;
                    formatNumber = -1;
                    return false;
            }

            formatNumber = Data[Offset + 1];
            config = new CardFormatParityConfig(Data, Offset + 2);
            return config != null;
        }

        private CardFormatParityConfig parseSetNewParityMaskCommand(out int formatNumber)
        {
            CardFormatParityConfig config = new CardFormatParityConfig();
            // Get format index
            formatNumber = this.Data[this.Offset + 1];
            // Mask 1
            if ((this.Data[this.Offset + 2] & 0x01) == 0x01)
            {
                config.Mask[0].Enabled = true;
                if ((this.Data[this.Offset + 2] & 0x10) == 0x10)
                {
                    config.Mask[0].OddParity = true;
                }
                else
                {
                    config.Mask[0].OddParity = false;
                }
                config.Mask[0].Offset = this.Data[this.Offset + 27];
                for (int iMask = 0; iMask < 8; iMask++)
                {
                    config.Mask[0].Mask[iMask] = this.Data[this.Offset + 3 + iMask];
                }                
            }
            else
            {
                config.Mask[0].Enabled = false;
            }
            // Mask 2
            if ((this.Data[this.Offset + 2] & 0x02) == 0x02)
            {
                config.Mask[1].Enabled = true;
                if ((this.Data[this.Offset + 2] & 0x20) == 0x20)
                {
                    config.Mask[1].OddParity = true;
                }
                else
                {
                    config.Mask[1].OddParity = false;
                }
                config.Mask[1].Offset = this.Data[this.Offset + 28];
                for (int iMask = 0; iMask < 8; iMask++)
                {
                    config.Mask[1].Mask[iMask] = this.Data[this.Offset + 11 + iMask];
                }                
            }
            else
            {
                config.Mask[1].Enabled = false;
            }
            // Mask 3
            if ((this.Data[this.Offset + 2] & 0x04) == 0x04)
            {
                config.Mask[2].Enabled = true;
                if ((this.Data[this.Offset + 2] & 0x40) == 0x40)
                {
                    config.Mask[2].OddParity = true;
                }
                else
                {
                    config.Mask[2].OddParity = false;
                }
                config.Mask[2].Offset = this.Data[this.Offset + 29];
                for (int iMask = 0; iMask < 8; iMask++)
                {
                    config.Mask[2].Mask[iMask] = this.Data[this.Offset + 19 + iMask];
                }
            }
            else
            {
                config.Mask[2].Enabled = false;
            }
            // Get invert and reverse
            if ((this.Data[this.Offset + 2] & 0x80) == 0x80)
            {
                config.Invert = true;
            }
            else
            {
                config.Invert = false;
            }
            if ((this.Data[this.Offset + 2] & 0x08) == 0x08)
            {
                config.Reverse = true;
            }
            else
            {
                config.Reverse = false;
            }
            return config;
        }

        public override string ToString()
        {
            return "Set Card Reader Format Parity Configuration";
        }

#if COMMUNICATIONSANALYZER

        public CardReaderSetNewParityMaskCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { 
                CardReaderSetNewParityMaskCommandReader1FunctionCode,
                CardReaderSetNewParityMaskCommandReader2FunctionCode
            }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
