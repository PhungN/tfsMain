﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // The 16 input expansion alarm unit allows different resolutions for different anolog inputs. These values can be downloaded to 16 input expansion alarm unit:
    // 10 , RES1, RES2, …, RES16
    // RES1 -  RES16  = resolutions for anolog input 1 – 16 respectively.
    public class SetResolutionForAnalogInputsLegacyCommand : DeviceLoopMessageBase
    {
        public const int SetResolutionForAnalogInputsLegacyCommandFunctionCode = 16;

        public SetResolutionForAnalogInputsLegacyCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public SetResolutionForAnalogInputsLegacyCommand(int[] analogInputResolutions)
        {
            Data = new byte[analogInputResolutions.Length + 1];
            FunctionCode = SetResolutionForAnalogInputsLegacyCommandFunctionCode;

            for (int byteIndex = 0; byteIndex < analogInputResolutions.Length; byteIndex++)
            {
                Data[byteIndex + 1] = (byte)analogInputResolutions[byteIndex];
            }

            Length = Data.Length;
        }

        public void GetResolutionForAnalogInputs(out int[] analogInputResolutions)
        {
            analogInputResolutions = new int[Length - 1];

            for (int byteIndex = 0; byteIndex < analogInputResolutions.Length; byteIndex++)
            {
                analogInputResolutions[byteIndex] = Data[Offset + byteIndex + 1];
            }
        }

        public override string ToString()
        {
            int[] analogInputResolutions;
            GetResolutionForAnalogInputs(out analogInputResolutions);

            string resolutionString = "";
            for (int i = 0; i < analogInputResolutions.Length; i++)
            {
                if (i > 0)
                    resolutionString += "-";
                resolutionString += analogInputResolutions[i].ToString();
            }

            return "Set Resolution For Analog Inputs (" + resolutionString + ")";
        }

#if COMMUNICATIONSANALYZER

        public SetResolutionForAnalogInputsLegacyCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetResolutionForAnalogInputsLegacyCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501}; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
