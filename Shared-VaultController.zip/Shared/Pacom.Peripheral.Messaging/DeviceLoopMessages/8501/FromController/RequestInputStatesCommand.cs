﻿namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // The current state of all alarm inputs (up to 48 inputs) can be returned.  
    // The message format is:
    // 01
    public class RequestInputStatesCommand : DeviceLoopMessageBase
    {
        public const int RequestInputStatesCommandFunctionCode = 1;

        public RequestInputStatesCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public RequestInputStatesCommand()
        {
            Data = new byte[1];
            FunctionCode = RequestInputStatesCommandFunctionCode;

            Length = 1;
        }

        public override string ToString()
        {
            return "Request Input States";
        }

#if COMMUNICATIONSANALYZER

        // Default constructor already defined

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { RequestInputStatesCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
