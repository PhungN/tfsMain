﻿
namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    /// <summary>
    /// Request the current type and status of expansion cards.
    /// </summary>
    public class RequestExpansionCardStatusCommand : DeviceLoopMessageBase
    {
        public const int RequestExpansionCardStatusCommandFunctionCode = 45;

        public RequestExpansionCardStatusCommand(byte[] data, int offset, int length)
            : base(data, offset, length, 1)
        {
        }

        public RequestExpansionCardStatusCommand()
        {
            Data = new byte[1];
            FunctionCode = RequestExpansionCardStatusCommandFunctionCode;

            Length = 1;
        }

        public override string ToString()
        {
            return "Request Expansion Cards Type and States";
        }

#if COMMUNICATIONSANALYZER

        // Default constructor already defined

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { RequestExpansionCardStatusCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return this.ToString();
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
