﻿using System;
using System.Reflection;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    /// <summary>
    /// Request a change to controller messaging set.
    /// Length is: 3 bytes for message signature plus 4 bytes for flags.
    /// MessageSignature: 0xAA, 0x55, 0xA5
    /// 4 bytes for flags: BYTE(Bits 32..24), BYTE(Bits 23..16), BYTE(Bits 15..8), BYTE(Bits 7..0);
    /// </summary>
    public class SetControllerMessaging : DeviceLoopMessageBase
    {
        private const int MessagingFlagsSerializedLength = 4;
        private const int messageLength = FunctionCodeSize + MessagingFlagsSerializedLength + MessageSignatureSize;
        public const int SetControllerMessagingFunctionCode = 70;

        public SetControllerMessaging(byte[] data, int offset, int length)
            : base(data, offset, length, messageLength)
        {
            if (Data[offset + 1] != MessageSignature[0] ||
                Data[offset + 2] != MessageSignature[1] ||
                Data[offset + 3] != MessageSignature[2])
            {
                throw new ArgumentException("Data doesn't have message signature", "data");
            }
        }

        public SetControllerMessaging(MessagingFlags value)
        {
            Data = new byte[messageLength];
            FunctionCode = SetControllerMessagingFunctionCode;
            Data[1] = MessageSignature[0];
            Data[2] = MessageSignature[1];
            Data[3] = MessageSignature[2];
            value.Serialize(Data, 4);
            Length = Data.Length;
        }

        public bool GetConfiguration(out MessagingFlags value)
        {
            value = MessagingFlags.None;
            if (this.Length == messageLength)
            {
                value = EnumFlagsExtensions.Deserialize < MessagingFlags>(Data, Offset + FunctionCodeSize + MessageSignatureSize);
                return true;
            }
            return false;
        }

        public override string ToString()
        {
            MessagingFlags flags = MessagingFlags.None;
            if (GetConfiguration(out flags) == true)
                return string.Format("Set Controller Messaging ({0})", flags.GetString());
            else
                return string.Format("Set Controller Messaging (Unable to parse flags)");
        }

#if COMMUNICATIONSANALYZER

        public SetControllerMessaging()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetControllerMessagingFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return "Set Controller Messaging";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
