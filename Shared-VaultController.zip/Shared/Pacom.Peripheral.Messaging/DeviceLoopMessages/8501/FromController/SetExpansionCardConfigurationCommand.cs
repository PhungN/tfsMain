﻿using System;
using System.Text;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages.Pacom8501
{
    // Expansion configuration information for device.
    // Length is: 3 bytes for signature + N sets of expansion configurations 3 bytes in length.
    // MessageSignature: 0xAA, 0x55, 0xA5
    // One set for expansion configuration consists of 3 bytes:
    //    PHYSICALPORT = defined in ExpansionCardConfigurationPhysicalPort
    //    CARDTYPE = defined in ExpansionCardConfigurationExpansionCardType
    //    PORTTYPE = defined in ExpansionCardConfigurationPortType
    public class SetExpansionCardConfigurationCommand : DeviceLoopMessageBase
    {
        public const int SetExpansionCardConfigurationCommandFunctionCode = 46;

        public SetExpansionCardConfigurationCommand(byte[] data, int offset, int length)
            : base(data, offset, length, FunctionCodeSize + MessageSignatureSize)
        {
            if (Data[offset + 1] != MessageSignature[0] ||
                Data[offset + 2] != MessageSignature[1] ||
                Data[offset + 3] != MessageSignature[2])
            {
                throw new ArgumentException("Data doesn't have message signature", "data");
            }
        }

        public SetExpansionCardConfigurationCommand(ExpansionCardConfiguration[] configuration)
        {
            Data = new byte[configuration.Length * 3 + (FunctionCodeSize + MessageSignatureSize)];
            FunctionCode = SetExpansionCardConfigurationCommandFunctionCode;
            Data[1] = MessageSignature[0];
            Data[2] = MessageSignature[1];
            Data[3] = MessageSignature[2];
            for (int i = 0; i < configuration.Length; i++)
            {
                Data[4 + (i * 3)] = (byte)configuration[i].PhysicalPort;
                Data[5 + (i * 3)] = (byte)(configuration[i].CardType);
                Data[6 + (i * 3)] = (byte)(configuration[i].PortType);
            }

            Length = Data.Length;
        }

        public void GetConfiguration(out ExpansionCardConfiguration[] configuration)
        {
            if (((this.Length - (FunctionCodeSize + MessageSignatureSize)) % 3) != 0)
            {
                configuration = new ExpansionCardConfiguration[0];
                return;
            }

            configuration = new ExpansionCardConfiguration[(this.Length - (FunctionCodeSize + MessageSignatureSize)) / 3];

            for (int i = 0; i < configuration.Length; i++)
            {
                configuration[i] = new ExpansionCardConfiguration();
                configuration[i].PhysicalPort = (ExpansionCardConfigurationPhysicalPort)Data[Offset + 4 + (i * 3)];
                configuration[i].CardType = (ExpansionCardConfigurationExpansionCardType)Data[Offset + 5 + (i * 3)];
                configuration[i].PortType = (ExpansionCardConfigurationPortType)Data[Offset + 6 + (i * 3)];
            }
        }

        public override string ToString()
        {            
            ExpansionCardConfiguration[] configuration;
            GetConfiguration(out configuration);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < configuration.Length; i++)
            {
                if (i != 0)
                    sb.Append(", ");
                sb.Append("[");
                sb.Append("PhysicalPort=");
                sb.Append(configuration[i].PhysicalPort.ToString());
                sb.Append(", CardType=");
                sb.Append(configuration[i].CardType.ToString());
                sb.Append(", PortType=");
                sb.Append(configuration[i].PortType.ToString());
                sb.Append("]");
            }
            return string.Format("Set Expansion Card Configuration ({0})", sb.ToString());
        }

#if COMMUNICATIONSANALYZER

        public SetExpansionCardConfigurationCommand()
        {
        }

        public override int[] HandledSerialFuntionCodes
        {
            get { return new int[] { SetExpansionCardConfigurationCommandFunctionCode }; }
        }

        public override Pacom.Peripheral.Common.DeviceType[] MessageOwners
        {
            get { return new Pacom.Peripheral.Common.DeviceType[] { Pacom.Peripheral.Common.DeviceType.Pacom8501 }; }
        }

        public override bool? FromController
        {
            get { return true; }
        }

        public override string ShortDescriptionToString()
        {
            return "Set Expansion Card Configuration";
        }

        public override string MultilineDescriptionToString()
        {
            return this.ToString();
        }

#endif
    }
}
