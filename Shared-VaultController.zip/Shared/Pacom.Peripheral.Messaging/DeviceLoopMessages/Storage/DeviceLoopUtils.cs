using Pacom.Peripheral.Common;
using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    internal static class DeviceLoopUtils
    {
        /// <summary>
        /// Get number of bytes required to accommodate specified number of bits.
        /// </summary>
        /// <param name="bits">Number of bits</param>
        /// <returns>Byte array length</returns>
        internal static int GetByteArrayLengthFromBits(int bits)
        {
            return (bits / 8) + (bits % 8 > 0 ? 1 : 0);
        }

        internal delegate void ConstructRawCardDataDelegate(int position, byte data);

        /// <summary>
        /// Construct raw card data. Populate request byte array.
        /// </summary>
        /// <param name="config">Request configuration</param>
        /// <param name="offset">Offset in device loop data stream</param>
        /// <param name="data">Device loop data stream</param>
        internal static void ConstructRawCardData(ref CardReaderDataSendDataRawConfig config, ConstructRawCardDataDelegate callback)
        {
            int dataBitPos = 7;
            int dataBytePos = 0;
            int outputBytePos = GetByteArrayLengthFromBits(config.NumberOfBits) - 1;
            int outputBitPos = (config.NumberOfBits - 1) % 8;
            byte outputByte = 0;
            for (int iBit = 0; iBit < Math.Min(config.NumberOfBits, config.Data.Length * 8); iBit++)
            {
                outputByte |= (byte)((config.Data[dataBytePos] & (1 << dataBitPos)) > 0 ? 1 << outputBitPos : 0);
                outputBitPos--;
                if (outputBitPos < 0)
                {
                    callback(outputBytePos, outputByte);
                    outputByte = 0;
                    outputBitPos = 7;
                    outputBytePos--;
                }
                dataBitPos--;
                if (dataBitPos < 0)
                {
                    dataBitPos = 7;
                    dataBytePos++;
                }
            }            
        }

        /// <summary>
        /// Construct raw card data. Populate request byte array.
        /// </summary>
        /// <param name="config">Request configuration</param>
        /// <param name="offset">Offset in device loop data stream</param>
        /// <param name="data">Device loop data stream</param>
        internal static void ConstructRawCardData(ref CardReaderEventRawDataConfig config, ConstructRawCardDataDelegate callback)
        {
            int dataBitPos = 7;
            int dataBytePos = 0;
            int outputBytePos = GetByteArrayLengthFromBits(config.CardLength) - 1;
            int outputBitPos = (config.CardLength - 1) % 8;
            byte outputByte = 0;
            for (int iBit = 0; iBit < Math.Min(config.CardLength, config.CardData.Length * 8); iBit++)
            {
                outputByte |= (byte)((config.CardData[dataBytePos] & (1 << dataBitPos)) > 0 ? 1 << outputBitPos : 0);
                outputBitPos--;
                if (outputBitPos < 0)
                {
                    callback(outputBytePos, outputByte);
                    outputByte = 0;
                    outputBitPos = 7;
                    outputBytePos--;
                }
                dataBitPos--;
                if (dataBitPos < 0)
                {
                    dataBitPos = 7;
                    dataBytePos++;
                }
            }            
        }
        
        /// <summary>
        /// Parse raw card data. Populate response configuration object.
        /// </summary>
        /// <param name="config">Response configuration</param>
        /// <param name="offset">Offset in device loop data stream</param>
        /// <param name="data">Device loop data stream</param>
        internal static void ParseRawCardData(ref CardReaderDataSendDataRawConfig config, int offset, byte[] data)
        {
            config.Data = new byte[GetByteArrayLengthFromBits(config.NumberOfBits)];
            int outputBitPos = 7;
            int outputBytePos = 0;
            int dataBitPos = config.NumberOfBits % 8 == 0 ? 7 : (config.NumberOfBits % 8) - 1;
            int dataBytePos = config.Data.Length - 1;
            for (int iBit = 0; iBit < config.NumberOfBits; iBit++)
            {
                config.Data[outputBytePos] |= (byte)((data[offset + dataBytePos] & (1 << dataBitPos)) > 0 ? 1 << outputBitPos : 0);
                outputBitPos--;
                if (outputBitPos < 0)
                {
                    outputBitPos = 7;
                    outputBytePos++;
                }
                dataBitPos--;
                if (dataBitPos < 0)
                {
                    dataBitPos = 7;
                    dataBytePos--;
                }
            }
        }

        /// <summary>
        /// Parse raw card data. Populate response configuration object.
        /// </summary>
        /// <param name="config">Response configuration</param>
        /// <param name="offset">Offset in device loop data stream</param>
        /// <param name="data">Device loop data stream</param>
        internal static void ParseRawCardData(ref CardReaderEventRawDataConfig config, int offset, byte[] data)
        {
            config.CardData = new byte[GetByteArrayLengthFromBits(config.CardLength)];
            int outputBitPos = 7;
            int outputBytePos = 0;
            int dataBitPos = config.CardLength % 8 == 0 ? 7 : (config.CardLength % 8) - 1;
            int dataBytePos = config.CardData.Length - 1;
            for (int iBit = 0; iBit < config.CardLength; iBit++)
            {
                config.CardData[outputBytePos] |= (byte)((data[offset + dataBytePos] & (1 << dataBitPos)) > 0 ? 1 << outputBitPos : 0);
                outputBitPos--;
                if (outputBitPos < 0)
                {
                    outputBitPos = 7;
                    outputBytePos++;
                }
                dataBitPos--;
                if (dataBitPos < 0)
                {
                    dataBitPos = 7;
                    dataBytePos--;
                }
            }
        }
    }
}