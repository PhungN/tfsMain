﻿using System.Collections.Generic;
using System;

namespace Pacom.Peripheral.Messaging.DeviceLoopMessages
{
    public class MessageGenericPart<T> where T : struct
    {
        public MessageGenericPart(int startingPoint, T[] data)
        {
            StartingPoint = startingPoint;
            Data = data;
        }

        public int StartingPoint
        {
            private set;
            get;
        }

        public T[] Data
        {
            private set;
            get;
        }

        /// <summary>
        /// Get maximum parts of the message with type T to be transmitted to the device.
        /// </summary>
        /// <param name="startingPoint">Owner starting point</param>
        /// <param name="values">All the values configured and ready for being partitioned</param>
        /// <param name="expectedDefaultValue">An instance or value of default configuration or null if all values should be partitined.</param>
        /// <param name="maximumDataPartCount">The longest the partition can get. It depends how the data is packed into the message: bits, nibbles, bytes.</param>
        /// <returns>Chunks of the configured values ready to be send</returns>
        public static IEnumerable<MessageGenericPart<T>> GetPart(int startingPoint, T[] values, int maximumDataPartCount, Nullable<T> expectedDefaultValue)
        {
            if (values != null && values.Length > 0)
            {
                bool sentPart = false;
                int partStartingPoint = 0;
                List<T> part = new List<T>();
                for (int pos = startingPoint; pos < values.Length; pos++)
                {
                    if (expectedDefaultValue.HasValue == false || EqualityComparer<T>.Default.Equals(values[pos], expectedDefaultValue.Value) == false)
                    {
                        if (part.Count == 0) // Make note of the starting point for the group
                            partStartingPoint = pos;
                        part.Add(values[pos]);
                    }
                    else
                    {
                        // The configuration is the same as defualt, send the part over; if any.
                        sentPart = true;
                    }
                    // Sent part to the device
                    if (part.Count >= maximumDataPartCount || (part.Count > 0 && (sentPart == true || pos == values.Length - 1)))
                    {
                        yield return new MessageGenericPart<T>(partStartingPoint, part.ToArray());
                        part.Clear();
                    }
                    sentPart = false;
                }
            }
        }
    }
}
