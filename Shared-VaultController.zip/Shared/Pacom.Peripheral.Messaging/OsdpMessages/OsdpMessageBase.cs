﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    public class OsdpMessageBase
    {
        /// <summary>
        /// OSDP packet start of message.
        /// </summary>
        public const int StartOfMessageByte = 0x53;

        /// <summary>
        /// Minimum OSDP length. SOM, ADDR, LEN_LSB, LEN_MSB, CTRL, CMND/REPLY, CKSUM
        /// </summary>
        public const int MinOsdpMessageLength = 7;

        /// <summary>
        /// Maximum OSDP length the system must support.
        /// </summary>
        public const int MaxOsdpMessageLength = 1440;

        public OsdpMessageBase(byte[] message)
        {
            this.message = message;
        }

        public OsdpMessageBase(byte[] message, int minimumDataSize, OsdpEncryptionDetails encryptionDetails)
        {
            this.message = message;
            if (encryptionBlockTypeAsInt >= 0x15 && encryptionBlockTypeAsInt <= 0x18)
            {
                byte[] calculatedMac = calculateMac(encryptionDetails, false);
                bool macValid = true;
                int macOffset = MacOffset;
                for (int i = 0; i < 4; i++)
                {
                    if (calculatedMac[i] != this.message[macOffset + i])
                    {
                        macValid = false;
                        break;
                    }
                }

                if (macValid == false)
                    throw new ArgumentException("MAC is invalid", "message");


                if (EncryptionBlockType == OsdpSecurityBlockType.ReaderToDoorController
#if DEBUG
                     || EncryptionBlockType == OsdpSecurityBlockType.DoorControllerToReader
#endif
                    )
                {
                    Data = decryptData(paddedData, encryptionDetails);
                }
            }
            if (DataLength < minimumDataSize)
                throw new ArgumentException("Message length is invalid", "message");
        }

        public OsdpMessageBase()
        {
        }

        public OsdpMessageBase(int address, int sequence, bool useCrc, int functionCode, byte[] data):
            this(address, sequence, useCrc, functionCode, data, null, OsdpSecurityBlockType.DoorControllerToReader, new OsdpEncryptionDetails())
        {
        }

        public OsdpMessageBase(int address, int sequence, bool useCrc, int functionCode, byte[] data, byte[] encryptionBlockData, OsdpSecurityBlockType encryptionBlockType, OsdpEncryptionDetails encryptionDetails)
        {
            int length;
            if (encryptionDetails.SessionEncryptionKey == null && functionCode != SessionInitiationStep1Command.FunctionCode)
            {
                length = MinOsdpMessageLength;
                if (useCrc)
                    length++;

                if (data != null)
                    length += data.Length;

                this.message = new byte[length];
                this.message[0] = StartOfMessageByte;
                Address = address;
                Length = length;
                if (useCrc)
                    Control = (byte)sequence | 0x4;
                else
                    Control = (byte)sequence;
                MessageFunctionCode = functionCode;
                if (data != null)
                    Data = data;
                if (useCrc)
                    updateCrc(length);
                else
                    updateChecksum(length);
                return;
            }

            length = MinOsdpMessageLength + 2 /* SEC_BLK */;
            if (useCrc)
                length++;

            if (data != null)
            {
                if (encryptionBlockType == OsdpSecurityBlockType.DoorControllerToReader
#if DEBUG
                     || encryptionBlockType == OsdpSecurityBlockType.ReaderToDoorController
#endif
                    )
                {
                    data = padData(data);
                }
                length += data.Length;
            }
            if (encryptionBlockData != null)
                length += encryptionBlockData.Length;
            if ((int)encryptionBlockType >= 0x15 && (int)encryptionBlockType <= 0x18)
                length += 4;

            this.message = new byte[length];
            this.message[0] = StartOfMessageByte;
            Address = address;
            Length = length;
            if (useCrc)
                Control = (byte)sequence | 0x4 | 0x8;
            else
                Control = (byte)sequence | 0x8;

            if (encryptionBlockData != null)
            {
                EncryptionBlockLength = 2 + encryptionBlockData.Length;    /* SEC_BLK_LEN */
                EncryptionBlockData = encryptionBlockData;
            }
            else
            {
                EncryptionBlockLength = 2;
            }
            EncryptionBlockType = encryptionBlockType;

            MessageFunctionCode = functionCode;
            if (data != null)
                Data = data;
        }

        protected byte[] message;

        public byte[] Message()
        {
            return Message(new OsdpEncryptionDetails());
        }

        public byte[] Message(OsdpEncryptionDetails encryptionDetails)
        {
            if (encryptionDetails.SessionEncryptionKey != null || MessageFunctionCode == SessionInitiationStep1Command.FunctionCode)
            {
                OsdpSecurityBlockType encryptionBlockType = EncryptionBlockType;
                int dataLength = paddedDataLength;
                if (dataLength > 0 && (encryptionBlockType == OsdpSecurityBlockType.DoorControllerToReader
#if DEBUG
                    || encryptionBlockType == OsdpSecurityBlockType.ReaderToDoorController
#endif
                    ))
                {
                    Data = encryptData(message, DataOffset, dataLength, encryptionDetails);
                }
                if ((int)encryptionBlockType >= 0x15 && (int)encryptionBlockType <= 0x18)
                {
                    byte[] mac = calculateMac(encryptionDetails, true);
                    Buffer.BlockCopy(mac, 0, this.message, MacOffset, 4);
                }
                if (CrcPresent)
                    updateCrc(message.Length);
                else
                    updateChecksum(message.Length);
            }

            return message;
        }

        public int Address
        {
            get
            {
                return (message[1] & 0x7F);
            }
            private set
            {
                message[1] = (byte)value;
            }
        }

        public int Length
        {
            get
            {
                return (message[3] << 8) | message[2];
            }
            private set
            {
                message[2] = (byte)(value & 0xFF);
                message[3] = (byte)((value & 0xFF00) >> 8);
            }
        }

        public int Control
        {
            get
            {
                return message[4];
            }
            private set
            {
                message[4] = (byte)value;
            }
        }

        public int Sequence
        {
            get
            {
                return (Control & 0x03);
            }
        }

        public bool CrcPresent
        {
            get
            {
                return ((Control & 0x04) != 0);
            }
        }

        public bool EncryptionBlockPresent
        {
            get
            {
                return ((Control & 0x08) != 0);
            }
        }

        public int EncryptionBlockLength
        {
            get
            {
                if (EncryptionBlockPresent)
                    return message[5];
                return 0;
            }
            private set
            {
                message[5] = (byte)value;
            }
        }

        private int encryptionBlockTypeAsInt
        {
            get
            {
                if (EncryptionBlockPresent)
                    return message[6];
                return 0;
            }
        }

        public OsdpSecurityBlockType EncryptionBlockType
        {
            get
            {
                if (EncryptionBlockPresent)
                    return (OsdpSecurityBlockType)message[6];
                return 0;
            }
            private set
            {
                message[6] = (byte)value;
            }
        }

        public int EncryptionBlockDataOffset
        {
            get
            {
                if (EncryptionBlockPresent)
                    return 7;
                return 0;
            }
        }

        public int EncryptionBlockDataLength
        {
            get
            {
                if (EncryptionBlockPresent)
                    return EncryptionBlockLength - 2;
                return 0;
            }
        }

        public byte[] EncryptionBlockData
        {
            get
            {
                if (EncryptionBlockPresent)
                {
                    byte[] encryptedBlockData = new byte[EncryptionBlockDataLength];
                    Buffer.BlockCopy(message, EncryptionBlockDataOffset, encryptedBlockData, 0, EncryptionBlockDataLength);
                    return encryptedBlockData;
                }
                return null;
            }
            private set
            {
                Buffer.BlockCopy(value, 0, message, EncryptionBlockDataOffset, EncryptionBlockDataLength);
            }
        }

        public int MacOffset
        {
            get
            {
                if (encryptionBlockTypeAsInt >= 0x15 && encryptionBlockTypeAsInt <= 0x18)
                {
                    if (CrcPresent)
                        return Length - 6;
                    else
                        return Length - 5;
                }
                return 0;
            }
        }

        public int MacLength
        {
            get
            {
                if (encryptionBlockTypeAsInt >= 0x15 && encryptionBlockTypeAsInt <= 0x18)
                    return 4;
                return 0;
            }
        }

        public byte[] Mac
        {
            get
            {
                if (encryptionBlockTypeAsInt >= 0x15 && encryptionBlockTypeAsInt <= 0x18)
                {
                    byte[] mac = new byte[MacLength];
                    Buffer.BlockCopy(message, MacOffset, mac, 0, MacLength);
                    return mac;
                }
                return null;
            }
        }

        public int MessageFunctionCode
        {
            get
            {
                return message[5 + EncryptionBlockLength];
            }
            private set
            {
                message[5 + EncryptionBlockLength] = (byte)value;
            }
        }

        public int DataOffset
        {
            get
            {
                return 6 + EncryptionBlockLength;
            }
        }

        private int paddedDataLength
        {
            get
            {
                int dataLength = Length - 8 - MacLength - EncryptionBlockLength;
                if (CrcPresent == false)
                    dataLength = Length - 7 - MacLength - EncryptionBlockLength;

                return dataLength;
            }
        }

        private byte[] paddedData
        {
            get
            {
                byte[] data = new byte[paddedDataLength];
                Buffer.BlockCopy(message, DataOffset, data, 0, paddedDataLength);
                return data;
            }
        }

        public int DataLength
        {
            get
            {
                int dataLength = paddedDataLength;

                if (EncryptionBlockPresent && (EncryptionBlockType == OsdpSecurityBlockType.ReaderToDoorController 
#if DEBUG
                    || EncryptionBlockType == OsdpSecurityBlockType.DoorControllerToReader
#endif
                    ))
                {
                    int dataOffset = DataOffset;
                    for (int i = dataLength - 1; i >= 0; i--)
                    {
                        if (message[dataOffset + i] == 0x80)
                        {
                            return i;
                        }
                        else if (message[dataOffset + i] != 0)
                        {
                            // Invalid padding. This should never happen as padding is always required.
                            return dataLength;
                        }
                    }
                }

                return dataLength;
            }
        }

        public byte[] Data
        {
            get
            {
                byte[] data = new byte[DataLength];
                Buffer.BlockCopy(message, DataOffset, data, 0, DataLength);
                return data;
            }
            private set
            {
                Buffer.BlockCopy(value, 0, message, DataOffset, value.Length);
            }
        }

        public void GetData(byte[] data, int offset, int length)
        {
            Buffer.BlockCopy(message, DataOffset + offset, data, 0, length);
        }

        private void updateChecksum(int length)
        {
            byte checksum = 0;
            for (int i = 0; i < length; i++)
                checksum += message[i];
            checksum = (byte)~checksum;
            checksum++;
            message[length - 1] = checksum;
        }

        private void updateCrc(int length)
        {
            ushort crc = Crc16Ccitt.ComputeChecksum(message, 0, length - 2);
            message[length - 2] = (byte)(crc & 0xFF);
            message[length - 1] = (byte)((crc & 0xFF00) >> 8);
        }

        private byte[] padData(byte[] data)
        {
            int paddedLength = ((data.Length / 16) + 1) * 16;
            byte[] paddedData = new byte[paddedLength];
            paddedData[data.Length] = 0x80;
            Buffer.BlockCopy(data, 0, paddedData, 0, data.Length);
            return paddedData;
        }

        private byte[] encryptData(byte[] data, int offset, int length, OsdpEncryptionDetails encryptionDetails)
        {
            byte[] initializationVector = new byte[16];
            Buffer.BlockCopy(encryptionDetails.SendingMac, 0, initializationVector, 0, 16);
            for (int i = 0; i < 16; i++)
            {
                initializationVector[i] = (byte)~(initializationVector[i]);
            }

            RijndaelManaged aes = new RijndaelManaged();
            aes.Key = encryptionDetails.SessionEncryptionKey;
            aes.IV = initializationVector;
            aes.Padding = PaddingMode.None;
            aes.Mode = CipherMode.CBC;

            using (ICryptoTransform encryptor = aes.CreateEncryptor())
            {
                data = encryptor.TransformFinalBlock(data, offset, length);
            }
            return data;
        }

        private byte[] decryptData(byte[] data, OsdpEncryptionDetails encryptionDetails)
        {
            byte[] initializationVector = new byte[16];
            Buffer.BlockCopy(encryptionDetails.ReceiveMac, 0, initializationVector, 0, 16);
            for (int i = 0; i < 16; i++)
            {
                initializationVector[i] = (byte)~(initializationVector[i]);
            }

            RijndaelManaged aes = new RijndaelManaged();
            aes.Key = encryptionDetails.SessionEncryptionKey;
            aes.IV = initializationVector;
            aes.Padding = PaddingMode.None;
            aes.Mode = CipherMode.CBC;

            using (ICryptoTransform decryptor = aes.CreateDecryptor())
            {
                data = decryptor.TransformFinalBlock(data, 0, data.Length);
            }
            return data;
        }

        private byte[] calculateMac(OsdpEncryptionDetails encryptionDetails, bool sending)
        {
            byte[] inputData;
            int paddedLength = 0;
            int length;
            if (CrcPresent)
                length = message.Length - 6;
            else
                length = message.Length - 5;

            if ((length % 16) == 0)
            {
                paddedLength = length;
                inputData = message;
            }
            else
            {
                paddedLength = ((length / 16) + 1) * 16;
                inputData = new byte[paddedLength];
                inputData[length] = 0x80;
                Buffer.BlockCopy(message, 0, inputData, 0, length);
            }

            RijndaelManaged aes = new RijndaelManaged();
            aes.Key = encryptionDetails.SessionMac1;
            if (sending)
                aes.IV = encryptionDetails.SendingMac;
            else
                aes.IV = encryptionDetails.ReceiveMac;
            aes.Padding = PaddingMode.None;
            aes.Mode = CipherMode.CBC;
            byte[] mac;
            if (paddedLength > 16)
            {
                using (ICryptoTransform encryptor = aes.CreateEncryptor())
                {
                    mac = encryptor.TransformFinalBlock(inputData, 0, paddedLength - 16);
                }
                if (mac.Length > 16)
                {
                    byte[] temp = new byte[16];
                    Buffer.BlockCopy(mac, mac.Length - 16, temp, 0, 16);
                    mac = temp;
                }
            }
            else
            {
                if (sending)
                    mac = encryptionDetails.SendingMac;
                else
                    mac = encryptionDetails.ReceiveMac;
            }
            aes.Key = encryptionDetails.SessionMac2;
            aes.IV = mac;
            using (ICryptoTransform encryptor = aes.CreateEncryptor())
            {
                mac = encryptor.TransformFinalBlock(inputData, paddedLength - 16, 16);
            }

            if (sending)
                encryptionDetails.ReceiveMac = mac;
            else
                encryptionDetails.SendingMac = mac;

            return mac;
        }

        public static void SetVendorBytes(ReaderManufacturer vendor, byte[] data, int offset)
        {
            switch (vendor)
            {
                case ReaderManufacturer.Pacom:
                    data[offset] = 0x00;
                    data[offset + 1] = 0xE0;
                    data[offset + 2] = 0x42;
                    break;
                case ReaderManufacturer.HidCorporation:
                    data[offset] = 0x00;
                    data[offset + 1] = 0x06;
                    data[offset + 2] = 0x8E;
                    break;
                case ReaderManufacturer.Contal:
                    data[offset] = 0x00;
                    data[offset + 1] = 0x0B;
                    data[offset + 2] = 0x3D;
                    break;
                case ReaderManufacturer.Bqt:
                    data[offset] = 0x54;
                    data[offset + 1] = 0xA3;
                    data[offset + 2] = 0xFA;
                    break;
            }
        }

        public static ReaderManufacturer GetVendor(byte[] data, int offset)
        {
            if (data[offset] == 0)
            {
                if (data[offset + 1] == 0xE0 && data[offset + 2] == 0x42)
                {
                    return ReaderManufacturer.Pacom;
                }
                else if (data[offset + 1] == 0x06 && data[offset + 2] == 0x8E)
                {
                    return ReaderManufacturer.HidCorporation;
                }
                else if (data[offset + 1] == 0x0B && data[offset + 2] == 0x3D)
                {
                    return ReaderManufacturer.Contal;
                }
            }
            else if (data[offset] == 0x54 && data[offset + 1] == 0xA3 && data[offset + 2] == 0xFA)
            {
                return ReaderManufacturer.Bqt;
            }
            return ReaderManufacturer.Unknown;
        }

        public static OsdpMessageBase Parse(byte[] data, OsdpEncryptionDetails encryptionDetails)
        {
            int encryptionBlockLength = 0;
            if (((data[4] & 0x08) != 0))
                encryptionBlockLength = data[5];
            int functionCode = data[5 + encryptionBlockLength];
            if ((data[1] & 0x80) != 0)
            {
                switch (functionCode)
                {
                    case AckReply.FunctionCode: return new AckReply(data, encryptionDetails);
                    case RawCardReply.FunctionCode: return new RawCardReply(data, encryptionDetails);
                    case SessionInitiationStep2Reply.FunctionCode: return new SessionInitiationStep2Reply(data, encryptionDetails);
                    case SessionInitiationStep4Reply.FunctionCode: return new SessionInitiationStep4Reply(data, encryptionDetails);
                    case BusyReply.FunctionCode: return new BusyReply(data, encryptionDetails);
                    case CapabilitiesReply.FunctionCode: return new CapabilitiesReply(data, encryptionDetails);
                    case CommsConfigurationReply.FunctionCode: return new CommsConfigurationReply(data, encryptionDetails);
                    case ExtendedReadReply.FunctionCode: return new ExtendedReadReply(data, encryptionDetails);
                    case IdReply.FunctionCode: return new IdReply(data, encryptionDetails);
                    case InputStatusReply.FunctionCode: return new InputStatusReply(data, encryptionDetails);
                    case KeyPressReply.FunctionCode: return new KeyPressReply(data, encryptionDetails);
                    case LocalStatusReply.FunctionCode: return new LocalStatusReply(data, encryptionDetails);
                    case ManufacturerSpecificReply.FunctionCode: return new ManufacturerSpecificReply(data, encryptionDetails);
                    case NackReply.FunctionCode: return new NackReply(data, encryptionDetails);
                    case OutputStatusReply.FunctionCode: return new OutputStatusReply(data, encryptionDetails);
                    case TamperStatusReply.FunctionCode: return new TamperStatusReply(data, encryptionDetails);
                    default: return new UnknownMessage(data, encryptionDetails);
                }
            }
            switch (functionCode)
            {
                case PollCommand.FunctionCode: return new PollCommand(data, encryptionDetails);
                case SessionInitiationStep1Command.FunctionCode: return new SessionInitiationStep1Command(data, encryptionDetails);
                case SessionInitiationStep3Command.FunctionCode: return new SessionInitiationStep3Command(data, encryptionDetails);
                case BuzzerCommand.FunctionCode: return new BuzzerCommand(data, encryptionDetails);
                case CapabilitiesCommand.FunctionCode: return new CapabilitiesCommand(data, encryptionDetails);
                case EncryptionKeySetCommand.FunctionCode: return new EncryptionKeySetCommand(data, encryptionDetails);
                case ExtendedWriteCommand.FunctionCode: return new ExtendedWriteCommand(data, encryptionDetails);
                case IdCommand.FunctionCode: return new IdCommand(data, encryptionDetails);
                case LedSetCommand.FunctionCode: return new LedSetCommand(data, encryptionDetails);
                case ManufacturerSpecificCommand.FunctionCode: return new ManufacturerSpecificCommand(data, encryptionDetails);
                case OutputSetCommand.FunctionCode: return new OutputSetCommand(data, encryptionDetails);
                case RequestInputStatusCommand.FunctionCode: return new RequestInputStatusCommand(data, encryptionDetails);
                case RequestLocalStatusCommand.FunctionCode: return new RequestLocalStatusCommand(data, encryptionDetails);
                case RequestOutputStatusCommand.FunctionCode: return new RequestOutputStatusCommand(data, encryptionDetails);
                case RequestTamperStatusCommand.FunctionCode: return new RequestTamperStatusCommand(data, encryptionDetails);
                case TextSetCommand.FunctionCode: return new TextSetCommand(data, encryptionDetails);
                default: return new UnknownMessage(data, encryptionDetails);
            }
        }
    }
}