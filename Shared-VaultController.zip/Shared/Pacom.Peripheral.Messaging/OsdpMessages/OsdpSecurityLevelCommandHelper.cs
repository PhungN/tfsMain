﻿using Pacom.Peripheral.Common;
using System;

namespace Pacom.Peripheral.OsdpMessaging
{
    public static class OsdpSecurityLevelCommandHelper
    {
        public static AlertCommand ToAlertCommand(SecurityLevelDisplayCommand securityLevelCommand)
        {
            switch (securityLevelCommand)
            {
                case SecurityLevelDisplayCommand.DoorUnlocked:
                    return AlertCommand.Unlocked;
                case SecurityLevelDisplayCommand.DoorLocked:
                    return AlertCommand.Locked;
                case SecurityLevelDisplayCommand.DoorForced:
                    return AlertCommand.Forced;
                case SecurityLevelDisplayCommand.DoorAjar:
                    return AlertCommand.Ajar;
                case SecurityLevelDisplayCommand.RejectRequest:
                    return AlertCommand.Reject;
                case SecurityLevelDisplayCommand.AcceptRequest:
                    return AlertCommand.Accept;
                case SecurityLevelDisplayCommand.WaitPinCode:
                    return AlertCommand.PIN;
                default:
                    return AlertCommand.Card;
            }
        }

        public static SecurityLevelDisplayCommand ToSecurityLevelCommand(AlertCommand alertCommand)
        {
            switch (alertCommand)
            {
                case AlertCommand.Unlocked:
                    return SecurityLevelDisplayCommand.DoorUnlocked;
                case AlertCommand.Locked:
                    return SecurityLevelDisplayCommand.DoorLocked;
                case AlertCommand.Forced:
                    return SecurityLevelDisplayCommand.DoorForced;
                case AlertCommand.Ajar:
                    return SecurityLevelDisplayCommand.DoorAjar;
                case AlertCommand.Card:
                    return SecurityLevelDisplayCommand.WaitCard;
                case AlertCommand.Reject:
                    return SecurityLevelDisplayCommand.RejectRequest;
                case AlertCommand.Accept:
                    return SecurityLevelDisplayCommand.AcceptRequest;
                case AlertCommand.PIN:
                    return SecurityLevelDisplayCommand.WaitPinCode;
                default:
                    return SecurityLevelDisplayCommand.None;
            }
        }
    }
}
