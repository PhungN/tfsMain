﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_CAP - PD Capabilities Request
    // This command requests the PD to return a list of its functional capabilities, such as the type and 
    // number of input points, outputs points, reader ports, etc.
    // Command structure: 1-byte request code
    public class CapabilitiesCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0x62;

        public CapabilitiesCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 1, encryptionDetails)
        {
        }

        public CapabilitiesCommand(int address, int sequence, bool useCrc)
            : base(address, sequence, useCrc, FunctionCode, new byte[1] { 0 })
        {
        }

        public CapabilitiesCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails)
            : base(address, sequence, useCrc, FunctionCode, new byte[1] { 0 }, null, OsdpSecurityBlockType.DoorControllerToReader, encryptionDetails)
        {
        }
    }
}