﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_OUT - Output Control Command
    // The Output Control command can alter the permanent state of the output, or it can request a timed 
    // pulse output. The permanent command is volatile (does not transcend power cycles).
    // Command structure: 4-byte element, repeated 1 or more times
    public class OutputSetCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0x68;

        public OutputSetCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 4, encryptionDetails)
        {
        }

        public OutputSetCommand(int address, int sequence, bool useCrc, OutputInstruction[] instructions)
            : base(address, sequence, useCrc, FunctionCode, constructData(instructions))
        {
        }

        public OutputSetCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, OutputInstruction[] instructions)
            : base(address, sequence, useCrc, FunctionCode, constructData(instructions), null, OsdpSecurityBlockType.DoorControllerToReader, encryptionDetails)
        {
        }

        private static byte[] constructData(OutputInstruction[] instructions)
        {
            byte[] data = new byte[4 * instructions.Length];
            for (int i = 0; i < instructions.Length; i++)
            {
                data[i * 4] = (byte)instructions[i].OutputNumber;
                data[(i * 4) + 1] = (byte)instructions[i].Instruction;
                int duration = (int)(instructions[i].Duration.TotalMilliseconds / 100);
                data[(i * 4) + 2] = (byte)(duration & 0xFF);
                data[(i * 4) + 3] = (byte)((duration & 0xFF00) >> 8);
            }
            return data;
        }

        public OutputInstruction[] Instructions
        {
            get
            {
                OutputInstruction[] instructions = new OutputInstruction[DataLength / 4];
                for (int i = 0; i < instructions.Length; i++)
                {
                    instructions[i] = new OutputInstruction();
                    instructions[i].OutputNumber = message[DataOffset + (4 * i)];
                    instructions[i].Instruction = (OutputInstructionType)message[DataOffset + ((4 * i) + 1)];
                    int duration = (message[DataOffset + ((4 * i) + 3)] << 8) | message[DataOffset + ((4 * i) + 2)];
                    instructions[i].Duration = new TimeSpan(0, 0, 0, 0, duration * 100);
                }
                return instructions;
            }
        }
    }
}