﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_SCRYPT - Server Cryptogram
    // This command transfers a block of data used for encryption synchronization.
    // Command structure: 16-byte server cryptogram
    public class SessionInitiationStep3Command : OsdpMessageBase
    {
        public const int FunctionCode = 0x77;

        public SessionInitiationStep3Command(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 1, encryptionDetails)
        {
        }

        public SessionInitiationStep3Command(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails)
            : base(address, sequence, useCrc, FunctionCode, encryptionDetails.ServerCryptogram, constructEncryptionBlockData(encryptionDetails), OsdpSecurityBlockType.SessionInitiationStep3, encryptionDetails)
        {
        }

        private static byte[] constructEncryptionBlockData(OsdpEncryptionDetails encryptionDetails)
        {
            byte[] encryptionBlockData = new byte[1] { 1 };
            if (encryptionDetails.EncryptionKey == OsdpEncryptionDetails.DefaultEncryptionKey
#if DEBUG
                 || encryptionDetails.EncryptionKey.SequenceEqual(OsdpEncryptionDetails.DefaultEncryptionKey)
#endif
)
            {
                encryptionBlockData[0] = 0;
            }
            return encryptionBlockData;
        }
    }
}
