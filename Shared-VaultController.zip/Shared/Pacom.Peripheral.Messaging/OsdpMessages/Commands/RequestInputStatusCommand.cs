﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_ISTAT - Input Status Report Request
    // Instructs the PD to reply with an input status report.
    // Command Structure: None
    // Reply: osdp_ISTATR - Input Status Reply
    public class RequestInputStatusCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0x65;

        public RequestInputStatusCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 0, encryptionDetails)
        {
        }

        public RequestInputStatusCommand(int address, int sequence, bool useCrc)
            : base(address, sequence, useCrc, FunctionCode, null)
        {
        }

        public RequestInputStatusCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails)
            : base(address, sequence, useCrc, FunctionCode, null, null, OsdpSecurityBlockType.DoorControllerToReaderNoData, encryptionDetails)
        {
        }
    }
}