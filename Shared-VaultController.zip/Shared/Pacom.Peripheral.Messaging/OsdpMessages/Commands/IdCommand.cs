﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_ID - ID Report Request
    // This command requests the return of the PD ID Report. The id request code parameter may request 
    // the extended form of the PD ID block.
    // Command structure: 1-byte id request code
    public class IdCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0x61;

        public IdCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 1, encryptionDetails)
        {
        }

        public IdCommand(int address, int sequence, bool useCrc)
            : base(address, sequence, useCrc, FunctionCode, new byte[1] { 0 })
        {
        }

        public IdCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails)
            : base(address, sequence, useCrc, FunctionCode, new byte[1] { 0 }, null, OsdpSecurityBlockType.DoorControllerToReader, encryptionDetails)
        {
        }
    }
}