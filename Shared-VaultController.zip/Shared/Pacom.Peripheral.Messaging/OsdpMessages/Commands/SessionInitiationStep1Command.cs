﻿using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_CHLNG - Challenge and Secure Session Initialization Rq.
    // This command is the first in the Secure Channel Session Connection Sequence (SCS-CS). It delivers 
    // a random challenge to the PD and it requests the PD to initialize for the secure session.
    // Command structure: 8-byte random number as the "challenge"
    public class SessionInitiationStep1Command : OsdpMessageBase
    {
        public const int FunctionCode = 0x76;

        public SessionInitiationStep1Command(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 1, encryptionDetails)
        {
        }

        public SessionInitiationStep1Command(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails)
            : base(address, sequence, useCrc, FunctionCode, encryptionDetails.RandomNumberA, constructEncryptionBlockData(encryptionDetails), OsdpSecurityBlockType.SessionInitiationStep1, encryptionDetails)
        {
        }

        private static byte[] constructEncryptionBlockData(OsdpEncryptionDetails encryptionDetails)
        {
            byte[] encryptionBlockData = new byte[1] { 1 };
            if (encryptionDetails.EncryptionKey == OsdpEncryptionDetails.DefaultEncryptionKey)
            {
                encryptionBlockData[0] = 0;
            }
            return encryptionBlockData;
        }
    }
}