﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_LED - Reader Led Control Command
    // The Reader LED Control command controls the operation of the LEDs associated with a reader. (This 
    // command supports the model where multiple LEDs may be associated with a reader.) Color and flash 
    // parameters may be specified.
    // Once the temporary command's timer expires the LED will revert to the last permanent state set. A
    // timer value of zero specifies zero duration.
    // The permanent command is volatile (does not transcend power cycles). 
    // Command structure: 14-byte records, repeated 1 or more times
    public class LedSetCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0x69;

        public LedSetCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 14, encryptionDetails)
        {
        }

        public LedSetCommand(int address, int sequence, bool useCrc, LedInstruction[] instructions)
            : base(address, sequence, useCrc, FunctionCode, constructData(instructions))
        {
        }

        public LedSetCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, LedInstruction[] instructions)
            : base(address, sequence, useCrc, FunctionCode, constructData(instructions), null, OsdpSecurityBlockType.DoorControllerToReader, encryptionDetails)
        {
        }

        private static byte[] constructData(LedInstruction[] instructions)
        {
            byte[] data = new byte[14 * instructions.Length];
            for (int i = 0; i < instructions.Length; i++)
            {
                data[i * 14] = 0; // Hardcoded to Reader 0
                data[(i * 14) + 1] = (byte)instructions[i].LedNumber;
                data[(i * 14) + 2] = (byte)instructions[i].Instruction;
                data[(i * 14) + 3] = (byte)(instructions[i].TemporaryOnTime.TotalMilliseconds / 100);
                data[(i * 14) + 4] = (byte)(instructions[i].TemporaryOffTime.TotalMilliseconds / 100);
                data[(i * 14) + 5] = (byte)instructions[i].TemporaryOnColor;
                data[(i * 14) + 6] = (byte)instructions[i].TemporaryOffColor;
                int duration = (int)(instructions[i].TemporaryDuration.TotalMilliseconds / 100);
                data[(i * 14) + 7] = (byte)(duration & 0xFF);
                data[(i * 14) + 8] = (byte)((duration & 0xFF00) >> 8);
                if (instructions[i].IncludePermanentSettings)
                    data[(i * 14) + 9] = 1;
                else
                    data[(i * 14) + 9] = 0;
                data[(i * 14) + 10] = (byte)(instructions[i].OnTime.TotalMilliseconds / 100);
                data[(i * 14) + 11] = (byte)(instructions[i].OffTime.TotalMilliseconds / 100);
                data[(i * 14) + 12] = (byte)instructions[i].OnColor;
                data[(i * 14) + 13] = (byte)instructions[i].OffColor;
            }
            return data;
        }

        public LedInstruction[] Instructions
        {
            get
            {
                LedInstruction[] instructions = new LedInstruction[DataLength / 14];
                for (int i = 0; i < instructions.Length; i++)
                {
                    instructions[i] = new LedInstruction();
                    instructions[i].LedNumber = message[DataOffset + ((14 * i) + 1)];
                    instructions[i].Instruction = (LedInstructionType)message[DataOffset + ((14 * i) + 2)];
                    instructions[i].TemporaryOnTime = new TimeSpan(0, 0, 0, 0, message[DataOffset + ((14 * i) + 3)] * 100);
                    instructions[i].TemporaryOffTime = new TimeSpan(0, 0, 0, 0, message[DataOffset + ((14 * i) + 4)] * 100);
                    instructions[i].TemporaryOnColor = (LedColor)message[DataOffset + ((14 * i) + 5)];
                    instructions[i].TemporaryOffColor = (LedColor)message[DataOffset + ((14 * i) + 6)];
                    int duration = (message[DataOffset + ((14 * i) + 8)] << 8) | message[DataOffset + ((14 * i) + 7)];
                    instructions[i].TemporaryDuration = new TimeSpan(0, 0, 0, 0, duration * 100);
                    if (message[DataOffset + ((14 * i) + 9)] == 0)
                        instructions[i].IncludePermanentSettings = false;
                    else
                        instructions[i].IncludePermanentSettings = true;
                    instructions[i].OnTime = new TimeSpan(0, 0, 0, 0, message[DataOffset + ((14 * i) + 10)] * 100);
                    instructions[i].OffTime = new TimeSpan(0, 0, 0, 0, message[DataOffset + ((14 * i) + 11)] * 100);
                    instructions[i].OnColor = (LedColor)message[DataOffset + ((14 * i) + 12)];
                    instructions[i].OffColor = (LedColor)message[DataOffset + ((14 * i) + 13)];
                }
                return instructions;
            }
        }
    }
}