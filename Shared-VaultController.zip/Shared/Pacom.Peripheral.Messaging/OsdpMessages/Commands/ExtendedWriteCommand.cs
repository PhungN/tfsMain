﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;
using System.Text;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_XWR - Extended Write Command
    // Command Structure: 2 byte command structure, followed by an optional data block.
    public class ExtendedWriteCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0xA1;

        public ExtendedWriteCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 3, encryptionDetails)
        {
        }

        public ExtendedWriteCommand(int address, int sequence, bool useCrc, byte[] command)
            : base(address, sequence, useCrc, FunctionCode, constructData(command))
        {
        }

        public ExtendedWriteCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, byte[] command)
            : base(address, sequence, useCrc, FunctionCode, constructData(command), null, OsdpSecurityBlockType.DoorControllerToReader, encryptionDetails)
        {
        }

        private static byte[] constructData(byte[] command)
        {
            byte[] data = new byte[command.Length + 3];
            data[0] = 1; // Transparent Smart Card Interface
            data[1] = 1; // Reader Apdu
            data[2] = 0; // Hardcoded to Reader 0
            Buffer.BlockCopy(command, 0, data, 3, command.Length);
            return data;
        }

        public byte[] Command
        {
            get
            {
                byte[] command = new byte[DataLength - 3];
                Buffer.BlockCopy(message, DataOffset + 3, command, 0, command.Length);
                return command;
            }
        }
    }
}