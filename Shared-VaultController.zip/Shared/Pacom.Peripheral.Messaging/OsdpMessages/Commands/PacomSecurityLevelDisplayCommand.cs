﻿using System;
using System.Text;
using System.Collections.Generic;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.OsdpMessaging
{
    /// <summary>
    /// PACOM Manufacturer specific command
    /// </summary>
    public class PacomSecurityLevelDisplayCommand : ManufacturerSpecificCommand
    {
        public PacomSecurityLevelDisplayCommand(int address, int sequence, bool useCrc, SecurityLevelDisplayCommand securityLevel, TimeSpan duration, string text)
            : base(address, sequence, useCrc, ReaderManufacturer.Pacom, constructCommand(securityLevel, duration, text))
        {
        }

        public PacomSecurityLevelDisplayCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, SecurityLevelDisplayCommand securityLevel, TimeSpan duration, string text)
            : base (address, sequence, useCrc, encryptionDetails, ReaderManufacturer.Pacom, constructCommand(securityLevel, duration, text))
        {
        }

        private static byte[] constructCommand(SecurityLevelDisplayCommand securityLevel, TimeSpan duration, string text)
        {
            int textLength = string.IsNullOrEmpty(text) ? 0 : text.Length;
            PresentationMode presentationMode = PresentationMode.EnableIcon | PresentationMode.EnableText;
            int durationInSeconds = (int)duration.TotalSeconds;

            byte [] command = new byte[5 + textLength + 1];
            command[0] = (byte)securityLevel;           // Security level command
            command[1] = (byte)presentationMode;        // Presentation Mode
            command[2] = 0;                             // The language to use for the security level, or zero to use the configured language.
            if (durationInSeconds > 127)                // Display duration
                command[3] = (byte)((byte)duration.TotalMinutes | 0x80);
            else
                command[3] = (byte)durationInSeconds;   
            command[4] = 0;                             // Additional data for the set security level, or 0 if unused.
            if (textLength > 0)
                Array.Copy(Encoding.ASCII.GetBytes(text), 0, command, 5, textLength);
            return command;
        }
    }
}
