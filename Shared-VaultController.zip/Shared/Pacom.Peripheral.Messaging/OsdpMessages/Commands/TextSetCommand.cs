﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;
using System.Text;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_TEXT - Text Output Command
    // This command defines a string to be shown on a simple character oriented text display organized in a 
    // row and column format.
    // Text will be written at the given starting position. If necessary, and if allowed by the command, the 
    // text may wrap to the next line.
    // Temporary text, overwrites a text field for a specified time period after which the permanent text field 
    // is restored.
    // The "temp text time" field indicates the duration of the temp display in seconds. This field has a 
    // different meaning when used with a permanent text command. In that case, if the temp text time is 
    // zero then any active temp text shall be allowed to complete. A non-zero temp text time means that 
    // any active temp text shall be aborted and the permanent text shall be displayed immediately.
    // At a minimum, the PD must implement the printable ASCII character set, ranging from 0x20 to 0x7E.
    // The permanent command is volatile (does not transcend power cycles).Command Structure: 
    // variable-length data with a fixed 6-byte header
    // Note: Commands issued to elements that are non-existent, will receive a NAK response.
    public class TextSetCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0x6B;

        public TextSetCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 6, encryptionDetails)
        {
        }

        public TextSetCommand(int address, int sequence, bool useCrc, TextType textType, TimeSpan temporaryTextDuration, int oneBasedRow, int oneBasedColumn, string text)
            : base(address, sequence, useCrc, FunctionCode, constructData(textType, temporaryTextDuration, oneBasedRow, oneBasedColumn, text))
        {
        }

        public TextSetCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, TextType textType, TimeSpan temporaryTextDuration, int oneBasedRow, int oneBasedColumn, string text)
            : base(address, sequence, useCrc, FunctionCode, constructData(textType, temporaryTextDuration, oneBasedRow, oneBasedColumn, text), null, OsdpSecurityBlockType.DoorControllerToReader, encryptionDetails)
        {
        }

        private static byte[] constructData(TextType textType, TimeSpan temporaryTextDuration, int oneBasedRow, int oneBasedColumn, string text)
        {
            byte[] data = new byte[6 + text.Length];
            data[0] = 0; // Hardcoded to Reader 0
            data[1] = (byte)textType;
            data[2] = (byte)temporaryTextDuration.TotalSeconds;
            data[3] = (byte)oneBasedRow;
            data[4] = (byte)oneBasedColumn;
            data[5] = (byte)text.Length;
            for (int i = 0; i < text.Length; i++)
            {
                data[6 + i] = (byte)text[i];
            }
            return data;
        }

        public TextType TextType
        {
            get
            {
                return (TextType)message[DataOffset + 1];
            }
        }

        public TimeSpan TemporaryTextDuration
        {
            get
            {
                return new TimeSpan(0, 0, message[DataOffset + 2]);
            }
        }

        public int OneBasedRow
        {
            get
            {
                return message[DataOffset + 3];
            }
        }

        public int OneBasedColumn
        {
            get
            {
                return message[DataOffset + 4];
            }
        }

        public string Text
        {
            get
            {
                return ASCIIEncoding.ASCII.GetString(message, DataOffset + 6, message[DataOffset + 5]);
            }
        }
    }
}