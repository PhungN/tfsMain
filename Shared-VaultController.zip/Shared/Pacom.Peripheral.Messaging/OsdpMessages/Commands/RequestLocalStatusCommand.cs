﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_LSTAT - Local Status Report Request
    // Instructs the PD to reply with a local status report.
    // Command Structure: None
    // Reply: osdp_LSTATR - Local Status Reply
    public class RequestLocalStatusCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0x64;

        public RequestLocalStatusCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 0, encryptionDetails)
        {
        }

        public RequestLocalStatusCommand(int address, int sequence, bool useCrc)
            : base(address, sequence, useCrc, FunctionCode, null)
        {
        }

        public RequestLocalStatusCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails)
            : base(address, sequence, useCrc, FunctionCode, null, null, OsdpSecurityBlockType.DoorControllerToReaderNoData, encryptionDetails)
        {
        }
    }
}