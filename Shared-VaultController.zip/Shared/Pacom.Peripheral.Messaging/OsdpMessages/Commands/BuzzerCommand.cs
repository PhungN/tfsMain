﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_BUZ - Reader Buzzer Control Command
    // This command defines commands to a single, monotone audible annunciator (beeper or buzzer) that 
    // may be associated with a reader.
    // The permanent command is volatile (does not transcend power cycles).  Command structure: 5-byte 
    // record.
    public class BuzzerCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0x6A;

        public BuzzerCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 5, encryptionDetails)
        {
        }

        public BuzzerCommand(int address, int sequence, bool useCrc, Tone tone, TimeSpan onTime, TimeSpan offTime, int count)
            : base(address, sequence, useCrc, FunctionCode, constructData(tone, onTime, offTime, count))
        {
        }

        public BuzzerCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, Tone tone, TimeSpan onTime, TimeSpan offTime, int count)
            : base(address, sequence, useCrc, FunctionCode, constructData(tone, onTime, offTime, count), null, OsdpSecurityBlockType.DoorControllerToReader, encryptionDetails)
        {
        }

        private static byte[] constructData(Tone tone, TimeSpan onTime, TimeSpan offTime, int count)
        {
            byte[] data = new byte[5];
            data[0] = 0; // Hardcoded to Reader 0
            data[1] = (byte)tone;
            data[2] = (byte)(onTime.TotalMilliseconds / 100);
            data[3] = (byte)(offTime.TotalMilliseconds / 100);
            data[4] = (byte)count;
            return data;
        }

        public Tone Tone
        {
            get
            {
                return (Tone)message[DataOffset + 1];
            }
        }

        public TimeSpan OnTime
        {
            get
            {
                return new TimeSpan(0, 0, 0, 0, (message[DataOffset + 2] * 100));
            }
        }

        public TimeSpan OffTime
        {
            get
            {
                return new TimeSpan(0, 0, 0, 0, (message[DataOffset + 3] * 100));
            }
        }

        public int Count
        {
            get
            {
                return message[DataOffset + 4];
            }
        }
    }
}