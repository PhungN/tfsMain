﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_POLL - Poll
    // This command serves as a general inquiry. The PD may return any reply that is marked as a possible 
    // "poll response". Normally, the PD will return any unreported input data or status change information 
    // as a poll response.
    // Command structure: None
    // Reply: Any of the Reply messages marked "poll response".
    public class PollCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0x60;

        public PollCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 0, encryptionDetails)
        {
        }

        public PollCommand(int address, int sequence, bool useCrc)
            : base(address, sequence, useCrc, FunctionCode, null)
        {
        }

        public PollCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails)
            : base(address, sequence, useCrc, FunctionCode, null, null, OsdpSecurityBlockType.DoorControllerToReaderNoData, encryptionDetails)
        {
        }
    }
}