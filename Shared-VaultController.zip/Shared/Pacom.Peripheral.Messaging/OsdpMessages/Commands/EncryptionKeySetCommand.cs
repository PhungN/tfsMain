﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;
using System.Text;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_KEYSET - Encryption Key Set Command
    // This command transfers an encryption key from the CP to a PD.
    // Command structure: 2-byte header followed by variable length data
    public class EncryptionKeySetCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0x75;

        public EncryptionKeySetCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 18, encryptionDetails)
        {
        }

        public EncryptionKeySetCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, byte[] key)
            : base(address, sequence, useCrc, FunctionCode, constructData(key), null, OsdpSecurityBlockType.DoorControllerToReader, encryptionDetails)
        {
        }

        private static byte[] constructData(byte[] key)
        {
            byte[] data = new byte[18];
            data[0] = 1;
            data[1] = 16;
            Buffer.BlockCopy(key, 0, data, 2, 16);
            return data;
        }

        public byte[] Key
        {
            get
            {
                byte[] key = new byte[16];
                Buffer.BlockCopy(message, DataOffset + 2, key, 0, 16);
                return key;
            }
        }
    }
}