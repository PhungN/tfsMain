﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_OSTAT - Output Status Report Request
    // Instructs the PD to reply with an output status report.
    // Command Structure: None 
    // Reply: osdp_OSTATR Output Status Reply
    public class RequestOutputStatusCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0x66;

        public RequestOutputStatusCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 0, encryptionDetails)
        {
        }

        public RequestOutputStatusCommand(int address, int sequence, bool useCrc)
            : base(address, sequence, useCrc, FunctionCode, null)
        {
        }

        public RequestOutputStatusCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails)
            : base(address, sequence, useCrc, FunctionCode, null, null, OsdpSecurityBlockType.DoorControllerToReaderNoData, encryptionDetails)
        {
        }
    }
}