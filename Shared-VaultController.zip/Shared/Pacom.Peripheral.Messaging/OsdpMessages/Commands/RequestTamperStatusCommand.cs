﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_RSTAT - Reader Status Report Request
    // Instructs the PD to reply with a reader status report.
    // Command Structure: None
    // Reply: osdp_RSTATR - Reader Status Reply
    public class RequestTamperStatusCommand : OsdpMessageBase
    {
        public const int FunctionCode = 0x67;

        public RequestTamperStatusCommand(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 0, encryptionDetails)
        {
        }

        public RequestTamperStatusCommand(int address, int sequence, bool useCrc)
            : base(address, sequence, useCrc, FunctionCode, null)
        {
        }

        public RequestTamperStatusCommand(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails)
            : base(address, sequence, useCrc, FunctionCode, null, null, OsdpSecurityBlockType.DoorControllerToReaderNoData, encryptionDetails)
        {
        }
    }
}