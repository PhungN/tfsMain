﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_LSTATR - Local Status Report
    // Sent in response to an osdp_LSTAT command or as a "poll response"
    // The local status report applies to conditions directly monitored by the PD. T amper status is detected 
    // by the PD by monitoring the enclosure tamper mechanism. Power monitor status can be derived from 
    // the status of the power supply. Normally this reply is sent in response to an osdp_POLL command if 
    // either status has changed since the last POLL.
    // Reply Structure: 2 status bytes
    public class LocalStatusReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x48;

        public LocalStatusReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 2, encryptionDetails)
        {
        }

        public LocalStatusReply(int address, int sequence, bool useCrc, bool tamperActive, bool powerFail)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(tamperActive, powerFail))
        {
        }

        public LocalStatusReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, bool tamperActive, bool powerFail)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(tamperActive, powerFail), null, OsdpSecurityBlockType.ReaderToDoorController, encryptionDetails)
        {
        }

        private static byte[] constructData(bool tamperActive, bool powerFail)
        {
            byte[] data = new byte[2];
            if (tamperActive)
                data[0] = 1;
            if (powerFail)
                data[1] = 1;
            return data;
        }

        public bool TamperActive
        {
            get
            {
                if (message[DataOffset] == 0)
                    return false;
                return true;
            }
        }

        public bool PowerFail
        {
            get
            {
                if (message[DataOffset + 1] == 0)
                    return false;
                return true;
            }
        }
    }
}