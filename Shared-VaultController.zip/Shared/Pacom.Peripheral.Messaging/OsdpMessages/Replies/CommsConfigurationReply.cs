﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_COM - PD Communications Configuration Report
    // Sent in response to an osdp_COMSET command.
    // This reply returns the communication parameters the PD will use after sending this reply.
    // Reply Structure: 5-byte record
    public class CommsConfigurationReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x54;

        public CommsConfigurationReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 5, encryptionDetails)
        {
        }

        public CommsConfigurationReply(int address, int sequence, bool useCrc, int baudRate)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(address, baudRate))
        {
        }

        public CommsConfigurationReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, int baudRate)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(address, baudRate), null, OsdpSecurityBlockType.ReaderToDoorController, encryptionDetails)
        {
        }

        private static byte[] constructData(int address, int baudRate)
        {
            byte[] data = new byte[5];
            data[0] = (byte)address;
            data[1] = (byte)(baudRate & 0xFF);
            data[2] = (byte)((baudRate & 0xFF00) >> 8);
            data[3] = (byte)((baudRate & 0xFF0000) >> 16);
            data[4] = (byte)((baudRate & 0xFF000000) >> 24);
            return data;
        }

        public int BaudRate
        {
            get
            {
                return (((((message[DataOffset + 4] << 8) | message[DataOffset + 3]) << 8) | message[DataOffset + 2]) << 8) | message[DataOffset + 1];
            }
        }
    }
}