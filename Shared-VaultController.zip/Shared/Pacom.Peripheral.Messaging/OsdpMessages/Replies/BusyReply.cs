﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_BUSY - PD is Busy reply
    // Sent in response to an osdp command if the PD is busy processing the previous command. This reply 
    // will use either checksum or CRC for message integrity even if the secure channel has been 
    // established and commands are exchanged using secure messaging. In other words, the busy reply is 
    // sent outside the secure channel and should not influence the secured messages that are sent before 
    // or after this reply.
    // The osdp_ACK is the appropriate response if the data requested by the command is not immediately 
    // available but will be returned in response to a subsequent osdp_POLL. Otherwise (meaning that a 
    // specific non-ACK response is required and the data is not available in time to meet the 
    // REPLY_TIMEOUT), the PD responds with osdp_BUSY until it is able to return the requested data. In 
    // this case, the CP shall continue to repeat the command in its original form until the PD returns 
    // something other than osdp_BUSY.
    // The sequence number of this reply will always be set to 0.
    public class BusyReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x79;

        public BusyReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 0, encryptionDetails)
        {
        }

        public BusyReply(int address, bool useCrc)
            : base(0x80 | address, 0, useCrc, FunctionCode, null)
        {
        }
    }
}