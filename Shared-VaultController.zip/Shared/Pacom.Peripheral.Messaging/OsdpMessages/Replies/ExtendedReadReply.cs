﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;
using System.Text;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_XRD - Extended Read Reply
    // Sent in response to an osdp_XWR command, or as a “poll response”.
    // Reply Structure: 2 byte reply structure, followed by an optional data block.
    public class ExtendedReadReply : OsdpMessageBase
    {
        public const int FunctionCode = 0xB1;

        public ExtendedReadReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 2, encryptionDetails)
        {
        }

        public ExtendedReadReply(int address, int sequence, bool useCrc, ExtendedProfileType profileType, byte[] profileData)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(profileType, profileData))
        {
        }

        public ExtendedReadReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, ExtendedProfileType profileType, byte[] profileData)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(profileType, profileData), null, OsdpSecurityBlockType.ReaderToDoorController, encryptionDetails)
        {
        }

        private static byte[] constructData(ExtendedProfileType profileType, byte[] profileData)
        {
            byte[] data = new byte[profileData.Length + 2];
            data[0] = 1; // Transparent Smart Card Interface
            data[1] = (byte)profileType;
            Buffer.BlockCopy(profileData, 0, data, 2, profileData.Length);
            return data;
        }

        public ExtendedProfileType ProfileType
        {
            get
            {
                int dataOffset = DataOffset;
                if (message[dataOffset] == 1 && message[dataOffset + 1] >= 1 && message[dataOffset + 1] <= 3)
                    return (ExtendedProfileType)message[dataOffset + 1];
                else if (message[dataOffset + 1] == 1)
                    return ExtendedProfileType.CurrentProfile;
                return ExtendedProfileType.GeneralError;
            }
        }

        public byte[] ProfileData
        {
            get
            {
                byte[] profileData = new byte[DataLength - 2];
                Buffer.BlockCopy(message, DataOffset + 2, profileData, 0, profileData.Length);
                return profileData;
            }
        }
    }
}