﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;
using System.Collections.Generic;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_PDCAP - PD Capabilities Report
    // Sent in response to an osdp_CAP command
    // Reply Structure: 3-byte element, repeated one or more times
    public class CapabilitiesReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x46;

        public CapabilitiesReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 3, encryptionDetails)
        {
        }

        public CapabilitiesReply(int address, int sequence, bool useCrc, Dictionary<FeatureCode, Capability> capabilities)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(capabilities))
        {
        }

        public CapabilitiesReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, Dictionary<FeatureCode, Capability> capabilities)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(capabilities), null, OsdpSecurityBlockType.ReaderToDoorController, encryptionDetails)
        {
        }

        private static byte[] constructData(Dictionary<FeatureCode, Capability> capabilities)
        {
            byte[] data = new byte[3 * capabilities.Count];
            int i = 0;
            foreach(KeyValuePair<FeatureCode, Capability> feature in capabilities)
            {
                data[(3 * i)] = (byte)feature.Key;
                data[(3 * i) + 1] = (byte)feature.Value.Compliance;
                data[(3 * i) + 2] = (byte)feature.Value.Count;
                i++;
            }
            return data;
        }

        public Dictionary<FeatureCode, Capability> Capabilities
        {
            get
            {
                int count = DataLength / 3;
                int dataOffset = DataOffset;
                Dictionary<FeatureCode, Capability> capabilities = new Dictionary<FeatureCode, Capability>(count);
                for (int i = 0; i < count; i++)
                {
                    capabilities[(FeatureCode)message[dataOffset + (3 * i)]] = new Capability(message[dataOffset + ((3 * i) + 1)], message[dataOffset + ((3 * i) + 2)]);
                }
                return capabilities;
            }
        }
    }
}