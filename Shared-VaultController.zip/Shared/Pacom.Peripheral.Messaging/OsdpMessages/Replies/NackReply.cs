﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_NAK - Command not processed
    public class NackReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x41;

        public NackReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 1, encryptionDetails)
        {
        }

        public NackReply(int address, int sequence, bool useCrc, NackErrorCode errorCode)
            : base(0x80 | address, sequence, useCrc, FunctionCode, new byte[1] { (byte)errorCode })
        {
        }

        public NackReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, NackErrorCode errorCode)
            : base(0x80 | address, sequence, useCrc, FunctionCode, new byte[1] { (byte)errorCode }, null, OsdpSecurityBlockType.ReaderToDoorController, encryptionDetails)
        {
        }

        public NackErrorCode Error
        {
            get
            {
                return (NackErrorCode)message[DataOffset];
            }
        }
    }
}