﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_ACK - Command accepted, nothing else to report
    // There is no reply structure associated with this reply. Sent in response to all valid commands that do 
    // not require a specific response or will not receive an immediate response. 
    public class AckReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x40;

        public AckReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 0, encryptionDetails)
        {
        }

        public AckReply(int address, int sequence, bool useCrc)
            : base(0x80 | address, sequence, useCrc, FunctionCode, null)
        {
        }

        public AckReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails)
            : base(0x80 | address, sequence, useCrc, FunctionCode, null, null, OsdpSecurityBlockType.ReaderToDoorControllerNoData, encryptionDetails)
        {
        }
    }
}