﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_RAW - Reader Data – Raw bit image of card data
    // Sent as a "poll response"
    // This reply is sent in response to an osdp_POLL command after a card was read but the raw data was 
    // not decoded into a character array.
    // Unreported card data is deleted in case of, or during, a communication loss. 
    // Reply structure: 4-byte header, variable-length data
    public class RawCardReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x50;

        public RawCardReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 4, encryptionDetails)
        {
        }

        public RawCardReply(int address, int sequence, bool useCrc, int bitCount, byte[] cardData)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(bitCount, cardData))
        {
        }

        public RawCardReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, int bitCount, byte[] cardData)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(bitCount, cardData), null, OsdpSecurityBlockType.ReaderToDoorController, encryptionDetails)
        {
        }

        private static byte[] constructData(int bitCount, byte[] cardData)
        {
            byte[] data = new byte[cardData.Length + 4];
            data[0] = 0; // Hardcoded to Reader 0
            data[1] = 0; // Raw bit array
            data[2] = (byte)(bitCount & 0xFF);
            data[3] = (byte)((bitCount & 0xFF00) >> 8);
            Buffer.BlockCopy(cardData, 0, data, 4, cardData.Length);
            return data;
        }

        public int BitCount
        {
            get
            {
                return (((message[DataOffset + 3]) << 8) | message[DataOffset + 2]);
            }
        }

        public byte[] CardData
        {
            get
            {
                byte[] data = new byte[DataLength - 4];
                Buffer.BlockCopy(message, DataOffset + 4, data, 0, data.Length);
                return data;
            }
        }
    }
}