﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_RSTATR - Reader Status Report
    // Sent in response to an osdp_RSTAT command or as a "poll response"
    // Normally, this reply is sent in response to an osdp_POLL if the status of any of the readers has 
    // changed since the last report. The tamper status of all readers will be returned in this reply. The 
    // array size is defined by the total message length. The order of the Status Bytes corresponds to the 
    // numbering of the readers, e.g. the first Status Byte corresponds to the first reader , etc.
    // The reader tamper is applicable only in cases where an external reader is attached to the PD, and the 
    // PD is able to monitor the status of the attached reader. (Certain readers can send periodic status 
    // messages.)
    // Reply Structure: 1 status byte for each reader
    public class TamperStatusReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x4B;

        public TamperStatusReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 1, encryptionDetails)
        {
        }

        public TamperStatusReply(int address, int sequence, bool useCrc, bool tamperActive)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(tamperActive))
        {
        }

        public TamperStatusReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, bool tamperActive)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(tamperActive), null, OsdpSecurityBlockType.ReaderToDoorController, encryptionDetails)
        {
        }

        private static byte[] constructData(bool tamperActive)
        {
            byte[] data = new byte[1];
            if (tamperActive)
                data[0] = 2;
            return data;
        }

        public bool TamperActive
        {
            get
            {
                if (message[DataOffset] == 2)
                    return true;
                return false;
            }
        }
    }
}