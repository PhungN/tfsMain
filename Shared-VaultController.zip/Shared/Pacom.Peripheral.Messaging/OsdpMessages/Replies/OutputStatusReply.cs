﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_OSTATR - Output Status Report
    // Sent in response to an osdp_OSTAT command, an osdp_OUT command or as a "poll response"
    // Normally, this response is sent as a reply to an osdp_OUT command to indicate that the output(s) 
    // have changed state.
    // This reply can also be sent in response to an osdp_POLL if the status of any of the outputs has 
    // changed since the last report. The status of all outputs will be returned in this reply. The array size is 
    // defined by the total message length. The order of the Status Bytes corresponds to the numbering of 
    // the outputs, e.g. the first Status Byte corresponds to the first output, etc.
    // Reply Structure: 1 status byte for each output 
    public class OutputStatusReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x4A;

        public OutputStatusReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 0, encryptionDetails)
        {
        }

        public OutputStatusReply(int address, int sequence, bool useCrc, bool[] activeOutputs)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(activeOutputs))
        {
        }

        public OutputStatusReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, bool[] activeOutputs)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(activeOutputs), null, OsdpSecurityBlockType.ReaderToDoorController, encryptionDetails)
        {
        }

        private static byte[] constructData(bool[] activeOutputs)
        {
            byte[] data = new byte[activeOutputs.Length];
            for (int i = 0; i < activeOutputs.Length; i++)
            {
                if (activeOutputs[i])
                    data[i] = 1;
            }
            return data;
        }

        public bool[] ActiveOutputs
        {
            get
            {
                bool[] activeOutputs = new bool[DataLength];
                for (int i = 0; i < activeOutputs.Length; i++)
                {
                    if (message[DataOffset + i] != 0)
                        activeOutputs[i] = true;
                }
                return activeOutputs;
            }
        }
    }
}