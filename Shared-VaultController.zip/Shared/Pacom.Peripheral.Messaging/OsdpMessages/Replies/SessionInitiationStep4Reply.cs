﻿using System;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_RMAC_I - Initial R-MAC
    // This command transfers a block of data used for encryption synchronization, send in response to 
    // osdp_SCRYPT.
    // Command structure: 16-byte structure
    public class SessionInitiationStep4Reply : OsdpMessageBase
    {
        public const int FunctionCode = 0x78;

        public SessionInitiationStep4Reply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 16, encryptionDetails)
        {
        }

        public SessionInitiationStep4Reply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, byte[] initialMac)
            : base(0x80 | address, sequence, useCrc, FunctionCode, initialMac, constructEncryptionBlockData(encryptionDetails), OsdpSecurityBlockType.SessionInitiationStep4, encryptionDetails)
        {
        }

        private static byte[] constructEncryptionBlockData(OsdpEncryptionDetails encryptionDetails)
        {
            byte[] encryptionBlockData = new byte[1] { 1 };
            if (encryptionDetails.EncryptionKey == OsdpEncryptionDetails.DefaultEncryptionKey
#if DEBUG
                 || encryptionDetails.EncryptionKey.SequenceEqual(OsdpEncryptionDetails.DefaultEncryptionKey)
#endif
)
            {
                encryptionBlockData[0] = 0;
            }
            return encryptionBlockData;
        }

        public byte[] ReplyMac
        {
            get
            {
                byte[] data = new byte[16];
                Buffer.BlockCopy(message, DataOffset, data, 0, 16);
                return data;
            }
        }

        public bool ReplyMacValid(OsdpEncryptionDetails encryptionDetails)
        {
            return encryptionDetails.SendingMac.SequenceEqual(message, DataOffset, 16);
        }
    }
}