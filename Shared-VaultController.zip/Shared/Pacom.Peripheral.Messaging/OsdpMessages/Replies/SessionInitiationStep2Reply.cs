﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_CCRYPT - Client's ID, Random Number, and Cryptogram
    // This reply sends a block of data used for encryption synchronization, sent in response to 
    // osdp_CHLNG command.
    // Command structure: 32-byte structure
    public class SessionInitiationStep2Reply : OsdpMessageBase
    {
        public const int FunctionCode = 0x76;

        public SessionInitiationStep2Reply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 32, encryptionDetails)
        {
        }

        public SessionInitiationStep2Reply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, ReaderManufacturer vendor, int model, int version, int serialNumber, byte[] randomB, byte[] clientCryptogram)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(vendor, model, version, serialNumber, randomB, clientCryptogram), constructEncryptionBlockData(encryptionDetails), OsdpSecurityBlockType.SessionInitiationStep2, encryptionDetails)
        {
        }

        private static byte[] constructEncryptionBlockData(OsdpEncryptionDetails encryptionDetails)
        {
            byte[] encryptionBlockData = new byte[1] { 1 };
            if (encryptionDetails.EncryptionKey == OsdpEncryptionDetails.DefaultEncryptionKey
#if DEBUG
                 || encryptionDetails.EncryptionKey.SequenceEqual(OsdpEncryptionDetails.DefaultEncryptionKey)
#endif
)
            {
                encryptionBlockData[0] = 0;
            }
            return encryptionBlockData;
        }

        private static byte[] constructData(ReaderManufacturer vendor, int model, int version, int serialNumber, byte[] randomB, byte[] clientCryptogram)
        {
            byte[] data = new byte[32];
            SetVendorBytes(vendor, data, 0);

            data[3] = (byte)model;
            data[4] = (byte)version;
            data[5] = (byte)(serialNumber & 0xFF);
            data[6] = (byte)((serialNumber & 0xFF00) >> 8);
            data[7] = (byte)((serialNumber & 0xFF0000) >> 16);
            Buffer.BlockCopy(randomB, 0, data, 8, 8);
            Buffer.BlockCopy(clientCryptogram, 0, data, 16, 16);
            return data;
        }

        public ReaderManufacturer Vendor
        {
            get
            {
                return GetVendor(message, DataOffset);
            }
        }

        public int Model
        {
            get
            {
                return message[DataOffset + 3];
            }
        }

        public int Version
        {
            get
            {
                return message[DataOffset + 4];
            }
        }

        public int PartialSerialNumber
        {
            get
            {
                return (((message[DataOffset + 7] << 8) | message[DataOffset + 6]) << 8) | message[DataOffset + 5];
            }
        }

        public byte[] RandomB
        {
            get
            {
                byte[] data = new byte[8];
                Buffer.BlockCopy(message, DataOffset + 8, data, 0, 8);
                return data;
            }
        }

        public byte[] ClientCryptogram
        {
            get
            {
                byte[] data = new byte[16];
                Buffer.BlockCopy(message, DataOffset + 16, data, 0, 16);
                return data;
            }
        }
    }
}