﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_KEYPAD - Keypad Data
    // Sent as a "poll response"
    // This reply is sent in response to an osdp_POLL if there is any data in the keypad buffer. It is applied 
    // when the keypad is in default operating mode.
    // Unreported keypad data is deleted in case of, or during, a communication loss.
    public class KeyPressReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x53;

        public KeyPressReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 2, encryptionDetails)
        {
        }

        public KeyPressReply(int address, int sequence, bool useCrc, KeypadKeys[] pressedKeys)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(pressedKeys))
        {
        }

        public KeyPressReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, KeypadKeys[] pressedKeys)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(pressedKeys), null, OsdpSecurityBlockType.ReaderToDoorController, encryptionDetails)
        {
        }

        private static byte[] constructData(KeypadKeys[] pressedKeys)
        {
            byte[] data = new byte[pressedKeys.Length + 2];
            data[0] = 0; // Hardcoded to Reader 0
            data[1] = (byte)pressedKeys.Length;
            for (int i = 0; i < pressedKeys.Length; i++)
            {
                data[2 + i] = (byte)pressedKeys[i];
            }
            return data;
        }

        public KeypadKeys[] PressedKeys
        {
            get
            {
                KeypadKeys[] pressedKeys = new KeypadKeys[DataLength - 2];
                for (int i = 0; i < pressedKeys.Length; i++)
                {
                    pressedKeys[i] = (KeypadKeys)message[DataOffset + 2 + i];
                }
                return pressedKeys;
            }
        }
    }
}