﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_ISTATR - Input Status Report
    // Sent in response to an osdp_ISTAT command or as a "poll response"
    // Normally, this reply is sent in response to an osdp_POLL command if the status of any of the inputs 
    // has changed since the last report. The status of all inputs will be returned in this reply. The array size 
    // is defined by the total message length. The order of the Status Bytes corresponds to the numbering 
    // of the inputs, e.g. the first Status Byte corresponds to the first input, etc.
    // Reply Structure: 1 status byte for each input
    public class InputStatusReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x49;

        public InputStatusReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 0, encryptionDetails)
        {
        }

        public InputStatusReply(int address, int sequence, bool useCrc, bool[] activeInputs)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(activeInputs))
        {
        }

        public InputStatusReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, bool[] activeInputs)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(activeInputs), null, OsdpSecurityBlockType.ReaderToDoorController, encryptionDetails)
        {
        }

        private static byte[] constructData(bool[] activeInputs)
        {
            byte[] data = new byte[activeInputs.Length];
            for (int i = 0; i < activeInputs.Length; i++)
            {
                if (activeInputs[i])
                    data[i] = 1;
            }
            return data;
        }

        public bool[] ActiveInputs
        {
            get
            {
                bool[] activeInputs = new bool[DataLength];
                for (int i = 0; i < activeInputs.Length; i++)
                {
                    if (message[DataOffset + i] != 0)
                        activeInputs[i] = true;
                }
                return activeInputs;
            }
        }
    }
}