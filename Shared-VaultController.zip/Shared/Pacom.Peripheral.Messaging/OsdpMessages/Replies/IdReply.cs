﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_PDID - PD ID Report
    // Sent in response to an osdp_ID command
    public class IdReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x45;

        public IdReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 12, encryptionDetails)
        {
        }

        public IdReply(int address, int sequence, bool useCrc, ReaderManufacturer vendor, int model, int version, int serialNumber, Version firmwareVersion)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(vendor, model, version, serialNumber, firmwareVersion))
        {
        }

        public IdReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, ReaderManufacturer vendor, int model, int version, int serialNumber, Version firmwareVersion)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(vendor, model, version, serialNumber, firmwareVersion), null, OsdpSecurityBlockType.ReaderToDoorController, encryptionDetails)
        {
        }

        private static byte[] constructData(ReaderManufacturer vendor, int model, int version, int serialNumber, Version firmwareVersion)
        {
            byte[] data = new byte[12];
            SetVendorBytes(vendor, data, 0);

            data[3] = (byte)model;
            data[4] = (byte)version;
            data[5] = (byte)(serialNumber & 0xFF);
            data[6] = (byte)((serialNumber & 0xFF00) >> 8);
            data[7] = (byte)((serialNumber & 0xFF0000) >> 16);
            data[8] = (byte)((serialNumber & 0xFF000000) >> 24);
            data[9] = (byte)firmwareVersion.Major;
            data[10] = (byte)firmwareVersion.Minor;
            data[11] = (byte)firmwareVersion.Build; 
            return data;
        }

        public ReaderManufacturer Vendor
        {
            get
            {
                return GetVendor(message, DataOffset);
            }
        }

        public int Model
        {
            get
            {
                return message[DataOffset + 3];
            }
        }

        public int Version
        {
            get
            {
                return message[DataOffset + 4];
            }
        }

        public int SerialNumber
        {
            get
            {
                return (((((message[DataOffset + 8] << 8) | message[DataOffset + 7]) << 8) | message[DataOffset + 6]) << 8) | message[DataOffset + 5];
            }
        }

        public Version FirmwareVersion
        {
            get
            {
                return new Version(message[DataOffset + 9], message[DataOffset + 10], message[DataOffset + 11]);
            }
        }
    }
}