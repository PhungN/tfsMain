﻿using System;
using Pacom.Peripheral.Common;
using System.Security.Cryptography;
using System.Text;

namespace Pacom.Peripheral.OsdpMessaging
{
    // osdp_MFGREP - Manufacturer Specific Reply
    // Sent in response to an osdp_MFGR command or as a "poll response"
    // This reply is intended to allow manufacturer specific messages to be embedded within this protocol. 
    // The data content of this reply is not defined in this document.
    public class ManufacturerSpecificReply : OsdpMessageBase
    {
        public const int FunctionCode = 0x90;

        public ManufacturerSpecificReply(byte[] data, OsdpEncryptionDetails encryptionDetails)
            : base(data, 3, encryptionDetails)
        {
        }

        public ManufacturerSpecificReply(int address, int sequence, bool useCrc, ReaderManufacturer vendor, byte[] command)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(vendor, command))
        {
        }

        public ManufacturerSpecificReply(int address, int sequence, bool useCrc, OsdpEncryptionDetails encryptionDetails, ReaderManufacturer vendor, byte[] command)
            : base(0x80 | address, sequence, useCrc, FunctionCode, constructData(vendor, command), null, OsdpSecurityBlockType.ReaderToDoorController, encryptionDetails)
        {
        }

        private static byte[] constructData(ReaderManufacturer vendor, byte[] command)
        {
            byte[] data = new byte[command.Length + 3];
            SetVendorBytes(vendor, data, 0);
            Buffer.BlockCopy(command, 0, data, 3, command.Length);
            return data;
        }

        public ReaderManufacturer Vendor
        {
            get
            {
                return GetVendor(message, DataOffset);
            }
        }

        public byte[] Command
        {
            get
            {
                byte[] command = new byte[DataLength - 3];
                Buffer.BlockCopy(message, DataOffset + 3, command, 0, command.Length);
                return command;
            }
        }
    }
}