﻿using System;
using System.Security.Cryptography;

namespace Pacom.Peripheral.OsdpMessaging
{
    public class OsdpEncryptionDetails
    {
        static Random random = new Random();
        public static byte[] DefaultEncryptionKey = new byte[] { 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F };

        public OsdpEncryptionDetails()
        {
        }

        public OsdpEncryptionDetails(byte[] randomNumberA)
        {
            RandomNumberA = randomNumberA;
        }

        public void Reset()
        {
            RandomNumberA = null;
            clientCryptogram = null;
            serverCryptogram = null;
            sessionEncryptionKey = null;
            sessionMac1 = null;
            sessionMac2 = null;
            sendingMac = null;
            ReceiveMac = null;
        }

        public Random Random
        {
            get
            {
                return random;
            }
        }

        public byte[] EncryptionKey { get; set; }

        public byte[] RandomNumberA { get; set; }
        public byte[] RandomNumberB
        {
            get
            {
                return null;
            }
            set
            {
                if (value == null)
                    return;

                sessionEncryptionKey = new byte[] { 0x01, 0x82, RandomNumberA[0], RandomNumberA[1], RandomNumberA[2], RandomNumberA[3], RandomNumberA[4], RandomNumberA[5], 0, 0, 0, 0, 0, 0, 0, 0 };
                encrypt(ref sessionEncryptionKey, EncryptionKey);

                clientCryptogram = new byte[16];
                Buffer.BlockCopy(RandomNumberA, 0, clientCryptogram, 0, 8);
                Buffer.BlockCopy(value, 0, clientCryptogram, 8, 8);
                encrypt(ref clientCryptogram, sessionEncryptionKey);

                sessionMac1 = new byte[] { 0x01, 0x01, RandomNumberA[0], RandomNumberA[1], RandomNumberA[2], RandomNumberA[3], RandomNumberA[4], RandomNumberA[5], 0, 0, 0, 0, 0, 0, 0, 0 };
                encrypt(ref sessionMac1, EncryptionKey);
                sessionMac2 = new byte[] { 0x01, 0x02, RandomNumberA[0], RandomNumberA[1], RandomNumberA[2], RandomNumberA[3], RandomNumberA[4], RandomNumberA[5], 0, 0, 0, 0, 0, 0, 0, 0 };
                encrypt(ref sessionMac2, EncryptionKey);

                serverCryptogram = new byte[16];
                Buffer.BlockCopy(value, 0, serverCryptogram, 0, 8);
                Buffer.BlockCopy(RandomNumberA, 0, serverCryptogram, 8, 8);
                encrypt(ref serverCryptogram, SessionEncryptionKey);

                sendingMac = new byte[16];
                Buffer.BlockCopy(serverCryptogram, 0, sendingMac, 0, 16);
                encrypt(ref sendingMac, sessionMac1);
                encrypt(ref sendingMac, sessionMac2);

                RandomNumberA = null;
            }
        }

        protected byte[] sessionMac1;
        protected byte[] sessionMac2;
        byte[] serverCryptogram;
        byte[] clientCryptogram;
        protected byte[] sessionEncryptionKey;
        byte[] sendingMac;

        public byte[] ClientCryptogram { get { return clientCryptogram; } }
        public byte[] ServerCryptogram { get { return serverCryptogram; } }
        public byte[] SessionEncryptionKey { get { return sessionEncryptionKey; } }
        public byte[] SessionMac1 { get { return sessionMac1; } }
        public byte[] SessionMac2 { get { return sessionMac2; } }

        public byte[] SendingMac 
        { 
            get 
            { 
                return sendingMac; 
            } 
            set 
            { 
                sendingMac = value;
            } 
        }
        private byte[] receiveMac;
        public byte[] ReceiveMac 
        {
            get
            {
                return receiveMac;
            }
            set
            {
                receiveMac = value;
            }
        }
        private static void encrypt(ref byte[] data, byte[] encryptionKey)
        {
            RijndaelManaged aes = new RijndaelManaged();
            aes.Key = encryptionKey;
            aes.IV = new byte[16];
            aes.Padding = PaddingMode.None;
            aes.Mode = CipherMode.CBC;

            using (ICryptoTransform encryptor = aes.CreateEncryptor())
            {
                data = encryptor.TransformFinalBlock(data, 0, 16);
            }
        }
    }
}
