﻿
namespace Pacom.Peripheral.OsdpMessaging
{
    public enum ExtendedProfileType : byte
    {
        GeneralError = 0,                   // General error indication: PD was unable to process the command
        CardPresent = 1,                    // Notifies the CP that the reader has detected a Smart Card (was osdp_PRES) 
        ReaderApdu = 2,                     // Returning an APDU embedded in this from the specified reader (was osdp_SCREP)
        ReaderPinCheckDone = 3,             // Reports that the reader has completed a “Secure PIN Entry” sequence (was osdp_SPER) 
        CurrentProfile = 4,                 // Returns the current XRW_PROFILE in effect
    }
}
