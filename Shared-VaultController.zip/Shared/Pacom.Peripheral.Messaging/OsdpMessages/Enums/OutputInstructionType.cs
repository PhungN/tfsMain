﻿
namespace Pacom.Peripheral.OsdpMessaging
{
    public enum OutputInstructionType
    {
        NoChange = 0,
        ImmediateOff = 1,
        ImmediateOn = 2,
        QueueOff = 3,
        QueueOn = 4,
        TemporaryOnWithDuration = 5,
        TemporaryOffWithDuration = 6
    }
}
