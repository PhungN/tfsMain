﻿using System;

namespace Pacom.Peripheral.OsdpMessaging
{
    [Flags]
    public enum PresentationMode
    {
        EnableText = 0x01,          // Security Level Text enabled
        EnableIcon = 0x02,          // Security Level Icon enabled
        EnableIndicators = 0x04,    // Indicators enabled (LEDs, Buzzer)
        ClearText = 0x10,           // Clear Security Level Text area – use in case if Security Level Text disabled and you don’t want to keep old text 
        ClearIcon = 0x20,           // Clear Security Level Icon area – use in case if Security Level Icon disabled and you don’t want to keep old presented graphic 
    }
}
