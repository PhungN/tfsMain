﻿using System;

namespace Pacom.Peripheral.OsdpMessaging
{
    public enum FeatureCode
    {
        /// <summary>
        /// This function indicates the ability to monitor the status of a switch using a two-wire electrical
        /// connection between the PD and the switch. The on/off position of the switch indicates the state of an
        /// external device.
        /// </summary>
        ContactStatusMonitoring = 1,
        /// <summary>
        /// This function provides a switched output, typically in the form of a relay. The Output has two states:
        /// active or inactive. The Control Panel (CP) can directly set the Output's state, or, if the PD supports
        /// timed operations, the CP can specify a time period for the activation of the Output.
        /// </summary>
        OutputControl = 2,
        /// <summary>
        /// This capability indicates the form of the card data is presented to the Control Panel.
        /// </summary>
        CardDataFormat = 3,
        /// <summary>
        /// This capability indicates the presence of and type of LEDs.
        /// </summary>
        LedControl = 4,
        /// <summary>
        /// This capability indicates the presence of and type of an Audible Annunciator (buzzer or similar tone generator)
        /// </summary>
        AudibleOutput = 5,
        /// <summary>
        /// This capability indicates that the PD supports a text display emulating character-based display terminals.
        /// </summary>
        TextOutput = 6,
        /// <summary>
        /// This capability indicates that the type of date and time awareness or time keeping ability of the PD.
        /// </summary>
        TimeKeeping = 7,
        /// <summary>
        /// All PDs must be able to support the checksum mode. This capability indicates if the PD is capable of supporting CRC mode.
        /// </summary>
        CrcSupport = 8,
        /// <summary>
        /// This capability indicates the extent to which the PD supports communication security.
        /// </summary>
        CommSecurity = 9,
        /// <summary>
        /// This capability indicates the maximum size single message the PD can receive.
        /// </summary>
        ReceiveBuffer = 10,
        /// <summary>
        /// This capability indicates the maximum size multi-part message which the PD can handle.
        /// </summary>
        LargestCombinedMessage = 11,
        /// <summary>
        /// This capability indicates whether the PD supports the transparent mode used for communicating
        /// directly with a smart card.
        /// </summary>
        SmartCardSupport = 12,
        /// <summary>
        /// This capability indicates the number of credential reader devices present. Compliance levels are bit
        /// fields to be assigned as needed.
        /// </summary>
        NumberOfReaders = 13,
        /// <summary>
        /// This capability indicates the ability of the reader to handle biometric input.
        /// </summary>
        BiometricsPresent = 14
    }
}
