﻿using System;

namespace Pacom.Peripheral.OsdpMessaging
{
    public enum KeypadKeys
    {
        Unknown = 0xFFFF,
        Zero = 0x30,
        One = 0x31,
        Two = 0x32,
        Three = 0x33,
        Four = 0x34,
        Five = 0x35,
        Six = 0x36,
        Seven = 0x37,
        Eight = 0x38,
        Nine = 0x39,
        Enter = 0x0D, // enter/#
        Delete = 0x7F, // clear/delete/*
    }
}
