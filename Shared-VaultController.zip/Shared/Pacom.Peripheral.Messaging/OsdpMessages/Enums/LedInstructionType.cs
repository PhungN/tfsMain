﻿
namespace Pacom.Peripheral.OsdpMessaging
{
    public enum LedInstructionType
    {
        NoChange = 0,
        SwitchToPermanentState = 1,
        StartTemporaryConfiguration = 2
    }
}
