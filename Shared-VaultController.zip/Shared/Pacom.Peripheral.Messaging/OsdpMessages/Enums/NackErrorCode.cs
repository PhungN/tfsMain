﻿using System;

namespace Pacom.Peripheral.OsdpMessaging
{
    /// <summary>
    /// Error codes for SIO osdp_NAK replay
    /// </summary>
    public enum NackErrorCode
    {
        /// <summary>
        /// No error
        /// </summary>
        NoError = 0,
        /// <summary>
        /// Message check character(s) error (bad cks/crc/mac[4])
        /// </summary>
        CheckSumOrCrcError = 1,
        /// <summary>
        /// Command length error
        /// </summary>
        CommandLengthError = 2,
        /// <summary>
        /// Unknown Command Code – Command not implemented by PD
        /// </summary>
        UnknownCommand = 3,
        /// <summary>
        /// Unexpected sequence number detected in the header
        /// </summary>
        UnexpectedSequenceNumber = 4,
        /// <summary>
        /// This PD does not support the security block that was received
        /// </summary>
        NotSupportSecurityBlock = 5,
        /// <summary>
        /// Encrypted communication is required to process this command
        /// </summary>
        EncryptedCommunicationRequired = 6,
        /// <summary>
        /// BIO_TYPE not supported
        /// </summary>
        BiometricTypeNotSupported = 7,
        /// <summary>
        /// BIO_FORMAT not supported
        /// </summary>
        BiometricFormatNotSupported = 8,
        /// <summary>
        /// Unable to process command record. 
        /// </summary>
        /// <remarks>
        /// Indicates that one or more command records had invalid parameters and was not processed which may be 
        /// followed by an optional array, where each byte represents the completion code of the corresponding command record. 
        /// </remarks>
        UnableToProcessCommandRecord = 9,
        /// <summary>
        /// Generic error
        /// </summary>
        GenericError = 0xFF
    }
}
