﻿
namespace Pacom.Peripheral.OsdpMessaging
{
    /// <summary>
    /// OSDP-sc block type
    /// </summary>
    public enum OsdpSecurityBlockType
    {
        /// <summary>
        /// SCS_11 - Begin new Secure Connection Sequence.
        /// Direction: CP to PD
        /// </summary>
        SessionInitiationStep1 = 0x11,
        /// <summary>
        /// SCS_12 - Secure Connection Sequence step 2
        /// Direction: PD to CP
        /// </summary>
        SessionInitiationStep2 = 0x12,
        /// <summary>
        /// SCS_13 - Secure Connection Sequence step 3
        /// Direction: CP to PD
        /// </summary>
        SessionInitiationStep3 = 0x13,
        /// <summary>
        /// SCS_14 - Secure Connection Sequence step 4
        /// Direction: PD to CP
        /// </summary>
        SessionInitiationStep4 = 0x14,
        /// <summary>
        ///  SCS_15 - Secure Session msg. w. MAC, no Data Security
        ///  Direction: CP to PD
        /// </summary>
        DoorControllerToReaderNoData = 0x15,
        /// <summary>
        /// SCS_16 - Secure Session msg. w. MAC, no Data Security
        /// Direction: PD to CP
        /// </summary>
        ReaderToDoorControllerNoData = 0x16,
        /// <summary>
        /// SCS_17 - Secure Session msg. with MAC & Data Security
        /// Direction: CP to PD
        /// </summary>
        DoorControllerToReader = 0x17,
        /// <summary>
        ///  SCS_18 - Secure Session msg. with MAC & Data Security
        ///  Direction: PD to CP
        /// </summary>
        ReaderToDoorController = 0x18
    }
}
