﻿
namespace Pacom.Peripheral.OsdpMessaging
{
    public enum TextType
    {
        PermanentTextWithNoWrap = 1,
        PermanantTextWithWrap = 2,
        TemporaryTextWithNoWrap = 3,
        TemporaryTextWithWrap = 4,
    }
}
