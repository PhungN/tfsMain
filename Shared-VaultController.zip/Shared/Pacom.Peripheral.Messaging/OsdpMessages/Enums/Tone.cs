﻿
namespace Pacom.Peripheral.OsdpMessaging
{
    /// <summary>
    /// Tone State
    /// </summary>
    public enum Tone
    {
        NoChange = 0,
        Off = 1,
        On = 2
    }
}
