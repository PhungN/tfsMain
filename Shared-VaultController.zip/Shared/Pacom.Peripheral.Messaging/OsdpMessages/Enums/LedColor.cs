﻿
namespace Pacom.Peripheral.OsdpMessaging
{
    /// <summary>
    /// Led color value
    /// </summary>
    public enum LedColor
    {
        /// <summary>
        /// Off or Unlit
        /// </summary>
        Black = 0,
        Red = 1,
        Green = 2,
        Amber = 3,
        Blue = 4
    }
}
