﻿
namespace Pacom.Peripheral.OsdpMessaging
{
    public class Capability
    {
        public Capability(int compliance, int count)
        {
            Compliance = compliance;
            Count = count;
        }

        public int Compliance { get; set; }
        public int Count { get; set; }
    }
}
