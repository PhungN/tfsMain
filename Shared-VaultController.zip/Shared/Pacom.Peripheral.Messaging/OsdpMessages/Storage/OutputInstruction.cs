﻿using System;

namespace Pacom.Peripheral.OsdpMessaging
{
    public class OutputInstruction
    {
        public int OutputNumber { get; set; }
        public OutputInstructionType Instruction { get; set; }
        public TimeSpan Duration { get; set; }
    }
}
