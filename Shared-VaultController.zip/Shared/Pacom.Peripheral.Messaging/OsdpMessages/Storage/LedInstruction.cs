﻿using System;

namespace Pacom.Peripheral.OsdpMessaging
{
    public class LedInstruction
    {
        public int LedNumber { get; set; }
        public LedInstructionType Instruction { get; set; }
        public TimeSpan TemporaryOnTime { get; set; }
        public TimeSpan TemporaryOffTime { get; set; }
        public LedColor TemporaryOnColor { get; set; }
        public LedColor TemporaryOffColor { get; set; }
        public TimeSpan TemporaryDuration { get; set; }
        public bool IncludePermanentSettings { get; set; }
        public TimeSpan OnTime { get; set; }
        public TimeSpan OffTime { get; set; }
        public LedColor OnColor { get; set; }
        public LedColor OffColor { get; set; }

        public static LedInstruction[] Off()
        {
            return On(LedColor.Black);
        }

        public static LedInstruction[] On(LedColor color)
        {
            LedInstruction[] instructions = new LedInstruction[1];
            instructions[0] = new LedInstruction()
            {
                IncludePermanentSettings = true,
                Instruction = LedInstructionType.SwitchToPermanentState,
                LedNumber = 0,
                OnColor = color,
                OffColor = color,
                OnTime = new TimeSpan(0, 0, 0, 0, 100),
                OffTime = new TimeSpan(0, 0, 0, 0, 100)
            };
            return instructions;
        }

        public static LedInstruction[] Flash(LedColor onLedColor, LedColor offLedColor)
        {
            LedInstruction[] instructions = new LedInstruction[1];
            instructions[0] = new LedInstruction()
            {
                IncludePermanentSettings = true,
                Instruction = LedInstructionType.SwitchToPermanentState,
                LedNumber = 0,
                OnColor = onLedColor,
                OffColor = offLedColor,
                OnTime = new TimeSpan(0, 0, 0, 0, 400),
                OffTime = new TimeSpan(0, 0, 0, 0, 400)
            };
            return instructions;
        }

        public static LedInstruction[] TemporaryLedFlash(LedColor onLedColor, LedColor offLedColor)
        {
            LedInstruction[] instructions = new LedInstruction[1];
            instructions[0] = new LedInstruction()
            {
                IncludePermanentSettings = false,
                Instruction = LedInstructionType.StartTemporaryConfiguration,
                LedNumber = 0,
                TemporaryOnColor = onLedColor,
                TemporaryOffColor = offLedColor,
                TemporaryOnTime = new TimeSpan(0, 0, 0, 0, 3000),
                TemporaryOffTime = new TimeSpan(0, 0, 0, 0, 0),
                TemporaryDuration = new TimeSpan(0, 0, 0, 0, 3000)
            };
            return instructions;
        }
    }
}
