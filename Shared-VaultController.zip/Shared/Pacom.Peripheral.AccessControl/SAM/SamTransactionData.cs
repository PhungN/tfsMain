﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Common.Utils;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.AccessControl
{
    public class SamTransactionData
    {
        byte[] cardSerialNumber = new byte[8];
        byte[] challenge = new byte[8];
        byte[] kifkvcSession = new byte[2];
        byte[] kifkvcSignature = new byte[2];
        byte[] environmentData = new byte[64];
        byte[] openSecureSessionData = new byte[76];

        /// <summary>
        /// Card Serial Number
        /// </summary>
        public byte[] CardSerialNumber 
        { 
            get { return cardSerialNumber; } 
            set { cardSerialNumber = value; } 
        }

        /// <summary>
        /// SAM Challenge
        /// </summary>
        public byte[] Challenge 
        { 
            get { return challenge; } 
            set { challenge = value; } 
        }

        /// <summary>
        /// Key Identifier/Version of session key
        /// </summary>
        public byte[] KIFKVCSession 
        { 
            get { return kifkvcSession; } 
            set { kifkvcSession = value; } 
        }

        /// <summary>
        /// Key Identifier/Version of signature key
        /// </summary>
        public byte[] KIFKVCSignature 
        { 
            get { return kifkvcSignature; } 
            set { kifkvcSignature = value; } 
        }

        /// <summary>
        /// Environment Data
        /// </summary>
        public byte[] EnvironmentData 
        { 
            get { return environmentData; } 
            set { environmentData = value; } 
        }

        /// <summary>
        /// Data out of the Open Secure Session
        /// </summary>
        public byte[] OpenSecureSessionData 
        { 
            get { return openSecureSessionData; } 
            set { openSecureSessionData = value; } 
        }
    }
}
