﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Common.Utils;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.AccessControl
{
    public enum SamAuthenticateResult
    {
        Success = 0,                // No error
        CardUnknownError,           // Incorrect card type
        CardDateError,              // Card expired or not yet valid
        CardBlackListedSamError,    // Card personalization SAM blacklisted
        CardFormatError,            // Incorrect data format (version, date...)
        CardComError,               // Communication error with the card
        CardSwError,                // Error reported by the card
        CardApduDataError,          // Card Apdu data error
        SamComError,                // Communication error with the SAM
        SamSwError,                 // Error reported by the SAM
        SamApduDataError,           // Sam Apdu data error
        InternalError               // Internal errors
    }
}
