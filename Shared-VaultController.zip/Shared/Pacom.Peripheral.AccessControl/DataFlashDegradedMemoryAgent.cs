﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// This class provides services and methods for maintaining card data in data flash.
    /// Data is stored in 264 bytes pages. There is several card records per page.
    /// This class will provide service for saving changes into the data flash periodically.    
    /// Changes must be saved only when there is change to the data.
    /// </summary>
    internal class DataFlashDegradedMemoryAgent : DegradedMemoryAgentBase
    {
        protected override string agentLogFix { get { return "DataFlash"; } }

        /// <summary>
        /// Data flash access objects.
        /// </summary>
        private IDataFlash dataFlash = DataFlash.Instance;

        /// <summary>
        /// Dictionary with card number as a key and additional information.
        /// The byte array with card data will have bits used attached to the end.
        /// [32 bits of data]+[2 bytes with card data length]
        /// </summary>
        private readonly Dictionary<byte[], CardMetadataRecord> cards = new Dictionary<byte[], CardMetadataRecord>(new ByteArrayComparer());

        /// <summary>
        /// This list holds indices of pages that have problems with reading the correct checksum.
        /// </summary>
        private List<int> corruptedPages = new List<int>();

#if DEBUG
        // Used to check if Erase Media is called inappropriately.
        private static bool instancesCreated = false;
#endif

        /// <summary>
        /// Constructor
        /// </summary>
        public DataFlashDegradedMemoryAgent(int doorHardwareId)
            : base(doorHardwareId)
        {
#if DEBUG
            instancesCreated = true;
#endif
        }

        #region IDegradedMemoryAgent Members

        /// <summary>
        /// Number of active cards held by this degraded memory agent.
        /// </summary>
        public override int CardCount 
        {
            get
            {
                return cards.Count;
            }
        }

        /// <summary>
        /// Number of maximum active cards held by this degraded memory agent.
        /// </summary>
        public override int MaxActiveCards 
        { 
            get 
            {
                return DataFlashLocations.CardAccessMaxCardRecords; 
            } 
        }
               
        /// <summary>
        /// Scan all card records and try to find card data and page. 
        /// </summary>
        /// <param name="cardData">Byte array with card data. Always supplied in 32 byte array.</param>
        /// <param name="cardLength">Number of bits used in byte array provided by cardData parameter.</param>
        /// <param name="pageIndex">Returns page index where the card data resides.</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator</returns>
        public override bool CardExists(byte[] cardData, int cardLength)
        {
            byte[] cardKey;
            return cardExists(cardData, cardLength, out cardKey);
        }
        
        /// <summary>
        /// This class accepts card data with specified length to be added to the list of cards in degraded mode.
        /// The cardData array is expected to be 32 byte in length. Used bits are defined by cardLength parameter.
        /// </summary>
        /// <param name="cardData">Byte array with card data bits. 32 bytes.</param>
        /// <param name="cardLength">Number of bits used in byte array provided by cardData parameter.</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator</returns>
        public override bool AddCard(byte[] cardData, int cardLength, LegacyCardRecord legacyCardData)
        {
            if (degradedMemoryOffline || LoadCardsFinished == false)
                return false;
            try
            {
                // Card data must be provided. The length parameter must be positive.
                if (cardData == null || cardLength <= 0)
                    return false;
                // This class expects 32 byte array of card data bits.
                if (cardData.Length != 32 || cardLength > 255)
                    return false;
                lock (cards)
                {
                    // Attempt to find card in existing degraded list.
                    if (CardExists(cardData, cardLength) == true)
                        return true;
                    if (cards != null && cards.Count >= DataFlashLocations.CardAccessMaxCardRecords)
                    {
                        // Remove cards above the MaxCardRecords from consts plus one more for the new one.
                        int cardsToRemove = (cards.Count + 1) - DataFlashLocations.CardAccessMaxCardRecords;
                        for (int iRemove = 0; iRemove < cardsToRemove; iRemove++)
                        {
                            // Find oldest card record and remove it.
                            var firstLastUsed = cards.GetValues().Min(obj => obj.LastUsed);
                            var firstLastUsedObject = cards.FirstOrDefault(card => card.Value.LastUsed == firstLastUsed);
                            if (firstLastUsedObject.Key != null)
                            {
                                cards.Remove(firstLastUsedObject.Key);
                                byte[] degradedCardData;
                                int degradedCardLength;
                                CardReaderUtilityFunctions.ParseCardkey(firstLastUsedObject.Key, out degradedCardData, out degradedCardLength);
                                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                                {
#if DEBUG
                                    // Format card data
                                    byte[] cardDataClean;
                                    int numBytes = (degradedCardLength / 8) + ((degradedCardLength % 8) != 0 ? 1 : 0);
                                    try
                                    {
                                        if (degradedCardData.Length == 32)
                                        {
                                            cardDataClean = degradedCardData;
                                        }
                                        else
                                        {
                                            cardDataClean = new byte[Math.Min(degradedCardData.Length, numBytes)];
                                            Array.Copy(degradedCardData, cardDataClean, Math.Min(degradedCardData.Length, numBytes));
                                        }
                                    }
                                    catch
                                    {
                                        cardDataClean = degradedCardData;
                                    }
                                    return agentLog("Removed oldest card. [{0}, length {1}]", BitConverter.ToString(cardDataClean), degradedCardLength);
#else
                                    return agentLog("Removed oldest card. [****, length {0}]", degradedCardLength);
#endif
                                });
                            }
                        }
                    }
                    // Add new card entry.                    
                    byte[] cardKey = CardReaderUtilityFunctions.ConstructCardkey(cardData, cardLength);
                    if (cardKey != null)
                    {
                        var metadata = new CardMetadataRecord();
                        metadata.LastUsed = DateTime.UtcNow;
                        cards.Add(cardKey, metadata);
                        delayedUpdateCardDatabaseAction.ScheduleUpdate();
                        return true;
                    }                    
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while adding card to memory. {0}", ex.Message);
                });
            }
            return false;
        }

        /// <summary>
        /// Delete card from degraded memory buffer.
        /// </summary>
        /// <param name="cardData">Card data.</param>
        /// <param name="comparer">Comparer used to decode card data byte and return true if it is found.</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator.</returns>
        public override bool DeleteCard(LegacyCardRecord cardData)
        {
            // Card data and comparer must be provided.
            if (degradedMemoryOffline || LoadCardsFinished == false || cardData == null || legacyDeleteComparer == null)
                return false;
            
            List<byte[]> cardsToRemove = new List<byte[]>();

            try
            {
                lock (cards)
                {
                    foreach (var card in cards)
                    {
                        byte[] degradedCardData;
                        int degradedCardLength;
                        CardReaderUtilityFunctions.ParseCardkey(card.Key, out degradedCardData, out degradedCardLength);
                        if (legacyDeleteComparer(cardData, degradedCardData, degradedCardLength))
                        {
                            cardsToRemove.Add(card.Key);
                        }
                    }
                }
                if (cardsToRemove.Count > 0)
                {
                    foreach (byte[] cardToRemove in cardsToRemove)
                    {
                        cards.Remove(cardToRemove);
                    }
                    delayedUpdateCardDatabaseAction.ScheduleUpdate();
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while deleting a card. {0}", ex.Message);
                });
            }
            return false;
        }

        /// <summary>
        /// Delete card from degraded memory buffer. (Raw card data)
        /// </summary>
        /// <param name="cardData">Raw card data byte array.</param>
        /// <param name="cardLength">Number of bits in the raw card data byte array.</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator.</returns>
        public override bool DeleteCard(byte[] cardData, int cardLength)
        {
            // Card data  must be provided.
            if (degradedMemoryOffline || LoadCardsFinished == false || cardData == null || cardLength < 0 || cardLength > 255)
                return false;
            List<byte[]> cardsToRemove = new List<byte[]>();
            try
            {
                lock (cards)
                {
                    int smallestBitCount = 0;
                    if (cardLength == 0)
                    {
                        smallestBitCount = getSmallestBitCount(cardData);
                        Array.Reverse(cardData);
                    }

                    foreach (var card in cards)
                    {
                        byte[] degradedCardData;
                        int degradedCardLength;
                        CardReaderUtilityFunctions.ParseCardkey(card.Key, out degradedCardData, out degradedCardLength);
                        if (cardLength == 0)
                        {
                            if (degradedCardLength <= 64 && degradedCardLength >= smallestBitCount)
                            {
                                byte[] nativeCardData;
                                if (translateLegacyCardNumberToNativeCardNumber(cardData, degradedCardLength, out nativeCardData))
                                {
                                    if (nativeCardData.SequenceEqual(degradedCardData))
                                        cardsToRemove.Add(card.Key);
                                }
                            }
                        }
                        else if (cardLength == degradedCardLength && cardData.SequenceEqual(degradedCardData))
                        {
                            cardsToRemove.Add(card.Key);
                            break;
                        }
                    }
                    if (cardsToRemove.Count > 0)
                    {
                        foreach (byte[] cardToRemove in cardsToRemove)
                        {
                            cards.Remove(cardToRemove);
                        }
                        delayedUpdateCardDatabaseAction.ScheduleUpdate();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while deleting card from degraded memory after controller request. {0}", ex.Message);
                });
            }
            return false;
        }

        /// <summary>
        /// Delete all cards from the degraded memory.
        /// </summary>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator.</returns>
        public override bool DeleteAll()
        {
            if (degradedMemoryOffline || (LoadCardsFinished == false && deleteAllCards == false))
                return false;
            try
            {
                lock (cards)
                {
                    cards.Clear();
                    delayedUpdateCardDatabaseAction.ScheduleUpdate();
                }
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while deleting all cards from degraded memory after controller request. {0}", ex.Message);
                });
            }
            return false;
        }

        #endregion

        /// <summary>
        /// Scan all card records and try to find card data and page. 
        /// </summary>
        /// <param name="cardData">Byte array with card data. Always supplied in 32 byte array.</param>
        /// <param name="cardLength">Number of bits</param>
        /// <param name="pageIndex">Returns page index where the card data resides.</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator</returns>
        private bool cardExists(byte[] cardData, int cardLength, out byte[] cardKey)
        {
            cardKey = null;
            if (degradedMemoryOffline == true || LoadCardsFinished == false)
                return false;

            // Card data must be provided. The length parameter must be positive.
            if (cardData == null || cardData.Length <= 0 || cardLength <= 0)
                return false;
            // Is card data provided.
            if (cardData.Length <= 0 || cardLength > 256)
                return false;

            // Attempt to find card in existing degraded list.
            cardKey = CardReaderUtilityFunctions.ConstructCardkey(cardData, cardLength);
            lock (cards)
            {
                if (cardKey != null && cards.ContainsKey(cardKey) == true)
                {
                    CardMetadataRecord cardRecord = null;
                    if (cards.TryGetValue(cardKey, out cardRecord) == true)
                    {
                        if (cardRecord != null)
                            return true;
                    }
                }
            }
            cardKey = null;
            return false;
        }

        /// <summary>
        /// Internal method for loading data page from data flash.
        /// Used by both header and card pages.
        /// </summary>
        /// <param name="pageNumber"></param>
        /// <param name="pageData"></param>
        /// <returns></returns>
        private bool loadDataPage(int pageNumber, out byte[] pageData)
        {
            if (pageNumber < 0 || pageNumber > (DataFlashLocations.CardAccessPageMaxNumber - 1))
            {
                pageData = new byte[0];
                return false;
            }
            pageData = new byte[DataFlashLocations.DataFlashPageSize];
            int offset = DataFlashLocations.CardAccessMemoryOffset(this.doorHardwareId, pageNumber);
            bool result = dataFlash.ReadData(offset, pageData);
#if DEBUG_DATAFLASH
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return string.Format("Door {0} degraded memory. Load page @{1} {2} {3}.", this.doorHardwareId + 1, offset, pageNumber, result ? "- OK" : "- Error");
            });
#endif
            return result;
        }

        /// <summary>
        /// Internal method for saving data page into data flash.
        /// Used by both header and card pages.
        /// </summary>
        /// <param name="pageNumber"></param>
        /// <param name="pageData"></param>
        /// <returns></returns>
        private bool saveDataPage(int pageNumber, byte[] pageData)
        {
            if (pageNumber < 0 || pageNumber > (DataFlashLocations.CardAccessPageMaxNumber - 1))
                return false;
            int offset = DataFlashLocations.CardAccessMemoryOffset(this.doorHardwareId, pageNumber);
            bool result = dataFlash.WriteData(offset, pageData);
#if DEBUG_DATAFLASH
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return string.Format("Door {0} degraded memory. Save page @{1} {2} {3}.", this.doorHardwareId + 1, offset, pageNumber, result ? "- OK" : "- Error");
            });
#endif
            return result;
        }

        protected override void updateCardDatabaseCallback()
        {
            if (requestDoorConfiguration == null)
                return;
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Saving cards and configuration.");
            });
            int addedNewCards = 0;
            int deletedCards = 0;
            int savingPages = 0;
            int savingConfigPages = 0;

            // Ask for configuration update before saving starts
            DegradedMemoryDoorConfiguration doorConfiguration = null;
            doorConfiguration = requestDoorConfiguration(this.disposing);
            // Doors configuration must be provided. The controller may be still offline. Abort saving process.
            if (doorConfiguration == null)
                return;
            // Copy configuration - Entry
            readerInitializationEntry.ReaderInitializationRecord = doorConfiguration[entryReaderId].InitializationConfig;
            readerInitializationEntry.AccessPointCardFormats = doorConfiguration[entryReaderId].FormatConfig;
            readerMasterCardsEntry.SetMasterCard(doorConfiguration[entryReaderId].MasterCard);
            // Copy configuration - Exit
            readerInitializationExit.ReaderInitializationRecord = doorConfiguration[exitReaderId].InitializationConfig;
            readerInitializationExit.AccessPointCardFormats = doorConfiguration[exitReaderId].FormatConfig;
            readerMasterCardsExit.SetMasterCard(doorConfiguration[exitReaderId].MasterCard);

            byte[] pageDataExisting;
            byte[] pageDataNew;

            // Save card initialization record for entry reader.
            if (loadDataPage(DataFlashLocations.CardAccessPageInitializationEntryReader, out pageDataExisting) == false)
            {
                readerInitializationEntry.Clear();
                readerInitializationExit.Clear();
                readerMasterCardsEntry.Clear();
                readerMasterCardsExit.Clear();
                setDegradedMemoryOffline();
                return;
            }
            pageDataNew = readerInitializationEntry.Serialize();
            if (pageDataNew.SequenceEqual(pageDataExisting) == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
#if DEBUG
                    return agentLog("Saving initialization for entry reader. {0}", printCompareArrays(pageDataNew, pageDataExisting));
#else
                    return agentLog("Saving initialization for entry reader.");
#endif
                });
                savingConfigPages++;
                if (saveDataPage(DataFlashLocations.CardAccessPageInitializationEntryReader, pageDataNew) == false)
                {
                    readerInitializationEntry.Clear();
                    readerInitializationExit.Clear();
                    readerMasterCardsEntry.Clear();
                    readerMasterCardsExit.Clear();
                    setDegradedMemoryOffline();
                    return;
                }
            }
            // Save card initialization record for exit reader.
            if (loadDataPage(DataFlashLocations.CardAccessPageInitializationExitReader, out pageDataExisting) == false)
            {
                readerInitializationEntry.Clear();
                readerInitializationExit.Clear();
                readerMasterCardsEntry.Clear();
                readerMasterCardsExit.Clear();
                setDegradedMemoryOffline();
                return;
            }
            pageDataNew = readerInitializationExit.Serialize();
            if (pageDataNew.SequenceEqual(pageDataExisting) == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
#if DEBUG
                    return agentLog("Saving initialization for exit reader. {0}", printCompareArrays(pageDataNew, pageDataExisting));
#else
                    return agentLog("Saving initialization for exit reader.");
#endif
                });

                savingConfigPages++;
                if (saveDataPage(DataFlashLocations.CardAccessPageInitializationExitReader, pageDataNew) == false)
                {
                    readerInitializationEntry.Clear();
                    readerInitializationExit.Clear();
                    readerMasterCardsEntry.Clear();
                    readerMasterCardsExit.Clear();
                    setDegradedMemoryOffline();
                    return;
                }
            }
            // Save master card record for entry reader.
            if (loadDataPage(DataFlashLocations.CardAccessPageMasterCardsEntryReader, out pageDataExisting) == false)
            {
                readerMasterCardsEntry.Clear();
            }
            pageDataNew = readerMasterCardsEntry.Serialize();
            if (pageDataNew.SequenceEqual(pageDataExisting) == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
#if DEBUG
                    return agentLog("Saving master cards for entry reader. {0}", printCompareArrays(pageDataNew, pageDataExisting));
#else
                    return agentLog("Saving master cards for entry reader.");
#endif
                });

                savingConfigPages++;
                if (saveDataPage(DataFlashLocations.CardAccessPageMasterCardsEntryReader, pageDataNew) == false)
                {
                    readerMasterCardsEntry.Clear();
                }
            }
            // Save master card record for exit reader.
            if (loadDataPage(DataFlashLocations.CardAccessPageMasterCardsExitReader, out pageDataExisting) == false)
            {
                readerMasterCardsExit.Clear();
            }
            pageDataNew = readerMasterCardsExit.Serialize();
            if (pageDataNew.SequenceEqual(pageDataExisting) == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
#if DEBUG
                    return agentLog("Saving master cards for exit reader. {0}", printCompareArrays(pageDataNew, pageDataExisting));
#else
                    return agentLog("Saving master cards for exit reader.");
#endif
                });
                savingConfigPages++;
                if (saveDataPage(DataFlashLocations.CardAccessPageMasterCardsExitReader, pageDataNew) == false)
                {
                    readerMasterCardsExit.Clear();
                }
            }
            pageDataExisting = null;
            pageDataNew = null;

            // Now iterate over our card data  
            DegradedMemoryCardsRecord pageCardRecord = new DegradedMemoryCardsRecord();
            try
            {
                lock (cards)
                {
                    if (ConfigurationManager.Instance.Doors[doorHardwareId + 1].DegradedMemoryEnabled == false && CardCount > 0)
                        cards.Clear();

                    bool changesMade = true;
                    int retryCount;
                    for (retryCount = 0; retryCount < 10; retryCount++)
                    {
                        if (changesMade == false)
                            break;
                        changesMade = false;
                        foreach (var card in cards)
                        {
                            card.Value.PageNumber = -1;
                        }

                        // First pass to remove any deleted cards and any duplicate cards
                        for (int iPage = DataFlashLocations.CardAccessExtraPagesCount; iPage < DataFlashLocations.CardAccessPageMaxNumber; iPage++)
                        {
                            // Check if page has been marked as corrupted, do not attempt to work with it if it has.
                            if (corruptedPages.IndexOf(iPage) >= 0)
                                continue;

                            // Read cards from the page.
                            pageCardRecord.Clear();
                            if (loadAndValidatePage(iPage, pageCardRecord, out pageDataExisting) == true)
                            {
                                // Compare the cards in RAM to the cards stored in Data Flash
                                for (int iPageCard = 0; iPageCard < DataFlashLocations.CardAccessCardRecordsPerPage; iPageCard++)
                                {
                                    if (pageCardRecord.Cards[iPageCard] != null && pageCardRecord.Cards[iPageCard].IsValidCard == true)
                                    {
                                        byte[] cardKey;
                                        if (cardExists(pageCardRecord.Cards[iPageCard].CardData, pageCardRecord.Cards[iPageCard].CardBits, out cardKey) == false
                                            || cards[cardKey].PageNumber != -1)
                                        {
                                            // Card has either been deleted or is a duplicate so remove it
                                            pageCardRecord.Cards[iPageCard].Invalidate();
                                            deletedCards++;
                                        }
                                        else
                                        {
                                            // Mark the card as found
                                            cards[cardKey].PageNumber = iPage;
                                        }
                                    }
                                }
                                // Save new page record if it has changed
                                pageDataNew = pageCardRecord.Serialize();
                                if (pageDataExisting.SequenceEqual(pageDataNew) == false)
                                {
                                    changesMade = true;
                                    if (saveDataPage(iPage, pageDataNew) == false)
                                    {
                                        // Here we have corrupted data flash
                                        markPageAsCorrupted(iPage);
                                    }
                                    else
                                    {
                                        savingPages++;
                                    }
                                }
                            }
                            else
                            {
                                changesMade = true;
                                // Corrupted page try to restore
                                if (saveDataPage(iPage, pageCardRecord.InitialPageData) == false)
                                {
                                    // Here we have corrupted data flash
                                    markPageAsCorrupted(iPage);
                                }
                                else if (loadDataPage(iPage, out pageDataNew) == false)
                                {
                                    // Here we have corrupted data flash
                                    markPageAsCorrupted(iPage);
                                }
                                else if (pageDataNew.SequenceEqual(pageCardRecord.InitialPageData) == false)
                                {
                                    // Here we have corrupted data flash
                                    markPageAsCorrupted(iPage);
                                }
                            }
                            pageDataExisting = null;
                            pageDataNew = null;
                        }

                        int pendingNewCards = 0;
                        foreach (var card in cards)
                        {
                            if (card.Value.PageNumber == -1)
                                pendingNewCards++;
                        }

                        // If there are no new cards, we don't need to proceed to the second pass
                        if (pendingNewCards == 0)
                            continue;

                        // Second pass to add any new cards
                        for (int iPage = DataFlashLocations.CardAccessExtraPagesCount; iPage < DataFlashLocations.CardAccessPageMaxNumber; iPage++)
                        {
                            // Check if page has been marked as corrupted, do not attempt to work with it if it has.
                            if (corruptedPages.IndexOf(iPage) >= 0)
                                continue;

                            // Read cards from the page.
                            pageCardRecord.Clear();
                            if (loadAndValidatePage(iPage, pageCardRecord, out pageDataExisting) == true)
                            {
                                // Compare the cards in RAM to the cards stored in Data Flash
                                for (int iPageCard = 0; iPageCard < DataFlashLocations.CardAccessCardRecordsPerPage; iPageCard++)
                                {
                                    if (pageCardRecord.Cards[iPageCard] != null && pageCardRecord.Cards[iPageCard].IsValidCard == false)
                                    {
                                        // Found an empty slot
                                        var newCard = cards.FirstOrDefault(card => card.Value.PageNumber == -1);
                                        if (newCard.Key != null)
                                        {
                                            // Found card data. Populate this empty slot.
                                            byte[] cardData;
                                            int cardLength;
                                            CardReaderUtilityFunctions.ParseCardkey(newCard.Key, out cardData, out cardLength);
                                            if (cardLength > 0)
                                            {
                                                pageCardRecord.Cards[iPageCard].CardData = cardData;
                                                pageCardRecord.Cards[iPageCard].CardBits = cardLength;
                                                pageCardRecord.Cards[iPageCard].LastUsed = newCard.Value.LastUsed;
                                                // This card is no longer new.
                                                newCard.Value.PageNumber = iPage;
                                                addedNewCards++;
                                                pendingNewCards--;
                                            }
                                            else
                                            {
                                                // Do some cleanup here. Card record is faulty. The parsing should have worked.
                                                cards.Remove(newCard.Key);
                                            }
                                        }
                                    }
                                }
                                // Save new page record if it has changed
                                pageDataNew = pageCardRecord.Serialize();
                                if (pageDataExisting.SequenceEqual(pageDataNew) == false)
                                {
                                    changesMade = true;
                                    if (saveDataPage(iPage, pageDataNew) == false)
                                    {
                                        // Here we have corrupted data flash
                                        markPageAsCorrupted(iPage);
                                    }
                                    else
                                    {
                                        savingPages++;
                                    }
                                }
                            }
                            else
                            {
                                changesMade = true;
                                // Corrupted page try to restore
                                if (saveDataPage(iPage, pageCardRecord.InitialPageData) == false)
                                {
                                    // Here we have corrupted data flash
                                    markPageAsCorrupted(iPage);
                                }
                                else if (loadDataPage(iPage, out pageDataNew) == false)
                                {
                                    // Here we have corrupted data flash
                                    markPageAsCorrupted(iPage);
                                }
                                else if (pageDataNew.SequenceEqual(pageCardRecord.InitialPageData) == false)
                                {
                                    // Here we have corrupted data flash
                                    markPageAsCorrupted(iPage);
                                }
                            }
                            pageDataExisting = null;
                            pageDataNew = null;

                            if (pendingNewCards == 0)
                                break;
                        }
                    }
                    if (changesMade)
                    {
                        Logger.LogCriticalMessage(LoggerClassPrefixes.AccessControlManager, () =>
                        {
                            return agentLog("Failed to write degraded memory records. Data flash is likely worn out.");
                        });
                    }
                }
            }
            finally
            {
                pageCardRecord = null;
            }
            if (savingConfigPages > 0 || savingPages > 0)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Added {0} card(s), Deleted {1} card(s), Total cards on list: {2}, saved {3} page(s). Saved config pages: {4}.",
                        addedNewCards, deletedCards, cards.Count, savingPages, savingConfigPages);
                });
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Finished saving data to degraded memory.");
            });
        }

        private void clearCardsAndConfiguration()
        {
            Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Unable to read degraded memory records.");
            });
            readerInitializationEntry.Clear();
            readerInitializationExit.Clear();
            readerMasterCardsEntry.Clear();
            readerMasterCardsExit.Clear();
            cards.Clear();
        }

        protected override void loadCardsAndConfiguration()
        {
            byte[] pageDataTemp;
            // Load card initialization record for entry reader.
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Reading initialization of entry reader.");
            });
            if (loadAndValidatePage(DataFlashLocations.CardAccessPageInitializationEntryReader, readerInitializationEntry) == false)
            {
                // Corrupted page try to restore
                if (saveDataPage(DataFlashLocations.CardAccessPageInitializationEntryReader, readerInitializationEntry.InitialPageData) == false)
                {
                    clearCardsAndConfiguration();
                    return;
                }
                else if (loadDataPage(DataFlashLocations.CardAccessPageInitializationEntryReader, out pageDataTemp) == false)
                {
                    clearCardsAndConfiguration();
                    return;
                }
                else if (pageDataTemp.SequenceEqual(readerInitializationEntry.InitialPageData) == false)
                {
                    clearCardsAndConfiguration();
                    return;
                }
                // The memory has been initialized. There will be no readers configuration in it.
            }
            // Load card initialization record for reader 2.
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Reading initialization of exit reader.");
            });
            if (loadAndValidatePage(DataFlashLocations.CardAccessPageInitializationExitReader, readerInitializationExit) == false)
            {
                // Corrupted page try to restore
                if (saveDataPage(DataFlashLocations.CardAccessPageInitializationExitReader, readerInitializationExit.InitialPageData) == false)
                {
                    clearCardsAndConfiguration();
                    return;
                }
                else if (loadDataPage(DataFlashLocations.CardAccessPageInitializationExitReader, out pageDataTemp) == false)
                {
                    clearCardsAndConfiguration();
                    return;
                }
                else if (pageDataTemp.SequenceEqual(readerInitializationExit.InitialPageData) == false)
                {
                    clearCardsAndConfiguration();
                    return;
                }
                // The memory has been initialized. There will be no readers configuration in it.
            }
            // Load master card record for entry reader.
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Reading master card of entry reader.");
            });
            if (loadAndValidatePage(DataFlashLocations.CardAccessPageMasterCardsEntryReader, readerMasterCardsEntry) == false)
            {
                // Corrupted page try to restore
                // The master card configuration is not compulsory. The program may go on without it.
                if (saveDataPage(DataFlashLocations.CardAccessPageMasterCardsEntryReader, readerMasterCardsEntry.InitialPageData) == false)
                {
                    readerMasterCardsEntry.Clear();
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return agentLog("entry reader degraded memory master card record is ignored.");
                    });
                }
                else if (loadDataPage(DataFlashLocations.CardAccessPageMasterCardsEntryReader, out pageDataTemp) == false)
                {
                    readerMasterCardsEntry.Clear();
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return agentLog("Entry reader degraded memory master card record is ignored.");                        
                    });
                }
                else if (pageDataTemp.SequenceEqual(readerMasterCardsEntry.InitialPageData) == false)
                {
                    readerMasterCardsEntry.Clear();
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return agentLog("Entry reader degraded memory master card record is ignored.");
                    });
                }
            }
            // Load master card record for exit reader.
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Reading master card of exit reader.");
            });
            if (loadAndValidatePage(DataFlashLocations.CardAccessPageMasterCardsExitReader, readerMasterCardsExit) == false)
            {
                // Corrupted page try to restore
                // The master card configuration is not compulsory. The program may go on without it.
                if (saveDataPage(DataFlashLocations.CardAccessPageMasterCardsExitReader, readerMasterCardsExit.InitialPageData) == false)
                {
                    readerMasterCardsExit.Clear();
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return agentLog("Exit reader degraded memory master card record is ignored.");
                    });
                }
                else if (loadDataPage(DataFlashLocations.CardAccessPageMasterCardsExitReader, out pageDataTemp) == false)
                {
                    readerMasterCardsExit.Clear();
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return agentLog("Exit reader degraded memory master card record is ignored.");
                    });
                }
                else if (pageDataTemp.SequenceEqual(readerMasterCardsExit.InitialPageData) == false)
                {
                    readerMasterCardsExit.Clear();
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return agentLog("Exit reader degraded memory master card record is ignored.");
                    });
                }
            }
            pageDataTemp = null;
            // Load reader degraded memory cards. Start from clearing the existing content.
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Reading card records.");
            });
            lock (cards)
            {
                cards.Clear();
            }

            if (ConfigurationManager.Instance.Doors[doorHardwareId + 1].DegradedMemoryEnabled == true)
            {
                DegradedMemoryCardsRecord pageCardRecord = new DegradedMemoryCardsRecord();
                try
                {
                    for (int iPage = DataFlashLocations.CardAccessExtraPagesCount; iPage < DataFlashLocations.CardAccessPageMaxNumber; iPage++)
                    {
                        // Check if page has been marked as corrupted, do not attempt to work with it in this session.
                        if (corruptedPages.IndexOf(iPage) >= 0)
                            continue;
                        // Read cards from the page.
                        pageCardRecord.Clear();
                        if (loadAndValidatePage(iPage, pageCardRecord) == true)
                        {
                            for (int iPageCard = 0; iPageCard < DataFlashLocations.CardAccessCardRecordsPerPage; iPageCard++)
                            {
                                if (pageCardRecord.Cards[iPageCard] != null && pageCardRecord.Cards[iPageCard].IsValidCard == true)
                                {
                                    lock (cards)
                                    {
                                        byte[] key = CardReaderUtilityFunctions.ConstructCardkey(
                                            pageCardRecord.Cards[iPageCard].CardData,
                                            pageCardRecord.Cards[iPageCard].CardBits);
                                        CardMetadataRecord value = new CardMetadataRecord()
                                        {
                                            LastUsed = pageCardRecord.Cards[iPageCard].LastUsed,
                                            PageNumber = iPageCard
                                        };

                                        // Stop any duplicate records from wiping out all degraded memory
                                        cards[key] = value;
                                    }
                                }
                            }
                        }
                        else
                        {
                            // Corrupted page try to restore
                            if (saveDataPage(iPage, pageCardRecord.InitialPageData) == false)
                            {
                                // Here we have corrupted data flash
                                markPageAsCorrupted(iPage);
                            }
                            else if (loadDataPage(iPage, out pageDataTemp) == false)
                            {
                                // Here we have corrupted data flash
                                markPageAsCorrupted(iPage);
                            }
                            else if (pageDataTemp.SequenceEqual(pageCardRecord.InitialPageData) == false)
                            {
                                // Here we have corrupted data flash
                                markPageAsCorrupted(iPage);
                            }
                        }
                        pageDataTemp = null;
                    }
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return agentLog("Number of loaded cards {0}, Number of corrupted pages {1}.", cards.Count, corruptedPages.Count);
                    });
                }
                finally
                {
                    pageCardRecord = null;
                }
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Finished reading degraded memory records.");
            });
        }

        private void markPageAsCorrupted(int pageNumber)
        {
            corruptedPages.Add(pageNumber);
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Degraded memory page corrupted. Page number: {0}.", pageNumber);
            });
        }

        private bool loadAndValidatePage(int pageNumber, IDegradedMemoryRecord record)
        {
            byte[] pageData;
            return loadAndValidatePage(pageNumber, record, out pageData);
        }

        private bool loadAndValidatePage(int pageNumber, IDegradedMemoryRecord record, out byte[] pageData)
        {
            if (loadDataPage(pageNumber, out pageData) == false)
            {
                pageData = null;
                // Unable to load page                
                return false;
            }
            if (record.Deserialize(pageData, Hal.Pcb.PcbType) == false)
            {
                pageData = null;
                // Unable to deserialize page
                return false;
            }
            return true;
        }

#if DEBUG

        /// <summary>
        /// Use this function to print diffs between two byte arrays.
        /// </summary>
        private string printCompareArrays(byte[] argNew, byte[] argExisting)
        {
            if (argNew == null)
                return "argNew is null.";
            if (argExisting == null)
                return "argExisting is null.";
            if (argNew.Length != argExisting.Length)
                return "argNew and argExisting are of different length.";
            StringBuilder sb = new StringBuilder();
#if DEBUG_ARRAY_DETAILS
            int count = 0;
            for (int i = 0; i < argExisting.Length; i++)
            {
                if (argNew[i] != argExisting[i])
                {
                    sb.Append(string.Format("{0}:{1}@{2} ", argNew[i].ToString("X2"), argExisting[i].ToString("X2"), i));
                    count++;
                }
                if (count > 50)
                {
                    sb.Append("... ");
                    break;
                }
            }
            sb.Append(string.Format("Found:{0}", count >= 50 ? "50+" : count.ToString()));
#else
            sb.Append(string.Format("[{0} bytes]", argNew.Length));
#endif
            return sb.ToString();
        }

        /// <summary>
        /// Use this function to debug degraded list.
        /// </summary>
        private string printDegradedList()
        {
            byte[] cardData;
            int cardLength;
            string outStr = string.Empty;
            foreach (var card in cards)
            {
                CardReaderUtilityFunctions.ParseCardkey(card.Key, out cardData, out cardLength);
                outStr += BitConverter.ToString(card.Key) + "," + BitConverter.ToString(cardData) + "," + cardLength.ToString() + Environment.NewLine;
            }
            return outStr;
        }

#endif

        protected override void Terminating()
        {                        
        }

        /// <summary>
        /// Used to erase the dataflash pages used for access control to factory default of all 0xFFs.
        /// </summary>
        public static void EraseMedia()
        {
#if DEBUG
            if (instancesCreated)
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("DataFlash.EraseMedia must not be called when the data flash is used for degraded memory storage!");
                });

                // Restart the device so that this issue is not ignored.
                Application.Closing = true;
                SingletonList.Closing = true;
            }
#endif

            byte[] emptyPage = new byte[DataFlashLocations.DataFlashPageSize];
            for (int i = 0; i < emptyPage.Length; i++)
            {
                emptyPage[i] = 0xFF;
            }

            byte[] readPage = new byte[DataFlashLocations.DataFlashPageSize];

            foreach (int cardAccessMemoryOffset in DataFlashLocations.CardAccessMemoryOffsets)
            {
                for (int i = cardAccessMemoryOffset; i < (cardAccessMemoryOffset + DataFlashLocations.CardAccessMemoryLength); i += emptyPage.Length)
                {
                    Hal.DataFlash.Instance.ReadData(i, readPage);
                    if (readPage.SequenceEqual(emptyPage) == false)
                        Hal.DataFlash.Instance.WriteData(i, emptyPage);
                }
            }
        }
    }
}
