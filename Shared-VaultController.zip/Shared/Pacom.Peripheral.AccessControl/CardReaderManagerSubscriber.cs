﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    public class CardReaderManagerSubscriber : IDisposable
    {
        private static CardReaderManagerSubscriber instance = null;

        public static CardReaderManagerSubscriber CreateInstance(IDeviceResponseProcessor deviceResponseProcessor)
        {
            if (instance == null)
                instance = new CardReaderManagerSubscriber(deviceResponseProcessor);
            return instance;
        }

        public static CardReaderManagerSubscriber Instance
        {
            get
            {
                if (instance == null)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return "CardReaderManagerSubscriber instance must be created before usage. Call CreateInstance() method before using this property.";
                    });
                }
                return instance;
            }
        }

        public CardReaderManagerSubscriber(IDeviceResponseProcessor deviceResponseProcessor)
        {
            CardReaderManager.Instance.SetDeviceResponseProcessor(deviceResponseProcessor);
        }
        
        #region IDisposable Members

        public void Dispose()
        {
            CardReaderManager.Instance.ClearDeviceResponseProcessor();
            instance = null;
        }

        #endregion
    }
}
