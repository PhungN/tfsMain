﻿using System;
using System.IO;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using CardReaderConsts = Pacom.Peripheral.AccessControl.CardReaderHardwareLocations;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// This class controls door operations. It supports two readers and one door.
    /// </summary>
    public class CardReaderManager : ICardReaderManager, IDisposable
    {
        #region Instance management

        /// <summary>
        /// Singleton instance of CardReaderManager class
        /// </summary>
        private static CardReaderManager instance = null;

        public static CardReaderManager CreateInstance()
        {
            if (instance == null)
                instance = new CardReaderManager();
            Logger.CardReaderManager = instance;
            return instance;
        }

        /// <summary>
        /// Instance method to get singleton
        /// </summary>
        /// <returns></returns>
        public static CardReaderManager Instance
        {
            get
            {
                if (instance == null)
                    instanceMustBeCreated();
                return instance;
            }
        }

        /// <summary>
        /// Card reader manager constructor.
        /// </summary>
        private CardReaderManager()
        {
            initialize();
        }

        private static void instanceMustBeCreated()
        {
            Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return "Instance must be created before usage. Call CreateInstance() method before using this property.";
            });
        }

        #endregion

        /// <summary>
        /// Notify access control classes that the application is now assembled.
        /// </summary>
        /// <param name="deviceResponseProcessor">An instance to device response processor</param>
        public void SetDeviceResponseProcessor(IDeviceResponseProcessor deviceResponseProcessor)
        {
            foreach (var agent in doors)
            {
                agent.SetDeviceResponseProcessor(deviceResponseProcessor);
            }
        }

        /// <summary>
        /// Notify access control classes that the application is disassembling.
        /// </summary>
        public void ClearDeviceResponseProcessor()
        {
            foreach (var agent in doors)
            {
                agent.ClearDeviceResponseProcessor();
            }
        }

        // Number of doors supported by this device
        private DeviceDoorAgent[] doors = null;

        /// <summary>
        /// Manager initialization
        /// </summary>
        private void initialize()
        {
            doors = new DeviceDoorAgent[ConfigurationManager.DoorsCount];
            foreach (int logicalDoorId in CardReaderConsts.HandledLogicalDoorIds)
            {
                doors[logicalDoorId - 1] = new DeviceDoorAgent(logicalDoorId,
                    CardReaderConsts.DoorReaderTypes[logicalDoorId][CardReaderConsts.DoorEntryReaderIndex],
                    CardReaderConsts.DoorReaderTypes[logicalDoorId][CardReaderConsts.DoorExitReaderIndex]);
            }
        }

        /// <summary>
        /// Get door agent based on reader type.
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        private DeviceDoorAgent getDeviceDoorAgent(CardReaderPortType reader)
        {
            foreach (int logicalDoorId in CardReaderConsts.HandledLogicalDoorIds)
            {
                if (CardReaderConsts.DoorReaderTypes[logicalDoorId][CardReaderConsts.DoorEntryReaderIndex] == reader ||
                    CardReaderConsts.DoorReaderTypes[logicalDoorId][CardReaderConsts.DoorExitReaderIndex] == reader)
                {
                    return doors[logicalDoorId - 1];
                }
            }
            return null;
        }

        /// <summary>
        /// This method processes card data received in Wiegand format from readers.
        /// </summary>
        /// <param name="readerNumber">Reader id between 0..4 as by the enumerator.</param>
        /// <param name="cardLength">Scanned card length</param>
        /// <param name="cardData">Scanned raw byte array</param>
        /// <param name="valid">Set to true if collision has been detected</param>
        public void ProcessScan(CardReaderPortType readerNumber, int cardLength, byte[] cardData, bool valid)
        {
            ProcessScan(readerNumber, cardLength, cardData, valid, false);
        }

        /// <summary>
        /// This method processes card data received in Wiegand format from readers.
        /// </summary>
        /// <param name="readerNumber">Reader id between 0..4 as by the enumerator.</param>
        /// <param name="cardLength">Scanned card length</param>
        /// <param name="cardData">Scanned raw byte array</param>
        /// <param name="valid">Set to true if collision has been detected</param>
        /// <param name="isUnauthorizedCard">Set to true if smartcard is blacklist or standard scan with mutual authentication required</param>
        public void ProcessScan(CardReaderPortType readerNumber, int cardLength, byte[] cardData, bool valid, bool isUnauthorizedCard)
        {
            if (disposing == true)
                return;
            // Get door agent
            var doorAgent = getDeviceDoorAgent(readerNumber);
            if (doorAgent == null)
                return;
            // If conflicts occurred signal to user
            if (valid == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return "Card scan [Collision] detected !";
                });
                doorAgent.ProcessInvalidScan();
                return;
            }

            // Format card data
            byte[] cardDataClean;
            int numBytes = (cardLength / 8) + ((cardLength % 8) != 0 ? 1 : 0);
            try
            {
                if (cardData.Length == 32)
                {
                    cardDataClean = cardData;
                }
                else
                {                    
                    cardDataClean = new byte[32];
                    Array.Copy(cardData, cardDataClean, Math.Min(cardData.Length, numBytes));
                }
            }
            catch
            {
                // Unable to cut needed bytes out of the incoming data. 
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("Reader {0} card scan aborted.", readerNumber);
                });
                return;
            }

            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
#if DEBUG
                return string.Format("Reader {0} card scan, {1} bits, {2}", readerNumber, cardLength, BitConverter.ToString(cardDataClean, 0, Math.Min(cardData.Length, numBytes)));
#else
                return string.Format("Reader {0} card scan, {1} bits, {2}", readerNumber, cardLength, "******");
#endif
            });

            // Only bother if there is card data to process.
            // Keypad data is minimum 4 bits, and the system is design to process maximum 255 bits.
            if (cardLength < 4 || cardLength > 255)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return "Card scan processing is skipped.";
                });
                return;
            }

            doorAgent.ProcessScan(readerNumber, cardLength, cardDataClean, isUnauthorizedCard);
        }

        /// <summary>
        /// Process controller command.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="command"></param>
        public void ProcessControllerCommand(CardReaderPortType readerNumber, CardReaderCommandDataConfig command)
        {
            if (disposing == true)
                return;
            // Make sure all data is good.
            if (command == null || readerNumber == CardReaderPortType.NoReader)
                return;
            // Get door agent
            var doorAgent = getDeviceDoorAgent(readerNumber);
            if (doorAgent == null)
                return;
            doorAgent.PeripheralsChange(readerNumber, command);
        }

        public void ProcessDisplaySecurityLevelCommand(int readerId, CardReaderDisplaySecurityLevelConfig config)
        {
            if (disposing == true)
                return;
            var doorAgent = getDeviceDoorAgent((CardReaderPortType)(readerId));
            if (doorAgent != null)
            {
                doorAgent.SetDisplaySecurityLevel(readerId, config);
            }
        }

        /// <summary>
        /// Process format mask configuration from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="command"></param>
        public void ProcessFormatMask(CardReaderPortType readerNumber, CardFormatMasksConfig mask)
        {
            if (disposing == true)
                return;
            // Make sure all data is good.
            if (mask == null || readerNumber == CardReaderPortType.NoReader)
                return;
            // Get door agent
            var doorAgent = getDeviceDoorAgent(readerNumber);
            if (doorAgent == null)
                return;
            doorAgent.FormatsChange(readerNumber, mask);
        }

        /// <summary>
        /// Process format parities configuration from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="command"></param>
        public void ProcessFormatParity(CardReaderPortType readerNumber, CardFormatParityConfig parity, int formatNumber)
        {
            if (disposing == true)
                return;
            // Make sure all data is good.
            if (parity == null || readerNumber == CardReaderPortType.NoReader)
                return;
            // Get door agent
            var doorAgent = getDeviceDoorAgent(readerNumber);
            if (doorAgent == null)
                return;
            doorAgent.ParityChange(readerNumber, parity, formatNumber);
        }

        /// <summary>
        /// This method is called when initialization record is received from controller.
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public void InitializeReader(CardReaderPortType readerNumber, ReaderInitializationConfig config)
        {
            if (disposing == true)
                return;
            // Get door agent
            var doorAgent = getDeviceDoorAgent(readerNumber);
            if (doorAgent == null)
                return;
            doorAgent.InitializeReader(readerNumber, config, InitializationSource.Controller);
        }

        /// <summary>
        /// Add or delete cards to degraded memory from message directed to this device. 
        /// </summary>
        /// <param name="readerNumber"></param>
        /// <param name="config"></param>
        public void ProcessDegradedModeLegacyCodeActionForThisDevice(CardReaderPortType readerNumber, ReaderDegradedMemoryConfig degConfig, byte[] rawCardNumber)
        {
            if (disposing == true)
                return;
            // Get door agent
            var doorAgent = getDeviceDoorAgent(readerNumber);
            if (doorAgent == null)
                return;
            doorAgent.ProcessDegradedModeLegacyCodeAction(readerNumber, degConfig, rawCardNumber);
        }

        /// <summary>
        /// Add or delete cards to degraded memory via broadcast.
        /// </summary>
        /// <param name="config"></param>
        public void ProcessDegradedModeLegacyCodeActionBroadcast(ReaderDegradedMemoryConfig degConfig, byte[] rawCardNumber)
        {
            if (disposing == true)
                return;
            foreach (var doorAgent in doors)
            {
                doorAgent.ProcessDegradedModeLegacyCodeAction(CardReaderPortType.NoReader, degConfig, rawCardNumber);
            }
        }

        /// <summary>
        /// Delete a card from degraded memory.
        /// </summary>
        /// <param name="legacyCardDetails"></param>
        /// <param name="rawCardDetails"></param>
        public void ProcessDeleteCardBroadcast(ReaderDegradedMemoryConfig legacyCardDetails, byte[] rawCardNumber, int rawCardLength)
        {
            if (disposing == true)
                return;
            foreach (var doorAgent in doors)
            {
                // Take a copy as we may need to manipulate the card number to go from 8002's raw card number format to the 8603's native format.
                // If a copy is not taken, the array may be manipulated on the first door the delete occurs on and then no card delete takes place on
                // the second door.

                byte[] rawCardNumberCopy = new byte[rawCardNumber.Length];
                Buffer.BlockCopy(rawCardNumber, 0, rawCardNumberCopy, 0, rawCardNumber.Length);

                doorAgent.ProcessDeleteCardBroadcast(legacyCardDetails, rawCardNumberCopy, rawCardLength);
            }
        }

        /// <summary>
        /// Call made by logger to populate this module with any logging information.
        /// </summary>
        /// <param name="textWriter">Stream used to provide textual logging.</param>
        public void CardReaderInfo(TextWriter textWriter)
        {
            try
            {
                if (textWriter == null)
                {
                    return;
                }
                textWriter.WriteLine("Access Control Interface Information");
                textWriter.WriteLine();

                foreach (var doorAgent in doors)
                {
                    doorAgent.IndividualInfo(textWriter);
                    textWriter.WriteLine();
                }
            }
            catch
            {
                textWriter.WriteLine("...");
                textWriter.WriteLine();
                textWriter.WriteLine("Unable to create readers configuration capture.");
            }
        }

        /// <summary>
        /// Get the count of all cards stored in degraded memory for both doors
        /// </summary>
        /// <returns>Cards count</returns>
        public int CountCardholder()
        {
            if (doors == null || doors.Length == 0)
                return 0;

            int count = 0;
            foreach (var doorAgent in doors)
            {
                count += doorAgent.DegradedMemoryCardCount;
            }
            return count;
        }

        #region IDisposable Members
                
        private bool disposed = false;

        private bool disposing = false;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    this.disposing = true;
                    Logger.CardReaderManager = null;
                    for (int i = 0; i < doors.Length; i++)
                    {
                        doors[i].Dispose();
                        doors[i] = null;
                    }
                    doors = null;
                }
                disposed = true;
            }
        }

        ~CardReaderManager()
        {
            Dispose(false);
        }

        #endregion
    }
}
