﻿using System;
using System.Threading;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// Base class for implementing 
    /// </summary>
    internal abstract class DegradedMemoryAgentBase : IDegradedMemoryAgent
    {
        protected readonly int doorHardwareId;

        protected const int entryReaderId = 0;

        protected const int exitReaderId = 1;

        protected abstract string agentLogFix { get; }

        /// <summary>
        /// Stores entry reader settings and initialization.
        /// </summary>
        protected DegradedMemorySettingsRecord readerInitializationEntry = new DegradedMemorySettingsRecord();

        /// <summary>
        /// Stores exit reader settings and initialization.
        /// </summary>
        protected DegradedMemorySettingsRecord readerInitializationExit = new DegradedMemorySettingsRecord();

        /// <summary>
        /// Stores master card details for entry reader.
        /// </summary>
        protected DegradedMemoryMasterCardRecord readerMasterCardsEntry = new DegradedMemoryMasterCardRecord();

        /// <summary>
        /// Stores master card details for exit reader.
        /// </summary>
        protected DegradedMemoryMasterCardRecord readerMasterCardsExit = new DegradedMemoryMasterCardRecord();

        /// <summary>
        /// This delegate is called when the loading cards is finished from degraded memory.
        /// It returns reader configuration.
        /// </summary>
        protected DegradedMemoryCardLoadingFinishedDelegate cardLoadingFinished;

        /// <summary>
        /// This delegate is called just before degraded memory persisting process begins.
        /// It expects door configuration to be supplied.
        /// </summary>
        protected DegradedMemoryRequestDoorConfigurationDelegate requestDoorConfiguration;

        /// <summary>
        /// This delegate is used to request comparison of legacy card with degraded memory record. Decide if it should be deleted.
        /// </summary>
        protected DegradedMemoryLegacyDeleteCardComparer legacyDeleteComparer;

        /// <summary>
        /// Cards cannot be added when loading procedure is in progress.
        /// Any cards requested to be added, will be ignored.
        /// </summary>
        private bool loadCardsFinished = false;

        internal bool LoadCardsFinished
        {
            get { return loadCardsFinished; }
        }

        private Random randomizer = new Random();

        /// <summary>
        ///  Get unique time delay based on door hardware index.
        /// </summary>
        /// <returns></returns>
        protected int getRandomDoorValue()
        {
            return randomizer.Next(1, 100) * (this.doorHardwareId + 1);
        }

        /// <summary>
        /// In case when agent is proven useless this will be marked as true.
        /// </summary>
        protected bool degradedMemoryOffline = false;

        protected void setDegradedMemoryOffline()
        {
            // Terminate the persisting timer
            degradedMemoryOffline = true;
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Degraded memory is forced to offline state.");
            });
        }

        /// <summary>
        /// Abstract class constructor
        /// </summary>
        public DegradedMemoryAgentBase(int doorHardwareId)
        {
            this.doorHardwareId = doorHardwareId;
            this.delayedUpdateCardDatabaseAction = new DelayedConfigurationAgent(2000 + getRandomDoorValue(), LoggerClassPrefixes.AccessControlManager);
            this.delayedUpdateCardDatabaseAction.ConfigurationChangedMethod = updateCardDatabaseCallback;
            ConfigurationManager.Instance.ConfigurationChanged += new EventHandler<EventArgs>(configurationManager_ConfigurationChanged);
        }

        void configurationManager_ConfigurationChanged(object sender, EventArgs e)
        {
            if (ConfigurationManager.Instance.Doors[doorHardwareId + 1].DegradedMemoryEnabled == false && CardCount > 0)
                updateCardDatabaseCallback();
        }

        protected DelayedConfigurationAgent delayedUpdateCardDatabaseAction = null;

        #region IDegradedMemoryAgent Members

        /// <summary>
        /// Set delegate which is called when the loading cards is finished from degraded memory.
        /// It returns reader configuration for applying when the controller is offline.
        /// </summary>
        public void SetCardLoadingFinishedDelegate(DegradedMemoryCardLoadingFinishedDelegate method)
        {
            cardLoadingFinished = method;
        }

        /// <summary>
        /// Set delegate which is called just before degraded memory persisting process begins.
        /// It expects door configuration to be supplied.
        /// </summary>
        /// <returns>Returns set of reader configuration for the door. 
        /// If null is returned the system if not online, and the previous configuration must persist.</returns>
        public void SetRequestDoorConfigurationDelegate(DegradedMemoryRequestDoorConfigurationDelegate function)
        {
            requestDoorConfiguration = function;
        }

        /// <summary>
        /// Set delegate for comparing legacy card with degraded memory records.
        /// </summary>
        public void SetLegacyDeleteCardComparerDelegate(DegradedMemoryLegacyDeleteCardComparer function)
        {
            legacyDeleteComparer = function;
        }

        /// <summary>
        /// Returned type for this degraded memory agent.
        /// </summary>
        public string AgentType { get { return agentLogFix; } }

        /// <summary>
        /// Number of active cards held by this degraded memory agent.
        /// </summary>
        public virtual int CardCount { get { return 0; } }

        /// <summary>
        /// Number of maximum active cards held by this degraded memory agent.
        /// </summary>
        public virtual int MaxActiveCards { get { return 0; } }
        
        private bool cardAndConfigurationRequestReceived = false;

        protected bool deleteAllCards = false;

        /// <summary>
        /// Request degraded memory agent to load cards and configuration. Should happen on startup.
        /// </summary>
        public void LoadCardAndConfiguration(bool deleteAllCards)
        {
            // Allow only once to load the card configuration
            if (cardAndConfigurationRequestReceived)
                return;
            this.deleteAllCards = deleteAllCards;
            cardAndConfigurationRequestReceived = true;
            loadCardsAndConfigurationBase();
        }

        /// <summary>
        /// Persist configuration and cards to degraded memory.
        /// </summary>
        public void Persist()
        {
            if (degradedMemoryOffline)
                return;
            try
            {
                delayedUpdateCardDatabaseAction.ScheduleUpdate();
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Fatal error while forcing write of data to degraded memory. {0}", ex.Message);
                });
            }
        }

        /// <summary>
        /// Thread method used to load cards and configuration from degraded memory
        /// </summary>
        private void loadCardsAndConfigurationBase()
        {
            try
            {
                loadCardsAndConfiguration();
                if (deleteAllCards)
                {
                    DeleteAll();
                    deleteAllCards = false;
                }
                // Notify manager and others that the degraded memory has loaded configuration and cards.
                if (cardLoadingFinished != null)
                {
                    DegradedMemoryDoorConfiguration doorConfiguration = new DegradedMemoryDoorConfiguration();
                    // Entry
                    var entryReader = doorConfiguration.AddReader(entryReaderId);
                    entryReader.InitializationConfig = readerInitializationEntry.ReaderInitializationRecord;
                    entryReader.FormatConfig = readerInitializationEntry.AccessPointCardFormats;
                    entryReader.MasterCard = readerMasterCardsEntry.GetMasterCard();
                    // Exit
                    var exitReader = doorConfiguration.AddReader(exitReaderId);
                    exitReader.InitializationConfig = readerInitializationExit.ReaderInitializationRecord;
                    exitReader.FormatConfig = readerInitializationExit.AccessPointCardFormats;
                    exitReader.MasterCard = readerMasterCardsExit.GetMasterCard();
                    // Call the subscriber that the job is done.
                    cardLoadingFinished(doorConfiguration);
                }
                loadCardsFinished = true;
            }
            catch
            {
                readerInitializationEntry.Clear();
                readerInitializationExit.Clear();
                readerMasterCardsEntry.Clear();
                readerMasterCardsExit.Clear();
                setDegradedMemoryOffline();
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Fatal error while reading degraded memory records");
                });
            }           
        }

        protected abstract void loadCardsAndConfiguration();

        public abstract bool CardExists(byte[] cardData, int cardLength);

        public abstract bool AddCard(byte[] cardData, int cardLength, LegacyCardRecord legacyCardData);

        public abstract bool DeleteCard(LegacyCardRecord cardData);

        public abstract bool DeleteCard(byte[] cardData, int cardLength);

        public abstract bool DeleteAll();
        
        #endregion
               
        protected abstract void updateCardDatabaseCallback();
        
        protected string agentLog(string message, params object[] parameters)
        {
            return string.Format("Door {0}: [{1}] {2}", doorHardwareId + 1, agentLogFix, string.Format(message, parameters));
        }

        protected static bool translateLegacyCardNumberToNativeCardNumber(byte[] legacyCardNumber, int cardBitLength, out byte[] nativeCardNumber)
        {
            nativeCardNumber = null;
            if (cardBitLength < 4 || legacyCardNumber == null || legacyCardNumber.Length != 8)
                return false;

            int requiredBytes;
            if (cardBitLength % 8 == 0)
            {
                requiredBytes = cardBitLength / 8;
                if (requiredBytes > 8)
                    requiredBytes = 8;
                nativeCardNumber = new byte[32];
                Buffer.BlockCopy(legacyCardNumber, (8 - requiredBytes), nativeCardNumber, 0, requiredBytes);
            }
            else
            {
                requiredBytes = (cardBitLength / 8) + 1;
                int shiftBy = (requiredBytes * 8) - cardBitLength;
                if (requiredBytes > 8)
                    requiredBytes = 8;
                nativeCardNumber = new byte[32];
                Buffer.BlockCopy(legacyCardNumber, (8 - requiredBytes), nativeCardNumber, 0, requiredBytes);
                for (int i = 0; i < requiredBytes; i++)
                {
                    if (i == 0)
                    {
                        nativeCardNumber[i] = (byte)(nativeCardNumber[i] << shiftBy);
                    }
                    else
                    {
                        nativeCardNumber[i - 1] = (byte)(nativeCardNumber[i - 1] | (byte)(nativeCardNumber[i] >> (8 - shiftBy)));
                        nativeCardNumber[i] = (byte)(nativeCardNumber[i] << shiftBy);
                    }
                }
            }

            return true;
        }

        protected static int getSmallestBitCount(byte[] legacyCardNumber)
        {
            if (legacyCardNumber.Length != 8)
                return 26;   // 26-bits is a sensible default 

            int highestBit = 0;
            int byteOfInterest = 0;
            if (legacyCardNumber[7] != 0)
                byteOfInterest = 7;
            else if (legacyCardNumber[6] != 0)
                byteOfInterest = 6;
            else if (legacyCardNumber[5] != 0)
                byteOfInterest = 5;
            else if (legacyCardNumber[4] != 0)
                byteOfInterest = 4;
            else if (legacyCardNumber[3] != 0)
                byteOfInterest = 3;
            else if (legacyCardNumber[2] != 0)
                byteOfInterest = 2;
            else if (legacyCardNumber[1] != 0)
                byteOfInterest = 1;

            highestBit = byteOfInterest * 8;

            if ((legacyCardNumber[byteOfInterest] & 0x80) != 0)
                highestBit += 8;
            else if ((legacyCardNumber[byteOfInterest] & 0x40) != 0)
                highestBit += 7;
            else if ((legacyCardNumber[byteOfInterest] & 0x20) != 0)
                highestBit += 6;
            else if ((legacyCardNumber[byteOfInterest] & 0x10) != 0)
                highestBit += 5;
            else if ((legacyCardNumber[byteOfInterest] & 0x08) != 0)
                highestBit += 4;
            else if ((legacyCardNumber[byteOfInterest] & 0x04) != 0)
                highestBit += 3;
            else if ((legacyCardNumber[byteOfInterest] & 0x02) != 0)
                highestBit += 2;
            else if ((legacyCardNumber[byteOfInterest] & 0x01) != 0)
                highestBit += 1;

            return highestBit;
        }

        #region IDisposable Members

        protected bool disposed = false;

        protected bool disposing = false;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Terminating()
        {
        }

        protected virtual void Dispose(bool disposing)
        {
            if (this.disposed == false)
            {
                this.disposing = true;
                // Make sure the persisting action is finished.
                delayedUpdateCardDatabaseAction.CancelScheduledUpdate();
                delayedUpdateCardDatabaseAction.WaitForCallbackIfInProgress();                
                // Persist configuration the last time
                updateCardDatabaseCallback();
                delayedUpdateCardDatabaseAction.Dispose();
                delayedUpdateCardDatabaseAction = null;
                cardLoadingFinished = null;
                requestDoorConfiguration = null;
                legacyDeleteComparer = null;
                Terminating();
                Logger.LogCriticalMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Degraded memory agent is disposed.");
                });
            }
            disposed = true;
        }
              
        #endregion
    }
}
