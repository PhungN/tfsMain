﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utils;
using Pacom.Peripheral.Communications;
using Pacom.Peripheral.Hal;
using CardReaderConsts = Pacom.Peripheral.AccessControl.CardReaderHardwareLocations;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// Object describing the working of door. It is handling up to two door readers, one set of door peripherals, and a stream of degraded memory.
    /// Degraded memory can be stored in SD card or data flash.
    /// </summary>
    internal partial class DeviceDoorAgent : IDisposable
    {
        public int DoorLogicalId
        {
            get;
            private set;
        }

        private readonly CardReaderPortType entryReader;

        private const int entryReaderId = 0;

        private readonly CardReaderPortType exitReader;

        private const int exitReaderId = 1;

        internal DeviceDoorAgent(int doorLogicalId, CardReaderPortType entryReader, CardReaderPortType exitReader)
        {
            this.DoorLogicalId = doorLogicalId;
            this.entryReader = entryReader;
            this.exitReader = exitReader;
            try
            {
                accessPointConfiguration[entryReaderId] = new AccessPointConfiguration(entryReader);
                accessPointConfiguration[exitReaderId] = new AccessPointConfiguration(exitReader);

                // Assign initial states for inputs. Do not use Unknown as the message to controller cannot process these.
                peripheralInputStates[doorContactStateIndex] = Common.InputStatus.Secure;
                peripheralInputStates[egressStateIndex] = Common.InputStatus.Secure;
                peripheralInputStates[strikeStateIndex] = Common.InputStatus.Secure;
                peripheralInputStates[spareStateIndex] = Common.InputStatus.Secure;

                // Hook-up events for access control peripherals 
                accessPointPeripherals.OnStrikeStateChange += new EventHandler<OutputStateChangeArgs>(accessPointPeripherals_OnStrikeStateChange);
                accessPointPeripherals.OnBuzzerStateChange += new EventHandler<BuzzerStateChangeArgs>(accessPointPeripherals_OnBuzzerStateChange);
                accessPointPeripherals.OnRedLedStateChange += new EventHandler<LedStateChangeArgs>(accessPointPeripherals_OnRedLedStateChange);
                accessPointPeripherals.OnGreenLedStateChange += new EventHandler<LedStateChangeArgs>(accessPointPeripherals_OnGreenLedStateChange);
                accessPointPeripherals.OnSpareOutputStateChange += new EventHandler<OutputStateChangeArgs>(accessPointPeripherals_OnSpareOutputStateChange);
                accessPointPeripherals.DisplaySecurityLevelStateChange += new EventHandler<DisplaySecurityLevelChangeEventArgs>(onDisplaySecurityLevelStateChange);

                CreateDegradedMemoryAgent();

#if DEBUG_TEST_OFFLINE_EVENTS
                for (int i=0; i<1000; i++)
                {
                    offlineAccessGranted(entryReader, 37, new byte[] { (byte)(i >> 8), (byte)(i & 0xFF) , 0x45, 0x56, 0x78, 0x67, 0xFE });
                }
#endif
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("{0} agent has been created.", this.ToString());
                });
            }
            catch
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("Fatal error while creating {0} environment.", this.ToString());
                });
            }

            // Turn off peripherals
            accessPointPeripherals.ClearStrike();
            accessPointPeripherals.SetNormalBuzzer(CardReaderBuzzerType.BuzzerOff, 1, 0);
            accessPointPeripherals.SetNormalRedLed(CardReaderLedType.LedOff, 1, 0);
            accessPointPeripherals.SetNormalGreenLed(CardReaderLedType.LedOff, 1, 0);
                        
            // Get the rest of the input events
            StatusManager.Instance.Inputs.UnmaskedInputChangedStatus += new EventHandler<InputChangedStatusEventArgs>(inputs_InputChangedStatus);

            // Subscribe to controller online/offline. Agent will try to send input status, so forced doors on startup will not go unnoticed.
            StatusManager.Instance.Device.ConnectedToControllerChanged += new EventHandler<ConnectedToControllerEventArgs>(device_ConnectedToControllerChanged);
        }
                
        #region Device Response Processor

        private IDeviceResponseProcessor deviceResponseProcessor = null;

        /// <summary>
        /// Set device response processor as the application is now assembled.
        /// </summary>
        /// <param name="deviceResponseProcessor">An instance of device response processor.</param>
        public void SetDeviceResponseProcessor(IDeviceResponseProcessor deviceResponseProcessor)
        {
            this.deviceResponseProcessor = deviceResponseProcessor;
            sendDoorInputsToController();
        }

        /// <summary>
        /// Clear device response processor as the application is disassembled.
        /// </summary>
        public void ClearDeviceResponseProcessor()
        {
            this.deviceResponseProcessor = null;
        }

        #endregion

        #region Peripherals Events and Processing

        /// <summary>
        /// Time given to enter a PIN plus the time taken for the controller to process the card scan. (In milliseconds)
        /// </summary>
        private const int controllerCommandMaxResponseTime = 20000;

        /// <summary>
        /// Access point (the whole door) peripheral logic
        /// </summary>        
        private AccessPointPeripheralAgent accessPointPeripherals = new AccessPointPeripheralAgent();

        private const int doorContactStateIndex = 0;
        private const int egressStateIndex = 1;
        private const int strikeStateIndex = 2;
        private const int spareStateIndex = 3;

        /// <summary>
        /// Buffer states as they come along.
        /// </summary>
        private Common.InputStatus[] peripheralInputStates = new Common.InputStatus[4];
        
        private void accessPointPeripherals_OnStrikeStateChange(object sender, OutputStateChangeArgs e)
        {
            // All input configuration will be processed when entry reader is configured.
            AccessPointConfiguration config = accessPointConfiguration[entryReaderId];
            if (config != null && config.InitializedReaderType != CardReaderType.NoReader)
            {
                bool strikeOutput = e.OutputState;
                if (config.DeviceLoopConfig.ReaderInitializationRecord.StrikeRelayNormallyClosed == true)
                {
                    strikeOutput = !strikeOutput;
                }

                if (strikeOutput == true)
                {
                    OnboardOutputs.Instance.SetOutput(CardReaderConsts.OnboardDoorOutputIds[this.DoorLogicalId][CardReaderConsts.DoorOutputStrikeIndex]);
                }
                else
                {
                    OnboardOutputs.Instance.ClearOutput(CardReaderConsts.OnboardDoorOutputIds[this.DoorLogicalId][CardReaderConsts.DoorOutputStrikeIndex]);
                }
            }
            else
            {
                OnboardOutputs.Instance.ClearOutput(CardReaderConsts.OnboardDoorOutputIds[this.DoorLogicalId][CardReaderConsts.DoorOutputStrikeIndex]);
            }
        }

        private void accessPointPeripherals_OnSpareOutputStateChange(object sender, OutputStateChangeArgs e)
        {
            // All input configuration will be processed when card reader 1 is configured.
            AccessPointConfiguration config = accessPointConfiguration[entryReaderId];
            if (CardReaderConsts.IsOutputHandled(CardReaderConsts.DoorOutputSpareIndex) == true
                && config != null
                && config.DeviceLoopConfig.ReaderInitializationRecord.ReaderType != CardReaderType.NoReader)
            {
                if (e.OutputState == true)
                {
                    OnboardOutputs.Instance.SetOutput(CardReaderConsts.OnboardDoorOutputIds[this.DoorLogicalId][CardReaderConsts.DoorOutputSpareIndex]);
                }
                else
                {
                    OnboardOutputs.Instance.ClearOutput(CardReaderConsts.OnboardDoorOutputIds[this.DoorLogicalId][CardReaderConsts.DoorOutputSpareIndex]);
                }
            }
            else
            {
                OnboardOutputs.Instance.ClearOutput(CardReaderConsts.OnboardDoorOutputIds[this.DoorLogicalId][CardReaderConsts.DoorOutputSpareIndex]);
            }
        }

        private void accessPointPeripherals_OnBuzzerStateChange(object sender, BuzzerStateChangeArgs e)
        {
            // All input configuration will be processed when card reader 1 is configured.
            AccessPointConfiguration config = accessPointConfiguration[entryReaderId];
            if (config != null && config.InitializedReaderType != CardReaderType.NoReader)
            {
                StatusManager.Instance.Doors[this.DoorLogicalId].BuzzerState = e.BuzzerState;
            }
            else
            {
                OnboardOutputs.Instance.ClearOutput(CardReaderConsts.OnboardDoorOutputIds[this.DoorLogicalId][CardReaderConsts.DoorOutputBuzzerIndex]);
            }
        }

        private void accessPointPeripherals_OnRedLedStateChange(object sender, LedStateChangeArgs e)
        {
            // All input configuration will be processed when card reader 1 is configured.
            AccessPointConfiguration config = accessPointConfiguration[entryReaderId];
            if (config != null && config.InitializedReaderType != CardReaderType.NoReader)
            {
                StatusManager.Instance.Doors[this.DoorLogicalId].DeniedLedState = e.LedState;
            }
            else
            {
                OnboardOutputs.Instance.ClearOutput(CardReaderConsts.OnboardDoorOutputIds[this.DoorLogicalId][CardReaderConsts.DoorOutputRedLedIndex]);
            }
        }

        private void accessPointPeripherals_OnGreenLedStateChange(object sender, LedStateChangeArgs e)
        {
            // All input configuration will be processed when card reader 1 is configured.
            AccessPointConfiguration config = accessPointConfiguration[entryReaderId];
            if (config != null && config.InitializedReaderType != CardReaderType.NoReader)
            {
                StatusManager.Instance.Doors[this.DoorLogicalId].AcceptLedState = e.LedState;
            }
            else
            {
                OnboardOutputs.Instance.ClearOutput(CardReaderConsts.OnboardDoorOutputIds[this.DoorLogicalId][CardReaderConsts.DoorOutputGreenLedIndex]);
            }
        }

        private void onDisplaySecurityLevelStateChange(object sender, DisplaySecurityLevelChangeEventArgs e)
        {
            StatusManager.Instance.Doors[this.DoorLogicalId].TriggerDisplaySecurityLevelCommand(e);
        }
        /// <summary>
        /// Process input states, and inform controller about any changes. All input states are buffered here.
        /// NOTE: Configuration from entry reader is used to communicate with controller.
        /// </summary>
        /// <param name="sender">Not used</param>
        /// <param name="e">Event argument with changed input details.</param>
        private void inputs_InputChangedStatus(object sender, InputChangedStatusEventArgs e)
        {
            try
            {
                if (e == null || e.Status == null || e.Owner != OwnerType.Onboard)
                    return;
                bool inputStatusChanged = processInputStatus(e.PointNumberOnParent, e.Status.UnmaskedStatus);
                if (inputStatusChanged)
                    dispatchInputStatus();
            }
            catch
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("Fatal error while processing {0} peripheral input event.", this.ToString());
                });
            }
        }

        /// <summary>
        /// Pull the input statuses from Status Manager and unconditionally dispatch to controller if possible. The reader must be configured.
        /// </summary>
        private void refreshDoorInputsFromStatus()
        {
            try
            {
                // All input configuration will be processed when entry card reader is configured.
                AccessPointConfiguration config = accessPointConfiguration[entryReaderId];
                if (config == null || config.InitializedReaderType == CardReaderType.NoReader)
                    return;

                foreach (var pointNumberOnParent in CardReaderConsts.OnboardDoorInputIds[this.DoorLogicalId])
                {
                    int inputLogicalId = ConfigurationManager.Instance.Inputs.LogicalInputId(OwnerType.Onboard, pointNumberOnParent);
                    var inputStatus = StatusManager.Instance.Inputs[inputLogicalId];
                    processInputStatus(pointNumberOnParent, inputStatus.UnmaskedStatus);
                }
                dispatchInputStatus();
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("Fatal error while resending peripheral input for {0} to controller. {1}", this.ToString(), ex.Message);
                });
            }
        }

        private void device_ConnectedToControllerChanged(object sender, ConnectedToControllerEventArgs e)
        {
            if (e.Connected == true)
            {
                sendDoorInputsToController();
            }
            else
            {
                // Turn off peripherals
                accessPointPeripherals.ClearStrike();
                accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerOff, 1, 0);
                accessPointPeripherals.SetNormalBuzzer(CardReaderBuzzerType.BuzzerOff, 1, 0);
                accessPointPeripherals.SetCurrentRedLed(CardReaderLedType.LedOff, 1, 0);
                accessPointPeripherals.SetNormalRedLed(CardReaderLedType.LedOff, 1, 0);
                accessPointPeripherals.SetCurrentGreenLed(CardReaderLedType.LedOff, 1, 0);
                accessPointPeripherals.SetNormalGreenLed(CardReaderLedType.LedOff, 1, 0);
            }
        }

        private bool isAnyDoorInputInAlarm()
        {
            if (peripheralInputStates[doorContactStateIndex] == Common.InputStatus.Alarm
                || peripheralInputStates[egressStateIndex] == Common.InputStatus.Alarm
                || peripheralInputStates[strikeStateIndex] == Common.InputStatus.Alarm
                || peripheralInputStates[spareStateIndex] == Common.InputStatus.Alarm)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Process input status
        /// </summary>
        /// <param name="inputNumber">Point number on parent for the input.</param>
        /// <param name="inputStatus">Input status.</param>
        /// <returns>Returns true if the input has changed.</returns>
        private bool processInputStatus(int inputNumber, Common.InputStatus inputStatus)
        {            
            // All input configuration will be processed when entry card reader is configured.
            AccessPointConfiguration config = accessPointConfiguration[entryReaderId];
            if (config == null || config.InitializedReaderType == CardReaderType.NoReader)
                return false;

            bool stateChanged = false;
            // Validate reader inputs and make a note of the status change.
            if (inputNumber == CardReaderConsts.OnboardDoorInputIds[this.DoorLogicalId][CardReaderConsts.DoorInputStrikeIndex]
                && peripheralsValidInputState(inputStatus))
            {
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("{0} strike input point {1} changed status to {2}.", this.ToString(), (inputNumber + 1).ToString(), inputStatus.ToString());
                });
#endif
                if (config.DeviceLoopConfig.ReaderInitializationRecord.StrikeNegative == true)
                {
                    peripheralInputStates[strikeStateIndex] = invertInputPolarity(inputStatus);
                }
                else
                {
                    peripheralInputStates[strikeStateIndex] = inputStatus;
                }
                stateChanged = true;
            }
            else if (inputNumber == CardReaderConsts.OnboardDoorInputIds[this.DoorLogicalId][CardReaderConsts.DoorInputEgressIndex]
                && peripheralsValidInputState(inputStatus))
            {
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("{0} egress input point {1} changed status to {2}.", this.ToString(), (inputNumber + 1).ToString(), inputStatus.ToString());
                });
#endif
                if (config.DeviceLoopConfig.ReaderInitializationRecord.EgressNegative == true)
                {
                    peripheralInputStates[egressStateIndex] = invertInputPolarity(inputStatus);
                }
                else
                {
                    peripheralInputStates[egressStateIndex] = inputStatus;
                }
                stateChanged = true;
            }
            else if (inputNumber == CardReaderConsts.OnboardDoorInputIds[this.DoorLogicalId][CardReaderConsts.DoorInputContactIndex]
                && peripheralsValidInputState(inputStatus))
            {
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("{0} contact input point {1} changed status to {2}.", this.ToString(), (inputNumber + 1).ToString(), inputStatus.ToString());
                });
#endif
                if (config.DeviceLoopConfig.ReaderInitializationRecord.ContactNegative == true)
                {
                    peripheralInputStates[doorContactStateIndex] = invertInputPolarity(inputStatus);
                }
                else
                {
                    peripheralInputStates[doorContactStateIndex] = inputStatus;
                }
                stateChanged = true;
            }
            // Use this code if spare input is to be used.
            else if (CardReaderConsts.IsInputHandled(CardReaderConsts.DoorInputSpareIndex) == true
                && inputNumber == CardReaderConsts.OnboardDoorInputIds[this.DoorLogicalId][CardReaderConsts.DoorInputSpareIndex]
                && peripheralsValidInputState(inputStatus))
            {
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("{0} spare input point {1} changed status to {2}.", this.ToString(), (inputNumber + 1).ToString(), inputStatus.ToString());
                });
#endif
                peripheralInputStates[spareStateIndex] = inputStatus;
                stateChanged = true;
            }
            return stateChanged;
        }

        private void dispatchInputStatus()
        {
            try
            {
                // All input configuration will be processed when entry card reader is configured.
                AccessPointConfiguration config = accessPointConfiguration[entryReaderId];
                if (config == null || config.InitializedReaderType == CardReaderType.NoReader)
                    return;

                if (StatusManager.Instance.Device.IsAnyConnectionValid == true)
                {
                    sendDoorInputsToController();
                }
                else if (ConfigurationManager.Instance.Doors[this.DoorLogicalId].DegradedMemoryEnabled == true)
                {
                    // Process egress locally only when controller is offline - activate strike
                    if (peripheralInputStates[egressStateIndex] == Common.InputStatus.Alarm)
                    {
                        if (config.DeviceLoopConfig.ReaderInitializationRecord.ProcessEgressLocally == true)
                        {
#if DEBUG
                            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                            {
                                return string.Format("{0} strike processed locally", this.ToString());
                            });
#endif
                            if (config.DeviceLoopConfig.ReaderInitializationRecord.KeepStrikeDuringEgress == true)
                            {
                                accessPointPeripherals.SetStrike();
                                accessPointPeripherals.SetCurrentGreenLedOn();
                            }
                            else
                            {
                                if (config.DeviceLoopConfig.ReaderInitializationRecord.StrikeDuration > 0)
                                    accessPointPeripherals.SetStrike(config.DeviceLoopConfig.ReaderInitializationRecord.StrikeDuration * 1000);
                                if (config.DeviceLoopConfig.ReaderInitializationRecord.StrikeDuration > 0)
                                    accessPointPeripherals.SetCurrentGreenLed(CardReaderLedType.LedOn, config.DeviceLoopConfig.ReaderInitializationRecord.StrikeDuration * 1000, 0);
                            }
                        }
                    }
                    else
                    {
                        if (config.DeviceLoopConfig.ReaderInitializationRecord.KeepStrikeDuringEgress == true)
                        {
                            accessPointPeripherals.ClearStrike();
                            accessPointPeripherals.SetCurrentGreenLed(CardReaderLedType.LedOff, 1, 0);
                        }
                    }                                        
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("Fatal error while dispatching peripheral input for {0}. {1}", this.ToString(), ex.Message);
                });
            }
        }

        private void sendDoorInputsToController()
        {
            try
            {
                AccessPointConfiguration config = accessPointConfiguration[entryReaderId];
                if (config != null && config.InitializedReaderType != CardReaderType.NoReader)
                {
                    // Inform controller about changes to the inputs.
                    ReaderInputStatusChangeConfig commandConfig = new ReaderInputStatusChangeConfig();
                    commandConfig.ReaderType = config.InitializedReaderType;
                    commandConfig.ContactState = peripheralInputStates[doorContactStateIndex];
                    commandConfig.EgressState = peripheralInputStates[egressStateIndex];
                    commandConfig.StrikeState = peripheralInputStates[strikeStateIndex];
                    commandConfig.SpareState = peripheralInputStates[spareStateIndex];

                    // Use entry reader as source of door input events.
                    if (deviceResponseProcessor != null)
                    {
                        deviceResponseProcessor.SendCardReaderInputChangeAlarm(EntryReader, commandConfig);
#if DEBUG
                        Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                        {
                            return string.Format("{0} input change. Message sent to controller: {1}", this.ToString(), commandConfig.ToString());
                        });
#endif
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("Fatal error while sending peripheral input for {0} to controller. {1}", this.ToString(), ex.Message);
                });
            }
        }

        /// <summary>
        /// Take card details and save for processing when controller responds within X seconds. X seconds from constants.
        /// </summary>
        /// <param name="readerNumber">Reader Id enumerator. (Values between 0..3)</param>
        /// <param name="cardLength">Card data length in bits.</param>
        /// <param name="cardData">Card data as byte array.</param>
        /// <returns>Returns true if the card was successfully registered for processing.</returns>
        private bool saveLastCardForControllerResponse(CardReaderPortType readerNumber, int cardLength, byte[] cardData, LegacyCardRecord legacyCardData)
        {
            // Get access point (reader) configuration and agent
            AccessPointConfiguration config = this[readerNumber];
            if (config == null)
                return false;
            config.LastRequestToController.RegisterCard(cardData, cardLength, controllerCommandMaxResponseTime, legacyCardData);
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                int numBytes = (cardLength / 8) + ((cardLength % 8) != 0 ? 1 : 0);
                return string.Format("Card registered. Waiting for controller response. Card:{0} Length:{1}",
                    BitConverter.ToString(cardData, 0, Math.Min(cardData.Length, numBytes)), cardLength);
            });
#endif
            return true;
        }

        internal void SetDisplaySecurityLevel(int readerId, CardReaderDisplaySecurityLevelConfig config)
        {
            accessPointPeripherals.SetDisplaySecurityLevel(readerId, config);
        }

        /// <summary>
        /// Process peripherals change and card storage.
        /// </summary>
        /// <param name="readerNumber">Reader Id enumerator. (Values between 0..3)</param>
        /// <param name="command">Data structure with command from controller</param>
        internal void PeripheralsChange(CardReaderPortType readerNumber, CardReaderCommandDataConfig command)
        {
            AccessPointConfiguration config;
            if (isReaderInitialized(readerNumber, out config) == false)
                return;

            try
            {
                // Process instructions
                if (command.StrikeIncluded)
                {
                    switch (command.StrikeState)
                    {
                        case CardReaderStrikeType.On:
                            accessPointPeripherals.SetStrike();
                            break;
                        case CardReaderStrikeType.TimeDriven:
                            if (command.StrikeTimeInMinutes == true)
                            {
                                accessPointPeripherals.SetStrike(command.StrikeTime * 1000 * 60);
                            }
                            else
                            {
                                accessPointPeripherals.SetStrike(command.StrikeTime * 1000);
                            }
                            break;
                        default: // Off
                            accessPointPeripherals.ClearStrike();
                            break;
                    }
                }

                if (command.BuzzerIncluded)
                {
                    if (command.BuzzerModifyNormal == true)
                    {
                        switch (command.BuzzerModifyNormalType)
                        {
                            case CardReaderBuzzerType.BuzzerOn:
                                accessPointPeripherals.SetNormalBuzzer(CardReaderBuzzerType.BuzzerOn, 0, 0);
                                break;
                            case CardReaderBuzzerType.BuzzerPulse:
                                accessPointPeripherals.SetNormalBuzzer(CardReaderBuzzerType.BuzzerPulse, 0, 200);
                                break;
                            default: // Off
                                accessPointPeripherals.SetNormalBuzzer(CardReaderBuzzerType.BuzzerOff, 0, 0);
                                break;
                        }
                    }

                    // Should go to normal state with time delay
                    if (command.BuzzerCurrentTime != 0)
                    {
                        switch (command.BuzzerCurrentType)
                        {
                            case CardReaderBuzzerType.BuzzerOn:
                                accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerOn, command.BuzzerCurrentTime * 1000, 0);
                                break;
                            case CardReaderBuzzerType.BuzzerPulse:
                                accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerPulse, command.BuzzerCurrentTime * 1000, 200);
                                break;
                            default: // Off
                                accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerOff, 0, 0);
                                break;
                        }
                    }
                }

                if (command.DeniedLedIncluded)
                {
                    if (command.DeniedLedModifyNormal == true)
                    {
                        switch (command.DeniedLedModifyNormalType)
                        {
                            case CardReaderLedType.LedOn:
                                accessPointPeripherals.SetNormalRedLed(CardReaderLedType.LedOn, 0, 0);
                                break;
                            case CardReaderLedType.LedFlashing:
                                accessPointPeripherals.SetNormalRedLed(CardReaderLedType.LedFlashing, 0, 500);
                                break;
                            default: // Off
                                accessPointPeripherals.SetNormalRedLed(CardReaderLedType.LedOff, 0, 0);
                                break;
                        }
                    }

                    // Should go to normal state with time delay
                    if (command.DeniedLedCurrentTime != 0)
                    {
                        switch (command.DeniedLedCurrentType)
                        {
                            case CardReaderLedType.LedOn:
                                accessPointPeripherals.SetCurrentRedLed(CardReaderLedType.LedOn, command.DeniedLedCurrentTime * 1000, 0);
                                break;
                            case CardReaderLedType.LedFlashing:
                                accessPointPeripherals.SetCurrentRedLed(CardReaderLedType.LedFlashing, command.DeniedLedCurrentTime * 1000, 500);
                                break;
                            default: // Off
                                accessPointPeripherals.SetCurrentRedLed(CardReaderLedType.LedOff, 0, 0);
                                break;
                        }
                    }
                }

                if (command.AcceptLedIncluded)
                {
                    if (command.AcceptLedModifyNormal == true)
                    {
                        switch (command.AcceptLedModifyNormalType)
                        {
                            case CardReaderLedType.LedOn:
                                accessPointPeripherals.SetNormalGreenLed(CardReaderLedType.LedOn, 0, 0);
                                break;
                            case CardReaderLedType.LedFlashing:
                                accessPointPeripherals.SetNormalGreenLed(CardReaderLedType.LedFlashing, 0, 500);
                                break;
                            default: // Off
                                accessPointPeripherals.SetNormalGreenLed(CardReaderLedType.LedOff, 0, 0);
                                break;
                        }
                    }

                    // Should go to normal state with time delay
                    if (command.AcceptLedCurrentTime != 0)
                    {
                        switch (command.AcceptLedCurrentType)
                        {
                            case CardReaderLedType.LedOn:
                                accessPointPeripherals.SetCurrentGreenLed(CardReaderLedType.LedOn, command.AcceptLedCurrentTime * 1000, 0);
                                break;
                            case CardReaderLedType.LedFlashing:
                                accessPointPeripherals.SetCurrentGreenLed(CardReaderLedType.LedFlashing, command.AcceptLedCurrentTime * 1000, 500);
                                break;
                            default: // Off
                                accessPointPeripherals.SetCurrentGreenLed(CardReaderLedType.LedOff, 0, 0);
                                break;
                        }
                    }
                }

                if (command.OutputIncluded)
                {
                    switch (command.OutputState)
                    {
                        case CardReaderOutputType.On:
                            accessPointPeripherals.SetSpareOutput();
                            break;
                        case CardReaderOutputType.TimeDriven:
                            if (command.OutputTimeInMinutes == true)
                            {
                                accessPointPeripherals.SetSpareOutput(command.OutputTime * 1000 * 60);
                            }
                            else
                            {
                                accessPointPeripherals.SetSpareOutput(command.OutputTime * 1000);
                            }
                            break;
                        default: // Off
                            accessPointPeripherals.ClearSpareOutput();
                            break;
                    }
                }

                // Save last card scan to the degraded memory, if requested.                
                if (command.StoreCardInDegradedMemory)
                {
                    if (config.LastRequestToController.CardDataExists)
                    {
                        if (ConfigurationManager.Instance.Doors[DoorLogicalId].DegradedMemoryEnabled == true &&
                            (config.LastRequestToController.CardLength <= 64 || ConfigurationManager.Instance.ControllerMessaging.Has(MessagingFlags.EnableSupportForLargeCardNumbers)))
                        {
                            // Last card data exists. The controller appear to be online. So, save card into the degraded mode.
                            degradedMemory.AddCard(config.LastRequestToController.CardData, config.LastRequestToController.CardLength, config.LastRequestToController.LegacyCardData);
#if DEBUG
                            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                            {
                                int cardLength = config.LastRequestToController.CardLength;
                                int numBytes = (cardLength / 8) + ((cardLength % 8) != 0 ? 1 : 0);
                                byte[] cardData = config.LastRequestToController.CardData;
                                return string.Format("Controller peripherals change request. Request to store card in degraded memory. Card:{0} Length:{1}",
                                    BitConverter.ToString(cardData, 0, Math.Min(cardData.Length, numBytes)),
                                    cardLength);
                            });
#endif
                        }
                    }
#if DEBUG
                    else
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                        {
                            return string.Format("Controller peripherals change request. Request to store card in degraded memory, but unable to find card record.");
                        });
                    }
                }
                else
                {
                    if (config.LastRequestToController.CardDataExists)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                        {
                            int cardLength = config.LastRequestToController.CardLength;
                            int numBytes = (cardLength / 8) + ((cardLength % 8) != 0 ? 1 : 0);
                            byte[] cardData = config.LastRequestToController.CardData;
                            return string.Format("Controller did not request to store card in degraded memory. Card:{0} Length:{1}",
                                BitConverter.ToString(config.LastRequestToController.CardData, 0, Math.Min(cardData.Length, numBytes)),
                                cardLength);
                        });
                    }
#endif
                }

                if (isAnyDoorInputInAlarm())
                    sendDoorInputsToController();
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("Fatal error while processing controller peripheral change for {0}. {1}", this.ToString(), ex.Message);
                });
            }
        }

        /// <summary>
        /// Invert input status polarity for secure and alarm.
        /// </summary>
        /// <param name="status">Input status state requiring inversion.</param>
        /// <returns>Inverted input state.</returns>
        private static Common.InputStatus invertInputPolarity(Common.InputStatus status)
        {
            if (status != Common.InputStatus.Secure)
                return Common.InputStatus.Secure;
            else if (status == Common.InputStatus.Secure)
                return Common.InputStatus.Alarm;
            else
                return status;
        }

        /// <summary>
        /// Validate card reader peripheral states. Not all states can be sent to the controller via reader messages.
        /// </summary>
        /// <param name="state">Input state that requires validation.</param>
        /// <returns>Returns true if the provided input state is valid.</returns>
        private static bool peripheralsValidInputState(Common.InputStatus state)
        {
            switch (state)
            {
                case Common.InputStatus.Alarm:
                case Common.InputStatus.Open:
                case Common.InputStatus.Secure:
                case Common.InputStatus.Short:
                case Common.InputStatus.Trouble:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Returns true if the memory used by degraded events must be trimmed to allocate new most recent event.
        /// </summary>
        private bool hasToTrimDegradedEvents
        {
            get
            {
                int freemem = NativeMemoryStatus.GetFreeMemoryPercentage();
                return freemem > 90 || degradedEvents.Count > maxDegradedEvents;
            }
        }

        private void offlineAccessGranted(CardReaderPortType readerNumber, byte[] code, byte[] issue, byte[] facility)
        {
            offlineAccessGrantedPeripherialChange(readerNumber);
            // Make note of the event
            if (code != null && issue != null && facility != null)
            {
                lock (degradedEventsLock)
                {
                    if (hasToTrimDegradedEvents)
                        degradedEvents.Dequeue();
                    // Add the new record
                    degradedEvents.Enqueue(new AccessPointEventRecordLegacy()
                    {
                        ReaderNumber = readerNumber,
                        AccessDateTime = DateTime.UtcNow,
                        Code = code,
                        Issue = issue,
                        Facility = facility
                    });
                }
            }
            return;
        }

        private void offlineAccessGranted(CardReaderPortType readerNumber, int cardLength, byte[] cardData)
        {
            offlineAccessGrantedPeripherialChange(readerNumber);
            // Make note of the event
            if (cardData != null && cardData.Length > 0 && cardData.Length <= 32 && cardLength > 0 && cardLength <= 255)
            {
                lock (degradedEventsLock)
                {
                    if (hasToTrimDegradedEvents)
                        degradedEvents.Dequeue();
                    // Add the new record
                    degradedEvents.Enqueue(new AccessPointEventRecordRaw()
                    {
                        ReaderNumber = readerNumber,
                        AccessDateTime = DateTime.UtcNow,
                        CardLength = cardLength,
                        CardData = cardData
                    });
                }
            }
            return;
        }

        private void offlineAccessGrantedPeripherialChange(CardReaderPortType readerNumber)
        {
            // Get access point (reader) configuration
            AccessPointConfiguration config;
            if (isReaderInitialized(readerNumber, out config) == false)
                return;
            var readerInitialization = config.DeviceLoopConfig.ReaderInitializationRecord;
            // Process strike
            accessPointPeripherals.SetStrike(readerInitialization.StrikeDuration * 1000);
            // Setup green LED
            if (readerInitialization.AcceptLedFlashEnabled == true)
            {
                accessPointPeripherals.SetCurrentGreenLed(CardReaderLedType.LedFlashing, readerInitialization.AcceptLedFlashTime * 1000, 500);
            }
            else
            {
                accessPointPeripherals.SetCurrentGreenLed(CardReaderLedType.LedOn, readerInitialization.AcceptLedFlashTime * 1000, 0);
            }
            // Setup buzzer
            switch (readerInitialization.AcceptBuzzer)
            {
                case CardReaderBuzzerType.BuzzerOn:
                    accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerOn, readerInitialization.AcceptLedFlashTime * 1000, 0);
                    break;
                case CardReaderBuzzerType.BuzzerPulse:
                    accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerPulse, readerInitialization.AcceptLedFlashTime * 1000, 500);
                    break;
                default:
                    accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerOff, 0, 0);
                    break;
            }
        }

        private void offlineAccessDenied(CardReaderPortType readerNumber)
        {
            // Make note of the event
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return string.Format("{0} invalid card scan in degraded mode.", this.ToString());
            });
            // Get access point (reader) configuration
            AccessPointConfiguration config;
            if (isReaderInitialized(readerNumber, out config) == false)
                return;
            var readerInitialization = config.DeviceLoopConfig.ReaderInitializationRecord;
            // Setup red LED
            if (readerInitialization.DeniedLedFlashEnabled == true)
            {
                accessPointPeripherals.SetCurrentRedLed(CardReaderLedType.LedFlashing, readerInitialization.DeniedLedFlashTime * 1000, 500);
            }
            else
            {
                accessPointPeripherals.SetCurrentRedLed(CardReaderLedType.LedOn, readerInitialization.DeniedLedFlashTime * 1000, 0);
            }
            // Setup buzzer
            switch (readerInitialization.DeniedBuzzer)
            {
                case CardReaderBuzzerType.BuzzerOn:
                    accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerOn, readerInitialization.DeniedLedFlashTime * 1000, 0);
                    break;
                case CardReaderBuzzerType.BuzzerPulse:
                    accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerPulse, readerInitialization.DeniedLedFlashTime * 1000, 500);
                    break;
                default:
                    accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerOff, 0, 0);
                    break;
            }
            return;
        }

        /// <summary>
        /// Process invalid reader scan.
        /// </summary>
        internal bool ProcessInvalidScan()
        {
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return string.Format("{0} invalid card scan.", this.ToString());
            });
#endif
            // Get access point (reader) configuration
            AccessPointConfiguration config;
            if (isReaderInitialized(this.EntryReader, out config) == false)
                return false;

            var readerInitialization = config.DeviceLoopConfig.ReaderInitializationRecord;
            // Setup red LED
            if (readerInitialization.InvalidLedFlashEnabled == true)
                accessPointPeripherals.SetCurrentRedLed(CardReaderLedType.LedFlashing, readerInitialization.InvalidLedFlashTime * 1000, 500);
            else
                accessPointPeripherals.SetCurrentRedLed(CardReaderLedType.LedOn, readerInitialization.InvalidLedFlashTime * 1000, 0);
            // Setup buzzer
            switch (readerInitialization.InvalidBuzzer)
            {
                case CardReaderBuzzerType.BuzzerOn:
                    accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerOn, readerInitialization.InvalidLedFlashTime * 1000, 0);
                    break;
                case CardReaderBuzzerType.BuzzerPulse:
                    accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerPulse, readerInitialization.InvalidLedFlashTime * 1000, 500);
                    break;
                default:
                    accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerOff, 0, 0);
                    break;
            }

            return true;
        }

        #endregion

        #region Degraded Memory Section

        private Queue<object> degradedDropCards = new Queue<object>();
        private Thread degradedDropCardThread = null;
        private object degradedDropCardsLock = new object();

        /// <summary>
        /// Maximum number of events in degraded mode.
        /// </summary>
        private const int maxDegradedEvents = 50 * 1000;

        /// <summary>
        /// Degraded memory process handler
        /// </summary>
        private IDegradedMemoryAgent degradedMemory = null;

        /// <summary>
        /// Accept events occurred during degraded mode.
        /// </summary>
        private Queue<AccessPointEventRecordBase> degradedEvents = new Queue<AccessPointEventRecordBase>();

        /// <summary>
        /// Lock used for multi-threading access to degradedEvents.
        /// </summary>
        private object degradedEventsLock = new object();

        /// <summary>
        /// Thread responsible for sending degraded events to controller when changing state to online.
        /// </summary>
        private Thread degradedEventsSenderThread = null;

        /// <summary>
        /// Get degraded memory name
        /// </summary>
        internal string DegradedMemoryName
        {
            get { return degradedMemory.AgentType; }
        }

        /// <summary>
        /// Get degraded memory max card records
        /// </summary>
        internal int DegradedMemoryMaxCardRecords
        {
            get { return degradedMemory.MaxActiveCards; }
        }

        /// <summary>
        /// Get degraded memory active cards
        /// </summary>
        internal int DegradedMemoryCardCount
        {
            get { return degradedMemory.CardCount; }
        }

        /// <summary>
        /// Add or delete cards to degraded memory.
        /// Only the master card is added via this method. Any card can be deleted. 
        /// </summary>
        /// <param name="readerNumber">Reader Id enumerator. (Values between 0..3)</param>
        /// <param name="degConfig">Degraded memory (re)configuration.</param>
        internal void ProcessDegradedModeLegacyCodeAction(CardReaderPortType readerNumber, ReaderDegradedMemoryConfig degConfig, byte[] rawCardNumber)
        {
            // Check if controller requests the removal of all cards
            if (degConfig.MasterCardStore == false && degConfig.AddCode == false && degConfig.CardRange == true &&
                degConfig.FirstCard.Code.SequenceEqual(new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00 }) &&
                        degConfig.FirstCard.Facility.SequenceEqual(new byte[] { 0x00, 0x00 }) &&
                            degConfig.FirstCard.Issue.SequenceEqual(new byte[] { 0x00 }) &&
                                degConfig.SecondCard.Code.SequenceEqual(new byte[] { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF }) &&
                                    degConfig.SecondCard.Facility.SequenceEqual(new byte[] { 0xFF, 0xFF }) &&
                                        degConfig.SecondCard.Issue.SequenceEqual(new byte[] { 0xFF }))
            {
                processDegradedModeLegacyCodeActionClearCards();
            }
            // Add master card for the reader. Reader must be provided.
            else if (readerNumber != CardReaderPortType.NoReader &&
                degConfig.MasterCardStore == true && degConfig.AddCode == true && degConfig.ModifyFacility == false)
            {
                // Get access point (reader) configuration and agent
                AccessPointConfiguration config = this[readerNumber];
                if (config == null)
                    return;
                config.DeviceLoopConfig.MasterCard.CloneFrom(degConfig.FirstCard);
            }
            // Remove card from degraded memory. Try configuration from both readers, and process only broadcast messages.
            else if (readerNumber == CardReaderPortType.NoReader &&
                degConfig.MasterCardStore == false && degConfig.AddCode == false && degConfig.ModifyFacility == false &&
                degConfig.CardRange == true && degConfig.FirstCard != null && degConfig.SecondCard != null)
            {
                ProcessDeleteCardBroadcast(degConfig, rawCardNumber, 0);
            }
        }

        internal void ProcessDeleteCardBroadcast(ReaderDegradedMemoryConfig legacyCardDetails, byte[] rawCardNumber, int rawCardLength)
        {
            AccessPointConfiguration config = accessPointConfiguration[entryReaderId];
            if (config == null || config.InitializedReaderType == CardReaderType.NoReader)
                config = accessPointConfiguration[exitReaderId];
            if (config == null || config.InitializedReaderType == CardReaderType.NoReader)
                return;

            if (config.InitializedReaderType == CardReaderType.Generic255BitRawData)
            {
                if (rawCardLength == 0 && ConfigurationManager.Instance.ControllerMessaging.Has(MessagingFlags.EnableSupportForLargeCardNumbers))
                    return;     // We are connected to an 8003 and this message is for legacy devices. Ignore this message and process the subsequent more detailed message.

                lock (degradedDropCardsLock)
                {
                    degradedDropCards.Enqueue(new CardNumberAndLength(rawCardNumber, rawCardLength));
                }
            }
            else
            {
                // Copy data across to the smaller structure.
                LegacyCardRecord card = new LegacyCardRecord();
                byte[] code = new byte[legacyCardDetails.FirstCard.Code.Length];
                Array.Copy(legacyCardDetails.FirstCard.Code, code, legacyCardDetails.FirstCard.Code.Length);
                card.Code = code;
                byte[] facility = new byte[legacyCardDetails.FirstCard.Facility.Length];
                Array.Copy(legacyCardDetails.FirstCard.Facility, facility, legacyCardDetails.FirstCard.Facility.Length);
                card.Facility = facility;
                byte[] issue = new byte[legacyCardDetails.FirstCard.Issue.Length];
                Array.Copy(legacyCardDetails.FirstCard.Issue, issue, legacyCardDetails.FirstCard.Issue.Length);
                card.Issue = issue;
                // Enrol card to the processing queue.
                lock (degradedDropCardsLock)
                {
                    degradedDropCards.Enqueue(card);
                }
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("Door {0}: Request to remove card from degraded memory. Facility: {1} Code: {2}.",
                        DoorLogicalId, BitConverter.ToString(card.Facility), BitConverter.ToString(card.Code));
                });
#endif
            }

            // Create the processing thread if needed.
            lock (degradedDropCardsLock)
            {
                if (degradedDropCardThread == null)
                {
                    degradedDropCardThread = new Thread(new ThreadStart(this.degradedDropCardThreadMethod));
                    degradedDropCardThread.Name = string.Format("Door {0} Drop degraded memory cards", DoorLogicalId);
                    degradedDropCardThread.IsBackground = true;
                    degradedDropCardThread.Priority = ThreadPriority.Lowest;
                    degradedDropCardThread.Start();
                }
            }
        }

        /// <summary>
        /// Function responsible for removing all degraded memory cards.
        /// </summary>
        private void processDegradedModeLegacyCodeActionClearCards()
        {
            degradedMemory.DeleteAll();
#if DEBUG
            Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return string.Format("Door {0}: All cards removed from degraded memory.", DoorLogicalId);
            });
#endif
        }

        /// <summary>
        /// Thread method for dropping cards from degraded memory on controller request.
        /// Cards are read from queue.
        /// </summary>
        private void degradedDropCardThreadMethod()
        {
            try
            {
                bool requestCardSaving = false;
                while (degradedDropCards.Count > 0)
                {
                    // Get card for deletion
                    object card = null;
                    lock (degradedDropCardsLock)
                    {
                        card = degradedDropCards.Dequeue();
                    }
                    LegacyCardRecord legacyCardRecord = card as LegacyCardRecord;
                    CardNumberAndLength rawCardDetails = card as CardNumberAndLength;

                    if (rawCardDetails != null)
                    {
                        requestCardSaving = degradedMemory.DeleteCard(rawCardDetails.CardNumber, rawCardDetails.Length);
                    }
                    else if (legacyCardRecord != null)
                    {
                        // Delete card
                        requestCardSaving = degradedMemory.DeleteCard(legacyCardRecord);
                    }
                }
                // Save to dataflash
                if (requestCardSaving == true)
                    degradedMemory.Persist();
            }
            finally
            {
                lock (degradedDropCardsLock)
                {
                    degradedDropCardThread = null;
                }
            }
        }

        /// <summary>
        /// Parse and compare cards for deletion. The door reader initialization record.
        /// </summary>
        /// <param name="deletingCardData">Card to be deleted.</param>
        /// <param name="degradedCardData">Card data from degraded memory.</param>
        /// <param name="degradedCardLength">Number of bits in card data from degraded memory.</param>
        /// <returns>Return true if card if scheduled for deletion.</returns>
        private bool compareDegradedMemoryCard(LegacyCardRecord deletingCardData, byte[] degradedCardData, int degradedCardLength)
        {
            CardReaderDataSendDataConfig command;
            foreach (CardReaderPortType cardReader in CardReaderConsts.DoorReaderTypes[DoorLogicalId])
            {
                AccessPointConfiguration config = this[cardReader];
                if (config == null
                    || config.InitializedReaderType == CardReaderType.NoReader
                    || config.InitializedReaderType == CardReaderType.Generic255BitRawData)
                {
                    continue;
                }
                LegacyCardProcessingResult result = searchForLegacyCardFormat(out command, cardReader, degradedCardLength, degradedCardData);
                if (result == LegacyCardProcessingResult.CardIssueFacilityFound)
                {
                    if (CardReaderUtilityFunctions.LengthInvariantCardCompare(command.Code, deletingCardData.Code) &&
                        CardReaderUtilityFunctions.LengthInvariantCardCompare(command.Issue, deletingCardData.Issue) &&
                        CardReaderUtilityFunctions.LengthInvariantCardCompare(command.Facility, deletingCardData.Facility))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// This thread is sending degraded events to controller when it becomes online.
        /// </summary>
        private void degradedEventsSenderThreadMethod()
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return string.Format("{0} agent has been created.", this.ToString());
            });
            // Allow for the initialization records to be processed.
            // It is not known how many, or how long will it take, so we just give some time to the manager.            
            Thread.Sleep(3000);
            int sentEventsCount = 0;
            try
            {
                while (degradedEvents.Count > 0)
                {
                    if (StatusManager.Instance.Device.IsAnyConnectionValid == false)
                    {
                        // Exit sending events to controller as controller is not there anymore.
                        break;
                    }
                    // Only allow sending events when there is less than 5 in the queue.
                    if (CommunicationsManager.Instance.SendMessageQueueCount < 5)
                    {
                        AccessPointEventRecordBase eventRecord = null;
                        lock (degradedEventsLock)
                        {
                            eventRecord = degradedEvents.Dequeue();
                            sentEventsCount++;
                        }
                        if (eventRecord != null && eventRecord is AccessPointEventRecordLegacy)
                        {
                            AccessPointEventRecordLegacy eventRecordLegacy = eventRecord as AccessPointEventRecordLegacy;
                            CardReaderEventDataConfig alarmConfig = new CardReaderEventDataConfig();
                            alarmConfig.ReaderNumber = eventRecordLegacy.ReaderNumber;
                            alarmConfig.Code = eventRecordLegacy.Code;
                            alarmConfig.Issue = eventRecordLegacy.Issue;
                            alarmConfig.Facility = eventRecordLegacy.Facility;
                            alarmConfig.Hour = (byte)eventRecordLegacy.AccessDateTime.Hour;
                            alarmConfig.Minute = (byte)eventRecordLegacy.AccessDateTime.Minute;
                            alarmConfig.Second = (byte)eventRecordLegacy.AccessDateTime.Second;
                            alarmConfig.DayOfWeek = (byte)eventRecordLegacy.AccessDateTime.DayOfWeek;
                            if (deviceResponseProcessor != null)
                                deviceResponseProcessor.SendCardReaderEventMessageAlarm(alarmConfig);
                        }
                        else if (eventRecord != null && eventRecord is AccessPointEventRecordRaw)
                        {
                            AccessPointEventRecordRaw eventRecordRaw = eventRecord as AccessPointEventRecordRaw;
                            CardReaderEventRawDataConfig alarmConfig = new CardReaderEventRawDataConfig();
                            alarmConfig.ReaderNumber = eventRecordRaw.ReaderNumber;
                            alarmConfig.CardData = eventRecordRaw.CardData;
                            alarmConfig.CardLength = eventRecordRaw.CardLength;
                            alarmConfig.Hour = (byte)eventRecordRaw.AccessDateTime.Hour;
                            alarmConfig.Minute = (byte)eventRecordRaw.AccessDateTime.Minute;
                            alarmConfig.Second = (byte)eventRecordRaw.AccessDateTime.Second;
                            alarmConfig.DayOfWeek = (byte)eventRecordRaw.AccessDateTime.DayOfWeek;
                            alarmConfig.AccessDenied = false; // Only access granted is logged.
                            if (deviceResponseProcessor != null)
                                deviceResponseProcessor.SendCardReaderEventMessageRawAlarm(alarmConfig);
                        }
                    }
                    else
                    {
                        // The sending queue is full stop switching.
                        Thread.Sleep(200);
                    }
                    // Give the controller a bit of break
                    Thread.Sleep(50);
                }
            }
            catch
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("{0} agent. Error while sending degraded events to the controller.", this.ToString());
                });
            }
            finally
            {
                degradedEventsSenderThread = null;
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("{0} agent. Sending degraded events to the controller has finished. ({1})", this.ToString(), sentEventsCount);
                });
            }
        }

        /// <summary>
        /// This is notification from degraded memory agent about successful finish of loading card data.
        /// It will return the configuration objects, and it should be copied across to the door agent.
        /// </summary>
        /// <param name="doorConfiguration">Configuration received from degraded memory.</param>
        private void degradedMemory_CardLoadingFinished(DegradedMemoryDoorConfiguration doorConfiguration)
        {
            // There must be no communication with controller
            if (StatusManager.Instance.Device.IsAnyConnectionValid == true)
                return;
            try
            {
                // Entry
                {
                    DegradedMemoryReaderConfiguration entryReaderConfig = doorConfiguration[CardReaderConsts.DoorEntryReaderIndex];
                    // Send initialization
                    InitializeReader(EntryReader, entryReaderConfig.InitializationConfig, InitializationSource.DegradedMemory);
                    // Read master card for entry reader
                    accessPointConfiguration[entryReaderId].DeviceLoopConfig.MasterCard.CloneFrom(entryReaderConfig.MasterCard);
                    // Send masks
                    CardFormatMasksConfig masks = new CardFormatMasksConfig();
                    for (int i = 0; i < 4; i++)
                        masks.Masks[i] = entryReaderConfig.FormatConfig[i].Mask;
                    FormatsChange(EntryReader, masks);
                    // Send parities 
                    for (int i = 0; i < 4; i++)
                        ParityChange(ExitReader, entryReaderConfig.FormatConfig[i].Parity, i);
                }
                // Exit
                {
                    DegradedMemoryReaderConfiguration exitReaderConfig = doorConfiguration[CardReaderConsts.DoorExitReaderIndex];
                    // Send initialization
                    InitializeReader(ExitReader, exitReaderConfig.InitializationConfig, InitializationSource.DegradedMemory);
                    // Read master card for exit reader
                    accessPointConfiguration[exitReaderId].DeviceLoopConfig.MasterCard.CloneFrom(exitReaderConfig.MasterCard);
                    // Send masks
                    CardFormatMasksConfig masks = new CardFormatMasksConfig();
                    for (int i = 0; i < 4; i++)
                        masks.Masks[i] = exitReaderConfig.FormatConfig[i].Mask;
                    FormatsChange(ExitReader, masks);
                    // Send parities 
                    for (int i = 0; i < 4; i++)
                        ParityChange(ExitReader, exitReaderConfig.FormatConfig[i].Parity, i);
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("Door {0}: Unable to process degraded memory configuration. {1}", DoorLogicalId, ex.Message);
                });
            }
        }
                
        /// <summary>
        /// This function is called just before the degraded memory is written to.
        /// It expects door configuration to be returned.
        /// </summary>
        /// <param name="isAgentDisposing">True is agent is disposing.</param>
        /// <returns>Returns set of reader configuration for the system. 
        /// If null is returned the system if not online, and the previous configuration must persist.</returns>
        private DegradedMemoryDoorConfiguration degradedMemory_RequestDoorConfiguration(bool isAgentDisposing)
        {
            if (isAgentDisposing == false && StatusManager.Instance.Device.IsAnyConnectionValid == false)
                return null;

            DegradedMemoryDoorConfiguration door = new DegradedMemoryDoorConfiguration();
            // Entry reader
            DegradedMemoryReaderConfiguration entryConfig = door.AddReader(CardReaderConsts.DoorEntryReaderIndex); // Reader hardware Id
            entryConfig.InitializationConfig = accessPointConfiguration[CardReaderConsts.DoorEntryReaderIndex].DeviceLoopConfig.ReaderInitializationRecord;
            entryConfig.FormatConfig = accessPointConfiguration[CardReaderConsts.DoorEntryReaderIndex].DeviceLoopConfig.AccessPointCardFormats;
            entryConfig.MasterCard = accessPointConfiguration[CardReaderConsts.DoorEntryReaderIndex].DeviceLoopConfig.MasterCard;
            // Exit reader
            DegradedMemoryReaderConfiguration exitConfig = door.AddReader(CardReaderConsts.DoorExitReaderIndex); // Reader hardware Id
            exitConfig.InitializationConfig = accessPointConfiguration[CardReaderConsts.DoorExitReaderIndex].DeviceLoopConfig.ReaderInitializationRecord;
            exitConfig.FormatConfig = accessPointConfiguration[CardReaderConsts.DoorExitReaderIndex].DeviceLoopConfig.AccessPointCardFormats;
            exitConfig.MasterCard = accessPointConfiguration[CardReaderConsts.DoorExitReaderIndex].DeviceLoopConfig.MasterCard;
            return door;
        }

        #endregion

        #region Configuration processing section

        private object configurationsLock = new object();

        /// <summary>
        /// Entry reader port type
        /// </summary>
        public CardReaderPortType EntryReader
        {
            get { return entryReader; }
        }

        /// <summary>
        /// Exit reader port type
        /// </summary>
        public CardReaderPortType ExitReader
        {
            get { return exitReader; }
        }

        /// <summary>
        /// Access point (reader) configuration and logic. 0 - entry, 1 - exit.
        /// </summary>
        private AccessPointConfiguration[] accessPointConfiguration = new AccessPointConfiguration[2];

        /// <summary>
        /// Return access point in the door for the specified reader.
        /// </summary>
        /// <param name="reader">Valid reader port type for the door.</param>
        /// <returns>Returns the reader access point instance or null if invalid reader port type was specified.</returns>
        internal AccessPointConfiguration this[CardReaderPortType reader]
        {
            get
            {
                if (entryReader == reader)
                    return accessPointConfiguration[entryReaderId];
                else if (exitReader == reader)
                    return accessPointConfiguration[exitReaderId];
                else
                    return null;
            }
        }

        /// <summary>
        /// Returns true if any of the two readers is configured.
        /// </summary>
        public bool IsCardAccessConfigured
        {
            get
            {
                AccessPointConfiguration config;
                // Check first reader
                if (this.isReaderInitialized(EntryReader, out config) == true)
                    return true;
                else if (this.isReaderInitialized(ExitReader, out config) == true)
                    return true;
                else
                    return false;
            }
        }

        /// <summary>
        /// Returns true if the reader is initialized, and outputs the reader configuration
        /// </summary>
        /// <returns></returns>
        private bool isReaderInitialized(CardReaderPortType readerNumber, out AccessPointConfiguration config)
        {
            config = this[readerNumber];
            if (config == null
                || config.InitializedReaderType == CardReaderType.NoReader)
            {
                config = null;
                return false;
            }
            return true;
        }

        /// <summary>
        /// Initialize reader from configuration. Pass the source of the configuration.
        /// </summary>
        /// <param name="readerNumber">Reader Id enumerator. (Values between 0..3)</param>
        /// <param name="config">Reader initialization configuration.</param>
        /// <param name="source">Source of the configuration.</param>
        internal void InitializeReader(CardReaderPortType readerNumber, ReaderInitializationConfig config, InitializationSource source)
        {
            try
            {
                DoorConfiguredType configuredDoorFlags = DoorConfiguredType.DoorNotConfigured;
                bool configurationChangedForEntryReader = false;
                bool configurationChangedForExitReader = false;
                if (config != null)
                {
                    lock (configurationsLock)
                    {
                        if (readerNumber == EntryReader)
                        {
                            if (accessPointConfiguration[entryReaderId].DeviceLoopConfig.ReaderInitializationRecord != null
                                && accessPointConfiguration[entryReaderId].DeviceLoopConfig.ReaderInitializationRecord.Equals(config))
                            {
                                configurationChangedForEntryReader = false;
                            }
                            else
                            {
                                accessPointConfiguration[entryReaderId].DeviceLoopConfig.ReaderInitializationRecord = config;
                                configurationChangedForEntryReader = true;
                            }                            
                        }
                        else if (readerNumber == ExitReader)
                        {
                            if (accessPointConfiguration[exitReaderId].DeviceLoopConfig.ReaderInitializationRecord != null
                                && accessPointConfiguration[exitReaderId].DeviceLoopConfig.ReaderInitializationRecord.Equals(config))
                            {
                                configurationChangedForExitReader = false;
                            }
                            else
                            {
                                accessPointConfiguration[exitReaderId].DeviceLoopConfig.ReaderInitializationRecord = config;
                                configurationChangedForExitReader = true;
                            }                            
                        }
                        else
                        {
                            // The reader is not handled by this door
                            return;
                        }
                        // Mark the type of entry reader
                        if (accessPointConfiguration[entryReaderId].DeviceLoopConfig.ReaderInitializationRecord.ReaderType != CardReaderType.NoReader)
                            configuredDoorFlags = configuredDoorFlags.SetFlags(DoorConfiguredType.EntryReaderConfigured);
                        // Mark the type of exit reader
                        if (accessPointConfiguration[exitReaderId].DeviceLoopConfig.ReaderInitializationRecord.ReaderType != CardReaderType.NoReader)
                            configuredDoorFlags = configuredDoorFlags.SetFlags(DoorConfiguredType.ExitReaderConfigured);
                    }
                }
                // Trigger following event only when configuration has changed.
                if (configurationChangedForEntryReader || configurationChangedForExitReader)
                {
                    try
                    {
                        // Adjust strike relay
                        accessPointPeripherals.ClearStrike();
                        accessPointPeripherals.ClearSpareOutput();
                    }
                    catch
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                        {
                            return "Internal configuration update error.";
                        });
                    }

                    using (ConfigurationManager.Instance.CreateConfigurationChanger())
                    {
                        // Door.SupervisedEgress
                        InitializeSupervisedInputForEgressDoor(readerNumber, config, source);
                        // The following update to Door.EntryReaderType is required to fire configuration changes
                        ConfigurationManager.Instance.Doors[this.DoorLogicalId].EntryReaderType = accessPointConfiguration[entryReaderId].InitializedReaderType;
                        // The following update to Door.ExitReaderType is required to fire configuration changes
                        ConfigurationManager.Instance.Doors[this.DoorLogicalId].ExitReaderType = accessPointConfiguration[exitReaderId].InitializedReaderType;
                    }

                    // Update reader types
                    int readerLogicalId;
                    readerLogicalId = StatusManager.Instance.Doors[this.DoorLogicalId].EntryReaderLogicalId;
                    StatusManager.Instance.Readers[readerLogicalId].SetReaderType(accessPointConfiguration[entryReaderId].InitializedReaderType);
                    readerLogicalId = StatusManager.Instance.Doors[this.DoorLogicalId].ExitReaderLogicalId;
                    StatusManager.Instance.Readers[readerLogicalId].SetReaderType(accessPointConfiguration[exitReaderId].InitializedReaderType);
                    // If controller sent new configuration save it to degraded memory
                    if (source == InitializationSource.Controller)
                        degradedMemory.Persist();
                }
                else if (source == InitializationSource.Controller)
                {
                    InitializeSupervisedInputForEgressDoor(readerNumber, config, source);
                }

                using (ConfigurationManager.Instance.CreateConfigurationChanger())
                {
                    ConfigurationManager.Instance.Doors[this.DoorLogicalId].IsConfigured = configuredDoorFlags;
                    // Just make sure when the door is not configured the unsupervised flag is off
                    if (configuredDoorFlags == DoorConfiguredType.DoorNotConfigured)
                        ConfigurationManager.Instance.Doors[this.DoorLogicalId].IsSupervisedEgress = true;
                }
                // Command received from controller
                // When received initialization record from controller check if there any degraded events to send.
                if (source == InitializationSource.Controller)
                {
                    lock (degradedEventsLock)
                    {
                        if (degradedEvents.Count > 0 && degradedEventsSenderThread == null)
                        {
                            degradedEventsSenderThread = new Thread(new ThreadStart(degradedEventsSenderThreadMethod));
                            degradedEventsSenderThread.Start();
                        }
                    }
                }
                if (IsCardAccessConfigured)
                {
                    refreshDoorInputsFromStatus();
                }
                else
                {
                    accessPointPeripherals.ClearStrike();
                    accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerOff, 1, 0);
                    accessPointPeripherals.SetNormalBuzzer(CardReaderBuzzerType.BuzzerOff, 1, 0);
                    accessPointPeripherals.SetCurrentGreenLed(CardReaderLedType.LedOff, 1, 0);
                    accessPointPeripherals.SetNormalGreenLed(CardReaderLedType.LedOff, 1, 0);
                    accessPointPeripherals.SetCurrentRedLed(CardReaderLedType.LedOff, 1, 0);
                    accessPointPeripherals.SetNormalRedLed(CardReaderLedType.LedOff, 1, 0);
                }
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("Error while initialization of readers for door {0}. {1}",
                        this.DoorLogicalId, ex.Message);
                });
            }
        }

        /// <summary>
        /// Update card reader parities assigned to this door.
        /// </summary>
        /// <param name="readerNumber">Reader Id enumerator. (Values between 0..3)</param>
        /// <param name="parity">Data structure with parities</param>
        /// <param name="formatNumber">Format index. Can be between 0 and 3.</param>
        internal void ParityChange(CardReaderPortType readerNumber, CardFormatParityConfig parity, int formatNumber)
        {
            // Get access point (reader) configuration. Do not look at the reader type.
            AccessPointConfiguration config = this[readerNumber];
            if (config == null)
                return;

            if (formatNumber >= 0 && formatNumber <= 3)
            {
                config.DeviceLoopConfig.AccessPointCardFormats[formatNumber].Parity = parity;
            }
        }

        /// <summary>
        /// Update card reader formats assigned to this door.
        /// </summary>
        /// <param name="readerNumber">Reader Id enumerator. (Values between 0..3)</param>
        /// <param name="mask">Data structure with masks</param>
        internal void FormatsChange(CardReaderPortType readerNumber, CardFormatMasksConfig masks)
        {
            // Get access point (reader) configuration. Do not look at the reader type.
            AccessPointConfiguration config = this[readerNumber];
            if (config == null)
                return;

            for (int i = 0; i < 4; i++)
            {
                config.DeviceLoopConfig.AccessPointCardFormats[i].Mask = masks[i];
            }
        }

        #endregion

        #region Reader Data processing section

        /// <summary>
        /// This method processes Wiegand 26 card data.
        /// </summary>
        /// <param name="command">Output with card code, facility and issue. Used for further processing.</param>
        /// <param name="readerNumber">Reader Id enumerator from which the data was forwarded. (Values between 0..3)</param>
        /// <param name="cardLength">Card data length in bits.</param>
        /// <param name="cardData">Card data as byte array.</param>
        /// <returns>Returns result from the processing.</returns>
        private LegacyCardProcessingResult processWiegand26(
            out CardReaderDataSendDataConfig command,
            CardReaderPortType readerNumber,
            int cardLength,
            byte[] cardData)
        {
            command = null;
            if (cardLength == 26)
            {
                // Get access point (reader) configuration and agent
                AccessPointConfiguration config = this[readerNumber];
                if (config == null)
                {
                    return LegacyCardProcessingResult.NotFound;
                }
                // Configure Wiegand 26 mask
                CardFormatMaskConfig formatMask = new CardFormatMaskConfig();
                formatMask.Facility.UnitType = CardConfigFieldType.InBits;
                formatMask.Facility.ZeroBasedOffset = 1;
                formatMask.Facility.Length = 8;
                formatMask.Code.UnitType = CardConfigFieldType.InBits;
                formatMask.Code.ZeroBasedOffset = 9;
                formatMask.Code.Length = 16;
                // Copy designators from initialization record.
                formatMask.Designators.Facility = config.DeviceLoopConfig.ReaderInitializationRecord.Designators.Facility;
                formatMask.Designators.Issue = config.DeviceLoopConfig.ReaderInitializationRecord.Designators.Issue;
                // Configure Wiegand 26 parity mask
                CardFormatParityConfig formatParity = new CardFormatParityConfig();
                formatParity.Invert = false;
                formatParity.Reverse = false;
                // Even configuration
                formatParity.Mask[0].Enabled = true;
                formatParity.Mask[0].Mask[0] = 0xFF;
                formatParity.Mask[0].Mask[1] = 0xF8;
                formatParity.Mask[0].OddParity = false;
                // Odd configuration
                formatParity.Mask[1].Enabled = true;
                formatParity.Mask[1].Mask[0] = 0x00;
                formatParity.Mask[1].Mask[1] = 0x07;
                formatParity.Mask[1].Mask[2] = 0xFF;
                formatParity.Mask[1].Mask[3] = 0xC0;
                formatParity.Mask[1].OddParity = true;
                // Process format request
                return processLegacyCardRequest(out command, readerNumber, cardLength, cardData, formatMask, formatParity, 0);
            }
            else
            {
                return LegacyCardProcessingResult.NotFound;
            }
        }

        /// <summary>
        /// Parse card data with specified format, check if it will return positive result.
        /// </summary>
        /// <param name="command">Output with card code, facility and issue. (Legacy processing result) Used for further processing.</param>
        /// <param name="readerNumber">Reader Id enumerator from which the data was forwarded. (Values between 0..3)</param>
        /// <param name="cardLength">Card data length in bits.</param>
        /// <param name="cardData">Card data as byte array.</param>
        /// <param name="mask">Mask configuration.</param>
        /// <param name="parity">Parity configuration.</param>
        /// <param name="detectedFormat">Format for controller to verify. Format 0 is passed in reader initialization instruction. Formats 1 to 4 are passed in mask configuration.</param>
        /// <returns>Returns result from the processing.</returns>
        private LegacyCardProcessingResult processLegacyCardRequest(
            out CardReaderDataSendDataConfig command,
            CardReaderPortType readerNumber,
            int cardLength,
            byte[] cardData,
            CardFormatMaskConfig mask,
            CardFormatParityConfig parity,
            int detectedFormat)
        {
            command = null;
            // Get access point (reader) configuration and agent            
            AccessPointConfiguration config;
            if (isReaderInitialized(readerNumber, out config) == false)
                return LegacyCardProcessingResult.NotFound;
            // Support up to 64 bit, but only when code designator is not 64 bit.
            // The 64 bit designator for code is flag from controller in Unison mode.
            if (mask.Designators.Code == 64 && cardLength > 63)
            {
                return LegacyCardProcessingResult.NotFound;
            }
            else if (cardLength > 64)
            {
                return LegacyCardProcessingResult.NotFound;
            }
            // Make a copy of card data
            byte[] cardDataForProcessing = new byte[cardData.Length];
            for (int iCopy = 0; iCopy < cardData.Length; iCopy++)
            {
                cardDataForProcessing[iCopy] = cardData[iCopy];
            }
            if (parity != null)
            {
                // Manipulate card data according to format instruction
                if (parity.Invert == true)
                {
                    CardReaderUtilityFunctions.InvertData(cardLength, cardDataForProcessing);
                }
                if (parity.Reverse == true)
                {
                    CardReaderUtilityFunctions.ReverseData(cardLength, cardDataForProcessing);
                }
                // Check if all 3 parity sets are correct
                for (int iParity = 0; iParity < 3; iParity++)
                {
                    if (parity.Mask[iParity].Enabled == true)
                    {
                        bool evenParityResult = CardReaderUtilityFunctions.CalcParity(cardLength, cardDataForProcessing, parity.Mask[iParity].Mask);
                        if (parity.Mask[iParity].OddParity == false && evenParityResult == false)
                        {
                            return LegacyCardProcessingResult.NotFound;
                        }
                        else if (parity.Mask[iParity].OddParity == true && evenParityResult == true)
                        {
                            return LegacyCardProcessingResult.NotFound;
                        }
                    }
                }
            }
            // Prepare configuration for command           
            CardReaderDataSendDataConfig commandTemp = new CardReaderDataSendDataConfig();
            commandTemp.ReaderType = config.InitializedReaderType;
            commandTemp.Format = detectedFormat;
            commandTemp.Designators = mask.Designators;
            // Controller in "Unison" mode with code designator of 64 bits must have facility, issue and code in code part.
            // At point of writing this, there is no way to recognize that controller is in "Unison" mode.
            // If code is 64 the facility and issue are automatically both zero.
            if (commandTemp.Designators.Code == 64)
            {
                // Load facility in Unison mode
                commandTemp.Facility = new byte[0];
                // Load issue in Unison mode
                commandTemp.Issue = new byte[0];
                // Load code in Unison mode if required. The code contains the code + issue + facility.
                if (mask.Code.Length > 0 && mask.Code.Length + mask.Code.ZeroBasedOffset <= cardLength)
                {
                    byte[] internalFacility = new byte[0];
                    byte[] internalIssue = new byte[0];
                    byte[] internalCode = new byte[0];
                    if (mask.Facility.Length > 0)
                    {
                        if (mask.Facility.Length + mask.Facility.ZeroBasedOffset <= cardLength)
                        {
                            internalFacility = CardReaderUtilityFunctions.ExtractData(cardDataForProcessing, mask.Facility.Length, mask.Facility.ZeroBasedOffset);
                        }
                        else
                        {
                            return LegacyCardProcessingResult.NotFound;
                        }
                    }
                    if (mask.Issue.Length > 0)
                    {
                        if (mask.Issue.Length + mask.Issue.ZeroBasedOffset <= cardLength)
                        {
                            internalIssue = CardReaderUtilityFunctions.ExtractData(cardDataForProcessing, mask.Issue.Length, mask.Issue.ZeroBasedOffset);
                        }
                        else
                        {
                            return LegacyCardProcessingResult.NotFound;
                        }
                    }
                    if (mask.Code.Length > 0 && mask.Code.Length + mask.Code.ZeroBasedOffset <= cardLength)
                    {
                        internalCode = CardReaderUtilityFunctions.ExtractData(cardDataForProcessing, mask.Code.Length, mask.Code.ZeroBasedOffset);
                    }
                    else
                    {
                        return LegacyCardProcessingResult.NotFound;
                    }
                    // The legacy controllers used to prefix the code with one zero byte. 8603 does not need to do it anymore.
                    byte[] internalCommandCode = new byte[internalFacility.Length + internalIssue.Length + internalCode.Length];
                    int interalCodeIndex = internalCommandCode.Length - 1;
                    // Copy code
                    for (int iCode = internalCode.Length - 1; iCode >= 0; iCode--)
                    {
                        internalCommandCode[interalCodeIndex--] = internalCode[iCode];
                    }
                    // Copy issue
                    for (int iIssue = internalIssue.Length - 1; iIssue >= 0; iIssue--)
                    {
                        internalCommandCode[interalCodeIndex--] = internalIssue[iIssue];
                    }
                    // Copy facility
                    for (int iFacility = internalFacility.Length - 1; iFacility >= 0; iFacility--)
                    {
                        internalCommandCode[interalCodeIndex--] = internalFacility[iFacility];
                    }
                    commandTemp.Code = internalCommandCode;
                    command = commandTemp;
                    return LegacyCardProcessingResult.RawFormat;
                }
                else
                {
                    return LegacyCardProcessingResult.NotFound;
                }
            }
            else
            {
                // Load data bits for facility in legacy mode
                if (mask.Facility.Length > 0)
                {
                    if (mask.Facility.Length + mask.Facility.ZeroBasedOffset <= cardLength)
                    {
                        commandTemp.Facility = CardReaderUtilityFunctions.ExtractData(cardDataForProcessing, mask.Facility.Length, mask.Facility.ZeroBasedOffset);
                    }
                    else
                    {
                        return LegacyCardProcessingResult.NotFound;
                    }
                }
                // Load data bits for issue in legacy mode
                if (mask.Issue.Length > 0)
                {
                    if (mask.Issue.Length + mask.Issue.ZeroBasedOffset <= cardLength)
                    {
                        commandTemp.Issue = CardReaderUtilityFunctions.ExtractData(cardDataForProcessing, mask.Issue.Length, mask.Issue.ZeroBasedOffset);
                    }
                    else
                    {
                        return LegacyCardProcessingResult.NotFound;
                    }
                }
                // Load data bits for code in legacy mode
                if (mask.Code.Length > 0 && mask.Code.Length + mask.Code.ZeroBasedOffset <= cardLength)
                {
                    commandTemp.Code = CardReaderUtilityFunctions.ExtractData(cardDataForProcessing, mask.Code.Length, mask.Code.ZeroBasedOffset);
                }
                else
                {
                    return LegacyCardProcessingResult.NotFound;
                }
                command = commandTemp;
                return LegacyCardProcessingResult.CardIssueFacilityFound;
            }
        }

         /// <summary>
        /// This method processes card data received in Wiegand format from readers.
        /// </summary>
        /// <param name="readerNumber">Reader Id enumerator. (Values between 0..3)</param>
        /// <param name="cardLength">Scanned card length</param>
        /// <param name="cardData">Scanned raw byte array</param>
        public void ProcessScan(CardReaderPortType readerNumber, int cardLength, byte[] cardData, bool isUnauthorizedCard)
        {
            // Get access point (reader) configuration and agent
            AccessPointConfiguration config = this[readerNumber];
            if (config == null)
                return;

            CardReaderType readerType = config.InitializedReaderType;

            // Are we in degraded mode?
            if (StatusManager.Instance.Device.IsAnyConnectionValid)
            {
                if (readerType != CardReaderType.NoReader)
                {
                    bool cardRequestSent = false;
                    LegacyCardRecord legacyCardData = null;
                    if (readerType != CardReaderType.Generic255BitRawData)
                    {
                        // Format to controller default format.
                        // Default format is: 2 bytes for facility, 1 byte for issue, and 5 bytes for code.
                        // Other formats are specified by designators in configuration.
                        if (processLegacyControllerRequest(readerNumber, cardLength, cardData, out legacyCardData, isUnauthorizedCard) == true)
                        {
                            cardRequestSent = true;
                        }
                    }
                    else
                    {
                        // Send raw card data
                        // Format to follow.
                        if (processRawCardRequest(readerNumber, cardLength, cardData, isUnauthorizedCard) == true)
                        {
                            cardRequestSent = true;
                        }
                    }

                    // Do not remember individual key presses on a reader
                    if (cardLength > 8)
                    {
                        // Save card for upcoming controller response
                        if (cardRequestSent == true)
                        {
                            saveLastCardForControllerResponse(readerNumber, cardLength, cardData, legacyCardData);
                        }
                        else
                        {
                            this.ProcessInvalidScan();
                            return;
                        }
                    }
                }
            }
            else if (ConfigurationManager.Instance.Doors[this.DoorLogicalId].DegradedMemoryEnabled == true)
            {
                if (cardLength <= 8 || isUnauthorizedCard)
                    return;

                // Attempt to process the card.
                if (readerType == CardReaderType.Generic255BitRawData)
                {
                    if (degradedMemory.CardExists(cardData, cardLength) == true)
                    {
                        // Raw format
                        offlineAccessGranted(readerNumber, cardLength, cardData);
                        return;
                    }
                    else
                    {
                        offlineAccessDenied(readerNumber);
                        return;
                    }
                }
                else
                {
                    CardReaderDataSendDataConfig command;
                    LegacyCardProcessingResult cardFormatSearchResult;
                    cardFormatSearchResult = searchForLegacyCardFormat(out command, readerNumber, cardLength, cardData);
                    if (cardFormatSearchResult == LegacyCardProcessingResult.CardIssueFacilityFound && command != null)
                    {
                        // Search degraded memory card data
                        // Search within master cards for the reader, but only if it is not raw format.
                        if (CardReaderUtilityFunctions.LengthInvariantCardCompare(command.Code, config.DeviceLoopConfig.MasterCard.Code) &&
                            CardReaderUtilityFunctions.LengthInvariantCardCompare(command.Issue, config.DeviceLoopConfig.MasterCard.Issue) &&
                            CardReaderUtilityFunctions.LengthInvariantCardCompare(command.Facility, config.DeviceLoopConfig.MasterCard.Facility))
                        {
                            offlineAccessGranted(readerNumber, command.Code, command.Issue, command.Facility);
                            return;
                        }
                        // It is not a master card, attempt to scan degraded memory card details                        
                        if (cardFormatSearchResult == LegacyCardProcessingResult.CardIssueFacilityFound && command != null &&
                                degradedMemory.CardExists(cardData, cardLength) == true)
                        {
                            // Format with designators
                            offlineAccessGranted(readerNumber, command.Code, command.Issue, command.Facility);
                            return;
                        }
                        else
                        {
                            offlineAccessDenied(readerNumber);
                            return;
                        }
                    }
                    else
                    {
                        offlineAccessDenied(readerNumber);
                    }
                }
            }
        }

        /// <summary>
        /// Send legacy card format to controller.
        /// </summary>
        /// <param name="readerNumber">Reader Id enumerator. (Values between 0..3)</param>
        /// <param name="cardLength">Card data length in bits.</param>
        /// <param name="cardData">Card data as byte array.</param>
        /// <returns>Returns true if the processing found valid data for the reader configuration.</returns>
        private bool processLegacyControllerRequest(CardReaderPortType readerNumber, int cardLength, byte[] cardData, out LegacyCardRecord legacyCardData, bool isUnauthorizedCard)
        {
            CardReaderDataSendDataConfig command;
            LegacyCardProcessingResult result = searchForLegacyCardFormat(out command, readerNumber, cardLength, cardData);
            if (result != LegacyCardProcessingResult.NotFound && command != null)
            {
                legacyCardData = LegacyCardRecord.Clone(command.Facility, command.Issue, command.Code);
                if (deviceResponseProcessor != null)
                {
                    if (isUnauthorizedCard == true)
                        deviceResponseProcessor.SendCardReaderUnauthorizedCardDataSendAlarm(readerNumber, command);
                    else
                        deviceResponseProcessor.SendCardReaderCardDataSendAlarm(readerNumber, command);
                }
                return true;
            }
            else if (result == LegacyCardProcessingResult.KeypadFound && command == null)
            {
#if DEBUG
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("{0} keypad activity detected.", this.ToString());
                });
#endif
                legacyCardData = null;
                return true;
            }
            else
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return string.Format("{0} could not find valid card format.", this.ToString());
                });
                legacyCardData = null;
                return false;
            }
        }

        /// <summary>
        /// Send raw format card to controller.
        /// </summary>
        /// <param name="readerNumber">Reader Id enumerator from which the raw data was forwarded. (Values between 0..3)</param>
        /// <param name="cardLength">Card data length in bits.</param>
        /// <param name="cardData">Card data as byte array.</param>
        /// <returns>Returns true if the data was processed and sent to controller.</returns>
        private bool processRawCardRequest(CardReaderPortType readerNumber, int cardLength, byte[] cardData, bool isUnauthorizedCard)
        {
            // Get access point (reader) configuration and agent
            AccessPointConfiguration config = this[readerNumber];
            if (config == null || config.DeviceLoopConfig == null)
                return false;
            // Only raw Wiegand reader type is allowed
            if (config.InitializedReaderType != CardReaderType.Generic255BitRawData)
                return false;

            if (cardLength == 4 || cardLength == 8)
            {
                processReaderKey(readerNumber, (byte)(cardData[0] >> 4));
                return true;
            }

            // Make a copy of card data
            byte[] cardDataForProcessing = new byte[cardData.Length];
            for (int iCopy = 0; iCopy < cardData.Length; iCopy++)
            {
                cardDataForProcessing[iCopy] = cardData[iCopy];
            }
            // Prepare command for controller
            CardReaderDataSendDataRawConfig command = new CardReaderDataSendDataRawConfig();
            command.NumberOfBits = cardLength;
            command.ReaderType = config.InitializedReaderType;
            command.Data = cardDataForProcessing;
            // Send to controller
            if (deviceResponseProcessor != null)
            {
                if(isUnauthorizedCard)
                    deviceResponseProcessor.SendCardReaderUnauthorizedCardDataRawSendAlarm(readerNumber, command);
                else
                    deviceResponseProcessor.SendCardReaderCardDataRawSendAlarm(readerNumber, command);
            }
            return true;
        }

        /// <summary>
        /// This function searches for card formatter within initialization and multi-format configuration
        /// </summary>
        /// <param name="command"></param>
        /// <param name="readerNumber">Reader Id enumerator from which the data was forwarded. (Values between 0..3)</param>
        /// <param name="cardLength">Card data length in bits.</param>
        /// <param name="cardData">Card data as byte array.</param>
        /// <returns>Returns result from the processing.</returns>
        private LegacyCardProcessingResult searchForLegacyCardFormat(
            out CardReaderDataSendDataConfig command,
            CardReaderPortType readerNumber,
            int cardLength,
            byte[] cardData)
        {
            command = null;
            // Get access point (reader) configuration and agent
            AccessPointConfiguration config = this[readerNumber];
            if (config == null)
            {
                return LegacyCardProcessingResult.NotFound;
            }
            switch (config.InitializedReaderType)
            {
                case CardReaderType.Wiegand26BitsKeypad:
                    switch (cardLength)
                    {
                        case 4:
                            return processReaderKey(readerNumber, (byte)(cardData[0] >> 4));
                        case 26:
                            return processWiegand26(out command, readerNumber, cardLength, cardData);
                        default:
                            ProcessInvalidScan();
                            return LegacyCardProcessingResult.NotFound;
                    }

                case CardReaderType.WiegandMultiFormat:
                    switch (cardLength)
                    {
                        case 4: return processReaderKey(readerNumber, (byte)(cardData[0] >> 4));
                        case 8: return processReaderKey(readerNumber, (byte)(cardData[0] & 0x0F));
                        default:
                            for (int i = 0; i < config.DeviceLoopConfig.AccessPointCardFormats.Length; i++)
                            {
                                var format = config.DeviceLoopConfig.AccessPointCardFormats[i];
                                if (format != null && format.Mask != null && format.Mask.NumberOfWiegandBits == cardLength)
                                {
                                    var formatSearchResult = processLegacyCardRequest(out command, readerNumber, cardLength, cardData, format.Mask, format.Parity, i+1);
                                    if (formatSearchResult != LegacyCardProcessingResult.NotFound)
                                        return formatSearchResult;
                                }
                            }

                            // Try default Wiegand 26 format
                            return processWiegand26(out command, readerNumber, cardLength, cardData);
                    }
                default: 
                    return processWiegand26(out command, readerNumber, cardLength, cardData);
            }
            command = null;
            return LegacyCardProcessingResult.NotFound;
        }

#endregion

        #region Keypad processing section

        private void sendCardReaderNumberInputAlarm(CardReaderPortType readerNumber, AccessPointConfiguration config)
        {
            KeypadOperation keypadOperation = config.KeypadState;
            byte[] keyData = new byte[keypadOperation.KeyCount];
            Buffer.BlockCopy(keypadOperation.KeyData, 0, keyData, 0, keypadOperation.KeyCount);
#if DEBUG
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return "Keypad keys sent to controller: " + BitConverter.ToString(keyData);
            });
#endif
            if (deviceResponseProcessor != null)
                deviceResponseProcessor.SendCardReaderNumberInputAlarm(readerNumber, config.InitializedReaderType, keyData);
            keypadOperation.Clear();
        }

        private LegacyCardProcessingResult processReaderKey(CardReaderPortType readerNumber, byte key)
        {
            const byte ENTER_KEY = 0x0B;

            // Get access point (reader) configuration and agent
            AccessPointConfiguration config = this[readerNumber];
            if (config == null)
            {
                return LegacyCardProcessingResult.NotFound;
            }

            if (key == 0x0F || key == 0x0E)
            {
                // Just make it valid key but do not process.
                return LegacyCardProcessingResult.KeypadFound;
            }

            ReaderInitializationConfig readerConfig = config.DeviceLoopConfig.ReaderInitializationRecord;
            KeypadOperation keypadOperation = config.KeypadState;
            keypadOperation.SetConfig(readerConfig.KeypadSendKeyWithPin, readerConfig.KeypadNoDigitsToEnter + 1, (readerConfig.KeypadInactivityTimer + 1) * 1000);

            if (key == ENTER_KEY)
            {
                if (keypadOperation.KeyCount > 0)
                {
                    if (keypadOperation.KeyCount == 1 && keypadOperation.KeyData[0] == 0x0A)
                        keypadOperation.Clear();
                    else
                        sendCardReaderNumberInputAlarm(readerNumber, config);
                }
            }
            else if (keypadOperation.AddKey(key) >= keypadOperation.MaxKeys)
            {
                sendCardReaderNumberInputAlarm(readerNumber, config);
            }
            return LegacyCardProcessingResult.KeypadFound;
        }

        #endregion

        #region Door Agent Logging and Information

        public override string ToString()
        {
            return string.Format("Door {0}", this.DoorLogicalId);
        }

        /// <summary>
        /// Logging call made to the door agent from Logger.
        /// </summary>
        /// <param name="textWriter">This instance of TextWriter can be used for providing textual information about the agent state.</param>
        internal void IndividualInfo(TextWriter textWriter)
        {
            textWriter.WriteLine();
            textWriter.WriteLine("{0}:", this.ToString());
            textWriter.WriteLine();
            // Entry door
            textWriter.WriteLine("   Details for entry reader: {0}", this.EntryReader.ToString());
            if (this[EntryReader] != null)
                cardReaderIndividualInfo(this[EntryReader], textWriter);
            else
                textWriter.WriteLine("                       N/A");
            // Exit reader
            textWriter.WriteLine("   Details for exit reader: {0}", this.ExitReader.ToString());
            if (this[ExitReader] != null)
                cardReaderIndividualInfo(this[ExitReader], textWriter);
            else
                textWriter.WriteLine("                       N/A");
            // Degraded memory
            textWriter.WriteLine("   Degraded memory:");
            textWriter.WriteLine("      Type: {0}", DegradedMemoryName);
            textWriter.WriteLine("      Maximum number of cards: {0}", DegradedMemoryMaxCardRecords);
            textWriter.WriteLine("      Number of cards in degraded memory buffer: {0}", DegradedMemoryCardCount);
            textWriter.WriteLine("      Number of offline events in queue: {0}", degradedEvents.Count);
            textWriter.WriteLine();
        }

        private void cardReaderIndividualInfo(AccessPointConfiguration config, TextWriter textWriter)
        {
            const string spacer = "      ";
            try
            {
                if (config.InitializedReaderType == CardReaderType.NoReader)
                {
                    textWriter.WriteLine(spacer + "Interface does not have configuration.");
                }
                else
                {
                    textWriter.WriteLine(spacer + "Reader type: " + config.InitializedReaderType.ToString());
                    if (config.InitializedReaderType == CardReaderType.WiegandMultiFormat)
                    {
                        textWriter.WriteLine(spacer + "Format 1:");
                        textWriter.WriteLine(spacer + spacer + "Wiegand 26 bits");
                        textWriter.WriteLine(spacer + "Format 2: ");
                        this.cardReaderIndividualFormatInfo(config.DeviceLoopConfig.AccessPointCardFormats[0], textWriter);
                        textWriter.WriteLine(spacer + "Format 3: ");
                        this.cardReaderIndividualFormatInfo(config.DeviceLoopConfig.AccessPointCardFormats[1], textWriter);
                        textWriter.WriteLine(spacer + "Format 4: ");
                        this.cardReaderIndividualFormatInfo(config.DeviceLoopConfig.AccessPointCardFormats[2], textWriter);
                        textWriter.WriteLine(spacer + "Format 5: ");
                        this.cardReaderIndividualFormatInfo(config.DeviceLoopConfig.AccessPointCardFormats[3], textWriter);
                    }
                    textWriter.WriteLine(spacer + "Strike time: " + config.DeviceLoopConfig.ReaderInitializationRecord.StrikeDuration);
                    textWriter.WriteLine(spacer + "Store cards in degraded memory: " + (config.DeviceLoopConfig.ReaderInitializationRecord.StoreCodeLocally == true ? "Yes" : "No"));
                    textWriter.WriteLine(spacer + "Process Egress Locally: " + (config.DeviceLoopConfig.ReaderInitializationRecord.ProcessEgressLocally == true ? "Yes" : "No"));
                    textWriter.WriteLine(spacer + "Egress Negative: " + (config.DeviceLoopConfig.ReaderInitializationRecord.EgressNegative == true ? "Yes" : "No"));
                    textWriter.WriteLine(spacer + "Door Supervised Egress: " + (config.DeviceLoopConfig.ReaderInitializationRecord.SupervisedEgressInput == true ? "Yes" : "No"));
                }
                textWriter.WriteLine();
            }
            catch
            {
                textWriter.WriteLine("...");
            }
        }

        private void cardReaderIndividualFormatInfo(AccessPointFormatConfig config, TextWriter textWriter)
        {
            const string spacer = "         ";
            if (config.Mask.NumberOfWiegandBits == 0)
            {
                textWriter.WriteLine(spacer + "Not configured");
            }
            else
            {
                textWriter.Write(spacer + "Wiegand " + config.Mask.NumberOfWiegandBits + " bits");
                if (config.Parity.Invert == true)
                {
                    textWriter.Write(", Inverted");
                }
                if (config.Parity.Reverse == true)
                {
                    textWriter.Write(", Reversed");
                }
                textWriter.WriteLine();
            }
        }

        #endregion

        #region IDisposable Members

        bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                if (disposing)
                {
                    StatusManager.Instance.Inputs.UnmaskedInputChangedStatus -= new EventHandler<InputChangedStatusEventArgs>(inputs_InputChangedStatus);

                    accessPointPeripherals.ClearStrike();
                    accessPointPeripherals.SetCurrentBuzzer(CardReaderBuzzerType.BuzzerOff, 1, 0);
                    accessPointPeripherals.SetNormalBuzzer(CardReaderBuzzerType.BuzzerOff, 1, 0);
                    accessPointPeripherals.SetCurrentGreenLed(CardReaderLedType.LedOff, 1, 0);
                    accessPointPeripherals.SetNormalGreenLed(CardReaderLedType.LedOff, 1, 0);
                    accessPointPeripherals.SetCurrentRedLed(CardReaderLedType.LedOff, 1, 0);
                    accessPointPeripherals.SetNormalRedLed(CardReaderLedType.LedOff, 1, 0);
                    accessPointPeripherals.OnSpareOutputStateChange -= new EventHandler<OutputStateChangeArgs>(accessPointPeripherals_OnSpareOutputStateChange);
                    accessPointPeripherals.OnStrikeStateChange -= new EventHandler<OutputStateChangeArgs>(accessPointPeripherals_OnStrikeStateChange);
                    accessPointPeripherals.OnBuzzerStateChange -= new EventHandler<BuzzerStateChangeArgs>(accessPointPeripherals_OnBuzzerStateChange);
                    accessPointPeripherals.OnRedLedStateChange -= new EventHandler<LedStateChangeArgs>(accessPointPeripherals_OnRedLedStateChange);
                    accessPointPeripherals.OnGreenLedStateChange -= new EventHandler<LedStateChangeArgs>(accessPointPeripherals_OnGreenLedStateChange);
                    accessPointPeripherals.DisplaySecurityLevelStateChange -= new EventHandler<DisplaySecurityLevelChangeEventArgs>(onDisplaySecurityLevelStateChange);

                    degradedEvents.Clear();
                    degradedMemory.Dispose();
                    degradedDropCards.Clear();

                    if (degradedDropCardThread != null)
                    {
                        if (degradedDropCardThread.Join(2000) == false)
                        {
                            try
                            {
                                degradedDropCardThread.Abort();
                            }
                            catch
                            {
                            }
                        }
                    }
                    Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return string.Format("{0} is disposed.", this.ToString());
                    });
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
