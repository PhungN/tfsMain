﻿
namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// Interface for accessing degardeded memory record.
    /// </summary>
    public interface IDegradedMemoryRecord
    {
        /// <summary>
        /// Checksum for the page.
        /// </summary>
        byte[] Checksum
        {
            get;
        }
        
        /// <summary>
        /// Serialization method
        /// </summary>
        /// <returns></returns>
        byte[] Serialize();

        /// <summary>
        /// Deserialization method
        /// </summary>
        /// <param name="pageData"></param>
        /// <returns></returns>
        bool Deserialize(byte[] pageData, Common.PcbType pcbType);

        /// <summary>
        /// Template of initial page
        /// </summary>
        byte[] InitialPageData
        {
            get;
        }

        /// <summary>
        /// Validation function
        /// </summary>
        /// <returns></returns>
        bool Validate();

        /// <summary>
        /// This method is used for clearing page record.
        /// </summary>
        void Clear();
    }
}
