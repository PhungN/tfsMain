﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// Delegate used to announce the end of loading degraded memory.
    /// </summary>
    /// <param name="readerConfiguration">Door configuration includes entry and exit readers.</param>
    public delegate void DegradedMemoryCardLoadingFinishedDelegate(DegradedMemoryDoorConfiguration readerConfiguration);

    /// <summary>
    /// Delegate used to request door configuration. It marks the beginning of degraded memory persistence process.
    /// </summary>
    /// <param name="isAgentDisposing">True if agent is disposing.</param>
    /// <returns>Returns door configuration which includes entry and exit reader.</returns>
    public delegate DegradedMemoryDoorConfiguration DegradedMemoryRequestDoorConfigurationDelegate(bool isAgentDisposing);

    /// <summary>
    /// Delegate used to request comparison of two raw cards. Decide if it should be deleted.
    /// </summary>
    /// <param name="deletingCardData">Card requested to be deleted.</param>
    /// <param name="degradedCardData">Card peeked from the degraded memory.</param>
    /// <param name="degradedCardLength">Number of bits for card peeked from degraded memory.</param>
    /// <returns>Returns true if the card meets criteria and should be deleted from degraded memory.</returns>
    public delegate bool DegradedMemoryLegacyDeleteCardComparer(LegacyCardRecord deletingCardData, byte[] degradedCardData, int degradedCardLength);
        
    /// <summary>
    /// Degraded Memory Agents Common Interface
    /// </summary>
    public interface IDegradedMemoryAgent : IDisposable
    {
        /// <summary>
        /// Set delegate which is called when the loading cards is finished from degraded memory.
        /// It returns door configuration.
        /// </summary>
        void SetCardLoadingFinishedDelegate(DegradedMemoryCardLoadingFinishedDelegate method);

        /// <summary>
        /// Set delegate which is called just before degraded memory persisting process begins.
        /// It expects door configuration to be supplied.
        /// </summary>
        /// <returns>Returns set of reader configuration for the system. 
        /// If null is returned the system if not online, and the previous configuration must persist.</returns>
        void SetRequestDoorConfigurationDelegate(DegradedMemoryRequestDoorConfigurationDelegate function);

        /// <summary>
        /// Set delegate for comparing legacy card with degraded memory records.
        /// </summary>
        void SetLegacyDeleteCardComparerDelegate(DegradedMemoryLegacyDeleteCardComparer comparer);
       
        /// <summary>
        /// Request degraded memory agent to load cards and configuration.
        /// </summary>
        void LoadCardAndConfiguration(bool deleteAllCards);

        /// <summary>
        /// Persist configuration and cards to degraded memory.
        /// </summary>
        void Persist();

        /// <summary>
        /// Returned type for this degraded memory agent.
        /// </summary>
        string AgentType { get; }

        /// <summary>
        /// Number of active cards held by this degraded memory agent.
        /// </summary>
        int CardCount { get; }

        /// <summary>
        /// Number of maximum active cards held by this degraded memory agent.
        /// </summary>
        int MaxActiveCards { get; }

        /// <summary>
        /// Scan all card records and try to find card data and page. 
        /// </summary>
        /// <param name="cardData">Byte array with card data. Always supplied in 32 byte array.</param>
        /// <param name="cardLength">Number of bits used in byte array provided by cardData parameter.</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator</returns>
        bool CardExists(byte[] cardData, int cardLength);

        /// <summary>
        /// This class accepts card data with specified length to be added to the list of cards in degraded mode.
        /// The cardData array is expected to be 32 byte in length. Used bits are defined by cardLength parameter.
        /// </summary>
        /// <param name="cardData">Byte array with card data bits. 32 bytes.</param>
        /// <param name="cardLength">Number of bits used in byte array provided by cardData parameter.</param>
        /// <param name="legacyCardData">Facility, Issue and Code if present.</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator</returns>
        bool AddCard(byte[] cardData, int cardLength, LegacyCardRecord legacyCardData);

        /// <summary>
        /// Delete card from degraded memory buffer. (With checking legacy formats)
        /// </summary>
        /// <param name="cardData">Legacy card data record.</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator.</returns>
        bool DeleteCard(LegacyCardRecord cardData);

        /// <summary>
        /// Delete card from degraded memory buffer. (Raw card data)
        /// </summary>
        /// <param name="cardData">Raw card data byte array.</param>
        /// <param name="cardLength">Number of bits in the raw card data byte array.</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator.</returns>
        bool DeleteCard(byte[] cardData, int cardLength);

        /// <summary>
        /// Delete all cards from the degraded memory.
        /// </summary>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator.</returns>
        bool DeleteAll();
    }
}
