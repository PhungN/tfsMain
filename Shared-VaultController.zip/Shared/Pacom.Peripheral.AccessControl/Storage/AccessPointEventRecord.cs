using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// Access point for making note of door access during degraded mode.
    /// </summary>
    public class AccessPointEventRecord
    {

        public CardReaderPortType ReaderNumber
        {
            get;
            set;
        }

        public DateTime AccessDateTime
        {
          get;
          set;
        }
    
        public byte[] Code
        {
            get;
            set;
        }

        public byte[] Issue
        {
            get;
            set;
        }

        public byte[] Facility
        {
            get;
            set;
        }
    }
}