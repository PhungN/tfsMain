﻿
namespace Pacom.Peripheral.AccessControl
{
    internal class DegradedMemoryRequestBase
    {        
    }
}
