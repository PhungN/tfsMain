using System;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// Raw access point class for making a note of door access during degraded mode.
    /// </summary>
    public class AccessPointEventRecordRaw : AccessPointEventRecordBase
    {
        public int CardLength
        {
            get;
            set;
        }
    
        public byte[] CardData
        {
            get;
            set;
        }        
    }
}