﻿using System;

namespace Pacom.Peripheral.AccessControl
{
    public class CardNumberAndLength
    {
        public CardNumberAndLength(byte[] cardNumber, int length)
        {
            CardNumber = cardNumber;
            Length = length;
        }

        public byte[] CardNumber { get; set; }
        public int Length { get; set; }
    }
}