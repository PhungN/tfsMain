﻿using System;
using System.Threading;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// This class defines holder for card details which are sent to controller for approval.
    /// The instance should clean itself after defined times, to prevent unauthorized card access.
    /// </summary>
    public class AccessPointLastRequestToController : IDisposable
    {
        private LegacyCardRecord legacyCardData;
        private byte[] cardData;
        private int cardLength;

        private object cardDataLock = new object();
        private Timer waitForControllerTimer = null;

        public AccessPointLastRequestToController()
        {
            waitForControllerTimer = new Timer(deleteRecordedCard, null, Timeout.Infinite, Timeout.Infinite);
            Clear();
        }

        /// <summary>
        /// Card byte data
        /// </summary>
        public byte[] CardData
        {
            get
            {
                return cardData;
            }
        }

        /// <summary>
        /// Card length in bits.
        /// </summary>
        public int CardLength
        {
            get
            {
                return cardLength;
            }
        }

        public LegacyCardRecord LegacyCardData
        {
            get
            {
                return legacyCardData;
            }
        }

        /// <summary>
        /// Clears the last card.
        /// </summary>
        public void Clear()
        {
            waitForControllerTimer.Change(Timeout.Infinite, Timeout.Infinite);
            lock (cardDataLock)
            {
                cardData = null;
                cardLength = 0;
            }
        }

        public void StopTimer()
        {
            waitForControllerTimer.Change(Timeout.Infinite, Timeout.Infinite);
        }

        /// <summary>
        /// Get true if request to store card is present and card can be retrived.
        /// </summary>
        public bool CardDataExists
        {
            get
            {
                lock (cardDataLock)
                {
                    return cardData != null;
                }
            }
        }

        /// <summary>
        /// Register card after sent to controller for approval.
        /// </summary>
        /// <param name="cardData">Card data to approved.</param>
        /// <param name="cardLength">Card length in bits.</param>
        /// <param name="validTime">Time allowed for controller to check the card and approve or deny</param>
        public void RegisterCard(byte[] cardData, int cardLength, int validTime, LegacyCardRecord legacyCardData)
        {
            StopTimer();
            lock (cardDataLock)
            {                
                this.cardData = cardData;
                this.cardLength = cardLength;
                this.legacyCardData = legacyCardData;
                waitForControllerTimer.Change(validTime, Timeout.Infinite);
            }
        }

        /// <summary>
        /// Delegate for the timer
        /// </summary>
        /// <param name="state"></param>
        private void deleteRecordedCard(object state)
        {
            Clear();
        }

        #region IDisposable Members

        private bool disposed = false;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    Clear();
                }
            }
            disposed = true;
        }

        ~AccessPointLastRequestToController()
        {
            Dispose(false);
        }

        #endregion
    }
}
