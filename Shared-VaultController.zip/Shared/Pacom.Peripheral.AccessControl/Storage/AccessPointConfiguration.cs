﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    public class AccessPointConfiguration : IDisposable
    {        
        public AccessPointConfiguration(CardReaderPortType reader)
        {
            DeviceLoopConfig = new AccessPointDeviceLoopConfig();
            DeviceLoopConfig.ReaderInitializationRecord.ReaderType = CardReaderType.NoReader;
            KeypadState = new KeypadOperation();
            LastRequestToController = new AccessPointLastRequestToController();
            LastRequestToController.Clear();
            handledReader = reader;
        }

        private readonly CardReaderPortType handledReader;

        /// <summary>
        /// Device loop configuration for the card reader.
        /// </summary>
        public readonly AccessPointDeviceLoopConfig DeviceLoopConfig;

        /// <summary>
        /// Get the controller initialized reader type.
        /// </summary>
        public CardReaderType InitializedReaderType
        {
            get
            {
                return DeviceLoopConfig.ReaderInitializationRecord.ReaderType;
            }
        }

        /// <summary>
        /// Keypad state operation.
        /// </summary>
        public KeypadOperation KeypadState;

        /// <summary>
        /// Last read card for this access point.
        /// </summary>
        public AccessPointLastRequestToController LastRequestToController;

        public override string ToString()
        {
            return handledReader.ToString();
        }

        #region IDisposable Members

        private bool disposed = false;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    DeviceLoopConfig.ReaderInitializationRecord.ReaderType = CardReaderType.NoReader;
                    KeypadState.Dispose();
                    LastRequestToController.Dispose();
                }
                disposed = true;
            }
        }

        ~AccessPointConfiguration()
        {
            Dispose(false);
        }

        #endregion
    }
}
