﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Pacom.Peripheral.AccessControl
{
    internal class DegradedMemoryRequestList : IDisposable
    {
        private Queue<DegradedMemoryRequestBase> requestQueue = new Queue<DegradedMemoryRequestBase>();
        private readonly object requestQueueLock = new object();

        private ManualResetEvent requestProcessingEvent = new ManualResetEvent(false);

        public DegradedMemoryRequestList()
        {
        }

        /// <summary>
        /// Add request for processing.
        /// </summary>
        /// <param name="request"></param>
        public void AddRequest(DegradedMemoryRequestBase request)
        {
            lock (requestQueueLock)
            {
                requestQueue.Enqueue(request);
                requestProcessingEvent.Set();
            }
        }
        
        /// <summary>
        /// Return true if there are any requests awaiting for processing.
        /// </summary>
        public bool IsRequestWaiting
        {
            get
            {
                lock (requestQueueLock)
                {
                    if (terminated)
                        return false;
                    else
                        return (requestQueue.Count != 0);
                }
            }
        }

        /// <summary>
        /// Wait for an request to be queued.
        /// </summary>
        public void Wait()
        {
            if (IsRequestWaiting)
                return;
            requestProcessingEvent.Reset();
            requestProcessingEvent.WaitOne();
        }

        /// <summary>
        /// Get last request for processing.
        /// </summary>
        /// <returns></returns>
        public DegradedMemoryRequestBase GetRequest()
        {
            lock (requestQueueLock)
            {
                DegradedMemoryRequestBase item = requestQueue.Dequeue();
                return item;
            }
        }

        /// <summary>
        /// Number of requests waiting for processing.
        /// </summary>
        public int RequestCount
        {
            get
            {
                lock (requestQueueLock)
                {
                    return requestQueue.Count;
                }
            }
        }

        private bool terminated = false;

        /// <summary>
        /// Terminate waiting for the request queue;
        /// </summary>
        public void Terminate()
        {
            terminated = true;
            requestProcessingEvent.Set();
        }

        #region IDisposable Members

        private bool disposed = false;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (this.disposed == false)
            {
                
            }
            disposed = true;
        }

        #endregion
    }
}
