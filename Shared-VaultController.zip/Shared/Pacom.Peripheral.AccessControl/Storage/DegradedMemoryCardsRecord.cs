﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// This class keeps record of data flash page usage.
    /// </summary>
    public class DegradedMemoryCardsRecord : IDegradedMemoryRecord
    {
        /// <summary>
        /// Parameterless constructor marking page as valid by default.
        /// </summary>
        public DegradedMemoryCardsRecord()
        {
        }

        private DegradedMemoryCardRecord[] cards = new DegradedMemoryCardRecord[DataFlashLocations.CardAccessCardRecordsPerPage];

        /// <summary>
        /// Public accessor for card collection
        /// </summary>
        public DegradedMemoryCardRecord[] Cards
        {
            get
            {
                return cards;
            }
        }

        private byte[] checkSum = new byte[0];

        public byte[] Checksum
        {
            get
            {
                return checkSum;
            }
        }

        /// <summary>
        /// Serialize this class into 264 bytes of byte array.
        /// </summary>
        /// <returns></returns>
        public byte[] Serialize()
        {
            byte[] pageData = new byte[DataFlashLocations.DataFlashPageSize];
            for (int iDef = 0; iDef < pageData.Length; iDef++)
            {
                pageData[iDef] = 0xFF;
            }

            int byteUsed = 4;
            for (int iRecord = 0; iRecord < DataFlashLocations.CardAccessCardRecordsPerPage; iRecord++)
            {
                if (cards[iRecord].CardData != null && cards[iRecord].CardData.Length > 0)
                {
                    // Bit used - 0xFFFF means card data not populated (default value)
                    pageData[byteUsed++] = (byte)((cards[iRecord].CardBits & 0xFF00) >> 8);
                    pageData[byteUsed++] = (byte)(cards[iRecord].CardBits & 0xFF);
                    // Copy card usage
                    long lastUsedInUTC = cards[iRecord].LastUsed.ToUniversalTime().Ticks;
                    int lastUsedInUTCHigh = (int)(lastUsedInUTC >> 32);
                    int lastUsedInUTCLow = (int)(lastUsedInUTC);
                    pageData[byteUsed++] = (byte)((lastUsedInUTCHigh & (uint)0xFF000000) >> 24);
                    pageData[byteUsed++] = (byte)((lastUsedInUTCHigh & (int)0x00FF0000) >> 16);
                    pageData[byteUsed++] = (byte)((lastUsedInUTCHigh & (int)0x0000FF00) >> 8);
                    pageData[byteUsed++] = (byte)(lastUsedInUTCHigh & (int)0x000000FF);
                    pageData[byteUsed++] = (byte)((lastUsedInUTCLow & (uint)0xFF000000) >> 24);
                    pageData[byteUsed++] = (byte)((lastUsedInUTCLow & (int)0x00FF0000) >> 16);
                    pageData[byteUsed++] = (byte)((lastUsedInUTCLow & (int)0x0000FF00) >> 8);
                    pageData[byteUsed++] = (byte)(lastUsedInUTCLow & (int)0x000000FF);
                    // Set unused bits
                    CardReaderUtilityFunctions.SetBits(cards[iRecord].CardData, cards[iRecord].CardBits);
                    // Copy card data
                    for (int iData = 0; iData < 32; iData++)
                    {
                        if (iData < cards[iRecord].CardData.Length)
                        {
                            pageData[byteUsed++] = cards[iRecord].CardData[iData];
                        }
                        else
                        {
                            byteUsed += 32 - iData;
                            break;
                        }
                    }
                }
            }
            // Calculate check sum
            byte[] checkSum = Crc32.ComputeHash(pageData, 4, pageData.Length - 4);
            pageData[0] = checkSum[0];
            pageData[1] = checkSum[1];
            pageData[2] = checkSum[2];
            pageData[3] = checkSum[3];
            return pageData;
        }

        /// <summary>
        /// Deserialize this class from 264 bytes of byte array.
        /// </summary>
        /// <param name="pageData"></param>
        /// <returns></returns>
        public bool Deserialize(byte[] pageData, PcbType pcbType)
        {
            // Check page size
            if (pageData.Length < DataFlashLocations.DataFlashPageSize)
            {
                checkSum = new byte[0];
                return false;
            }
            try
            {
                // Check check-sum
                checkSum = new byte[4];
                checkSum[0] = pageData[0];
                checkSum[1] = pageData[1];
                checkSum[2] = pageData[2];
                checkSum[3] = pageData[3];
                byte[] recheckSum = Crc32.ComputeHash(pageData, 4, pageData.Length - 4);
                if (recheckSum.SequenceEqual(checkSum) == false)
                {
                    checkSum = new byte[0];
                    return false;
                }

                // Copy rest of data
                int byteUsed = 4;
                for (int iRecord = 0; iRecord < DataFlashLocations.CardAccessCardRecordsPerPage; iRecord++)
                {
                    // Get card bits and do checks
                    int cardBits = (pageData[byteUsed++] << 8) | (pageData[byteUsed++]);
                    if (cardBits <= 0 || cardBits > 256)
                    {
                        cards[iRecord] = new DegradedMemoryCardRecord(new byte[0], 0, DateTime.MinValue);
                    }
                    else
                    {
                        // Get last uased
                        int lastUsedInUTCHigh = (pageData[byteUsed++] << 24) | (pageData[byteUsed++] << 16) | (pageData[byteUsed++] << 8) | pageData[byteUsed++];
                        int lastUsedInUTCLow = (pageData[byteUsed++] << 24) | (pageData[byteUsed++] << 16) | (pageData[byteUsed++] << 8) | pageData[byteUsed++];
                        long ticks = (long)(lastUsedInUTCHigh) << 32;
                        ticks |= (uint)lastUsedInUTCLow;
                        DateTime cardLastUsed = new DateTime(ticks, DateTimeKind.Utc).ToLocalTime();
                        // Reserve byte array for card data, and copy only used bytes.
                        int cardBytes = cardBits / 8 + (cardBits % 8 > 0 ? 1 : 0);
                        byte[] cardData = new byte[cardBytes];
                        for (int iData = 0; iData < cardBytes; iData++)
                        {
                            cardData[iData] = pageData[byteUsed++];
                        }
                        byteUsed += 32 - cardBytes;
                        // We still need to clear the bits, in case when last byte is not fully used.
                        CardReaderUtilityFunctions.ClearBits(cardData, cardBits);
                        cards[iRecord] = new DegradedMemoryCardRecord(cardData, cardBits, cardLastUsed);
                    }
                }
            }
            catch
            {
                Clear();
                return false;
            }
            return true;
        }

        public bool Validate()
        {
            if (checkSum == null)
            {
                return false;
            }

            if (checkSum.Length == 0)
            {
                return false;
            }
          
            return true;
        }

        public byte[] InitialPageData
        {
            get
            {
                return GetInitialPageData();
            }
        }

        private static byte[] GetInitialPageData()
        {
            byte[] initialData = new byte[DataFlashLocations.DataFlashPageSize];
            for (int iData = 0; iData < initialData.Length; iData++)
            {
                initialData[iData] = 0xFF;
            }
            // Calculate check sum
            byte[] checkSum = Crc32.ComputeHash(initialData, 4, initialData.Length - 4);
            initialData[0] = checkSum[0];
            initialData[1] = checkSum[1];
            initialData[2] = checkSum[2];
            initialData[3] = checkSum[3];
            return initialData;
        }

        public void Clear()
        {
            checkSum = new byte[0];
        }
    }
}
