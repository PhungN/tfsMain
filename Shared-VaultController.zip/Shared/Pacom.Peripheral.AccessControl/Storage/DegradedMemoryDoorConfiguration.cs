﻿using System.Collections.Generic;

namespace Pacom.Peripheral.AccessControl
{
    public class DegradedMemoryDoorConfiguration
    {
        private Dictionary<int, DegradedMemoryReaderConfiguration> readerList = new Dictionary<int, DegradedMemoryReaderConfiguration>();

        public DegradedMemoryDoorConfiguration()
        {
        }

        /// <summary>
        /// Clear all readers from the degraded memory door list.
        /// </summary>
        public void Clear()
        {
            readerList.Clear();
        }

        /// <summary>
        /// Add reader item to the configuration list.
        /// </summary>
        /// <param name="logicalDoorId">Reader hardware index</param>
        /// <returns>Returns DegradedMemoryReaderConfiguration instance for the given door logical id.</returns>
        public DegradedMemoryReaderConfiguration AddReader(int readerIndex)
        {
            DegradedMemoryReaderConfiguration config = null;
            if (readerList.ContainsKey(readerIndex))
            {
                config = readerList[readerIndex];
            }
            else
            {
                config = new DegradedMemoryReaderConfiguration();
                readerList.Add(readerIndex, config);
            }
            return config;
        }

        /// <summary>
        /// Return reader configuration 
        /// </summary>
        /// <param name="index">Hardware index. Zero based.</param>
        /// <returns>Reaturned complete reader configuration</returns>
        public DegradedMemoryReaderConfiguration this[int index]
        {
            get
            {
                return readerList[index];
            }
        }
    }
}
