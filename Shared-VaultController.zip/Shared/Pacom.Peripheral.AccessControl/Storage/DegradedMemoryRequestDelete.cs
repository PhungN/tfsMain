﻿
namespace Pacom.Peripheral.AccessControl
{
    internal class DegradedMemoryRequestDelete : DegradedMemoryRequestBase
    {
        public DegradedMemoryRequestDelete(byte[] cardData, int cardLength)
        {
            CardData = cardData;
            CardLength = cardLength;
        }

        public byte[] CardData
        {
            get;
            private set;
        }
            
        public int CardLength
        {
            get;
            private set;
        }
    }
}
