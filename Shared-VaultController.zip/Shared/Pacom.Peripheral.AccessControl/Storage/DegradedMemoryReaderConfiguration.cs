﻿using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// Complete reader configuration.
    /// </summary>
    public class DegradedMemoryReaderConfiguration
    {
        public DegradedMemoryReaderConfiguration()
        {
            InitializationConfig = new ReaderInitializationConfig();
            InitializationConfig.ReaderType = CardReaderType.NoReader;
            FormatConfig = new AccessPointFormatConfig[0];
            MasterCard = new LegacyCardRecord();
        }

        public ReaderInitializationConfig InitializationConfig
        {
            get;
            set;
        }

        public AccessPointFormatConfig[] FormatConfig
        {
            get;
            set;
        }

        public LegacyCardRecord MasterCard
        {
            get;
            set;
        }        
    }
}
