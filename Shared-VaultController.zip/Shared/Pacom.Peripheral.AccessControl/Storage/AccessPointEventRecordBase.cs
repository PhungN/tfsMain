using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// Base class for access point note of door access during degraded mode.
    /// </summary>
    public class AccessPointEventRecordBase
    {

        public CardReaderPortType ReaderNumber
        {
            get;
            set;
        }

        public DateTime AccessDateTime
        {
          get;
          set;
        }            
    }
}