﻿using System;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// This class is used to convey card information to and from the degraded memory record.
    /// </summary>
    public class DegradedMemoryCardRecord
    {
        /// <summary>
        /// Constructor 
        /// </summary>
        /// <param name="cardData"></param>
        /// <param name="cardBits"></param>
        /// <param name="lastUsed"></param>
        public DegradedMemoryCardRecord(byte[] cardData, int cardBits, DateTime lastUsed)
        {
            this.CardData = cardData;
            this.CardBits = cardBits;
            this.LastUsed = lastUsed;
        }

        /// <summary>
        /// Card data
        /// </summary>
        public byte[] CardData;

        /// <summary>
        /// Card bits used within card data
        /// </summary>
        public int CardBits;

        /// <summary>
        /// Last time card transaction was positively identified from the controller.
        /// </summary>
        public DateTime LastUsed;

        /// <summary>
        /// Return status of card record.
        /// </summary>
        public bool IsValidCard
        {
            get
            {
                if (CardBits <= 0 || CardBits > 256)
                {
                    return false;
                }
                if (CardData == null || CardData.Length <= 0 || CardData.Length > 32)
                {
                    return false;
                }
                return true;
            }
        }

        public void Invalidate()
        {
            CardBits = int.MaxValue;
            CardData = null;
        }
    }
}
