﻿using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    internal class DegradedMemoryRequestLegacyDelete : DegradedMemoryRequestBase
    {
        public DegradedMemoryRequestLegacyDelete(LegacyCardRecord cardData)
        {
            CardData = cardData;
        }

        public LegacyCardRecord CardData
        {
            get;
            private set;
        }
    }
}
