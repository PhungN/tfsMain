using System;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// Legacy access point class for making a note of door access during degraded mode.
    /// </summary>
    public class AccessPointEventRecordLegacy : AccessPointEventRecordBase
    {
        public byte[] Code
        {
            get;
            set;
        }

        public byte[] Issue
        {
            get;
            set;
        }

        public byte[] Facility
        {
            get;
            set;
        }
    }
}