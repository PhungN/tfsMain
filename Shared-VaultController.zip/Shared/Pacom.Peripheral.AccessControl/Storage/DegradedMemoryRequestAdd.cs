﻿using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    internal class DegradedMemoryRequestAdd : DegradedMemoryRequestBase
    {
        public DegradedMemoryRequestAdd(byte[] cardData, int cardLength, LegacyCardRecord legacyCardData)
        {
            CardData = cardData;
            CardLength = cardLength;
            LegacyCardData = legacyCardData;
        }

        public byte[] CardData
        {
            get;
            private set;
        }
            
        public int CardLength
        {
            get;
            private set;
        }

        public LegacyCardRecord LegacyCardData
        {
            get;
            private set;
        }
    }
}
