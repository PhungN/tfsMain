﻿using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// Reader access point configuration. This includes device loop storage, master code from legacy controller.
    /// </summary>
    public class AccessPointDeviceLoopConfig
    {

        /// <summary>
        /// Number of formats held by this class.
        /// </summary>
        public const int NumberOfFormats = 4;

        /// <summary>
        /// Reader access point constructor.
        /// </summary>
        public AccessPointDeviceLoopConfig()
        {
            this.AccessPointCardFormats = new AccessPointFormatConfig[NumberOfFormats];
            for (int i = 0; i < NumberOfFormats; i++)
            {
                this.AccessPointCardFormats[i] = new AccessPointFormatConfig();
            }
            this.ReaderInitializationRecord = new ReaderInitializationConfig();
            this.MasterCard = new LegacyCardRecord();
        }

        /// <summary>
        /// Reader initialization record.
        /// </summary>
        public ReaderInitializationConfig ReaderInitializationRecord;

        /// <summary>
        /// Access point format.
        /// </summary>
        public AccessPointFormatConfig[] AccessPointCardFormats;

        /// <summary>
        /// Master card configured by legacy controller. It is stored in legacy degraded mode format.
        /// </summary>
        public LegacyCardRecord MasterCard;
    }
}
