﻿using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    public class AccessPointFormatConfig
    {
        public CardFormatMaskConfig Mask;
        public CardFormatParityConfig Parity;
    }
}
