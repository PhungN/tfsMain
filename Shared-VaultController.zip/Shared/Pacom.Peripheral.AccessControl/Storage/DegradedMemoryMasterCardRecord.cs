﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.AccessControl
{
    /// <summary>
    /// This class is representing master card record in degraded memory.
    /// </summary>
    public class DegradedMemoryMasterCardRecord : IDegradedMemoryRecord
    {
        /// <summary>
        /// Byte array with master card code. Only first 32 bytes will be copied to data flash.
        /// </summary>
        public byte[] Code = new byte[0];

        /// <summary>
        /// Byte array with master card issue. Only first 32 bytes will be copied to data flash.
        /// </summary>
        public byte[] Issue = new byte[0];

        /// <summary>
        /// Byte array with master card facility. Only first 32 bytes will be copied to data flash.
        /// </summary>
        public byte[] Facility = new byte[0];

        private byte[] checkSum = new byte[0];

        /// <summary>
        /// Page checksum.
        /// </summary>        
        public byte[] Checksum
        {
            get
            {
                return checkSum;
            }
        }

        public void SetMasterCard(LegacyCardRecord masterCard)
        {
            if (masterCard == null)
                return;
            this.Code = masterCard.Code;
            this.Issue = masterCard.Issue;
            this.Facility = masterCard.Facility;
        }

        public LegacyCardRecord GetMasterCard()
        {
            return LegacyCardRecord.Clone(Facility, Issue, Code);
        }

        private const int codeLengthOffset = 4;
        private const int codeOffset = 5;
        private const int issueLengthOffset = 37;
        private const int issueOffset = 38;
        private const int facilityLengthOffset = 70;
        private const int facilityOffset = 71;

        public byte[] Serialize()
        {
            byte[] pageData = new byte[DataFlashLocations.DataFlashPageSize];
            for (int i = 0; i < pageData.Length; i++)
            {
                pageData[i] = 0xFF;
            }

            if (Code == null)
            {
                pageData[codeLengthOffset] = 0;
            }
            else
            {
                pageData[codeLengthOffset] = (byte)Code.Length;
                Buffer.BlockCopy(Code, 0, pageData, codeOffset, Code.Length);
            }

            if (Issue == null)
            {
                pageData[issueLengthOffset] = 0;
            }
            else
            {
                pageData[issueLengthOffset] = (byte)Issue.Length;
                Buffer.BlockCopy(Issue, 0, pageData, issueOffset, Issue.Length);
            }

            if (Facility == null)
            {
                pageData[facilityLengthOffset] = 0;
            }
            else
            {
                pageData[facilityLengthOffset] = (byte)Facility.Length;
                Buffer.BlockCopy(Facility, 0, pageData, facilityOffset, Facility.Length);
            }

            // Calculate check sum
            byte[] checkSum = Crc32.ComputeHash(pageData, 4, pageData.Length - 4);
            pageData[0] = checkSum[0];
            pageData[1] = checkSum[1];
            pageData[2] = checkSum[2];
            pageData[3] = checkSum[3];
            return pageData;
        }

        public bool Deserialize(byte[] pageData, PcbType pcbType)
        {
            // Check page size
            if (pageData.Length < DataFlashLocations.DataFlashPageSize)
            {
                checkSum = new byte[0];
                return false;
            }
            try
            {
                // Check check-sum
                checkSum = new byte[4];
                checkSum[0] = pageData[0];
                checkSum[1] = pageData[1];
                checkSum[2] = pageData[2];
                checkSum[3] = pageData[3];
                byte[] recheckSum = Crc32.ComputeHash(pageData, 4, pageData.Length - 4);
                if (recheckSum.SequenceEqual(checkSum) == false)
                {
                    checkSum = new byte[0];
                    return false;
                }

                Code = new byte[pageData[codeLengthOffset]];
                Issue = new byte[pageData[issueLengthOffset]];
                Facility = new byte[pageData[facilityLengthOffset]];

                Buffer.BlockCopy(pageData, codeOffset, Code, 0, Code.Length);
                Buffer.BlockCopy(pageData, issueOffset, Issue, 0, Issue.Length);
                Buffer.BlockCopy(pageData, facilityOffset, Facility, 0, Facility.Length);
            }
            catch
            {
                Clear();
                return false;
            }
            return true;
        }

        public bool Validate()
        {
            if (checkSum == null)
            {
                return false;
            }

            if (checkSum.Length == 0)
            {
                return false;
            }

            return true;
        }

        public byte[] InitialPageData
        {
            get
            {
                return GetInitialPageData();
            }
        }

        private static byte[] GetInitialPageData()
        {
            byte[] initialData = new byte[DataFlashLocations.DataFlashPageSize];
            for (int iData = 0; iData < initialData.Length; iData++)
            {
                initialData[iData] = 0xFF;
            }
            // Calculate check sum
            byte[] checkSum = Crc32.ComputeHash(initialData, 4, initialData.Length - 4);
            initialData[0] = checkSum[0];
            initialData[1] = checkSum[1];
            initialData[2] = checkSum[2];
            initialData[3] = checkSum[3];
            return initialData;
        }

        public void Clear()
        {
            checkSum = new byte[0];
            Code = new byte[0];
            Issue = new byte[0];
            Facility = new byte[0];
        }
    }
}
