﻿
namespace Pacom.Peripheral.AccessControl
{
    internal class DegradedMemoryRequestDeleteAll : DegradedMemoryRequestBase
    {
    }
}
