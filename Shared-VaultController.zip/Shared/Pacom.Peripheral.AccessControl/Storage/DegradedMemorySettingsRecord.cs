﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.AccessControl
{
    public class DegradedMemorySettingsRecord : IDegradedMemoryRecord
    {
        /// <summary>
        /// Card reader initialization record reference
        /// </summary>
        public ReaderInitializationConfig ReaderInitializationRecord = new ReaderInitializationConfig();

        /// <summary>
        /// Card reader multi formats reference
        /// </summary>
        public AccessPointFormatConfig[] AccessPointCardFormats = null;

        public DegradedMemorySettingsRecord()
        {
            this.AccessPointCardFormats = new AccessPointFormatConfig[4];
            for (int i = 0; i < 4; i++)
            {
                this.AccessPointCardFormats[i] = new AccessPointFormatConfig();
                this.AccessPointCardFormats[i].Mask = null;
                this.AccessPointCardFormats[i].Parity = null;
            }
        }

        private byte[] checkSum = new byte[0];

        /// <summary>
        /// Page checksum.
        /// </summary>  
        public byte[] Checksum
        {
            get
            {
                return checkSum;
            }
        }

        public byte[] Serialize()
        {
            byte[] pageData = new byte[DataFlashLocations.DataFlashPageSize];
            for (int iDef = 0; iDef < pageData.Length; iDef++)
            {
                pageData[iDef] = 0xFF;
            }
            // Start to serialize. Offset by 4 for check sum
            int byteUsed = 4;
            
            // Reader type
            pageData[byteUsed] = (byte)ReaderInitializationRecord.ReaderType;

            // Facility
            if (ReaderInitializationRecord.Facility.UnitType == CardConfigFieldType.InBits)
            {
                pageData[byteUsed + 1] = (byte)((ReaderInitializationRecord.Facility.Length & 0x3F) | 0x40); // Length always in bits
                pageData[byteUsed + 2] = (byte)((ReaderInitializationRecord.Facility.ZeroBasedOffset & 0x7F));
                if (ReaderInitializationRecord.Facility.IncludeInMask == true)
                {
                    pageData[byteUsed + 2] |= (byte)0x80;
                }
            }
            else
            {
                pageData[byteUsed + 1] = 0;
                pageData[byteUsed + 2] = 0;
            }

            // Issue
            if (ReaderInitializationRecord.Issue.UnitType == CardConfigFieldType.InBits)
            {
                pageData[byteUsed + 3] = (byte)((ReaderInitializationRecord.Issue.Length & 0x3F) | 0x40); // Length always in bits
                pageData[byteUsed + 4] = (byte)((ReaderInitializationRecord.Issue.ZeroBasedOffset & 0x7F));
                if (ReaderInitializationRecord.Issue.IncludeInMask == true)
                {
                    pageData[byteUsed + 4] |= (byte)0x80;
                }
            }
            else
            {
                pageData[byteUsed + 3] = 0;
                pageData[byteUsed + 4] = 0;
            }

            // Code
            if (ReaderInitializationRecord.Code.UnitType == CardConfigFieldType.InBits)
            {
                pageData[byteUsed + 5] = (byte)((ReaderInitializationRecord.Code.Length & 0x3F) | 0x40); // Length always in bits
                pageData[byteUsed + 6] = (byte)((ReaderInitializationRecord.Code.ZeroBasedOffset & 0x7F));
                if (ReaderInitializationRecord.Code.IncludeInMask == true)
                {
                    pageData[byteUsed + 6] |= (byte)0x80;
                }
            }
            else
            {
                pageData[byteUsed + 5] = 0;
                pageData[byteUsed + 6] = 0;
            }

            // Provide facility and issue designators in nibbles as expectd by legacy systems.
            // Check if facility designator can be converted into nibbles.
            if ((ReaderInitializationRecord.Designators.Facility % 4) != 0)
            {
                throw new ArgumentException("Configuration facility designator cannot be converted into nibbles.");
            }
            pageData[byteUsed + 7] = (byte)((ReaderInitializationRecord.Designators.Facility / 4) & 0x0F);
            // Check if issue designator can be converted into nibbles.
            if ((ReaderInitializationRecord.Designators.Issue % 4) != 0)
            {
                throw new ArgumentException("Configuration issue designator cannot be converted into nibbles.");
            }
            pageData[byteUsed + 7] |= (byte)(((ReaderInitializationRecord.Designators.Issue / 4) << 4) & 0xF0);

            pageData[byteUsed + 8] = (byte)(ReaderInitializationRecord.StrikeDuration);

            pageData[byteUsed + 9] = (byte)(ReaderInitializationRecord.EmbarrassmentTimer);

            pageData[byteUsed + 10] = (byte)(ReaderInitializationRecord.AcceptLedFlashTime & 0x07);
            if (ReaderInitializationRecord.AcceptLedFlashEnabled == true)
            {
                pageData[byteUsed + 10] |= 0x08;
            }

            pageData[byteUsed + 11] = (byte)(ReaderInitializationRecord.DeniedLedFlashTime & 0x07);
            if (ReaderInitializationRecord.DeniedLedFlashEnabled == true)
            {
                pageData[byteUsed + 11] |= 0x08;
            }

            pageData[byteUsed + 12] = (byte)(ReaderInitializationRecord.InvalidLedFlashTime & 0x07);
            if (ReaderInitializationRecord.InvalidLedFlashEnabled == true)
            {
                pageData[byteUsed + 12] |= 0x08;
            }
            switch (ReaderInitializationRecord.InvalidBuzzer)
            {
                case CardReaderBuzzerType.BuzzerOff:
                    break;
                case CardReaderBuzzerType.BuzzerOn:
                    pageData[byteUsed + 12] |= 0x10;
                    break;
                case CardReaderBuzzerType.BuzzerPulse:
                    pageData[byteUsed + 12] |= 0x20;
                    break;
            }

            pageData[byteUsed + 13] = (byte)(ReaderInitializationRecord.ContactHitCount & 0x0F);
            pageData[byteUsed + 13] |= (byte)((ReaderInitializationRecord.EgressHitCount & 0x0F) << 4);

            pageData[byteUsed + 14] = (byte)(ReaderInitializationRecord.StrikeHitCount & 0x0F);
            if (ReaderInitializationRecord.StrikeRelayNormallyClosed == true)
            {
                pageData[byteUsed + 14] |= 0x10;
            }
            if (ReaderInitializationRecord.ContactNegative == true)
            {
                pageData[byteUsed + 14] |= 0x20;
            }
            if (ReaderInitializationRecord.EgressNegative == true)
            {
                pageData[byteUsed + 14] |= 0x40;
            }
            if (ReaderInitializationRecord.StrikeNegative == true)
            {
                pageData[byteUsed + 14] |= 0x80;
            }

            pageData[byteUsed + 15] = 0;
            pageData[byteUsed + 15] |= (byte)(ReaderInitializationRecord.KeypadInactivityTimer & 0x0F);
            pageData[byteUsed + 15] |= (byte)((ReaderInitializationRecord.KeypadNoDigitsToEnter & 0x07) << 4);
            if (ReaderInitializationRecord.KeypadSendKeyWithPin == true)
            {
                pageData[byteUsed + 15] |= 0x80;
            }

            pageData[byteUsed + 16] = ReaderInitializationRecord.BeeperDuration;


            pageData[byteUsed + 17] = 0;
            switch (ReaderInitializationRecord.AcceptBuzzer)
            {
                case CardReaderBuzzerType.BuzzerOff:
                    break;
                case CardReaderBuzzerType.BuzzerOn:
                    pageData[byteUsed + 17] |= 0x01;
                    break;
                case CardReaderBuzzerType.BuzzerPulse:
                    pageData[byteUsed + 17] |= 0x02;
                    break;
            }
            switch (ReaderInitializationRecord.DeniedBuzzer)
            {
                case CardReaderBuzzerType.BuzzerOff:
                    break;
                case CardReaderBuzzerType.BuzzerOn:
                    pageData[byteUsed + 17] |= 0x10;
                    break;
                case CardReaderBuzzerType.BuzzerPulse:
                    pageData[byteUsed + 17] |= 0x20;
                    break;
            }

            pageData[byteUsed + 18] = 0;
            if (ReaderInitializationRecord.ProcessEgressLocally == true)
            {
                pageData[byteUsed + 18] |= 0x01;
            }
            if (ReaderInitializationRecord.EgressShuntOnly == true)
            {
                pageData[byteUsed + 18] |= 0x02;
            }
            if (ReaderInitializationRecord.StoreCodeLocally == true)
            {
                pageData[byteUsed + 18] |= 0x04;
            }
            if (ReaderInitializationRecord.KeepStrikeDuringEgress == true)
            {
                pageData[byteUsed + 18] |= 0x08;
            }
            if (ReaderInitializationRecord.AllowPinOnly == true)
            {
                pageData[byteUsed + 18] |= 0x10;
            }
            if (ReaderInitializationRecord.InterlockPassback == true)
            {
                pageData[byteUsed + 18] |= 0x20;
            }
            if (ReaderInitializationRecord.ResetUserInOut == true)
            {
                pageData[byteUsed + 18] |= 0x40;
            }
            if (ReaderInitializationRecord.EnableTimeInAttend == true)
            {
                pageData[byteUsed + 18] |= 0x80;
            }

            pageData[byteUsed + 19] = 0;
            if (ReaderInitializationRecord.SupervisedEgressInput == true)
            {
                pageData[byteUsed + 19] |= 0x01;
            }
            byteUsed += 20;

            // Masks
            for (int iPosition = 0; iPosition < 4; iPosition++)
            {
                CardFormatMaskConfig mask = AccessPointCardFormats[iPosition].Mask;
                if (mask != null)
                {
                    pageData[byteUsed + (iPosition * 8)] = (byte)mask.NumberOfWiegandBits;
                    // Facility
                    pageData[byteUsed + 1 + (iPosition * 8)] = (byte)(mask.Facility.Length & 0x3F);
                    if (mask.Facility.UnitType == CardConfigFieldType.InBits)
                    {
                        pageData[byteUsed + 1 + (iPosition * 8)] |= 0x40;
                    }
                    pageData[byteUsed + 2 + (iPosition * 8)] = (byte)(mask.Facility.ZeroBasedOffset & 0x7F);
                    if (mask.Facility.IncludeInMask)
                    {
                        pageData[byteUsed + 2 + (iPosition * 8)] |= 0x80;
                    }
                    // Issue
                    pageData[byteUsed + 3 + (iPosition * 8)] = (byte)(mask.Issue.Length & 0x3F);
                    if (mask.Issue.UnitType == CardConfigFieldType.InBits)
                    {
                        pageData[byteUsed + 3 + (iPosition * 8)] |= 0x40;
                    }
                    pageData[byteUsed + 4 + (iPosition * 8)] = (byte)(mask.Issue.ZeroBasedOffset & 0x7F);
                    if (mask.Issue.IncludeInMask)
                    {
                        pageData[byteUsed + 4 + (iPosition * 8)] |= 0x80;
                    }
                    // Code
                    pageData[byteUsed + 5 + (iPosition * 8)] = (byte)(mask.Code.Length & 0x3F);
                    if (mask.Code.UnitType == CardConfigFieldType.InBits)
                    {
                        pageData[byteUsed + 5 + (iPosition * 8)] |= 0x40;
                    }
                    pageData[byteUsed + 6 + (iPosition * 8)] = (byte)(mask.Code.ZeroBasedOffset & 0x7F);
                    if (mask.Code.IncludeInMask)
                    {
                        pageData[byteUsed + 6 + (iPosition * 8)] |= 0x80;
                    }
                    // Designators
                    pageData[byteUsed + 7 + (iPosition * 8)] = (byte)((mask.Designators.Facility / 4) & 0x0F);
                    pageData[byteUsed + 7 + (iPosition * 8)] |= (byte)(((mask.Designators.Issue / 4) << 4) & 0xF0);
                }
                else
                {
                    pageData[byteUsed + (iPosition * 8)] = 0;                    
                }
            }
            byteUsed += 32;

            // Parities
            for (int iPosition = 0; iPosition < 4; iPosition++)
            {
                // Write format number
                pageData[byteUsed + (iPosition * 29)] = (byte)iPosition;

                CardFormatParityConfig config = AccessPointCardFormats[iPosition].Parity;
                if (config != null)
                {
                    byte option = 0;
                    
                    // Mask 1
                    if (config.Mask[0] != null && config.Mask[0].Enabled)
                    {
                        option |= 0x01;
                        if (config.Mask[0].OddParity)
                        {
                            option |= 0x10;
                        }
                        for (int iMask = 0; iMask < 8; iMask++)
                        {
                            if (iMask < config.Mask[0].Mask.Length)
                            {
                                pageData[byteUsed + 2 + (iPosition * 29) + iMask] = config.Mask[0].Mask[iMask];
                            }
                        }
                    }
                    else
                    {
                        option &= 0xFE;
                    }
                    pageData[byteUsed + 26 + (iPosition * 29)] = (byte)config.Mask[0].Offset;
                    // Mask 2
                    if (config.Mask[1].Enabled)
                    {
                        option |= 0x02;
                        if (config.Mask[1].OddParity)
                        {
                            option |= 0x20;
                        }
                        for (int iMask = 0; iMask < 8; iMask++)
                        {
                            if (iMask < config.Mask[1].Mask.Length)
                            {
                                pageData[byteUsed + 10 + (iPosition * 29) + iMask] = config.Mask[1].Mask[iMask];
                            }
                        }
                    }
                    else
                    {
                        option &= 0xFD;
                    }
                    pageData[byteUsed + 27 + (iPosition * 29)] = (byte)config.Mask[1].Offset;
                    // Mask 3
                    if (config.Mask[2].Enabled)
                    {
                        option |= 0x04;
                        if (config.Mask[2].OddParity)
                        {
                            option |= 0x40;
                        }
                        for (int iMask = 0; iMask < 8; iMask++)
                        {
                            if (iMask < config.Mask[2].Mask.Length)
                            {
                                pageData[byteUsed + 18 + (iPosition * 29) + iMask] = config.Mask[2].Mask[iMask];
                            }
                        }
                    }
                    else
                    {
                        option &= 0xFB;
                    }
                    pageData[byteUsed + 28 + (iPosition * 29)] = (byte)config.Mask[2].Offset;
                    // Set invert and reverse
                    if (config.Invert)
                    {
                        option |= 0x80;
                    }
                    if (config.Reverse)
                    {
                        option |= 0x08;
                    }
                    pageData[byteUsed + 1 + (iPosition * 29)] = option;
                }
                else
                {
                    // All masks disabled for this format.
                    pageData[byteUsed + 1 + (iPosition * 29)] = 0x00;
                }
            }           

            // Calculate check sum
            byte[] checkSum = Crc32.ComputeHash(pageData, 4, pageData.Length - 4);
            pageData[0] = checkSum[0];
            pageData[1] = checkSum[1];
            pageData[2] = checkSum[2];
            pageData[3] = checkSum[3];
            return pageData;
        }

        public bool Deserialize(byte[] pageData, PcbType pcbType)
        {
            // Check page size
            if (pageData.Length < DataFlashLocations.DataFlashPageSize)
            {
                checkSum = new byte[0];
                return false;
            }
            try
            {
                // Check check-sum
                checkSum = new byte[4];
                checkSum[0] = pageData[0];
                checkSum[1] = pageData[1];
                checkSum[2] = pageData[2];
                checkSum[3] = pageData[3];
                byte[] recheckSum = Crc32.ComputeHash(pageData, 4, pageData.Length - 4);
                if (recheckSum.SequenceEqual(checkSum) == false)
                {
                    checkSum = new byte[0];
                    return false;
                }

                // Create new instances of configuration holdes.
                ReaderInitializationRecord = new ReaderInitializationConfig();
                this.AccessPointCardFormats = new AccessPointFormatConfig[4];
                for (int i = 0; i < 4; i++)
                {
                    this.AccessPointCardFormats[i] = new AccessPointFormatConfig();
                    this.AccessPointCardFormats[i].Mask = new CardFormatMaskConfig();
                    this.AccessPointCardFormats[i].Parity = new CardFormatParityConfig();
                }

                // Copy rest of data
                int byteUsed = 4;

                // Parse initialization record
                ReaderInitializationRecord.ReaderType = (CardReaderType)Enum.Parse(typeof(CardReaderType), pageData[byteUsed].ToString(), true);
                // Facility
                switch ((pageData[byteUsed + 1] & 0xC0) >> 6)
                {
                    case 0:
                        ReaderInitializationRecord.Facility.UnitType = CardConfigFieldType.NotUsed;
                        ReaderInitializationRecord.Facility.Length = 0;
                        ReaderInitializationRecord.Facility.ZeroBasedOffset = 0;
                        ReaderInitializationRecord.Facility.IncludeInMask = false;
                        break;
                    case 1: // InBits
                        ReaderInitializationRecord.Facility.UnitType = CardConfigFieldType.InBits;
                        ReaderInitializationRecord.Facility.Length = (byte)(pageData[byteUsed + 1] & 0x3F);
                        ReaderInitializationRecord.Facility.ZeroBasedOffset = (pageData[byteUsed + 2] & 0x7F);
                        ReaderInitializationRecord.Facility.IncludeInMask = ((pageData[byteUsed + 2] & 128) == 128);
                        break;
                    case 2: // InNibbles (probbably not used as this stage)
                        ReaderInitializationRecord.Facility.UnitType = CardConfigFieldType.InBits;
                        ReaderInitializationRecord.Facility.Length = (byte)((pageData[byteUsed + 1] & 0x3F) * 4);
                        ReaderInitializationRecord.Facility.ZeroBasedOffset = ((pageData[byteUsed + 2] & 0x7F) * 4);
                        ReaderInitializationRecord.Facility.IncludeInMask = ((pageData[byteUsed + 2] & 128) == 128);
                        break;
                    case 3: // InBytes (probbably not used as this stage)
                        ReaderInitializationRecord.Facility.UnitType = CardConfigFieldType.InBits;
                        ReaderInitializationRecord.Facility.Length = (byte)((pageData[byteUsed + 1] & 0x3F) * 8);
                        ReaderInitializationRecord.Facility.ZeroBasedOffset = ((pageData[byteUsed + 2] & 0x7F) * 8);
                        ReaderInitializationRecord.Facility.IncludeInMask = ((pageData[byteUsed + 2] & 128) == 128);
                        break;
                }
                // Issue
                switch ((pageData[byteUsed + 3] & 0xC0) >> 6)
                {
                    case 0:
                        ReaderInitializationRecord.Issue.UnitType = CardConfigFieldType.NotUsed;
                        ReaderInitializationRecord.Issue.Length = 0;
                        ReaderInitializationRecord.Issue.ZeroBasedOffset = 0;
                        ReaderInitializationRecord.Issue.IncludeInMask = false;
                        break;
                    case 1: // InBits
                        ReaderInitializationRecord.Issue.UnitType = CardConfigFieldType.InBits;
                        ReaderInitializationRecord.Issue.Length = (byte)(pageData[byteUsed + 3] & 0x3F);
                        ReaderInitializationRecord.Issue.ZeroBasedOffset = (pageData[byteUsed + 4] & 0x7F);
                        ReaderInitializationRecord.Issue.IncludeInMask = ((pageData[byteUsed + 4] & 128) == 128);
                        break;
                    case 2: // InNibbles (probbably not used as this stage)
                        ReaderInitializationRecord.Issue.UnitType = CardConfigFieldType.InBits;
                        ReaderInitializationRecord.Issue.Length = (byte)((pageData[byteUsed + 3] & 0x3F) * 4);
                        ReaderInitializationRecord.Issue.ZeroBasedOffset = ((pageData[byteUsed + 4] & 0x7F) * 4);
                        ReaderInitializationRecord.Issue.IncludeInMask = ((pageData[byteUsed + 4] & 128) == 128);
                        break;
                    case 3: // InBytes (probbably not used as this stage)
                        ReaderInitializationRecord.Issue.UnitType = CardConfigFieldType.InBits;
                        ReaderInitializationRecord.Issue.Length = (byte)((pageData[byteUsed + 3] & 0x3F) * 8);
                        ReaderInitializationRecord.Issue.ZeroBasedOffset = ((pageData[byteUsed + 4] & 0x7F) * 8);
                        ReaderInitializationRecord.Issue.IncludeInMask = ((pageData[byteUsed + 4] & 128) == 128);
                        break;
                }
                // Code
                switch ((pageData[byteUsed + 5] & 0xC0) >> 6)
                {
                    case 0:
                        ReaderInitializationRecord.Code.UnitType = CardConfigFieldType.NotUsed;
                        ReaderInitializationRecord.Code.Length = 0;
                        ReaderInitializationRecord.Code.ZeroBasedOffset = 0;
                        ReaderInitializationRecord.Code.IncludeInMask = false;
                        break;
                    case 1: // InBits
                        ReaderInitializationRecord.Code.UnitType = CardConfigFieldType.InBits;
                        ReaderInitializationRecord.Code.Length = (byte)(pageData[byteUsed + 5] & 0x3F);
                        ReaderInitializationRecord.Code.ZeroBasedOffset = (pageData[byteUsed + 6] & 0x7F);
                        ReaderInitializationRecord.Code.IncludeInMask = ((pageData[byteUsed + 6] & 128) == 128);
                        break;
                    case 2: // InNibbles (probbably not used as this stage)
                        ReaderInitializationRecord.Code.UnitType = CardConfigFieldType.InBits;
                        ReaderInitializationRecord.Code.Length = (byte)((pageData[byteUsed + 5] & 0x3F) * 4);
                        ReaderInitializationRecord.Code.ZeroBasedOffset = ((pageData[byteUsed + 6] & 0x7F) * 4);
                        ReaderInitializationRecord.Code.IncludeInMask = ((pageData[byteUsed + 6] & 128) == 128);
                        break;
                    case 3: // InBytes (probbably not used as this stage)
                        ReaderInitializationRecord.Code.UnitType = CardConfigFieldType.InBits;
                        ReaderInitializationRecord.Code.Length = (byte)((pageData[byteUsed + 5] & 0x3F) * 8);
                        ReaderInitializationRecord.Code.ZeroBasedOffset = ((pageData[byteUsed + 6] & 0x7F) * 8);
                        ReaderInitializationRecord.Code.IncludeInMask = ((pageData[byteUsed + 6] & 128) == 128);
                        break;
                }

                // SPEC485 byte 7            
                // Unit type for facility designator is in nibbles, it will be converted to bits here;
                ReaderInitializationRecord.Designators.Facility = (byte)(pageData[byteUsed + 7] & 0x0F) * 4;
                // Unit type for issue designator is in nibbles, it will be converted to bits here.
                ReaderInitializationRecord.Designators.Issue = (byte)((pageData[byteUsed + 7] & 0xF0) >> 4) * 4;

                // SPEC485 byte 8
                ReaderInitializationRecord.StrikeDuration = (byte)pageData[byteUsed + 8];

                // SPEC485 byte 9
                ReaderInitializationRecord.EmbarrassmentTimer = pageData[byteUsed + 9];

                // SPEC485 byte 10
                ReaderInitializationRecord.AcceptLedFlashTime = (byte)(pageData[byteUsed + 10] & 0x07);
                ReaderInitializationRecord.AcceptLedFlashEnabled = ((pageData[byteUsed + 10] & 0x08) == 0x08);

                // SPEC485 byte 11
                ReaderInitializationRecord.DeniedLedFlashTime = (byte)(pageData[byteUsed + 11] & 0x07);
                ReaderInitializationRecord.DeniedLedFlashEnabled = ((pageData[byteUsed + 11] & 0x08) == 0x08);

                // SPEC485 byte 12            
                ReaderInitializationRecord.InvalidLedFlashTime = (byte)(pageData[byteUsed + 12] & 0x07);
                ReaderInitializationRecord.InvalidLedFlashEnabled = ((pageData[byteUsed + 12] & 0x08) == 0x08);
                switch ((pageData[byteUsed + 12] & 0x30) >> 4)
                {
                    case 0: ReaderInitializationRecord.InvalidBuzzer = CardReaderBuzzerType.BuzzerOff; break;
                    case 1: ReaderInitializationRecord.InvalidBuzzer = CardReaderBuzzerType.BuzzerOn; break;
                    case 2: ReaderInitializationRecord.InvalidBuzzer = CardReaderBuzzerType.BuzzerPulse; break;
                }

                // SPEC485 byte 13
                ReaderInitializationRecord.ContactHitCount = (byte)(pageData[byteUsed + 13] & 0x0F);
                ReaderInitializationRecord.EgressHitCount = (byte)((pageData[byteUsed + 13] & 0xF0) >> 4);

                // SPEC485 byte 14
                ReaderInitializationRecord.StrikeHitCount = (byte)(pageData[byteUsed + 14] & 0x0F);
                ReaderInitializationRecord.StrikeRelayNormallyClosed = ((pageData[byteUsed + 14] & 0x10) == 0x10);
                ReaderInitializationRecord.ContactNegative = ((pageData[byteUsed + 14] & 0x20) == 0x20);
                ReaderInitializationRecord.EgressNegative = ((pageData[byteUsed + 14] & 0x40) == 0x40);
                ReaderInitializationRecord.StrikeNegative = ((pageData[byteUsed + 14] & 0x80) == 0x80);

                // SPEC485 byte 15
                ReaderInitializationRecord.KeypadInactivityTimer = (byte)(pageData[byteUsed + 15] & 0x0F);
                ReaderInitializationRecord.KeypadNoDigitsToEnter = (byte)((pageData[byteUsed + 15] & 0x70) >> 4);
                ReaderInitializationRecord.KeypadSendKeyWithPin = (pageData[byteUsed + 15] & 0x80) == 0x80;

                // SPEC485 byte 16 - Beeper duration. Skipped from implementation.
                ReaderInitializationRecord.BeeperDuration = pageData[byteUsed + 16];

                // SPEC485 byte 17
                switch (pageData[byteUsed + 17] & 0x03)
                {
                    case 0: ReaderInitializationRecord.AcceptBuzzer = CardReaderBuzzerType.BuzzerOff; break;
                    case 1: ReaderInitializationRecord.AcceptBuzzer = CardReaderBuzzerType.BuzzerOn; break;
                    case 2: ReaderInitializationRecord.AcceptBuzzer = CardReaderBuzzerType.BuzzerPulse; break;
                }
                switch ((pageData[byteUsed + 17] & 0x0C) >> 2)
                {
                    case 0: ReaderInitializationRecord.DeniedBuzzer = CardReaderBuzzerType.BuzzerOff; break;
                    case 1: ReaderInitializationRecord.DeniedBuzzer = CardReaderBuzzerType.BuzzerOn; break;
                    case 2: ReaderInitializationRecord.DeniedBuzzer = CardReaderBuzzerType.BuzzerPulse; break;
                }

                // Flags SPEC485 byte 18.
                ReaderInitializationRecord.ProcessEgressLocally = (pageData[byteUsed + 18] & 0x01) == 0x01;
                ReaderInitializationRecord.EgressShuntOnly = (pageData[byteUsed + 18] & 0x02) == 0x02;
                ReaderInitializationRecord.StoreCodeLocally = (pageData[byteUsed + 18] & 0x04) == 0x04;
                ReaderInitializationRecord.KeepStrikeDuringEgress = (pageData[byteUsed + 18] & 0x08) == 0x08;
                ReaderInitializationRecord.AllowPinOnly = (pageData[byteUsed + 18] & 0x10) == 0x10;
                ReaderInitializationRecord.InterlockPassback = (pageData[byteUsed + 18] & 0x20) == 0x20;
                ReaderInitializationRecord.ResetUserInOut = (pageData[byteUsed + 18] & 0x40) == 0x40;
                ReaderInitializationRecord.EnableTimeInAttend = (pageData[byteUsed + 18] & 0x80) == 0x80;

                // Flags byte 19
                if (pcbType != PcbType.Pacom8603) // for 8501, this parameter is not store in the config file
                    ReaderInitializationRecord.SupervisedEgressInput = (pageData[byteUsed + 19] & 0x01) == 0x01;
                byteUsed += 20;

                for (int iPosition = 0; iPosition < 4; iPosition++)                
                {
                    AccessPointCardFormats[iPosition].Mask.NumberOfWiegandBits = pageData[byteUsed + 0 + (iPosition * 8)];

                    // Facility
                    if ((pageData[byteUsed + 1 + (iPosition * 8)] & 0xC0) == 0x00) // not used
                    {
                        AccessPointCardFormats[iPosition].Mask.Facility.UnitType = CardConfigFieldType.NotUsed;
                        AccessPointCardFormats[iPosition].Mask.Facility.Length = 0;
                    }
                    else if ((pageData[byteUsed + 1 + (iPosition * 8)] & 0xC0) == 0x40) // bits
                    {
                        AccessPointCardFormats[iPosition].Mask.Facility.UnitType = CardConfigFieldType.InBits;
                        AccessPointCardFormats[iPosition].Mask.Facility.Length = (byte)(pageData[byteUsed + 1 + (iPosition * 8)] & 0x3F);
                    }
                    else if ((pageData[byteUsed + 1 + (iPosition * 8)] & 0xC0) == 0x80) // nibbles
                    {
                        AccessPointCardFormats[iPosition].Mask.Facility.UnitType = CardConfigFieldType.InBits;
                        AccessPointCardFormats[iPosition].Mask.Facility.Length = (byte)((pageData[byteUsed + 1 + (iPosition * 8)] & 0x3F) * 4);
                    }
                    else if ((pageData[byteUsed + 1 + (iPosition * 8)] & 0xC0) == 0xC0) // bytes
                    {
                        AccessPointCardFormats[iPosition].Mask.Facility.UnitType = CardConfigFieldType.InBits;
                        AccessPointCardFormats[iPosition].Mask.Facility.Length = (byte)((pageData[byteUsed + 1 + (iPosition * 8)] & 0x3F) * 8);
                    }
                    AccessPointCardFormats[iPosition].Mask.Facility.ZeroBasedOffset = (pageData[byteUsed + 2 + (iPosition * 8)] & 0x7F);
                    AccessPointCardFormats[iPosition].Mask.Facility.IncludeInMask = ((pageData[byteUsed + 2 + (iPosition * 8)] & 0x80) == 0x80);

                    // Issue
                    if ((pageData[byteUsed + 3 + (iPosition * 8)] & 0xC0) == 0x00) // not used
                    {
                        AccessPointCardFormats[iPosition].Mask.Issue.UnitType = CardConfigFieldType.NotUsed;
                        AccessPointCardFormats[iPosition].Mask.Issue.Length = 0;
                    }
                    else if ((pageData[byteUsed + 3 + (iPosition * 8)] & 0xC0) == 0x40) // bits
                    {
                        AccessPointCardFormats[iPosition].Mask.Issue.UnitType = CardConfigFieldType.InBits;
                        AccessPointCardFormats[iPosition].Mask.Issue.Length = (byte)(pageData[byteUsed + 3 + (iPosition * 8)] & 0x3F);
                    }
                    else if ((pageData[byteUsed + 3 + (iPosition * 8)] & 0xC0) == 0x80) // nibbles
                    {
                        AccessPointCardFormats[iPosition].Mask.Issue.UnitType = CardConfigFieldType.InBits;
                        AccessPointCardFormats[iPosition].Mask.Issue.Length = (byte)((pageData[byteUsed + 3 + (iPosition * 8)] & 0x3F) * 4);
                    }
                    else if ((pageData[byteUsed + 3 + (iPosition * 8)] & 0xC0) == 0xC0) // bytes
                    {
                        AccessPointCardFormats[iPosition].Mask.Issue.UnitType = CardConfigFieldType.InBits;
                        AccessPointCardFormats[iPosition].Mask.Issue.Length = (byte)((pageData[byteUsed + 3 + (iPosition * 8)] & 0x3F) * 8);
                    }
                    AccessPointCardFormats[iPosition].Mask.Issue.ZeroBasedOffset = (pageData[byteUsed + 4 + (iPosition * 8)] & 0x7F);
                    AccessPointCardFormats[iPosition].Mask.Issue.IncludeInMask = ((pageData[byteUsed + 4 + (iPosition * 8)] & 0x80) == 0x80);

                    // Code
                    if ((pageData[byteUsed + 5 + (iPosition * 8)] & 0xC0) == 0x00) // not used
                    {
                        AccessPointCardFormats[iPosition].Mask.Code.UnitType = CardConfigFieldType.NotUsed;
                        AccessPointCardFormats[iPosition].Mask.Code.Length = 0;
                    }
                    else if ((pageData[byteUsed + 5 + (iPosition * 8)] & 0xC0) == 0x40) // bits
                    {
                        AccessPointCardFormats[iPosition].Mask.Code.UnitType = CardConfigFieldType.InBits;
                        AccessPointCardFormats[iPosition].Mask.Code.Length = (byte)(pageData[byteUsed + 5 + (iPosition * 8)] & 0x3F);
                    }
                    else if ((pageData[byteUsed + 5 + (iPosition * 8)] & 0xC0) == 0x80) // nibbles
                    {
                        AccessPointCardFormats[iPosition].Mask.Code.UnitType = CardConfigFieldType.InBits;
                        AccessPointCardFormats[iPosition].Mask.Code.Length = (byte)((pageData[byteUsed + 5 + (iPosition * 8)] & 0x3F) * 4);
                    }
                    else if ((pageData[byteUsed + 5 + (iPosition * 8)] & 0xC0) == 0xC0) // bytes
                    {
                        AccessPointCardFormats[iPosition].Mask.Code.UnitType = CardConfigFieldType.InBits;
                        AccessPointCardFormats[iPosition].Mask.Code.Length = (byte)((pageData[byteUsed + 5 + (iPosition * 8)] & 0x3F) * 8);
                    }
                    AccessPointCardFormats[iPosition].Mask.Code.ZeroBasedOffset = (pageData[byteUsed + 6 + (iPosition * 8)] & 0x7F);
                    AccessPointCardFormats[iPosition].Mask.Code.IncludeInMask = ((pageData[byteUsed + 6 + (iPosition * 8)] & 0x80) == 0x80);

                    // Designators (convert nibbles to bits)
                    AccessPointCardFormats[iPosition].Mask.Designators.Facility = (pageData[byteUsed + 7 + (iPosition * 8)] & 0x0F) * 4;
                    AccessPointCardFormats[iPosition].Mask.Designators.Issue = ((pageData[byteUsed + 7 + (iPosition * 8)] & 0xF0) >> 4) * 4;
                }
                byteUsed += 32;

                // Parities
                for (int iPosition = 0; iPosition < 4; iPosition++)
                {
                    // Get format index
                    if (pageData[byteUsed + (iPosition * 29)] != iPosition)
                    {
                        throw new ArgumentException("Invalid format index.");
                    }
                    // Mask 1
                    if ((pageData[byteUsed + 1 + (iPosition * 29)] & 0x01) == 0x01)
                    {
                        AccessPointCardFormats[iPosition].Parity.Mask[0].Enabled = true;
                        if ((pageData[byteUsed + 1 + (iPosition * 29)] & 0x10) == 0x10)
                        {
                            AccessPointCardFormats[iPosition].Parity.Mask[0].OddParity = true;
                        }
                        else
                        {
                            AccessPointCardFormats[iPosition].Parity.Mask[0].OddParity = false;
                        }
                        AccessPointCardFormats[iPosition].Parity.Mask[0].Offset = pageData[byteUsed + 26 + (iPosition * 29)];
                        for (int iMask = 0; iMask < 8; iMask++)
                        {
                            AccessPointCardFormats[iPosition].Parity.Mask[0].Mask[iMask] = pageData[byteUsed + 2 + (iPosition * 29) + iMask];
                        }
                    }
                    else
                    {
                        AccessPointCardFormats[iPosition].Parity.Mask[0].Enabled = false;
                    }
                    // Mask 2
                    if ((pageData[byteUsed + 1 + (iPosition * 29)] & 0x02) == 0x02)
                    {
                        AccessPointCardFormats[iPosition].Parity.Mask[1].Enabled = true;
                        if ((pageData[byteUsed + 1 + (iPosition * 29)] & 0x20) == 0x20)
                        {
                            AccessPointCardFormats[iPosition].Parity.Mask[1].OddParity = true;
                        }
                        else
                        {
                            AccessPointCardFormats[iPosition].Parity.Mask[1].OddParity = false;
                        }
                        AccessPointCardFormats[iPosition].Parity.Mask[1].Offset = pageData[byteUsed + 27 + (iPosition * 29)];
                        for (int iMask = 0; iMask < 8; iMask++)
                        {
                            AccessPointCardFormats[iPosition].Parity.Mask[1].Mask[iMask] = pageData[byteUsed + 10 + (iPosition * 29) + iMask];
                        }
                    }
                    else
                    {
                        AccessPointCardFormats[iPosition].Parity.Mask[1].Enabled = false;
                    }
                    // Mask 3
                    if ((pageData[byteUsed + 1 + (iPosition * 29)] & 0x04) == 0x04)
                    {
                        AccessPointCardFormats[iPosition].Parity.Mask[2].Enabled = true;
                        if ((pageData[byteUsed + 1 + (iPosition * 29)] & 0x40) == 0x40)
                        {
                            AccessPointCardFormats[iPosition].Parity.Mask[2].OddParity = true;
                        }
                        else
                        {
                            AccessPointCardFormats[iPosition].Parity.Mask[2].OddParity = false;
                        }
                        AccessPointCardFormats[iPosition].Parity.Mask[2].Offset = pageData[byteUsed + 28 + (iPosition * 29)];
                        for (int iMask = 0; iMask < 8; iMask++)
                        {
                            AccessPointCardFormats[iPosition].Parity.Mask[2].Mask[iMask] = pageData[byteUsed + 18 + (iPosition * 29) + iMask];
                        }
                    }
                    else
                    {
                        AccessPointCardFormats[iPosition].Parity.Mask[2].Enabled = false;
                    }
                    // Get invert and reverse
                    if ((pageData[byteUsed + 1 + (iPosition * 29)] & 0x80) == 0x80)
                    {
                        AccessPointCardFormats[iPosition].Parity.Invert = true;
                    }
                    else
                    {
                        AccessPointCardFormats[iPosition].Parity.Invert = false;
                    }
                    if ((pageData[byteUsed + 1 + (iPosition * 29)] & 0x08) == 0x08)
                    {
                        AccessPointCardFormats[iPosition].Parity.Reverse = true;
                    }
                    else
                    {
                        AccessPointCardFormats[iPosition].Parity.Reverse = false;
                    }
                }
            }
            catch
            {
                Clear();
                return false;
            }
            return true;
        }
                
        public bool Validate()
        {
            if (checkSum == null)
            {
                return false;
            }

            if (checkSum.Length == 0)
            {
                return false;
            }

            return true;
        }
                
        public byte[] InitialPageData
        {
            get 
            {
                return GetInitialPageData();
            }
        }

        private static byte[] GetInitialPageData()
        {
            byte[] initialData = new byte[DataFlashLocations.DataFlashPageSize];
            for (int iData = 0; iData < initialData.Length; iData++)
            {
                initialData[iData] = 0xFF;
            }
            // Reader type
            initialData[4] = (byte)CardReaderType.NoReader;
            // Calculate check sum
            byte[] checkSum = Crc32.ComputeHash(initialData, 4, initialData.Length - 4);
            initialData[0] = checkSum[0];
            initialData[1] = checkSum[1];
            initialData[2] = checkSum[2];
            initialData[3] = checkSum[3];
            return initialData;
        }

        public void Clear()
        {
            checkSum = new byte[0];
            this.AccessPointCardFormats = new AccessPointFormatConfig[4];
            for (int i = 0; i < 4; i++)
            {
                this.AccessPointCardFormats[i] = new AccessPointFormatConfig();
                this.AccessPointCardFormats[i].Mask = null;
                this.AccessPointCardFormats[i].Parity = null;
            }
            ReaderInitializationRecord = new ReaderInitializationConfig();
            ReaderInitializationRecord.ReaderType = CardReaderType.NoReader;
        }
    }
}
