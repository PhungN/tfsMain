﻿using System;
using System.Data.Common;
using System.Text;
using System.Threading;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.SQLCE;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.Common.Configuration;
using System.Collections.Generic;

namespace Pacom.Peripheral.AccessControl
{
    internal class SDCardDegradedMemoryAgent : DegradedMemoryAgentBase
    {
        protected override string agentLogFix { get { return "SD"; } }

        private const int maxActiveCards = 500000;
                
        /// <summary>
        /// Event to signal that the persisting thread is terminated.l
        /// </summary>
        private ManualResetEvent persistThreadTerminatedEvent = new ManualResetEvent(true);

        internal const int MaxRequestInQueue = 2000;

        private DegradedMemoryRequestList requestList = new DegradedMemoryRequestList();
           
        private readonly string cardsTableName;

        private const string readerConfigTableName = "ReaderConfig";

        /// <summary>
        /// Thread used for processing requests
        /// </summary>
        private Thread executeRequestsThread = null;

        /// <summary>
        /// Constructor
        /// </summary>
        public SDCardDegradedMemoryAgent(int doorHardwareId)
            : base(doorHardwareId)
        {
            this.cardsTableName = string.Format("Door{0}Cards", doorHardwareId + 1);
            connection = SqlCeDatabase.Instance.OpenDatabase();
            connection.Open();
            command = connection.CreateCommand();
            if (sqlVerifyTables())
            {
                executeRequestsThread = new Thread(new ThreadStart(this.executeRequestsThreadMethod));
                executeRequestsThread.Name = "Process degraded memory requests [SD]";
                executeRequestsThread.IsBackground = true;
                executeRequestsThread.Priority = ThreadPriority.Lowest;
                executeRequestsThread.Start();                
            }
            else
            { 
                setDegradedMemoryOffline();
            }
        }
               
        #region IDegradedMemoryAgent Members
               
        /// <summary>
        /// Number of active cards held by this degraded memory agent.
        /// </summary>
        public override int CardCount
        {
            get
            {
                return sqlCardCount();
            }
        }

        /// <summary>
        /// Number of maximum active cards held by this degraded memory agent.
        /// </summary>
        public override int MaxActiveCards
        {
            get
            {
                return maxActiveCards;
            }
        }

        /// <summary>
        /// Scan all card records and try to find card data and page. 
        /// </summary>
        /// <param name="cardData">Byte array with card data. Always supplied in 32 byte array.</param>
        /// <param name="cardLength">Number of bits</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator</returns>
        public override bool CardExists(byte[] cardData, int cardLength)
        {
            if (degradedMemoryOffline || LoadCardsFinished == false)
                return false;
            if (sqlCardExists(cardData, cardLength))
                return true;
            return false;
        }

        /// <summary>
        /// This class accepts card data with specified length to be added to the list of cards in degraded mode.
        /// The cardData array is expected to be 32 byte in length. Used bits are defined by cardLength parameter.
        /// </summary>
        /// <param name="cardData">Byte array with card data bits. 32 bytes.</param>
        /// <param name="cardLength">Number of bits used in byte array provided by cardData parameter.</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator</returns>
        public override bool AddCard(byte[] cardData, int cardLength, LegacyCardRecord legacyCardData)
        {
            if (degradedMemoryOffline || LoadCardsFinished == false || requestList.RequestCount > MaxRequestInQueue)
                return false;
            requestList.AddRequest(new DegradedMemoryRequestAdd(cardData, cardLength, legacyCardData));
            return true;
        }

        /// <summary>
        /// Delete card from degraded memory buffer. (With checking legacy formats)
        /// </summary>
        /// <param name="cardData">Legacy card data record.</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator.</returns>
        public override bool DeleteCard(LegacyCardRecord cardData)
        {
            if (degradedMemoryOffline || LoadCardsFinished == false || requestList.RequestCount > MaxRequestInQueue)
                return false;
            requestList.AddRequest(new DegradedMemoryRequestLegacyDelete(cardData));
            return true;
        }

        /// <summary>
        /// Delete card from degraded memory buffer. (Raw card data)
        /// </summary>
        /// <param name="cardData">Raw card data byte array.</param>
        /// <param name="cardLength">Number of bits in the raw card data byte array.</param>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator.</returns>
        public override bool DeleteCard(byte[] cardData, int cardLength)
        {
            if (degradedMemoryOffline || LoadCardsFinished == false || requestList.RequestCount > MaxRequestInQueue)
                return false;
            requestList.AddRequest(new DegradedMemoryRequestDelete(cardData, cardLength));
            return true;
        }

        /// <summary>
        /// Delete all cards from the degraded memory.
        /// </summary>
        /// <returns>Returns DegradedMemoryAgentResultCode enumerator.</returns>
        public override bool DeleteAll()
        {
            if (degradedMemoryOffline || (LoadCardsFinished == false && deleteAllCards == false) || requestList.RequestCount > MaxRequestInQueue)
                return false;
            requestList.AddRequest(new DegradedMemoryRequestDeleteAll());
            return true;
        }

        #endregion

        #region Processing Threads

        protected override void loadCardsAndConfiguration()
        {
            {
                DegradedMemorySettingsRecord dbInitializationReader;
                // Load card initialization record for entry reader.
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Reading initialization of entry reader.");
                });
                dbInitializationReader = new DegradedMemorySettingsRecord();
                if (sqlInitializationSelect(entryReaderId, dbInitializationReader) == false)
                {
                    readerInitializationEntry.Clear();
                    readerInitializationExit.Clear();
                    readerMasterCardsEntry.Clear();
                    readerMasterCardsExit.Clear();
                    return;
                }
                else
                {
                    readerInitializationEntry = dbInitializationReader;
                }
                // Load card initialization record for exit reader.
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Reading initialization of exit reader.");
                });
                dbInitializationReader = new DegradedMemorySettingsRecord();
                if (sqlInitializationSelect(exitReaderId, dbInitializationReader) == false)
                {
                    readerInitializationEntry.Clear();
                    readerInitializationExit.Clear();
                    readerMasterCardsEntry.Clear();
                    readerMasterCardsExit.Clear();
                    return;
                }
                else
                {
                    readerInitializationExit = dbInitializationReader;
                }
            }
            {
                DegradedMemoryMasterCardRecord dbMasterCardRecord;
                // Load master card record for entry reader.
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Reading master card of entry reader.");
                });
                dbMasterCardRecord = new DegradedMemoryMasterCardRecord();
                if (sqlMasterCardsSelect(entryReaderId, dbMasterCardRecord) == false)
                {
                    readerInitializationEntry.Clear();
                    readerInitializationExit.Clear();
                    readerMasterCardsEntry.Clear();
                    readerMasterCardsExit.Clear();
                    return;
                }
                else
                {
                    readerMasterCardsEntry = dbMasterCardRecord;
                }

                // Load master card record for exit reader.
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Reading master card of exit reader.");
                });
                dbMasterCardRecord = new DegradedMemoryMasterCardRecord();
                if (sqlMasterCardsSelect(exitReaderId, dbMasterCardRecord) == false)
                {
                    readerInitializationEntry.Clear();
                    readerInitializationExit.Clear();
                    readerMasterCardsEntry.Clear();
                    readerMasterCardsExit.Clear();
                    return;
                }
                else
                {
                    readerMasterCardsExit = dbMasterCardRecord;
                }
            }

            if (ConfigurationManager.Instance.Doors[doorHardwareId + 1].DegradedMemoryEnabled == false && CardCount > 0)
                sqlDeleteAll();

            Logger.LogCriticalMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Number of loaded cards is {0}.", CardCount);
            });
        }

        /// <summary>
        /// Thread method for processing degraded memory requests.
        /// </summary>
        private void executeRequestsThreadMethod()
        {
            while (Application.Closing == false && disposing == false)
            {
                if (Application.Closing == true || disposing == true)
                    return;
                requestList.Wait();
                if (Application.Closing == true || disposing == true)
                    return;
                if (requestList.IsRequestWaiting == false)
                    continue;
                var request = requestList.GetRequest();
                if (request == null)
                    continue;
                try
                {
                    var requestAdd = request as DegradedMemoryRequestAdd;
                    if (requestAdd != null)
                    {
                        sqlAddCard(requestAdd.CardData, requestAdd.CardLength, requestAdd.LegacyCardData);
                        delayedUpdateCardDatabaseAction.ScheduleUpdate();
                        continue;
                    }
                    var requestDeleteAll = request as DegradedMemoryRequestDeleteAll;
                    if (requestDeleteAll != null)
                    {
                        sqlDeleteAll();
                        delayedUpdateCardDatabaseAction.ScheduleUpdate();
                        continue;
                    }
                    var requestDelete = request as DegradedMemoryRequestDelete;
                    if(requestDelete != null)
                    {
                        sqlDeleteCard(requestDelete.CardData, requestDelete.CardLength);
                        delayedUpdateCardDatabaseAction.ScheduleUpdate();
                        continue;
                    }
                    var legacyDelete = request as DegradedMemoryRequestLegacyDelete;
                    if (legacyDelete != null)
                    {
                        sqlDeleteLegacyCard(legacyDelete.CardData);
                        delayedUpdateCardDatabaseAction.ScheduleUpdate();
                        continue;
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                    {
                        return agentLog("Degraded memory error while processing request. {0}", ex.Message);
                    });
                }
            }
        }

        protected override void updateCardDatabaseCallback()
        {
            if (requestDoorConfiguration == null)
                return;
            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Saving cards and configuration.");
            });
            // Ask for configuration update before saving starts
            DegradedMemoryDoorConfiguration doorConfiguration = null;
            doorConfiguration = requestDoorConfiguration(this.disposing);
            // Doors configuration must be provided. The controller may be still offline. Abort saving process.
            if (doorConfiguration == null)
                return;
            // Copy configuration - Entry
            readerInitializationEntry.ReaderInitializationRecord = doorConfiguration[entryReaderId].InitializationConfig;
            readerInitializationEntry.AccessPointCardFormats = doorConfiguration[entryReaderId].FormatConfig;
            readerMasterCardsEntry.SetMasterCard(doorConfiguration[entryReaderId].MasterCard);
            // Copy configuration - Exit
            readerInitializationExit.ReaderInitializationRecord = doorConfiguration[exitReaderId].InitializationConfig;
            readerInitializationExit.AccessPointCardFormats = doorConfiguration[exitReaderId].FormatConfig;
            readerMasterCardsExit.SetMasterCard(doorConfiguration[exitReaderId].MasterCard);
            // Write configuration to the database
            sqlInitializationAddUpdate(entryReaderId, readerInitializationEntry);
            sqlInitializationAddUpdate(exitReaderId, readerInitializationExit);
            sqlMasterCardsAddUpdate(entryReaderId, readerMasterCardsEntry);
            sqlMasterCardsAddUpdate(exitReaderId, readerMasterCardsExit);

            if (ConfigurationManager.Instance.Doors[doorHardwareId + 1].DegradedMemoryEnabled == false && CardCount > 0)
                sqlDeleteAll();

            Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
            {
                return agentLog("Finished saving data to degraded memory. Total cards on list: {0}", CardCount);
            });
        }

        #endregion

        #region SQL handling

        private DbConnection connection = null;

        private DbCommand command = null;

        private StringBuilder sqlCommand = new StringBuilder();

        private bool sqlVerifyTables()
        {
            try
            {
                lock (connection)
                {
                    if (connection.TableExists(cardsTableName))
                    {
                        command.Parameters.Clear();
                        sqlCommand.Length = 0;
                        sqlCommand.Append("SELECT COUNT(*)");
                        sqlCommand.Append(" FROM INFORMATION_SCHEMA.COLUMNS");
                        sqlCommand.Append(" WHERE TABLE_NAME = N'");
                        sqlCommand.Append(cardsTableName);
                        sqlCommand.Append("'");
                        command.CommandText = sqlCommand.ToString();
                        object count = command.ExecuteScalar();
                        if (count == null || (int)count != 4)
                        {
                            sqlCommand.Length = 0;
                            sqlCommand.Append(@"DROP TABLE ");
                            sqlCommand.Append(cardsTableName);
                            command.CommandText = sqlCommand.ToString();
                            command.ExecuteNonQuery();
                        }
                    }

                    if (!connection.TableExists(cardsTableName))
                    {
                        sqlCommand.Length = 0;
                        sqlCommand.Append(@"CREATE TABLE ");
                        sqlCommand.Append(cardsTableName);
                        sqlCommand.Append(@" (");
                        sqlCommand.Append(@"Card BINARY(32) NOT NULL,");
                        sqlCommand.Append(@"Length TINYINT NOT NULL,");
                        sqlCommand.Append(@"CardholderId BIGINT,"); // The CardholderId is a combination of the Facility, Issue and Code and is stored as a 64 bit int 
                        // as per the 8003 GMS access mode. This can be derived from the raw Card array + the card formats
                        // so doesn't strictly need the be stored but if this isn't present, deleting a card from the degraded
                        // mode would require converting all (potentially 1 millon) records from the database from raw to
                        // facility, issue and code.
                        sqlCommand.Append(@"LastUsed DATETIME DEFAULT GETDATE(),");
                        sqlCommand.Append(@"CONSTRAINT ");
                        sqlCommand.Append(cardsTableName); // The card data and card length must be unique.
                        sqlCommand.Append(@"_PK PRIMARY KEY (Card, Length)");
                        sqlCommand.Append(@")");
                        command.CommandText = sqlCommand.ToString();
                        command.ExecuteNonQuery();
                    }

                    if (!connection.TableExists(readerConfigTableName))
                    {
                        sqlCommand.Length = 0;
                        sqlCommand.Append(@"CREATE TABLE ");
                        sqlCommand.Append(readerConfigTableName);
                        sqlCommand.Append(@" (");
                        sqlCommand.Append(@"DoorId TINYINT NOT NULL,");
                        sqlCommand.Append(@"ReaderId TINYINT NOT NULL,");
                        sqlCommand.Append(@"Type TINYINT NOT NULL,");
                        sqlCommand.Append(@"Data VARBINARY(1024)");
                        sqlCommand.Append(@")");
                        command.CommandText = sqlCommand.ToString();
                        command.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Unable to verify storage for degraded memory. {0}", ex.Message);
                });
                return false;
            }
        }

        private int sqlCardCount()
        {
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    sqlCommand.Length = 0;
                    sqlCommand.Append("SELECT CARDINALITY");
                    sqlCommand.Append(" FROM INFORMATION_SCHEMA.INDEXES");
                    sqlCommand.Append(" WHERE PRIMARY_KEY = 1 AND TABLE_NAME = N'");
                    sqlCommand.Append(cardsTableName);
                    sqlCommand.Append("'");
                    command.CommandText = sqlCommand.ToString();
                    object count = command.ExecuteScalar();
                    if (count == null)
                        return 0;
                    else
                        return (int)(Int64)count;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while counting no. of cards {0}", ex.Message);
                });
            }
            return 0;
        }
               
        private bool sqlCardExists(byte[] cardData, int cardLength)
        {
            bool result = false;
            // Card data must be provided. The length parameter must be positive.
            if (cardData == null || cardData.Length <= 0 || cardLength <= 0)
                return result;
            // Is card data provided.
            if (cardData.Length <= 0 || cardLength > 256)
                return result;
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    sqlCommand.Length = 0;
                    sqlCommand.Append("SELECT TOP(1) 1");
                    sqlCommand.Append(" FROM ");
                    sqlCommand.Append(cardsTableName);
                    sqlCommand.Append(" WHERE Length = @Length AND Card = @Card");
                    command.CommandText = sqlCommand.ToString();
                    command.AddParameterWithValue("Length", cardLength);
                    command.AddParameterWithValue("Card", cardData);
                    object sqlResult = command.ExecuteScalar();
                    if (sqlResult != null && ((int)sqlResult) == 1)
                        result = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while checking for card. {0}", ex.Message);
                });
            }
            return result;
        }

        private bool sqlAddCard(byte[] cardData, int cardLength, LegacyCardRecord legacyCardData)
        {
            bool result = false;
            try
            {
                long cardholderId = 0;
                if (legacyCardData != null)
                    cardholderId = legacyCardData.AsLong();

                lock (connection)
                {
                    if (sqlCardExists(cardData, cardLength))
                    {
                        command.Parameters.Clear();
                        sqlCommand.Length = 0;
                        sqlCommand.Append("UPDATE ");
                        sqlCommand.Append(cardsTableName);
                        sqlCommand.Append(" SET LastUsed=@LastUsed ");
                        if (legacyCardData != null)
                        {
                            sqlCommand.Append(", CardholderId=@CardholderId ");
                            command.AddParameterWithValue("CardholderId", cardholderId);
                        }
                        sqlCommand.Append(" WHERE Length=@Length AND Card=@Card ");
                        command.AddParameterWithValue("LastUsed", DateTime.UtcNow);
                        command.AddParameterWithValue("Card", cardData);
                        command.AddParameterWithValue("Length", cardLength);
                        command.CommandText = sqlCommand.ToString();
                        command.ExecuteNonQuery();
                        result = true;
                    }
                    else
                    {
                        command.Parameters.Clear();
                        sqlCommand.Length = 0;
                        sqlCommand.Append("INSERT INTO ");
                        sqlCommand.Append(cardsTableName);
                        if (legacyCardData == null)
                        {
                            sqlCommand.Append(" (Card,Length,LastUsed)");
                            sqlCommand.Append(" VALUES(@Card,@Length,@LastUsed)");
                        }
                        else
                        {
                            sqlCommand.Append(" (Card,Length,CardholderId,LastUsed)");
                            sqlCommand.Append(" VALUES(@Card,@Length,@CardholderId,@LastUsed)");
                            command.AddParameterWithValue("CardholderId", cardholderId);
                        }
                        command.AddParameterWithValue("Card", cardData);
                        command.AddParameterWithValue("Length", cardLength);
                        command.AddParameterWithValue("LastUsed", DateTime.UtcNow);
                        command.CommandText = sqlCommand.ToString();
                        command.ExecuteNonQuery();
                        result = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while adding a card. {0}", ex.Message);
                });                
            }
            return result;
        }

        private bool sqlDeleteCard(byte[] cardData, int cardLength)
        {
            bool result = false;
            try
            {
                List<int> possibleCardLengths = new List<int>();
                if (cardLength == 0)
                {
                    int smallestBitCount = getSmallestBitCount(cardData);
                    Array.Reverse(cardData);

                    lock (connection)
                    {
                        command.Parameters.Clear();
                        sqlCommand.Length = 0;
                        sqlCommand.Append("SELECT DISTINCT LENGTH FROM ");
                        sqlCommand.Append(cardsTableName);
                        command.CommandText = sqlCommand.ToString();
                        DbDataReader sqlReader = command.ExecuteReader();
                        while (sqlReader.Read())
                        {
                            try
                            {
                                int databaseCardLength = (int)(byte)sqlReader[0];
                                if (databaseCardLength >= smallestBitCount && databaseCardLength <= 64)
                                    possibleCardLengths.Add(databaseCardLength);
                            }
                            catch
                            {
                            }
                        }
                    }
                }
                else
                {
                    possibleCardLengths.Add(cardLength);
                }

                foreach (int possibleCardLength in possibleCardLengths)
                {
                    lock (connection)
                    {
                        byte[] nativeCardData = null;
                        if (cardLength == 0)
                        {
                            if (translateLegacyCardNumberToNativeCardNumber(cardData, possibleCardLength, out nativeCardData))
                            {
                            }
                        }
                        else
                        {
                            nativeCardData = cardData;
                        }
                        command.Parameters.Clear();
                        sqlCommand.Length = 0;
                        sqlCommand.Append("DELETE FROM ");
                        sqlCommand.Append(cardsTableName);
                        sqlCommand.Append(" WHERE Card = @Card AND Length = @Length");
                        command.AddParameterWithValue("Card", nativeCardData);
                        command.AddParameterWithValue("Length", possibleCardLength);
                        command.CommandText = sqlCommand.ToString();
                        command.ExecuteNonQuery();
                        result = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while deleting card. {0}", ex.Message);
                });                
            }
            return result;
        }

        private bool sqlDeleteLegacyCard(LegacyCardRecord legacyCardData)
        {
            long cardholderId = 0;
            if (legacyCardData == null)
                return false;
            
            cardholderId = legacyCardData.AsLong();

            bool result = false;
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    sqlCommand.Length = 0;
                    sqlCommand.Append("DELETE FROM ");
                    sqlCommand.Append(cardsTableName);
                    sqlCommand.Append(" WHERE CardholderId = @CardholderId");
                    command.AddParameterWithValue("CardholderId", cardholderId);
                    command.CommandText = sqlCommand.ToString();
                    command.ExecuteNonQuery();
                    result = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while deleting card. {0}", ex.Message);
                });
            }
            return result;
        }

        public bool sqlDeleteAll()
        {
            bool result = false;
            try
            {
                lock (connection)
                {
                    // Cards
                    command.Parameters.Clear();
                    sqlCommand.Length = 0;
                    sqlCommand.Append("DELETE FROM ");
                    sqlCommand.Append(cardsTableName);
                    command.CommandText = sqlCommand.ToString();
                    command.ExecuteNonQuery();
                    // Configuration
                    sqlCommand.Length = 0;
                    sqlCommand.Append("DELETE FROM ");
                    sqlCommand.Append(readerConfigTableName);
                    command.CommandText = sqlCommand.ToString();
                    command.ExecuteNonQuery();
                }
                Logger.LogDebugMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("All cards and configuration are deleted.");
                });
                result = true;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while deleting all cards and configuration. {0}", ex.Message);
                });
            }
            return result;
        }

        private const int sqlReaderInitializationRecord = 0;
        private const int sqlReaderMasterCardsRecord = 1;

        private bool sqlInitializationExists(int readerIndex)
        {
            bool result = false;
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    sqlCommand.Length = 0;
                    sqlCommand.Append("SELECT TOP(1) 1");
                    sqlCommand.Append(" FROM ");
                    sqlCommand.Append(readerConfigTableName);
                    sqlCommand.Append(" WHERE DoorId=@DoorId AND ReaderId=@ReaderId AND Type=@Type");
                    command.AddParameterWithValue("DoorId", doorHardwareId);
                    command.AddParameterWithValue("ReaderId", readerIndex);
                    command.AddParameterWithValue("Type", sqlReaderInitializationRecord);
                    command.CommandText = sqlCommand.ToString();
                    object sqlResult = command.ExecuteScalar();
                    if (sqlResult != null && ((int)sqlResult) == 1)
                        result = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while checking reader initialization record for {0} reader. {1}", readerIndex == 0 ? "entry" : "exit", ex.Message);
                });
            }
            return result;
        }

        private bool sqlInitializationSelect(int readerIndex, IDegradedMemoryRecord record)
        {
            try
            {
                object sqlResult;
                lock (connection)
                {
                    command.Parameters.Clear();
                    sqlCommand.Length = 0;
                    sqlCommand.Append("SELECT Data");
                    sqlCommand.Append(" FROM ");
                    sqlCommand.Append(readerConfigTableName);
                    sqlCommand.Append(" WHERE DoorId=@DoorId AND ReaderId=@ReaderId AND Type=@Type");
                    command.AddParameterWithValue("DoorId", doorHardwareId);
                    command.AddParameterWithValue("ReaderId", readerIndex);
                    command.AddParameterWithValue("Type", sqlReaderInitializationRecord);
                    command.CommandText = sqlCommand.ToString();
                    sqlResult = command.ExecuteScalar();
                }
                if (sqlResult != null)
                {
                    byte[] data = (byte[])sqlResult;
                    return record.Deserialize(data, Hal.Pcb.PcbType);
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while selecting reader initialization record for {0} reader. {1}", readerIndex == 0 ? "entry" : "exit", ex.Message);
                });
            }
            return false;
        }

        private bool sqlInitializationAddUpdate(int readerIndex, DegradedMemorySettingsRecord readerInitialization)
        {
            bool result = false;
            if (readerInitialization == null || (!(readerIndex == entryReaderId || readerIndex == exitReaderId)))
                return result;
            try
            {
                lock (connection)
                {
                    byte[] data = readerInitialization.Serialize();
                    if (sqlInitializationExists(readerIndex))
                    {
                        command.Parameters.Clear();
                        sqlCommand.Length = 0;
                        sqlCommand.Append("UPDATE ");
                        sqlCommand.Append(readerConfigTableName);
                        sqlCommand.Append(" SET Data=@Data");
                        sqlCommand.Append(" WHERE DoorId=@DoorId AND ReaderId=@ReaderId AND Type=@Type");
                        command.AddParameterWithValue("DoorId", doorHardwareId);
                        command.AddParameterWithValue("ReaderId", readerIndex);
                        command.AddParameterWithValue("Type", sqlReaderInitializationRecord);
                        command.AddParameterWithValue("Data", data);
                        command.CommandText = sqlCommand.ToString();
                        command.ExecuteNonQuery();
                        result = true;
                    }
                    else
                    {
                        command.Parameters.Clear();
                        sqlCommand.Length = 0;
                        sqlCommand.Append("INSERT INTO ");
                        sqlCommand.Append(readerConfigTableName);
                        sqlCommand.Append(" (DoorId,ReaderId,Type,Data)");
                        sqlCommand.Append(" VALUES(@DoorId,@ReaderId,@Type,@Data)");
                        command.AddParameterWithValue("DoorId", doorHardwareId);
                        command.AddParameterWithValue("ReaderId", readerIndex);
                        command.AddParameterWithValue("Type", sqlReaderInitializationRecord);
                        command.AddParameterWithValue("Data", data);
                        command.CommandText = sqlCommand.ToString();
                        command.ExecuteNonQuery();
                        result = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while adding initialization for {0} reader. {1}", readerIndex == 0 ? "entry" : "exit", ex.Message);
                });
            }
            return result;
        }

        private bool sqlInitializationDelete(int readerIndex)
        {
            bool result = false;
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    sqlCommand.Length = 0;
                    sqlCommand.Append("DELETE FROM ");
                    sqlCommand.Append(readerConfigTableName);
                    sqlCommand.Append(" WHERE DoorId=@DoorId AND ReaderId=@ReaderId AND Type=@Type");
                    command.AddParameterWithValue("DoorId", doorHardwareId);
                    command.AddParameterWithValue("ReaderId", readerIndex);
                    command.AddParameterWithValue("Type", sqlReaderInitializationRecord);
                    command.CommandText = sqlCommand.ToString();
                    command.ExecuteNonQuery();
                }
                result = true;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while deleting initialization for {0} reader. {1}", readerIndex == 0 ? "entry" : "exit", ex.Message);
                });
            }
            return result;
        }

        private bool sqlMasterCardsExists(int readerIndex)
        {
            bool result = false;
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    sqlCommand.Length = 0;
                    sqlCommand.Append("SELECT TOP(1) 1");
                    sqlCommand.Append(" FROM ");
                    sqlCommand.Append(readerConfigTableName);
                    sqlCommand.Append(" WHERE DoorId=@DoorId AND ReaderId=@ReaderId AND Type=@Type");
                    command.AddParameterWithValue("DoorId", doorHardwareId);
                    command.AddParameterWithValue("ReaderId", readerIndex);
                    command.AddParameterWithValue("Type", sqlReaderMasterCardsRecord);
                    command.CommandText = sqlCommand.ToString();
                    object sqlResult = command.ExecuteScalar();
                    if (sqlResult != null && ((int)sqlResult) == 1)
                        result = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while checking reader master card record for {0} reader. {1}", readerIndex == 0 ? "entry" : "exit", ex.Message);
                });
            }
            return result;
        }

        private bool sqlMasterCardsSelect(int readerIndex, IDegradedMemoryRecord record)
        {
            try
            {
                object sqlResult;
                lock (connection)
                {
                    command.Parameters.Clear();
                    sqlCommand.Length = 0;
                    sqlCommand.Append("SELECT Data");
                    sqlCommand.Append(" FROM ");
                    sqlCommand.Append(readerConfigTableName);
                    sqlCommand.Append(" WHERE DoorId=@DoorId AND ReaderId=@ReaderId AND Type=@Type");
                    command.AddParameterWithValue("DoorId", doorHardwareId);
                    command.AddParameterWithValue("ReaderId", readerIndex);
                    command.AddParameterWithValue("Type", sqlReaderMasterCardsRecord);
                    command.CommandText = sqlCommand.ToString();
                    sqlResult = command.ExecuteScalar();
                }
                if (sqlResult != null)
                {
                    byte[] data = (byte[])sqlResult;
                    return record.Deserialize(data, Hal.Pcb.PcbType);
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while selecting master card record for {0} reader. {1}", readerIndex == 0 ? "entry" : "exit", ex.Message);
                });
            }
            return false;
        }

        private bool sqlMasterCardsAddUpdate(int readerIndex, DegradedMemoryMasterCardRecord readerMasterCard)
        {
            bool result = false;
            if (readerMasterCard == null || (!(readerIndex == entryReaderId || readerIndex == exitReaderId)))
                return result;
            try
            {
                lock (connection)
                {
                    byte[] data = readerMasterCard.Serialize();
                    if (sqlMasterCardsExists(readerIndex))
                    {
                        command.Parameters.Clear();
                        sqlCommand.Length = 0;
                        sqlCommand.Append("UPDATE ");
                        sqlCommand.Append(readerConfigTableName);
                        sqlCommand.Append(" SET Data=@Data");
                        sqlCommand.Append(" WHERE DoorId=@DoorId AND ReaderId=@ReaderId AND Type=@Type");
                        command.AddParameterWithValue("DoorId", doorHardwareId);
                        command.AddParameterWithValue("ReaderId", readerIndex);
                        command.AddParameterWithValue("Type", sqlReaderMasterCardsRecord);
                        command.AddParameterWithValue("Data", data);
                        command.CommandText = sqlCommand.ToString();
                        command.ExecuteNonQuery();
                        result = true;
                    }
                    else
                    {
                        command.Parameters.Clear();
                        sqlCommand.Length = 0;
                        sqlCommand.Append("INSERT INTO ");
                        sqlCommand.Append(readerConfigTableName);
                        sqlCommand.Append(" (DoorId,ReaderId,Type,Data)");
                        sqlCommand.Append(" VALUES(@DoorId,@ReaderId,@Type,@Data)");
                        command.AddParameterWithValue("DoorId", doorHardwareId);
                        command.AddParameterWithValue("ReaderId", readerIndex);
                        command.AddParameterWithValue("Type", sqlReaderMasterCardsRecord);
                        command.AddParameterWithValue("Data", data);
                        command.CommandText = sqlCommand.ToString();
                        command.ExecuteNonQuery();
                        result = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while adding master card for {0} reader. {1}", readerIndex == 0 ? "entry" : "exit", ex.Message);
                });
            }
            return result;
        }

        private bool sqlMasterCardsDelete(int readerIndex)
        {
            bool result = false;
            try
            {
                lock (connection)
                {
                    command.Parameters.Clear();
                    sqlCommand.Length = 0;
                    sqlCommand.Append("DELETE FROM ");
                    sqlCommand.Append(readerConfigTableName);
                    sqlCommand.Append(" WHERE DoorId=@DoorId AND ReaderId = @ReaderId AND Type = @Type");
                    command.AddParameterWithValue("DoorId", doorHardwareId);
                    command.AddParameterWithValue("ReaderId", readerIndex);
                    command.AddParameterWithValue("Type", sqlReaderMasterCardsRecord);
                    command.CommandText = sqlCommand.ToString();
                    command.ExecuteNonQuery();
                }
                result = true;
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.AccessControlManager, () =>
                {
                    return agentLog("Error while deleting master card for {0} reader. {1}", readerIndex == 0 ? "entry" : "exit", ex.Message);
                });
            }
            return result;
        }

        #endregion

        protected override void Terminating()
        {
            // Stop waiting for requests
            requestList.Terminate();          
            // Dispose request list
            requestList.Dispose();
            requestList = null;
            // Dispose sql database
            command.Dispose();
            connection.Close();
            connection.Dispose();
            connection = null;            
        }               
    }
}
