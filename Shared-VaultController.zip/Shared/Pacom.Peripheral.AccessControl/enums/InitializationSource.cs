﻿
namespace Pacom.Peripheral.AccessControl
{
    internal enum InitializationSource
    {
        Controller,
        DegradedMemory
    }
}
