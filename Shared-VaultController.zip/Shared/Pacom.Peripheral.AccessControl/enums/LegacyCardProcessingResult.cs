﻿
namespace Pacom.Peripheral.AccessControl
{
    internal enum LegacyCardProcessingResult
    {
        NotFound,
        CardIssueFacilityFound,
        KeypadFound,
        RawFormat
    }
}
