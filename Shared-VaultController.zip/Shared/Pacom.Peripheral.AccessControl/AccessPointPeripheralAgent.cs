﻿using System;
using System.Threading;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.AccessControl
{
    internal class AccessPointPeripheralAgent : IDisposable
    {
        public AccessPointPeripheralAgent()
        {
            // Create peripheral timers
            triggerBuzzerTimer = new Timer(triggerBuzzerState, null, Timeout.Infinite, Timeout.Infinite);
            triggerBuzzerPulsingTimer = new Timer(triggerPulsingBuzzerState, null, Timeout.Infinite, Timeout.Infinite); ;
            triggerRedLedTimer = new Timer(triggerRedLedState, null, Timeout.Infinite, Timeout.Infinite);
            triggerRedLedFlashingTimer = new Timer(triggerFlashingRedLedState, null, Timeout.Infinite, Timeout.Infinite);
            triggerGreenLedTimer = new Timer(triggerGreenLedState, null, Timeout.Infinite, Timeout.Infinite);
            triggerGreenLedFlashingTimer = new Timer(triggerFlashingGreenLedState, null, Timeout.Infinite, Timeout.Infinite);
            triggerStrikeTimer = new Timer(triggerStrikeState, null, Timeout.Infinite, Timeout.Infinite);
            triggerSpareOutputTimer = new Timer(triggerSpareOutputState, null, Timeout.Infinite, Timeout.Infinite);
            // Set default states
            setBuzzer(normalBuzzer, 0, 0);
            setRedLed(normalRedLed, 0, 0);
            setGreenLed(normalGreenLed, 0, 0);
        }

        private Timer triggerBuzzerTimer = null;
        private Timer triggerBuzzerPulsingTimer = null;
        private Timer triggerRedLedTimer = null;
        private Timer triggerRedLedFlashingTimer = null;
        private Timer triggerGreenLedTimer = null;
        private Timer triggerGreenLedFlashingTimer = null;
        private Timer triggerStrikeTimer = null;
        private Timer triggerSpareOutputTimer = null;

        private bool strikeWithoutTimer = false;
        private object sync = new object();

        public event EventHandler<BuzzerStateChangeArgs> OnBuzzerStateChange;
        public event EventHandler<LedStateChangeArgs> OnRedLedStateChange;
        public event EventHandler<LedStateChangeArgs> OnGreenLedStateChange;
        public event EventHandler<OutputStateChangeArgs> OnStrikeStateChange;
        public event EventHandler<OutputStateChangeArgs> OnSpareOutputStateChange;
        public event EventHandler<DisplaySecurityLevelChangeEventArgs> DisplaySecurityLevelStateChange;

        #region Normal State Section

        private CardReaderBuzzerType normalBuzzer = CardReaderBuzzerType.BuzzerOff;
        private int normalBuzzerDuration = 0;
        private int normalBuzzerFrequency = 0;

        public void SetNormalBuzzer(CardReaderBuzzerType type, int duration, int frequency)
        {
            if (this.disposing)
                return;

            lock (sync)
            {
                if (type == CardReaderBuzzerType.BuzzerPulse && frequency == 0)
                {
                    normalBuzzer = CardReaderBuzzerType.BuzzerOff;
                    normalBuzzerDuration = 0;
                    normalBuzzerFrequency = 0;
                }
                else
                {
                    normalBuzzer = type;
                    normalBuzzerDuration = duration;
                    normalBuzzerFrequency = frequency;
                }

                // Copy normal settings over current state
                if (duration == 0)
                    triggerBuzzerState(null);
            }
        }

        private CardReaderLedType normalRedLed = CardReaderLedType.LedOff;
        private int normalRedLedDuration = 0;
        private int normalRedLedFrequency = 0;

        /// <summary>
        /// Set normal Red led. 
        /// </summary>
        /// <param name="type">Type of set.</param>
        /// <param name="duration">Duration</param>
        /// <param name="frequency"></param>
        public void SetNormalRedLed(CardReaderLedType type, int duration, int frequency)
        {
            if (this.disposing)
                return;

            lock (sync)
            {
                normalRedLed = type;
                normalRedLedDuration = duration;
                normalRedLedFrequency = frequency;

                if (type == CardReaderLedType.LedFlashing && frequency == 0)
                {
                    normalRedLed = CardReaderLedType.LedOff;
                    normalRedLedDuration = 0;
                    normalRedLedFrequency = 0;
                }
                else
                {
                    normalRedLed = type;
                    normalRedLedDuration = duration;
                    normalRedLedFrequency = frequency;
                }

                // Copy normal settings over current state
                if (duration == 0)
                    triggerRedLedState(null);
            }
        }

        private CardReaderLedType normalGreenLed = CardReaderLedType.LedOff;
        private int normalGreenLedDuration = 0;
        private int normalGreenLedFrequency = 0;

        public void SetNormalGreenLed(CardReaderLedType type, int duration, int frequency)
        {
            if (this.disposing)
                return;

            lock (sync)
            {
                if (type == CardReaderLedType.LedFlashing && frequency == 0)
                {
                    normalGreenLed = CardReaderLedType.LedOff;
                    normalGreenLedDuration = 0;
                    normalGreenLedFrequency = 0;
                }
                else
                {
                    normalGreenLed = type;
                    normalGreenLedDuration = duration;
                    normalGreenLedFrequency = frequency;
                }

                // Copy normal settings over current state
                if (duration == 0)
                    triggerGreenLedState(null);
            }
        }

        #endregion

        private bool currentBuzzerPulsingHigh = false;
        private CardReaderBuzzerType currentBuzzer = CardReaderBuzzerType.BuzzerOff;
        private int currentBuzzerDuration = 0;
        private int currentBuzzerFrequency = 0;

        private bool currentRedLedFlashingHigh = false;
        private CardReaderLedType currentRedLed = CardReaderLedType.LedOff;
        private int currentRedLedDuration = 0;
        private int currentRedLedFrequency = 0;

        private bool currentGreenLedFlashingHigh = false;
        private CardReaderLedType currentGreenLed = CardReaderLedType.LedOff;
        private int currentGreenLedDuration = 0;
        private int currentGreenLedFrequency = 0;

        #region Current Buzzer State Section

        /// <summary>
        /// Set current buzzer.
        /// </summary>
        /// <param name="type">Requested state</param>
        /// <param name="duration">Duration of the state</param>
        /// <param name="frequency">Frequency of the state</param>
        public void SetCurrentBuzzer(CardReaderBuzzerType type, int duration, int frequency)
        {
            if (this.disposing || (duration <= 0))
                return;
            setBuzzer(type, duration, frequency);
        }

        /// <summary>
        /// Set current buzzer on permanently.
        /// </summary>
        /// <param name="type"></param>
        public void SetCurrentBuzzerOn()
        {
            if (this.disposing)
                return;
            setBuzzer(CardReaderBuzzerType.BuzzerOn, Timeout.Infinite, 0);
        }

        #endregion

        #region Current Red LED State Section

        /// <summary>
        /// Set current red led.
        /// </summary>
        /// <param name="type">Requested state</param>
        /// <param name="duration">Duration of the state</param>
        /// <param name="frequency">Frequency of the state</param>
        public void SetCurrentRedLed(CardReaderLedType type, int duration, int frequency)
        {
            if (this.disposing || duration <= 0)
                return;
            setRedLed(type, duration, frequency);
        }

        /// <summary>
        /// Set current red led on permanently.
        /// </summary>
        public void SetCurrentRedLedOn()
        {
            if (this.disposing)
                return;
            setRedLed(CardReaderLedType.LedOn, Timeout.Infinite, 0);
        }

        #endregion

        #region Current Green LED State Section

        /// <summary>
        /// Set current green led.
        /// </summary>
        /// <param name="type"></param>
        /// <param name="duration"></param>
        /// <param name="frequency"></param>
        public void SetCurrentGreenLed(CardReaderLedType type, int duration, int frequency)
        {
            if (this.disposing || duration <= 0)
                return;
            setGreenLed(type, duration, frequency);
        }

        /// <summary>
        /// Set current green led on permanently
        /// </summary>
        public void SetCurrentGreenLedOn()
        {
            if (this.disposing)
                return;
            setGreenLed(CardReaderLedType.LedOn, Timeout.Infinite, 0);
        }

        #endregion

        #region Display Security Level  Section
        public void SetDisplaySecurityLevel(int readerId, CardReaderDisplaySecurityLevelConfig config)
        {
            if (this.disposing)
                return;
            if (DisplaySecurityLevelStateChange != null)
            {
                DisplaySecurityLevelStateChange(this, new DisplaySecurityLevelChangeEventArgs(readerId, config));
            }
        }

        #endregion

        #region Strike Secion

        /// <summary>
        /// Set strike without timer.
        /// </summary>
        public void SetStrike()
        {
            if (this.disposing)
                return;

            lock (sync)
            {
                triggerStrikeTimer.Change(Timeout.Infinite, Timeout.Infinite);
                strikeWithoutTimer = true;
                try
                {
                    if (OnStrikeStateChange != null)
                        OnStrikeStateChange(this, new OutputStateChangeArgs(true));
                }
                catch
                {
                }
            }
        }

        /// <summary>
        /// Set strike with timer.
        /// </summary>
        /// <param name="duration"></param>
        public void SetStrike(int duration)
        {
            if (this.disposing)
                return;

            lock (sync)
            {
                triggerStrikeTimer.Change(Timeout.Infinite, Timeout.Infinite);
                strikeWithoutTimer = false;
                if (duration == 0)
                {
                    ClearStrike();
                }
                else
                {
                    try
                    {
                        if (OnStrikeStateChange != null)
                            OnStrikeStateChange(this, new OutputStateChangeArgs(true));
                    }
                    catch
                    {
                    }
                    triggerStrikeTimer.Change(duration, Timeout.Infinite);
                }
            }
        }

        /// <summary>
        /// Clear strike.
        /// </summary>
        public void ClearStrike()
        {
            if (this.disposing)
                return;

            lock (sync)
            {
                triggerStrikeTimer.Change(Timeout.Infinite, Timeout.Infinite);
                strikeWithoutTimer = false;
                if (OnStrikeStateChange != null)
                    OnStrikeStateChange(this, new OutputStateChangeArgs(false));
            }
        }

        private void triggerStrikeState(object state)
        {
            ClearStrike();
        }

        /// <summary>
        /// Indicates if strike was enabled without timer.
        /// </summary>
        public bool StrikeWithoutTimer
        {
            get
            {
                return strikeWithoutTimer;
            }
        }

        #endregion

        #region Spare Output Secion

        /// <summary>
        /// Set spare output
        /// </summary>
        public void SetSpareOutput()
        {
            if (this.disposing)
                return;

            lock (sync)
            {
                triggerSpareOutputTimer.Change(Timeout.Infinite, Timeout.Infinite);
                if (OnSpareOutputStateChange != null)
                {
                    try
                    {
                        OnSpareOutputStateChange(this, new OutputStateChangeArgs(true));
                    }
                    catch
                    {
                    }
                }
            }
        }

        /// <summary>
        /// Set spare output with timer
        /// </summary>
        /// <param name="duration">Timer duration</param>
        public void SetSpareOutput(int duration)
        {
            if (this.disposing)
                return;

            lock (sync)
            {
                triggerSpareOutputTimer.Change(Timeout.Infinite, Timeout.Infinite);
                if (duration == 0)
                {
                    ClearSpareOutput();
                }
                else
                {
                    if (OnSpareOutputStateChange != null)
                    {
                        try
                        {
                            OnSpareOutputStateChange(this, new OutputStateChangeArgs(true));
                        }
                        catch
                        {
                        }
                    }
                    triggerSpareOutputTimer.Change(duration, Timeout.Infinite);
                }
            }
        }

        /// <summary>
        /// Clear spare output.
        /// </summary>
        public void ClearSpareOutput()
        {
            if (this.disposing)
                return;

            lock (sync)
            {
                triggerSpareOutputTimer.Change(Timeout.Infinite, Timeout.Infinite);
                if (OnSpareOutputStateChange != null)
                {
                    try
                    {
                        OnSpareOutputStateChange(this, new OutputStateChangeArgs(false));
                    }
                    catch
                    {
                    }
                }
            }
        }

        private void triggerSpareOutputState(object state)
        {
            ClearSpareOutput();
        }

        #endregion

        #region State Change Timers

        private void triggerBuzzerState(object state)
        {
            lock (sync)
            {
                triggerBuzzerTimer.Change(Timeout.Infinite, Timeout.Infinite);
                triggerBuzzerPulsingTimer.Change(Timeout.Infinite, Timeout.Infinite);

                // Current state finished, restore to normal
                currentBuzzer = normalBuzzer;
                currentBuzzerDuration = normalBuzzerDuration;
                currentBuzzerFrequency = normalBuzzerFrequency;

                // For pulsing restore pulsing and state change timer 
                if (currentBuzzer == CardReaderBuzzerType.BuzzerPulse)
                {
                    // But only if pulsing frequency is provided
                    if (currentBuzzerFrequency > 0)
                    {
                        // Startup state change timer if duration is provided
                        if (currentBuzzerDuration > 0)
                            triggerBuzzerTimer.Change(currentBuzzerDuration, Timeout.Infinite);
                        triggerBuzzerPulsingTimer.Change(currentBuzzerFrequency, Timeout.Infinite);
                    }
                    else
                    {
                        currentBuzzer = CardReaderBuzzerType.BuzzerOff;
                    }
                }
                else
                {
                    if (OnBuzzerStateChange != null)
                    {
                        try
                        {
                            OnBuzzerStateChange(this, new BuzzerStateChangeArgs(currentBuzzer));
                        }
                        catch
                        {
                        }
                    }
                }
            }
        }

        private void triggerRedLedState(object state)
        {
            lock (sync)
            {
                triggerRedLedTimer.Change(Timeout.Infinite, Timeout.Infinite);
                triggerRedLedFlashingTimer.Change(Timeout.Infinite, Timeout.Infinite);

                // Current state finished, restore to normal
                currentRedLed = normalRedLed;
                currentRedLedDuration = normalRedLedDuration;
                currentRedLedFrequency = normalRedLedFrequency;

                // For pulsing restore pulsing and state change timer 
                if (currentRedLed == CardReaderLedType.LedFlashing)
                {
                    // But only if pulsing frequency is provided
                    if (currentRedLedFrequency > 0)
                    {
                        // Startup state change timer if duration is provided
                        if (currentRedLedDuration > 0)
                        {
                            triggerRedLedTimer.Change(currentRedLedDuration, Timeout.Infinite);
                        }
                        triggerRedLedFlashingTimer.Change(currentRedLedFrequency, Timeout.Infinite);
                    }
                    else
                    {
                        currentRedLed = CardReaderLedType.LedOff;
                    }
                }
                else
                {
                    if (OnRedLedStateChange != null)
                    {
                        try
                        {
                            OnRedLedStateChange(this, new LedStateChangeArgs(currentRedLed));
                        }
                        catch
                        {
                        }
                    }
                }
            }
        }

        private void triggerGreenLedState(object state)
        {
            lock (sync)
            {
                triggerGreenLedTimer.Change(Timeout.Infinite, Timeout.Infinite);
                triggerGreenLedFlashingTimer.Change(Timeout.Infinite, Timeout.Infinite);

                // Current state finished, restore to normal
                currentGreenLed = normalGreenLed;
                currentGreenLedDuration = normalGreenLedDuration;
                currentGreenLedFrequency = normalGreenLedFrequency;

                // For pulsing restore pulsing and state change timer 
                if (currentGreenLed == CardReaderLedType.LedFlashing)
                {
                    // But only if pulsing frequency is provided
                    if (currentGreenLedFrequency > 0)
                    {
                        // Startup state change timer if duration is provided
                        if (currentGreenLedDuration > 0)
                            triggerGreenLedTimer.Change(currentGreenLedDuration, Timeout.Infinite);
                        triggerGreenLedFlashingTimer.Change(currentGreenLedFrequency, Timeout.Infinite);
                        //currentGreenLed = CardReaderLedType.LedOn;
                    }
                    else
                    {
                        currentGreenLed = CardReaderLedType.LedOff;
                    }
                }
                else
                {
                    if (OnGreenLedStateChange != null)
                    {
                        try
                        {
                            OnGreenLedStateChange(this, new LedStateChangeArgs(currentGreenLed));
                        }
                        catch
                        {
                        }
                    }
                }
            }
        }

        #endregion

        #region Pulsing and Flashing Timers

        private void triggerPulsingBuzzerState(object state)
        {
            lock (sync)
            {
                triggerBuzzerPulsingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                if (currentBuzzer != CardReaderBuzzerType.BuzzerPulse)
                    return;

                currentBuzzerPulsingHigh = !currentBuzzerPulsingHigh;
                CardReaderBuzzerType buzzerType;
                if (currentBuzzerPulsingHigh == true)
                    buzzerType = CardReaderBuzzerType.BuzzerPulse | CardReaderBuzzerType.BuzzerOff;
                else
                    buzzerType = CardReaderBuzzerType.BuzzerPulse | CardReaderBuzzerType.BuzzerOn;
                try
                {
                    if (OnBuzzerStateChange != null)
                        OnBuzzerStateChange(this, new BuzzerStateChangeArgs(buzzerType));
                }
                catch
                {
                }

                if (currentBuzzerFrequency > 0)
                    triggerBuzzerPulsingTimer.Change(currentBuzzerFrequency, Timeout.Infinite);
            }
        }

        private void triggerFlashingRedLedState(object state)
        {
            lock (sync)
            {
                triggerRedLedFlashingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                if (currentRedLed != CardReaderLedType.LedFlashing)
                    return;

                currentRedLedFlashingHigh = !currentRedLedFlashingHigh;
                CardReaderLedType ledType;
                if (currentRedLedFlashingHigh == true)
                    ledType = CardReaderLedType.LedFlashing | CardReaderLedType.LedOff;
                else
                    ledType = CardReaderLedType.LedFlashing | CardReaderLedType.LedOn;

                try
                {
                    if (OnRedLedStateChange != null)
                        OnRedLedStateChange(this, new LedStateChangeArgs(ledType));
                }
                catch
                {
                }
                if (currentRedLedFrequency > 0)
                    triggerRedLedFlashingTimer.Change(currentRedLedFrequency, Timeout.Infinite);
            }
        }

        private void triggerFlashingGreenLedState(object state)
        {
            lock (sync)
            {
                triggerGreenLedFlashingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                if (currentGreenLed != CardReaderLedType.LedFlashing)
                    return;

                currentGreenLedFlashingHigh = !currentGreenLedFlashingHigh;
                CardReaderLedType ledType;
                if (currentGreenLedFlashingHigh == true)
                    ledType = CardReaderLedType.LedFlashing | CardReaderLedType.LedOff;
                else
                    ledType = CardReaderLedType.LedFlashing | CardReaderLedType.LedOn;

                try
                {
                    if (OnGreenLedStateChange != null)
                        OnGreenLedStateChange(this, new LedStateChangeArgs(ledType));
                }
                catch
                {
                }

                if (currentGreenLedFrequency > 0)
                    triggerGreenLedFlashingTimer.Change(currentGreenLedFrequency, Timeout.Infinite);
            }
        }

        #endregion

        #region Privite Current State Setters

        private void setBuzzer(CardReaderBuzzerType type, int duration, int frequency)
        {
            lock (sync)
            {
                switch (type)
                {
                    case CardReaderBuzzerType.BuzzerOff:
                        triggerBuzzerPulsingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        currentBuzzer = CardReaderBuzzerType.BuzzerOff;
                        currentBuzzerDuration = 0;
                        currentBuzzerFrequency = 0;
                        if (OnBuzzerStateChange != null)
                        {
                            try
                            {
                                OnBuzzerStateChange(this, new BuzzerStateChangeArgs(CardReaderBuzzerType.BuzzerOff));
                            }
                            catch
                            {
                            }
                        }
                        break;
                    case CardReaderBuzzerType.BuzzerOn:
                        triggerBuzzerPulsingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        currentBuzzer = CardReaderBuzzerType.BuzzerOn;
                        currentBuzzerDuration = duration;
                        currentBuzzerFrequency = frequency;
                        if (OnBuzzerStateChange != null)
                        {
                            try
                            {
                                OnBuzzerStateChange(this, new BuzzerStateChangeArgs(CardReaderBuzzerType.BuzzerOn));
                            }
                            catch
                            {
                            }
                        }
                        triggerBuzzerTimer.Change(duration, Timeout.Infinite);
                        break;
                    case CardReaderBuzzerType.BuzzerPulse:
                        triggerBuzzerPulsingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        if (duration > 0 && frequency > 0)
                        {
                            currentBuzzer = CardReaderBuzzerType.BuzzerPulse;
                            currentBuzzerDuration = duration;
                            currentBuzzerFrequency = frequency;
                            triggerBuzzerTimer.Change(duration, Timeout.Infinite);
                            triggerBuzzerPulsingTimer.Change(frequency, Timeout.Infinite);
                        }
                        break;
                }
            }
        }

        private void setRedLed(CardReaderLedType type, int duration, int frequency)
        {
            lock (sync)
            {
                switch (type)
                {
                    case CardReaderLedType.LedOff:
                        triggerRedLedFlashingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        currentRedLed = CardReaderLedType.LedOff;
                        currentRedLedDuration = 0;
                        currentRedLedFrequency = 0;
                        if (OnRedLedStateChange != null)
                        {
                            try
                            {
                                OnRedLedStateChange(this, new LedStateChangeArgs(CardReaderLedType.LedOff));
                            }
                            catch
                            {
                            }
                        }
                        break;
                    case CardReaderLedType.LedOn:
                        setGreenLed(CardReaderLedType.LedOff, 0, 0);
                        triggerRedLedFlashingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        currentRedLed = CardReaderLedType.LedOn;
                        currentRedLedDuration = duration;
                        currentRedLedFrequency = frequency;
                        if (OnRedLedStateChange != null)
                        {
                            try
                            {
                                OnRedLedStateChange(this, new LedStateChangeArgs(CardReaderLedType.LedOn));
                            }
                            catch
                            {
                            }
                        }
                        triggerRedLedTimer.Change(duration, Timeout.Infinite);
                        break;
                    case CardReaderLedType.LedFlashing:
                        setGreenLed(CardReaderLedType.LedOff, 0, 0);
                        triggerRedLedFlashingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        if (duration > 0 && frequency > 0)
                        {
                            currentRedLed = CardReaderLedType.LedFlashing;
                            currentRedLedDuration = duration;
                            currentRedLedFrequency = frequency;
                            triggerRedLedTimer.Change(duration, Timeout.Infinite);
                            triggerRedLedFlashingTimer.Change(frequency, Timeout.Infinite);
                        }
                        break;
                }
            }
        }

        private void setGreenLed(CardReaderLedType type, int duration, int frequency)
        {
            lock (sync)
            {
                switch (type)
                {
                    case CardReaderLedType.LedOff:
                        triggerGreenLedFlashingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        currentGreenLed = CardReaderLedType.LedOff;
                        currentGreenLedDuration = 0;
                        currentGreenLedFrequency = 0;
                        if (OnGreenLedStateChange != null)
                        {
                            try
                            {
                                OnGreenLedStateChange(this, new LedStateChangeArgs(CardReaderLedType.LedOff));
                            }
                            catch
                            {
                            }
                        }
                        break;
                    case CardReaderLedType.LedOn:
                        setRedLed(CardReaderLedType.LedOff, 0, 0);
                        triggerGreenLedFlashingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        currentGreenLed = CardReaderLedType.LedOn;
                        currentGreenLedDuration = duration;
                        currentGreenLedFrequency = frequency;
                        if (OnGreenLedStateChange != null)
                        {
                            try
                            {
                                OnGreenLedStateChange(this, new LedStateChangeArgs(CardReaderLedType.LedOn));
                            }
                            catch
                            {
                            }
                        }
                        triggerGreenLedTimer.Change(duration, Timeout.Infinite);
                        break;
                    case CardReaderLedType.LedFlashing:
                        setRedLed(CardReaderLedType.LedOff, 0, 0);
                        triggerGreenLedFlashingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        if (duration > 0 && frequency > 0)
                        {
                            currentGreenLed = CardReaderLedType.LedFlashing;
                            currentGreenLedDuration = duration;
                            currentGreenLedFrequency = frequency;
                            triggerGreenLedTimer.Change(duration, Timeout.Infinite);
                            triggerGreenLedFlashingTimer.Change(frequency, Timeout.Infinite);
                        }
                        break;
                }
            }
        }

        #endregion

        #region IDisposable Members

        private bool disposed = false;

        private bool disposing = false;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    this.disposing = true;

                    if (triggerBuzzerTimer != null)
                    {
                        triggerBuzzerTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        triggerBuzzerTimer.Dispose();
                        triggerBuzzerTimer = null;
                    }
                    if (triggerBuzzerPulsingTimer != null)
                    {
                        triggerBuzzerPulsingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        triggerBuzzerPulsingTimer.Dispose();
                        triggerBuzzerPulsingTimer = null;
                    }
                    if (triggerRedLedTimer != null)
                    {
                        triggerRedLedTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        triggerRedLedTimer.Dispose();
                        triggerRedLedTimer = null;
                    }
                    if (triggerRedLedFlashingTimer != null)
                    {
                        triggerRedLedFlashingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        triggerRedLedFlashingTimer.Dispose();
                        triggerRedLedFlashingTimer = null;
                    }
                    if (triggerGreenLedTimer != null)
                    {
                        triggerGreenLedTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        triggerGreenLedTimer.Dispose();
                        triggerGreenLedTimer = null;
                    }
                    if (triggerGreenLedFlashingTimer != null)
                    {
                        triggerGreenLedFlashingTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        triggerGreenLedFlashingTimer.Dispose();
                        triggerGreenLedFlashingTimer = null;
                    }
                    if (triggerStrikeTimer != null)
                    {
                        triggerStrikeTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        triggerStrikeTimer.Dispose();
                        triggerStrikeTimer = null;
                    }
                    if (triggerSpareOutputTimer != null)
                    {
                        triggerSpareOutputTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        triggerSpareOutputTimer.Dispose();
                        triggerSpareOutputTimer = null;
                    }
                }
            }
            disposed = true;
        }

        ~AccessPointPeripheralAgent()
        {
            Dispose(false);
        }

        #endregion
    }
}
