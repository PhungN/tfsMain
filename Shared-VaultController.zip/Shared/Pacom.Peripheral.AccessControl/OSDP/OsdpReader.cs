﻿using System;
using System.Collections.Generic;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Protocol;

namespace Pacom.Peripheral.OsdpDeviceLoop
{
    /// <summary>
    /// This is an implementation of a single Led OSDP device.
    /// </summary>
    public class OsdpReader : IDisposable
    {
        private OsdpDeviceLoopManager manager;

        private readonly int logicalReaderId;
        private readonly OsdpDeviceLoopDevice device;
        private CardReaderBuzzerType buzzerStatus = CardReaderBuzzerType.BuzzerOff;
        private CardReaderLedType acceptLedStatus = CardReaderLedType.LedOff;
        private CardReaderLedType deniedLedStatus = CardReaderLedType.LedOff;

        private System.Threading.Timer contalReaderRefreshTimer = null;
        private bool contalReaderWaitForPin = false;

        internal OsdpReader(OsdpDeviceLoopManager manager, OsdpDeviceLoopDevice device)
        {
            this.manager = manager;
            this.logicalReaderId = device.LogicalReaderId;
            this.device = device;
            contalReaderWaitForPin = false;
            var readerStatus = StatusManager.Instance.Readers[logicalReaderId];
            if (readerStatus != null)
            {
                readerStatus.ParentDoor.AccessControlCommandRequested += new EventHandler<AccessControlCommandRequestEventArgs>(readerAccessControlCommandRequested);
                readerStatus.ParentDoor.AccessControlSecurityLevelDisplayCommandRequested += new EventHandler<DisplaySecurityLevelChangeEventArgs>(onDisplaySecurityLevelCommandRequested);
            }
        }

        /// <summary>
        /// Osdp device bus id.
        /// </summary>
        public int DeviceId
        {
            get
            {
                return device.Address;
            }
        }

        /// <summary>
        /// Osdp device buzzer led status.
        /// </summary>
        public CardReaderBuzzerType BuzzerStatus
        {
            get
            {
                return this.buzzerStatus;
            }
            private set
            {
                if (this.buzzerStatus != value)
                {
                    this.buzzerStatus = value;
                    updateBuzzerStatus();
                }
            }
        }

        /// <summary>
        /// Osdp device accept led status.
        /// </summary>
        public CardReaderLedType AcceptLedStatus
        {
            get
            {
                return this.acceptLedStatus;
            }
            private set
            {
                if (this.acceptLedStatus != value)
                {
                    CardReaderLedType previousValue = this.acceptLedStatus;
                    this.acceptLedStatus = value;
                    updateAcceptLed(previousValue);
                }
            }
        }

        /// <summary>
        /// Osdp device denied led status.
        /// </summary>
        public CardReaderLedType DeniedLedStatus
        {
            get
            {
                return this.deniedLedStatus;
            }
            private set
            {
                if (this.deniedLedStatus != value)
                {
                    this.deniedLedStatus = value;
                    updateDeniedLed();
                }
            }
        }

        /// <summary>
        /// OSDP device vendor
        /// </summary>
        public ReaderManufacturer Vendor
        {
            get
            {
                return device.Vendor;
            }
        }

        /// <summary>
        /// Send initialization messages to device.
        /// </summary>
        /// <returns></returns>
        public void QueueDeviceInitialization()
        {
            device.QueueDeviceInitialization();
        }

        /// <summary>
        /// Process access control reader request
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void readerAccessControlCommandRequested(object sender, AccessControlCommandRequestEventArgs e)
        {
            if (e.LogicalReaderId != this.logicalReaderId)
                return;
            if (e.IsIncluded(AccessCommandType.Buzzer) == true)
            {
                AccessCommandBuzzerConfig buzzerCommand = e[AccessCommandType.Buzzer] as AccessCommandBuzzerConfig;
                if (buzzerCommand != null)
                    this.BuzzerStatus = buzzerCommand.BuzzerType;
            }
            if (e.IsIncluded(AccessCommandType.AcceptLed) == true)
            {
                AccessCommandAcceptLedConfig acceptCommand = e[AccessCommandType.AcceptLed] as AccessCommandAcceptLedConfig;
                if (acceptCommand != null)
                    this.AcceptLedStatus = acceptCommand.AcceptLedType;
            }
            if (e.IsIncluded(AccessCommandType.DeniedLed) == true)
            {
                AccessCommandDeniedLedConfig deniedCommand = e[AccessCommandType.DeniedLed] as AccessCommandDeniedLedConfig;
                if (deniedCommand != null)
                    this.DeniedLedStatus = deniedCommand.DeniedLedType;
            }
        }

        private void onDisplaySecurityLevelCommandRequested(object sender, DisplaySecurityLevelChangeEventArgs e)
        {
            device.QueueSecurityLevelDisplayCommand(e);
        }

        #region Handling of Leds and buzzer

        private void queueLedOn(OsdpMessaging.LedColor ledColor)
        {
            if (contalReaderRefreshTimer != null)
            {
                contalReaderRefreshTimer.Dispose();
                contalReaderRefreshTimer = null;
                contalReaderWaitForPin = false;
                System.Threading.Thread.Sleep(200);
            }
            device.QueueLedOn(ledColor);
        }

        private void updateBuzzerStatus()
        {
            if ((buzzerStatus & CardReaderBuzzerType.BuzzerOn) == CardReaderBuzzerType.BuzzerOn)
                device.QueueBuzzerOn();
            else
                device.QueueBuzzerOff();
        }

        private void updateAcceptLed(CardReaderLedType previousValue)
        {
            if (Vendor == ReaderManufacturer.Pacom || Vendor == ReaderManufacturer.Contal)
            {
                if ((acceptLedStatus & CardReaderLedType.LedFlashing) == CardReaderLedType.LedFlashing)
                {
                    // To accomodate the graphic LCD animations of the 8705, the green led flashing for pin entry needs to be handled slightly different to normal.
                    // The pin pad is only shown when a message is sent to flash the green LED and not when discrete LED ON / LED OFF commands are sent.

                    device.QueueLedFlash(OsdpMessaging.LedColor.Green, OsdpMessaging.LedColor.Black);
                    contalReaderWaitForPin = true;
                    return;
                }
                else if ((previousValue & CardReaderLedType.LedFlashing) == CardReaderLedType.LedFlashing &&
                    acceptLedStatus == CardReaderLedType.LedOn && deniedLedStatus == CardReaderLedType.LedOff)
                {
                    device.QueueLedOn(OsdpMessaging.LedColor.Black);
                    System.Threading.Thread.Sleep(200);
                }
            }

            if ((acceptLedStatus & CardReaderLedType.LedOn) == CardReaderLedType.LedOn)
            {
                if ((DeniedLedStatus & CardReaderLedType.LedOn) == CardReaderLedType.LedOn)
                    queueLedOn(OsdpMessaging.LedColor.Amber);
                else
                    queueLedOn(OsdpMessaging.LedColor.Green);
            }
            else
            {
                if ((acceptLedStatus & CardReaderLedType.LedFlashing) == CardReaderLedType.LedFlashing)
                {
                    if (DeniedLedStatus == CardReaderLedType.LedOff)
                        device.QueueLedFlash(OsdpMessaging.LedColor.Green, OsdpMessaging.LedColor.Black);
                    else
                        device.QueueLedFlash(OsdpMessaging.LedColor.Amber, OsdpMessaging.LedColor.Black);
                }
                else if ((deniedLedStatus & CardReaderLedType.LedOn) == CardReaderLedType.LedOn)
                {
                    queueLedOn(OsdpMessaging.LedColor.Red);
                }
                else
                {
                    device.QueueLedOn(OsdpMessaging.LedColor.Black);
                    if (contalReaderRefreshTimer == null && contalReaderWaitForPin)
                    {
                        contalReaderRefreshTimer = new System.Threading.Timer((_) =>
                        {
                            if (contalReaderRefreshTimer != null)
                            {
                                contalReaderRefreshTimer.Dispose();
                                contalReaderRefreshTimer = null;
                                contalReaderWaitForPin = false;
                                device.QueueLedFlash(OsdpMessaging.LedColor.Red, OsdpMessaging.LedColor.Black);
                                System.Threading.Thread.Sleep(200);
                                device.QueueLedOn(OsdpMessaging.LedColor.Black);
                            }
                        }, null, 1000, 1000);
                    }
                }
            }
        }

        private void updateDeniedLed()
        {
            if ((acceptLedStatus & CardReaderLedType.LedFlashing) == CardReaderLedType.LedFlashing &&
                (Vendor == ReaderManufacturer.Pacom || Vendor == ReaderManufacturer.Contal))
            {
                // To accomodate the graphic LCD animations of the 8705, the green led flashing for pin entry needs to be handled slightly different to normal.
                // The pin pad is only shown when a message is sent to flash the green LED and not when discrete LED ON / LED OFF commands are sent.
                return;
            }

            if ((deniedLedStatus & CardReaderLedType.LedOn) == CardReaderLedType.LedOn)
            {
                if ((acceptLedStatus & CardReaderLedType.LedOn) == CardReaderLedType.LedOn)
                    queueLedOn(OsdpMessaging.LedColor.Amber);
                else
                    queueLedOn(OsdpMessaging.LedColor.Red);
            }
            else if ((deniedLedStatus & CardReaderLedType.LedFlashing) == CardReaderLedType.LedFlashing)
            {
                if (AcceptLedStatus == CardReaderLedType.LedOff)
                    device.QueueLedFlash(OsdpMessaging.LedColor.Red, OsdpMessaging.LedColor.Black);
                else
                    device.QueueLedFlash(OsdpMessaging.LedColor.Amber, OsdpMessaging.LedColor.Black);
            }
            else
            {
                if ((acceptLedStatus & CardReaderLedType.LedOn) == CardReaderLedType.LedOn)
                    queueLedOn(OsdpMessaging.LedColor.Green);
                else
                    device.QueueLedOn(OsdpMessaging.LedColor.Black);
            }
        }

        #endregion


        #region IDisposable Members

        private bool disposed = false;

        private void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                if (disposing == true)
                {
                    try
                    {
                        var readerStatus = StatusManager.Instance.Readers[logicalReaderId];
                        if (readerStatus != null)
                        {
                            readerStatus.ParentDoor.AccessControlCommandRequested -= new EventHandler<AccessControlCommandRequestEventArgs>(readerAccessControlCommandRequested);
                            readerStatus.ParentDoor.AccessControlSecurityLevelDisplayCommandRequested -= new EventHandler<DisplaySecurityLevelChangeEventArgs>(onDisplaySecurityLevelCommandRequested);
                        }

                        Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                        {
                            return string.Format("[Device {0,2}] : Successfully Destroyed!", this.device.Address);
                        });
                        manager = null;
                    }
                    catch (Exception ex)
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, () =>
                        {
                            return ex.ToString();
                        });
                    }
                    disposed = true;
                }
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
