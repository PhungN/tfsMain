﻿using System.Collections.Generic;
using Pacom.Peripheral.Protocol;

namespace Pacom.Peripheral.OsdpDeviceLoop
{
    internal class DeviceAndConnection
    {
        internal DeviceAndConnection(OsdpReader device, OsdpDeviceLoopProtocolMasterConnection deviceConnection)
        {
            Device = device;
            Connection = deviceConnection;
        }

        internal OsdpReader Device { get; set; }
        internal OsdpDeviceLoopProtocolMasterConnection Connection { get; private set; }
    }
}
