﻿using System.Collections.Generic;
using Pacom.Peripheral.Protocol;

namespace Pacom.Peripheral.OsdpDeviceLoop
{
    internal class DeviceListItem
    {
        internal readonly List<DeviceAndConnection> deviceAndConnections = new List<DeviceAndConnection>();
        internal List<DeviceAndConnection> DeviceAndConnections { get { return deviceAndConnections; } }
    }
}
