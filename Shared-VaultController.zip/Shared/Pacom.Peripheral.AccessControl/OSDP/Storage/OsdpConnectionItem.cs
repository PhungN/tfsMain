﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Protocol;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.OsdpDeviceLoop
{
    internal class OsdpConnectionItem
    {
        public OsdpDeviceLoopPortConfiguration Configuration
        {
            get;
            set;
        }

        public OsdpDeviceLoopProtocolMasterConnection OsdpConnection
        {
            get;
            set;
        }

        public PhysicalSerialPort CommPort
        {
            get;
            set;
        }

        public string CommPortDisplay
        {
            get;
            set;
        }
    }
}
