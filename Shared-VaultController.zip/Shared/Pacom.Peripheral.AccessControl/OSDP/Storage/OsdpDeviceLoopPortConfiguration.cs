﻿
namespace Pacom.Peripheral.OsdpDeviceLoop
{
    internal class OsdpDeviceLoopPortConfiguration
    {
        public OsdpDeviceLoopPortConfiguration()
        {            
        }

        /// <summary>
        /// The 128 bits Secure Channel Base Key. Null is unencrypted OSDP - no secure channel.
        /// </summary>
        public byte[] SecureChannelBaseKey { get; set; }

        /// <summary>
        /// OSDP baud rate.
        /// </summary>
        public int BaudRate { get; set; }
    }
}
