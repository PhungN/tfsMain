﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.OsdpMessaging;
using Pacom.Peripheral.Protocol;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.OsdpDeviceLoop
{
    public class OsdpDeviceLoopManager : IOsdpDeviceLoopManager, IDisposable
    {
        public const int DeviceLoopMaxDeviceCount = ConfigurationManager.DoorsCount * 2;
        public const int MaxIdleTime = 90000;

        /// <summary>
        /// List of OSDPDeviceLoop Devices.
        /// There can be multiple devices with the same address.
        /// </summary>
        private readonly DeviceListItem[] deviceList = new DeviceListItem[DeviceLoopMaxDeviceCount];
        private readonly object deviceListLock = new object();

        #region OSDP connections data structures

        private ICardReaderManager cardReaderManager = null;

        private SerialManager serialManager = new SerialManager();
        private readonly object recreateSerialPortsSync = new object();

        private DelayedConfigurationAgent delayedConfiguration = null;

        internal enum ConnectionChangeEnum
        {
            NoChange = 1,
            AddConnection = 2,
            RemoveConnection = 3
        }

        /// <summary>
        /// Id translations for OsdpConnections
        /// </summary>
        internal class OsdpConnectionPort
        {
            public const int ExpansionCard1 = 0;
            public const int ExpansionCard2 = 1;
        }

        /// <summary>
        /// Controller RS485 OSDP port configuration
        /// Entry 0, 1 is for slot 1 and 2, on-board interface is not used
        /// </summary>
        internal readonly OsdpConnectionItem[] OsdpConnections = new OsdpConnectionItem[] 
        {
            new OsdpConnectionItem() { Configuration = null, OsdpConnection = null, CommPort = PhysicalSerialPort.ExpansionCard1, CommPortDisplay = "Expansion Card 1" }, // Slot 1
            new OsdpConnectionItem() { Configuration = null, OsdpConnection = null, CommPort = PhysicalSerialPort.ExpansionCard2, CommPortDisplay = "Expansion Card 2" }, // Slot 2
        };

        private OsdpDeviceLoopProtocolMasterManager osdpDeviceLoopProtocolMasterManager = new OsdpDeviceLoopProtocolMasterManager();

        /// <summary>
        /// Indicator that the instance should not accept any more new connections, and shutdown (disposing) process will happen soon.
        /// </summary>
        private bool deviceLoopManagerClosed = false;

        /// <summary>
        /// Flag set to TRUE if the configuration is changing so no messages from / to device loop devices will be processed because
        /// the device loop will be destroyed and then re-created.
        /// </summary>
        private bool changingConfiguration = false;

        /// <summary>
        /// List of logical ids for configured readers.
        /// </summary>
        private List<int> configuredReaders = new List<int>();

        #endregion

        #region Instance management

        /// <summary>
        /// Singleton instance of OsdpDeviceLoopManager class
        /// </summary>
        private static OsdpDeviceLoopManager instance = null;

        public static OsdpDeviceLoopManager CreateInstance(ICardReaderManager cardReaderManager)
        {
            if (instance == null)
                instance = new OsdpDeviceLoopManager(cardReaderManager);
            return instance;
        }

        /// <summary>
        /// Instance method to get singleton
        /// </summary>
        /// <returns></returns>
        public static OsdpDeviceLoopManager Instance
        {
            get
            {
                if (instance == null)
                    instanceMustBeCreated();
                return instance;
            }
        }

        private static void instanceMustBeCreated()
        {
            Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, () =>
            {
                return "Instance must be created before usage. Call CreateInstance() method before using this property.";
            });
        }

        #endregion

        /// <summary>
        /// Constructor for OsdpDeviceLoopManager
        /// </summary>
        private OsdpDeviceLoopManager(ICardReaderManager cardReaderManager)
        {
            this.cardReaderManager = cardReaderManager;

            delayedConfiguration = new DelayedConfigurationAgent(2000, LoggerClassPrefixes.OsdpDeviceLoopManager);
            delayedConfiguration.ConfigurationChangedMethod = configurationChangedCallback;

            configurationManager_ConfigurationChanged(null, null);
            ConfigurationManager.Instance.ConfigurationChanged += new EventHandler<EventArgs>(configurationManager_ConfigurationChanged);
        }

        private void configurationManager_ConfigurationChanged(object sender, EventArgs e)
        {
            if (deviceLoopManagerClosed || disposing)
                return;

            try
            {
                try
                {
                    // Prepare for configuration
                    changingConfiguration = true;

                    ConnectionChangeEnum isConfigurationChangedForCard1 = ConnectionChangeEnum.NoChange;
                    ConnectionChangeEnum isConfigurationChangedForCard2 = ConnectionChangeEnum.NoChange;
                    int baudRate = ConfigurationManager.Instance.OsdpBaudRate;
                    byte[] scbkAsByteArray = new byte[0];

                    // Create list of configured readers
                    List<int> readerList = new List<int>();
                    foreach (var door in ConfigurationManager.Instance.Doors.Items)
                    {
                        int readerLogicalId;
                        // Entry
                        readerLogicalId = StatusManager.Instance.Doors[door.LogicalId].EntryReaderLogicalId;
                        if (StatusManager.Instance.Readers[readerLogicalId].IsEnabled)
                            readerList.Add(StatusManager.Instance.Readers[readerLogicalId].LogicalId);
                        // Exit
                        readerLogicalId = StatusManager.Instance.Doors[door.LogicalId].ExitReaderLogicalId;
                        if (StatusManager.Instance.Readers[readerLogicalId].IsEnabled)
                            readerList.Add(StatusManager.Instance.Readers[readerLogicalId].LogicalId);
                    }

                    if (readerList.Count > 0)
                    {
                        // Read OSDP configuration and compare to currently running                        
                        try
                        {
                            string input = ConfigurationManager.Instance.OsdpSecureChannelBaseKey;
                            if (input.Length % 2 == 0)
                            {
                                scbkAsByteArray = new byte[input.Length / 2];
                                for (int i = 0; i < scbkAsByteArray.Length; i++)
                                {
                                    scbkAsByteArray[i] = (byte)Convert.ToInt32(input.Substring(i * 2, 2), 16);
                                }
                            }
                            else
                            {
                                scbkAsByteArray = new byte[0];
                            }
                        }
                        catch
                        {
                            scbkAsByteArray = new byte[0];
                        }

                        // Check if configuration has changed for card 1
                        if ((ConfigurationManager.Instance.ControllerMessaging.DoesNotHave(MessagingFlags.RestoreDefaultsAndSwitchAllReportingToExtendedFormat) &&
                            StatusManager.Instance.ExpansionCards.IsOnline(OsdpConnectionPort.ExpansionCard1, ExpansionCardType.Pacom8205SerialCard) ||
                            StatusManager.Instance.ExpansionCards.IsOnline(OsdpConnectionPort.ExpansionCard1, ExpansionCardType.Pacom8207StarCouplerCard)) ||
                            // Non legacy
                            StatusManager.Instance.ExpansionCards.IsConfiguredAndOnline(OsdpConnectionPort.ExpansionCard1, ExpansionCardType.Pacom8205SerialCard) ||
                            StatusManager.Instance.ExpansionCards.IsConfiguredAndOnline(OsdpConnectionPort.ExpansionCard1, ExpansionCardType.Pacom8207StarCouplerCard))
                        {
                            if (OsdpConnections[OsdpConnectionPort.ExpansionCard1].Configuration == null)
                            {
                                isConfigurationChangedForCard1 = ConnectionChangeEnum.AddConnection;
                            }
                            else if ((OsdpConnections[OsdpConnectionPort.ExpansionCard1].Configuration.BaudRate != baudRate) ||
                                (OsdpConnections[OsdpConnectionPort.ExpansionCard1].Configuration.SecureChannelBaseKey.SequenceEqual(scbkAsByteArray) == false) ||
                                (configuredReaders.IsSameList(readerList) == false))
                            {
                                isConfigurationChangedForCard1 = ConnectionChangeEnum.AddConnection;
                            }
                            else if (Serial485ExpansionCardConnection.Com2InUse && Serial485ExpansionCardConnection.LastSentMessageTimeCom2.ElapsedTime > MaxIdleTime)
                            {
                                isConfigurationChangedForCard1 = ConnectionChangeEnum.AddConnection;
                            }
                        }
                        else
                        {
                            if (OsdpConnections[OsdpConnectionPort.ExpansionCard1].Configuration != null)
                            {
                                isConfigurationChangedForCard1 = ConnectionChangeEnum.RemoveConnection;
                            }
                        }

                        // Check if configuration has changed for card 2                        
                        if ((ConfigurationManager.Instance.ControllerMessaging.DoesNotHave(MessagingFlags.RestoreDefaultsAndSwitchAllReportingToExtendedFormat) &&
                            StatusManager.Instance.ExpansionCards.IsOnline(OsdpConnectionPort.ExpansionCard2, ExpansionCardType.Pacom8205SerialCard) ||
                            StatusManager.Instance.ExpansionCards.IsOnline(OsdpConnectionPort.ExpansionCard2, ExpansionCardType.Pacom8207StarCouplerCard)) ||
                            // Non legacy
                            (StatusManager.Instance.ExpansionCards.IsConfiguredAndOnline(OsdpConnectionPort.ExpansionCard2, ExpansionCardType.Pacom8205SerialCard) ||
                            StatusManager.Instance.ExpansionCards.IsConfiguredAndOnline(OsdpConnectionPort.ExpansionCard2, ExpansionCardType.Pacom8207StarCouplerCard)))
                        {
                            if (OsdpConnections[OsdpConnectionPort.ExpansionCard2].Configuration == null)
                            {
                                isConfigurationChangedForCard2 = ConnectionChangeEnum.AddConnection;
                            }
                            else if ((OsdpConnections[OsdpConnectionPort.ExpansionCard2].Configuration.BaudRate != baudRate) ||
                                (OsdpConnections[OsdpConnectionPort.ExpansionCard2].Configuration.SecureChannelBaseKey.SequenceEqual(scbkAsByteArray) == false) ||
                                (configuredReaders.IsSameList(readerList) == false))
                            {
                                isConfigurationChangedForCard2 = ConnectionChangeEnum.AddConnection;
                            }
                            else if (Serial485ExpansionCardConnection.Com3InUse && Serial485ExpansionCardConnection.LastSentMessageTimeCom3.ElapsedTime > MaxIdleTime)
                            {
                                isConfigurationChangedForCard2 = ConnectionChangeEnum.AddConnection;
                            }
                        }
                        else
                        {
                            if (OsdpConnections[OsdpConnectionPort.ExpansionCard2].Configuration != null)
                            {
                                isConfigurationChangedForCard2 = ConnectionChangeEnum.RemoveConnection;
                            }
                        }

                        if (isConfigurationChangedForCard1 == ConnectionChangeEnum.NoChange &&
                            isConfigurationChangedForCard2 == ConnectionChangeEnum.NoChange)
                        {
                            // Appears there is no difference in configuration for OSDP.
                            return;
                        }

                        // Reassign the list of handled readers
                        configuredReaders = readerList;
                    }
                    else
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, () =>
                        {
                            return string.Format("OSDP handling is removed. Door is not configured.");
                        });
                        isConfigurationChangedForCard1 = ConnectionChangeEnum.RemoveConnection;
                        isConfigurationChangedForCard2 = ConnectionChangeEnum.RemoveConnection;
                        configuredReaders.Clear();
                    }

                    // Stop all existing OSDP sessions
                    disposeSerialPorts();

                    if (isConfigurationChangedForCard1 == ConnectionChangeEnum.AddConnection)
                    {
                        OsdpConnections[OsdpConnectionPort.ExpansionCard1].Configuration =
                            new OsdpDeviceLoopPortConfiguration()
                            {
                                SecureChannelBaseKey = scbkAsByteArray,
                                BaudRate = baudRate
                            };
                    }
                    else
                    {
                        OsdpConnections[OsdpConnectionPort.ExpansionCard1].Configuration = null;
                    }

                    if (isConfigurationChangedForCard2 == ConnectionChangeEnum.AddConnection)
                    {
                        OsdpConnections[OsdpConnectionPort.ExpansionCard2].Configuration =
                            new OsdpDeviceLoopPortConfiguration()
                            {
                                SecureChannelBaseKey = scbkAsByteArray,
                                BaudRate = baudRate
                            };
                    }
                    else
                    {
                        OsdpConnections[OsdpConnectionPort.ExpansionCard2].Configuration = null;
                    }

                    Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                    {
                        int validConnectionsCount = 0;
                        StringBuilder ports = new StringBuilder();
                        ports.Append("OSDP manager is waiting on the following ports: ");
                        for (int i = 0; i < OsdpConnections.Length; i++)
                        {
                            if (OsdpConnections[i].OsdpConnection == null && OsdpConnections[i].Configuration != null)
                            {
                                if (validConnectionsCount > 0)
                                    ports.Append(", ");
                                ports.Append(OsdpConnections[i].CommPortDisplay.ToString());
                                ports.Append(" (");
                                ports.Append(OsdpConnections[i].CommPort.ToString());
                                ports.Append(")");
                                validConnectionsCount++;
                            }
                        }
                        if (validConnectionsCount != 0)
                            return ports.ToString();
                        else
                            return "OSDP manager is not waiting for incoming connections.";

                    });

                    // Find out if there are any OSDP connection requiring reconnection
                    bool osdpIsHandled = false;
                    for (int i = 0; i < OsdpConnections.Length; i++)
                    {
                        if (OsdpConnections[i].OsdpConnection == null && OsdpConnections[i].Configuration != null)
                        {
                            delayedConfiguration.ScheduleUpdate();
                            osdpIsHandled = true;
                            break;
                        }
                    }
                    // When the execution got to this point and still following flag is false
                    // the OSDP connection is not established.
                    if (osdpIsHandled == false)
                        StatusManager.Instance.Device.IsOsdpEnabled = false;
                }
                finally
                {
                    changingConfiguration = false;
                }
            }
            catch (Exception ex)
            {
                changingConfiguration = false;
                Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, () =>
                {
                    return string.Format("Error while applying configuration change. {0}", ex.ToString());
                });
            }
        }

        public void Restart()
        {
            configurationManager_ConfigurationChanged(null, new EventArgs());
        }

        private void configurationChangedCallback()
        {
            createSerialPorts();
        }

        private void connection_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (deviceLoopManagerClosed || disposing)
                return;

            if (e.NewConnectionState == ConnectionState.Disconnected)
            {
                delayedConfiguration.ScheduleUpdate();
            }
        }

        private void createSerialPorts()
        {
            lock (recreateSerialPortsSync)
            {
                for (int i = 0; i < OsdpConnections.Length; i++)
                {
                    if (deviceLoopManagerClosed == true)
                        break;

                    if (OsdpConnections[i].OsdpConnection == null && OsdpConnections[i].Configuration != null)
                    {
                        try
                        {
                            OsdpDeviceLoopProtocolMasterConnection osdpConnection =
                                osdpDeviceLoopProtocolMasterManager.CreateConnection(OsdpConnections[i].Configuration.SecureChannelBaseKey);

                            // Add OSDP readers
                            foreach (int readersLogicalId in configuredReaders)
                            {
                                osdpConnection.SetConfiguration(readersLogicalId - 1, readersLogicalId);
                            }

                            osdpConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(osdpConnection_DataReceived);
                            OsdpConnections[i].OsdpConnection = osdpConnection;
                            ProtocolConnectionBase hardwareSerial =
                                serialManager.CreateConnection(
                                    PhysicalSerialType.RS485,
                                    OsdpConnections[i].CommPort,
                                    OsdpConnections[i].Configuration.BaudRate,
                                    System.IO.Ports.Parity.None,
                                    8,
                                    System.IO.Ports.StopBits.One);

                            StatusManager.Instance.Device.IsOsdpEnabled = true;
                            OsdpConnections[i].OsdpConnection.SetLowerLayerConnection(hardwareSerial);
                            OsdpConnections[i].OsdpConnection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(connection_ConnectionStateChanged);
                            OsdpConnections[i].OsdpConnection.Connect();

                        }
                        catch (Exception ex)
                        {
                            Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, () =>
                            {
                                return string.Format("Error while recreating OSDP connection on {0} ({1}). {2}",
                                    OsdpConnections[i].CommPortDisplay, OsdpConnections[i].CommPort, ex.Message);
                            });
                            Thread.Sleep(100);
                        }
                    }
                }
            }
        }

        private void disposeSerialPorts()
        {
            try
            {
                changingConfiguration = true;

                delayedConfiguration.CancelScheduledUpdate();
                delayedConfiguration.WaitForCallbackIfInProgress();

                lock (deviceListLock)
                {
                    for (int i = 0; i < deviceList.Length; i++)
                    {
                        if (deviceList[i] != null)
                        {
                            try
                            {
                                foreach (DeviceAndConnection deviceAndConnection in deviceList[i].DeviceAndConnections)
                                {
                                    if (deviceAndConnection.Device != null)
                                        deviceAndConnection.Device.Dispose();
                                    if (deviceAndConnection.Connection != null && deviceAndConnection.Connection.IsOnline(i) == true)
                                        StatusManager.Instance.Readers[i + 1].Online = false;
                                }
                                deviceList[i] = null;
                            }
                            catch (Exception ex)
                            {
                                deviceList[i] = null;
                                Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, () =>
                                {
                                    return string.Format("Error while disposing of device. {0}", ex.ToString());
                                });
                            }
                        }
                    }
                }

                lock (recreateSerialPortsSync)
                {
                    destroyOsdpConnection(OsdpConnectionPort.ExpansionCard1);
                    destroyOsdpConnection(OsdpConnectionPort.ExpansionCard2);
                }

            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, () =>
                {
                    return string.Format("Error while preparing for configuration change. {0}", ex.ToString());
                });
            }
        }

        private void destroyOsdpConnection(int portIndex)
        {
            if (portIndex < 0 || portIndex > OsdpConnections.Length)
                return;
            try
            {
                if (OsdpConnections[portIndex].OsdpConnection != null)
                {
                    OsdpDeviceLoopProtocolMasterConnection masterConnection = (OsdpDeviceLoopProtocolMasterConnection)OsdpConnections[portIndex].OsdpConnection;

                    masterConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(osdpConnection_DataReceived);
                    OsdpConnections[portIndex].OsdpConnection.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(connection_ConnectionStateChanged);

                    OsdpConnections[portIndex].OsdpConnection.Dispose();
                    OsdpConnections[portIndex].OsdpConnection = null;
                    Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                    {
                        return string.Format("OSDP connection stopped on {0} ({1})", OsdpConnections[portIndex].CommPortDisplay, OsdpConnections[portIndex].CommPort);
                    });
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, () =>
                {
                    return string.Format("Error while disposing OSDP connection {0} ({1}). {2}",
                        OsdpConnections[portIndex].CommPortDisplay, OsdpConnections[portIndex].CommPort, ex.Message);
                });
                OsdpConnections[portIndex].OsdpConnection = null;
            }
        }

        private void osdpConnection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            if (disposing || changingConfiguration || deviceLoopManagerClosed)
                return;

            try
            {
                OsdpDeviceLoopProtocolMasterConnection sourceConnection = sender as OsdpDeviceLoopProtocolMasterConnection;

                OsdpConnectionReceivedDataBase messageBase = e.Metadata["DeviceLoopMessage"] as OsdpConnectionReceivedDataBase;

                // Process online, offline off the connection thread, but other messages over manager separate thread.
                OsdpDeviceMessageReceived dataMessage = messageBase as OsdpDeviceMessageReceived;
                if (dataMessage != null)
                {
                    if (dataMessage.Message.MessageFunctionCode == LocalStatusReply.FunctionCode)
                    {
                        LocalStatusReply localStatusReply = (LocalStatusReply)dataMessage.Message;
                        StatusManager.Instance.Readers[dataMessage.LogicalReaderId].TamperActive = localStatusReply.TamperActive;
                    }
                    else if (dataMessage.Message.MessageFunctionCode == KeyPressReply.FunctionCode)
                    {
                        KeyPressReply keypadReply = (KeyPressReply)dataMessage.Message;
                        KeypadKeys[] inputKeys = keypadReply.PressedKeys;
                        foreach (KeypadKeys key in inputKeys)
                        {
                            byte[] cardData = null;
                            switch (key)
                            {
                                case KeypadKeys.Zero:
                                    cardData = new byte[] { 0x00 };
                                    break;
                                case KeypadKeys.One:
                                    cardData = new byte[] { 0x10 };
                                    break;
                                case KeypadKeys.Two:
                                    cardData = new byte[] { 0x20 };
                                    break;
                                case KeypadKeys.Three:
                                    cardData = new byte[] { 0x30 };
                                    break;
                                case KeypadKeys.Four:
                                    cardData = new byte[] { 0x40 };
                                    break;
                                case KeypadKeys.Five:
                                    cardData = new byte[] { 0x50 };
                                    break;
                                case KeypadKeys.Six:
                                    cardData = new byte[] { 0x60 };
                                    break;
                                case KeypadKeys.Seven:
                                    cardData = new byte[] { 0x70 };
                                    break;
                                case KeypadKeys.Eight:
                                    cardData = new byte[] { 0x80 };
                                    break;
                                case KeypadKeys.Nine:
                                    cardData = new byte[] { 0x90 };
                                    break;
                                case KeypadKeys.Delete:
                                    cardData = new byte[] { 0xA0 };
                                    break;
                                case KeypadKeys.Enter:
                                    cardData = new byte[] { 0xB0 };
                                    break;
                            }
                            if (cardData != null)
                            {
                                CardReaderPortType cardReaderPort = (CardReaderPortType)dataMessage.DeviceAddress;
                                this.cardReaderManager.ProcessScan(cardReaderPort, 4, cardData, true);
                            }
                        }
                    }
                    else if (dataMessage.Message.MessageFunctionCode == RawCardReply.FunctionCode)
                    {
                        RawCardReply rawReply = (RawCardReply)dataMessage.Message;
                        CardReaderPortType cardReaderPort = (CardReaderPortType)dataMessage.DeviceAddress;

                        if (rawReply.CardData != null &&
                            rawReply.CardData.Length > 1 && // More than one byte
                            rawReply.CardData.Length <= 32 &&
                            rawReply.BitCount > 8 &&
                            rawReply.BitCount <= 256)
                        {
                            // The ProcessScan function required 32 bytes data.
                            byte[] bytesReceived = new byte[32];
                            Array.Copy(rawReply.CardData, bytesReceived, rawReply.CardData.Length);
                            this.cardReaderManager.ProcessScan(cardReaderPort, rawReply.BitCount, bytesReceived, true, dataMessage.IsUnauthorizedCard);
                        }
                    }
                }
                else
                {
                    OsdpDeviceOnlineReceived onlineMessage = messageBase as OsdpDeviceOnlineReceived;
                    if (onlineMessage != null)
                    {
                        lock (deviceListLock)
                        {
                            var readerStatus = StatusManager.Instance.Readers[onlineMessage.LogicalReaderId];
                            if (readerStatus != null
                                && ConfigurationManager.Instance.Doors[readerStatus.ParentDoor.LogicalId].IsConfigured != DoorConfiguredType.DoorNotConfigured)
                            {
                                // OSDP Device is online
                                // Prepare the connection list for the device
                                if (deviceList[onlineMessage.DeviceAddress] == null)
                                    deviceList[onlineMessage.DeviceAddress] = new DeviceListItem();

                                // Add device if required
                                OsdpReader reader = new OsdpReader(this, onlineMessage.Device);
                                bool found = false;
                                foreach(DeviceAndConnection deviceAndConnection in deviceList[onlineMessage.DeviceAddress].DeviceAndConnections)
                                {
                                    if (deviceAndConnection.Connection == sourceConnection)
                                    {
                                        deviceAndConnection.Device.Dispose();
                                        deviceAndConnection.Device = reader;
                                        found = true;
                                        break;
                                    }
                                }
                                if (found == false)
                                {
                                    deviceList[onlineMessage.DeviceAddress].DeviceAndConnections.Add
                                        (new DeviceAndConnection(reader, sourceConnection));
                                }

                                // Initialize the specific reader over its connection
                                reader.QueueDeviceInitialization();

                                // Mark device online
                                readerStatus.Online = true;

                                // Refresh door status as new reader could be just attached
                                readerStatus.ParentDoor.TryLockUnlockDoor();
                            }
                        }
                    }
                    else
                    {
                        OsdpDeviceOfflineReceived offlineMessage = messageBase as OsdpDeviceOfflineReceived;
                        if (offlineMessage != null)
                        {
                            lock (deviceListLock)
                            {
                                // Device was not added in first place. Do nothing.
                                if (deviceList[offlineMessage.DeviceAddress] == null)
                                    return;

                                DeviceAndConnection matchingDeviceAndConnection = null;
                                foreach (DeviceAndConnection deviceAndConnection in deviceList[offlineMessage.DeviceAddress].DeviceAndConnections)
                                {
                                    if (deviceAndConnection.Connection == sourceConnection)
                                    {
                                        deviceAndConnection.Device.Dispose();
                                        matchingDeviceAndConnection = deviceAndConnection;
                                        break;
                                    }
                                }
                                if (matchingDeviceAndConnection != null)
                                    deviceList[offlineMessage.DeviceAddress].DeviceAndConnections.Remove(matchingDeviceAndConnection);
                                if (deviceList[offlineMessage.DeviceAddress].DeviceAndConnections.Count == 0)
                                {
                                    deviceList[offlineMessage.DeviceAddress] = null;

                                    // Device is offline
                                    ReaderStatus readerStatus = StatusManager.Instance.Readers[offlineMessage.LogicalReaderId];
                                    if (readerStatus != null)
                                        readerStatus.Online = false;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, () =>
                {
                    return string.Format("Unable to process received message. {0}", ex.Message);
                });
            }
        }

        /// <summary>
        /// Call made by logger to populate this module with any logging information.
        /// </summary>
        /// <param name="textWriter">Stream used to provide textual logging.</param>
        public void CardReaderInfo(TextWriter textWriter)
        {
            try
            {
                if (textWriter == null)
                    return;
                // Prepare log output
                textWriter.WriteLine("OSDP Card Reader Information");
                textWriter.WriteLine();
                if (OsdpConnections[0] != null && OsdpConnections[0].Configuration != null && OsdpConnections[0].OsdpConnection != null)
                {
                    textWriter.WriteLine("Expansion 1:  Configured.");
                    textWriter.WriteLine(string.Format("              Baudrate: {0}", OsdpConnections[0].Configuration.BaudRate));
                    textWriter.WriteLine(string.Format("              SCBK: {0}", OsdpConnections[0].Configuration.SecureChannelBaseKey.Length == 16 ? "Yes" : "No"));
                }
                else
                    textWriter.WriteLine("Expansion 1:  N/A");
                if (OsdpConnections[1] != null && OsdpConnections[1].Configuration != null && OsdpConnections[1].OsdpConnection != null)
                {
                    textWriter.WriteLine("Expansion 2:  Configured.");
                    textWriter.WriteLine(string.Format("              Baudrate: {0}", OsdpConnections[1].Configuration.BaudRate));
                    textWriter.WriteLine(string.Format("              SCBK: {0}", OsdpConnections[1].Configuration.SecureChannelBaseKey.Length == 16 ? "Yes" : "No"));
                }
                else
                    textWriter.WriteLine("Expansion 2:  N/A");
                textWriter.WriteLine();
                textWriter.WriteLine();
                textWriter.Write("Found devices:  ");

                int deviceCount = 0;
                foreach (var d in deviceList)
                {
                    if (d != null)
                        deviceCount++;
                }

                if (deviceCount == 0)
                {
                    textWriter.WriteLine("0");
                }
                else
                {
                    textWriter.WriteLine("{0}", deviceCount);
                    textWriter.WriteLine();
                    foreach (var device in deviceList)
                    {
                        if (device == null)
                            continue;

                        if (device.DeviceAndConnections == null || device.DeviceAndConnections.Count == 0)
                        {
                            textWriter.WriteLine("          None");
                        }
                        else
                        {
                            foreach (var deviceAndConnection in device.DeviceAndConnections)
                            {
                                textWriter.WriteLine("    Device {0} on {1}", deviceAndConnection.Device.DeviceId, getConnectionPort(deviceAndConnection.Connection));
                                textWriter.WriteLine();
                            }
                        }
                    }
                }
            }
            catch
            {
                textWriter.WriteLine("...");
                textWriter.WriteLine();
                textWriter.WriteLine("Unable to create OSDP readers configuration capture.");
            }
        }

        /// <summary>
        /// Shutdown the OSDP Device Loop Manager. Terminate any reader connections.
        /// </summary>
        public void Shutdown()
        {            
            this.deviceLoopManagerClosed = true;
            for (int i = 0; i < OsdpConnections.Length; i++)
            {
                if (OsdpConnections[i].OsdpConnection != null)
                {
                    OsdpDeviceLoopProtocolMasterConnection osdpConnection = OsdpConnections[i].OsdpConnection as OsdpDeviceLoopProtocolMasterConnection;
                    if (osdpConnection != null)
                        osdpConnection.Shutdown();
                }
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return "OSDP Device Loop Manager is shutdown and ready for disposal.";
            });
        }

        private string getConnectionPort(OsdpDeviceLoopProtocolMasterConnection connection)
        {
            if (OsdpConnections[0].OsdpConnection == connection)
                return OsdpConnections[0].CommPortDisplay;
            else if (OsdpConnections[1].OsdpConnection == connection)
                return OsdpConnections[1].CommPortDisplay;
            else
                return "Unknown";
        }

        #region IDisposable Members

        private bool disposed = false;

        private bool disposing = false;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            try
            {
                if (this.disposed == false)
                {
                    if (disposing == true)
                    {
                        this.disposing = true;
                        this.deviceLoopManagerClosed = true;
                        ConfigurationManager.Instance.ConfigurationChanged -= new EventHandler<EventArgs>(configurationManager_ConfigurationChanged);
                        disposeSerialPorts();
                        Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                        {
                            return "OSDP Device Loop Manager Successfully Destroyed";
                        });
                    }
                    instance = null;
                    disposed = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopManager, () =>
                {
                    return ex.ToString();
                });
            }
        }

        ~OsdpDeviceLoopManager()
        {
            Dispose(false);
        }

        #endregion
    }
}
