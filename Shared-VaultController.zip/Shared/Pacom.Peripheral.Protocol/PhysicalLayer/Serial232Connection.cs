﻿using System;
using System.Threading;
using System.IO.Ports;
using System.Collections.Generic;
using Pacom.Peripheral.Common;
using System.Runtime.InteropServices;
using Pacom.Peripheral.Hal;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// The physcial level connection to implement a RS232 serial port for inbuild port.
    /// </summary>
    public class Serial232Connection : SerialConnectionBase
    {
        /// <summary>
        /// Triggered when bytes are received on the port, returned in the byte array.
        /// </summary>
        public override event EventHandler<ReceivedDataEventArgs> DataReceived;

        /// <summary>
        /// Triggered when the connection changes state (Disconnected, Connecting, Connected)
        /// </summary>
        public override event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;

        private IntPtr serialPort;
        private Thread serialPortThread;
        private Thread informUpperLayerThread;
        private readonly Parity portParity;
        private readonly int portDataBits;
        private readonly System.IO.Ports.StopBits portStopBits;
        private bool closing;

        private readonly List<ReceivedDataItem> receivedData = new List<ReceivedDataItem>();
        private ManualResetEvent dataReceived = new ManualResetEvent(false);
        private readonly byte[] readBuffer = new byte[1000];

        private bool disposed;

        private Thread communicationErrorTimerThread = null;
        private int communicationErrorCounter = 0;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="portId">Com Port Id: 1, 2 or 3</param>
        /// <param name="portBaudRate">The speed of the port i.e. 38400</param>
        /// <param name="portParity">The parity to use.</param>
        /// <param name="portDataBits">The number of data bits per character.</param>
        /// <param name="portStopBits">The number of stop bits per character.</param>
        public Serial232Connection(int portId, int portBaudRate, Parity portParity, int portDataBits, System.IO.Ports.StopBits portStopBits) : 
            base(portId, portBaudRate)
        {
            this.portParity = portParity;
            this.portDataBits = portDataBits;
            this.portStopBits = portStopBits;
        }

        ~Serial232Connection()
        {
            Dispose(false);
        }

        private readonly ManualResetEvent informUpperLayerThreadReady = new ManualResetEvent(false);
        /// <summary>
        /// A seperate thread is used to pass the received data up to higher layers so that replies can be sent directly from this thread.
        /// </summary>
        private void informUpperLayerThreadMethod()
        {
            try
            {
                bool waitRequired = false;
                ReceivedDataItem item;

                informUpperLayerThreadReady.Set();
                while (Application.Closing == false && closing == false)
                {
                    lock (receivedData)
                    {
                        if (receivedData.Count == 0)
                        {
                            waitRequired = true;
                            dataReceived.Reset();
                        }
                        else
                        {
                            waitRequired = false;
                        }
                    }
                    if (waitRequired)
                    {
                        dataReceived.WaitOne();
                    }
                    if (Application.Closing || closing)
                        break;
                    lock (receivedData)
                    {
                        item = receivedData[0];
                        receivedData.RemoveAt(0);
                    }
                    if (item != null)
                    {
                        try
                        {
                            // Pass the received data up a layer
                            if (DataReceived != null)
                            {
                                Logger.LogTracedCommsMessage(LoggerClassPrefixes.RS232Connection, DebugLoggingSubCategory.Rs232Connections, () =>
                                {
                                    return string.Format("COM{0} Received on RS232:{1}", portId, BitConverter.ToString(item.Data));
                                });
                                // Pass the error count for the received data to the upper layer to decide.
                                Dictionary<string, object> metadata = new Dictionary<string, object>();
                                metadata.Add("CommErrorCount", item.ErrorCount);
                                DataReceived(this, new ReceivedDataEventArgs(item.Data, metadata));
                            }
                        }
                        catch
                        {
                            Logger.LogErrorMessage(LoggerClassPrefixes.RS232Connection, () =>
                            {
                                return string.Format("Error occurred on port COM{0} during processing received data.", portId);
                            });
                        }
                        item = null;
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle the Error
                Logger.LogErrorMessage(LoggerClassPrefixes.RS232Connection, () =>
                {
                    return string.Format("Inform thread terminated unexpectedly. {0}", ex.Message);
                });
            }
        }

        private readonly ManualResetEvent serialPortThreadReady = new ManualResetEvent(false);
        private void serialPortThreadMethod()
        {
            bool dataLinkFailed = false;
            int communicationErrorCounterSnapshot = 0;
            uint bytesRead;

            try
            {
                // Set the thread priority to very high as the serial port must be handled with very low latency.
                if (NativeMethods.CeSetThreadPriority(new IntPtr(Constants.SH_CURTHREAD + Constants.SYS_HANDLE_BASE), 52) == 0)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.RS232Connection, () =>
                    {
                        return string.Format("COM{0} Failed on CeSetThreadPriority in SerialConnection.serialPortThreadMethod.", portId);
                    });
                }
                if (initializePort() == false)
                {
                    serialPortThreadReady.Set();
                    ConnectionState = ConnectionState.Disconnected;
                    if (ConnectionStateChanged != null)
                        ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Disconnected));
                    return;
                }

                if (ConnectionState == ConnectionState.Connecting)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.RS232Connection, () =>
                    {
                        return string.Format("COM{0} Something has gone wrong with the SerialConnection error code 9002.", portId);
                    });
                }
                serialPortThreadReady.Set();
                while (Application.Closing == false && closing == false)
                {
                    if (ConnectionState == ConnectionState.Connecting)
                    {
                        Logger.LogCriticalMessage(LoggerClassPrefixes.RS232Connection, () =>
                        {
                            return string.Format("COM{0} Something has gone wrong with the SerialConnection error code 9003.", portId);
                        });
                    }

                    bytesRead = 0;

                    // Start counting comm errors
                    communicationErrorCounter = 0;
                    // The read timeout between characters is set to 3 character times so as to return when a complete message
                    // has been received.
                    if (NativeMethods.ReadFile(serialPort, readBuffer, (uint)readBuffer.Length, out bytesRead, IntPtr.Zero) != 0)
                    {
                        communicationErrorCounterSnapshot = communicationErrorCounter;

                        // Check if object is closing down. No need for processing anymore.
                        if (Application.Closing || closing)
                            return;

                        // Pass the received data up a layer
                        byte[] dataBufferTemp = new byte[bytesRead];
                        Buffer.BlockCopy(readBuffer, 0, dataBufferTemp, 0, dataBufferTemp.Length);
                        lock (receivedData)
                        {
                            receivedData.Add(new ReceivedDataItem()
                            {
                                Data = dataBufferTemp,
                                ErrorCount = communicationErrorCounterSnapshot
                            });
                            dataReceived.Set();
                        }
                    }
                }
            }
            catch (ThreadAbortException)
            {
                // The thread was aborted
                ConnectionState = ConnectionState.Disconnected;
                try
                {
                    if (ConnectionStateChanged != null)
                        ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Disconnected));
                }
                catch
                {
                }
                Logger.LogWarnMessage(LoggerClassPrefixes.RS232Connection, () =>
                {
                    return string.Format("COM{0} Thread aborted.", portId);
                });
            }
            catch (Exception ex)
            {
                Logger.LogWarnMessage(LoggerClassPrefixes.RS232Connection, () =>
                {
                    return string.Format("COM{0} Fatal error: {1}", portId, ex.ToString());
                });
                dataLinkFailed = true;
            }
            if (dataLinkFailed)
            {
                ConnectionState = ConnectionState.Disconnected;
                try
                {
                    if (ConnectionStateChanged != null)
                        ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Disconnected));
                }
                catch
                {
                }
            }
            GC.KeepAlive(this);
        }

        private bool initializePort()
        {
            lock (readBuffer)
            {
                try
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.RS232Connection, () =>
                    {
                        return string.Format("COM{0} port open.", portId);
                    });
                    serialPort = NativeMethods.CreateFile(string.Format("COM{0}:", portId), Pacom.Peripheral.Hal.FileAccess.GenericRead | Pacom.Peripheral.Hal.FileAccess.GenericWrite, Pacom.Peripheral.Hal.FileShare.None, IntPtr.Zero, CreationDisposition.OpenExisting, 0, IntPtr.Zero);
                    if (serialPort.ToInt32() == Constants.InvalidHandleValue)
                    {
                        int error = Marshal.GetLastWin32Error();
                        Logger.LogCriticalMessage(LoggerClassPrefixes.RS232Connection, () =>
                        {
                            return string.Format("COM{0} port failed to open. ({1})", portId, error);
                        });
                        return false;
                    }

                    DcbStructure dcb = new DcbStructure();
                    dcb.DCBlength = (uint)Marshal.SizeOf(typeof(DcbStructure));
                    int bytesReturned = 0;
                    // IOCTL_SERIAL_GET_DCB
                    if (NativeMethods.DeviceIoControl(serialPort, NativeMethods.IOCTL_SERIAL_GET_DCB, IntPtr.Zero, 0, ref dcb, Marshal.SizeOf(typeof(DcbStructure)), out bytesReturned, IntPtr.Zero) == 0)
                        return false;

                    dcb.BaudRate = (uint)portBaudRate;
                    dcb.ByteSize = (byte)portDataBits;
                    switch (portParity)
                    {
                        case Parity.Even: dcb.Parity = 2; break;
                        case Parity.Mark: dcb.Parity = 3; break;
                        case Parity.None: dcb.Parity = 0; break;
                        case Parity.Odd: dcb.Parity = 1; break;
                        case Parity.Space: dcb.Parity = 4; break;
                    }

                    // Enable parity checking 
                    dcb.Flags = 0x02;

                    switch (portStopBits)
                    {
                        case System.IO.Ports.StopBits.One: dcb.StopBits = 0; break;
                        case System.IO.Ports.StopBits.OnePointFive: dcb.StopBits = 1; break;
                        case System.IO.Ports.StopBits.Two: dcb.StopBits = 2; break;
                    }

                    // IOCTL_SERIAL_SET_DCB
                    if (NativeMethods.DeviceIoControl(serialPort, NativeMethods.IOCTL_SERIAL_SET_DCB, ref dcb, Marshal.SizeOf(typeof(DcbStructure)), IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                        return false;

                    // Set the timeouts so that a call to ReadFile will return after a set of characters are received followed
                    // by idle for 3 characters.
                    CommTimeoutsStructure commTimeouts = new CommTimeoutsStructure();
                    commTimeouts.ReadIntervalTimeout = (uint)((33000 / portBaudRate) + 1); // Aim for 3 characters as the read timeout.
                    commTimeouts.ReadTotalTimeoutMultiplier = 0;
                    commTimeouts.ReadTotalTimeoutConstant = 0;
                    commTimeouts.WriteTotalTimeoutMultiplier = (uint)(20000 / portBaudRate);
                    commTimeouts.WriteTotalTimeoutConstant = 0;
                    if (NativeMethods.SetCommTimeouts(serialPort, ref commTimeouts) == 0)
                        return false;

                    // IOCTL_SERIAL_SET_WAIT_MASK
                    // Signal line status error occurred (0x0080 = EV_ERR)
                    if (NativeMethods.SetCommMask(serialPort, 0x0080) == 0)
                        return false;

                    communicationErrorTimerThread = new Thread(new ThreadStart(communicationErrorTimerThreadMethod));
                    communicationErrorTimerThread.Name = "Serial Comm Status Checker Timer Thread";
                    communicationErrorTimerThread.IsBackground = true;
                    communicationErrorTimerThread.Priority = ThreadPriority.Highest;
                    communicationErrorTimerThread.Start();

                }
                catch (Exception ex)
                {   // Cannot access the serial port
                    Logger.LogWarnMessage(LoggerClassPrefixes.RS232Connection, () =>
                    {
                        return ex.ToString();
                    });
                    return false;
                }
            }

            ConnectionState = ConnectionState.Connected;
            if (ConnectionStateChanged != null)
                ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Connected));

            if (ConnectionState == ConnectionState.Connecting)
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.RS232Connection, () =>
                {
                    return string.Format("COM{0} Something has gone wrong with error code 9001.", portId);
                });
            }

            GC.KeepAlive(this);
            return true;
        }

        /// <summary>
        /// A non-blocking call to initiate the connection.
        /// A ConnectionStateChanged event will be fired to indicate the final result of the call.
        /// </summary>
        /// <returns>True on success.</returns>
        public override bool Connect()
        {
            // Start the serial port thread
            if (serialPortThread == null)
            {
                serialPortThread = new Thread(new ThreadStart(this.serialPortThreadMethod));
                serialPortThread.Name = string.Format("COM{0} Thread", portId);
                serialPortThread.IsBackground = true;
                serialPortThread.Priority = ThreadPriority.Highest;
                serialPortThread.Start();

                informUpperLayerThread = new Thread(new ThreadStart(this.informUpperLayerThreadMethod));
                informUpperLayerThread.Name = string.Format("COM{0} Inform Thread", portId);
                informUpperLayerThread.IsBackground = true;
                informUpperLayerThread.Priority = ThreadPriority.Normal;
                informUpperLayerThread.Start();
            }
            return true;
        }

        /// <summary>
        /// A blocking call to send a byte array on the connection.
        /// </summary>
        /// <param name="data">The data to send on the port.</param>
        /// <param name="metadata">unused</param>
        /// <returns>True if successfully sent out on the physical connection.</returns>
        public override bool Send(byte[] data, Dictionary<string, object> metadata)
        {
            if (closing)
                return false;

            return send(data);
        }

        /// <summary>
        /// A blocking call to send a byte array on the connection.
        /// </summary>
        /// <param name="data">The data to send on the port.</param>
        /// <returns>True if successfully sent out on the physical connection.</returns>
        private bool send(byte[] data)
        {
            // Do not look at closing here
            Logger.LogTracedCommsMessage(LoggerClassPrefixes.RS232Connection, DebugLoggingSubCategory.Rs232Connections, () =>
            {
                return string.Format("COM{0} Sending on RS232:{1}", portId, BitConverter.ToString(data));
            });

            // Note : The connection could be closed at this point as there is no lock yet.
            // This is unlikely, and not a problem as it only happens on shutdown and a IoException will occur and be caught.

            bool dataLinkFailed = false;
            bool errorOccurred = false;
            uint bytesWritten;

            // Lock the serial port while writing.
            lock (readBuffer)
            {
                try
                {
                    if (NativeMethods.WriteFile(serialPort, data, (uint)data.Length, out bytesWritten, IntPtr.Zero) == 0 || bytesWritten != data.Length)
                        errorOccurred = true;
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.RS232Connection, () =>
                    {
                        return ex.ToString();
                    });
                    dataLinkFailed = true;
                    errorOccurred = true;
                }
            }

            if (dataLinkFailed && ConnectionStateChanged != null)
            {
                ConnectionState = ConnectionState.Disconnected;
                ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Disconnected));
            }

            if (errorOccurred)
            {
                return false;
            }

            GC.KeepAlive(this);
            return true;
        }

        /// <summary>
        /// Thread method counting parity errors during ReadFile.
        /// </summary>
        private void communicationErrorTimerThreadMethod()
        {
            try
            {
                while (Application.Closing == false && closing == false)
                {
                    int mask = 0;
                    if (NativeMethods.WaitCommEvent(serialPort, out mask, IntPtr.Zero) != 0)
                    {
                        if (mask == 0)
                            break;

                        communicationErrorCounter++;
                    }
                }
                GC.KeepAlive(this);
            }
            catch (Exception ex)
            {
                // Handle the Error
                Logger.LogErrorMessage(LoggerClassPrefixes.RS232Connection, () =>
                {
                    return string.Format("Comms error thread terminated unexpectedly. {0}", ex.Message);
                });
            }
        }

        public void Purge()
        {
            purge();
        }

        private bool purge()
        {
            if (serialPort.ToInt32() == Constants.InvalidHandleValue)
                return false;

            SerialPurgeStructure requestFlags = new SerialPurgeStructure();
            requestFlags.Flags = (uint)(SerialPurgeFlags.PurgeRXAbort | SerialPurgeFlags.PurgeTXAbort);

            // IOCTL_SERIAL_PURGE
            if (NativeMethods.DeviceIoControl(serialPort, NativeMethods.IOCTL_SERIAL_PURGE, ref requestFlags, Marshal.SizeOf(typeof(SerialPurgeStructure)), IntPtr.Zero, 0, IntPtr.Zero, IntPtr.Zero) == 0)
                return false;

            GC.KeepAlive(this);
            return true;
        }

        private bool disconnect()
        {
            if (closing || disposed)
                return false;

            closing = true;

            if (NativeMethods.SetCommMask(serialPort, 0) == 0)    // The comms thread should now exit
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.RS232Connection, () =>
                {
                    return string.Format("Failed on SetCommMask in SerialConnection.Disconnect for port {0}.", PortName);
                });
            }

            // All threads must die before proceeding.
            if (serialPortThread != null)
            {
                int countShutdownTry = 0;
                while (!serialPortThread.Join(50))
                {
                    purge();
                    countShutdownTry++;
                    if (countShutdownTry > 3)
                    {
                        serialPortThread.JoinOrRestart(50);
                    }
                }
            }

            if (communicationErrorTimerThread != null)
            {
                communicationErrorTimerThread.JoinOrRestart(2000);
                communicationErrorTimerThread = null;
            }
            if (serialPortThread != null)
            {
                serialPortThread.JoinOrRestart(2000);
                serialPortThread = null;
            }
            if (informUpperLayerThread != null)
            {
                dataReceived.Set();
                informUpperLayerThread.JoinOrRestart(2000);
                informUpperLayerThread = null;
            }

            lock (readBuffer)
            {
                if (serialPort.ToInt32() != Constants.InvalidHandleValue)
                {
                    if (NativeMethods.CloseHandle(serialPort) == 0)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.RS232Connection, () =>
                        {
                            return string.Format("COM{0} Failed on CloseHandle in SerialConnection.Disconnect", portId);
                        });
                    }
                    serialPort = new IntPtr(Constants.InvalidHandleValue);
                }
            }

            NativeMethods.UartIsRS485(portId, false);

            GC.KeepAlive(this);
            return true;
        }

        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposed == false)
                {
                    if (disposing == true)
                    {
                        // dispose managed resources
                        // Just call Disconnect in case it hasn't been called previously.
                        serialPortThreadReady.WaitOne();
                        informUpperLayerThreadReady.WaitOne();
                        disconnect();

                        if (dataReceived != null)
                        {
                            dataReceived.Close();
                            dataReceived = null;
                        }
                        serialPortThreadReady.Close();
                        informUpperLayerThreadReady.Close();
                    }
                    disposed = true;
                }
                base.Dispose(disposing);
            }
            catch (Exception ex)
            {
                Logger.LogWarnMessage(LoggerClassPrefixes.RS232Connection, () =>
                {
                    return ex.ToString();
                });
            }
        }
    }
}
