﻿using System;
using System.IO.Ports;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// A factory that produces SerialConnection instances.
    /// </summary>
    public sealed class SerialManager : IDisposable
    {
        /// <summary>
        /// Produces a new SerialConnection instance.
        /// </summary>
        /// <param name="portType">The type of the serial connection required.</param>
        /// <param name="portId">The com port number via enumeration.</param>
        /// <param name="portBaudRate">The speed of the port i.e. 38400</param>
        /// <param name="portParity">The parity to use.</param>
        /// <param name="portDataBits">The number of data bits per character.</param>
        /// <param name="portStopBits">The number of stop bits per character.</param>
        /// <returns>A new SerialConnection instance.</returns>
        public ProtocolConnectionBase CreateConnection(PhysicalSerialType portType, PhysicalSerialPort portId, int portBaudRate, Parity portParity, int portDataBits, StopBits portStopBits)
        {
            switch (portType)
            {
                case PhysicalSerialType.RS485:
                    {
                        switch (portId)
                        {
                            case PhysicalSerialPort.OnboardRS485Port:
                                {
                                    // Onboard port
                                    return new Serial485Connection((int)portId, portBaudRate, portParity, portDataBits, portStopBits);
                                }
                            case PhysicalSerialPort.ExpansionCard1:
                                {
                                    // Mezz port on expansion 1
                                    return new Serial485ExpansionCardConnection((int)portId, portBaudRate, portParity, portDataBits, portStopBits);
                                }
                            case PhysicalSerialPort.ExpansionCard2:
                                {
                                    // Mezz port on expansion 2
                                    return new Serial485ExpansionCardConnection((int)portId, portBaudRate, portParity, portDataBits, portStopBits);
                                }
                            default:
                                throw new ArgumentException("Invalid port id", "portId");
                        }
                    }
                case PhysicalSerialType.RS232:
                    {
                        if (portId >= PhysicalSerialPort.ExpansionCard1 && portId <= PhysicalSerialPort.OnboardRS232Port)
                        {
                            // Onboard RS232 debugging / Inovonics EchoStream Port or Expansion Slot 1 / Slot 2 as RS232 Port
                            return new Serial232Connection((int)portId, portBaudRate, portParity, portDataBits, portStopBits);
                        }
                        else
                        {
                            throw new ArgumentException(string.Format("Invalid port Id: {0}", portId.ToString()), "portId");
                        }
                    }
                default:
                    throw new NotImplementedException();
            }            
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}
