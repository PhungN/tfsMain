﻿using System;
using System.Collections.Generic;
using System.IO.Ports;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// A factory that produces UdpIPConnection instances.
    /// </summary>
    public partial class UdpIPManager : IDisposable
    {
        private static Dictionary<int, UdpIPConnectionAndInstances> activeListeners = new Dictionary<int, UdpIPConnectionAndInstances>();

        public UdpIPManager()
        {
        }                

        /// <summary>
        /// Produces a new UdpIPConnection instance.
        /// </summary>
        /// <param name="portNumber">The port number to send from as well as to listen on, if required.</param>
        /// <param name="listenOnPort">Set to true if incoming data is expected on the port.</param>
        /// <returns>A new UdpIPConnection instance.</returns>
        public UdpIPConnection CreateConnection(int portNumber, bool listenOnPort)
        {
            if (listenOnPort == false)
                return new UdpIPConnection(portNumber, false);

            UdpIPConnectionAndInstances connectionDetails = null;
            lock (activeListeners)
            {
                if (activeListeners.ContainsKey(portNumber))
                {
                    connectionDetails = activeListeners[portNumber];
                    if (connectionDetails.Connection.IsDisposed == true)
                    {
                        // The UDP connection has been aleardy disposed.
                        activeListeners.Remove(portNumber);
                        connectionDetails = null;
                    }
                }
                if (connectionDetails == null)
                {
                    connectionDetails = new UdpIPConnectionAndInstances();
                    connectionDetails.Connection = new UdpIPConnection(portNumber, true);
                    activeListeners[portNumber] = connectionDetails;
                }
                else
                {
                    connectionDetails.AddReference();
                }
            }
            return connectionDetails.Connection;
        }

        public void DisposeConnection(int portNumber)
        {
            lock (activeListeners)
            {
                if (activeListeners.ContainsKey(portNumber))
                {
                    UdpIPConnectionAndInstances connectionDetails = activeListeners[portNumber];
                    if (connectionDetails.Release())
                    {
                        connectionDetails.Connection.Dispose();
                        activeListeners.Remove(portNumber);
                    }
                }
            }
        }

        public void Dispose()
        {
            activeListeners.Clear();
#if CONTROLLER
            instance = null;
#endif
            GC.SuppressFinalize(this);
        }
    }
}
