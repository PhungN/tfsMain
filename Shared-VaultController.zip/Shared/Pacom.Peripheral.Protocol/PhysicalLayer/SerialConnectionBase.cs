﻿
using Pacom.Peripheral.Common;
namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// Base class for all serial connections
    /// </summary>
    public abstract class SerialConnectionBase : ProtocolConnectionBase
    {
        protected readonly int portId;
        protected readonly int portBaudRate;
        public SerialConnectionBase(int portId, int portBaudRate)
        {
            this.portId = portId;
            this.portBaudRate = portBaudRate;
        }

        /// <summary>
        /// Get serial port as name for this connection
        /// </summary>
        public string PortName
        {
            get
            {
                return string.Format("COM{0}", portId);
            }
        }

        public int PortId
        {
            get { return portId; }
        }

        protected int consecutiveCollisions = 0;
        public int ConsecutiveCollisions
        {
            get
            {
                return consecutiveCollisions;
            }
        }

        public PhysicalSerialPort PhysicalSerialPort
        {
            get
            {
                return (PhysicalSerialPort)portId;
            }
        }

        public int PortBaudRate
        {
            get
            {
                return portBaudRate;
            }
        }
    }
}
