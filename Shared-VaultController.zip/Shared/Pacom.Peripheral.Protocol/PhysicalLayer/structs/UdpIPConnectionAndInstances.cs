﻿using System;
using System.Collections.Generic;
using System.IO.Ports;

namespace Pacom.Peripheral.Protocol
{
    internal class UdpIPConnectionAndInstances
    {
        public UdpIPConnection Connection { get; set; }
        private int referenceCount = 1;

        public void AddReference()
        {
            referenceCount++;
        }

        public bool Release()
        {
            if (referenceCount > 0)
                referenceCount--;

            return (referenceCount == 0);
        }
    }
}