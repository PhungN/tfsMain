﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// Structure holding data and coresponding number of errors.
    /// </summary>
    public class ReceivedDataItem
    {
        /// <summary>
        /// Received data.
        /// </summary>
        public byte[] Data;

        /// <summary>
        /// Number of errors within data array. There is no indication what bytes are good,
        /// only count of errors during receiving of the data can be established.
        /// </summary>
        public int ErrorCount = 0;
    }
}
