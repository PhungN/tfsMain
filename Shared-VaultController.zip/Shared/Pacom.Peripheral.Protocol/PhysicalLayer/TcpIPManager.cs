﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Hal;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// A factory that produces TcpIPConnection instances.
    /// This class also takes care of producing TcpIPConnection instances for incoming connections.
    /// </summary>
    public partial class TcpIPManager : IDisposable
    {
        /// <summary>
        /// Triggered on a new incoming connection.
        /// </summary>
        private readonly List<TcpIPListener> incomingConnectionHandlers = new List<TcpIPListener>();
        private readonly List<TcpIPListenerThread> incomingConnectionThreads = new List<TcpIPListenerThread>();
        private readonly object sync = new object();        
        private bool disposed;

        private static TcpIPManager instance = null;
        
        private TcpIPManager()
        {
        }                

        /// <summary>
        /// Produces a new TcpIPConnection instance.
        /// </summary>
        /// <param name="remoteAddress">The IP address of the remote party.</param>
        /// <param name="localAddress">The local address to bind the port to.</param>
        /// <returns>A new TcpIPConnection instance.</returns>
        public TcpIPConnection CreateConnection(IPEndPoint remoteEndPoint, IPEndPoint localEndPoint)
        {
            return new TcpIPConnection(remoteEndPoint, localEndPoint);
        }

        /// <summary>
        /// Starts listening for incoming TCP/IP connections.
        /// </summary>
        /// <param name="listenPortNumber">The port number to listen on.</param>
        /// <param name="continueListeningAfterConnection">Set to true to allow multiple connections or to false to only accept one connection.</param>
        /// <param name="messageHeader">Contains the initial few bytes expected on the tcp stream. This is required when the same port number is used for different purposes.</param>
        public void StartListening(int listenPortNumber, bool continueListeningAfterConnection, EventHandler<IncomingConnectionEventArgs> handler, byte[] messageHeader)
        {
            if (disposed)
                return;

            lock (sync)
            {
                bool portInUse = false;
                foreach (TcpIPListener incomingConnectionHandler in incomingConnectionHandlers)
                {
                    if (listenPortNumber == incomingConnectionHandler.ListeningPortNumber)
                    {
                        portInUse = true;
                        break;
                    }
                }
                incomingConnectionHandlers.Add(new TcpIPListener(listenPortNumber, continueListeningAfterConnection, handler, messageHeader));

                if (portInUse == true)
                    return;

                try
                {
                    TcpListener portListener = new TcpListener(new IPEndPoint(IPAddress.Any, listenPortNumber));
                    portListener.Start();

                    Thread portListenerThread = new Thread(new ThreadStart(portListenerThreadMethod));
                    incomingConnectionThreads.Add(new TcpIPListenerThread(portListener, portListenerThread, listenPortNumber));
                    portListenerThread.Name = String.Format("TCP Port Listener Thread : {0}", listenPortNumber);
                    portListenerThread.IsBackground = true;
                    portListenerThread.Priority = ThreadPriority.BelowNormal;
                    portListenerThread.Start();
                }
                catch (SocketException ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.TcpIPManager, () =>
                    {
                        return ex.ToString();
                    });
                }
                catch (InvalidOperationException ex)
                {
                    StopListening(handler);
                    Logger.LogErrorMessage(LoggerClassPrefixes.TcpIPManager, () =>
                    {
                        return ex.ToString();
                    });
                }
            }
        }

        /// <summary>
        /// Stops listening for new incoming TCP/IP connections.
        /// </summary>
        public void StopListening(EventHandler<IncomingConnectionEventArgs> handler)
        {
            lock (sync)
            {
                TcpIPListener listener = null;
                foreach (TcpIPListener tcpIPListener in incomingConnectionHandlers)
                {
                    if (tcpIPListener.Handler == handler)
                    {
                        listener = tcpIPListener;
                        break;
                    }
                }

                if (listener == null)
                    return;

                incomingConnectionHandlers.Remove(listener);
                Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPManager, () =>
                {
                    return string.Format("StopListening was called for port {0}.", listener.ListeningPortNumber);
                });

                bool portStillRequired = false;
                foreach (TcpIPListener incomingConnectionHandler in incomingConnectionHandlers)
                {
                    if (incomingConnectionHandler.ListeningPortNumber == listener.ListeningPortNumber)
                    {
                        portStillRequired = true;
                        break;
                    }
                }

                if (portStillRequired == false)
                {
                    foreach (TcpIPListenerThread incomingConnectionThread in incomingConnectionThreads)
                    {
                        if (incomingConnectionThread.ListeningPortNumber == listener.ListeningPortNumber)
                        {
                            incomingConnectionThread.ShuttingDown = true;
                            incomingConnectionThread.PortListener.Server.Close();
                            incomingConnectionThread.PortListener = null;

                            break;
                        }
                    }
                }
            }
        }

        public const string acceptTcpClientExceptionMessage = "A blocking operation was interrupted by a call to WSACancelBlockingCall";

        private void portListenerThreadMethod()
        {
            TcpIPListenerThread incomingConnectionThread = null;
            try
            {
                lock (sync)
                {
                    foreach (TcpIPListenerThread tcpIPListenerThread in incomingConnectionThreads)
                    {
                        if (tcpIPListenerThread.PortListenerThread == Thread.CurrentThread)
                        {
                            incomingConnectionThread = tcpIPListenerThread;
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle the Error
                Logger.LogErrorMessage(LoggerClassPrefixes.TcpIPManager, () =>
                {
                    return string.Format("Processing thread terminated unexpectedly. {0}", ex.Message);
                });
            }

            if (incomingConnectionThread == null)
                return;

            TcpListener listener;
            TcpClient client = null;
            // Signal begin of listening thread
            while (Application.Closing == false && disposed == false && incomingConnectionThread.ShuttingDown == false)
            {
                try
                {
                    listener = incomingConnectionThread.PortListener;

                    if (listener != null)
                        client = listener.AcceptTcpClient();
                    else
                        client = null;
                }
                catch (SocketException ex)
                {
                    // This is likely because we have been instructed to stop listening.
                    if (ex.Message == acceptTcpClientExceptionMessage)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPManager, () =>
                        {
                            return string.Format("TCP port {0} has stopped accepting connections.", incomingConnectionThread.ListeningPortNumber);
                        });
                    }
                    else
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPManager, () =>
                        {
                            return string.Format("SocketException occurred while listening : {0}", ex.ToString());
                        });
                    }
                    break;
                }
                catch (ObjectDisposedException ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPManager, () =>
                    {
                        return string.Format("ObjectDisposedException occurred while listening : {0}", ex.ToString());
                    });
                    break;
                }
                catch (ThreadAbortException)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPManager, () =>
                    {
                        return "TCP/IP Listener Thread Aborted.";
                    });
                    break;
                }
                catch (Exception ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPManager, () =>
                    {
                        return string.Format("Exception occurred while listening : {0}", ex.ToString());
                    });
                    break;
                }

                try
                {
                    if (client != null)
                    {
                        IPEndPoint remoteEndPoint = client.Client.RemoteEndPoint as IPEndPoint;

                        if (remoteEndPoint != null)
                        {
                            TcpIPConnection connection = new TcpIPConnection(remoteEndPoint, client);
                            int messageHeaderLength = 0;
                            List<TcpIPListener> portListenerDetailsList = new List<TcpIPListener>();
                            lock (sync)
                            {
                                foreach (TcpIPListener incomingConnectionHandler in incomingConnectionHandlers)
                                {
                                    if (incomingConnectionHandler.ListeningPortNumber == incomingConnectionThread.ListeningPortNumber)
                                    {
                                        portListenerDetailsList.Add(incomingConnectionHandler);
                                        if (incomingConnectionHandler.MessageHeader != null && incomingConnectionHandler.MessageHeader.Length > messageHeaderLength)
                                            messageHeaderLength = incomingConnectionHandler.MessageHeader.Length;
                                    }
                                }
                            }

                            if (portListenerDetailsList.Count > 1)
                            {
                                byte[] data = new byte[messageHeaderLength];
                                for (int i = 0; i < 10; i++)
                                {
                                    if (client.Client.Available >= messageHeaderLength)
                                        break;
                                    Thread.Sleep(100);
                                }
                                if (client.Client.Available < messageHeaderLength)
                                {
                                    connection.Dispose();
                                    continue;
                                }
                                client.Client.Receive(data, 0, messageHeaderLength, SocketFlags.None);

                                bool portListenerFound = false;
                                foreach (TcpIPListener portListenerDetails in portListenerDetailsList)
                                {
                                    Debug.Assert(portListenerDetails.MessageHeader != null, string.Format("{0}Port listener can't have MessageHeader = null for a shared port.", LoggerClassPrefixes.TcpIPManager));
                                    bool messageHeaderMatch = true;
                                    for (int i = 0; i < portListenerDetails.MessageHeader.Length; i++)
                                    {
                                        if (portListenerDetails.MessageHeader[i] != data[i])
                                        {
                                            messageHeaderMatch = false;
                                            break;
                                        }
                                    }

                                    if (messageHeaderMatch)
                                    {
                                        if (portListenerDetails.ContinueListeningAfterConnection == false)
                                        {
                                            lock (sync)
                                            {
                                                incomingConnectionHandlers.Remove(portListenerDetails);

                                                // Check that there is are still multiple handlers for this port
                                                bool portStillRequired = false;
                                                foreach (TcpIPListener incomingConnectionHandler in incomingConnectionHandlers)
                                                {
                                                    if (incomingConnectionHandler.ListeningPortNumber == incomingConnectionThread.ListeningPortNumber)
                                                    {
                                                        portStillRequired = true;
                                                        break;
                                                    }
                                                }

                                                if (portStillRequired == false)
                                                {
                                                    incomingConnectionThreads.Remove(incomingConnectionThread);
                                                    incomingConnectionThread.ShuttingDown = true;
                                                }
                                            }
                                        }

                                        connection.EnqueueFirstRead(data);
                                        portListenerDetails.Handler(this, new IncomingConnectionEventArgs(connection));
                                        portListenerFound = true;
                                        break;
                                    }
                                }

                                if (portListenerFound == false)
                                {
                                    connection.Dispose();
                                    continue;
                                }
                            }
                            else
                            {
                                if (portListenerDetailsList[0].ContinueListeningAfterConnection == false)
                                {
                                    lock (sync)
                                    {
                                        incomingConnectionHandlers.Remove(portListenerDetailsList[0]);

                                        // Check that there is still only one handler for this port
                                        bool portStillRequired = false;
                                        foreach (TcpIPListener incomingConnectionHandler in incomingConnectionHandlers)
                                        {
                                            if (incomingConnectionHandler.ListeningPortNumber == incomingConnectionThread.ListeningPortNumber)
                                            {
                                                portStillRequired = true;
                                                break;
                                            }
                                        }

                                        if (portStillRequired == false)
                                        {
                                            incomingConnectionThreads.Remove(incomingConnectionThread);
                                            incomingConnectionThread.ShuttingDown = true;
                                        }
                                    }
                                }

                                portListenerDetailsList[0].Handler(this, new IncomingConnectionEventArgs(connection));
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return ex.ToString();
                    });
                }
            }

            try
            {
                lock (sync)
                {
                    incomingConnectionThreads.Remove(incomingConnectionThread);
                }
            }
            catch
            {
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                if (disposing == true)
                {
                    List<EventHandler<IncomingConnectionEventArgs>> handlers;
                    List<Thread> threads;
                    lock (sync)
                    {
                        handlers = new List<EventHandler<IncomingConnectionEventArgs>>(incomingConnectionHandlers.Count);
                        threads = new List<Thread>(incomingConnectionThreads.Count);

                        foreach (TcpIPListener incomingConnectionHandler in incomingConnectionHandlers)
                        {
                            handlers.Add(incomingConnectionHandler.Handler);
                        }
                        foreach (TcpIPListenerThread incomingConnectionThread in incomingConnectionThreads)
                        {
                            threads.Add(incomingConnectionThread.PortListenerThread);
                        }
                    }
                    foreach (EventHandler<IncomingConnectionEventArgs> handler in handlers)
                    {
                        StopListening(handler);
                    }
                    foreach (Thread thread in threads)
                    {
                        try
                        {
                            thread.JoinOrRestart(1000);
                        }
                        catch
                        {
                        }
                    }

                    incomingConnectionHandlers.Clear();
                    incomingConnectionThreads.Clear();
                    instance = null;
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
