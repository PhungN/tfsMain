﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Hal;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// The physcial level connection to implement a TCP/IP connection.
    /// </summary>
    public class TcpIPConnection : ProtocolConnectionBase, IDisposable
    {
        /// <summary>
        /// Triggered when bytes are received on the port, returned in the byte array.
        /// </summary>
        public override event EventHandler<ReceivedDataEventArgs> DataReceived;

        /// <summary>
        /// Triggered when the connection changes state (Disconnected, Connecting, Connected)
        /// </summary>
        public override event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;

        private readonly TcpClient client;
        protected IPEndPoint remoteAddress;
        private readonly object tcpClientLock = new object();
        private readonly byte[] receiveBuffer = new byte[50000];
        private bool disposed;
        private bool callOnDisconnected = true;
        private byte[] firstRead = null;

        /// <summary>
        /// Store disconnection status for Disconnect() function.
        /// </summary>
        private DisconnectionReason connectionFailureReason = DisconnectionReason.Other;

        public IPEndPoint RemoteAddress
        {
            get { return remoteAddress; }
        }

        public IPEndPoint LocalAddress
        {
            get
            {
                if (client != null && client.Client != null)
                {
                    IPEndPoint localIPEndPoint = (IPEndPoint)client.Client.LocalEndPoint;
                    if (localIPEndPoint.Address.Equals(IPAddress.Any))
                        localIPEndPoint = NetworkAdapter.GetLocalAddress(localIPEndPoint.Port, (IPEndPoint)client.Client.RemoteEndPoint);
                    return localIPEndPoint;
                }
                return new IPEndPoint(IPAddress.Any, 0);
            }
        }

        /// <summary>
        /// Constructor. Used to create an outgoing connection to a remote party.
        /// </summary>
        /// <param name="remoteAddress">The IP address of the remote party.</param>
        public TcpIPConnection(IPEndPoint remoteAddress)
            : this(remoteAddress, new TcpClient(AddressFamily.InterNetwork))
        {
            ConnectionState = ConnectionState.Disconnected;
        }

        /// <summary>
        /// Constructor. Used to accept an incomming connection from a remote party.
        /// </summary>
        /// <param name="remoteAddress">The IP address of the remote party.</param>
        /// <param name="client">The incoming connection.</param>
        public TcpIPConnection(IPEndPoint remoteAddress, TcpClient client)
        {
            this.client = client;
            this.remoteAddress = remoteAddress;

            if (this.client.Client.Connected)
                ConnectionState = ConnectionState.Connecting;

            connectionFailureReason = DisconnectionReason.Other;
        }

        /// <summary>
        /// Constructor. Used to create an outgoing connection to a remote party from a specific port number.
        /// </summary>
        /// <param name="remoteAddress">The IP address of the remote party.</param>
        /// <param name="localAddress">The local address to bind the port to.</param>
        public TcpIPConnection(IPEndPoint remoteAddress, IPEndPoint localAddress)
            : this(remoteAddress, new TcpClient(localAddress))
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
            {
                return string.Format("Creating connection from {0} to {1}", localAddress.ToString(), remoteAddress.ToString());
            });
            ConnectionState = ConnectionState.Disconnected;
        }

        internal void EnqueueFirstRead(byte[] firstRead)
        {
            this.firstRead = firstRead;
        }

        private void completeRead(IAsyncResult ar)
        {
            bool forceDisconnect = false;
            bool remoteEndClosedConnection = false;
            try
            {
                byte[] receivedData = null;

                lock (tcpClientLock)
                {
                    if (disposed)
                        return;

                    if ((this.clientExists) && (this.client.Client.Connected))
                    {
                        int bytesRead = 0;
                        try
                        {
                            NetworkStream dataStream = this.client.GetStream();
                            bytesRead = dataStream.EndRead(ar);
                        }
                        catch (InvalidCastException ex)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                            {
                                return string.Format("Invalid Socket Cast Exception: {0}", ex.ToString());
                            });
                        }
                        catch (Exception ex)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                            {
                                return string.Format("Unknown Socket Exception: {0}", ex.ToString());
                            });
                        }
                        if (bytesRead > 0)
                        {
                            receivedData = new byte[bytesRead];
                            Buffer.BlockCopy(this.receiveBuffer, 0, receivedData, 0, bytesRead);
                        }
                        else
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                            {
                                return string.Format("Remote end{0} closed connection.", clientExists ? " " + client.Client.RemoteEndPoint.ToString() : "");
                            });
                            ConnectionState = ConnectionState.Disconnected;
                            remoteEndClosedConnection = true;
                            forceDisconnect = true;
                        }
                    }
                }

                if (remoteEndClosedConnection && ConnectionStateChanged != null)
                {
                    ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Disconnected, DisconnectionReason.TcpIPRemoteEndClosed));
                    callOnDisconnected = false;
                }

                if (!forceDisconnect)
                {
                    if (receivedData != null)
                    {
                        if (DataReceived != null)
                        {
                            Logger.LogTracedCommsMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                            {
                                return string.Format("Received on TCP:{0}", BitConverter.ToString(receivedData));
                            });
                            DataReceived(this, new ReceivedDataEventArgs(receivedData, new Dictionary<string, object>()));
                        }
                    }

                    lock (tcpClientLock)
                    {
                        if (disposed)
                            return;

                        if ((this.clientExists) && (this.client.Client.Connected))
                        {
                            NetworkStream dataStream = this.client.GetStream();
                            dataStream.BeginRead(receiveBuffer, 0, receiveBuffer.Length, new AsyncCallback(readCompleteCallback), dataStream);
                        }
                    }
                }
            }
            catch (SocketException ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                {
                    return string.Format("Error while reading from TCP/IP port. {0}", ex.Message);
                });
                forceDisconnect = true;
            }
            catch (IOException ex)
            {
                if (ex.InnerException is SocketException && ((SocketException)ex.InnerException).ErrorCode == 10054)
                {
                    ConnectionState = ConnectionState.Disconnected;
                    if (ConnectionStateChanged != null)
                    {
                        ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState, DisconnectionReason.Other));
                        callOnDisconnected = false;
                    }
                }
                else
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                    {
                        return string.Format("Error while finishing reading from TCP/IP socket. {0}", ex.Message);
                    });
                }
                forceDisconnect = true;
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                {
                    return string.Format("Error while reading from TCP/IP socket. {0}", ex.Message);
                });
                forceDisconnect = true;
            }

            try
            {
                if (forceDisconnect)
                    Dispose();
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                {
                    return ex.Message;
                });
            }
        }

        private void readCompleteCallback(IAsyncResult ar)
        {
            if (ConnectionState != ConnectionState.Connected)
                return;

            try
            {
                if (ar.CompletedSynchronously)
                {
                    ThreadPool.QueueUserWorkItem(new WaitCallback(delegate(object context)
                    {
                        try
                        {
                            completeRead(ar);
                        }
                        catch (Exception ex)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                            {
                                return ex.ToString();
                            });
                        }
                    }
                    ));
                }
                else
                    completeRead(ar);
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                {
                    return ex.ToString();
                });
            }
        }

        private bool clientExists
        {
            get { return (this.client != null && this.client.Client != null); }
        }

        private void completeConnection()
        {
            bool forceDisconnect = false;

            if (disposed)
                return;

            try
            {
                if ((this.clientExists) && (this.client.Client.Connected))
                {
                    ConnectionState = ConnectionState.Connected;
                    if (ConnectionStateChanged != null)
                        ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Connected, DisconnectionReason.Other));

                    if (firstRead != null && DataReceived != null)
                    {
                        Logger.LogTracedCommsMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                        {
                            return string.Format("Received on TCP:{0}", BitConverter.ToString(firstRead));
                        });
                        DataReceived(this, new ReceivedDataEventArgs(firstRead, new Dictionary<string, object>()));
                        firstRead = null;
                    }

                    NetworkStream dataStream = this.client.GetStream();
                    dataStream.BeginRead(receiveBuffer, 0, receiveBuffer.Length, new AsyncCallback(readCompleteCallback), dataStream);
                }
                else
                {
                    ConnectionState = ConnectionState.Disconnected;
                    if (ConnectionStateChanged != null)
                        ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Disconnected, DisconnectionReason.Other));
                }
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                {
                    return ex.ToString();
                });
                forceDisconnect = true;
            }

            if (forceDisconnect)
            {
                Dispose();
                return;
            }
        }

        /// <summary>
        /// A blocking call to send a byte array on the connection.
        /// </summary>
        /// <param name="data">The data to send on the port.</param>
        /// <param name="metadata">unused</param>
        /// <returns>True if successfully sent out on the physical connection.</returns>
        public override bool Send(byte[] data, Dictionary<string, object> metadata)
        {
            if (ConnectionState != ConnectionState.Connected)
                return false;

            bool forceDisconnect = false;
            Logger.LogTracedCommsMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
            {
                return string.Format("Sending on TCP:{0}", BitConverter.ToString(data));
            });

            try
            {
                if (disposed)
                    return false;

                lock (tcpClientLock)
                {
                    if (clientExists && client.Client.Connected)
                    {
                        client.GetStream().Write(data, 0, data.Length);
                    }
                }
            }
            catch (SocketException ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                {
                    return ex.ToString();
                });
                forceDisconnect = true;
            }
            catch (InvalidOperationException ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                {
                    return ex.ToString();
                });
                forceDisconnect = true;
            }
            catch (IOException ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                {
                    return ex.ToString();
                });
                forceDisconnect = true;
            }

            if (forceDisconnect)
            {
                Dispose();
                return false;
            }
            return true;
        }

        /// <summary>
        /// A blocking call to initiate the connection.
        /// </summary>
        /// <returns>True on success.</returns>
        public override bool Connect()
        {
            connectionFailureReason = DisconnectionReason.Other;

            if (ConnectionState == ConnectionState.Connecting)
                completeConnection();

            if (ConnectionState != ConnectionState.Connected)
            {
                bool forceDisconnect = false;

                try
                {
                    bool callCompleteConnection = false;
                    lock (tcpClientLock)
                    {
                        if (disposed)
                            return false;

                        if (clientExists == false)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                            {
                                return "Client is null.";
                            });
                            return false;
                        }

                        callOnDisconnected = true;

                        if (!this.client.Client.Connected)
                        {
                            ConnectionState = ConnectionState.Connecting;
                            Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                            {
                                return "Connect";
                            });
                            this.client.Connect(remoteAddress);
                            callCompleteConnection = true;
                        }
                    }
                    if (callCompleteConnection)
                        completeConnection();
                }
                catch (SocketException ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                    {
                        return ex.Message;
                    });
                    forceDisconnect = true;
                    // Address already in use.
                    // Typically, only one usage of each socket address (protocol/IP address/port) is permitted.
                    // 8001 firmware up to 4.09D had check forcing source port to 3435. It has been relaxed after this version.
                    // The port requirement is still honored in this code for legacy (<= 4.09D) versions.
                    if (ex.ErrorCode == 10048)
                    {
                        connectionFailureReason = DisconnectionReason.TcpIPAddressAlreadyInUse;
                    }
                }
                catch (InvalidOperationException ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                    {
                        return ex.ToString();
                    });
                    forceDisconnect = true;
                }
                catch (IOException ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                    {
                        return ex.ToString();
                    });
                    forceDisconnect = true;
                }

                if (forceDisconnect)
                {
                    Dispose();
                    return false;
                }
            }

            return true;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                if (disposing == true)
                {
                    lock (tcpClientLock)
                    {
                        try
                        {
                            if ((this.clientExists) && (this.client.Client.Connected))
                            {
                                Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                                {
                                    return string.Format("Disconnect from IP Address: {0}", client.Client.RemoteEndPoint.ToString());
                                });
                                this.client.Client.Shutdown(SocketShutdown.Both);
                                this.client.Client.Close();
                            }
                        }
                        catch (SocketException ex)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                            {
                                return string.Format("Error while disconnecting TCP/IP socket. {0}", ex.Message);
                            });
                        }

                        try
                        {
                            if (client != null)
                                client.Close();
                            Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                            {
                                return "Destroyed";
                            });
                        }
                        catch (Exception ex)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                            {
                                return string.Format("Error while destroying TCP/IP connection instance. {0}", ex.Message);
                            });
                        }
                    }
                    try
                    {
                        ConnectionState = ConnectionState.Disconnected;
                        if (callOnDisconnected == true)
                        {
                            callOnDisconnected = false;
                            if (ConnectionStateChanged != null)
                                ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Disconnected, connectionFailureReason));
                        }
                    }
                    catch (SocketException ex)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.TcpIPConnection, DebugLoggingSubCategory.TcpConnections, () =>
                        {
                            return string.Format("Unable to send notification on connection state change. {0}", ex.Message);
                        });
                    }
                }
                disposed = true;
            }
            base.Dispose(disposing);
        }
    }
}
