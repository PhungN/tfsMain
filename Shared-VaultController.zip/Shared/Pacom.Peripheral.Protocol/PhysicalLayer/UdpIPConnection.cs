﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Hal;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// The physcial level connection to implement a UDP/IP connection.
    /// </summary>
    public class UdpIPConnection : ProtocolConnectionBase, IDisposable
    {
        /// <summary>
        /// Triggered when bytes are received on the port, returned in the byte array.
        /// </summary>
        public override event EventHandler<ReceivedDataEventArgs> DataReceived;

        /// <summary>
        /// Triggered when the connection changes state (Disconnected, Connecting, Connected)
        /// </summary>
        public override event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;

        private UdpClient client;
        private bool closing =  false;
        private bool disposed = false;
        private readonly object sync = new object();

        /// <summary>
        /// Local port number to bind the UDP client to
        /// </summary>
        private int portNumber;

        public virtual IPEndPoint RemoteEndPoint
        {
            get;
            set;
        }

        private bool isListener;
        private bool isListening = false;
        private Thread listenerThread = null;

        /// <summary>
        /// Check if we need to filter data received from a specific remote host only.
        /// </summary>
        /// <param name="remoteEndPoint">Remote host from which the connection will accept data</param>
        /// <returns></returns>
        protected virtual bool AnyRemoteHost(IPEndPoint remoteEndPoint)
        {
            return true;
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="portNumber">The port number to send from as well as to listen on, if required.</param>
        /// <param name="listenOnPort">Set to true if incoming data is expected on the port.</param>
        public UdpIPConnection(int portNumber, bool listenOnPort)
        {
            ConnectionState = ConnectionState.Connecting;
            this.portNumber = portNumber;
            this.isListener = listenOnPort;
            RemoteEndPoint = null;
        }

        private void listenerThreadMethod()
        {
            IPEndPoint remoteEndPoint;
            try
            {
                isListening = true;
                while (Application.Closing == false && closing == false)
                {
                    remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);
                    byte[] receivedData = client.Receive(ref remoteEndPoint);

                    if (receivedData != null && DataReceived != null && AnyRemoteHost(remoteEndPoint) == true)
                    {
                        Dictionary<string, object> d = new Dictionary<string, object>();
                        d.Add("RemoteEndPoint", remoteEndPoint);
                        Logger.LogTracedCommsMessage(LoggerClassPrefixes.UdpConnection, DebugLoggingSubCategory.TcpConnections, () =>
                        {
                            return string.Format("Received on UDP {0} from end point: {1}", BitConverter.ToString(receivedData), remoteEndPoint.ToString());
                        });
                        DataReceived(this, new ReceivedDataEventArgs(receivedData, d));
                    }
                }
            }
            catch (ThreadAbortException ex)
            {
                isListening = false;
                // The thread was aborted
                ConnectionState = ConnectionState.Disconnected;
                try
                {
                    if (ConnectionStateChanged != null)
                        ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Disconnected));
                }
                catch
                {
                }
                Logger.LogWarnMessage(LoggerClassPrefixes.UdpConnection, () =>
                {
                    return string.Format("UDP Listen Fatal Thread Abort Error : {0}", ex.ToString());
                });
            }
            catch (Exception ex)
            {
                isListening = false;
                if (closing == false)
                {
                    Logger.LogWarnMessage(LoggerClassPrefixes.UdpConnection, () =>
                    {
                        return string.Format("UDP Listen Fatal Error : {0}", ex.ToString());
                    });
                }
            }
            isListening = false;
        }

        /// <summary>
        /// A blocking call to send a byte array on the connection.
        /// </summary>
        /// <param name="data">The data to send on the port.</param>
        /// <param name="metadata">Must contain an element named 'RemoteEndPoint' whos value is an IPEndPoint containing the IP address and port number the message should be sent to.</param>
        /// <returns>True if successfully sent out on the physical connection.</returns>
        public override bool Send(byte[] data, Dictionary<string, object> metadata)
        {
            if (closing || ConnectionState != ConnectionState.Connected)
                return false;

            Logger.LogTracedCommsMessage(LoggerClassPrefixes.UdpConnection, DebugLoggingSubCategory.TcpConnections, () =>
            {
                return string.Format("Sending on UDP:{0}", BitConverter.ToString(data));
            });

            int sentBytes;
            object tempObject;
            IPEndPoint remoteEndPoint = RemoteEndPoint;
            if (metadata.TryGetValue("RemoteEndPoint", out tempObject))
            {
                remoteEndPoint = tempObject as IPEndPoint;
            }

            if (remoteEndPoint == null)
                return false;

            try
            {
                lock (sync)
                {
                    sentBytes = client.Send(data, data.Length, remoteEndPoint);
                }
            }
            catch
            {
                return false;
            }

            if (sentBytes == data.Length)
                return true;
            return false;
        }

        /// <summary>
        /// Binds to the specified port number and, if required, listen for received data on the port.
        /// </summary>
        /// <returns></returns>
        public override bool Connect()
        {
            if (ConnectionState == ConnectionState.Connecting)
            {
                try
                {
                    lock (sync)
                    {
                        client = new UdpClient(portNumber);
                        client.Client.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.TypeOfService, 0xE0);

                        if (isListener)
                        {
                            listenerThread = new Thread(new ThreadStart(this.listenerThreadMethod));
                            listenerThread.Name = "UDP Port " + portNumber + " Listener Thread";
                            listenerThread.IsBackground = true;
                            listenerThread.Priority = ThreadPriority.Normal;
                            listenerThread.Start();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogWarnMessage(LoggerClassPrefixes.UdpConnection, () =>
                    {
                        return string.Format("Failed creating UDP/IP port : {0}", ex);
                    });
                    disconnect();
                    return false;
                }

                ConnectionState = ConnectionState.Connected;
                if (ConnectionStateChanged != null)
                    ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState));
                Logger.LogDebugMessage(LoggerClassPrefixes.UdpConnection, DebugLoggingSubCategory.TcpConnections, () =>
                {
                    return "Connect";
                });
            }

            return true;
        }

        private bool clientExists
        {
            get { return (client != null && client.Client != null); }
        }

        private bool disconnect()
        {
            if (closing || disposed)
                return false;

            closing = true;
            lock (sync)
            {
                try
                {
                    if (clientExists == true)
                        client.Close();
                    if (isListening && listenerThread != null)
                        listenerThread.JoinOrRestart(3000);
                    Logger.LogDebugMessage(LoggerClassPrefixes.UdpConnection, DebugLoggingSubCategory.TcpConnections, () =>
                    {
                        string message = "Disconnect";
                        if (RemoteEndPoint != null)
                            message = string.Format("Disconnect from IP Address: {0}", RemoteEndPoint.ToString());
                        return message;
                    });
                    return true;
                }
                catch (SocketException ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.UdpConnection, () =>
                    {
                        return string.Format("Error while disconnecting UDP/IP socket. {0}", ex.Message);
                    });
                }
                catch (Exception ex)
                {
                    Logger.LogErrorMessage(LoggerClassPrefixes.UdpConnection, () =>
                    {
                        return string.Format("Unknown error while disconnecting UDP/IP socket. {0}", ex.Message);
                    });
                }
                return false;
            }
        }

        /// <summary>
        /// Returns true if the instance is listening for incoming UDP/IP traffic.
        /// </summary>
        public bool IsListening
        {
            get
            {
                if (isListener && isListening)
                    return true;
                return false;
            }
        }

        /// <summary>
        /// The local port number.
        /// </summary>
        public int Port
        {
            get
            {
                return portNumber;
            }
        }

        /// <summary>
        /// Returnes true if the connection instance is already disposed.
        /// </summary>
        public bool IsDisposed
        {
            get
            {
                return disposed;
            }
        }

        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposed == false)
                {
                    if (disposing == true)
                    {
                        // Call Disconnect in case it hasn't been called previously.
                        disconnect();
                        RemoteEndPoint = null;
                    }
                    Logger.LogDebugMessage(LoggerClassPrefixes.UdpConnection, DebugLoggingSubCategory.TcpConnections, () =>
                    {
                        return "Destroyed";
                    });
                    disposed = true;
                }                
                base.Dispose(disposing);                
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.UdpConnection, () =>
                {
                    return ex.ToString();
                });
            }
        }
    }
}

