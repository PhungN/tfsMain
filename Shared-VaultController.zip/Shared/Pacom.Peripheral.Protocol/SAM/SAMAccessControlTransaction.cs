﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Common.Utils;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.OsdpMessaging.Apdu
{
    public class SamAccessControlTransaction
    {
        #region constants
        private readonly byte[] Le                                      = new byte[] { 0x00 };
        private readonly byte[] ModeAndTracability                      = new byte[] { 0x68, 0x01, 0xB8};
        // Card Commands
        private readonly byte[] cardSelectApplicationCmdData            = new byte[] { 0x00, 0xA4, 0x04, 0x00, 0x0B, 0xA0, 0x00, 0x00, 0x02, 0x91, 0xA0, 0x04, 0x00, 0x01, 0x93, 0x11, 0x00 };
        private readonly byte[] cardOpenSecureSessionCmdData            = new byte[] { 0x00, 0x8A, 0x0B, 0x8A, 0x09, 0x00 };
        private readonly byte[] cardCloseSecureSessionCmdData           = new byte[] { 0x00, 0x8E, 0x80, 0x00, 0x08 };
        private readonly byte[] cardSelectApplicationReplyFirstPart     = new byte[] { 0x6F, 0x26, 0x84, 0x0C, 0xA0, 0x00, 0x00, 0x02, 0x91, 0xA0, 0x04, 0x00, 0x01, 0x93, 0x11 };
        private readonly byte[] cardSelectApplicationReplySecondPart    = new byte[] { 0xA5, 0x16, 0xBF, 0x0C, 0x13, 0xC7, 0x08 };
        // SAM Commands
        private readonly byte[] samSelectDiverfierCmdData               = new byte[] { 0x80, 0x14, 0x00, 0x00, 0x08 };
        private readonly byte[] samGetChallengeCmdData                  = new byte[] { 0x80, 0x84, 0x00, 0x00, 0x08 };
        private readonly byte[] samPsoVerifySignatureCmdData            = new byte[] { 0x80, 0x2A, 0x00, 0xA8, 0x4E, 0xFF };
        private readonly byte[] samDigestInitCmdData                    = new byte[] { 0x80, 0x8A, 0x02, 0xFF, 0x4E };
        private readonly byte[] samDigestCloseCmdData                   = new byte[] { 0x80, 0x8E, 0x00, 0x00, 0x08 };
        private readonly byte[] samDigestAuthenticateCmdData            = new byte[] { 0x80, 0x82, 0x00, 0x00, 0x08 };
        #endregion

        #region private members
        private SamTransactionData apduData = new SamTransactionData();

        private static UInt32 getTimeInBCD(uint year, uint month, uint day)
        {
            return (int2BCD(year / 100) << 24) | (int2BCD(year % 100) << 16) | (int2BCD(month) << 8) | (day & 0xFF);
        }
        private static UInt32 int2BCD(UInt32 bcd)
        {
            return (UInt32)((bcd % 10) | (bcd / 10) << 4);
        }
        private static UInt32 bcd2Int(UInt32 num)
        {
            return (UInt32)((((byte)num) >> 4) * 10 + (num & 0x0f));
        }

        private SamAuthenticateResult getData(SamAuthenticateDataType type, byte[] apduData, Int32 apduIndex, Int32 dataLen, byte[] oData)
        {
            SamAuthenticateResult result = SamAuthenticateResult.Success;
            if (apduIndex < 0 || apduIndex > apduData.Length)
                result = SamAuthenticateResult.InternalError;
            else if (apduData.Length < apduIndex + dataLen)
                result = type == SamAuthenticateDataType.Card ? SamAuthenticateResult.SamApduDataError : SamAuthenticateResult.SamApduDataError;
            else
                Array.Copy(apduData, apduIndex, oData, 0, dataLen);
            return result;
        }

        private SamAuthenticateResult getChallenge(byte[] apduData, byte[] challenge)
        {
            return getData(SamAuthenticateDataType.SAM, apduData, 0, challenge.Length, challenge);
        }

        private SamAuthenticateResult getKIFKVCSession(byte[] apduData, byte[] KIFKVC)
        {
            return getData(SamAuthenticateDataType.Card, apduData, 9, KIFKVC.Length, KIFKVC);
        }

        private SamAuthenticateResult getDataEnv(byte[] apduData, byte[] envData)
        {
            return getData(SamAuthenticateDataType.Card, apduData, 12, envData.Length, envData);
        }

        private SamAuthenticateResult getSerialNumber(byte[] apduData, byte[] serialNumber)
        {
            return getData(SamAuthenticateDataType.Card, apduData, 23, serialNumber.Length, serialNumber);
        }

        private SamAuthenticateResult getKIFKVCSignature(byte[] apduData, byte[] KIFKVCSig)
        {
            return getData(SamAuthenticateDataType.Card, apduData, 12 + 54, KIFKVCSig.Length, KIFKVCSig);
        }

        private bool isCardBlackListed(UInt32 cardSerialNumber, UInt32 cardCounterValue, List<SamBlackListItem> blackList)
        {
            if(blackList != null)
            {
                foreach (var item in blackList)
                {
                    if (cardSerialNumber == item.SerialNumber && cardCounterValue >= item.CounterValue)
                        return true;
                }
            }
            return false;
        }

        private static int daySince1990(int year, int month, int day)
        {
            return  ((UInt16)(365u * (uint)((year) - 1990) + (3 + (year)) / 4 + 61 * (month) / 2	+(((year) % 4 != 0 ? 0x440028 : 0x1995568) >> 2 * (month)) % 4 + (day) - 531 ));
        }

        /// <summary>
        /// 1/1/2000 day since 1990
        /// </summary>
        private const int dateMin = ((UInt16)(365u * (uint)((2000) - 1990) + (3 + 2000) / 4 + 61 * (1) / 2 + (((2000) % 4 != 0 ? 0x440028 : 0x1995568) >> 2 * (1)) % 4 + (1) - 531));
        /// <summary>
        /// 31/12/2099 day since 1990
        /// </summary>
        private const int dateMax = ((UInt16)(365u * (uint)((2099) - 1990) + (3 + (2099)) / 4 + 61 * (12) / 2 + (((2099) % 4 != 0 ? 0x440028 : 0x1995568) >> 2 * (12)) % 4 + (31) - 531));

        private int invalidDataFormat(UInt32 inDate)
        {
            UInt32 tmpYMD = inDate;
            int vDate = (UInt16)(tmpYMD >> 8);
            if (tmpYMD >= 0x21000000 || 0 != (0xF0F0F0 & ((tmpYMD + 0x06060606) ^ tmpYMD)))
                return -1;
            tmpYMD -= 3 * ((0xF0F0F0 & tmpYMD) >> 3) + 0x101; // each byte is now converted from BCD, month and day are normalized to 0;
            if ((byte)(tmpYMD >> 8) >= 12 || (byte)tmpYMD >= 31)
                return -1;
            vDate = (int)
                ((365 * (byte)((tmpYMD >> 16) + 10u)) +     // days resulting from years since 1990, at most 0xF0F5
                ((3u + (byte)(tmpYMD >> 16)) >> 2) +        // correction for leap years (up to 2099)
                (byte)tmpYMD +      // days
                ((61u * (byte)(tmpYMD >> 8)) >> 1) +        // days resulting from month
                (3u & ((0 != (3u & (tmpYMD >> 16)) ? 0x55444E : 0xAA999E) >> (((byte)(tmpYMD >> 8)) << 1))));   // correction for uneven month, in range [0..3]

            if ((UInt16)(vDate - dateMin) > (UInt16)(dateMax - dateMin))
                return -1;

            return 0;
        }

        private SamAuthenticateResult verifyDataValidity(byte[] dataEnv, List<SamBlackListItem>  blackList, UInt32 cardDuration, DateTime currentDate)
        {
            bool verifyDateRequired = false;
            SamAuthenticateResult result = SamAuthenticateResult.Success;
            byte envVersion = dataEnv[0];
            UInt32 envIssuingDate = ByteArray.ToUInt32(dataEnv, 5);
            UInt32 envSamId = ByteArray.ToUInt32(dataEnv, 47);
            UInt32 envSamCount = ByteArray.ToUInt32(dataEnv, 51) >> 8;

            if (envVersion == 0)                                                // Verify the version of the environment
            {
                ErrorMessage = "invalid evironment version";
                result = SamAuthenticateResult.CardFormatError;
            }
            else if (invalidDataFormat(envIssuingDate) != 0)                    // verify the format of the date
            {
                ErrorMessage = "invalid date format";
                result = SamAuthenticateResult.CardFormatError;
            }
            else if (isCardBlackListed(envSamId, envSamCount, blackList))       // Verify if the card is not personalise with a blackListedSam
            {
                ErrorMessage = "card is black listed";
                result = SamAuthenticateResult.CardBlackListedSamError;
            }
            else                                                                // Verify validity of the card (vEnvIssuingDate is in BCD format: 0x20161112 for 12 November 2016)
            {
                if (verifyDateRequired == false)
                    return result;
                // create the end date validity
                UInt32 issuingYear = bcd2Int((byte)(envIssuingDate >> 24)) * 100 + bcd2Int((byte)(envIssuingDate >> 16));
                UInt32 issuingMonth = bcd2Int((byte)(envIssuingDate >> 8));
                UInt32 month = issuingMonth + cardDuration - 1;
                UInt32 year = issuingYear + month / 12;
                month = (month % 12) + 1;
                UInt32 endDate = getTimeInBCD(year, month, envIssuingDate);

                //-------------------------------------------------
                // Return an error if the date is before the personalisation
                // return an error if the validity of the card is expired
                //-------------------------------------------------
                //DateTime dt = DateTime.Now;
                UInt32 currentDateInBCD = getTimeInBCD((uint)currentDate.Year, (uint)currentDate.Month, (uint)currentDate.Day);
                if (currentDateInBCD < envIssuingDate || currentDateInBCD >= endDate)
                {
                    ErrorMessage = "invalid card date";
                    result = SamAuthenticateResult.CardDateError;
                }
            }

            return result;
        }
        #endregion

        #region Public properties
        public string ErrorMessage
        {
            private set;
            get;
        }
        #endregion

        #region public members
        public delegate SamAuthenticateResult CardExchange(int deviceAddress, byte[] apduCommand, byte[] apduResponse, ref int apduResponseLength);
        public delegate SamAuthenticateResult SamExchange(byte[] apduCommand, byte[] apduResponse, ref int apduResponseLength);

        public SamAuthenticateResult GetBadgeIdentifier(int deviceAddress, CardExchange cardApduExchange, SamExchange samApduExchange, UInt32 cardDuration,
            List<SamBlackListItem> blackList,
            DateTime currentDate, ref byte[] badgeIdentifier)
        {
            byte[] apduResponse = new byte[258];
            byte[] apduCommand = null;
            int apduResponseLength = 0;
            ErrorMessage = "";
            if (cardApduExchange == null || samApduExchange == null)
                return SamAuthenticateResult.InternalError;

            #region Send Select Application and get the serial number
            SamAuthenticateResult result = selectApplication(cardApduExchange, deviceAddress, apduResponse, ref apduResponseLength);
            if (result != SamAuthenticateResult.Success)
                return result;
            #endregion

            #region Select Diversifier with the SAM
            apduCommand = ByteArray.Combine(samSelectDiverfierCmdData, apduData.CardSerialNumber);
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("SAM Diversify CMD: {0}.", BitConverter.ToString(apduCommand, 0, apduCommand.Length));
            });

            result = samApduExchange(apduCommand, apduResponse, ref apduResponseLength);
            if (result != SamAuthenticateResult.Success)
            {
                ErrorMessage = "Failed SAM Select Diversify";
                return result;
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("SAM Diversify RSP : {0}.", BitConverter.ToString(apduResponse, 0, apduResponseLength));
            });
            #endregion

            #region Get Challenge with the SAM
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format(" SAM Challenge CMD: {0}.", BitConverter.ToString(samGetChallengeCmdData));
            });
            result = samApduExchange(samGetChallengeCmdData, apduResponse, ref apduResponseLength);
            if (result != SamAuthenticateResult.Success)
            {
                ErrorMessage = "Failed SAM Challenge";
                return result;
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("SAM Challenge RSP : {0}.", BitConverter.ToString(apduResponse, 0, apduResponseLength));
            });
            result = getChallenge(apduResponse, apduData.Challenge);
            if (result != SamAuthenticateResult.Success)
            {
                ErrorMessage = "Invalid SAM Challenge";
                return result;
            }
            #endregion

            #region Open Secure Session and get data
            result = openSecureSession(cardApduExchange, deviceAddress, apduResponse, ref apduResponseLength);
            if (result != SamAuthenticateResult.Success)
                return result;
            #endregion

            #region PSO Verify Signature
            apduCommand = ByteArray.Combine(samPsoVerifySignatureCmdData, apduData.KIFKVCSignature, ModeAndTracability, apduData.CardSerialNumber, apduData.EnvironmentData);
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("SAM Verify Signature CMD : {0}.", BitConverter.ToString(apduCommand));
            });
            result = samApduExchange(apduCommand, apduResponse, ref apduResponseLength);
            if (result != SamAuthenticateResult.Success)
            {
                ErrorMessage = "Failed SAM Verify Signature";
                return result;
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("SAM Verify Signature RSP : {0}.", BitConverter.ToString(apduResponse, 0, apduResponseLength));
            });
            #endregion

            #region Digest Init
            apduCommand = ByteArray.Combine(samDigestInitCmdData, apduData.KIFKVCSession, apduData.OpenSecureSessionData);
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("SAM Digest Init CMD : {0}.", BitConverter.ToString(apduCommand));
            });
            result = samApduExchange(apduCommand, apduResponse, ref apduResponseLength);
            if (result != SamAuthenticateResult.Success)
            {
                ErrorMessage = "Failed SAM Digest Init";
                return result;
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("SAM Digest Init RSP : {0}.", BitConverter.ToString(apduResponse, 0, apduResponseLength));
            });
            #endregion

            #region Digest Close
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("SAM Digest Close CMD : {0}.", BitConverter.ToString(samDigestCloseCmdData));
            });
            if ((result = samApduExchange(samDigestCloseCmdData, apduResponse, ref apduResponseLength)) != SamAuthenticateResult.Success)
            {
                ErrorMessage = "Failed SAM Digest Close";
                return result;
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("SAM Digest Close RSP : {0}.", BitConverter.ToString(apduResponse, 0, apduResponseLength));
            });
            result = getData(SamAuthenticateDataType.SAM, apduResponse, 0, apduData.Challenge.Length, apduData.Challenge);
            if (result != SamAuthenticateResult.Success)
            {
                ErrorMessage = "Invalid SAM Challenge";
                return result;
            }
            #endregion

            #region Close Secure Session
            apduCommand = ByteArray.Combine(cardCloseSecureSessionCmdData, apduData.Challenge, Le);
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("CARD Close Session CMD : {0}.", BitConverter.ToString(apduCommand));
            });
            if ((result = cardApduExchange(deviceAddress, apduCommand, apduResponse, ref apduResponseLength)) != SamAuthenticateResult.Success)
            {
                ErrorMessage = "Failed Card Close Secure Session";
                return result;
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("CARD Close Session RSP : {0}.", BitConverter.ToString(apduResponse, 0, apduResponseLength));
            });
            result = getData(SamAuthenticateDataType.Card, apduResponse, 0, apduData.Challenge.Length, apduData.Challenge);
            if (result != SamAuthenticateResult.Success)
            {
                ErrorMessage = "Invalid Card Challenge";
                return result;
            }
            #endregion

            #region Digest Authenticate
            apduCommand = ByteArray.Combine(samDigestAuthenticateCmdData, apduData.Challenge);
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("SAM Digest Authenticate CMD : {0}.", BitConverter.ToString(apduCommand));
            });
            result = samApduExchange(apduCommand, apduResponse, ref apduResponseLength);

            if (result != SamAuthenticateResult.Success)
            {
                //LogMessage("SAM-CMD Digest Authenticate error: ", apduResponse, apduResponseLength);
                ErrorMessage = "Failed SAM Digest Authenticate";
                return result;
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("SAM Digest Authenticate RSP : {0}.", BitConverter.ToString(apduResponse, 0, apduResponseLength));
            });
            #endregion

            //----------------------------
            // Some additional verifications:
            // - stucture of the data
            // - validity of the data
            // - personnalisation of the data
            //----------------------------
            result = verifyDataValidity(apduData.EnvironmentData, blackList, cardDuration, currentDate);
            if (result == SamAuthenticateResult.Success || result == SamAuthenticateResult.CardBlackListedSamError)
            {
                Array.Copy(apduData.EnvironmentData, 1, badgeIdentifier, 0, badgeIdentifier.Length);
            }
            return result;
        }

        private static Random random = new Random();
        public SamAuthenticateResult GetBadgeIdentifierNoSAM(int deviceAddress, CardExchange cardApduExchange, UInt32 cardDuration,
            List<SamBlackListItem> blackList,
            DateTime currentDate, ref byte[] badgeIdentifier)
        {
            byte[] apduResponse = new byte[258];
            int apduResponseLength = 0;
            ErrorMessage = "";
            if (cardApduExchange == null)
                return SamAuthenticateResult.InternalError;

            SamAuthenticateResult result = selectApplication(cardApduExchange, deviceAddress, apduResponse, ref apduResponseLength);
            if (result != SamAuthenticateResult.Success)
                return result;

            apduData.Challenge = new byte[8];
            random.NextBytes(apduData.Challenge);

            result = openSecureSession(cardApduExchange, deviceAddress, apduResponse, ref apduResponseLength);
            if (result != SamAuthenticateResult.Success)
                return result;

            Array.Copy(apduData.EnvironmentData, 1, badgeIdentifier, 0, badgeIdentifier.Length);
            result = verifyDataValidity(apduData.EnvironmentData, blackList, cardDuration, currentDate);
            return result;
        }

        private SamAuthenticateResult selectApplication(CardExchange cardApduExchange, int deviceAddress, byte[] apduResponse, ref int apduResponseLength)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("Card SA CMD : {0}.", BitConverter.ToString(cardSelectApplicationCmdData));
            });
            SamAuthenticateResult result = cardApduExchange(deviceAddress, cardSelectApplicationCmdData, apduResponse, ref apduResponseLength);
            if (result != SamAuthenticateResult.Success)
            {
                ErrorMessage = "Failed Card Select Application";
                return result;
            }
            byte[] retFirstPart = new byte[cardSelectApplicationReplyFirstPart.Length];
            byte[] retSecondPart = new byte[cardSelectApplicationReplySecondPart.Length];
            Array.Copy(apduResponse, retFirstPart, retFirstPart.Length);
            Array.Copy(apduResponse, 16, retSecondPart, 0, retSecondPart.Length);
            int responseLength = apduResponseLength;
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("Card SA RSP : {0}.", BitConverter.ToString(apduResponse, 0, responseLength));
            });
            if (retFirstPart.SequenceEqual(cardSelectApplicationReplyFirstPart) == false || retSecondPart.SequenceEqual(cardSelectApplicationReplySecondPart) == false)
            {
                ErrorMessage = "Invalid Card Select Application Data";
                return SamAuthenticateResult.CardApduDataError;
            }
            else
            {
                result = getSerialNumber(apduResponse, apduData.CardSerialNumber);
                if (result != SamAuthenticateResult.Success)
                {
                    ErrorMessage = "Invalid Card Serial Number";
                    return result;
                }
            }
            return result;
        }

        private SamAuthenticateResult openSecureSession(CardExchange cardApduExchange, int deviceAddress, byte[] apduResponse, ref int apduResponseLength)
        {
            SamAuthenticateResult result = SamAuthenticateResult.InternalError;
            byte[] apduCommand = ByteArray.Combine(cardOpenSecureSessionCmdData, apduData.Challenge, Le);
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("CARD Open Secure Session CMD : {0}.", BitConverter.ToString(apduCommand));
            });
            if ((result = cardApduExchange(deviceAddress, apduCommand, apduResponse, ref apduResponseLength)) == SamAuthenticateResult.Success)
            {
                int responseLength = apduResponseLength;
                Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                {
                    return string.Format("CARD Open Secure Session RSP : {0}.", BitConverter.ToString(apduResponse, 0, responseLength));
                });
                byte[] cardChallenge = new byte[8];
                getData(SamAuthenticateDataType.Card, apduResponse, 0, cardChallenge.Length, cardChallenge);
                if ((result = getKIFKVCSession(apduResponse, apduData.KIFKVCSession)) == SamAuthenticateResult.Success) // Get session key
                {
                    if ((result = getKIFKVCSignature(apduResponse, apduData.KIFKVCSignature)) == SamAuthenticateResult.Success) // Get signature key
                    {
                        if ((result = getDataEnv(apduResponse, apduData.EnvironmentData)) == SamAuthenticateResult.Success)
                        {
                            result = getData(SamAuthenticateDataType.Card, apduResponse, 0, apduData.OpenSecureSessionData.Length, apduData.OpenSecureSessionData); // Get the 76 first bytes of the reply of open secure session (only the last 0x9000 is not save)
                        }
                    }
                }
            }
            if (result != SamAuthenticateResult.Success)
            {
                ErrorMessage = "Invalid Card Data";
            }

            return result;
        }
        #endregion
    }
}
