﻿using System;
using System.Collections.Generic;
using System.Text;
using Pacom.Peripheral.Common.Utils;
using Pacom.Peripheral.Common.Configuration;

namespace Pacom.Peripheral.OsdpMessaging.Apdu
{
    public enum SamAuthenticateDataType
    {
        Card = 0, SAM = 1
    }
}
