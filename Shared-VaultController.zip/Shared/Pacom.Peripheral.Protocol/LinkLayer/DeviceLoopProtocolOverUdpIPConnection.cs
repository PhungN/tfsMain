﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Cryptography;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Messaging.DeviceLoopMessages;
using System.Threading;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// The link level connection to implement the Pacom device loop protocol over IP.
    /// </summary>
    public partial class DeviceLoopProtocolOverUdpIPConnection : ProtocolConnectionBase
    {
        /// <summary>
        /// Triggered when a complete message has been received and successfully parsed. The original message
        /// can be found as a byte array, while the parsed message is available in the 'DeviceLoopMessage'
        /// element in the dictionary.
        /// </summary>
        public override event EventHandler<ReceivedDataEventArgs> DataReceived;

        /// <summary>
        /// Triggered when the connection changes state (Disconnected, Connecting, Connected)
        /// </summary>
        public override event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;

        private const int responseTimeout = 250;

        private readonly byte[] serialNumber = new byte[] { 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32 };

        private readonly FirmwareVersion applicationVersion = new FirmwareVersion("01.00");

        private readonly int unitNumber = 0;

        private DeviceLoopOverUdpIPMessageAuthenticator authenticator;
        private Dictionary<string, object> controllerSendDictionary = new Dictionary<string, object>();

        private object messageDetailsSync = new object();
        private DeviceLoopOverUdpIPMessageBase lastReceivedDataMessage;
        private byte[] lastSentMessage;
        private DateTime lastMessageReceived;
        private ManualResetEvent ackReceived = new ManualResetEvent(false);
        private UInt32 ackSequenceNumber = 0;

        private Timer onlineTimer = null;
        private int consecutiveFailedSendAttempts = 0;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="deviceRestarted">Set to true on the first instance created of this class since rebooting to indicate that the 8603 has restarted.</param>
        public DeviceLoopProtocolOverUdpIPConnection(IPAddress controllerAddress, int controllerPort)
        {
            ConnectionState = ConnectionState.Connecting;
            string serialNumber = ConfigurationManager.Instance.SerialNumber;
            if (serialNumber != null)
            {
                for (int i = 0; i < serialNumber.Length; i++)
                {
                    this.serialNumber[i] = (byte)serialNumber[i];
                }
            }

            this.applicationVersion = new FirmwareVersion(ConfigurationManager.Instance.ApplicationVersion);
            this.unitNumber = ConfigurationManager.Instance.DeviceLoopAddress(DeviceLoopAddressType.IP);
            this.lastMessageReceived = DateTime.UtcNow;
            this.authenticator = new DeviceLoopOverUdpIPMessageAuthenticator(DeviceLoopMessageBase.DeviceLoopDeviceType, this.serialNumber, unitNumber, applicationVersion);

            controllerSendDictionary.Add("RemoteEndPoint", new IPEndPoint(controllerAddress, controllerPort));

            onlineTimer = new Timer(checkForOnline, null, 30000, 30000);
        }

        private void checkForOnline(object state)
        {
            double timeSinceLastMessage = (DateTime.UtcNow - lastMessageReceived).TotalSeconds;
            if (timeSinceLastMessage >= 30 || consecutiveFailedSendAttempts >= 10)
            {
                ConnectionState = ConnectionState.Disconnected;
                if (ConnectionStateChanged != null)
                    ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Disconnected));
            }
            else if (timeSinceLastMessage < 0)
            {
                // Just incase the time has been updated.
                lastMessageReceived = DateTime.UtcNow;
            }
        }

        /// <summary>
        /// A blocking call to initiate the connection.
        /// </summary>
        /// <returns>True on success.</returns>
        public override bool Connect()
        {
            if (lowerLayerConnection.ConnectionState == ConnectionState.Connected ||
                (lowerLayerConnection.ConnectionState == ConnectionState.Connecting && lowerLayerConnection.Connect() == true))
            {
                DeviceLoopOverUdpIPMessageLogOn message = authenticator.GenerateMessageType1();
                lowerLayerConnection.Send(message.Data, controllerSendDictionary);
                return true;
            }

            return false;
        }

        /// <summary>
        /// A blocking call to send a message on the connection.
        /// The metadata dictionary is expected to contain an element named 'DeviceLoopMessage' whos value derives from the DeviceLoopMessageBase class.
        /// Alarms messages, which require a link level confirmation from the controller, will block till the link level confirmation arrives or times out.
        /// </summary>
        /// <param name="data">unused</param>
        /// <param name="metadata">Must contain an element named 'DeviceLoopMessage' whos value derives from the DeviceLoopMessageBase class.</param>
        /// <returns>True if successfully sent out on the physical connection.</returns>
        public override bool Send(byte[] data, Dictionary<string, object> metadata)
        {
            object tempObject;
            DeviceLoopMessageBase deviceLoopMessage;
            if (metadata.TryGetValue("DeviceLoopMessage", out tempObject))
                deviceLoopMessage = (DeviceLoopMessageBase)tempObject;
            else
                return false;

            DeviceLoopOverUdpIPMessageData message = null;
            lock (messageDetailsSync)
            {
                message = authenticator.GenerateMessageType4(deviceLoopMessage, lastReceivedDataMessage.ControllerSequenceNumber);

                if (message == null)
                    return false;

                ackSequenceNumber = message.DeviceSequenceNumber;
                ackReceived.Reset();
            }

            lowerLayerConnection.Send(message.Data, controllerSendDictionary);

            bool success = ackReceived.WaitOne(responseTimeout, false);
            if (success)
            {
                consecutiveFailedSendAttempts = 0;
                lastSentMessage = null;
            }
            else
            {
                consecutiveFailedSendAttempts++;
#if DEBUG
                Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                {
                    return "Timed out waiting for response.";
                });
#endif
            }
            return success;
        }

        /// <summary>
        /// Used to implement a protocol stack pattern.
        /// </summary>
        /// <param name="lowerLayerConnection">The protocol layer one layer down.</param>
        public override void SetLowerLayerConnection(ProtocolConnectionBase lowerLayerConnection)
        {
            lowerLayerConnection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(lowerLayerConnection_ConnectionStateChanged);
            lowerLayerConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(lowerLayerConnection_DataReceived);
            base.SetLowerLayerConnection(lowerLayerConnection);
        }

        void lowerLayerConnection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            try
            {
                DeviceLoopOverUdpIPMessageBase message = DeviceLoopOverUdpIPMessageBase.Create(e.Data);

                if (message == null)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                    {
                        return string.Format("Received malformed packet from {0}. {1}", ((IPEndPoint)e.Metadata["RemoteEndPoint"]).ToString(), BitConverter.ToString(e.Data));
                    });
                    return;
                }

                lock (messageDetailsSync)
                {
                    if (message.SessionId == authenticator.SessionId &&
                        lastReceivedDataMessage != null &&
                        message.ControllerSequenceNumber == lastReceivedDataMessage.ControllerSequenceNumber &&
                        message.MessageType == lastReceivedDataMessage.MessageType)
                    {
                        // This is a retransmit of the previous message. Send the previous response.
                        lowerLayerConnection.Send(lastSentMessage, e.Metadata);

                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return "Duplicate message detected.";
                        });
                        return;
                    }
                }

                if (message.MessageType == DeviceLoopOverUdpIPMessageType.Poll)
                {
                    DeviceLoopOverUdpIPMessagePoll messageType6 = (DeviceLoopOverUdpIPMessagePoll)message;
                    DeviceLoopOverUdpIPMessagePoll response = authenticator.AuthenticateMessage(messageType6);
                    if (response != null)
                    {
                        lastMessageReceived = DateTime.UtcNow;
                        lowerLayerConnection.Send(response.Data, e.Metadata);
                    }
                }
                else if (message.MessageType == DeviceLoopOverUdpIPMessageType.Data)
                {
                    DeviceLoopOverUdpIPMessageData messageType4 = (DeviceLoopOverUdpIPMessageData)message;
                    DeviceLoopMessageBase[] messages;
                    DeviceLoopOverUdpIPMessageAck response = authenticator.AuthenticateMessage(messageType4, lastReceivedDataMessage, out messages);
                    if (response != null)
                    {
                        if (message.DeviceSequenceNumber == ackSequenceNumber)
                        {
                            ackReceived.Set();
                        }

                        lock (messageDetailsSync)
                        {
                            lastMessageReceived = DateTime.UtcNow;
                            lastReceivedDataMessage = messageType4;
                            lastSentMessage = response.Data;
                        }
                        lowerLayerConnection.Send(response.Data, e.Metadata);

                        if (messages != null && messages.Length > 0)
                        {
                            if (DataReceived != null)
                            {
                                foreach (DeviceLoopMessageBase deviceLoopMessage in messages)
                                {
                                    Dictionary<string, object> d = new Dictionary<string, object>();
                                    d.Add("DeviceLoopMessage", deviceLoopMessage);
                                    DataReceived(this, new ReceivedDataEventArgs(e.Data, d));
                                }
                            }
                        }
                    }
                }
                else if (message.MessageType == DeviceLoopOverUdpIPMessageType.Ack)
                {
                    DeviceLoopOverUdpIPMessageAck messageType5 = (DeviceLoopOverUdpIPMessageAck)message;
                    if (authenticator.AuthenticateMessage(messageType5) == true && message.DeviceSequenceNumber == ackSequenceNumber)
                    {
                        ackReceived.Set();
                    }
                }
                else if (message.MessageType == DeviceLoopOverUdpIPMessageType.LogOnResponseSuccess)
                {
                    DeviceLoopOverUdpIPMessageLogOnResponseSuccess messageType2 = (DeviceLoopOverUdpIPMessageLogOnResponseSuccess)message;
                    DeviceLoopOverUdpIPMessageAck response = authenticator.AuthenticateMessage(messageType2);
                    if (response != null)
                    {
                        lock (messageDetailsSync)
                        {
                            lastMessageReceived = DateTime.UtcNow;
                            lastReceivedDataMessage = messageType2;
                            lastSentMessage = response.Data;
                        }
                        lowerLayerConnection.Send(response.Data, e.Metadata);

                        if (ConnectionState != ConnectionState.Connected)
                        {
                            ConnectionState = ConnectionState.Connected;
                            if (ConnectionStateChanged != null)
                                ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Connected));
                        }
                    }
                }
                else if (message.MessageType == DeviceLoopOverUdpIPMessageType.LogOnResponseSetMasterKey)
                {
                    DeviceLoopOverUdpIPMessageLogOnResponseSetMasterKey messageType3 = (DeviceLoopOverUdpIPMessageLogOnResponseSetMasterKey)message;
                    DeviceLoopOverUdpIPMessageLogOn response = authenticator.AuthenticateMessage(messageType3);
                    if (response != null)
                    {
                        lock (messageDetailsSync)
                        {
                            lastMessageReceived = DateTime.UtcNow;
                            lastReceivedDataMessage = messageType3;
                            lastSentMessage = response.Data;
                        }
                        lowerLayerConnection.Send(response.Data, e.Metadata);
                    }
                }
                else if (message.MessageType == DeviceLoopOverUdpIPMessageType.LogOff)
                {
                    DeviceLoopOverUdpIPMessageLogOff messageType7 = (DeviceLoopOverUdpIPMessageLogOff)message;
                    DeviceLoopOverUdpIPMessageLogOn response = authenticator.AuthenticateMessage(messageType7);
                    if (response != null)
                    {
                        lock (messageDetailsSync)
                        {
                            lastMessageReceived = DateTime.UtcNow;
                            lastReceivedDataMessage = messageType7;
                            lastSentMessage = response.Data;
                        }
                        lowerLayerConnection.Send(response.Data, e.Metadata);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                {
                    return string.Format("Failed parsing packet from {0}. {1}", ((IPEndPoint)e.Metadata["RemoteEndPoint"]).ToString(), ex);
                });
            }
        }

        void lowerLayerConnection_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (e.NewConnectionState == ConnectionState.Disconnected)
            {
                ConnectionState = ConnectionState.Disconnected;
                if (ConnectionStateChanged != null)
                    ConnectionStateChanged(this, e);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (lowerLayerConnection != null)
            {
                lowerLayerConnection.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(lowerLayerConnection_ConnectionStateChanged);
                lowerLayerConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(lowerLayerConnection_DataReceived);
            }

            if (onlineTimer != null)
            {
                onlineTimer.Dispose();
                onlineTimer = null;
            }

            if (authenticator != null)
                authenticator.Dispose();

            ackReceived.Close();

            base.Dispose(true);
        }
    }
}
