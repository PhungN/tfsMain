﻿using System;
using System.Collections.Generic;
using System.Threading;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.Common;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common.Status;
using System.Diagnostics;
using System.Net;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// RFC 5424 implementation
    /// </summary>
    public partial class SyslogProtocolConnection : ProtocolConnectionBase
    {
        /// <summary>
        /// Triggered when a complete message has been received and successfully parsed. The original message
        /// can be found as a byte array, while the parsed message is available in the 'DeviceLoopMessage'
        /// element in the dictionary.
        /// </summary>
#pragma warning disable 0067
        public override event EventHandler<ReceivedDataEventArgs> DataReceived;
#pragma warning restore 0067

        /// <summary>
        /// Triggered when the connection changes state (Disconnected, Connecting, Connected)
        /// </summary>
        public override event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;

        private Thread sendThread;
        private bool terminateSendThread = false;
        private NativeAutoResetEvent sendRequiredEvent = new NativeAutoResetEvent(false);
        private readonly Queue<LoggingEventArgs> messagesToSend = new Queue<LoggingEventArgs>();
        private string processId = Process.GetCurrentProcess().Id.ToString();
        private readonly Dictionary<string, object> endpointDictionary = new Dictionary<string, object>();

        public SyslogProtocolConnection(IPAddress syslogServerAddress)
        {
            sendThread = new Thread(new ThreadStart(sendThreadMethod));
            sendThread.Name = "Syslog Send Thread";
            sendThread.IsBackground = true;
            sendThread.Priority = ThreadPriority.Lowest;
            setHostname();
            endpointDictionary.Add("RemoteEndPoint", new IPEndPoint(syslogServerAddress, 514));
            Logger.MessageToLogAvailable += new EventHandler<LoggingEventArgs>(Logger_MessageToLogAvailable);
        }

        void Logger_MessageToLogAvailable(object sender, LoggingEventArgs e)
        {
            lock (messagesToSend)
            {
                messagesToSend.Enqueue(e);
            }
            sendRequiredEvent.Set();
        }

        private void sendThreadMethod()
        {
            try
            {
                IntPtr[] events = new IntPtr[] { sendRequiredEvent.Handle, Application.ClosingEvent };

                LoggingEventArgs messageToLog;
                while (true)
                {
                    if (NativeMethods.WaitForMultipleObjects(2, events, 0, Constants.Infinite) == 1 || terminateSendThread == true)
                        return;

                    while (true)
                    {
                        lock (messagesToSend)
                        {
                            if (messagesToSend.Count > 0)
                                messageToLog = messagesToSend.Dequeue();
                            else
                                messageToLog = null;
                        }

                        if (messageToLog != null)
                        {
                            // Construct a syslog message
                            SyslogLevel syslogLevel;

                            switch (messageToLog.Level)
                            {
                                case LoggingLevel.Critical:
                                    syslogLevel = SyslogLevel.Critical;
                                    break;
                                case LoggingLevel.Error:
                                    syslogLevel = SyslogLevel.Error;
                                    break;
                                case LoggingLevel.Warn:
                                    syslogLevel = SyslogLevel.Warning;
                                    break;
                                default:
                                    syslogLevel = SyslogLevel.Debug;
                                    break;
                            }

                            string syslogMessage = string.Format("<{0}>1 {1} {2} {3} - - - BOM{4}",
                                ((int)SyslogFacility.User) * 8 + ((int)syslogLevel), // PRI
                                DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.ffffffzzz")   // Timestamp
                                , hostname, applicationName, messageToLog.Message);

                            byte[] data = System.Text.Encoding.ASCII.GetBytes(syslogMessage);
                            lowerLayerConnection.Send(data, endpointDictionary);
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle the Error
                Logger.LogErrorMessage(LoggerClassPrefixes.SysLogManager, () =>
                {
                    return string.Format("Processing thread terminated unexpectedly. {0}", ex.Message);
                });
            }
        }

        /// <summary>
        /// Used to implement a protocol stack pattern.
        /// </summary>
        /// <param name="lowerLayerConnection">The protocol layer one layer down.</param>
        public override void SetLowerLayerConnection(ProtocolConnectionBase lowerLayerConnection)
        {
            base.SetLowerLayerConnection(lowerLayerConnection);
        }

        /// <summary>
        /// A blocking call to initiate the connection.
        /// </summary>
        /// <returns>True on success.</returns>
        public override bool Connect()
        {
            try
            {
                if (terminateSendThread == false)
                {
                    bool result = lowerLayerConnection.Connect();
                    if (result == true)
                    {
                        if (ConnectionStateChanged != null)
                            ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Connected));
                        sendThread.Start();
                        return true;
                    }
                }
            }
            catch
            {
            }
            return false;
        }

        /// <summary>
        /// Returns false.
        /// </summary>
        /// <param name="data">unused</param>
        /// <param name="metadata">unused</param>
        /// <returns>False</returns>
        public override bool Send(byte[] data, Dictionary<string, object> metadata)
        {
            return false;
        }

        bool disposed = false;
        protected override void Dispose(bool disposing)
        {
            if (disposed == false)
            {
                if (disposing)
                {
                    terminateSendThread = true;
                    Logger.MessageToLogAvailable -= new EventHandler<LoggingEventArgs>(Logger_MessageToLogAvailable);

                    if (sendRequiredEvent != null)
                    {
                        sendRequiredEvent.Set();

                        try
                        {
                            sendThread.JoinOrRestart(10000);
                        }
                        catch (ThreadStateException)
                        {
                            Logger.LogErrorMessage(LoggerClassPrefixes.SysLogManager, () =>
                            {
                                return "The thread has not yet started.";
                            });
                        }
                        sendRequiredEvent.Close();
                        sendRequiredEvent = null;
                    }
                }
                disposed = true;
            }
            base.Dispose(disposing);
        }
    }
}

