﻿using System;
using Pacom.Peripheral.OsdpMessaging;

namespace Pacom.Peripheral.Protocol
{
    public partial class OsdpDeviceLoopProtocolMasterConnection
    {
        internal void PrepareForResponse()
        {
            messageResponseData = null;
            messageResponseReceivedEvent.Reset();
        }

        internal OsdpDeviceResponse WaitForResponse<T>(OsdpDeviceLoopDevice deviceItem, int responseTimeOut, out T messageReply) where T : OsdpMessageBase
        {
            return waitForResponse<T>(true, deviceItem, responseTimeOut, out messageReply);
        }

        internal OsdpDeviceResponse WaitForResponseWithoutEncryption<T>(OsdpDeviceLoopDevice deviceItem, int responseTimeOut, out T messageReply) where T : OsdpMessageBase
        {
            return waitForResponse<T>(false,deviceItem, responseTimeOut, out messageReply);
        }

        private OsdpDeviceResponse waitForResponse<T>(bool useEncryption, OsdpDeviceLoopDevice deviceItem, int responseTimeOut, out T messageReply) where T : OsdpMessageBase
        {
            if (useEncryption == true && IsEncryptionKeyValid && deviceItem.CryptoSession.SessionEncryptionKey == null)
            {
                messageReply = null;
                return OsdpDeviceResponse.NoResponse;
            }

            // Wait here for response message
            if (messageResponseReceivedEvent.WaitOne(responseTimeOut, false) == true)
            {
                // Message received
                if (messageResponseData != null)
                {
                    // Decrypt the message
                    OsdpMessageBase receivedReply;
                    if (useEncryption == true && deviceItem.CryptoSession.SessionEncryptionKey != null)
                    {
                        receivedReply = OsdpMessageBase.Parse(messageResponseData, deviceItem.CryptoSession);
                    }
                    else
                    {
                        receivedReply = OsdpMessageBase.Parse(messageResponseData, null);
                    }
                    // Check if message is unknown or null
                    if (receivedReply == null)
                    {
                        messageReply = null;
                        return OsdpDeviceResponse.NoResponse;
                    }
                    if (receivedReply.MessageFunctionCode == BusyReply.FunctionCode)
                    {
                        messageReply = null;
                        return OsdpDeviceResponse.Busy;
                    }
                    // Check if received with expected sequence number 
                    if (receivedReply.Sequence != deviceItem.ReceiveSequenceNumber)
                    {
                        response = receivedReply;
                        messageReply = null;
                        return OsdpDeviceResponse.DeviceOutOfSequence;
                    }
                    deviceItem.ResetBusyTimeout();
                    deviceItem.ResetCommandRetryCounter();
                    // Decide if reply satisfies the requested response type
                    if (receivedReply is T)
                    {
                        response = receivedReply;
                        messageReply = (T)receivedReply;                            
                        return OsdpDeviceResponse.Ok;
                    }
                    else
                    {
                        response = receivedReply;
                        messageReply = null;
                        return OsdpDeviceResponse.InvalidResponse;
                    }
                }
                else
                {
                    // Response has been received but the message is empty
                    messageReply = null;
                    return OsdpDeviceResponse.NoResponse;
                }
            }
            else
            {
                // Time out
                messageReply = null;
                return OsdpDeviceResponse.NoResponse;
            }
        }

        private OsdpMessageBase response = null;

        public OsdpMessageBase Response
        {
            get { return response; }
        }
    }
}
