﻿using System;
using System.Collections.Generic;
using System.Threading;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Messaging.DeviceLoopMessages;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// The link level connection to implement the Pacom device loop protocol over IP.
    /// </summary>
    public partial class DeviceLoopProtocolOverIPConnection : ProtocolConnectionBase
    {
        /// <summary>
        /// Triggered when a complete message has been received and successfully parsed. The original message
        /// can be found as a byte array, while the parsed message is available in the 'DeviceLoopMessage'
        /// element in the dictionary.
        /// </summary>
        public override event EventHandler<ReceivedDataEventArgs> DataReceived;

        /// <summary>
        /// Triggered when the connection changes state (Disconnected, Connecting, Connected)
        /// </summary>
        public override event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;

        private const int responseTimeout = 5000;

        private readonly DeviceLoopProtocolOverIPFifo fifo;
        private int lastTxSequence = 0;
        private int lastRxSequence = 0;
        private readonly byte[] serialNumber = new byte[] { 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32 };

        private readonly FirmwareVersion applicationVersion = new FirmwareVersion("01.00");
        private readonly FirmwareVersion bootloaderVersion = new FirmwareVersion("01.00");
        private readonly FirmwareVersion osVersion = new FirmwareVersion("01.00");

        private readonly int unitNumber = 0;
        private ManualResetEvent receivedResposeReply = new ManualResetEvent(false);
        private bool deviceRestarted;
        private Timer keepAliveTimer = null;
        private TimeLimit lastMessageReceived = new TimeLimit();

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="deviceRestarted">Set to true on the first instance created of this class since rebooting to indicate that the device has restarted.</param>
        public DeviceLoopProtocolOverIPConnection(bool deviceRestarted)
        {
            ConnectionState = ConnectionState.Connecting;
            fifo = new DeviceLoopProtocolOverIPFifo(1000, true);
            fifo.MessageAvailable += new EventHandler<ReceivedDataEventArgs>(fifo_MessageAvailable);

            string serialNumber = ConfigurationManager.Instance.SerialNumber;
            if (serialNumber != null)
            {
                for (int i = 0; i < serialNumber.Length; i++)
                {
                    this.serialNumber[i] = (byte)serialNumber[i];
                }
            }

            this.applicationVersion = new FirmwareVersion(ConfigurationManager.Instance.ApplicationVersion);
            this.bootloaderVersion = new FirmwareVersion(ConfigurationManager.Instance.BootloaderVersion);
            this.osVersion = new FirmwareVersion(ConfigurationManager.Instance.OSVersion);
            this.unitNumber = ConfigurationManager.Instance.DeviceLoopAddress(DeviceLoopAddressType.IP);
            this.lastMessageReceived.Reset();
            this.deviceRestarted = deviceRestarted;
        }

        void fifo_MessageAvailable(object sender, ReceivedDataEventArgs e)
        {
            lastMessageReceived.Reset();
            DeviceLoopOverIPMessage message = new DeviceLoopOverIPMessage(e.Data);
            if (ConnectionState != ConnectionState.Connected)
            {
                ConnectionState = ConnectionState.Connected;
                if (ConnectionStateChanged != null)
                    ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState));
            }

            lastRxSequence = message.TransmitSequenceNumber;

            if ((message.ControlFlags & ControlFlags.ResponseRequired) != 0)
            {
                DeviceLoopOverIPMessage response = new DeviceLoopOverIPMessage(DeviceLoopMessageBase.DeviceLoopDeviceType, serialNumber, unitNumber, applicationVersion, ControlFlags.ResponseReply, null);
                lastTxSequence++;
                response.TransmitSequenceNumber = lastTxSequence;
                response.ReceiveSequenceNumber = lastRxSequence;
                lowerLayerConnection.Send(response.GetEncryptedData(), blankDictionary);
            }
            if ((message.ControlFlags & ControlFlags.ResponseReply) != 0)
                receivedResposeReply.Set();

            DeviceLoopMessageBase[] messages = message.GetMessages();
            if (messages != null)
            {
                if (messages.Length > 0)
                {
                    if (DataReceived != null)
                    {
                        foreach (DeviceLoopMessageBase deviceLoopMessage in messages)
                        {
                            Dictionary<string, object> d = new Dictionary<string, object>();
                            d.Add("DeviceLoopMessage", deviceLoopMessage);
                            DataReceived(this, new ReceivedDataEventArgs(e.Data, d));
                        }
                    }
                }
                else
                {
                    // Controller keep alive is an empty header without messages. Respond with keep alive from the device.
                    enqueueKeepAlive();
                }
            }
        }

        /// <summary>
        /// A blocking call to initiate the connection.
        /// </summary>
        /// <returns>True on success.</returns>
        public override bool Connect()
        {
            return lowerLayerConnection.Connect();
        }

        /// <summary>
        /// A blocking call to send a message on the connection.
        /// The metadata dictionary is expected to contain an element named 'DeviceLoopMessage' whos value derives from the DeviceLoopMessageBase class.
        /// Alarms messages, which require a link level confirmation from the controller, will block till the link level confirmation arrives or times out.
        /// </summary>
        /// <param name="data">unused</param>
        /// <param name="metadata">Must contain an element named 'DeviceLoopMessage' whos value derives from the DeviceLoopMessageBase class.</param>
        /// <returns>True if successfully sent out on the physical connection.</returns>
        public override bool Send(byte[] data, Dictionary<string, object> metadata)
        {
            object tempObject;
            bool result = false;
            bool responseRequired = false;
            DeviceLoopMessageBase deviceLoopMessage;
            if (metadata.TryGetValue("DeviceLoopMessage", out tempObject))
                deviceLoopMessage = (DeviceLoopMessageBase)tempObject;
            else
                return false;

            ControlFlags flags = ControlFlags.None;
            if (deviceLoopMessage != null)
            {
                responseRequired = isMessageResponseRequired(deviceLoopMessage);
                if (responseRequired)
                {
                    receivedResposeReply.Reset();
                    DeviceLoopOverIPMessage deviceLoopOverIPMessage = new DeviceLoopOverIPMessage(DeviceLoopMessageBase.DeviceLoopDeviceType, serialNumber, unitNumber, applicationVersion, flags | ControlFlags.ResponseRequired, new DeviceLoopMessageBase[] { deviceLoopMessage });
                    if (lowerLayerConnection.Send(deviceLoopOverIPMessage.GetEncryptedData(), blankDictionary))
                    {
                        if (receivedResposeReply.WaitOne(responseTimeout, false))
                            result = true;
                    }
                }
                else
                {
                    DeviceLoopOverIPMessage deviceLoopOverIPMessage = new DeviceLoopOverIPMessage(DeviceLoopMessageBase.DeviceLoopDeviceType, serialNumber, unitNumber, applicationVersion, flags, new DeviceLoopMessageBase[] { deviceLoopMessage });
                    result = lowerLayerConnection.Send(deviceLoopOverIPMessage.GetEncryptedData(), blankDictionary);
                }
            }

            if (result)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                {
                    return "Sent on IP successfully";
                });
            }
            else
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                {
                    return "Failed sending on IP";
                });
            }

            return result;
        }

        private void sendKeepAlive(object state)
        {
            if (lastMessageReceived.IsTimeUp(180000))
            {
                if (keepAliveTimer != null)
                {
                    keepAliveTimer.Dispose();
                    keepAliveTimer = null;
                }
                ConnectionState = ConnectionState.Disconnected;
                if (ConnectionStateChanged != null)
                    ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Disconnected));
            }
            else
            {
                enqueueKeepAlive();
            }
        }

        private void enqueueKeepAlive()
        {
            DeviceLoopOverIPMessage keepAliveMessage = new DeviceLoopOverIPMessage(DeviceLoopMessageBase.DeviceLoopDeviceType, serialNumber, unitNumber, applicationVersion, ControlFlags.None, null);
            lastTxSequence++;
            keepAliveMessage.TransmitSequenceNumber = lastTxSequence;
            keepAliveMessage.ReceiveSequenceNumber = lastRxSequence;
            lowerLayerConnection.Send(keepAliveMessage.GetEncryptedData(), blankDictionary);
        }

        /// <summary>
        /// Used to implement a protocol stack pattern.
        /// </summary>
        /// <param name="lowerLayerConnection">The protocol layer one layer down.</param>
        public override void SetLowerLayerConnection(ProtocolConnectionBase lowerLayerConnection)
        {
            lowerLayerConnection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(lowerLayerConnection_ConnectionStateChanged);
            lowerLayerConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(lowerLayerConnection_DataReceived);
            base.SetLowerLayerConnection(lowerLayerConnection);
        }

        void lowerLayerConnection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            fifo.Enqueue(e.Data, 0, e.Data.Length);
        }

        void lowerLayerConnection_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (e.NewConnectionState == ConnectionState.Disconnected)
            {
                if (keepAliveTimer != null)
                {
                    keepAliveTimer.Dispose();
                    keepAliveTimer = null;
                }
                ConnectionState = ConnectionState.Disconnected;
                if (ConnectionStateChanged != null)
                    ConnectionStateChanged(this, e);
            }
            else if (e.NewConnectionState == ConnectionState.Connected)
            {
                ControlFlags flags = ControlFlags.None;
                if (deviceRestarted)
                    flags |= ControlFlags.DeviceRestarted;
                flags |= ControlFlags.PortReconnected;
                deviceRestarted = false;
                DeviceLoopOverIPMessage versionMessage = getMessageVersion(flags);

                lastTxSequence++;
                versionMessage.TransmitSequenceNumber = lastTxSequence;
                versionMessage.ReceiveSequenceNumber = lastRxSequence;
                lowerLayerConnection.Send(versionMessage.GetEncryptedData(), blankDictionary);
                keepAliveTimer = new Timer(sendKeepAlive, null, 10000, 10000);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (lowerLayerConnection != null)
            {
                lowerLayerConnection.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(lowerLayerConnection_ConnectionStateChanged);
                lowerLayerConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(lowerLayerConnection_DataReceived);
            }
            if (keepAliveTimer != null)
            {
                keepAliveTimer.Dispose();
                keepAliveTimer = null;
            }
            receivedResposeReply.Close();
            base.Dispose(true);
        }
    }
}
