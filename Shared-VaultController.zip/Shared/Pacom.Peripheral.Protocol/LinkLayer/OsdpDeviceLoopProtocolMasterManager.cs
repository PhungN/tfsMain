﻿using System;

namespace Pacom.Peripheral.Protocol
{
    public sealed class OsdpDeviceLoopProtocolMasterManager : IDisposable
    {
        public OsdpDeviceLoopProtocolMasterConnection CreateConnection(byte[] sessionKey)
        {
            return new OsdpDeviceLoopProtocolMasterConnection(sessionKey);
        }
        
        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}
