﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// A factory that produces DeviceLoopProtocolConnection instances.
    /// </summary>
    public sealed class DeviceLoopProtocolManager : IDisposable
    {
        /// <summary>
        /// Produces a new DeviceLoopProtocolConnection instance.
        /// </summary>
        /// <returns>A new DeviceLoopProtocolConnection instance.</returns>
        public DeviceLoopProtocolConnection CreateConnection(int baudRate)
        {
            return new DeviceLoopProtocolConnection(baudRate);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}
