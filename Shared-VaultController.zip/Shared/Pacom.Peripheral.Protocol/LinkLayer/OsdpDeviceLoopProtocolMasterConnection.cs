﻿using System;
using System.Collections.Generic;
using System.Threading;
using Pacom.Configuration.ConfigurationCommon;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.OsdpMessaging;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Common.Utils;
using System.IO.Ports;

namespace Pacom.Peripheral.Protocol
{
    public partial class OsdpDeviceLoopProtocolMasterConnection : ProtocolConnectionBase
    {
        public int minDelayBetweenDeviceCalls = 50;      // Sleep duration after polling all devices
        public int minDelayAfterReply = 10;
        private const int maximumCommandsPerCycle = 5;

        private int onlineDeviceReplyTimeout;
        private int offlineDeviceReplyTimeout;
        public const int ignoreDeviceAfterErrorsTimeout = 15000;

        public const int NumberOfDevices = 4;
        private readonly OsdpDeviceLoopDeviceList deviceList = new OsdpDeviceLoopDeviceList(NumberOfDevices);

        private AutoResetEvent lowerLayerConnectedEvent = new AutoResetEvent(false);
        private AutoResetEvent configurationChangedEvent = new AutoResetEvent(false);

        private OsdpDeviceLoopProtocolFifo fifo = null;

        private Thread mainPollingThread = null;

        private bool isSamStarted = false;
        private bool isSmartCardReader = false;

        TimeLimit sendMessageDelayAfterReply = new TimeLimit();

        private IPacomTimer securedSessionsRestartTimer = null;
        private bool securedSessionsRestart = false;
        private bool sendingOfPaddingRequired = false;

        /// <summary>
        /// Triggered when a complete message has been received and successfully parsed. The original message
        /// can be found as a byte array, while the parsed message is available in the 'DeviceLoopMessage'
        /// element in the dictionary.
        /// </summary>
        public override event EventHandler<ReceivedDataEventArgs> DataReceived;

        /// <summary>
        /// Triggered when the connection changes state (Disconnected, Connecting, Connected)
        /// </summary>
        public override event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;

        /// <summary>
        /// Secure Channel Base Key use for this connection (port)
        /// </summary>
        private readonly byte[] encryptionKey = null;

        protected bool IsEncryptionKeyValid
        {
            get { return (encryptionKey != null && encryptionKey.Length == 16); }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serialPortNumber"></param>
        public OsdpDeviceLoopProtocolMasterConnection(byte[] encryptionKey)
        {
            onlineDeviceReplyTimeout = 2000;
            offlineDeviceReplyTimeout = 400;

            this.encryptionKey = encryptionKey;

            fifo = new OsdpDeviceLoopProtocolFifo();
            fifo.MessageAvailable += new EventHandler<ReceivedDataEventArgs>(fifo_MessageAvailable);

            mainPollingThread = new Thread(new ThreadStart(osdpConnectionManagerThreadMethod));
            mainPollingThread.Name = "OSDP Device Loop Protocol Master Thread";
            mainPollingThread.IsBackground = true;
            mainPollingThread.Priority = ThreadPriority.Normal;
            mainPollingThread.Start();

            securedSessionsRestartTimer = TimerManager.Instance.CreateTimer(_ => { securedSessionsRestart = true; }, null, 12 * 60 * 60 * 1000, 12 * 60 * 60 * 1000);
        }

        public override void SetLowerLayerConnection(ProtocolConnectionBase lowerLayerConnection)
        {
            lowerLayerConnection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(lowerLayerConnection_ConnectionStateChanged);
            lowerLayerConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(lowerLayerConnection_DataReceived);
            base.SetLowerLayerConnection(lowerLayerConnection);
        }

        private string getUnderlayingCommPortName()
        {
            SerialConnectionBase commBase = lowerLayerConnection as SerialConnectionBase;
            if (commBase == null)
                return "[Not assigned]";
            return commBase.PortName;
        }

        public void SetConfiguration(int deviceId, int logicalReaderId)
        {
            deviceList[deviceId] = new OsdpDeviceLoopDevice(deviceId, logicalReaderId);
            if (IsEncryptionKeyValid)
                deviceList[deviceId].CryptoSession.EncryptionKey = this.encryptionKey;
        }

        public override bool Connect()
        {
            return lowerLayerConnection.Connect();
        }
        
        public bool IsOnline(int deviceAddress)
        {
            if (deviceAddress < NumberOfDevices && deviceList[deviceAddress] != null)
                return deviceList[deviceAddress].IsOnline;
            return false;
        }

        private void osdpConnectionManagerThreadMethod()
        {
            try
            {
                // Wait here for the lower layer
                lowerLayerConnectedEvent.WaitOne();

                // Allow quick exit out of the thread when application is closing for some unknown reason
                if (Application.Closing == true || this.disposing == true)
                    return;

                Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                {
                    return string.Format("Processing thread starts for port {0}.", getUnderlayingCommPortName());
                });

                sendMessageDelayAfterReply.Reset();

                // Assure the main OSDP loop does not go idle
                TimeLimit lineMinBusyTime = new TimeLimit();
                // Handle devices state, make them go online
                osdpConnectionClosedWait.Reset();
                while (Application.Closing == false && this.disposing == false && osdpConnectionClosed == false)
                {
                    if (deviceList.IsEmpty)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                        {
                            return "No devices found. Waiting for configuration changes.";
                        });
                        configurationChangedEvent.WaitOne();
                        lineMinBusyTime.Reset();
                        continue;
                    }

                    // Assure the main OSDP thread does go to sleep for at least the specified time below
                    int timeToSleep = minDelayBetweenDeviceCalls - lineMinBusyTime.ElapsedTime;
                    if (timeToSleep < 30)
                        timeToSleep = 30;

                    Thread.Sleep(timeToSleep);
                    lineMinBusyTime.Reset();
                    // Query OSDP devices. Begin secure connection.
                    for (int iDeviceAddress = 0; iDeviceAddress < NumberOfDevices; iDeviceAddress++)
                    {
                        if (securedSessionsRestart == true)
                        {
                            securedSessionsRestart = false;
                            for (int deviceAddress = 0; deviceAddress < NumberOfDevices; deviceAddress++)
                            {
                                if (deviceList[deviceAddress] != null)
                                {
                                    deviceList[deviceAddress].SecuredSessionRestart = true;
                                    deviceRestart(deviceAddress);
                                }
                            }
                            break;
                        }

                        if (deviceList[iDeviceAddress] == null)
                            continue;

                        try
                        {
                            if (deviceList[iDeviceAddress].IsDeviceSkipped == false)
                                processDeviceState(iDeviceAddress, null);
                        }
                        catch (Exception ex)
                        {
                            Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, () =>
                            {
                                return string.Format("Unexpected error occurred during processing device {0}. {1}", iDeviceAddress, ex.Message);
                            });
                            deviceRestart(iDeviceAddress, ignoreDeviceAfterErrorsTimeout);
                        }
                    }
                }
                // Shutdown OSDP connection. Disable reader peripherals.
                Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, () =>
                {
                    return string.Format("Shutting down OSDP connection for port {0}.", getUnderlayingCommPortName());
                });
                if (Application.Closing == false)
                {
                    for (int iDeviceAddress = 0; iDeviceAddress < NumberOfDevices; iDeviceAddress++)
                    {
                        OsdpDeviceLoopDevice osdpDevice = deviceList[iDeviceAddress];
                        if (osdpDevice == null || osdpDevice.Step != OsdpDeviceLifeStep.DeviceOnline)
                            continue;
                        if (osdpDevice.CommandsToSendPending() > 3)
                            continue;
                        try
                        {
                            // Turn off LED 0
                            deviceList[iDeviceAddress].QueueLedOn(OsdpMessaging.LedColor.Black);
                            // Turn off buzzer
                            deviceList[iDeviceAddress].QueueBuzzerOff();
                            // Process last commands

                            for (int i = 0; i < 5; i++)
                            {
                                bool isPollCommand = false;
                                PrepareForResponse();
                                OsdpMessageBase commandToBeSent = osdpDevice.CommandsToSendPeek(out isPollCommand);
                                if (isPollCommand)
                                    break;
                                OsdpDeviceResponse result = executeCommand(iDeviceAddress, isPollCommand, commandToBeSent);
                                if (result != OsdpDeviceResponse.Ok)
                                    break;
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, () =>
                            {
                                return string.Format("Unexpected error occurred during shutting down peripherals for device {0}. {1}", iDeviceAddress, ex.Message);
                            });
                            deviceRestart(iDeviceAddress, ignoreDeviceAfterErrorsTimeout);
                        }
                    }
                    // Send last commands for this session. Invalidate secure connections.
                    for (int iDeviceAddress = 0; iDeviceAddress < NumberOfDevices; iDeviceAddress++)
                    {
                        if (deviceList[iDeviceAddress] == null)
                            continue;
                        try
                        {
                            closeDeviceState(iDeviceAddress);
                        }
                        catch (Exception ex)
                        {
                            Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, () =>
                            {
                                return string.Format("Unexpected error occurred during closing device {0}. {1}", iDeviceAddress, ex.Message);
                            });
                            deviceRestart(iDeviceAddress, ignoreDeviceAfterErrorsTimeout);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle the Error
                Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, () =>
                {
                    return string.Format("Processing thread terminated unexpectedly. {0}", ex.Message);
                });
            }
            finally
            {
                osdpConnectionClosedWait.Set();
            }
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("Processing thread stops for port {0}.", getUnderlayingCommPortName());
            });
            mainPollingThread = null;
        }

        private void closeDeviceState(int deviceAddress)
        {
            if (deviceList[deviceAddress].CryptoSession.SessionEncryptionKey != null)
            {
                PrepareForResponse();
                // Send command
                deviceList[deviceAddress].InvalidateEncryptionSession();
                PollCommand pollCommand = deviceList[deviceAddress].PollCommand();
                for (int iReapeat = 0; iReapeat < 5; iReapeat++)
                {
                    if (lowerLayerConnection == null || SendOSDPMessage(pollCommand.Message(deviceList[deviceAddress].CryptoSession)) == false)
                    {
                        // Data corruption or serial already closed
                        continue;
                    }
                    // Wait for specific reply
                    OsdpMessageBase pollReply = null;
                    switch (WaitForResponseWithoutEncryption<OsdpMessageBase>(deviceList[deviceAddress], onlineDeviceReplyTimeout, out pollReply))
                    {
                        case OsdpDeviceResponse.Ok:
                        case OsdpDeviceResponse.Busy:
                        case OsdpDeviceResponse.DeviceOutOfSequence:
                        case OsdpDeviceResponse.InvalidResponse:
                        case OsdpDeviceResponse.NoResponse:
                            return;
                    }
                }
                deviceList[deviceAddress].CryptoSession.Reset();
            }
        }

        private void processDeviceState(int deviceAddress, Queue<OsdpMessageBase> commands)
        {
            OsdpDeviceLoopDevice osdpDevice = deviceList[deviceAddress];
            bool success = false;
            switch (osdpDevice.Step)
            {
                case OsdpDeviceLifeStep.DeviceOffline:
                    {
                        if (osdpDevice.IsOfflineTimeoutUp == true)
                        {
                            osdpDevice.Step = OsdpDeviceLifeStep.DeviceNotDiscovered;
                            osdpDevice.CryptoSession.Reset();
                            osdpDevice.ResetSequence();
                            osdpDevice.ResetBusyTimeout();
                            osdpDevice.ResetCommandRetryCounter();
                            fifo.Reset();
                        }
                    }
                    break;

                case OsdpDeviceLifeStep.DeviceNotDiscovered:
                    {
                        IdCommand idCommand = osdpDevice.IdCommand();
                        PrepareForResponse();
                        if (sendCommand(osdpDevice, idCommand.Message(osdpDevice.CryptoSession)) == false)
                            return;

                        // Wait for specific reply
                        IdReply replyId = null;
                        switch (WaitForResponseWithoutEncryption(osdpDevice, offlineDeviceReplyTimeout, out replyId))
                        {
                            case OsdpDeviceResponse.Ok:
                                osdpDevice.IncrementReceiveSequence();
                                bool deviceDetectedNew = false;
                                bool deviceDetectedSame = false;
                                bool deviceDetectedSubstituted = false;
                                // Process device id, check device substitution
                                if (osdpDevice.IsDeviceIdSet)
                                {
                                    if (osdpDevice.SameDevice(replyId))
                                    {
                                        // Same device
                                        deviceDetectedSame = true;
                                    }
                                    else
                                    {
                                        // Send device substitution event
                                        deviceDetectedSubstituted = true;
                                    }
                                }
                                else
                                {
                                    deviceDetectedNew = true;
                                }
                                if (deviceDetectedNew || deviceDetectedSubstituted || deviceDetectedSame)
                                {
                                    osdpDevice.SetDeviceId(replyId);

                                    var readerStatus = StatusManager.Instance.Readers[osdpDevice.LogicalReaderId];
                                    if (readerStatus != null)
                                    {
                                        readerStatus.Manufacturer = (ReaderManufacturer)replyId.Vendor;
                                        readerStatus.Model = replyId.Model.ToString();
                                        readerStatus.HardwareRevision = replyId.Version.ToString();
                                        if (replyId.SerialNumber != 0)
                                        {
                                            readerStatus.SerialNumber = replyId.SerialNumber.ToString();
                                        }
                                        else
                                        {
                                            readerStatus.SerialNumber = "";
                                        }
                                        readerStatus.FirmwareVersion = replyId.FirmwareVersion.ToString();
                                        readerStatus.Interface |= CardReaderInterface.Osdp;
                                    }

                                    Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                                    {
                                        string reasonMessage = string.Empty;
                                        if (deviceDetectedNew)
                                            reasonMessage = "New device detected.";
                                        else if (deviceDetectedSame)
                                            reasonMessage = "Device reconnected.";
                                        else if (deviceDetectedSubstituted)
                                            reasonMessage = "Device reconnected and substituted.";
                                        else
                                            reasonMessage = "Device detected.";

                                        return string.Format("{0} Address: {1}, Vendor: {2}, Version: {3}, Serial: {4}, Firmware: {5}.{6}.{7}",
                                            reasonMessage, deviceAddress, replyId.Vendor.ToString(), replyId.Version, replyId.SerialNumber,
                                            replyId.FirmwareVersion.Major, replyId.FirmwareVersion.Minor, replyId.FirmwareVersion.Build);
                                    });

                                    osdpDevice.Step = OsdpDeviceLifeStep.RequestDeviceCapabilities;
                                }
                                break;
                            case OsdpDeviceResponse.Busy:
                                evaluateDeviceBusyState(deviceAddress);
                                break;
                            case OsdpDeviceResponse.DeviceOutOfSequence:
                                onDeviceOutOfSequence(deviceAddress);
                                break;
                            case OsdpDeviceResponse.InvalidResponse:
                                if (Response.MessageFunctionCode == NackReply.FunctionCode)
                                {
                                    NackReply replyNak = (NackReply)Response;
                                    if (replyNak.Error == NackErrorCode.CheckSumOrCrcError)
                                    {
                                        Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                                        {
                                            return string.Format("Device {0} on {1} does not accept CS as message check. Try with CRC.", deviceAddress, getUnderlayingCommPortName());
                                        });
                                        osdpDevice.UseCrc = !osdpDevice.UseCrc;
                                        osdpDevice.IncrementReceiveSequence();
                                    }
                                    else
                                    {
                                        Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                                        {
                                            return string.Format("Device {0} on {1} did not acknowledge command. Error code {2}.", deviceAddress, getUnderlayingCommPortName(), replyNak.Error.ToString());
                                        });
                                        deviceRestart(deviceAddress, ignoreDeviceAfterErrorsTimeout);
                                    }
                                }
                                else
                                {
                                    Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                                    {
                                        return string.Format("Device {0} on {1} responded with unknown reply while getting id.", deviceAddress, getUnderlayingCommPortName());
                                    });
                                    deviceRestart(deviceAddress, ignoreDeviceAfterErrorsTimeout);
                                }
                                break;
                            case OsdpDeviceResponse.NoResponse:
                                osdpDevice.SecuredSessionRestart = false;
#if CONTROLLER
                                Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                                {
                                    return string.Format("Device {0} on {1} did not responded within given time while getting id.", deviceAddress, getUnderlayingCommPortName());
                                });
#endif
                                deviceRestart(deviceAddress, ignoreDeviceAfterErrorsTimeout);
                                break;
                        }
                    }
                    break;

                case OsdpDeviceLifeStep.RequestDeviceCapabilities:
                    {
                        CapabilitiesCommand capabilitiesCommand = osdpDevice.CapabilitiesCommand();
                        PrepareForResponse();
                        if (sendCommand(osdpDevice, capabilitiesCommand.Message(osdpDevice.CryptoSession)) == false)
                            return;

                        CapabilitiesReply capabilitiesReply = null;
                        switch (WaitForResponseWithoutEncryption(osdpDevice, onlineDeviceReplyTimeout, out capabilitiesReply))
                        {
                            case OsdpDeviceResponse.Ok:
                                osdpDevice.IncrementReceiveSequence();
                                // CRC calculation
                                Capability capability;
                                if (capabilitiesReply.Capabilities.TryGetValue(FeatureCode.CrcSupport, out capability))
                                {
                                    if (capability.Compliance == 1) // CRC is supported
                                        osdpDevice.UseCrc = true;
                                }
                                // Secure Session
                                if (capabilitiesReply.Capabilities.TryGetValue(FeatureCode.CommSecurity, out capability))
                                {
                                    if (capability.Compliance == 1) // AES128 is supported
                                        osdpDevice.SupportsSecureChannel = true;
                                }
                                // Mutual Authentication
                                if (capabilitiesReply.Capabilities.TryGetValue(FeatureCode.SmartCardSupport, out capability))
                                {
                                    if (capability.Compliance == 1) // TransparentMode is supported
                                    {
                                        isSmartCardReader = true;
                                        if (isSamStarted == false)
                                            isSamStarted = initializeSam();
                                    }

                                }
                                osdpDevice.Step = OsdpDeviceLifeStep.ReadyToGoOnline;
                                break;
                            case OsdpDeviceResponse.Busy:
                                evaluateDeviceBusyState(deviceAddress);
                                break;
                            case OsdpDeviceResponse.DeviceOutOfSequence:
                                onDeviceOutOfSequence(deviceAddress);
                                break;
                            case OsdpDeviceResponse.InvalidResponse:
                                Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                                {
                                    return string.Format("Device {0} on {1} responded with unknown reply while getting capabilities.", deviceAddress, getUnderlayingCommPortName());
                                });
                                deviceRestart(deviceAddress, ignoreDeviceAfterErrorsTimeout);
                                break;
                            case OsdpDeviceResponse.NoResponse:
                                Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                                {
                                    return string.Format("Device {0} on {1} did not responded within given time while getting capabilities.", deviceAddress, getUnderlayingCommPortName());
                                });
                                deviceRestart(deviceAddress, ignoreDeviceAfterErrorsTimeout);
                                break;
                        }
                    }
                    break;

                case OsdpDeviceLifeStep.ReadyToGoOnline:
                    {
                        // When base key is setup for the connection, all devices must use encrypted channel
                        if (IsEncryptionKeyValid == false)
                            osdpDevice.Step = OsdpDeviceLifeStep.DeviceOnlineFirstTime;
                        else
                        {
                            if (osdpDevice.SupportsSecureChannel == false)
                            {
                                // Device does not support secure channel but the channel key is set
                                Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                                {
                                    return string.Format("Device {0} on {1} does not support secure channel. This connection only accepts devices with secure channel.", deviceAddress, getUnderlayingCommPortName());
                                });
                                removeDevice(deviceAddress);
                                return;
                            }
                            else
                            {
                                osdpDevice.Step = OsdpDeviceLifeStep.EstablishSecureSessionStep1;
                            }
                        }
                    }
                    break;

                case OsdpDeviceLifeStep.EstablishSecureSessionStep1:
                    {
                        // Consume entropy and send it to the device
                        SessionInitiationStep1Command sessionInitiationCommand = osdpDevice.SessionInitiationStep1Command(this.encryptionKey);
                        PrepareForResponse();
                        if (sendCommand(osdpDevice, sessionInitiationCommand.Message(osdpDevice.CryptoSession)) == false)
                            return;

                        // Wait for specific reply
                        SessionInitiationStep2Reply osdpReply = null;
                        processOsdpResponse(osdpDevice, out osdpReply, (reply) =>
                        {
                            osdpDevice.CryptoSession.RandomNumberB = reply.RandomB;
                            if (osdpDevice.CryptoSession.ClientCryptogram.SequenceEqual(reply.ClientCryptogram))
                            {
                                osdpDevice.Step = OsdpDeviceLifeStep.EstablishSecureSessionStep2;
                            }
                            else
                            {
                                if (osdpDevice.ProgramEncryptionKey)
                                {
                                    sendEventToManager(deviceAddress, new OsdpDeviceOfflineReceived(deviceAddress, osdpDevice.LogicalReaderId));
                                    osdpDevice.Step = OsdpDeviceLifeStep.ProgramEncryptionKeyStep1;
                                }
                                else
                                {
                                    deviceRestart(deviceAddress, ignoreDeviceAfterErrorsTimeout);
                                }
                            }
                            return true;
                        });

                        if (osdpDevice.ProgramEncryptionKey && Response.MessageFunctionCode == NackReply.FunctionCode)
                        {
                            sendEventToManager(deviceAddress, new OsdpDeviceOfflineReceived(deviceAddress, osdpDevice.LogicalReaderId));
                            osdpDevice.Step = OsdpDeviceLifeStep.ProgramEncryptionKeyStep1;
                        }
                    }
                    break;

                case OsdpDeviceLifeStep.EstablishSecureSessionStep2:
                    {
                        // Send server cryptogram to the device
                        SessionInitiationStep3Command sessionInitiationCommand = osdpDevice.SessionInitiationStep3Command();
                        PrepareForResponse();
                        if (sendCommand(osdpDevice, sessionInitiationCommand.Message(osdpDevice.CryptoSession)) == false)
                            return;

                        // Wait for specific reply
                        SessionInitiationStep4Reply osdpReply = null;
                        success = processOsdpResponse(osdpDevice, out osdpReply, (reply) =>
                        {
                            // Device send us initial MAC let check it.
                            if (osdpReply.ReplyMacValid(osdpDevice.CryptoSession) == false)
                            {
                                // Hmm, unexpected initial MAC. Remove device from the list.
                                Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                                {
                                    return string.Format("Device {0} on {1} has sent unexpected initial MAC and will be restarted.", deviceAddress, getUnderlayingCommPortName());
                                });
                                deviceRestart(deviceAddress, ignoreDeviceAfterErrorsTimeout);
                                return false;
                            }
                            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                            {
                                return string.Format("Device {0} on {1} secure session initialized.", deviceAddress, getUnderlayingCommPortName());
                            });
                            osdpDevice.Step = OsdpDeviceLifeStep.DeviceOnlineFirstTime;
                            return true;
                        });

                        if (success == false)
                            return;
                    }
                    break;

                case OsdpDeviceLifeStep.ProgramEncryptionKeyStep1:
                    {
                        PrepareForResponse();
                        if (sendCommand(osdpDevice, osdpDevice.PollCommand().Message(osdpDevice.CryptoSession)) == false)
                            return;

                        OsdpMessageBase osdpReply;
                        processOsdpResponse(osdpDevice, out osdpReply, (reply) =>
                        {
                            osdpDevice.Step = OsdpDeviceLifeStep.ProgramEncryptionKeyStep2;
                            return true;
                        });
                    }
                    break;
                case OsdpDeviceLifeStep.ProgramEncryptionKeyStep2:
                    {
                        SessionInitiationStep1Command sessionInitiationCommand = osdpDevice.SessionInitiationStep1Command(OsdpEncryptionDetails.DefaultEncryptionKey);
                        PrepareForResponse();
                        if (sendCommand(osdpDevice, sessionInitiationCommand.Message(osdpDevice.CryptoSession)) == false)
                            return;

                        SessionInitiationStep2Reply osdpReply = null;
                        processOsdpResponse(osdpDevice, out osdpReply, (reply) =>
                        {
                            osdpDevice.CryptoSession.RandomNumberB = reply.RandomB;
                            if (osdpDevice.CryptoSession.ClientCryptogram.SequenceEqual(reply.ClientCryptogram))
                            {
                                osdpDevice.Step = OsdpDeviceLifeStep.ProgramEncryptionKeyStep3;
                            }
                            else
                            {
                                osdpDevice.ProgramEncryptionKey = false;
                                deviceRestart(deviceAddress, ignoreDeviceAfterErrorsTimeout);
                            }
                            return true;
                        });
                    }
                    break;

                case OsdpDeviceLifeStep.ProgramEncryptionKeyStep3:
                    {
                        SessionInitiationStep3Command sessionInitiationCommand = osdpDevice.SessionInitiationStep3Command();
                        PrepareForResponse();
                        if (sendCommand(osdpDevice, sessionInitiationCommand.Message(osdpDevice.CryptoSession)) == false)
                            return;

                        SessionInitiationStep4Reply osdpReply = null;
                        success = processOsdpResponse(osdpDevice, out osdpReply, (reply) =>
                        {
                            if (osdpReply.ReplyMacValid(osdpDevice.CryptoSession) == false)
                            {
                                Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                                {
                                    return string.Format("Device {0} on {1} has sent unexpected initial MAC and will be restarted.", deviceAddress, getUnderlayingCommPortName());
                                });
                                deviceRestart(deviceAddress, ignoreDeviceAfterErrorsTimeout);
                                return false;
                            }
                            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                            {
                                return string.Format("Device {0} on {1} secure session initialized.", deviceAddress, getUnderlayingCommPortName());
                            });
                            osdpDevice.Step = OsdpDeviceLifeStep.ProgramEncryptionKeyStep4;
                            return true;
                        });

                        if (success == false)
                            return;
                    }
                    break;

                case OsdpDeviceLifeStep.ProgramEncryptionKeyStep4:
                    EncryptionKeySetCommand keySetCommand = osdpDevice.EncryptionKeySetCommand(this.encryptionKey);
                    PrepareForResponse();
                    if (sendCommand(osdpDevice, keySetCommand.Message(osdpDevice.CryptoSession)) == false)
                        return;

                    try
                    {
                        OsdpMessageBase osdpReply;
                        processOsdpResponse(osdpDevice, out osdpReply, (reply) =>
                        {
                            osdpDevice.CryptoSession.EncryptionKey = this.encryptionKey;
                            deviceRestart(reply.Address);
                            return true;
                        });
                    }
                    catch (Exception)
                    {
                        deviceRestart(osdpDevice.Address);
                    }
                    break;

                case OsdpDeviceLifeStep.DeviceOnlineFirstTime:
                    osdpDevice.IsOnline = true;
                    deviceOnline(deviceAddress);
                    osdpDevice.Step = OsdpDeviceLifeStep.DeviceOnline;
                    osdpDevice.SecuredSessionRestart = false;
                    break;

                case OsdpDeviceLifeStep.DeviceOnline:
                    bool isPollCommand;
                    for (int i = 0; i < maximumCommandsPerCycle; i++)
                    {
                        PrepareForResponse();
                        OsdpMessageBase commandToBeSent = osdpDevice.CommandsToSendPeek(out isPollCommand);
                        if (executeCommand(deviceAddress, isPollCommand, commandToBeSent) != OsdpDeviceResponse.Ok)
                            return;
                        if (osdpDevice.CommandsToSendPending() == 0 || disposing == true)
                            return;
                    }
                    break;
            }
        }

        protected bool SendOSDPMessage(byte[] message)
        {
            if (sendMessageDelayAfterReply.IsTimeUp(minDelayAfterReply) == false)
            {
                int time = minDelayAfterReply - sendMessageDelayAfterReply.ElapsedTime;
                if (time >= 0)
                    Thread.Sleep(time);
            }

            if (sendingOfPaddingRequired)
                lowerLayerConnection.Send(new byte[] { 0xFF }, blankDictionary); // This is required for Contal readers or they miss messages when there are more than 1 reader on the bus.
            if (lowerLayerConnection.Send(message, blankDictionary))
                return true;

            SerialConnectionBase currentSerialConnection = lowerLayerConnection as SerialConnectionBase;
            if (currentSerialConnection != null && currentSerialConnection.ConsecutiveCollisions > 3)
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, () =>
                {
                    return string.Format("{0}: Restarting frozen port", getUnderlayingCommPortName());
                });
                PhysicalSerialPort physicalSerialPort = currentSerialConnection.PhysicalSerialPort;
                int baudRate = currentSerialConnection.PortBaudRate;
                lowerLayerConnection.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(lowerLayerConnection_ConnectionStateChanged);
                lowerLayerConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(lowerLayerConnection_DataReceived);
                lowerLayerConnection.Dispose();
                ProtocolConnectionBase serialConnection = new SerialManager().CreateConnection(PhysicalSerialType.RS485, physicalSerialPort, baudRate, Parity.None, 8, StopBits.One);
                serialConnection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(lowerLayerConnection_ConnectionStateChanged);
                serialConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(lowerLayerConnection_DataReceived);
                serialConnection.Connect();
                base.SetLowerLayerConnection(serialConnection);
                Logger.LogCriticalMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, () =>
                {
                    return string.Format("{0}: New port ready", getUnderlayingCommPortName());
                });

                return lowerLayerConnection.Send(message, blankDictionary);
            }
            return false;
        }

        private bool sendCommand(OsdpDeviceLoopDevice osdpDevice, byte[] commandData)
        {
            if (commandData != null)
            {
                if (SendOSDPMessage(commandData) == true)
                {
                    osdpDevice.ResetSkipDeviceFlag();
                    return true;
                }

                if (osdpDevice.SkipDevice() == false)
                    deviceRestart(osdpDevice.Address, ignoreDeviceAfterErrorsTimeout);
            }
            return false;
        }

        private bool processOsdpResponse<T>(OsdpDeviceLoopDevice osdpDevice, out T osdpReply, Func<T, bool> OnOK) where T : OsdpMessageBase
        {
            osdpReply = null;
            OsdpDeviceResponse osdpDeviceResponse =
                osdpDevice.CryptoSession.SessionEncryptionKey != null && osdpDevice.SupportsSecureChannel ?
                WaitForResponse<T>(osdpDevice, onlineDeviceReplyTimeout, out osdpReply) :
                WaitForResponseWithoutEncryption<T>(osdpDevice, onlineDeviceReplyTimeout, out osdpReply);
            switch (osdpDeviceResponse)
            {
                case OsdpDeviceResponse.Ok:
                    osdpDevice.IncrementReceiveSequence();
                    return OnOK(osdpReply);
                case OsdpDeviceResponse.Busy:
                    evaluateDeviceBusyState(osdpDevice.Address);
                    break;
                case OsdpDeviceResponse.DeviceOutOfSequence:
                    onDeviceOutOfSequence(osdpDevice.Address);
                    break;
                case OsdpDeviceResponse.InvalidResponse:
                    deviceRestart(osdpDevice.Address, ignoreDeviceAfterErrorsTimeout);
                    break;
                case OsdpDeviceResponse.NoResponse:
                    deviceRestart(osdpDevice.Address, ignoreDeviceAfterErrorsTimeout);
                    break;
            }
            return true;
        }

        /// <summary>
        /// Evaluate the device busy state.
        /// </summary>
        /// <param name="deviceAddress">Device address</param>
        /// <returns>This function returns True when the device is to be restarted.</returns>
        private bool evaluateDeviceBusyState(int deviceAddress)
        {
            if (deviceList[deviceAddress].IsSubsequentlyBusy)
            {
                if (deviceList[deviceAddress].IsBusyTimeout)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                    {
                        return string.Format("Device {0} on {1} exceeded number of busy replies and will be restarted.", deviceAddress, getUnderlayingCommPortName());
                    });
                    deviceRestart(deviceAddress, ignoreDeviceAfterErrorsTimeout);
                    return true;
                }
            }
            else
            {
                deviceList[deviceAddress].StartBusyTimeout();
            }
            return false;
        }

        private void deviceOnline(int deviceAddress)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("Device {0} on {1} is online.", deviceAddress, getUnderlayingCommPortName());
            });
            if (deviceList[deviceAddress].SecuredSessionRestart == false)
                sendEventToManager(deviceAddress, new OsdpDeviceOnlineReceived(deviceList[deviceAddress]));

            if (deviceList[deviceAddress].Vendor == ReaderManufacturer.Pacom || deviceList[deviceAddress].Vendor == ReaderManufacturer.Contal)
            {
                sendingOfPaddingRequired = true;
                setSlowPolling();
            }
            else if (deviceList[deviceAddress].Vendor == ReaderManufacturer.Bqt)
            {
                setSlowPolling();
            }
        }

        private void setSlowPolling()
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("Slowing polling rate.");
            });

            minDelayBetweenDeviceCalls = 200;      // Sleep duration after polling all devices
            minDelayAfterReply = 50;
        }

        private OsdpDeviceResponse deviceRestart(int deviceAddress)
        {
            return deviceRestart(deviceAddress, 0);
        }

        private OsdpDeviceResponse deviceRestart(int deviceAddress, int delay)
        {
            var osdpDevice = deviceList[deviceAddress];
            if (osdpDevice.Step == OsdpDeviceLifeStep.DeviceNotDiscovered)
            {
                if (osdpDevice.SecuredSessionRestart == false)
                {
                    // Send event to manager
                    if (osdpDevice.IsOnline)
                    {
                        Dictionary<string, object> inputDictionary = new Dictionary<string, object>();
                        var deviceOffline = new OsdpDeviceOfflineReceived(deviceAddress, osdpDevice.LogicalReaderId);
                        deviceOffline.SetDeviceInformation(ReaderManufacturer.Unknown, 0, 0, new Version(0, 0, 0), 0);
                        inputDictionary.Add("DeviceLoopMessage", deviceOffline);
                        processCommand(inputDictionary);
                        osdpDevice.CommandsToSendClear();
                        osdpDevice.IsOnline = false;
                    }
                }
            }
            else if (osdpDevice.Step == OsdpDeviceLifeStep.DeviceOnline)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                {
                    return string.Format("Device {0} on {1} is offline.", deviceAddress, getUnderlayingCommPortName());
                });
                if (osdpDevice.SecuredSessionRestart == false)
                    sendEventToManager(deviceAddress, new OsdpDeviceOfflineReceived(deviceAddress, osdpDevice.LogicalReaderId));
                osdpDevice.CommandsToSendClear();
            }

            if (delay > 0)
            {
                int timeInSeconds = delay / 1000;
#if CONTROLLER
                Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                {
                    return string.Format("Device {0} on {1} is restarted. It will be checked again after {2} seconds.", deviceAddress, getUnderlayingCommPortName(), timeInSeconds);
                });
#endif
                osdpDevice.Reset(delay);
            }
            else
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                {
                    return string.Format("Device {0} on {1} is restarted.", deviceAddress, getUnderlayingCommPortName());
                });
                osdpDevice.Reset(0);
            }

            return OsdpDeviceResponse.DeviceRestart;
        }

        private void sendEventToManager(int deviceAddress, OsdpConnectionReceivedDataBase deviceMessage)
        {
            Dictionary<string, object> inputDictionary = new Dictionary<string, object>();
            deviceMessage.SetDeviceInformation(deviceList[deviceAddress]);
            inputDictionary.Add("DeviceLoopMessage", deviceMessage);
            processCommand(inputDictionary);
        }

        private OsdpDeviceResponse executeCommand(int deviceAddress, bool isPollCommand, OsdpMessageBase commandToBeSent)
        {
            OsdpDeviceLoopDevice osdpDevice = deviceList[deviceAddress];
            if (SendOSDPMessage(commandToBeSent.Message(osdpDevice.CryptoSession)) == false)
            {
                // Data corruption
                if (osdpDevice.SkipDevice())
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                    {
                        return string.Format("Device {0} on {1} conflict during sending command. Device skipped.", deviceAddress, getUnderlayingCommPortName());
                    });
                    return OsdpDeviceResponse.DeviceSkip;
                }
                else
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                    {
                        return string.Format("Device {0} on {1} conflict persists during sending command. Device is being reset.", deviceAddress, getUnderlayingCommPortName());
                    });
                    deviceRestart(deviceAddress, ignoreDeviceAfterErrorsTimeout);
                }
            }
            else
            {
                osdpDevice.ResetSkipDeviceFlag();
            }

            // Wait for any reply
            OsdpMessageBase deviceReply = null;
            switch (WaitForResponse<OsdpMessageBase>(osdpDevice, onlineDeviceReplyTimeout, out deviceReply))
            {
                case OsdpDeviceResponse.Ok:
                    if (isPollCommand == false)
                        osdpDevice.CommandsToSendRemove(commandToBeSent);
                    osdpDevice.IncrementReceiveSequence();

                    // Process the online device response
                    switch (Response.MessageFunctionCode)
                    {
                        case NackReply.FunctionCode:
                            if (onDeviceNAK((NackReply)Response, deviceAddress) == OsdpDeviceResponse.DeviceRestart)
                                return OsdpDeviceResponse.DeviceRestart;
                            break;
                        case LocalStatusReply.FunctionCode:
                            if (osdpConnectionClosed)
                                return OsdpDeviceResponse.ConnectionClosed;
                            LocalStatusReply localStatusReply = (LocalStatusReply)Response;
                            sendEventToManager(deviceAddress, new OsdpDeviceMessageReceived(deviceAddress, osdpDevice.LogicalReaderId, localStatusReply));
                            break;
                        case RawCardReply.FunctionCode:
                            if (osdpConnectionClosed)
                                return OsdpDeviceResponse.ConnectionClosed;
                            osdpDevice.OnCardBadge(BeepReaderWhenCardPresent);

                            // Process RAW response
                            RawCardReply rawReply = (RawCardReply)Response;
                            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                            {
#if DEBUG
                                string logMessage = string.Format("- Card scan. Bits: {0} Data: ", rawReply.BitCount);
                                logMessage += BitConverter.ToString(rawReply.CardData);
                                return logMessage;
#else
                                return string.Format("- Card scan. Bits: {0} Data: ****", rawReply.BitCount);
#endif
                            });
                            bool isUnauthorized = isSmartCardReader ? isCardUnauthorized(deviceAddress) : false;
                            if (isUnauthorized)
                            {
                                osdpDevice.QueueTemporaryLedOn(OsdpMessaging.LedColor.Amber, new TimeSpan(0, 0, 0, 3));
                            }
                            sendEventToManager(deviceAddress, new OsdpDeviceMessageReceived(deviceAddress, osdpDevice.LogicalReaderId, rawReply, isUnauthorized));
                            break;
                        case KeyPressReply.FunctionCode:
                            if (osdpConnectionClosed)
                                return OsdpDeviceResponse.ConnectionClosed;
                            KeyPressReply keypadReply = (KeyPressReply)Response;

                            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                            {
#if DEBUG
                                string logMessage = "- Keypad press. Raw keys: ";
                                foreach(KeypadKeys key in keypadReply.PressedKeys)
                                {
                                    logMessage += key.ToString() + " ";
                                }
                                return logMessage;
#else
                                return "- Keypad press. Raw keys: ****";
#endif
                            });
                            sendEventToManager(deviceAddress, new OsdpDeviceMessageReceived(deviceAddress, osdpDevice.LogicalReaderId, keypadReply));
                            break;
                        case ExtendedReadReply.FunctionCode:
                            if (osdpConnectionClosed)
                                return OsdpDeviceResponse.ConnectionClosed;
                            processExtendedReadReply(deviceAddress, (ExtendedReadReply)Response);
                            break;
                        default:
#if OSDP_TEST_TOOLS
                            // Send event to manager
                            Dictionary<string, object> inputDictionary = new Dictionary<string, object>();
                            var deviceMessage = new OsdpDeviceMessageReceived(deviceAddress, osdpDevice.LogicalReaderId, responseHandler.Response);
                            inputDictionary.Add("DeviceLoopMessage", deviceMessage);
                            processCommand(inputDictionary);
#endif
                            break;
                    }

                    return OsdpDeviceResponse.Ok;
                case OsdpDeviceResponse.Busy:
                    // Retry the same command next turn. Restore previous MAC if secure channel is established.
                    if (isPollCommand)
                        osdpDevice.QueueMissedPollMessage(commandToBeSent);
                    evaluateDeviceBusyState(deviceAddress);
                    return OsdpDeviceResponse.Busy;
                case OsdpDeviceResponse.DeviceOutOfSequence:
                    onDeviceOutOfSequence(deviceAddress);
                    return OsdpDeviceResponse.DeviceOutOfSequence;
                case OsdpDeviceResponse.InvalidResponse:
                    // This should never happen
                    deviceRestart(deviceAddress);
                    return OsdpDeviceResponse.InvalidResponse;
                case OsdpDeviceResponse.NoResponse:
                    osdpDevice.DeviceDidNotRespondToCommand();
                    if (osdpDevice.SporadicMissedResponses)
                    {
                        setSlowPolling();
                        osdpDevice.SporadicMissedResponses = false;
                    }
                    if (osdpDevice.IsCommandRetryCounterExceeded)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                        {
                            return string.Format("Device {0} on {1} exceeded number of same command retries and will be restarted.", deviceAddress, getUnderlayingCommPortName());
                        });
                        osdpDevice.ResetCommandRetryCounter();
                        deviceRestart(deviceAddress);
                    }
                    else
                    {
                        // Retry the same command next turn. Restore previous MAC if secure channel is established.
                        if (isPollCommand)
                            osdpDevice.QueueMissedPollMessage(commandToBeSent);
                        Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                        {
                            return string.Format("Device {0} on {1} did not respond within {2}ms. Trying the same command....", deviceAddress, getUnderlayingCommPortName(), onlineDeviceReplyTimeout);
                        });
                    }
                    return OsdpDeviceResponse.NoResponse;
            }

            return OsdpDeviceResponse.Error;
        }

        private void removeDevice(int deviceAddress)
        {
            deviceList[deviceAddress] = null;
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("Device {0} on {1} is removed from OSDP loop.", deviceAddress, getUnderlayingCommPortName());
            });
        }

        private void processCommand(Dictionary<string, object> inputDictionary)
        {
            if (this.DataReceived != null && inputDictionary != null)
                this.DataReceived(this, new ReceivedDataEventArgs(null, inputDictionary));
        }

        /// <summary>
        /// Indicator that the instance should not accept any more new connections, and shutdown (disposing) process will happen soon.
        /// </summary>
        private bool osdpConnectionClosed = false;

        private ManualResetEvent osdpConnectionClosedWait = new ManualResetEvent(false);

        /// <summary>
        /// Shutdown the OSDP connection. Terminate any reader connections.
        /// </summary>
        public void Shutdown()
        {
            osdpConnectionClosed = true;
            osdpConnectionClosedWait.WaitOne(1000, false);
        }

        #region Message Response Handling

        private byte[] messageResponseData = null;
        private ManualResetEvent messageResponseReceivedEvent = new ManualResetEvent(false);

        private void fifo_MessageAvailable(object sender, ReceivedDataEventArgs e)
        {
            if (Application.Closing)
                return;

            sendMessageDelayAfterReply.Reset();

            messageResponseData = e.Data;
            messageResponseReceivedEvent.Set();
        }

        private void lowerLayerConnection_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (e.NewConnectionState == ConnectionState.Connected)
            {
                lowerLayerConnectedEvent.Set();
                if (ConnectionStateChanged != null)
                    ConnectionStateChanged(this, e);
            }
            else
            {
                ConnectionState = ConnectionState.Disconnected;
                if (ConnectionStateChanged != null)
                    ConnectionStateChanged(this, e);
            }
        }

        private void lowerLayerConnection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            if (Application.Closing)
                return;
            try
            {
                fifo.Enqueue(e.Data, 0, e.Data.Length);
            }
            catch
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, () =>
                {
                    return "Error while responding to received data. FIFO error.";
                });
                fifo.Reset();
            }
        }

        private void onDeviceOutOfSequence(int deviceAddress)
        {
            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
            {
                return string.Format("Device {0} on {1} is out of sequence.", deviceAddress, getUnderlayingCommPortName());
            });
            deviceRestart(deviceAddress, ignoreDeviceAfterErrorsTimeout);
        }

        private OsdpDeviceResponse onDeviceNAK(NackReply nakReply, int deviceAddress)
        {
            sendEventToManager(deviceAddress, new OsdpDeviceMessageReceived(deviceAddress, deviceList[deviceAddress].LogicalReaderId, nakReply));
            switch (nakReply.Error)
            {
                case NackErrorCode.CheckSumOrCrcError:
                    Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                    {
                        return string.Format("Device {0} on {1} reports message checksum error. Restarting device.", deviceAddress, getUnderlayingCommPortName());
                    });
                    deviceRestart(deviceAddress);
                    return OsdpDeviceResponse.DeviceRestart;
                case NackErrorCode.UnexpectedSequenceNumber:
                    Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                    {
                        return string.Format("Device {0} on {1} reports unexpected message sequence. Restarting device.", deviceAddress, getUnderlayingCommPortName());
                    });
                    deviceRestart(deviceAddress);
                    return OsdpDeviceResponse.DeviceRestart;
                case NackErrorCode.EncryptedCommunicationRequired:
                    OsdpDeviceLoopDevice osdpDevice = deviceList[deviceAddress];
                    if (IsEncryptionKeyValid)
                    {
                        if (osdpDevice.CryptoSession.SessionEncryptionKey == null)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                            {
                                return string.Format("Device {0} on {1} supports only secure session. Restarting device.", deviceAddress, getUnderlayingCommPortName());
                            });
                            deviceRestart(deviceAddress);
                            return OsdpDeviceResponse.DeviceRestart;
                        }
                        else
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                            {
                                return string.Format("Device {0} on {1} dropped secure session. Restarting device.", deviceAddress, getUnderlayingCommPortName());
                            });
                            deviceRestart(deviceAddress);
                            return OsdpDeviceResponse.DeviceRestart;
                        }
                    }
                    else
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, DebugLoggingSubCategory.OsdpDeviceLoop, () =>
                        {
                            return string.Format("Device {0} on {1} expects secure session. Restarting device.", deviceAddress, getUnderlayingCommPortName());
                        });
                        deviceRestart(deviceAddress);
                        return OsdpDeviceResponse.DeviceRestart;
                    }
            }

            return OsdpDeviceResponse.NAK;
        }

        #endregion

        #region Message Request Handling

        public override bool Send(byte[] data, Dictionary<string, object> metadata)
        {
            return false;
        }
        #endregion

        #region IDisposable Members

        bool disposed = false;

        bool disposing = false;

        protected override void Dispose(bool disposing)
        {
            if (disposed == true)
                return;

            if (disposing == true)
            {
                this.disposing = true;
                // Free any other managed objects here.                

                try
                {
                    onlineDeviceReplyTimeout = 200;
                    offlineDeviceReplyTimeout = 200;

                    if (configurationChangedEvent != null)
                    {
                        configurationChangedEvent.Set();
                    }

                    if (mainPollingThread != null)
                    {
                        mainPollingThread.JoinOrRestart(6000);
                        mainPollingThread = null;
                    }

                    if (configurationChangedEvent != null)
                    {
                        configurationChangedEvent.Close();
                        configurationChangedEvent = null;
                    }

                    if (lowerLayerConnection != null)
                    {
                        lowerLayerConnection.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(lowerLayerConnection_ConnectionStateChanged);
                        lowerLayerConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(lowerLayerConnection_DataReceived);
                    }

                    if (lowerLayerConnectedEvent != null)
                    {
                        lowerLayerConnectedEvent.Close();
                        lowerLayerConnectedEvent = null;
                    }

                    if (fifo != null)
                    {
                        fifo.MessageAvailable -= new EventHandler<ReceivedDataEventArgs>(fifo_MessageAvailable);
                        fifo = null;
                    }

                    if (securedSessionsRestartTimer != null)
                    {
                        securedSessionsRestartTimer.Stop();
                        TimerManager.Instance.RemoveTimer(securedSessionsRestartTimer);
                        securedSessionsRestartTimer = null;
                    }
                }
                catch
                {
                }
            }

            // Free any unmanaged objects here.            
            disposed = true;

            base.Dispose(disposing);
        }

        #endregion
    }
}
