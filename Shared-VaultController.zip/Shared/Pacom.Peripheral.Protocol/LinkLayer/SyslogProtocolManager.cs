﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;

namespace Pacom.Peripheral.Protocol
{
    public sealed class SyslogProtocolManager : IDisposable
    {
        public SyslogProtocolConnection CreateConnection(IPAddress syslogServerAddress)
        {
            return new SyslogProtocolConnection(syslogServerAddress);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}
