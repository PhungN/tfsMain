﻿using System;
using System.Net;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// A factory that produces DeviceLoopProtocolOverUdpIPConnection instances.
    /// </summary>
    public sealed class DeviceLoopProtocolOverUdpIPManager : IDisposable
    {
        /// <summary>
        /// Produces a new DeviceLoopProtocolOverUdpIPConnection instance.
        /// </summary>
        /// <returns>A new DeviceLoopProtocolOverUdpIPConnection instance.</returns>
        public DeviceLoopProtocolOverUdpIPConnection CreateConnection(IPAddress controllerAddress, int controllerPort)
        {
            DeviceLoopProtocolOverUdpIPConnection deviceLoopProtocolOverUdpIPConnection = new DeviceLoopProtocolOverUdpIPConnection(controllerAddress, controllerPort);
            return deviceLoopProtocolOverUdpIPConnection;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}
