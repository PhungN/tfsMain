﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// A factory that produces DeviceLoopProtocolOverIPConnection instances.
    /// </summary>
    public sealed class DeviceLoopProtocolOverIPManager : IDisposable
    {
        private bool firstConnection = true;

        /// <summary>
        /// Produces a new DeviceLoopProtocolOverIPConnection instance.
        /// </summary>
        /// <returns>A new DeviceLoopProtocolOverIPConnection instance.</returns>
        public DeviceLoopProtocolOverIPConnection CreateConnection()
        {
            DeviceLoopProtocolOverIPConnection deviceLoopProtocolOverIPConnection = new DeviceLoopProtocolOverIPConnection(firstConnection);
            firstConnection = false;
            return deviceLoopProtocolOverIPConnection;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}
