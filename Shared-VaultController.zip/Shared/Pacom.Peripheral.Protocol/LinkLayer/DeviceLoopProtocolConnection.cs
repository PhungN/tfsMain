﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Ports;
using System.Security.Cryptography;
using System.Threading;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utils;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.Messaging.DeviceLoopMessages;
using System.Text;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// The link level connection to implement the Pacom device loop protocol.
    /// </summary>
    public partial class DeviceLoopProtocolConnection : ProtocolConnectionBase
    {
        /// <summary>
        /// Triggered when a complete message has been received and successfully parsed. The original message
        /// can be found as a byte array, while the parsed message is available in the 'DeviceLoopMessage'
        /// element in the dictionary.
        /// </summary>
        public override event EventHandler<ReceivedDataEventArgs> DataReceived;

        /// <summary>
        /// Triggered when the connection changes state (Disconnected, Connecting, Connected)
        /// </summary>
        public override event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;

        private readonly DeviceLoopProtocolFifo fifo;
        private readonly byte deviceAddressByte = 0;
        private bool closing = false;
        private bool busIsInContentionMode = false;
        private readonly ManualResetEvent busIsInContentionModeEvent = new ManualResetEvent(false);
        private readonly ManualResetEvent messageSentEvent = new ManualResetEvent(false);
        private readonly ManualResetEvent sendDeviceAddressReleaseEvent = new ManualResetEvent(false);
        private readonly ManualResetEvent disposingEvent = new ManualResetEvent(false);
        private readonly Random rand = new Random();
        private bool restarted = true;
        private int sequenceNumber = 0;
        private int consecutiveMissedPolls = 0;
        private DateTime lastValidMessageReceived;
        private Thread sendDeviceAddressThread;

        private readonly Timer contentionModeTimer;
        private readonly Timer offlineTimer;
        private readonly ManualResetEvent pollReceived = new ManualResetEvent(false);
        private byte[] messageToSend = null;
        private bool messageSendAttempted = false;
        private readonly object messageToSendSync = new object();
        private byte[] ackMessage = new byte[3];
        private byte randomNumber = 0;

        private byte[] lastReceivedMessage = new byte[0];
        private byte[] lastReceivedMessageResponse = new byte[0];

        private int numberOfCommunicationErrors = 0;
        private int lastReceivedSingleByte = -1; // initialize here to signal other states
        private int lastReceivedSingleByteCount = 0;
        private const int offlineTimeoutValue = 65000;
        private int baudRate;

        private byte[] deviceLoopPassword = null;
        private byte[] randomNumbers = new byte[8];
        private AesCryptor sessionKeyCryptor = null;
        private bool enableEncryption = false;
        private bool encryptionKeyChanged = false;
        private byte nextTransmitSequenceNumber;
        private byte nextExpectedReceiveSequenceNumber;

        private byte[] encryptionVerification = new byte[12];

        public DeviceLoopProtocolConnection(int baudRate)
        {
            this.baudRate = baudRate;
            ConnectionState = ConnectionState.Connecting;
            fifo = new DeviceLoopProtocolFifo();
            fifo.MessageAvailable += new EventHandler<ReceivedDataEventArgs>(fifo_MessageAvailable);

            int tempInteger = ConfigurationManager.Instance.DeviceLoopAddress(DeviceLoopAddressType.Serial);
            if (tempInteger >= 0)
                this.deviceAddressByte = (byte)(tempInteger | 0xE0);
            ackMessage[0] = deviceAddressByte;

            deviceLoopPassword = ConfigurationManager.Instance.DeviceLoopPassword;
            if (deviceLoopPassword != null)
            {
                enableEncryption = true;
                updateEncryptionVerification();
            }

            contentionModeTimer = new Timer(contentionTimeout, null, 250, System.Threading.Timeout.Infinite);
            offlineTimer = new Timer(offlineTimeout, null, offlineTimeoutValue, System.Threading.Timeout.Infinite);
            sendDeviceAddressThread = new Thread(new ThreadStart(this.sendDeviceAddressThreadMethod));
            sendDeviceAddressThread.Name = "Send Device Address";
            sendDeviceAddressThread.IsBackground = true;
            sendDeviceAddressThread.Priority = ThreadPriority.AboveNormal;
            sendDeviceAddressThread.Start();
        }

        private void fifo_MessageAvailable(object sender, ReceivedDataEventArgs e)
        {
            if (Application.Closing || closing)
                return;

            try
            {
                int messageType = e.Data[1] & 0x07;
                if (messageType == 3)
                {
                    // Broadcast contention
                    contentionModeTimer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
                    busIsInContentionMode = true;
                    busIsInContentionModeEvent.Set();

                    lock (messageToSendSync)
                    {
                        if (messageToSend != null)
                            pollRequired();
                    }
                }
                else if (messageType == 6)
                {
                    // Broadcast data
                    if (DataReceived != null)
                    {
                        Dictionary<string, object> d = new Dictionary<string, object>();
                        try
                        {
                            d.Add("DeviceLoopMessage", DeviceLoopMessageBase.ParseBroadcast(e.Data, 3, e.Data.Length - 4, DeviceType.PacomController));
                            DataReceived(this, new ReceivedDataEventArgs(e.Data, d));
                        }
                        catch
                        {
                            Logger.LogWarnMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                            {
                                return "DeviceLoop: Failed to parse broadcast message " + BitConverter.ToString(e.Data, 0, e.Data.Length);
                            });
                        }
                    }
                }
                else if (e.Data[0] == deviceAddressByte)
                {
                    pollReceived.Set();
                    consecutiveMissedPolls = 0;
                    bool sequenceNumberValid = true;
                    if (restarted)
                    {
                        if ((e.Data[1] & 0x08) == 0)
                            sequenceNumber = 0;
                        else
                            sequenceNumber = 1;
                    }
                    else
                    {
                        if (sequenceNumber == 0 && (e.Data[1] & 0x08) != 0)
                            sequenceNumberValid = false;
                        else if (sequenceNumber == 1 && (e.Data[1] & 0x08) == 0)
                            sequenceNumberValid = false;
                    }

                    if (sequenceNumberValid == false)
                    {
                        // The sequence number was not what was expected
                        if (e.Data.SequenceEqual(lastReceivedMessage))
                        {
                            // This is a retransmit so, send the previous response.
                            if (fifo.IsEmpty)
                                lowerLayerConnectionSend(lastReceivedMessageResponse, blankDictionary);
                        }
                        else
                        {
                            // This is an invalid condition and should never happen but
                            // just in case it happens, we will correct for the invalid
                            // sequence number and process the message as per normal.

                            sequenceNumber ^= 1;
                            sequenceNumberValid = true;
                        }
                    }
                    else
                    {
                        // A message is only marked as sent when a message with the next sequence number is received.
                        // If we received a check device command, it is likely because the sequence numbers are out of sync.
                        if (messageSendAttempted == true && (e.Data.Length != 13 || e.Data[3] != 0 || (e.Data[1] & 0x07) != 1))
                        {
                            messageToSend = null;
                            messageSendAttempted = false;
                            messageSentEvent.Set();
                        }

                        if (e.Data.Length == 3)
                        {
                            switch (messageType)
                            {
                                case 0: // Poll
                                    sendAckOrData();
                                    break;
                                case 4: // Reset Sequence Numbers
                                    sequenceNumber = 0;
                                    sendAck();
                                    break;
                            }
                        }
                        else if ((e.Data[1] & 0x07) == 1)
                        {
                            // Data message
                            if (e.Data.Length == 13 && e.Data[3] == 0)
                            {
                                // Check device command
                                Buffer.BlockCopy(e.Data, 4, randomNumbers, 0, 8);

                                byte randa = (byte)((deviceAddressByte & 0x1F) ^ (byte)0xb3);
                                byte randb = (byte)(randomNumber ^ (byte)0x68);

                                byte checkCode = 0;
                                for (int i = 0; i < 8; i++)
                                {
                                    if ((randa & (1 << i)) != 0)
                                    {
                                        if ((e.Data[4 + i] & 0x80) == 0x80)
                                            e.Data[4 + i] = (byte)((e.Data[4 + i] << 1) | 0x01);
                                        else
                                            e.Data[4 + i] = (byte)(e.Data[4 + i] << 1);
                                    }
                                    checkCode += e.Data[4 + i];
                                }
                                checkCode ^= randb;

                                sendCheckCode(checkCode);
                                nextTransmitSequenceNumber = checkCode;
                                nextExpectedReceiveSequenceNumber = checkCode;

                                if (deviceLoopPassword != null)
                                    sessionKeyCryptor = getSessionKey();
                            }
                            else if (e.Data.Length == 22 && e.Data[3] == 248)
                            {
                                sendAck();

                                // Set encryption key unencrypted command
                                deviceLoopPassword = new byte[16];
                                Buffer.BlockCopy(e.Data, 5, deviceLoopPassword, 0, 16);
                                if (enableEncryption == true)
                                {
                                    sessionKeyCryptor = getSessionKey();
                                }
                                updateEncryptionVerification();
                            }
                            else if (e.Data.Length == 6 && e.Data[3] == 249)
                            {
                                sendAck();

                                // Set encryption command
                                if (e.Data[4] == 0)
                                {
                                    sessionKeyCryptor = null;
                                    enableEncryption = false;
                                    ConfigurationManager.Instance.DeviceLoopPassword = null;
                                    lock (messageToSendSync)
                                    {
                                        encryptionKeyChanged = true;
                                        messageToSend = null;
                                        messageSentEvent.Set();
                                    }
                                }
                                else
                                {
                                    enableEncryption = true;
                                    if (deviceLoopPassword != null)
                                        sessionKeyCryptor = getSessionKey();
                                }
                            }
                            else
                            {
                                sendAckOrData();

                                if (sessionKeyCryptor != null && e.Data.Length > 5)
                                {
                                    byte[] unencryptedData;
                                    byte[] decryptedData = sessionKeyCryptor.AesDecryptor.TransformFinalBlock(e.Data, 3, e.Data.Length - 4);

                                    int paddingLength = decryptedData[0] & 0x0F;
                                    int sequenceNumber = decryptedData[paddingLength + 1];

                                    if (sequenceNumber == nextExpectedReceiveSequenceNumber)
                                    {
                                        nextExpectedReceiveSequenceNumber++;

                                        unencryptedData = new byte[decryptedData.Length - paddingLength - 2 + 4]; // Final data won't include the padding length or the sequence number bytes;

                                        unencryptedData[0] = e.Data[0];              // ADDR
                                        unencryptedData[1] = e.Data[1];              // CTRL
                                        unencryptedData[2] = (byte)(unencryptedData.Length - 3);      // BC

                                        Buffer.BlockCopy(decryptedData, paddingLength + 2, unencryptedData, 3, unencryptedData.Length - 4);

                                        if (unencryptedData.Length == 22 && unencryptedData[3] == 248)
                                        {
                                            // Set encryption key, encrypted command
                                            deviceLoopPassword = new byte[16];
                                            Buffer.BlockCopy(unencryptedData, 5, deviceLoopPassword, 0, 16);
                                            if (enableEncryption)
                                                sessionKeyCryptor = getSessionKey();
                                            updateEncryptionVerification();
                                        }
                                        else
                                        {
                                            triggerDataReceived(unencryptedData);
                                        }
                                    }
                                    else
                                    {
                                        restarted = true;
                                    }
                                }
                                else
                                {
                                    triggerDataReceived(e.Data);
                                }
                            }
                        }
                        else if (e.Data.Length == 4 && (e.Data[1] & 0x07) == 5)
                        {
                            // Reset random numbers
                            sendAck();
                            randomNumber = e.Data[2];
                            ConnectionState = ConnectionState.Connected;
                            if (ConnectionStateChanged != null)
                                ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Connected));
                        }
                        lastReceivedMessage = e.Data;
                    }

                    if (Application.Closing || closing)
                        return;

                    offlineTimer.Change(offlineTimeoutValue, Timeout.Infinite);
                    consecutiveMissedPolls = 0;
                }
                lastValidMessageReceived = DateTime.Now;
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                {
                    return "DeviceLoop: Failed processing message available. " + ex.ToString();
                });
            }
        }

        private void triggerDataReceived(byte[] data)
        {
            if (DataReceived != null)
            {
                Dictionary<string, object> d = new Dictionary<string, object>();
                try
                {
                    d.Add("DeviceLoopMessage", DeviceLoopMessageBase.Parse(data, 3, data.Length - 4, DeviceType.PacomController));
                    DataReceived(this, new ReceivedDataEventArgs(data, d));
                }
                catch
                {
                    Logger.LogWarnMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                    {
                        return "DeviceLoop: Failed to parse message " + BitConverter.ToString(data, 0, data.Length);
                    });
                }
            }
        }

        private void sendAck()
        {
            ackMessage[1] = 0x40;
            if (sequenceNumber == 1)
                ackMessage[1] |= 0x08;
            sequenceNumber ^= 1;
            setChecksum(ackMessage);

            if (fifo.IsEmpty)
                lowerLayerConnectionSend(ackMessage, blankDictionary);
            lastReceivedMessageResponse = ackMessage;
        }

        private void sendCheckCode(byte checkCode)
        {
            byte[] checkCodeMessage;
            if (deviceLoopPassword == null)
            {
                checkCodeMessage = new byte[8];
            }
            else
            {
                checkCodeMessage = new byte[20];
                Buffer.BlockCopy(encryptionVerification, 0, checkCodeMessage, 7, 12);
            }

            checkCodeMessage[0] = deviceAddressByte;
            checkCodeMessage[1] = 0x41;
            checkCodeMessage[2] = (byte)(checkCodeMessage.Length - 3);
            checkCodeMessage[3] = (byte)DeviceLoopMessageBase.DeviceLoopDeviceType;
            checkCodeMessage[4] = 0;
            checkCodeMessage[5] = checkCode;
            checkCodeMessage[6] = 1;

            if (sequenceNumber == 1)
                checkCodeMessage[1] |= 0x08;
            sequenceNumber ^= 1;
            setChecksum(checkCodeMessage);

            if (fifo.IsEmpty)
                lowerLayerConnectionSend(checkCodeMessage, blankDictionary);
            lastReceivedMessageResponse = checkCodeMessage;
        }

        private void sendAckOrData()
        {
            byte[] data = null;
            bool sendingAck = true;
            ackMessage[1] = 0x40;
            bool result;
            if (restarted)
            {
                ackMessage[1] = 0x44;
                restarted = false;
            }
            else
            {
                lock (messageToSendSync)
                {
                    if (messageToSend != null)
                    {
                        data = messageToSend;
                        sendingAck = false;
                        messageSendAttempted = true;
                    }
                }
            }
            if (sendingAck)
                data = ackMessage;
            if (sequenceNumber == 1)
            {
                data[1] |= 0x08;
            }
            else
            {
                data[1] &= 0xF7;
            }
            sequenceNumber ^= 1;
            setChecksum(data);

            if (fifo.IsEmpty)
                result = lowerLayerConnectionSend(data, blankDictionary);
            else
                result = false;
            lastReceivedMessageResponse = data;
        }

        private static void setChecksum(byte[] data)
        {
            int checksum = 0;
            for (int i = 0; i < (data.Length - 1); i++)
                checksum += data[i];
            checksum *= -1;
            if (data.Length == 3)
                checksum &= 0x1F;
            data[data.Length - 1] = (byte)checksum;
        }

        public override void SetLowerLayerConnection(ProtocolConnectionBase lowerLayerConnection)
        {
            lowerLayerConnection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(lowerLayerConnection_ConnectionStateChanged);
            lowerLayerConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(lowerLayerConnection_DataReceived);
            base.SetLowerLayerConnection(lowerLayerConnection);
        }

        private bool lowerLayerConnectionSend(byte[] data, Dictionary<string, object> metadata)
        {
            if (lowerLayerConnection.Send(data, metadata))
                return true;

            SerialConnectionBase currentSerialConnection = lowerLayerConnection as SerialConnectionBase;
            if (currentSerialConnection != null && currentSerialConnection.ConsecutiveCollisions > 3)
            {
                PhysicalSerialPort physicalSerialPort = currentSerialConnection.PhysicalSerialPort;
                Logger.LogCriticalMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                {
                    return string.Format("COM{0}: Restarting frozen port", (int)physicalSerialPort);
                });
                lowerLayerConnection.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(lowerLayerConnection_ConnectionStateChanged);
                lowerLayerConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(lowerLayerConnection_DataReceived);
                lowerLayerConnection.Dispose();
                ProtocolConnectionBase serialConnection = new SerialManager().CreateConnection(PhysicalSerialType.RS485, physicalSerialPort, baudRate, Parity.Even, 8, StopBits.One);
                serialConnection.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(lowerLayerConnection_ConnectionStateChanged);
                serialConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(lowerLayerConnection_DataReceived);
                serialConnection.Connect();
                base.SetLowerLayerConnection(serialConnection);
                Logger.LogCriticalMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                {
                    return string.Format("COM{0}: New port ready", (int)physicalSerialPort);
                });

                return lowerLayerConnection.Send(data, metadata);
            }
            return false;
        }

        private void lowerLayerConnection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            busIsInContentionMode = false;
            if (Application.Closing || closing)
                return;
            try
            {
                fifo.Enqueue(e.Data, 0, e.Data.Length);
                contentionModeTimer.Change(250, System.Threading.Timeout.Infinite);

                // Uncomment this line if you want to see the received traffic
#if DEBUG
                // Console.WriteLine("Received on 485 " + BitConverter.ToString(e.Data) + ", communication error count " + numberOfCommunicationErrors);
#endif

                // During connecting state check certain communication errors
                if (ConnectionState == ConnectionState.Connecting)
                {
                    if (e.Metadata != null && e.Metadata["CommErrorCount"] != null)
                        numberOfCommunicationErrors += (int)e.Metadata["CommErrorCount"];

                    // Check if all data bytes are zeros
                    int numberOfZerosInData = 0;
                    for (int i = 0; i < e.Data.Length; i++)
                    {
                        if (e.Data[i] == 0)
                            numberOfZerosInData++;
                        else
                            break;
                    }
                    if (numberOfZerosInData == e.Data.Length)
                        numberOfCommunicationErrors++;

                    // Check if we receive same single byte during connecting
                    if (e.Data.Length == 1)
                    {
                        if (e.Data[0] == lastReceivedSingleByte)
                        {
                            if (lastReceivedSingleByteCount < 10)
                                lastReceivedSingleByteCount++;
                            else
                            {
                                numberOfCommunicationErrors++;
                            }
                        }
                        lastReceivedSingleByte = e.Data[0];
                    }
                    else
                    {
                        lastReceivedSingleByte = -1;
                        lastReceivedSingleByteCount = 0;
                    }

                    if (numberOfCommunicationErrors >= 50)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                        {
                            return "Disconnection forced during connecting state due to number of communication errors.";
                        });
                        // Try a different baud rate
                        ConnectionState = ConnectionState.Disconnected;
                        if (ConnectionStateChanged != null)
                            ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Disconnected));
                    }
                }
                else
                {
                    numberOfCommunicationErrors = 0;
                }
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                {
                    return "Error while responding to received data." + ex.ToString();
                });
            }
        }

        private void lowerLayerConnection_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            try
            {
                if (Application.Closing || closing)
                    return;
                if (e.NewConnectionState == ConnectionState.Connected)
                {
                    sendDeviceAddressLastTime.ExpectedDuration = 1000 + rand.Next(2000);
                    pollRequired();
                }
                else
                {
                    ConnectionState = ConnectionState.Disconnected;
                    if (ConnectionStateChanged != null)
                        ConnectionStateChanged(this, e);
                }
            }
            catch
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                {
                    return "Error while responding to connection state change.";
                });
            }
        }

        /// <summary>
        /// A non-blocking call to initiate the connection.
        /// A ConnectionStateChanged event will be fired to indicate the final result of the call.
        /// </summary>
        /// <returns>True on success.</returns>
        public override bool Connect()
        {
            lowerLayerConnection.Connect();
            lastValidMessageReceived = DateTime.Now;
            return true;
        }

        /// <summary>
        /// A blocking call to send a message on the connection.
        /// The metadata dictionary is expected to contain an element named 'DeviceLoopMessage' who's value derives from the DeviceLoopMessageBase class.
        /// </summary>
        /// <param name="data">unused</param>
        /// <param name="metadata">Must contain an element named 'DeviceLoopMessage' who's value derives from the DeviceLoopMessageBase class.</param>
        /// <returns>True if successfully sent out on the physical connection.</returns>
        public override bool Send(byte[] data, Dictionary<string, object> metadata)
        {
            object tempObject;
            bool result = false;
            DeviceLoopMessageBase deviceLoopMessage;
            if (metadata.TryGetValue("DeviceLoopMessage", out tempObject))
                deviceLoopMessage = (DeviceLoopMessageBase)tempObject;
            else
                return false;

            // While the encryption key may change while we are waiting on the messageSentEvent event, it still makes sense to do the encryption here
            // and have the message ready to send rather than make all the devices on the device loop wait while we encypt the message when it is our 
            // turn to send.

            if (deviceLoopMessage != null)
            {
                encryptionKeyChanged = false;
                byte[] messageBytes;
                if (sessionKeyCryptor != null)
                {
                    int unpaddedMessageLength = deviceLoopMessage.Data.Length;
                    messageBytes = new byte[(((unpaddedMessageLength + 1) / 16) * 16) + 21];

                    try
                    {
                        messageBytes[0] = deviceAddressByte;                                    // Address
                        messageBytes[1] = 0x41;                                                 // Control (Sequence number is added later)
                        messageBytes[2] = (byte)(messageBytes.Length - 3);                      // Byte count
                        int paddingLength = messageBytes.Length - unpaddedMessageLength - 7;
                        messageBytes[3] = (byte)DeviceLoopMessageBase.DeviceLoopDeviceType;     // Device Type
                        messageBytes[4] = (byte)((rand.Next(255) & 0xF0) | (paddingLength));    // Padding length in lower nibble

                        // padding
                        for (int i = 0; i < paddingLength; i++)
                        {
                            messageBytes[5 + i] = (byte)rand.Next(255);
                        }

                        messageBytes[5 + paddingLength] = nextTransmitSequenceNumber;                   // Sequence
                        Buffer.BlockCopy(deviceLoopMessage.Data, deviceLoopMessage.Offset, messageBytes, paddingLength + 6, unpaddedMessageLength);

                        byte[] encryptedData = sessionKeyCryptor.AesEncryptor.TransformFinalBlock(messageBytes, 4, messageBytes.Length - 5);
                        Buffer.BlockCopy(encryptedData, 0, messageBytes, 4, encryptedData.Length);
                    }
                    catch (Exception ex)
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                        {
                            return string.Format("Failed encrypting message: {0}", ex.ToString());
                        });
                    }
                }
                else
                {
                    messageBytes = new byte[deviceLoopMessage.Data.Length + 5];
                    Buffer.BlockCopy(deviceLoopMessage.Data, 0, messageBytes, 4, deviceLoopMessage.Data.Length);
                    messageBytes[0] = deviceAddressByte;                            // Address
                    messageBytes[1] = 0x41;                                         // Control (Sequence number is added later)
                    messageBytes[2] = (byte)(deviceLoopMessage.Data.Length + 2);    // Byte count
                    messageBytes[3] = (byte)DeviceLoopMessageBase.DeviceLoopDeviceType; // Device Type
                }
                lock (messageToSendSync)
                {
                    if (encryptionKeyChanged == true)
                        return false;
                    messageToSend = messageBytes;
                    pollRequired();
                    messageSentEvent.Reset();
                }
                result = messageSentEvent.WaitOne(30000, false);
                if (closing == true)
                    return false;

                // If the encryption key has changed since we constructed the message, return false so that the CommunicationsManager will retry sending the message.
                if (encryptionKeyChanged == true)
                    return false;
                if (result == true)
                {
                    nextTransmitSequenceNumber++;

                    messageToSend = null;
                    Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                    {
                        return "Sent on 485 successfully";
                    });
                }
                else
                {
                    lock (messageToSendSync)
                    {
                        result = messageSentEvent.WaitOne(0, false);
                        if (result == true)
                        {
                            nextTransmitSequenceNumber++;
                            messageToSend = null;
                            Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                            {
                                return "Sent on 485 successfully";
                            });
                        }
                        else
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                            {
                                return "Failed sending on 485";
                            });
                        }
                    }
                }
            }

            return result;
        }

        private void contentionTimeout(object state)
        {
            busIsInContentionMode = true;
            busIsInContentionModeEvent.Set();
        }

        #region Send device address

        TimeLimit sendDeviceAddressLastTime = new TimeLimit(10000, true);

        private void offlineTimeout(object state)
        {
            pollRequired();
        }

        private void pollRequired()
        {
            if (Application.Closing || closing)
                return;

#if DEBUG_DEVICEADDRESS
            Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
            {
                return "Poll Required";
            });
#endif
            sendDeviceAddressReleaseEvent.Set();
        }

        private bool checkForOffline()
        {
            consecutiveMissedPolls++;
            if (consecutiveMissedPolls >= 5 && (((DateTime.Now - lastValidMessageReceived).TotalSeconds > 30) || ConnectionState == ConnectionState.Connecting))
            {
#if DEBUG_DEVICEADDRESS
                Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                {
                    return "Too many polls missed";
                });
#endif
                // Try a different baud rate
                ConnectionState = ConnectionState.Disconnected;
                if (ConnectionStateChanged != null)
                    ConnectionStateChanged(this, new ConnectionStateChangedEventArgs(ConnectionState.Disconnected));
                return true;
            }
            return false;
        }

        private void sendDeviceAddressThreadMethod()
        {
            while (Application.Closing == false && closing == false)
            {
                sendDeviceAddressReleaseEvent.WaitOne();
                uint elapsedTime;
                if (sendDeviceAddressLastTime.IsTimeUp(sendDeviceAddressLastTime.ExpectedDuration, out elapsedTime) == false)
                {
                    // Calculate remaining timeout
                    int timeout = (int)(sendDeviceAddressLastTime.ExpectedDuration - elapsedTime);
                    if (timeout > 0)
                        disposingEvent.WaitOne(timeout, false);
                }
                if (Application.Closing || closing)
                    break;
#if DEBUG_DEVICEADDRESS
                Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                {
                    return "Ready to send device address";
                });
#endif
                try
                {
                    pollReceived.Reset();
                    if (busIsInContentionMode == false)
                    {
#if DEBUG_DEVICEADDRESS
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                        {
                            return "Poll - In Contention;Waiting";
                        });
#endif
                        busIsInContentionModeEvent.Reset();
                        if (busIsInContentionModeEvent.WaitOne(2000, false) == false)
                        {
                            if (checkForOffline())
                                sendDeviceAddressReleaseEvent.Reset();
                            continue;
                        }
                    }
                    if (pollReceived.WaitOne(rand.Next(200), false))
                    {
                        if (ConnectionState == ConnectionState.Connected && messageToSend == null)
                            sendDeviceAddressReleaseEvent.Reset();
                        continue;
                    }
                    if (Application.Closing || closing)
                        break;
                    // The device cannot talk
                    if (busIsInContentionMode == false)
                        continue;
                    // Write the device address on the 485 bus
#if DEBUG_DEVICEADDRESS
                    Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                    {
                        return "Sending Poll";
                    });
#endif
                    pollReceived.Reset();
                    if (lowerLayerConnectionSend(new byte[] { deviceAddressByte }, blankDictionary))
                    {
                        disposingEvent.WaitOne(500, false);
                        if (pollReceived.WaitOne(0, false) == false)
                        {
                            if (checkForOffline())
                                sendDeviceAddressReleaseEvent.Reset();
                        }
                        else
                        {
                            if (ConnectionState == ConnectionState.Connected && messageToSend == null)
                                sendDeviceAddressReleaseEvent.Reset();
                        }
                        continue;
                    }
                    busIsInContentionMode = false;
                    // Prevent from sending the address too often                            
                    sendDeviceAddressLastTime.Reset();
                }
                catch
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopRS485MasterConnection, () =>
                    {
                        return "Failed while waiting for device address.";
                    });
                }
                if (Application.Closing || closing)
                    break;
            }
        }

        #endregion

        protected override void Dispose(bool disposing)
        {
            closing = true;
            disposingEvent.Set();
            busIsInContentionModeEvent.Set();
            sendDeviceAddressReleaseEvent.Set();
            contentionModeTimer.Change(Timeout.Infinite, Timeout.Infinite);
            offlineTimer.Change(Timeout.Infinite, Timeout.Infinite);
            if (sendDeviceAddressThread != null)
            {
                sendDeviceAddressThread.JoinOrRestart(3000);
                sendDeviceAddressThread = null;
            }
            if (lowerLayerConnection != null)
            {
                lowerLayerConnection.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(lowerLayerConnection_ConnectionStateChanged);
                lowerLayerConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(lowerLayerConnection_DataReceived);
            }
            contentionModeTimer.Dispose();
            offlineTimer.Dispose();
            busIsInContentionModeEvent.Close();
            sendDeviceAddressReleaseEvent.Close();
            messageSentEvent.Set();
            messageSentEvent.Close();
            pollReceived.Close();
            disposingEvent.Close();
            base.Dispose(true);
        }

        private void updateEncryptionVerification()
        {
            rand.NextBytes(encryptionVerification);

            byte[] sessionKey = calculateSessionKey((this.deviceAddressByte & 0x1F), baudRate, deviceLoopPassword, encryptionVerification);

            RijndaelManaged aesAlgorithm = new RijndaelManaged();
            aesAlgorithm.KeySize = 128;
            aesAlgorithm.Key = sessionKey;
            aesAlgorithm.Mode = CipherMode.CBC;
            aesAlgorithm.Padding = PaddingMode.None;
            aesAlgorithm.IV = new byte[16] { 0x50, 0x61, 0x63, 0x6F, 0x6D, 0x20, 0x53, 0x79, 0x73, 0x74, 0x65, 0x6D, 0x73, 0x2E, 0x2E, 0x2E };
            ICryptoTransform aesEncryptor = aesAlgorithm.CreateEncryptor();

            byte[] encryptedSessionKey = aesEncryptor.TransformFinalBlock(sessionKey, 0, 16);
            aesEncryptor.Dispose();
            byte[] hash = MD5Managed.ComputeHash(encryptedSessionKey, 0, 16);

            encryptionVerification[8] = hash[0];
            encryptionVerification[9] = hash[1];
            encryptionVerification[10] = hash[2];
            encryptionVerification[11] = hash[3];
        }

        private AesCryptor getSessionKey()
        {
            byte[] sessionKey = calculateSessionKey((this.deviceAddressByte & 0x1F), baudRate, deviceLoopPassword, randomNumbers);

            bool isDefaultPassword = true;
            for (int i = 0; i < 16; i++)
            {
                if (deviceLoopPassword[i] != (byte)(0x3F - i))
                {
                    isDefaultPassword = false;
                    break;
                }
            }
            if (isDefaultPassword == false)
            {
                ConfigurationManager.Instance.DeviceLoopPassword = deviceLoopPassword;
            }

            RijndaelManaged aesAlgorithm = new RijndaelManaged();
            aesAlgorithm.KeySize = 128;
            aesAlgorithm.Key = sessionKey;
            aesAlgorithm.Mode = CipherMode.CBC;
            aesAlgorithm.Padding = PaddingMode.None;
            aesAlgorithm.IV = new byte[16] { 0x50, 0x61, 0x63, 0x6F, 0x6D, 0x20, 0x53, 0x79, 0x73, 0x74, 0x65, 0x6D, 0x73, 0x2E, 0x2E, 0x2E };
            ICryptoTransform aesEncryptor = aesAlgorithm.CreateEncryptor();
            ICryptoTransform aesDecryptor = aesAlgorithm.CreateDecryptor();
            AesCryptor aesCryptor = new AesCryptor(aesEncryptor, aesDecryptor);

            lock (messageToSendSync)
            {
                encryptionKeyChanged = true;
                messageToSend = null;
                messageSentEvent.Set();
            }
            return aesCryptor;
        }

        private static byte[] calculateSessionKey(int deviceAddress, int baudRate, byte[] encryptionKey, byte[] checkCode)
        {
            byte[] deviceIdAsAscii = ASCIIEncoding.ASCII.GetBytes((deviceAddress + 1).ToString());
            byte[] baudRateAsAscii = ASCIIEncoding.ASCII.GetBytes(baudRate.ToString());

            byte[] data = new byte[24 + deviceIdAsAscii.Length + baudRateAsAscii.Length];
            Buffer.BlockCopy(encryptionKey, 0, data, 0, encryptionKey.Length);
            Buffer.BlockCopy(deviceIdAsAscii, 0, data, encryptionKey.Length, deviceIdAsAscii.Length);
            Buffer.BlockCopy(baudRateAsAscii, 0, data, encryptionKey.Length + deviceIdAsAscii.Length, baudRateAsAscii.Length);
            Buffer.BlockCopy(checkCode, 0, data, encryptionKey.Length + deviceIdAsAscii.Length + baudRateAsAscii.Length, 8); // 8 is specified as the checkCode length explicitly as updateEncryptionVerification passes in a 12 byte array.

            return MD5Managed.ComputeHash(data, 0, data.Length);
        }
    }
}
