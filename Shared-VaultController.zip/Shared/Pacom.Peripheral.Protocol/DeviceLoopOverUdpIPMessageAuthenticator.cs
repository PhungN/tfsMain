using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Messaging.DeviceLoopMessages;
using System.Security.Cryptography;
using System.Text;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Utils;

namespace Pacom.Peripheral.Protocol
{
    public class DeviceLoopOverUdpIPMessageAuthenticator : IDisposable
    {
        private static readonly byte[] encryptionInitializationVector = Encoding.UTF8.GetBytes("Pacom Systems...");

        private readonly DeviceType device;
        private readonly byte[] serialNumber;
        private readonly int unitNumber;
        private readonly FirmwareVersion version;

        private byte[] masterKey;
        private readonly byte[] serialNumberKey;

        private ICryptoTransform sessionKeyEncryptor = null;
        private ICryptoTransform sessionKeyDecryptor = null;
        private ICryptoTransform masterKeyEncryptor = null;
        private ICryptoTransform serialNumberEncryptor = null;

        private byte[] sessionKey = null;
        private byte[] sessionKey1 = null;
        private byte[] sessionKey2 = null;

        Pacom.Peripheral.Common.HMAC sessionKeyMacGenerator = null;
        Pacom.Peripheral.Common.HMAC sessionKey1MacGenerator = null;
        Pacom.Peripheral.Common.HMAC sessionKey2MacGenerator = null;

        private Random random = new Random();

        UInt32 deviceSequenceNumber;
        UInt32? lastPollSequenceNumber;
        byte sessionId;
        static bool deviceRestarted = true;

        private EncryptionType encryptionType = EncryptionType.None;

        private DeviceLoopMessageBase lastSentMessage = null;

        public DeviceLoopOverUdpIPMessageAuthenticator(DeviceType device, byte[] serialNumber, int unitNumber, FirmwareVersion version)
        {
            if (serialNumber == null || serialNumber.Length != 16)
                throw new ArgumentException("serialNumber is null or not of appropriate size", "serialNumber");

            this.device = device;
            this.serialNumber = serialNumber;
            this.unitNumber = unitNumber;
            this.version = version;

            byte[] masterKey = ConfigurationManager.Instance.MasterKey;

            if (masterKey != null)
                this.masterKey = masterKey;
            else
                this.masterKey = new byte[16];

            RijndaelManaged aesAlgorithm = new RijndaelManaged();
            aesAlgorithm.KeySize = this.masterKey.Length * 8;
            aesAlgorithm.Key = this.masterKey;
            aesAlgorithm.Mode = CipherMode.CBC;
            aesAlgorithm.Padding = PaddingMode.None;
            aesAlgorithm.IV = new byte[16];
            masterKeyEncryptor = aesAlgorithm.CreateEncryptor();

            serialNumberKey = Pacom.Peripheral.Common.SHA256Managed.ComputeHash(serialNumber, 0, serialNumber.Length);
            aesAlgorithm = new RijndaelManaged();
            aesAlgorithm.KeySize = 256;
            aesAlgorithm.Key = serialNumberKey;
            aesAlgorithm.Mode = CipherMode.CBC;
            aesAlgorithm.Padding = PaddingMode.None;
            aesAlgorithm.IV = encryptionInitializationVector;
            serialNumberEncryptor = aesAlgorithm.CreateEncryptor();

            if (deviceRestarted)
            {
                deviceSequenceNumber = (uint)random.Next();
                lastPollSequenceNumber = null;
            }
            sessionId = (byte)random.Next(255);
        }

        public DeviceLoopOverUdpIPMessageLogOn GenerateMessageType1()
        {
            bool newKeys = false;
            DeviceLoopOverUdpIPMessageLogOn message;
            lastSentMessage = null;

            lock (encryptionInitializationVector)
            {
                if (sessionKeyEncryptor != null)
                    sessionKeyEncryptor.Dispose();
                if (sessionKeyDecryptor != null)
                    sessionKeyDecryptor.Dispose();
                sessionKey = null;

                if (sessionKey1 == null || sessionKey2 == null)
                {
                    sessionKey1 = new byte[masterKey.Length];
                    sessionKey2 = new byte[32];

                    random.NextBytes(sessionKey1);
                    random.NextBytes(sessionKey2);

                    sessionId++;
                    deviceSequenceNumber++;
                    lastPollSequenceNumber = null;
                    newKeys = true;
                }

                byte[] sessionKey1EncryptedWithMasterKey = masterKeyEncryptor.TransformFinalBlock(sessionKey1, 0, sessionKey1.Length);
                byte[] sessionKey2EncryptedWithSerialNumber = serialNumberEncryptor.TransformFinalBlock(sessionKey2, 0, sessionKey2.Length);

                message = new DeviceLoopOverUdpIPMessageLogOn(unitNumber, sessionId, deviceSequenceNumber, serialNumber, device, version, deviceRestarted, sessionKey1EncryptedWithMasterKey, sessionKey2EncryptedWithSerialNumber);

                if (newKeys)
                {
                    if (sessionKey1.Length == 16)
                        sessionKey1MacGenerator = new Pacom.Peripheral.Common.HMACMD5(sessionKey1);
                    else if (sessionKey1.Length == 32)
                        sessionKey1MacGenerator = new Pacom.Peripheral.Common.HMACSHA256(sessionKey1);
                    sessionKey2MacGenerator = new Pacom.Peripheral.Common.HMACSHA256(sessionKey2);
                }

                message.HmacSessionKey1 = sessionKey1MacGenerator.ComputeHash(message.Data, 0, message.HmacSessionKeyOffset);
                message.HmacSessionKey2 = sessionKey2MacGenerator.ComputeHash(message.Data, 0, message.HmacSessionKeyOffset);
            }

            return message;
        }

        public DeviceLoopOverUdpIPMessageData GenerateMessageType4(DeviceLoopMessageBase deviceLoopMessage, UInt32 controllerSequenceNumber)
        {
            lock (encryptionInitializationVector)
            {
                if (sessionKeyMacGenerator == null)
                    return null;

                int dataPortionSize = deviceLoopMessage.Length + 3;

                int paddingLength = 0;
                if ((dataPortionSize % 16) != 0)
                    paddingLength = (16 - (dataPortionSize % 16));
                dataPortionSize += paddingLength;

                byte[] unencryptedData = new byte[dataPortionSize];

                // Message Count
                unencryptedData[0] = 1;

                // Size - a 2 byte little endian of the message data
                unencryptedData[1] = (byte)(deviceLoopMessage.Length & 0xFF);
                unencryptedData[2] = (byte)((deviceLoopMessage.Length & 0xFF00) >> 8);

                // Data
                Buffer.BlockCopy(deviceLoopMessage.Data, deviceLoopMessage.Offset, unencryptedData, 3, deviceLoopMessage.Length);

                byte[] randomData = new byte[paddingLength];
                random.NextBytes(randomData);
                Buffer.BlockCopy(randomData, 0, unencryptedData, deviceLoopMessage.Length + 3, paddingLength);

                byte[] encryptedData = sessionKeyEncryptor.TransformFinalBlock(unencryptedData, 0, unencryptedData.Length);

                if (lastSentMessage != deviceLoopMessage)
                {
                    deviceSequenceNumber++;
                    lastSentMessage = deviceLoopMessage;
                }
                DeviceLoopOverUdpIPMessageData message = new DeviceLoopOverUdpIPMessageData(unitNumber, DeviceLoopOverUdpIPMessageBase.ControllerUnitNumber, sessionId, deviceSequenceNumber, controllerSequenceNumber, encryptedData, encryptionType);
                int hmacSessionKeyOffset = message.GetHmacSessionKeyOffset(masterKey.Length);
                message.SetHmacSessionKey(sessionKeyMacGenerator.ComputeHash(message.Data, 0, hmacSessionKeyOffset), masterKey.Length);
                return message;
            }
        }

        public DeviceLoopOverUdpIPMessageAck GenerateMessageType5(UInt32 deviceSequenceNumber, UInt32 controllerSequenceNumber)
        {
            lock (encryptionInitializationVector)
            {
                if (sessionKeyMacGenerator == null)
                    return null;

                DeviceLoopOverUdpIPMessageAck message = new DeviceLoopOverUdpIPMessageAck(unitNumber, DeviceLoopOverUdpIPMessageBase.ControllerUnitNumber, sessionId, deviceSequenceNumber, controllerSequenceNumber, encryptionType);
                message.HmacSessionKey = sessionKeyMacGenerator.ComputeHash(message.Data, 0, message.HmacSessionKeyOffset);
                return message;
            }
        }

        public DeviceLoopOverUdpIPMessagePoll GenerateMessageType6(UInt32 pollSequenceNumber)
        {
            lock (encryptionInitializationVector)
            {
                if (sessionKeyMacGenerator == null)
                    return null;

                DeviceLoopOverUdpIPMessagePoll message = new DeviceLoopOverUdpIPMessagePoll(unitNumber, DeviceLoopOverUdpIPMessageBase.ControllerUnitNumber, sessionId, pollSequenceNumber, encryptionType);
                message.HmacSessionKey = sessionKeyMacGenerator.ComputeHash(message.Data, 0, message.HmacSessionKeyOffset);
                return message;
            }
        }

        public DeviceLoopOverUdpIPMessageLogOn AuthenticateMessage(DeviceLoopOverUdpIPMessageLogOff message)
        {
            lock (encryptionInitializationVector)
            {
                if (sessionKeyMacGenerator == null || sessionKeyDecryptor == null || sessionKeyEncryptor == null)
                    return null;

                byte[] calculatedHmacSessionKey = sessionKeyMacGenerator.ComputeHash(message.Data, 0, message.HmacSessionKeyOffset);

                if (calculatedHmacSessionKey.SequenceEqual(message.HmacSessionKey))
                {
                    if (message.SessionId != sessionId ||
                        pollSequenceValid(message.PollSequenceNumber) == false)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return string.Format("Received a message from the controller with incorrect sessionId or sequence number.");
                        });

                        return null;
                    }

                    return GenerateMessageType1();
                }
            }

            Logger.LogWarnMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
            {
                return string.Format("Controller sent a rogue message.");
            });
            return null;
        }

        public bool AuthenticateMessage(DeviceLoopOverUdpIPMessageAck message)
        {
            lock (encryptionInitializationVector)
            {
                if (sessionKeyMacGenerator == null || sessionKeyDecryptor == null || sessionKeyEncryptor == null)
                    return false;

                byte[] calculatedHmacSessionKey = sessionKeyMacGenerator.ComputeHash(message.Data, 0, message.HmacSessionKeyOffset);

                if (calculatedHmacSessionKey.SequenceEqual(message.HmacSessionKey))
                {
                    if (message.SessionId != sessionId ||
                        (message.DeviceSequenceNumber != deviceSequenceNumber && message.DeviceSequenceNumber != (deviceSequenceNumber - 1)))
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return string.Format("Received a message from the controller with incorrect sessionId or sequence number.");
                        });

                        return false;
                    }

                    return true;
                }
            }

            Logger.LogWarnMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
            {
                return string.Format("Controller sent a rogue message.");
            });
            return false;
        }

        public DeviceLoopOverUdpIPMessagePoll AuthenticateMessage(DeviceLoopOverUdpIPMessagePoll message)
        {
            lock (encryptionInitializationVector)
            {
                if (sessionKeyMacGenerator == null || sessionKeyDecryptor == null || sessionKeyEncryptor == null)
                    return null;

                byte[] calculatedHmacSessionKey = sessionKeyMacGenerator.ComputeHash(message.Data, 0, message.HmacSessionKeyOffset);

                if (calculatedHmacSessionKey.SequenceEqual(message.HmacSessionKey))
                {
                    if (message.SessionId != sessionId ||
                        message.FromController == false ||
                        pollSequenceValid(message.PollSequenceNumber) == false)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return string.Format("Received a message from the controller with incorrect sessionId or sequence number.");
                        });

                        return null;
                    }

                    return GenerateMessageType6(message.PollSequenceNumber);
                }
            }

            Logger.LogWarnMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
            {
                return string.Format("Controller sent a rogue message.");
            });
            return null;
        }

        public DeviceLoopOverUdpIPMessageAck AuthenticateMessage(DeviceLoopOverUdpIPMessageData message, DeviceLoopOverUdpIPMessageBase lastReceivedDataMessage, out DeviceLoopMessageBase[] messages)
        {
            messages = null;
            lock (encryptionInitializationVector)
            {
                if (sessionKeyMacGenerator == null || sessionKeyDecryptor == null || sessionKeyEncryptor == null)
                    return null;

                int hmacSessionKeyOffset = message.GetHmacSessionKeyOffset(masterKey.Length);
                byte[] calculatedHmacSessionKey = sessionKeyMacGenerator.ComputeHash(message.Data, 0, hmacSessionKeyOffset);
                byte[] messageHmacSessionKey = new byte[message.Data.Length - hmacSessionKeyOffset];
                Buffer.BlockCopy(message.Data, hmacSessionKeyOffset, messageHmacSessionKey, 0, messageHmacSessionKey.Length);
                if (calculatedHmacSessionKey.SequenceEqual(messageHmacSessionKey))
                {
                    if (message.SessionId != sessionId ||
                        (message.DeviceSequenceNumber != deviceSequenceNumber && message.DeviceSequenceNumber != (deviceSequenceNumber - 1)) ||
                        (controllerSequenceValid(message, lastReceivedDataMessage) == false))
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return string.Format("Received a message from the controller with incorrect sessionId or sequence number.");
                        });
                        return null;
                    }

                    byte[] encryptedData = message.GetEncryptedData(masterKey.Length);
                    byte[] rawDeviceLoopMessage = sessionKeyDecryptor.TransformFinalBlock(encryptedData, 0, encryptedData.Length);

                    try
                    {
                        int messageCount = rawDeviceLoopMessage[0];
                        messages = new DeviceLoopMessageBase[messageCount];

                        int dataPointer = 1;
                        for (int i = 0; i < messageCount; i++)
                        {
                            int size = (rawDeviceLoopMessage[dataPointer + 1] << 8) + rawDeviceLoopMessage[dataPointer];
                            dataPointer += 2;
                            try
                            {
                                messages[i] = DeviceLoopMessageBase.Parse(rawDeviceLoopMessage, dataPointer, size, DeviceType.PacomController);
                            }
                            catch
                            {
                                Logger.LogWarnMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                                {
                                    if (rawDeviceLoopMessage == null || rawDeviceLoopMessage.Length < size)
                                        return string.Format("Failed to parse message from controller. Data received length {0} is smaller than the expected size {1}.",
                                                             rawDeviceLoopMessage == null ? 0 : rawDeviceLoopMessage.Length, size);
                                    else
                                        return string.Format("Failed to parse message from controller. Data received was: {0}",
                                                             BitConverter.ToString(rawDeviceLoopMessage, dataPointer, size));
                                });
                                messages[i] = new UntranslatedMessage(rawDeviceLoopMessage, dataPointer, size);
                            }
                            dataPointer += size;
                        }
                    }
                    catch
                    {
                    }

                    return GenerateMessageType5(message.DeviceSequenceNumber, message.ControllerSequenceNumber);
                }
            }

            Logger.LogWarnMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
            {
                return string.Format("Controller sent a rogue message.");
            });

            return null;
        }


        public DeviceLoopOverUdpIPMessageLogOn AuthenticateMessage(DeviceLoopOverUdpIPMessageLogOnResponseSetMasterKey message)
        {
            lock (encryptionInitializationVector)
            {
                if (sessionKey2MacGenerator == null)
                    return null;

                byte[] calculatedHmacSessionKey2 = sessionKey2MacGenerator.ComputeHash(message.Data, 0, message.HmacSessionKeyOffset);

                if (calculatedHmacSessionKey2.SequenceEqual(message.HmacSessionKey2))
                {
                    if (message.SessionId != sessionId ||
                        (message.DeviceSequenceNumber != deviceSequenceNumber && message.DeviceSequenceNumber != (deviceSequenceNumber - 1)))
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return string.Format("Received a message from the controller with incorrect sessionId or sequence number.");
                        });

                        return null;
                    }

                    Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                    {
                        return string.Format("Received a new Master Key from the controller.");
                    });

                    RijndaelManaged aesAlgorithm = new RijndaelManaged();
                    aesAlgorithm.KeySize = 256;
                    aesAlgorithm.Key = sessionKey2;
                    aesAlgorithm.Mode = CipherMode.CBC;
                    aesAlgorithm.Padding = PaddingMode.None;
                    aesAlgorithm.IV = new byte[16];
                    ICryptoTransform sessionKey2Decryptor = aesAlgorithm.CreateDecryptor();

                    masterKey = sessionKey2Decryptor.TransformFinalBlock(message.MasterKeyEncryptedWithSessionKey2, 0, message.MasterKeyEncryptedWithSessionKey2.Length);
                    sessionKey2Decryptor.Dispose();

                    if (masterKeyEncryptor != null)
                        masterKeyEncryptor.Dispose();

                    aesAlgorithm = new RijndaelManaged();
                    aesAlgorithm.KeySize = this.masterKey.Length * 8;
                    aesAlgorithm.Key = this.masterKey;
                    aesAlgorithm.Mode = CipherMode.CBC;
                    aesAlgorithm.Padding = PaddingMode.None;
                    aesAlgorithm.IV = new byte[16];
                    masterKeyEncryptor = aesAlgorithm.CreateEncryptor();

                    // Clear out session keys 1 and 2 so that they are not reused
                    sessionKey1 = null;
                    sessionKey2 = null;

                    ConfigurationManager.Instance.MasterKey = masterKey;

                    return GenerateMessageType1();
                }
            }

            Logger.LogWarnMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
            {
                return string.Format("Controller sent a rogue message.");
            });
            return null;
        }

        public DeviceLoopOverUdpIPMessageAck AuthenticateMessage(DeviceLoopOverUdpIPMessageLogOnResponseSuccess message)
        {
            lock (encryptionInitializationVector)
            {
                if (sessionKey1 == null)
                    return null;

                RijndaelManaged aesAlgorithm = new RijndaelManaged();
                aesAlgorithm.KeySize = sessionKey1.Length * 8;
                aesAlgorithm.Key = sessionKey1;
                aesAlgorithm.Mode = CipherMode.CBC;
                aesAlgorithm.Padding = PaddingMode.None;
                aesAlgorithm.IV = new byte[16];
                ICryptoTransform sessionKey1Decryptor = aesAlgorithm.CreateDecryptor();

                sessionKey = sessionKey1Decryptor.TransformFinalBlock(message.SessionKeyEncryptedWithSessionKey1, 0, message.SessionKeyEncryptedWithSessionKey1.Length);
                if (sessionKey.Length == 16)
                    sessionKeyMacGenerator = new Pacom.Peripheral.Common.HMACMD5(sessionKey);
                else if (sessionKey.Length == 32)
                    sessionKeyMacGenerator = new Pacom.Peripheral.Common.HMACSHA256(sessionKey);

                byte[] calculatedHmacSessionKey = sessionKeyMacGenerator.ComputeHash(message.Data, 0, message.HmacSessionKeyOffset);

                if (calculatedHmacSessionKey.SequenceEqual(message.HmacSessionKey))
                {
                    if (message.SessionId != sessionId ||
                        (message.DeviceSequenceNumber != deviceSequenceNumber && message.DeviceSequenceNumber != (deviceSequenceNumber - 1)))
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return string.Format("Received a message from the controller with incorrect sessionId or sequence number.");
                        });

                        return null;
                    }

                    encryptionType = message.EncryptionType;
                    if ((encryptionType == EncryptionType.Aes128 && masterKey.Length != 16) ||
                        (encryptionType == EncryptionType.Aes256 && masterKey.Length != 32) ||
                        encryptionType == EncryptionType.None)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                        {
                            return string.Format("Invalid encryption specified.");
                        });
                        return null;
                    }

                    Logger.LogDebugMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
                    {
                        return string.Format("Logon successful.");
                    });

                    // Clear out session keys 1 and 2 so that they are not reused
                    sessionKey1 = null;
                    sessionKey2 = null;

                    if (sessionKeyEncryptor != null)
                        sessionKeyEncryptor.Dispose();
                    if (sessionKeyDecryptor != null)
                        sessionKeyDecryptor.Dispose();

                    aesAlgorithm = new RijndaelManaged();
                    aesAlgorithm.KeySize = sessionKey.Length * 8;
                    aesAlgorithm.Key = sessionKey;
                    aesAlgorithm.Mode = CipherMode.CBC;
                    aesAlgorithm.Padding = PaddingMode.None;
                    aesAlgorithm.IV = new byte[16];
                    sessionKeyEncryptor = aesAlgorithm.CreateEncryptor();
                    sessionKeyDecryptor = aesAlgorithm.CreateDecryptor();

                    deviceRestarted = false;

                    return GenerateMessageType5(message.DeviceSequenceNumber, message.ControllerSequenceNumber);
                }
            }

            Logger.LogWarnMessage(LoggerClassPrefixes.DeviceLoopINetMasterConnection, () =>
            {
                return string.Format("Controller sent a rogue message.");
            });
            return null;
        }

        public byte SessionId
        {
            get
            {
                return sessionId;
            }
        }

        private bool controllerSequenceValid(DeviceLoopOverUdpIPMessageData message, DeviceLoopOverUdpIPMessageBase lastReceivedDataMessage)
        {
            if (lastReceivedDataMessage == null)
                return true;
            int difference = (int)(message.ControllerSequenceNumber - lastReceivedDataMessage.ControllerSequenceNumber);
            if (difference > 0 && difference < 11)
                return true;
            return false;
        }

        private bool pollSequenceValid(UInt32 pollSequenceNumber)
        {
            if (lastPollSequenceNumber.HasValue == false)
            {
                lastPollSequenceNumber = pollSequenceNumber;
                return true;
            }

            int difference = (int)(pollSequenceNumber - lastPollSequenceNumber);
            if (difference > 0 && difference < 11)
            {
                lastPollSequenceNumber = pollSequenceNumber;
                return true;
            }
            return false;
        }

        public void Dispose()
        {
            if (sessionKeyEncryptor != null)
                sessionKeyEncryptor.Dispose();
            if (sessionKeyDecryptor != null)
                sessionKeyDecryptor.Dispose();
            if (masterKeyEncryptor != null)
                masterKeyEncryptor.Dispose();
            if (serialNumberEncryptor != null)
                serialNumberEncryptor.Dispose();
        }
    }
}
