﻿using System;
using System.Collections.Generic;

namespace Pacom.Peripheral.Protocol
{
    public class ReceivedDataEventArgs : EventArgs
    {
        private readonly byte[] data;
        private readonly Dictionary<string, object> metadata;

        public ReceivedDataEventArgs(byte[] data, Dictionary<string, object> metadata)
        {
            this.data = data;
            this.metadata = metadata;
        }

        public byte[] Data
        {
            get { return data; }
        }

        public Dictionary<string, object> Metadata
        {
            get { return metadata; }
        }
    }
}
