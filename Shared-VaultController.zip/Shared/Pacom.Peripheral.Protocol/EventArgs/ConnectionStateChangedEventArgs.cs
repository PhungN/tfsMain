﻿using System;

namespace Pacom.Peripheral.Protocol
{
    public class ConnectionStateChangedEventArgs : EventArgs
    {
        private readonly ConnectionState newConnectionState;

        private readonly DisconnectionReason disconnectionReason;

        public ConnectionStateChangedEventArgs(ConnectionState newConnectionState)
        {
            this.newConnectionState = newConnectionState;
            this.disconnectionReason = DisconnectionReason.Other;
        }

        public ConnectionStateChangedEventArgs(ConnectionState newConnectionState, DisconnectionReason disconnectionReason)
        {
            this.newConnectionState = newConnectionState;
            this.disconnectionReason = disconnectionReason;
        }

        public ConnectionState NewConnectionState
        {
            get { return newConnectionState; }
        }

        public DisconnectionReason DisconnectionReason
        {
            get { return disconnectionReason; }
        }
    }
}
