﻿using System;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Protocol
{
    public abstract class OsdpConnectionReceivedDataBase
    {
        public OsdpConnectionReceivedDataBase(int deviceAddress, int logicalReaderId)
        {
            this.DeviceAddress = deviceAddress;
            this.LogicalReaderId = logicalReaderId;
            this.Vendor = ReaderManufacturer.Unknown;
            this.SerialNumber = 0;
            this.FirmwareVersion = new Version(0, 0, 0);
            this.ModelNumber = 0;
        }

        public int DeviceAddress
        {
            get;
            private set;
        }

        public int LogicalReaderId
        {
            get;
            private set;
        }

        public ReaderManufacturer Vendor
        {
            get;
            private set;
        }

        public int ModelNumber
        {
            get;
            private set;
        }

        public int Version
        {
            get;
            private set;
        }

        public Version FirmwareVersion
        {
            get;
            private set;
        }

        public int SerialNumber
        {
            get;
            private set;
        }

        public void SetDeviceInformation(ReaderManufacturer vendor, int modelNumber, int version, Version firmwareVersion, int serialNumber)
        {
            this.Vendor = vendor;
            this.ModelNumber = modelNumber;
            this.Version = version;
            this.FirmwareVersion = firmwareVersion;
            this.SerialNumber = serialNumber;
        }

        internal void SetDeviceInformation(OsdpDeviceLoopDevice osdpDevice)
        {
            SetDeviceInformation(osdpDevice.Vendor, osdpDevice.ModelNumber, osdpDevice.Version, osdpDevice.FirmwareVersion, osdpDevice.SerialNumber);
        }
    }
}
