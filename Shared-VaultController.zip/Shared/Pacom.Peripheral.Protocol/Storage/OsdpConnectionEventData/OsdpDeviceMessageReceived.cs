﻿using Pacom.Peripheral.OsdpMessaging;

namespace Pacom.Peripheral.Protocol
{
    public class OsdpDeviceMessageReceived : OsdpConnectionReceivedDataBase
    {
        public bool IsUnauthorizedCard
        {
            get;
            private set;
        }
        public OsdpMessageBase Message
        {
            get;
            private set;
        }

        public OsdpDeviceMessageReceived(int deviceAddress, int logicalReaderId, OsdpMessageBase message)
            : this(deviceAddress, logicalReaderId, message, false)
        {
        }

        public OsdpDeviceMessageReceived(int deviceAddress, int logicalReaderId, OsdpMessageBase message, bool isUnauthorizedCard)
            : base(deviceAddress, logicalReaderId)
        {
            this.Message = message;
            IsUnauthorizedCard = isUnauthorizedCard;
        }
    }
}
