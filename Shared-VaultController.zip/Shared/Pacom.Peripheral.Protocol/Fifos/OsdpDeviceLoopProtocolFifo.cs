﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.OsdpMessaging;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// This class takes chunks of data as they are received and generates events of valid, complete OSDP messages.
    /// </summary>
    public class OsdpDeviceLoopProtocolFifo
    {        
        private byte[] fifoBuffer = new byte[OsdpMessageBase.MaxOsdpMessageLength * 2];
        private int fifoBufferEnqueueIndex = 0;
        private int fifoBufferProcessIndex = 0;

        /// <summary>
        /// Event fired when a complete valid message is available.
        /// </summary>
        public event EventHandler<ReceivedDataEventArgs> MessageAvailable;

        /// <summary>
        /// Initializes a new instance of the DeviceLoopProtocolFifo class.
        /// </summary>
        public OsdpDeviceLoopProtocolFifo()
        {
            Reset();
        }

        /// <summary>
        /// Returns true if there is no bytes in the FIFO buffer either because the bytes all belong to 
        /// previous messages or because the bytes have been in the buffer long enough to time out.
        /// </summary>
        public bool IsEmpty
        {
            get
            {
                return fifoBufferProcessIndex == fifoBufferEnqueueIndex;
            }
        }

        private static int byteArrayContains(byte[] buffer, byte toFind, int startIndex, int bufferLength)
        {
            if (bufferLength > buffer.Length)
                bufferLength = buffer.Length;

            for (int currentBufferOffset = startIndex; currentBufferOffset < bufferLength; currentBufferOffset++)
            {
                if (buffer[currentBufferOffset] == toFind)
                    return currentBufferOffset;
            }
            return -1;
        }

        private void processBuffer()
        {
            //
            // Byte
            // 0      1      2        3       4     .....  n-1            n 
            // SOM    ADDR   LEN_LSB  LEN_MSB CTRL  .....  CKSUM/CRC_LSB  CRC_MSB
            // 0x53   
            //
            while (fifoBufferProcessIndex < fifoBufferEnqueueIndex && fifoBufferEnqueueIndex >= OsdpMessageBase.MinOsdpMessageLength)
            {
                int startOfTextIndex = byteArrayContains(fifoBuffer, OsdpMessageBase.StartOfMessageByte, fifoBufferProcessIndex, fifoBufferEnqueueIndex);
                if (startOfTextIndex == -1)
                {
                    Reset();
                    return;
                }
                fifoBufferProcessIndex = startOfTextIndex;

                int bytesAvailable = fifoBufferEnqueueIndex - startOfTextIndex;
                if (bytesAvailable < OsdpMessageBase.MinOsdpMessageLength)
                    return;
                int length = (fifoBuffer[startOfTextIndex + 3] << 8) | fifoBuffer[startOfTextIndex + 2];
                if (length < OsdpMessageBase.MinOsdpMessageLength || length > OsdpMessageBase.MaxOsdpMessageLength)
                {
                    fifoBufferProcessIndex = startOfTextIndex + 1;
                    continue;
                }
                if (bytesAvailable < length)
                    return;
                int controlByte = fifoBuffer[startOfTextIndex + 4];
                bool crcPresent = ((controlByte & 0x04) != 0);

                if (crcPresent)
                {
                    ushort calculatedCrc = Crc16Ccitt.ComputeChecksum(fifoBuffer, fifoBufferProcessIndex, length - 2);
                    ushort receivedCrc = (ushort)((fifoBuffer[fifoBufferProcessIndex + length - 1] << 8) + fifoBuffer[fifoBufferProcessIndex + length - 2]);
                    if (calculatedCrc != receivedCrc)
                    {
                        fifoBufferProcessIndex = startOfTextIndex + 1;
                        continue;
                    }
                }
                else
                {
                    byte calculatedChecksum = computeCheckSum(fifoBuffer, fifoBufferProcessIndex, length);
                    if (calculatedChecksum != 0)
                    {
                        fifoBufferProcessIndex = startOfTextIndex + 1;
                        continue;
                    }
                }

                if (MessageAvailable != null)
                {
                    byte[] message = new byte[length];
                    Buffer.BlockCopy(fifoBuffer, fifoBufferProcessIndex, message, 0, length);
                    try
                    {
                        MessageAvailable(this, new ReceivedDataEventArgs(message, null));
                    }
                    catch (Exception ex)
                    {
                        Logger.LogErrorMessage(LoggerClassPrefixes.OsdpDeviceLoopMasterConnection, () =>
                        {
                            return "Error while processing received data. " + ex.ToString();
                        });
                    }
                }
                fifoBufferProcessIndex += length;
                if (fifoBufferProcessIndex == fifoBufferEnqueueIndex)
                {
                    Reset();
                    break;
                }
            }
        }

        private static byte computeCheckSum(byte[] bytes, int index, int count)
        {
            byte sum = 0;
            for (int i = index; i < index + count; i++)
                sum += bytes[i];
            sum = (byte)~sum;
            sum++;
            return sum;
        }

        /// <summary>
        /// Adds the contents of an array to the end of the FIFO.
        /// </summary>
        /// <param name="buffer">The contents to add to the array.</param>
        /// <param name="offset">The offset into the array from which to start.</param>
        /// <param name="count">The number of bytes to add to the FIFO.</param>
        public void Enqueue(byte[] buffer, int offset, int count)
        {
            lock (fifoBuffer)
            {
                Buffer.BlockCopy(buffer, offset, fifoBuffer, fifoBufferEnqueueIndex, count);
                fifoBufferEnqueueIndex += count;
                processBuffer();
            }
        }

        /// <summary>
        /// Empties the contents of all buffers.
        /// </summary>
        public void Reset()
        {
            lock (fifoBuffer)
            {
                fifoBufferEnqueueIndex = 0;
                fifoBufferProcessIndex = 0;
            }
        }
    }
}
