﻿using System;
using System.Collections;
using System.Security.Cryptography;
using System.Text;
using System.Collections.Generic;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// This class takes chunks of data as they are received and generates events of valid, complete messages.
    /// </summary>
    public class DeviceLoopProtocolOverIPFifo
    {
        private readonly byte[] fifoBuffer = new byte[2000];
        private int fifoBufferEnqueueIndex = 0;
        private int fifoBufferProcessIndex = 0; 
        
        private TimeSpan interMessageTimeout;
        private TimeLimit lastMessageReceivedTime = new TimeLimit();

        private readonly byte[] headerFromControllerBytes = { 0x50, 0x03 };
        private readonly byte[] headerFromDeviceBytes = { 0x50, 0x02 };
        private readonly byte[] headerBytes;
        private readonly byte[] encryptionInitializationVector = Encoding.UTF8.GetBytes("Pacom Systems...");

        private ICryptoTransform aesDecryptor = null;

        /// <summary>
        /// Event fired when a complete valid message is available.
        /// </summary>
        public event EventHandler<ReceivedDataEventArgs> MessageAvailable;

        /// <summary>
        /// Initializes a new instance of the DeviceLoopProtocolOverIPFifo class that is empty.
        /// </summary>
        /// <param name="millisecondsInterMessageTimeout">The maximum time between two consecutive bytes before the current message is marked as incomplete and disposed of.</param>
        /// <param name="fromController">True if the messages for this fifo originate from a controller, otherwise false.</param>
        public DeviceLoopProtocolOverIPFifo(int millisecondsInterMessageTimeout, bool fromController)
        {
            this.interMessageTimeout = new TimeSpan(0, 0, 0, 0, millisecondsInterMessageTimeout);
            resetFifo();
            if (fromController)
                headerBytes = headerFromControllerBytes;
            else
                headerBytes = headerFromDeviceBytes;
        }

        private void resetFifo()
        {
            fifoBufferEnqueueIndex = 0;
            fifoBufferProcessIndex = 0;
        }

        private void processBuffer()
        {
            byte[] message;

            while (true)
            {
                // Find the 50 03 or 50 02 header bytes of the message ensuring we still have at least the minimum message size
                while ((fifoBufferEnqueueIndex - fifoBufferProcessIndex) >= 46)
                {
                    if (fifoBuffer[fifoBufferProcessIndex + 2] == headerBytes[0] && fifoBuffer[fifoBufferProcessIndex + 3] == headerBytes[1])
                        break;
                    fifoBufferProcessIndex++;
                }

                if ((fifoBufferEnqueueIndex - fifoBufferProcessIndex) < 46)
                {
                    if (fifoBufferEnqueueIndex == fifoBufferProcessIndex || fifoBufferEnqueueIndex > 1800)
                        resetFifo();
                    return;
                }

                // Check that the header length seems reasonable
                if (fifoBuffer[fifoBufferProcessIndex] != 0x00 || fifoBuffer[fifoBufferProcessIndex + 1] != 0x1C)
                {
                    fifoBufferProcessIndex++;
                    continue;
                }

                int dataSize = (fifoBuffer[fifoBufferProcessIndex + 29] << 8) + fifoBuffer[fifoBufferProcessIndex + 28];
                int encryptedPortionSize = dataSize + 2;
                int completeMessageSize;
                if ((encryptedPortionSize % 16) == 0)
                    completeMessageSize = encryptedPortionSize + 30;
                else
                    completeMessageSize = (((encryptedPortionSize / 16) + 1) * 16) + 30;

                if ((fifoBufferEnqueueIndex - fifoBufferProcessIndex) < completeMessageSize)
                    return;

                ICryptoTransform decryptor = createDecryptor();

                // At this point we have a complete message ready to be decrypted
                byte[] decryptedData = decryptor.TransformFinalBlock(fifoBuffer, fifoBufferProcessIndex + 30, (completeMessageSize - 30));
                message = new byte[completeMessageSize];
                try
                {
                    Buffer.BlockCopy(fifoBuffer, fifoBufferProcessIndex, message, 0, 30);
                    Buffer.BlockCopy(decryptedData, 0, message, 30, (completeMessageSize - 30));
                }
                catch
                {
                }
                fifoBufferProcessIndex += completeMessageSize;
                if (this.MessageAvailable != null)
                    this.MessageAvailable(this, new ReceivedDataEventArgs(message, new Dictionary<string, object>()));
            }
        }

        private ICryptoTransform createDecryptor()
        {
            // It is assumed that the FIFO will only exist for the life of a TCP connection and that the controller
            // will not change its serial number for the life of the connection.
            if (aesDecryptor == null)
            {
                byte[] aesKey = new byte[16];
                Buffer.BlockCopy(fifoBuffer, 4, aesKey, 0, aesKey.Length);
                aesKey = MD5.Create().ComputeHash(aesKey);

                RijndaelManaged aesAlgorithm = new RijndaelManaged();
                aesAlgorithm.KeySize = 128;
                aesAlgorithm.Key = aesKey;
                aesAlgorithm.Mode = CipherMode.CBC;
                aesAlgorithm.Padding = PaddingMode.None;
                aesAlgorithm.IV = encryptionInitializationVector;
                aesDecryptor = aesAlgorithm.CreateDecryptor();
            }
            return aesDecryptor;
        }

        /// <summary>
        /// Adds the contents of an array to the end of the FIFO.
        /// </summary>
        /// <param name="buffer">The contents to add to the array.</param>
        /// <param name="offset">The offset into the array from which to start.</param>
        /// <param name="count">The number of bytes to add to the FIFO.</param>
        public void Enqueue(byte[] buffer, int offset, int count)
        {
            lock (fifoBuffer)
            {
                if (lastMessageReceivedTime.ElapsedTime > this.interMessageTimeout.TotalMilliseconds)
                    resetFifo();
                this.lastMessageReceivedTime.Reset();

                Buffer.BlockCopy(buffer, offset, this.fifoBuffer, this.fifoBufferEnqueueIndex, count);
                fifoBufferEnqueueIndex += count;
                processBuffer();
            }
        }

        /// <summary>
        /// Empties the contents of all buffers.
        /// </summary>
        public void Reset()
        {
            resetFifo();
        }
    }
}
