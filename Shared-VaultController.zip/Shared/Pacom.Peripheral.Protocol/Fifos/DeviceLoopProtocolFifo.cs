﻿using System;
using System.Collections.Generic;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// This class takes chunks of data as they are received and generates events of valid, complete messages.
    /// </summary>
    public class DeviceLoopProtocolFifo
    {
        private readonly byte[] fifoBuffer = new byte[2000];
        private int fifoBufferEnqueueIndex = 0;
        private int fifoBufferProcessIndex = 0;

        /// <summary>
        /// Event fired when a complete valid message is available.
        /// </summary>
        public event EventHandler<ReceivedDataEventArgs> MessageAvailable;

        /// <summary>
        /// Initializes a new instance of the DeviceLoopProtocolFifo class.
        /// </summary>
        public DeviceLoopProtocolFifo()
        {
            resetFifo();
        }

        private void resetFifo()
        {
            fifoBufferEnqueueIndex = 0;
            fifoBufferProcessIndex = 0;
        }

        /// <summary>
        /// Returns true if there is no bytes in the FIFO buffer either because the bytes all belong to 
        /// previous messages or because the bytes have been in the buffer long enough to time out.
        /// </summary>
        public bool IsEmpty
        {
            get
            {
                return fifoBufferEnqueueIndex == fifoBufferProcessIndex;
            }
        }

        private void processBuffer()
        {
            while (true)
            {
                // Search for a valid packet (111XXXXX 0100XXXX ...)
                while ((fifoBufferEnqueueIndex - fifoBufferProcessIndex) >= 3)
                {
                    if ((fifoBuffer[fifoBufferProcessIndex] & 0xE0) == 0xE0 && (fifoBuffer[fifoBufferProcessIndex + 1] & 0xF0) == 0x40)
                        break;
                    fifoBufferProcessIndex++;
                }

                if ((fifoBufferEnqueueIndex - fifoBufferProcessIndex) < 3)
                {
                    if (fifoBufferEnqueueIndex == fifoBufferProcessIndex || fifoBufferEnqueueIndex > 1800)
                        resetFifo();
                    return;
                }

                int control = fifoBuffer[fifoBufferProcessIndex + 1];
                int minimumMessageLength = 0;

                switch (control & 0x7)
                {
                    case 0:
                        minimumMessageLength = 3;
                        break;
                    case 1:
                        minimumMessageLength = 5;
                        break;
                    case 3:
                        minimumMessageLength = 3;
                        break;
                    case 4:
                        minimumMessageLength = 3;
                        break;
                    case 5:
                        minimumMessageLength = 4;
                        break;
                    case 6:
                        minimumMessageLength = 5;
                        break;
                    case 7:
                        minimumMessageLength = 3;
                        break;
                }

                // If the control byte is invalid, discard the message and continue processing
                if (minimumMessageLength == 0)
                {
                    fifoBufferProcessIndex++;
                    continue;
                }

                // If there is not enough data yet, return
                if ((fifoBufferEnqueueIndex - fifoBufferProcessIndex) < minimumMessageLength)
                    return;

                int messageLength = minimumMessageLength;
                if (minimumMessageLength == 5)
                {
                    // While the spec limits the message length field to 5 bits, in practice this is not
                    // the case and should not be tested for.
                    messageLength = fifoBuffer[fifoBufferProcessIndex + 2];

                    // Add for address, control and byte count
                    messageLength += 3;
                }

                // If there is not enough data yet, return
                if ((fifoBufferEnqueueIndex - fifoBufferProcessIndex) < messageLength)
                    return;

                // There are enough bytes to constitue a valid message but still need to check the checksum
                if (isValidChecksum(fifoBuffer, fifoBufferProcessIndex, messageLength) == false)
                {
                    fifoBufferProcessIndex += messageLength;

                    // Continue processing
                    continue;
                }

                byte[] message = new byte[messageLength];
                Buffer.BlockCopy(fifoBuffer, fifoBufferProcessIndex, message, 0, messageLength);
                fifoBufferProcessIndex += messageLength;
                if (this.MessageAvailable != null)
                    this.MessageAvailable(this, new ReceivedDataEventArgs(message, new Dictionary<string, object>()));
            }
        }

        private static bool isValidChecksum(byte[] message, int offset, int length)
        {
            int calculatedChecksum = 0;
            for (int i = offset; i < (offset + length - 1); i++)
            {
                calculatedChecksum += message[i];
            }
            calculatedChecksum *= -1;

            if (length > 4)
            {
                // Structure 3 with a CS-8 checksum
                calculatedChecksum &= 0x000000FF;
            }
            else
            {
                // Structure 1 or 2 with a CS-5 checksum
                calculatedChecksum &= 0x0000001F;
            }

            return (byte)calculatedChecksum == message[offset + length - 1];
        }

        /// <summary>
        /// Adds the contents of an array to the end of the FIFO.
        /// </summary>
        /// <param name="buffer">The contents to add to the array.</param>
        /// <param name="offset">The offset into the array from which to start.</param>
        /// <param name="count">The number of bytes to add to the FIFO.</param>
        public void Enqueue(byte[] buffer, int offset, int count)
        {
            lock (fifoBuffer)
            {
                Buffer.BlockCopy(buffer, offset, this.fifoBuffer, this.fifoBufferEnqueueIndex, count);
                fifoBufferEnqueueIndex += count;
                processBuffer();
            }
        }

        /// <summary>
        /// Empties the contents of all buffers.
        /// </summary>
        public void Reset()
        {
            resetFifo();
        }
    }
}
