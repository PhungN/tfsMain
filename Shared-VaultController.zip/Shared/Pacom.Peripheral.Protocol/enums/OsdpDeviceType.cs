﻿using System;

namespace Pacom.Peripheral.Protocol
{
    public enum OsdpDeviceType
    {
        Other,
        Pacom8705,
        Pacom8707,
    }
}
