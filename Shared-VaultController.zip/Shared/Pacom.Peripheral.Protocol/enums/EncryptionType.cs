﻿using System;

namespace Pacom.Peripheral.Protocol
{
    public enum EncryptionType
    {
        None = 0,
        Aes128 = 1,
        Aes256 = 2,
    };
}