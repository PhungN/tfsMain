﻿using System;

namespace Pacom.Peripheral.Protocol
{
    internal enum OsdpDeviceResponse
    {
        /// <summary>
        /// The correct response has been received
        /// </summary>
        Ok,
        /// <summary>
        /// Device is busy
        /// </summary>
        Busy,
        /// <summary>
        /// Device did not sent requested response
        /// </summary>
        InvalidResponse,
        /// <summary>
        /// Timeout is up and device did not respond.
        /// </summary>
        NoResponse,
        /// <summary>
        /// The device did not send expected sequence number
        /// </summary>
        DeviceOutOfSequence,

        /// <summary>
        /// Connection closed
        /// </summary>
        ConnectionClosed,

        /// <summary>
        /// General Error
        /// </summary>
        Error,

        /// <summary>
        /// Device is NAK
        /// </summary>
        NAK, 

        /// <summary>
        /// Device restart
        /// </summary>
        DeviceRestart, 

        /// <summary>
        /// Skip checking device
        /// </summary>
        DeviceSkip
    }
}
