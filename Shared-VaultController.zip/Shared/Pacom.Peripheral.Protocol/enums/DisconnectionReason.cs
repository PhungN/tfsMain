using System;

namespace Pacom.Peripheral.Protocol
{
    public enum DisconnectionReason
    {
        Other,
        TcpIPAddressAlreadyInUse,
        TcpIPRemoteEndClosed,
        DataNotFound,
        /// <summary>
        /// Attempt to reconnect if possible.
        /// </summary>
        ImmediateReconnect
    };
}