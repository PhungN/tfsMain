﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using Pacom.Configuration.ConfigurationCommon;

namespace Pacom.Peripheral.Protocol
{
    /// <summary>
    /// The level of severity of the syslog event.
    /// </summary>
    public enum SyslogLevel
    {
        Emergency = 0,
        Alert = 1,
        Critical = 2,
        Error = 3,
        Warning = 4,
        Notice = 5,
        Information = 6,
        Debug = 7,
    }
}