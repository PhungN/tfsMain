﻿using System;

namespace Pacom.Peripheral.Protocol
{
    internal enum OsdpDeviceLifeStep
    {
        DeviceOffline,
        DeviceNotDiscovered,
        RequestDeviceCapabilities,
        ReadyToGoOnline,
        EstablishSecureSessionStep1,
        EstablishSecureSessionStep2,
        DeviceFirstTimeIsOnline,
        DeviceOnlineFirstTime,
        DeviceOnline,
        ProgramEncryptionKeyStep1,
        ProgramEncryptionKeyStep2,
        ProgramEncryptionKeyStep3,
        ProgramEncryptionKeyStep4,
    }
}
