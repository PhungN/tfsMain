﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.Messaging.DeviceLoopMessages;
using Pacom.Peripheral.Protocol;

namespace Pacom.Peripheral.Communications
{
    /// <summary>
    /// This class is responsible for establishing and maintaining connections to a controller.
    /// This class is also responsible for queuing and sending messages (alarms / responses) to the controller.
    /// Note. Message queues are flushed when communications are lost.
    /// 
    /// UDP implementation document can be found at: VSS $/RTU/Documentation/Word Documents/Controller Device Loop over UDPIP operation.doc
    /// 
    /// </summary>
    public class CommunicationsManager : ICommunicationsManager, IDisposable
    {
        private Timer recreateIPPortTimer = null;
        private bool recreateIPPortTimerRunning = false;
        private const int maximumNetworkLatency = 250;
        public const int MaxIdleTime = 300000;

        private UdpIPConnection udpIPAutodiscoveryConnection = null;

        private volatile ProtocolConnectionBase tcpIPPort = null;
        private volatile ProtocolConnectionBase udpIPPort = null;
        private UdpIPConnection udpIPConnection = null;
        private IPConnectionConfiguration ipPortConfiguration = null;
        private readonly object tcpSync = new object();
        private readonly object udpSync = new object();
        private readonly object udpIPAutodiscoverySync = new object();

        private Timer disposeTcpPortTimer = null;
        private Timer disposeUdpPortTimer = null;

        private Timer recreateSerialPortTimer = null;
        private bool recreateSerialPortTimerRunning = false;

        private ProtocolConnectionBase serialPort = null;
        private SerialConnectionConfiguration serialPortConfiguration = null;
        private readonly object serialSync = new object();

        private Dictionary<string, object> broadcastDictionary = new Dictionary<string, object>();

        // Link layer factories
        private DeviceLoopProtocolManager deviceLoopProtocolManager = new DeviceLoopProtocolManager();
        private DeviceLoopProtocolOverIPManager deviceLoopProtocolOverIPManager = new DeviceLoopProtocolOverIPManager();
        private DeviceLoopProtocolOverUdpIPManager deviceLoopProtocolOverUdpIPManager = new DeviceLoopProtocolOverUdpIPManager();

        // Physical layer factories
        private SerialManager serialManager = new SerialManager();
        private TcpIPManager tcpIPManager = TcpIPManager.Instance;
        private UdpIPManager udpIPManager = new UdpIPManager();
        private DisconnectionReason lastTcpDisconnectionReason = DisconnectionReason.Other;

        private ConnectionsStatus connectionsStatus = null;

        private Thread sendThread;
        private readonly ManualResetEvent sendPending = new ManualResetEvent(false);
        private readonly List<DeviceLoopMessageAndConnection> outgoingMessageQueue = new List<DeviceLoopMessageAndConnection>();

        private Thread processThread;
        private readonly ManualResetEvent processPending = new ManualResetEvent(false);
        private readonly List<DeviceLoopMessageAndConnection> toProcessMessageQueue = new List<DeviceLoopMessageAndConnection>();
        
        private byte[] serialNumber = new byte[] { 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32 };
        private FirmwareVersion applicationVersion = new FirmwareVersion("01.00");

        #region Instance management

        private static CommunicationsManager instance = null;

        public static CommunicationsManager CreateInstance()
        {
            if (instance == null)
                instance = new CommunicationsManager();
            return instance;
        }

        public static CommunicationsManager Instance
        {
            get
            {
                if (instance == null)
                    instanceMustBeCreated();
                return instance;
            }
        }
                
        private CommunicationsManager()
        {
            recreateIPPortTimer = new Timer(recreateIPPortMethod, null, Timeout.Infinite, Timeout.Infinite);            
            recreateSerialPortTimer = new Timer(recreateSerialPortMethod, null, Timeout.Infinite, Timeout.Infinite);
            disposeTcpPortTimer = new Timer(disposeTcpPortMethod, null, Timeout.Infinite, Timeout.Infinite);
            disposeUdpPortTimer = new Timer(disposeUdpPortMethod, null, Timeout.Infinite, Timeout.Infinite);

            connectionsStatus = new ConnectionsStatus();
            connectionsStatus.DisposeTcpConnection += new EventHandler<EventArgs>(connectionsStatus_DisposeTcpConnection);
            connectionsStatus.DisposeUdpConnection += new EventHandler<EventArgs>(connectionsStatus_DisposeUdpConnection);

            ConfigurationManager.Instance.ConfigurationChanged += new EventHandler<EventArgs>(configurationManager_ConfigurationChanged);
            configurationManager_ConfigurationChanged(null, null);

            // Deactivate the RS485 transmit enable pin
            Pcb.DeactivateOnboardRs485Driver();

            sendThread = new Thread(new ThreadStart(messageSendThreadMethod));
            sendThread.Name = "Message Send Thread";
            sendThread.IsBackground = true;
            sendThread.Priority = ThreadPriority.Normal;
            sendThread.Start();

            processThread = new Thread(new ThreadStart(messageProcessThreadMethod));
            processThread.Name = "Message Process Thread";
            processThread.IsBackground = true;
            processThread.Priority = ThreadPriority.Normal;
            processThread.Start();
        }

        private static void instanceMustBeCreated()
        {
            Logger.LogErrorMessage(LoggerClassPrefixes.CommunicationManager, () =>
            {
                return "Communication Manager is not ready yet.";
            });
        }

        #endregion

        #region Configuration handling

        private void configurationManager_ConfigurationChanged(object sender, EventArgs e)
        {
            copyConfigurationToLocal();

            if (ConfigurationManager.Instance.ConnectionTcp != null)
            {
                // Determine if IP connections must be recreated
                if (ipPortConfiguration == null
                    || ipPortConfiguration.Equals(ConfigurationManager.Instance.ConnectionTcp) == false)
                {
                    ipPortConfiguration = new IPConnectionConfiguration(
                        ConfigurationManager.Instance.ConnectionTcp.ConnectionRequired,
                        ConfigurationManager.Instance.UseAutoDiscovery,
                        // If auto discovery is enabled, the controller address must be discarded.
                        ConfigurationManager.Instance.UseAutoDiscovery == true ? NetworkAddress.CreateAddressAny() : ConfigurationManager.Instance.ConnectionTcp.ControllerAddress,
                        ConfigurationManager.Instance.ConnectionTcp.Port,
                        ConfigurationManager.Instance.ConnectionTcp.ControllerNumber,
                        ConfigurationManager.Instance.DeviceLoopAddress(DeviceLoopAddressType.IP));

                    // Prepare broadcast parameters for auto discovery
                    broadcastDictionary.Clear();
                    broadcastDictionary.Add("RemoteEndPoint", new IPEndPoint(IPAddress.Parse("255.255.255.255"), ipPortConfiguration.Port));

                    if (recreateIPPortTimerRunning == false)
                    {
                        recreateIPPortTimerRunning = true;
                        recreateIPPortTimer.Change(500, Timeout.Infinite);
                    }
                }
            }

            // Determine if serial connection must be recreated
            if (ConfigurationManager.Instance.ConnectionSerial != null)
            {
                if (serialPortConfiguration == null
                    || serialPortConfiguration.Equals(ConfigurationManager.Instance.ConnectionSerial) == false 
                    || Serial485Connection.LastSentMessageTimeCom1.ElapsedTime > CommunicationsManager.MaxIdleTime)
                {
                    serialPortConfiguration = new SerialConnectionConfiguration(
                        ConfigurationManager.Instance.ConnectionSerial.ConnectionRequired,
                        ConfigurationManager.Instance.ConnectionSerial.BaudRate,
                        ConfigurationManager.Instance.DeviceLoopAddress(DeviceLoopAddressType.Serial));
                    connectionsStatus.CurrentBaudRate = serialPortConfiguration.BaudRate;
                    connectionsStatus.SerialConnectionValid = false;
                    if (recreateSerialPortTimerRunning == false)
                    {
                        recreateSerialPortTimerRunning = true;
                        recreateSerialPortTimer.Change(1000, Timeout.Infinite);
                    }
                }
            }
        }

        public void Restart()
        {
            configurationManager_ConfigurationChanged(null, new EventArgs());
        }

        private void copyConfigurationToLocal()
        {
            applicationVersion = new FirmwareVersion(ConfigurationManager.Instance.ApplicationVersion);

            string serialNumberString = ConfigurationManager.Instance.SerialNumber;
            if (serialNumberString != null)
            {
                for (int i = 0; i < serialNumberString.Length; i++)
                {
                    serialNumber[i] = (byte)serialNumberString[i];
                }
            }
        }

        #endregion

        #region Data processing

        private void port_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            object tempObject;
            DeviceLoopMessageBase deviceLoopMessage = null;

            if (e.Metadata.TryGetValue("DeviceLoopMessage", out tempObject))
                deviceLoopMessage = tempObject as DeviceLoopMessageBase;

            ConnectionType connection;
            if (sender == serialPort)
                connection = ConnectionType.Serial;
            else
                connection = ConnectionType.IP;

            if (deviceLoopMessage != null)
            {
                lock (toProcessMessageQueue)
                {
                    toProcessMessageQueue.Add(new DeviceLoopMessageAndConnection(deviceLoopMessage, connection));
                    processPending.Set();
                }
            }
        }

        /// <summary>
        /// Return number of messages queued for sending.
        /// </summary>
        public int SendMessageQueueCount
        {
            get
            {
                return outgoingMessageQueue.Count;
            }
        }

        /// <summary>
        /// Queues a message to be sent to the controller via any available communication channel.
        /// Non blocking.
        /// Note. Messages are only queued if online to the controller.
        /// </summary>
        /// <param name="message">The message to send to the controller.</param>
        public void SendMessage(DeviceLoopMessageBase message)
        {
            if (connectionsStatus.IPConnectionValid != ControllerIPConnectionType.NoConnectionToControllerOverIP 
                || connectionsStatus.SerialConnectionValid == true)
            {
                lock (outgoingMessageQueue)
                {
                    outgoingMessageQueue.Add(new DeviceLoopMessageAndConnection(message, ConnectionType.SerialOrIP));
                    sendPending.Set();
                }
            }
        }

        /// <summary>
        /// Queues a message to be sent to the controller via a specified communication channel.
        /// Non blocking.
        /// Note. Messages are only queued if online to the controller on the specified connection.
        /// </summary>
        /// <param name="message">The message to send to the controller.</param>
        /// <param name="connectionToUse"></param>
        public void SendMessage(DeviceLoopMessageBase message, ConnectionType connectionToUse)
        {
            if (connectionToUse == ConnectionType.Serial && connectionsStatus.SerialConnectionValid == false)
                return;
            if (connectionToUse == ConnectionType.IP && connectionsStatus.IPConnectionValid == ControllerIPConnectionType.NoConnectionToControllerOverIP)
                return;
            if (connectionToUse == ConnectionType.SerialOrIP && connectionsStatus.SerialConnectionValid == false 
                && connectionsStatus.IPConnectionValid == ControllerIPConnectionType.NoConnectionToControllerOverIP)
                return;

            lock (outgoingMessageQueue)
            {
                outgoingMessageQueue.Add(new DeviceLoopMessageAndConnection(message, connectionToUse));
                sendPending.Set();
            }
        }

        private void messageSendThreadMethod()
        {
            try
            {
                DeviceLoopMessageBase message = null;
                ConnectionType connection = ConnectionType.SerialOrIP;

                while (Application.Closing == false && this.disposing == false)
                {
                    if (message == null)
                    {
                        sendPending.Reset();
                        sendPending.WaitOne();
                    }

                    if (Application.Closing == true || this.disposing == true)
                        return;

                    lock (outgoingMessageQueue)
                    {
                        if (outgoingMessageQueue.Count > 0)
                        {
                            message = outgoingMessageQueue[0].Message;
                            connection = outgoingMessageQueue[0].Connection;
                            outgoingMessageQueue.RemoveAt(0);
                        }
                        else
                        {
                            message = null;
                        }
                    }
                    if (message == null)
                        continue;
                
                    // Message found. Attempt to send to controller over established connection(s).
                    bool sentOnIP = false;
                    bool sentOnSerial = false;
                    try
                    {
                        lock (udpSync)
                        {
                            if (connectionsStatus.IPConnectionValid == ControllerIPConnectionType.UDPOnly)
                            {
                                Dictionary<string, object> sendParameters = new Dictionary<string, object>();
                                sendParameters.Clear();
                                sendParameters.Add("DeviceLoopMessage", message);
                                if (udpIPPort.Send(null, sendParameters))
                                    sentOnIP = true;
                                else
                                    Thread.Sleep(500); // Add an additional sleep here so on a failure we don't send messages every 110ms.
                            }
                        }
                        // We are deliberately testing the tcpIPConnectionValid variable twice as
                        // tcpIPPort.Connect(); is a blocking call and can hold the tcpSync lock
                        // for a long period of time (in the order of 30 seconds).
                        if (connectionsStatus.IPConnectionValid == ControllerIPConnectionType.TCPOnly && sentOnIP == false)
                        {
                            lock (tcpSync)
                            {
                                if (connectionsStatus.IPConnectionValid == ControllerIPConnectionType.TCPOnly)
                                {
                                    Dictionary<string, object> sendParameters = new Dictionary<string, object>();
                                    sendParameters.Clear();
                                    sendParameters.Add("DeviceLoopMessage", message);
                                    if (tcpIPPort.Send(null, sendParameters))
                                        sentOnIP = true;
                                }
                            }
                        }
                        if (sentOnIP == false)
                        {
                            lock (serialSync)
                            {
                                if (connectionsStatus.SerialConnectionValid == true)
                                {
                                    Dictionary<string, object> sendParameters = new Dictionary<string, object>();
                                    sendParameters.Clear();
                                    sendParameters.Add("DeviceLoopMessage", message);
                                    if (serialPort.Send(null, sendParameters))
                                        sentOnSerial = true;
                                }
                            }
                        }
                        // If the connections are down clear the messages, or re-queue it for processing.
                        if (connectionsStatus.IPConnectionValid == ControllerIPConnectionType.NoConnectionToControllerOverIP 
                            && connectionsStatus.SerialConnectionValid == false)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                            {
                                return "Clearing outgoing message queue.";
                            });
                            lock (outgoingMessageQueue)
                            {
                                outgoingMessageQueue.Clear();
                                message = null;
                            }
                        }
                        else if (sentOnIP == false && sentOnSerial == false)
                        {
                            System.Threading.Thread.Sleep(10);
                            lock (outgoingMessageQueue)
                            {
                                outgoingMessageQueue.Insert(0, new DeviceLoopMessageAndConnection(message, connection));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                        {
                            return string.Format("Failed sending message. {0}", ex.Message);
                        });
                        if (sentOnIP == false && sentOnSerial == false)
                        {
                            System.Threading.Thread.Sleep(100);
                            lock (outgoingMessageQueue)
                            {
                                outgoingMessageQueue.Insert(0, new DeviceLoopMessageAndConnection(message, connection));
                            }
                        }
                    }
                }
            }
            catch
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                {
                    return "Failed processing send message.";
                });
            }
        }

        private void messageProcessThreadMethod()
        {
            DeviceLoopMessageBase message = null;
            ConnectionType connection = ConnectionType.SerialOrIP;
            while (Application.Closing == false && this.disposing == false)
            {
                if (message == null)
                {
                    processPending.Reset();
                    processPending.WaitOne();
                }

                if (Application.Closing == true || this.disposing == true)
                    return;

                try
                {
                    lock (toProcessMessageQueue)
                    {
                        if (toProcessMessageQueue.Count > 0)
                        {
                            message = toProcessMessageQueue[0].Message;
                            connection = toProcessMessageQueue[0].Connection;
                            toProcessMessageQueue.RemoveAt(0);
                        }
                        else
                        {
                            message = null;
                        }
                    }
                    if (message != null)
                        CommandProcessor.Instance.ProcessCommand(message, connection);
                }
                catch (Exception ex)
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                    {
                        return string.Format("Failed processing received message. {0}", ex.Message);
                    });
                    System.Threading.Thread.Sleep(100);
                }
            }
        }

        #endregion

        #region Connction changes and data

        private void udpIPAutodiscoveryConnection_DataReceived(object sender, ReceivedDataEventArgs e)
        {
            try
            {
                lock (udpIPAutodiscoverySync)
                {
                    ControllerDiscoveryMessage discoveryMessage = new ControllerDiscoveryMessage(e.Data);
                    if (discoveryMessage.IsValid && discoveryMessage.Device == DeviceType.PacomController)
                    {
                        // Controller has been found
                        object tempObject;
                        IPEndPoint remoteEndPoint = null;
                        if (e.Metadata.TryGetValue("RemoteEndPoint", out tempObject))
                        {
                            remoteEndPoint = tempObject as IPEndPoint;
                        }
                        if (remoteEndPoint != null)
                        {
                            ipPortConfiguration.ControllerAddress.Address = remoteEndPoint.Address;
                            Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                            {
                                return "Auto discovery found controller with IP address: " + remoteEndPoint.Address.ToString();
                            });
                        }
                        if (recreateIPPortTimerRunning == false)
                        {
                            recreateIPPortTimerRunning = true;
                            recreateIPPortTimer.Change(1000, Timeout.Infinite);
                        }
                    }
                }
            }
            catch
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                {
                    return "Error while discovering controller presence.";
                });
                if (recreateIPPortTimerRunning == false)
                {
                    recreateIPPortTimerRunning = true;
                    recreateIPPortTimer.Change(5000, Timeout.Infinite);
                }
            }            
        }

        private void tcpIPPort_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (this.disposing == true)
                return;

            Logger.LogWarnMessage(LoggerClassPrefixes.CommunicationManager, () =>
            {
                return string.Format("TCP to Controller {0}", e.NewConnectionState);
            });

            switch (e.NewConnectionState)
            {
                case ConnectionState.Connecting:
                    connectionsStatus.DisconnectIPConnection(ControllerIPConnectionType.TCPOnly);
                    break;
                case ConnectionState.Connected:
                    if (connectionsStatus.ConnectIPConnection(ControllerIPConnectionType.TCPOnly) == true)
                        sendPending.Set();                    
                    break;
                case ConnectionState.Disconnected:
                    // If this is the current connection

                    // Allow the UDP a chance to connect before we call recreate port.
                    Thread.Sleep(maximumNetworkLatency);
                    if (connectionsStatus.DisconnectIPConnection(ControllerIPConnectionType.TCPOnly) == true)
                    {
                        // In case of auto discovery, remove controller address from configuration.
                        if (ConfigurationManager.Instance.UseAutoDiscovery == true)
                            ipPortConfiguration.ControllerAddress.Address = IPAddress.Any;
                        if (recreateIPPortTimerRunning == false)
                        {
                            recreateIPPortTimerRunning = true;
                            recreateIPPortTimer.Change(5000, Timeout.Infinite);
                        }
                    }                    
                    break;
            }
            sendPending.Set();
        }

        private void udpIPPort_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (this.disposing == true)
                return;

            Logger.LogWarnMessage(LoggerClassPrefixes.CommunicationManager, () =>
            {
                return string.Format("UDP to Controller {0}", e.NewConnectionState);
            });
            
            switch (e.NewConnectionState)
            {
                case ConnectionState.Connecting:
                    connectionsStatus.DisconnectIPConnection(ControllerIPConnectionType.UDPOnly);
                    break;
                case ConnectionState.Connected:                    
                    if (connectionsStatus.ConnectIPConnection(ControllerIPConnectionType.UDPOnly) == true)
                        sendPending.Set();
                    break;
                case ConnectionState.Disconnected:
                    // If this is the current connection

                    // Allow the TCP a chance to connect before we call recreate port.
                    Thread.Sleep(maximumNetworkLatency);
                    if (connectionsStatus.DisconnectIPConnection(ControllerIPConnectionType.UDPOnly) == true)
                    {
                        // In case of auto discovery, remove controller address from configuration.
                        if (ConfigurationManager.Instance.UseAutoDiscovery == true)
                            ipPortConfiguration.ControllerAddress.Address = IPAddress.Any;
                        if (recreateIPPortTimerRunning == false)
                        {
                            recreateIPPortTimerRunning = true;
                            recreateIPPortTimer.Change(5000, Timeout.Infinite);
                        }
                    }
                    break;
            }            
        }

        private void serialPort_ConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            if (this.disposing == true)
                return;

            Logger.LogWarnMessage(LoggerClassPrefixes.CommunicationManager, () =>
            {
                return string.Format("485 to Controller {0}", e.NewConnectionState);
            });

            switch (e.NewConnectionState)
            {
                case ConnectionState.Connecting:
                    connectionsStatus.SerialConnectionValid = false;
                    break;
                case ConnectionState.Connected:
                    // Save the baud rate and store in status manager for viewing state
                    if (serialPortConfiguration.BaudRate != connectionsStatus.CurrentBaudRate)
                    {
                        serialPortConfiguration.BaudRate = connectionsStatus.CurrentBaudRate;
                        using (ConfigurationManager.Instance.CreateConfigurationChanger())
                        {
                            ConfigurationManager.Instance.ConnectionSerial = serialPortConfiguration;
                        }
                    }
                    else
                    {
                        // Reconnected before protocol detected the state.
                        // The following line will make a note of that.
                        connectionsStatus.SerialConnectionValid = false;
                    }
                    connectionsStatus.SerialConnectionValid = true;
                    break;
                case ConnectionState.Disconnected:
                    // Rotate the baud rate
                    if (connectionsStatus.SerialConnectionValid == false)
                    {
                        switch (connectionsStatus.CurrentBaudRate)
                        {
                            case 4800:
                                connectionsStatus.CurrentBaudRate = 115200;
                                break;
                            case 9600:
                                connectionsStatus.CurrentBaudRate = 4800;
                                break;
                            case 19200:
                                connectionsStatus.CurrentBaudRate = 9600;
                                break;
                            case 38400:
                                connectionsStatus.CurrentBaudRate = 19200;
                                break;
                            default:
                                connectionsStatus.CurrentBaudRate = 38400;
                                break;
                        }
                    }
                    connectionsStatus.SerialConnectionValid = false;
                    // Schedule re-connection
                    if (recreateSerialPortTimerRunning == false)
                    {
                        recreateSerialPortTimerRunning = true;
                        recreateSerialPortTimer.Change(1000, Timeout.Infinite);
                    }
                    break;
            }

            sendPending.Set();
        }

        #endregion

        #region Disposal of connections

        /// <summary>
        /// Internal function to cleanup any resources or events used by the serial connection.
        /// </summary>
        private void disposeSerialPort()
        {
            try
            {
                if (serialPort != null)
                {
                    serialPort.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(serialPort_ConnectionStateChanged);
                    serialPort.DataReceived -= new EventHandler<ReceivedDataEventArgs>(port_DataReceived);
                    serialPort.Dispose();
                    serialPort = null;
                    connectionsStatus.SerialConnectionValid = false;
                }
            }
            catch (Exception)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                {
                    return "Error while disposing serial connection object.";
                });
            }
        }

        /// <summary>
        /// Internal function to cleanup any resources or events used by the UDP auto discovery connection.
        /// </summary>
        private void disposeUdpAutodiscoveryConnection()
        {
            try
            {
                if (udpIPAutodiscoveryConnection != null)
                {
                    lock (udpIPAutodiscoverySync)
                    {
                        int portToDispose = udpIPAutodiscoveryConnection.Port;
                        udpIPAutodiscoveryConnection.DataReceived -= new EventHandler<ReceivedDataEventArgs>(udpIPAutodiscoveryConnection_DataReceived);
                        udpIPAutodiscoveryConnection.Dispose();
                        udpIPAutodiscoveryConnection = null;
                        udpIPManager.DisposeConnection(portToDispose);
                    }
                }
            }
            catch (Exception)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                {
                    return "Error while disposing UDP auto discovery connection object.";
                });
            }
        }

        /// <summary>
        /// Internal function to cleanup any resources or events used by the TCP connection.
        /// </summary>
        private void disposeTcpPort()
        {
            try
            {
                if (tcpIPPort != null)
                {
                    lock (tcpSync)
                    {
                        tcpIPPort.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(tcpIPPort_ConnectionStateChanged);
                        tcpIPPort.DataReceived -= new EventHandler<ReceivedDataEventArgs>(port_DataReceived);
                        tcpIPPort.Dispose();
                        tcpIPPort = null;
                        connectionsStatus.DisconnectIPConnection(ControllerIPConnectionType.TCPOnly);
                    }
                }
            }
            catch (Exception)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                {
                    return "Error while disposing TCP/IP connection objects.";
                });
            }
        }

        private void connectionsStatus_DisposeTcpConnection(object sender, EventArgs e)
        {
            disposeTcpPortTimer.Change(400, Timeout.Infinite);
        }

        /// <summary>
        /// Timer method used to dispose TCP connection.
        /// </summary>
        /// <param name="state">Not used</param>
        private void disposeTcpPortMethod(object state)
        {
            disposeTcpPort();
        }

        /// <summary>
        /// Internal function to cleanup any resources or events used by the UDP connection.
        /// </summary>
        private void disposeUdpPort()
        {
            try
            {
                if (udpIPPort != null)
                {
                    lock (udpSync)
                    {
                        int portToDispose = udpIPConnection.Port;
                        udpIPPort.DataReceived -= new EventHandler<ReceivedDataEventArgs>(port_DataReceived);
                        udpIPPort.ConnectionStateChanged -= new EventHandler<ConnectionStateChangedEventArgs>(udpIPPort_ConnectionStateChanged);
                        udpIPPort.Dispose();
                        udpIPPort = null;
                        udpIPConnection = null;
                        udpIPManager.DisposeConnection(portToDispose);
                        connectionsStatus.DisconnectIPConnection(ControllerIPConnectionType.UDPOnly);
                    }
                }
            }
            catch (Exception)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                {
                    return "Error while disposing UDP connection objects.";
                });
            }
        }

        private void connectionsStatus_DisposeUdpConnection(object sender, EventArgs e)
        {
            disposeUdpPortTimer.Change(400, Timeout.Infinite);
        }

        /// <summary>
        /// Timer method used to dispose UDP connection.
        /// </summary>
        /// <param name="state">Not used</param>
        private void disposeUdpPortMethod(object state)
        {
            disposeUdpPort();
        }                

        #endregion

        private void recreateSerialPortMethod(object state)
        {
            if (this.disposing == true)
                return;

            recreateSerialPortTimer.Change(Timeout.Infinite, Timeout.Infinite);
            recreateSerialPortTimerRunning = false;
            lock (serialSync)
            {
                try
                {
                    disposeSerialPort();

                    if (serialPortConfiguration.ConnectionRequired)
                    {
                        Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                        {
                            return string.Format("Connecting to the device loop at {0}", connectionsStatus.CurrentBaudRate);
                        });
                        DeviceLoopProtocolConnection linkLayerConnection = deviceLoopProtocolManager.CreateConnection(connectionsStatus.CurrentBaudRate);
                        ProtocolConnectionBase physicalLayerConnection = serialManager.CreateConnection(
                            PhysicalSerialType.RS485,
                            PhysicalSerialPort.OnboardRS485Port,
                            connectionsStatus.CurrentBaudRate,
                            System.IO.Ports.Parity.Even,
                            8, System.IO.Ports.StopBits.One);
                        linkLayerConnection.SetLowerLayerConnection(physicalLayerConnection);
                        serialPort = linkLayerConnection;
                        // Add events and connect
                        serialPort.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(serialPort_ConnectionStateChanged);
                        serialPort.DataReceived += new EventHandler<ReceivedDataEventArgs>(port_DataReceived);
                        serialPort.Connect();
                    }
                }
#pragma warning disable 0168
#if DEBUG
                catch (Exception ex)
#else
                catch
#endif
#pragma warning restore 0168
                {
#if DEBUG
                    Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                    {
                        return ex.ToString();
                    });
#endif
                    if (recreateSerialPortTimerRunning == false)
                    {
                        recreateSerialPortTimerRunning = true;
                        recreateSerialPortTimer.Change(1000, Timeout.Infinite);
                    }
                    sendPending.Set();
                }
            }
        }

        private bool logWaitingForIPAddress = true;

        /// <summary>
        /// New environmental parameters. Dispose connections and start again.
        /// If one of the IP ways of communicating (TCP or UDP) succeeded, stop connecting with the other.
        /// 
        /// Only one connection UDP or TCP is possible + one SERIAL.
        /// 
        /// This is starting point after configuration changes
        /// </summary>
        /// <param name="state">Not used.</param>
        private void recreateIPPortMethod(object state)
        {
            if (this.disposing == true)
                return;
                        
            recreateIPPortTimer.Change(Timeout.Infinite, Timeout.Infinite);
            recreateIPPortTimerRunning = false;
            lock (tcpSync)
            {
                try
                {
                    disposeTcpPort();
                    disposeUdpPort();
                    // Assume no connections are valid. The auto discovery can be in progress.
                    connectionsStatus.DisconnectIPConnection(ControllerIPConnectionType.TCPOnly);
                    connectionsStatus.DisconnectIPConnection(ControllerIPConnectionType.UDPOnly);

                    if (ipPortConfiguration.ConnectionRequired)
                    {
                        IPAddress currentIPAddress = Dns.GetHostEntry(Dns.GetHostName()).AddressList[0];
                        if (currentIPAddress.Equals(IPAddress.Parse("127.0.0.1")))
                        {
                            // Host IP address is not setup yet. Wait...
                            if (logWaitingForIPAddress)
                            {
                                Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                                {
                                    return "Waiting for controller IP address...";
                                });
                                logWaitingForIPAddress = false;
                            }
                            if (recreateIPPortTimerRunning == false)
                            {
                                recreateIPPortTimerRunning = true;
                                recreateIPPortTimer.Change(5000, Timeout.Infinite);
                            }
                        }
                        else
                        {
                            logWaitingForIPAddress = true;
                            // Autodiscovery is enabled and address is "Any" - activate the autodiscovery.
                            if (ConfigurationManager.Instance.UseAutoDiscovery == true
                                && ipPortConfiguration.ControllerAddress.Address.Equals(IPAddress.Any) == true)
                            {
                                if (udpIPAutodiscoveryConnection == null)
                                {
                                    udpIPAutodiscoveryConnection = udpIPManager.CreateConnection(ipPortConfiguration.Port, true);
                                    udpIPAutodiscoveryConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(udpIPAutodiscoveryConnection_DataReceived);
                                }
                                else
                                {
                                    if (udpIPAutodiscoveryConnection.Port != ipPortConfiguration.Port)
                                    {
                                        disposeUdpAutodiscoveryConnection();
                                        // Setup new UDP request
                                        udpIPAutodiscoveryConnection = new UdpIPConnection(ipPortConfiguration.Port, true);
                                        udpIPAutodiscoveryConnection.DataReceived += new EventHandler<ReceivedDataEventArgs>(udpIPAutodiscoveryConnection_DataReceived);
                                    }
                                }
                                if (udpIPAutodiscoveryConnection.Connect())
                                {
                                    udpIPAutodiscoveryConnection.Send(
                                        new ControllerDiscoveryMessage(
                                            DeviceLoopMessageBase.DeviceLoopDeviceType,
                                            serialNumber,
                                            ipPortConfiguration.ControllerNumber,
                                            applicationVersion).Data,
                                        broadcastDictionary);
                                    Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                                    {
                                        return "Controller auto discovery enabled. Searching...";
                                    });
                                }
                                if (recreateIPPortTimerRunning == false)
                                {
                                    recreateIPPortTimerRunning = true;
                                    recreateIPPortTimer.Change(30000, Timeout.Infinite);
                                }
                            }
                            else // We have controller IP address. Try to connect to controller.
                            {
                                // In case of auto discovery, do not remove controller address from configuration, as it was just received
                                if (ConfigurationManager.Instance.UseAutoDiscovery == false)
                                {
                                    // Request controller IP address again from resolver, if name provided, otherwise reassign IP address.
                                    ipPortConfiguration.ControllerAddress.Set(ipPortConfiguration.ControllerAddress.AddressAsString);
                                }
                                disposeUdpAutodiscoveryConnection();
                                if (ipPortConfiguration.ControllerAddress.Address.Equals(IPAddress.Any) == false)
                                {
                                    connectToControllerUsingUdpIP();
                                    connectToControllerUsingTcpIP();
                                }
                                else
                                {
                                    Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                                    {
                                        return "Unable to start IP connection. Invalid controller address.";
                                    });
                                    if (recreateIPPortTimerRunning == false)
                                    {
                                        recreateIPPortTimerRunning = true;
                                        recreateIPPortTimer.Change(30000, Timeout.Infinite);
                                    }
                                }
                            }
                        }
                    }
                }
                catch
                {
                    if (disposing == true)
                        return;
                    if (recreateIPPortTimerRunning == false)
                    {
                        recreateIPPortTimerRunning = true;
                        recreateIPPortTimer.Change(30000, Timeout.Infinite);
                    }
                    sendPending.Set();
                }
            }
        }

        /// <summary>
        /// Invoke connection to controller 
        /// </summary>
        private void connectToControllerUsingUdpIP()
        {
            udpIPConnection = udpIPManager.CreateConnection(ipPortConfiguration.Port, true);
            udpIPPort = deviceLoopProtocolOverUdpIPManager.CreateConnection(ipPortConfiguration.ControllerAddress.Address, ipPortConfiguration.Port);
            udpIPPort.SetLowerLayerConnection(udpIPConnection);
            // Save UDP configuration into status manager for status preview
            StatusManager.Instance.Device.CurrentConnectionUdp =
                new IPConnectionConfiguration(
                    ipPortConfiguration.ConnectionRequired,
                    ipPortConfiguration.AutoDiscovery,
                    ipPortConfiguration.ControllerAddress,
                    ipPortConfiguration.Port,
                    ipPortConfiguration.ControllerNumber,
                    ipPortConfiguration.DeviceAddress);
            // Setup events and try to connect
            udpIPPort.DataReceived += new EventHandler<ReceivedDataEventArgs>(port_DataReceived);
            udpIPPort.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(udpIPPort_ConnectionStateChanged);
            udpIPPort.Connect();
        }

        /// <summary>
        /// Invoke connection to controller
        /// </summary>
        private void connectToControllerUsingTcpIP()
        {
            DeviceLoopProtocolOverIPConnection linkLayerConnection = deviceLoopProtocolOverIPManager.CreateConnection();
            TcpIPConnection physicalLayerConnection;
            // Connect to controller
            // Begin the TcpIP connection to controller. Due to restriction in legacy controller up to ver. 4.09D, the source port must have been 
            // specified as 3435. After this version the source port is not needed anymore. Here we use the status manager to fix the issue here.
            if (lastTcpDisconnectionReason == DisconnectionReason.TcpIPRemoteEndClosed)
            {
                // In last attempt the port is not specified. Try with port...
                physicalLayerConnection = tcpIPManager.CreateConnection(ipPortConfiguration.EndPoint,
                    new IPEndPoint(Dns.GetHostEntry(Dns.GetHostName()).AddressList[0], ipPortConfiguration.Port));
            }
            else if (lastTcpDisconnectionReason == DisconnectionReason.TcpIPAddressAlreadyInUse)
            {
                // In last attempt the port is specified. Try without the port...
                physicalLayerConnection = tcpIPManager.CreateConnection(ipPortConfiguration.EndPoint);
            }
            else
            {
                // This should happen on try to connect. No port the first time.
                physicalLayerConnection = tcpIPManager.CreateConnection(ipPortConfiguration.EndPoint);
            }
            linkLayerConnection.SetLowerLayerConnection(physicalLayerConnection);
            tcpIPPort = linkLayerConnection;
            // Save TCP configuration for status preview
            StatusManager.Instance.Device.CurrentConnectionTcp =
                new IPConnectionConfiguration(
                    ipPortConfiguration.ConnectionRequired,
                    ipPortConfiguration.AutoDiscovery,
                    ipPortConfiguration.ControllerAddress,
                    ipPortConfiguration.Port,
                    ipPortConfiguration.ControllerNumber,
                    ipPortConfiguration.DeviceAddress);
            // Setup events and try to connect
            tcpIPPort.ConnectionStateChanged += new EventHandler<ConnectionStateChangedEventArgs>(tcpIPPort_ConnectionStateChanged);
            tcpIPPort.DataReceived += new EventHandler<ReceivedDataEventArgs>(port_DataReceived);
            tcpIPPort.Connect();
        }

        #region IDisposable Members

        private bool disposed = false;
        private bool disposing = false;

        protected virtual void Dispose(bool disposing)
        {
            try
            {
                if (disposed == false)
                {
                    if (disposing == true)
                    {
                        this.disposing = true;

                        if (disposeTcpPortTimer != null)
                            disposeTcpPortTimer.Change(Timeout.Infinite, Timeout.Infinite);

                        if (disposeUdpPortTimer != null)
                            disposeUdpPortTimer.Change(Timeout.Infinite, Timeout.Infinite);

                        if (recreateIPPortTimer != null)
                        {
                            recreateIPPortTimerRunning = true; // Mark as running during the disposal
                            recreateIPPortTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        }

                        if (recreateSerialPortTimer != null)
                        {
                            recreateSerialPortTimerRunning = true; // Mark as running during the disposal
                            recreateSerialPortTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        }
                        
                        connectionsStatus.DisposeTcpConnection -= new EventHandler<EventArgs>(connectionsStatus_DisposeTcpConnection);
                        connectionsStatus.DisposeUdpConnection -= new EventHandler<EventArgs>(connectionsStatus_DisposeUdpConnection);

                        if (processPending != null)
                            processPending.Set();
                        if (sendPending != null)
                            sendPending.Set();

                        disposeUdpAutodiscoveryConnection();
                        disposeSerialPort();

                        // Do not wait for TCP disconnections
                        //disposeTcpPort();
                        disposeUdpPort();

                        if (sendThread != null)
                            sendThread.JoinOrRestart(1000);
                        if (processThread != null)
                            processThread.JoinOrRestart(1000);
                        
                        if (disposeUdpPortTimer != null)
                            disposeUdpPortTimer.Dispose();

                        if (disposeTcpPortTimer != null)
                            disposeTcpPortTimer.Dispose();

                        if (recreateIPPortTimer != null)
                            recreateIPPortTimer.Dispose();

                        if (recreateSerialPortTimer != null)
                            recreateSerialPortTimer.Dispose();

                        if (processPending != null)
                            processPending.Close();

                        if (sendPending != null)
                            sendPending.Close();

                        // Deactivate the RS485 transmit enable pin
                        Pcb.DeactivateOnboardRs485Driver();

                        Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                        {
                            return "Communication manager successfully destroyed.";
                        });
                    }
                    instance = null;
                    disposed = true;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.CommunicationManager, () =>
                {
                    return string.Format("Unexpected error during disposing manager. {0}", ex.ToString());
                });
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
