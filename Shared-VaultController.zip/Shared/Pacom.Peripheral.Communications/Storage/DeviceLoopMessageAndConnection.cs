﻿using System;
using Pacom.Peripheral.Messaging.DeviceLoopMessages;
using Pacom.Peripheral.Common;

namespace Pacom.Peripheral.Communications
{
    public class DeviceLoopMessageAndConnection
    {
        public DeviceLoopMessageAndConnection(DeviceLoopMessageBase message, ConnectionType connection)
        {
            Message = message;
            Connection = connection;
        }

        public DeviceLoopMessageBase Message
        {
            get;
            set;
        }

        public ConnectionType Connection
        {
            get;
            set;
        }
    }
}
