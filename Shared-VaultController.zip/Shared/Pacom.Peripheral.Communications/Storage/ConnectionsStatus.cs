﻿using System;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Status;

namespace Pacom.Peripheral.Communications
{
    /// <summary>
    /// Holder for connection status
    /// 
    /// Rule: Only one connection UDP or TCP is possible + additionally one SERIAL.
    /// 
    /// </summary>
    internal class ConnectionsStatus
    {
        internal ConnectionsStatus()
        {
            serialConnectionValid = false;
            currentIPConnection = ControllerIPConnectionType.NoConnectionToControllerOverIP;
            checkMarkOfflineToController();
        }

        /// <summary>
        /// Event triggered when the TCP connection is to be disposed.
        /// </summary>
        public event EventHandler<EventArgs> DisposeTcpConnection;

        /// <summary>
        /// Event triggered when the UDP connection is to be disposed.
        /// </summary>
        public event EventHandler<EventArgs> DisposeUdpConnection;

        private readonly object syatemStatusLock = new object();

        /// <summary>
        /// Check is required to mark status as offline to controller. Check all possible connections for their status.
        /// </summary>
        private void checkMarkOfflineToController()
        {
            lock (syatemStatusLock)
            {
                if (this.serialConnectionValid == false
                    && currentIPConnection == ControllerIPConnectionType.NoConnectionToControllerOverIP)
                {
                    Hal.StatusLed.AddStatus(SystemStatus.OfflineToController);
                    StatusManager.Instance.Device.SerialConnectionValid = false;
                    StatusManager.Instance.Device.UdpIPConnectionValid = false;
                    StatusManager.Instance.Device.TcpIPConnectionValid = false;
                }
                else
                {
                    Hal.StatusLed.ClearStatus(SystemStatus.OfflineToController);
                }
            }
        }

        private int currentBaudRate = 38400;

        internal int CurrentBaudRate
        {
            get { return currentBaudRate; }
            set { currentBaudRate = value; }
        }

        #region Serial connections

        private bool serialConnectionValid = false;

        private readonly object serialConnectionValidLock = new object();

        /// <summary>
        /// Get or Set the status of a RS485 connection to controller.
        /// </summary>
        internal bool SerialConnectionValid
        {
            get { return serialConnectionValid; }
            set
            {
                lock (serialConnectionValidLock)
                {
                    if (serialConnectionValid != value)
                    {
                        serialConnectionValid = value;
                        StatusManager.Instance.Device.SerialConnectionValid = serialConnectionValid;
                        if (serialConnectionValid == true)
                        {
                            CounterManager.IncrementCounter("RTUConnectedBySerial");
                            Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                            {
                                return string.Format("Connected to Pacom device loop over RS485 with {0}.", currentBaudRate);
                            });
                        }
                        else
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                            {
                                return "Disconnected from Pacom device loop over RS485.";
                            });
                        }
                        checkMarkOfflineToController();
                    }
                }
            }
        }

        #endregion

        #region IP connections

        private ControllerIPConnectionType currentIPConnection = ControllerIPConnectionType.NoConnectionToControllerOverIP;

        /// <summary>
        /// Get the status of a IP connection to controller.
        /// </summary>
        internal ControllerIPConnectionType IPConnectionValid
        {
            get { return currentIPConnection; }
        }

        private readonly object ipConnectionValidLock = new object();

        /// <summary>
        /// Device connected to the controller over one of the IP connections.
        /// </summary>
        /// <param name="newConnectionType">Type of IP connection</param>
        /// <returns>Returned true if the connection was accepted</returns>
        internal bool ConnectIPConnection(ControllerIPConnectionType newConnectionType)
        {
            lock (ipConnectionValidLock)
            {
                if (currentIPConnection == newConnectionType
                    || newConnectionType == ControllerIPConnectionType.NoConnectionToControllerOverIP)
                    return false;

                if (currentIPConnection == ControllerIPConnectionType.NoConnectionToControllerOverIP)
                {
                    // New IP connection is connected
                    currentIPConnection = newConnectionType;
                    string connectionName = "Unknown";
                    if (currentIPConnection == ControllerIPConnectionType.TCPOnly)
                    {
                        connectionName = "TCP";
                        CounterManager.IncrementCounter("RTUConnectedByTCPIP");
                        StatusManager.Instance.Device.TcpIPConnectionValid = true;
                        StatusManager.Instance.Device.UdpIPConnectionValid = false;
                    }
                    else if (currentIPConnection == ControllerIPConnectionType.UDPOnly)
                    {
                        connectionName = "UDP";
                        CounterManager.IncrementCounter("RTUConnectedByUDPIP");
                        StatusManager.Instance.Device.UdpIPConnectionValid = true;
                        StatusManager.Instance.Device.TcpIPConnectionValid = false;
                    }
                    checkMarkOfflineToController();
                    Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                    {
                        return string.Format("Connected to Pacom device loop over {0}.", connectionName);
                    });
                    return true;
                }
                else
                {
                    // Dispose connection as there is already one
                    // Only one IP connection is allowed
                    if (newConnectionType == ControllerIPConnectionType.TCPOnly)
                        this.DisposeTcpConnection(this, new EventArgs());
                    else if (newConnectionType == ControllerIPConnectionType.UDPOnly)
                        this.DisposeUdpConnection(this, new EventArgs());
                }
            }
            return false;
        }

        /// <summary>
        /// Device disconnected from the controller over one of the IP connections.
        /// </summary>
        /// <param name="disconnectingConnectionType">Type of IP connection</param>
        /// <returns>Returned true if the disconnection was accepted</returns>
        internal bool DisconnectIPConnection(ControllerIPConnectionType disconnectingConnectionType)
        {
            lock (ipConnectionValidLock)
            {
                // If there is no connection established yet, the first disconnection is successful.
                // This will recreate all connections in communication manager via the disconnect event.
                if (currentIPConnection == ControllerIPConnectionType.NoConnectionToControllerOverIP
                    && disconnectingConnectionType != ControllerIPConnectionType.NoConnectionToControllerOverIP)
                    return true;

                if (currentIPConnection != disconnectingConnectionType)
                    return false;

                string connectionName = "Unknown";
                if (currentIPConnection == ControllerIPConnectionType.TCPOnly)
                {
                    connectionName = "TCP";
                    StatusManager.Instance.Device.TcpIPConnectionValid = false;
                }
                else if (currentIPConnection == ControllerIPConnectionType.UDPOnly)
                {
                    connectionName = "UDP";
                    StatusManager.Instance.Device.UdpIPConnectionValid = false;
                }

                currentIPConnection = ControllerIPConnectionType.NoConnectionToControllerOverIP;

                // IP connection is dropped
                Logger.LogDebugMessage(LoggerClassPrefixes.CommunicationManager, () =>
                {
                    return string.Format("Disconnected from Pacom device loop over {0}.", connectionName);
                });

                checkMarkOfflineToController();
                return true;
            }
        }

        #endregion
    }
}
