﻿
namespace Pacom.Peripheral.Communications
{
    /// <summary>
    /// Defines the ways of conneting to controller over IP
    /// </summary>
    internal enum ControllerIPConnectionType : int
    {
        NoConnectionToControllerOverIP = 0,
        TCPOnly = 2,
        UDPOnly = 3,
    }
}
