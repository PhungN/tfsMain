﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.Common.Utilities;

namespace Pacom.Peripheral.StartupApplication
{
    /// <summary>
    /// This application is used to copy any incremental updates over the base image and to start either the
    /// functional test application (FCT) or the main device application (CRI/IO).
    ///
    /// If debugging of the (CRI/IO) application is required make sure the IOApplication is deployed first,
    /// before running the startup app.
    ///
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            StatusLed.SetStatus(SystemStatus.Booting);

            // The FCT input is active low.
            if (Pcb.FctInput == false)
            {
                UsbDevice.Instance.Initialize();
                if (StoreManager.InitializeStorage() == false)
                {
                    Console.WriteLine("StartupApplication: Unable to restore disks for operation.");
                    Thread.Sleep(1000);
                    return;
                }

                // Launch the CRI-IO Application
                while (true)
                {
                    try
                    {
                        // Create a directory for the application to live
                        if (Directory.Exists(FileSystemPaths.ApplicationStorage) == false)
                            Directory.CreateDirectory(FileSystemPaths.ApplicationStorage);

                        // Copy the base application to the application directory
                        // During debug build check if the application was deployed from VisualStudio.
                        string[] files;
#if DEBUG
                        if (Directory.Exists(FileSystemPaths.ApplicationDeploymentFromVS) == true)
                            files = Directory.GetFiles(FileSystemPaths.ApplicationDeploymentFromVS);
                        else
#endif
                            files = Directory.GetFiles(FileSystemPaths.OSImageFolder);
                        foreach (string file in files)
                        {
                            if (file.Contains("Pacom."))
                            {
                                File.Copy(file, FileSystemPaths.ApplicationStorage + "\\" + Path.GetFileName(file), true);
                                removeReadOnlyFlag(FileSystemPaths.ApplicationStorage + "\\" + Path.GetFileName(file));
                            }
                        }

                        File.Copy(FileSystemPaths.OSImageVersionFile, FileSystemPaths.ApplicationStorage + "\\Version.txt", true);
                        File.Copy(FileSystemPaths.OSImageSharpCompressLib, FileSystemPaths.ApplicationStorage + "\\SharpCompress.dll", true);

                        removeReadOnlyFlag(FileSystemPaths.ApplicationStorage + "\\Version.txt");
                        removeReadOnlyFlag(FileSystemPaths.ApplicationStorage + "\\SharpCompress.dll");

                        // Determine which image is running and apply any relevant updates.
                        DataFlashConfig dataFlashConfig = new DataFlashConfig(DataFlash.Instance);
                        // Make sure differential updates are taken into account
                        string updateDirectory = null;
                        if (dataFlashConfig.IsAImageActive == true)
                            updateDirectory = FileSystemPaths.FirmwareUpdateForImageA;
                        else if (dataFlashConfig.IsBImageActive == true)
                            updateDirectory = FileSystemPaths.FirmwareUpdateForImageB;
                        if (string.IsNullOrEmpty(updateDirectory) == false)
                        {
                            // Copy diff files for execution
                            if (Directory.Exists(updateDirectory) == true)
                            {
                                FirmwareVersion osImageVersion = CommonUtilities.ReadFirmwareVersion(FileSystemPaths.ApplicationStorage + "\\Version.txt"); ;
                                FirmwareVersion updateVersion = CommonUtilities.ReadFirmwareVersion(updateDirectory + "\\Version.txt");

                                if (updateVersion.Major > osImageVersion.Major || (updateVersion.Major == osImageVersion.Major && updateVersion.Minor > osImageVersion.Minor))
                                {
                                    files = Directory.GetFiles(updateDirectory);
                                    foreach (string file in files)
                                    {
                                        File.Copy(file, FileSystemPaths.ApplicationStorage + "\\" + Path.GetFileName(file), true);
                                    }
                                }
                                else
                                {
                                    // Due to a bug in pre 1.06 versions, the update directory may contain old files that need to be purged.
                                    DirectoryExtensions.Recreate(updateDirectory);
                                }
                            }
                        }
                        break;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("StartupApplication: Error while preparing configuration for CRI-IO application. " + ex.ToString());
                        Thread.Sleep(10);
                    }
                }
                // Launch the IO Application
                string ioApplication = FileSystemPaths.ApplicationStorage + "\\Pacom.Peripheral.IOApplication.exe";
                if (File.Exists(ioApplication) == true)
                {
                    Console.WriteLine("StartupApplication: Starting CRI-IO application...");
                    startProcess(ioApplication, FileSystemPaths.ApplicationStorage);
                }
                else
                {
#if DEBUG
                    Console.WriteLine("StartupApplication: CRI-IO application not found. Consider deployment of IOApplication before running this startup app.");
#else
                    Console.WriteLine("StartupApplication: CRI-IO application not found.");
#endif

                }
            }
            else
            {
                // Launch the FCT Application
                string fctApplication = FileSystemPaths.OSImageFctApplication;
                if (File.Exists(fctApplication) == true)
                {
                    Console.WriteLine("StartupApplication: Starting FCT application...");
                    startProcess(fctApplication, "\\Windows");
                }
                else
                {
                    Console.WriteLine("StartupApplication: FCT application not found.");
                }
            }
            Console.WriteLine("StartupApplication: Completed.");
            // Terminate USB and PCB threads - if any.
            Application.Closing = true;
        }

        static void removeReadOnlyFlag(string path)
        {
            FileInfo fileInfo = new FileInfo(path);
            if ((fileInfo.Attributes & FileAttributes.ReadOnly) != 0)
                fileInfo.Attributes &= ~FileAttributes.ReadOnly;
        }

        static bool startProcess(string processPath, string workingDirectory)
        {
            try
            {
                ProcessStartInfo processStartInfo = new ProcessStartInfo(processPath, "");
                processStartInfo.WorkingDirectory = workingDirectory;
                Process process = Process.Start(processStartInfo);
                if (process == null)
                {
                    Console.WriteLine("StartupApplication: Failed to launch '" + processPath + "'.");
                    return false;
                }
                process.WaitForExit();
                Console.WriteLine("'" + processPath + "' completed.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("StartupApplication: Caught an exception while starting '" + processPath + "': " + ex.Message);
                return false;
            }
            return true;
        }
    }
}
