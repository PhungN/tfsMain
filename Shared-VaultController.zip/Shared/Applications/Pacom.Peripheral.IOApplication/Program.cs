﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using Pacom.Peripheral.AccessControl;
using Pacom.Peripheral.Common;
using Pacom.Peripheral.Common.Configuration;
using Pacom.Peripheral.Common.Status;
using Pacom.Peripheral.Communications;
using Pacom.Peripheral.Hal;
using Pacom.Peripheral.OsdpDeviceLoop;
using Pacom.Peripheral.Protocol;
using Pacom.Peripheral.WebServer;
using Pacom.Peripheral.Website;

namespace Pacom.Peripheral.Applications
{
    /// <summary>
    /// The CRI-IO application.
    /// </summary>
    public partial class IOApplication
    {
        private static HttpServerAsync httpServerAsync = null;

        private static SingletonList singletons = null;

        public static void Main()
        {
            System.AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(currentDomain_UnhandledException);
            SingletonList.ForcedResetRequired += new EventHandler<EventArgs>(Program_ForcedResetRequired);
            ThreadExtensions.ForcedResetRequired += new EventHandler<EventArgs>(Program_ForcedResetRequired);

            Adc.CreateInstance();

            if (IsHardwarePlatformValid == false)
            {
                // Enable watchdog timer
                Hal.Gpio.ClearOutput(GpioPort.PortA, 9);
                Hal.Gpio.ConfigurePin(GpioPort.PortA, 9, true, false, false);
                Hal.Gpio.ClearOutput(GpioPort.PortC, 11);
                Hal.Gpio.ConfigurePin(GpioPort.PortC, 11, true, false, false);

                return;
            }

            // Ready to handle device events linked to the specific PCB design.
            SubscribeToDeviceEvents();

            try
            {
                using (singletons = new SingletonList())
                {
                    // Create configuration manager
                    bool restoreDefaults = RestoreDefaultConfigurationRequested();
                    ConfigurationManager.CreateInstance(Hal.DataFlash.Instance, new Hal.NetworkAdapter(), restoreDefaults);

                    using (ConfigurationManager.Instance.CreateConfigurationChanger())
                    {
                        ApplicationSpecificInitialisation();
                    }

                    NetworkFirewall.CreateInstance();

                    // Subscribe for configuration changes
                    Pcb.SubscribeToConfigurationChanged();

                    // Prepare device response processor.
                    DeviceResponseProcessor.CreateInstance();

                    // Startup application status manager
                    StatusManager.CreateInstance();
                    StatusManager.Instance.SetDeviceResponseProcessor(DeviceResponseProcessor.Instance);
                    StatusManager.Instance.Device.ConnectedToControllerChanged += new EventHandler<ConnectedToControllerEventArgs>(statusManager_ConnectedToControllerChanged);
                    OnboardInputs.CreateInstance();
                    OnboardOutputs.CreateInstance();
                    StatusManager.Instance.SetOnboardOutputs(OnboardOutputs.Instance);
                    foreach (int doorId in CardReaderHardwareLocations.HandledLogicalDoorIds)
                    {
                        StatusManager.Instance.Doors[doorId].AccessControlCommandRequested += new EventHandler<AccessControlCommandRequestEventArgs>(statusManager_AccessControlCommandRequested);
                    }

#if DEBUG
                    if ((Directory.Exists("\\RestrictedRegion") == false || 
                         Directory.Exists("\\PublicRegion") == false) && 
                        StoreManager.InitializeStorage() == false)
                    {
                        Application.Closing = true;
                        return;
                    }
                    ConfigurationManager.Instance.UpdateConfigFile(ConfigurationUpdateReason.Initial);
                    if (restoreDefaults && File.Exists("\\RestrictedRegion\\SamBlackList\\blackList.dat"))
                        File.Delete("\\RestrictedRegion\\SamBlackList\\blackList.dat");
#endif

                    DataFlashConfig dataFlashConfig = new DataFlashConfig(DataFlash.Instance);

                    Pcb.DeactivateOnboardRs485Driver();

                    if (dataFlashConfig.IsAImageActive == false && dataFlashConfig.IsBImageActive == false)
                    {
                        performRescueImageInitialization();
                    }

                    Logger.SetNetworkAdapter(new NetworkAdapter());

                    Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return "Starting CRI-IO Application...";
                    });

                    Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return dataFlashConfig.BootImage.ToString();
                    });

                    // Read the version file.
                    try
                    {
                        using (StreamReader streamReader = new StreamReader(FileSystemPaths.ApplicationStorage + "\\Version.txt"))
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                            {
                                return streamReader.ReadLine();
                            });
                            Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                            {
                                return streamReader.ReadLine();
                            });
                            Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                            {
                                return streamReader.ReadLine();
                            });
                            streamReader.Close();
                        }
                    }
                    catch
                    {
                    }

                    // The application should now take over control of the watchdog timer from the OS
                    Hal.WatchdogTimer.CreateInstance(WatchdogType.Native);
                    Hal.WatchdogTimer.Instance.EnableWatchdogTimer();

                    // Read device details
                    using (ConfigurationManager.Instance.CreateConfigurationChanger())
                    {
                        ConfigurationManager.Instance.PcbRevision = Hal.Pcb.Version;
                        ConfigurationManager.Instance.PcbType = Hal.Pcb.PcbType;
                        ReadApplicationSpecificSettings();
                    }

                    PrepareForApplicationRun();

                    ConfigurationManager.Instance.SystemTimeChanged += new EventHandler<SystemTimeChangeArgs>(configurationManager_SystemTimeChanged);

                    // Read logging level from configuration manager
                    Logger.SetLoggingLevel(ConfigurationManager.Instance.LoggingLevel);

                    // Process any configuration changes
                    ConfigurationManager.Instance.ConfigurationChanged += new EventHandler<EventArgs>(configurationManager_ConfigurationChanged);

                    // This is to resolve an issue in devices that were programmed without valid MAC address.
                    // The default MAC address for all devices is set to 00:E0:42:XX:00:00. Invalid MAC address will cause problems on Ethernet.
                    // The serial number will be used to recreate the MAC.
                    //
                    // Note: In the above MAC sample the XX place holder changes per device type. Look into DeviceMacAddress.cs for specific value.
                    //
                    if (dataFlashConfig.MacAddress[4] == 0 && dataFlashConfig.MacAddress[5] == 0)
                    {
                        string[] serialNumberParts = ConfigurationManager.Instance.SerialNumber.Split('-');
                        if (serialNumberParts.Length == 3)
                        {
                            int unitNumber = 0;
                            if (unitNumber.TryParseInt(serialNumberParts[2], out unitNumber) == true)
                            {
                                if (unitNumber != 0)
                                {
                                    byte[] macAddress = dataFlashConfig.MacAddress;
                                    macAddress[0] = DeviceMacAddress.Empty[0];
                                    macAddress[1] = DeviceMacAddress.Empty[1];
                                    macAddress[2] = DeviceMacAddress.Empty[2];
                                    macAddress[3] = DeviceMacAddress.Empty[3];
                                    macAddress[4] = (byte)(unitNumber >> 8);
                                    macAddress[5] = (byte)unitNumber;
                                    dataFlashConfig.MacAddress = macAddress;
                                    dataFlashConfig.Update();
                                    // Reboot for the new MAC address to take effect
                                    Application.Closing = true;
                                    return;
                                }
                            }
                        }
                    }

                    // Prepare update manager - USB is cleaning folders using this instance
                    FirmwareUpdater.CreateInstance();

                    // Reconnect USB
                    usbDevice_DeviceDisconnected(null, null);
                    UsbDevice.Instance.DeviceConnected += new EventHandler<EventArgs>(usbDevice_DeviceConnected);
                    UsbDevice.Instance.DeviceDisconnected += new EventHandler<EventArgs>(usbDevice_DeviceDisconnected);

                    // Set initial inputs states for onboard inputs
                    StatusManager.Instance.SetOnboardInputs((inputNumber) =>
                    {
                        return OnboardInputs.Instance.GetInputPointStatus(inputNumber);
                    });

                    // Startup Card Reader Manager
                    singletons.CreateInstanceAndRegister<CardReaderManager>();

                    // Prepare for receiving commands from controller                    
                    CommandProcessor.CreateInstance(FirmwareUpdater.Instance, CardReaderManager.Instance);

                    StatusLed.SetStatus(SystemStatus.OfflineToController);

                    // Start scanning expansion cards
                    ExpansionCardManager.CreateInstance();
                    // Hold off execution till all of the inputs have settled
                    while (ExpansionCardManager.Instance.Initialized == false || OnboardInputs.Instance.Initialized == false)
                    {
                        Thread.Sleep(100);
                    }
                    StatusManager.Instance.SetExpansionManager(ExpansionCardManager.Instance);

                    // Set initial inputs states for expansion cards
                    StatusManager.Instance.SetInputs<Pacom8204InputCard>(new OwnerType[] { OwnerType.Expansion1, OwnerType.Expansion2, OwnerType.Expansion3, OwnerType.Expansion4 },
                        (slotNumber) => { return ExpansionCardManager.Instance.InputExpansionCard(slotNumber); },
                        (card, inputNumber) => { return card.GetInputPointStatus(inputNumber); });
                    StatusManager.Instance.SetInputs<Pacom8208SartCard>(new OwnerType[] { OwnerType.Sart1 },
                        (slotNumber) => { return ExpansionCardManager.Instance.SartExpansionCard(slotNumber); },
                        (card, inputNumber) => { return card.GetInputPointStatus(inputNumber); }
                    );

                    // Clear all outputs
                    StatusManager.Instance.Outputs.ClearAllOutputs();

                    // Prepare web update mechanism
                    FirmwareUpdaterManager.OnDownloadLocationCleanup += new EventHandler<EventArgs>(firmwareUpdaterManager_OnDownloadLocationCleanup);
                    FirmwareUpdaterManager.OnUpdate += new EventHandler<EventArgs>(firmwareUpdaterManager_OnUpdate);

                    // Prepare web restart application
                    ShutdownManager.CloseApplication += new EventHandler<EventArgs>(shutdownManager_CloseApplication);

                    // Print System Summary 
                    ConfigurationManager.Instance.PrintSystemSummary();

                    singletons.CreateInstanceAndRegister<SyslogManager>();

                    // Startup communications to controller
                    singletons.CreateInstanceAndRegister<CommunicationsManager>();
                    singletons.CreateInstanceAndRegister<CardReaderManagerSubscriber>(DeviceResponseProcessor.Instance);

                    // Refresh power supply status
                    StatusManager.Instance.Device.PowerSupplyStatus = Pcb.PowerSupplyStatus;

                    // Create web server instance
                    startupWebServer();

                    // Subscribe card reader manager to onboard Wiegand events
                    Cri.CardRead += new EventHandler<CardReadEventArgs>(cri_CardRead);

                    singletons.CreateInstanceAndRegister<TimerManager>();
                    TimerManager.Instance.Start();

                    // Subscribe card reader manager to OSDP events
                    singletons.CreateInstanceAndRegister<OsdpDeviceLoopManager>(CardReaderManager.Instance);

                    // Device additional info
                    Logger.OsdpDeviceLoopManager = OsdpDeviceLoopManager.Instance;

                    FirmwareUpdater.Instance.CheckFirmware();
#if DEBUG
                    int memoryStatusCounter = 0;
                    while (Application.Closing == false)
                    {
                        if (memoryStatusCounter <= 0)
                        {
                            Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                            {
                                return NativeMemoryStatus.GetMemoryStatus();
                            });
                            memoryStatusCounter = 3 * 60 * 10; // status every 1 minute
                        }
                        else
                        {
                            memoryStatusCounter--;
                        }
                        Thread.Sleep(100);
                    }
#else
                    Application.WaitOnClose();
#endif

                    Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return "Application is closing.";
                    });

                    stopWebServer();

                    // Application is not working anymore. Signal to the user. It may be still changes by communication manager.
                    Hal.StatusLed.SetStatus(SystemStatus.OfflineToController);
                }
            }
            catch (Exception ex)
            {
                Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return "Application caught an unhandled exception : " + ex.ToString();
                });
            }

            // Application is not working anymore. Turnoff the status led.
            Hal.StatusLed.SetStatus(SystemStatus.Terminating);

            Application.Closing = true;
            Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
            {
                return "Application closed.";
            });
            Thread.Sleep(300);
            Pcb.DeactivateOnboardRs485Driver();

            if (WatchdogTimer.Instance != null)
                WatchdogTimer.Instance.Dispose();

#if DEBUG_RESET
            // Enable watchdog timer
            Hal.Gpio.ClearOutput(GpioPort.PortA, 9);
            Hal.Gpio.ConfigurePin(GpioPort.PortA, 9, true, false, false);
            Hal.Gpio.ClearOutput(GpioPort.PortC, 11);
            Hal.Gpio.ConfigurePin(GpioPort.PortC, 11, true, false, false);
#endif

            return;
        }

        #region Web Server startup and configuration changes

        /// <summary>
        /// Startup the web server
        /// </summary>
        private static void startupWebServer()
        {
            try
            {
                // Always subscribe to the config change event
                ConfigurationManager.Instance.ConfigurationChanged += new EventHandler<EventArgs>(configurationManager_ConfigurationWebServerProcessChanged);

                if (ConfigurationManager.Instance.WebServerEnabled == true)
                {
                    int port = ConfigurationManager.Instance.WebServerPort;
                    string password = ConfigurationManager.Instance.WebServerPassword;
                    // Start server
                    httpServerAsync = new HttpServerAsync(port, new WebRequestHandler(new WebsiteRequestHandler()));
                    httpServerAsync.EnableAuthentication(@"Interface Board", @"admin", password);
                    httpServerAsync.Start();
                    // Firewall will be switched on in its own thread
                }
                else
                {
                    httpServerAsync = null;
                }
            }
            catch (Exception ex)
            {
                Logger.LogErrorMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return string.Format("Web Server startup failure. {0}", ex.Message);
                });
            }
        }

        /// <summary>
        /// Stop web server handling
        /// </summary>
        private static void stopWebServer()
        {
            // Shutdown web server
            if (httpServerAsync != null)
            {
                httpServerAsync.Dispose();
                // Firewall will be switched off in its own thread
            }
        }

        /// <summary>
        /// Handle any configuration changes. See if the web server must reconfigure itself.
        /// </summary>
        /// <param name="sender">Not used</param>
        /// <param name="e">Not used</param>
        private static void configurationManager_ConfigurationWebServerProcessChanged(object sender, EventArgs e)
        {
            try
            {
                bool enabled = ConfigurationManager.Instance.WebServerEnabled;
                int port = ConfigurationManager.Instance.WebServerPort;
                string password = ConfigurationManager.Instance.WebServerPassword;
                if (httpServerAsync != null)
                {
                    if (enabled == false || httpServerAsync.Port != port)
                    {
                        try
                        {
                            // Stop Server
                            httpServerAsync.Stop();
                            httpServerAsync.Dispose();
                            httpServerAsync = null;
                        }
                        catch
                        {
                            // Any shutdown error are not important
                        }

                        // Firewall will be reloaded in its own thread

                        if (enabled)
                        {
                            // Start server
                            httpServerAsync = new HttpServerAsync(port, new WebRequestHandler(new WebsiteRequestHandler()));
                            httpServerAsync.EnableAuthentication(@"Interface Board", @"admin", password);
                            httpServerAsync.Start();
                        }
                    }
                    else if (httpServerAsync.AccessPassword != password)
                    {
                        httpServerAsync.AccessPassword = password;
                    }
                }
                else
                {
                    if (enabled)
                    {
                        httpServerAsync = new HttpServerAsync(port, new WebRequestHandler(new WebsiteRequestHandler()));
                        httpServerAsync.EnableAuthentication(@"Interface Board", @"admin", password);
                        httpServerAsync.Start();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return string.Format("CONFIG: Error while changing settings for web server. {0}", ex.Message);
                });
            }
        }

        #endregion

        #region Hanble USB events

        private static void usbDevice_DeviceConnected(object sender, EventArgs e)
        {
            Logger.WriteLogsToDisk();
            UsbDevice.Instance.AllowNewUsbConnection();
        }

        private static void usbDevice_DeviceDisconnected(object sender, EventArgs e)
        {
            try
            {
                while (true)
                {
                    if (Directory.Exists(FileSystemPaths.PublicRegionRootDirectory))
                        break;
                    Thread.Sleep(10);
                }
                ConfigurationManager.Instance.UpdateConfigFile(ConfigurationUpdateReason.UsbDisconnection);
                // Empty download folder
                FirmwareUpdater.Instance.DeleteFilesFromDownload();
                // Look for update file. The bdt and bin files must have same name before extension.
                string[] binFiles = Directory.GetFiles(FileSystemPaths.PublicRegionRootDirectory, "*.bin");
                string[] bdtFiles = Directory.GetFiles(FileSystemPaths.PublicRegionRootDirectory, "*.bdt");
                if (binFiles.Length == 1 && bdtFiles.Length == 1 &&
                    (binFiles[0].ToLower().Replace(".bin", "") == bdtFiles[0].ToLower().Replace(".bdt", "")))
                {
                    Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return "Found update image. Processing...";
                    });
                    // Delete bdt file
                    File.Delete(bdtFiles[0]);

                    // Process upgrade file
                    File.Move(binFiles[0], binFiles[0].Replace(FileSystemPaths.PublicRegionRootDirectory, FileSystemPaths.DownloadPath));
                    FirmwareUpdater.Instance.PerformUpdate();
                }
                else if (binFiles.Length != 0 || bdtFiles.Length != 0)
                {
                    // Cleanup bin and bdt files
                    Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                    {
                        return "Cleaning up Public Region.";
                    });
                    foreach (string file in binFiles)
                    {
                        File.Delete(file);
                    }
                    foreach (string file in bdtFiles)
                    {
                        File.Delete(file);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return "UpdateException " + ex.ToString();
                });
            }
        }

        #endregion

        private static void configurationManager_SystemTimeChanged(object sender, SystemTimeChangeArgs e)
        {
            ConfigurationManager.Instance.UpdateManagerStartDateTime(e.Difference);
        }

        private static void firmwareUpdaterManager_OnUpdate(object sender, EventArgs e)
        {
            FirmwareUpdater.Instance.PerformUpdate();
        }

        private static void firmwareUpdaterManager_OnDownloadLocationCleanup(object sender, EventArgs e)
        {
            FirmwareUpdater.Instance.DeleteFilesFromDownload();
        }

        private static void shutdownManager_CloseApplication(object sender, EventArgs e)
        {
            Application.Closing = true;
        }

        private static void currentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Logger.LogCriticalMessage(LoggerClassPrefixes.HostingApplication, () =>
            {
                return "UnhandledException " + e.ExceptionObject.ToString();
            });
        }

        private static void statusManager_ConnectedToControllerChanged(object sender, ConnectedToControllerEventArgs e)
        {
            if (e.Connected == false)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.HostingApplication, () =>
                {
                    return "Offline to controller on all connections.";
                });
                StatusManager.Instance.Outputs.ClearAllOutputs();
            }
        }

        private static void statusManager_AccessControlCommandRequested(object sender, AccessControlCommandRequestEventArgs e)
        {
            if (StatusManager.Instance.Readers[e.LogicalReaderId].IsEnabled == false)
                return;

            List<int> doorHardware = null;
            foreach (int doorId in CardReaderHardwareLocations.HandledLogicalDoorIds)
            {
                if (CardReaderHardwareLocations.DoorReadersIds[doorId].Contains(e.LogicalReaderId))
                {
                    doorHardware = CardReaderHardwareLocations.OnboardDoorOutputIds[doorId];
                    break;
                }
            }
            if (doorHardware == null)
                return;
            
            if (e.IsIncluded(AccessCommandType.Buzzer) == true)
            {
                AccessCommandBuzzerConfig buzzerCommand = e[AccessCommandType.Buzzer] as AccessCommandBuzzerConfig;
                if (buzzerCommand != null)
                {
                    if ((buzzerCommand.BuzzerType & CardReaderBuzzerType.BuzzerOn) == CardReaderBuzzerType.BuzzerOn)
                        OnboardOutputs.Instance.SetOutput(doorHardware[CardReaderHardwareLocations.DoorOutputBuzzerIndex]);
                    else
                        OnboardOutputs.Instance.ClearOutput(doorHardware[CardReaderHardwareLocations.DoorOutputBuzzerIndex]);
                }
            }
            if (e.IsIncluded(AccessCommandType.AcceptLed) == true)
            {
                AccessCommandAcceptLedConfig acceptCommand = e[AccessCommandType.AcceptLed] as AccessCommandAcceptLedConfig;
                if (acceptCommand != null)
                {
                    if ((acceptCommand.AcceptLedType & CardReaderLedType.LedOn) == CardReaderLedType.LedOn)
                        OnboardOutputs.Instance.SetOutput(doorHardware[CardReaderHardwareLocations.DoorOutputGreenLedIndex]);
                    else
                        OnboardOutputs.Instance.ClearOutput(doorHardware[CardReaderHardwareLocations.DoorOutputGreenLedIndex]);
                }
            }
            if (e.IsIncluded(AccessCommandType.DeniedLed) == true)
            {
                AccessCommandDeniedLedConfig deniedCommand = e[AccessCommandType.DeniedLed] as AccessCommandDeniedLedConfig;
                if (deniedCommand != null)
                {
                    if ((deniedCommand.DeniedLedType & CardReaderLedType.LedOn) == CardReaderLedType.LedOn)
                        OnboardOutputs.Instance.SetOutput(doorHardware[CardReaderHardwareLocations.DoorOutputRedLedIndex]);
                    else
                        OnboardOutputs.Instance.ClearOutput(doorHardware[CardReaderHardwareLocations.DoorOutputRedLedIndex]);
                }
            }
        }

        private static void configurationManager_ConfigurationChanged(object sender, EventArgs e)
        {
            // Update logging level
            Logger.SetLoggingLevel(ConfigurationManager.Instance.LoggingLevel);

            // Update Red LED incase the 'Allow Reader LEDs to Turn Off' setting has changed
            foreach (int doorId in CardReaderHardwareLocations.HandledLogicalDoorIds)
            {
                StatusManager.Instance.Doors[doorId].UpdateDeniedLedState();
            }
        }

        private static void cri_CardRead(object sender, CardReadEventArgs e)
        {
            try
            {
                // Skip cards with less than 4 bits.
                if (e.CardLength < 4)
                    return;
                // Process card scan.
                byte readerByte = getCardReaderNumber(e.CardReaderNumber);
                if (Enum.IsDefined(typeof(CardReaderPortType), readerByte) == true)
                {
                    CardReaderPortType reader = (CardReaderPortType)readerByte;
                    if (reader == CardReaderPortType.NoReader)
                        return;
                    // Update status manager. Set the reader as online.
                    int readerLogicalId = readerByte + 1;
                    StatusManager statusManager = StatusManager.Instance;
                    if (statusManager != null)
                        statusManager.Readers[readerLogicalId].SetWiegandOnline();
                    // Send card for processing
                    ICardReaderManager cardReaderManager = CardReaderManager.Instance;
                    if (cardReaderManager != null)
                        cardReaderManager.ProcessScan(reader, e.CardLength, e.ReadCardNumber, e.CollisionOccurred == false);
                }
            }
            catch (Exception ex)
            {
                Logger.LogDebugMessage(LoggerClassPrefixes.CardReaderInterface, () =>
                {
                    return string.Format("Unable to process card scan. {0}", ex.Message);
                });
            }
        }

        /// <summary>
        /// During disposing the SingletonList will call this method when reset is required.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        static void Program_ForcedResetRequired(object sender, EventArgs e)
        {
            Hal.WatchdogTimer.Instance.Dispose();
#if !DEBUG
            // Enable watchdog timer
            Hal.Gpio.ClearOutput(GpioPort.PortA, 9);
            Hal.Gpio.ConfigurePin(GpioPort.PortA, 9, true, false, false);
            Hal.Gpio.ClearOutput(GpioPort.PortC, 11);
            Hal.Gpio.ConfigurePin(GpioPort.PortC, 11, true, false, false);
#endif
        }
    }
}
